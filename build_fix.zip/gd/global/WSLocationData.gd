extends Node



var city_data: = {}


var building_list_dic: = {}



var hero_location_cache = {}

const LOCATION_SIZE_MAX_FACTOR: = 100.0

const DEFAULT_BUTTON_TYPE_LIST_CITY: = [
    LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
    LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
    LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
    LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
    LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
    LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
]

const DEFAULT_BUTTON_TYPE_LIST_CASTLE: = [
    LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
]

const DEFAULT_BUTTON_TYPE_LIST_VILLAGE: = [
    LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
    LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,

]

const INIT_CITY_DATA: = {
    "MWCity0001": {

        "population_total": 2200,
        "population_working_age": 2200,
        "consumption_goods": 1800,
        "excess_goods": 1000,
        "happiness_level": 500,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA,

        "recruit": [],











    },
    "MWCity0002": {
        "population_total": 8100,
        "population_working_age": 4200,
        "consumption_goods": 2000,
        "excess_goods": 1100,
        "happiness_level": 550,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWCity0003": {
        "population_total": 8000,
        "population_working_age": 4000,
        "consumption_goods": 1800,
        "excess_goods": 1200,
        "happiness_level": 550,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWCity0004": {
        "population_total": 8400,
        "population_working_age": 4400,
        "consumption_goods": 2000,
        "excess_goods": 1600,
        "happiness_level": 550,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWCity0005": {
        "population_total": 8100,
        "population_working_age": 4000,
        "consumption_goods": 1700,
        "excess_goods": 1300,
        "happiness_level": 500,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWCity0006": {
        "population_total": 8150,
        "population_working_age": 4100,
        "consumption_goods": 1850,
        "excess_goods": 1100,
        "happiness_level": 550,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWCity0007": {
        "population_total": 8000,
        "population_working_age": 4000,
        "consumption_goods": 1600,
        "excess_goods": 1100,
        "happiness_level": 500,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWCity0008": {
        "population_total": 8100,
        "population_working_age": 4100,
        "consumption_goods": 1700,
        "excess_goods": 1200,
        "happiness_level": 500,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWCastle0001": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWCastle0002": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWCastle0003": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWCastle0004": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWCastle0005": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR,
    },
    "MWCastle0006": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR,
    },
    "MWCastle0007": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL,
    },
    "MWCastle0008": {
        "population_total": 0,
        "population_working_age": 0,
        "consumption_goods": 0,
        "excess_goods": 0,
        "happiness_level": 0,
        "tax_ratio": 0.2,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL,
    },
    "MWVillage0001": {
        "population_total": 800,
        "population_working_age": 400,
        "consumption_goods": 400,
        "excess_goods": 400,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA,
    },
    "MWVillage0002": {
        "population_total": 750,
        "population_working_age": 350,
        "consumption_goods": 350,
        "excess_goods": 350,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0003": {
        "population_total": 780,
        "population_working_age": 380,
        "consumption_goods": 380,
        "excess_goods": 380,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0004": {
        "population_total": 760,
        "population_working_age": 360,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0005": {
        "population_total": 770,
        "population_working_age": 370,
        "consumption_goods": 370,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0006": {
        "population_total": 740,
        "population_working_age": 340,
        "consumption_goods": 340,
        "excess_goods": 340,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0007": {
        "population_total": 750,
        "population_working_age": 350,
        "consumption_goods": 370,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0008": {
        "population_total": 780,
        "population_working_age": 380,
        "consumption_goods": 380,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0009": {
        "population_total": 800,
        "population_working_age": 400,
        "consumption_goods": 380,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0010": {
        "population_total": 780,
        "population_working_age": 380,
        "consumption_goods": 370,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.LUCIANA
    },
    "MWVillage0011": {
        "population_total": 360,
        "population_working_age": 360,
        "consumption_goods": 380,
        "excess_goods": 380,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0012": {
        "population_total": 380,
        "population_working_age": 380,
        "consumption_goods": 350,
        "excess_goods": 350,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0013": {
        "population_total": 340,
        "population_working_age": 340,
        "consumption_goods": 350,
        "excess_goods": 350,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0014": {
        "population_total": 380,
        "population_working_age": 380,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0015": {
        "population_total": 400,
        "population_working_age": 400,
        "consumption_goods": 380,
        "excess_goods": 380,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0016": {
        "population_total": 390,
        "population_working_age": 390,
        "consumption_goods": 390,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0017": {
        "population_total": 390,
        "population_working_age": 390,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0018": {
        "population_total": 380,
        "population_working_age": 380,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0019": {
        "population_total": 350,
        "population_working_age": 350,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0020": {
        "population_total": 360,
        "population_working_age": 360,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.EDRAS
    },
    "MWVillage0021": {
        "population_total": 370,
        "population_working_age": 370,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0022": {
        "population_total": 380,
        "population_working_age": 380,
        "consumption_goods": 380,
        "excess_goods": 380,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0023": {
        "population_total": 380,
        "population_working_age": 380,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0024": {
        "population_total": 400,
        "population_working_age": 400,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0025": {
        "population_total": 410,
        "population_working_age": 410,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0026": {
        "population_total": 400,
        "population_working_age": 400,
        "consumption_goods": 370,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0027": {
        "population_total": 370,
        "population_working_age": 370,
        "consumption_goods": 370,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0028": {
        "population_total": 370,
        "population_working_age": 370,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0029": {
        "population_total": 370,
        "population_working_age": 370,
        "consumption_goods": 400,
        "excess_goods": 400,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0030": {
        "population_total": 370,
        "population_working_age": 370,
        "consumption_goods": 370,
        "excess_goods": 370,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.DORDAR
    },
    "MWVillage0031": {
        "population_total": 380,
        "population_working_age": 380,
        "consumption_goods": 380,
        "excess_goods": 380,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0032": {
        "population_total": 370,
        "population_working_age": 370,
        "consumption_goods": 380,
        "excess_goods": 380,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0033": {
        "population_total": 340,
        "population_working_age": 340,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0034": {
        "population_total": 350,
        "population_working_age": 350,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0035": {
        "population_total": 360,
        "population_working_age": 360,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0036": {
        "population_total": 390,
        "population_working_age": 390,
        "consumption_goods": 390,
        "excess_goods": 390,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0037": {
        "population_total": 360,
        "population_working_age": 360,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0038": {
        "population_total": 350,
        "population_working_age": 350,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
    "MWVillage0039": {
        "population_total": 340,
        "population_working_age": 340,
        "consumption_goods": 360,
        "excess_goods": 360,
        "happiness_level": 500,
        "belong_country": WSCountryData.COUNTRY_NAME_ENUM.HASKAL
    },
}


const CITY_SYSTEM_DATA: = {
    "MWCity0001": {
        "name": "阿尔塔利斯",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(28 * LOCATION_SIZE_MAX_FACTOR),
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB,
        "generate_mercenary_config": LocationConfig.DEFAULT_GENERATE_MERCENARY_CONFIG,
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],

        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0001Tavern"
        },
        "specialty_grocery": {
            "food_0001": 110,
            "food_0002": 90,

            "food_0004": 60,
            "food_0005": 40,

            "food_0007": 40,
            "food_0008": -60,

            "food_0010": 80,

            "food_0012": 100,

            "food_0014": 70,

            "food_0016": -30,
            "food_0017": -70,
            "food_0018": -40,
            "food_0019": -40,

            "food_0021": -70,
            "food_0022": -100,
            "food_0023": -80,
            "food_0024": -80,
            "commodity_0001": -70,
            "commodity_0002": -60,
            "commodity_0003": -50,
            "commodity_0004": 150,
            "commodity_0005": 80,


            "commodity_0008": 140,
            "commodity_0009": -80,
            "commodity_0010": -130,
            "commodity_0011": -150,
            "commodity_0012": -170,
            "commodity_0013": 50,
            "commodity_0014": -130,
            "commodity_0015": 135,
            "commodity_0016": 90,
            "commodity_0017": -20,
            "commodity_0018": 0,
            "commodity_0019": -100,
            "commodity_0020": -80,
            "commodity_0021": -130,
            "commodity_0022": -40,
            "commodity_0023": -150,
            "commodity_0024": -60,
            "commodity_0025": -50,
            "commodity_0026": -170,
            "commodity_0027": -70,
            "commodity_0028": -60,
            "commodity_0029": -150,
            "commodity_0030": -80,
             "commodity_0031": -90,
            "food_0028": 100,
            "food_0029": 100,
        },
    },
    "MWCity0002": {
        "name": "维林多尔",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(31 * LOCATION_SIZE_MAX_FACTOR),
        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0002Tavern"
        },
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 0.8,
        "generate_mercenary_config": LocationConfig.DEFAULT_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {
            "food_0001": 100,



            "food_0005": 80,
            "food_0006": 100,

            "food_0008": -80,
            "food_0009": -80,
            "food_0010": -100,
            "food_0011": -50,
            "food_0012": -80,
            "food_0013": -100,
            "food_0014": 80,
            "food_0015": 70,
            "food_0016": -70,
            "food_0017": -50,
            "food_0018": -30,
            "food_0019": -50,

            "food_0021": -50,
            "food_0022": -80,
            "food_0023": -100,
            "food_0024": -70,
            "commodity_0001": 90,
            "commodity_0002": 150,
            "commodity_0003": 70,
            "commodity_0004": 130,
            "commodity_0005": 55,
            "commodity_0006": 100,

            "commodity_0008": -95,
            "commodity_0009": -20,
            "commodity_0010": -150,
            "commodity_0011": -130,
            "commodity_0012": -150,
            "commodity_0013": 170,
            "commodity_0014": 130,
            "commodity_0015": 70,
            "commodity_0016": -130,


            "commodity_0020": 80,
            "commodity_0021": -60,
            "commodity_0022": -170,
            "commodity_0023": -100,
            "commodity_0024": -80,
            "commodity_0025": -60,
            "commodity_0026": -150,
            "commodity_0027": -150,
            "commodity_0028": -70,
            "commodity_0029": -150,
            "commodity_0030": -100,
             "commodity_0031": -90,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],
    },
    "MWCity0003": {
        "name": "德拉",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(26 * LOCATION_SIZE_MAX_FACTOR),
        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0003Tavern"
        },
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 1.3,
        "generate_mercenary_config": LocationConfig.DEFAULT_NEAR_RESETO_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {

            "food_0002": 90,
            "food_0003": 0,
            "food_0004": 0,



            "food_0008": 100,

            "food_0010": 100,
            "food_0011": 0,


            "food_0014": 110,
            "food_0015": 70,
            "food_0016": 60,

            "food_0018": 50,
            "food_0019": 80,
            "food_0020": 50,
            "food_0021": -40,
            "food_0022": -60,
            "food_0023": -70,
            "food_0024": -60,
            "commodity_0001": -60,
            "commodity_0002": -50,
            "commodity_0003": -80,
            "commodity_0004": -60,
            "commodity_0005": 100,

            "commodity_0007": 100,
            "commodity_0008": 55,
            "commodity_0009": -90,
            "commodity_0010": -100,
            "commodity_0011": -140,
            "commodity_0012": -80,
            "commodity_0013": 0,
            "commodity_0014": -150,
            "commodity_0015": -20,
            "commodity_0016": 150,
            "commodity_0017": -50,
            "commodity_0018": 70,
            "commodity_0019": -60,
            "commodity_0020": 140,

            "commodity_0022": -110,
            "commodity_0023": -80,
            "commodity_0024": -160,
            "commodity_0025": -70,
            "commodity_0026": -60,
            "commodity_0027": -50,
            "commodity_0028": -180,
            "commodity_0029": -70,
            "commodity_0030": -70,
             "commodity_0031": -80,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],
    },
    "MWCity0004": {
        "name": "克里斯塔拉",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(32 * LOCATION_SIZE_MAX_FACTOR),
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 1.5,
        "generate_mercenary_config": LocationConfig.DEFAULT_NEAR_RESETO_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {
            "food_0001": 90,

            "food_0003": 70,




            "food_0008": 110,
            "food_0009": 70,


            "food_0012": -10,
            "food_0013": 40,
            "food_0014": -20,
            "food_0015": 0,
            "food_0016": 90,
            "food_0017": 90,


            "food_0020": 55,
            "food_0021": -30,
            "food_0022": -45,
            "food_0023": -80,
            "food_0024": -50,
            "commodity_0001": -50,
            "commodity_0002": -40,
            "commodity_0003": 130,
            "commodity_0004": 90,

            "commodity_0006": 140,
            "commodity_0007": -80,

            "commodity_0009": 120,
            "commodity_0010": 75,
            "commodity_0011": 80,

            "commodity_0014": 0,
            "commodity_0015": 0,
            "commodity_0016": -150,
            "commodity_0017": -150,
            "commodity_0018": -140,

            "commodity_0020": -105,
            "commodity_0021": -70,
            "commodity_0022": -40,
            "commodity_0023": -10,
            "commodity_0024": -160,
            "commodity_0025": -120,
            "commodity_0026": -50,
            "commodity_0027": -190,
            "commodity_0028": -155,
            "commodity_0029": -15,
            "commodity_0030": -55,
             "commodity_0031": -105,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],

        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0004Tavern"
        },
    },
    "MWCity0005": {
        "name": "泰伦城",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(26.5 * LOCATION_SIZE_MAX_FACTOR),
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 1.1,
        "generate_mercenary_config": LocationConfig.MARKA_NEAR_KREVUR_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {
            "food_0001": 130,

            "food_0003": -10,
            "food_0004": 90,
            "food_0005": 0,
            "food_0006": 70,
            "food_0007": 100,

            "food_0009": 80,

            "food_0011": -20,
            "food_0012": 0,

            "food_0014": 0,
            "food_0015": -50,

            "food_0017": 110,
            "food_0018": 95,
            "food_0019": 100,

            "food_0021": -30,
            "food_0022": -35,
            "food_0023": -70,
            "food_0024": -40,



            "commodity_0004": -20,


            "commodity_0007": 80,
            "commodity_0008": -70,
            "commodity_0009": -170,
            "commodity_0010": -100,
            "commodity_0011": -80,
            "commodity_0012": 70,


            "commodity_0015": -70,
            "commodity_0016": -80,
            "commodity_0017": 70,


            "commodity_0020": -50,
            "commodity_0021": -50,
            "commodity_0022": 100,


            "commodity_0025": 90,
            "commodity_0026": 100,
            "commodity_0027": -160,
            "commodity_0028": -80,
            "commodity_0029": -90,
            "commodity_0030": -150,
             "commodity_0031": -70,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],
        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0005Tavern"
        },
    },
    "MWCity0006": {
        "name": "兰达尔城",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(27 * LOCATION_SIZE_MAX_FACTOR),
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 1.2,
        "generate_mercenary_config": LocationConfig.MARKA_NEAR_KREVUR_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {
            "food_0001": 120,


            "food_0004": -30,

            "food_0006": 0,
            "food_0007": 110,
            "food_0008": 80,
            "food_0009": 75,




            "food_0014": -5,
            "food_0015": -35,

            "food_0017": 80,
            "food_0018": 100,
            "food_0019": 70,
            "food_0020": 70,
            "food_0021": -10,
            "food_0022": -30,
            "food_0023": -50,
            "food_0024": -30,
            "commodity_0001": -30,
            "commodity_0002": -20,
            "commodity_0003": -10,
            "commodity_0004": -10,
            "commodity_0005": 85,



            "commodity_0009": -120,
            "commodity_0010": -60,
            "commodity_0011": -180,
            "commodity_0012": -80,
            "commodity_0013": 100,
            "commodity_0014": -50,

            "commodity_0016": -60,



            "commodity_0020": -40,
            "commodity_0021": -40,
            "commodity_0022": 140,
            "commodity_0023": 40,
            "commodity_0024": 90,

            "commodity_0026": 160,
            "commodity_0027": -90,
            "commodity_0028": -70,
            "commodity_0029": -120,
            "commodity_0030": -170,
             "commodity_0031": -30,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],
        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0006Tavern"
        },
    },
    "MWCity0007": {
        "name": "吉尔沙",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(26 * LOCATION_SIZE_MAX_FACTOR),
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 0.9,
        "generate_mercenary_config": LocationConfig.SHALUK_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {
            "food_0001": -10,
            "food_0002": -20,
            "food_0003": -50,
            "food_0004": -80,
            "food_0005": -70,
            "food_0006": -50,
            "food_0007": 0,

            "food_0009": -100,
            "food_0010": -60,
            "food_0011": -80,
            "food_0012": -20,
            "food_0013": -20,
            "food_0014": -80,
            "food_0015": -40,
            "food_0016": 100,
            "food_0017": 0,
            "food_0018": 0,
            "food_0019": 0,
            "food_0020": -50,
            "food_0021": 50,
            "food_0022": 110,
            "food_0023": 80,
            "food_0024": 80,
            "commodity_0001": -40,
            "commodity_0002": -20,
            "commodity_0003": -10,
            "commodity_0004": -70,
            "commodity_0005": -20,
            "commodity_0006": -20,
            "commodity_0007": -30,

            "commodity_0009": -60,
            "commodity_0010": 80,
            "commodity_0012": -80,
            "commodity_0013": -20,
            "commodity_0014": -80,
            "commodity_0015": 40,
            "commodity_0016": -50,


            "commodity_0019": 50,
            "commodity_0020": -70,
            "commodity_0021": -70,
            "commodity_0022": -120,
            "commodity_0023": -80,
            "commodity_0024": -60,
            "commodity_0025": -50,
            "commodity_0026": -80,
            "commodity_0027": 110,
            "commodity_0028": 80,
            "commodity_0029": 90,
            "commodity_0030": 110,
             "commodity_0031": 60,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],
        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0007Tavern"
        },
    },
    "MWCity0008": {
        "name": "伊多拉",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CITY,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(29 * LOCATION_SIZE_MAX_FACTOR),
        "mercenary_spawn_prob": LocationConfig.DEFAULT_MERCENARY_SPAWN_PROB * 0.7,
        "generate_mercenary_config": LocationConfig.SHALUK_GENERATE_MERCENARY_CONFIG,
        "specialty_grocery": {
            "food_0001": -20,
            "food_0002": -40,
            "food_0003": -20,
            "food_0004": -100,
            "food_0005": -50,
            "food_0006": -100,
            "food_0007": -20,
            "food_0008": 70,
            "food_0009": -100,
            "food_0010": -30,
            "food_0011": -40,
            "food_0012": -100,
            "food_0013": -50,
            "food_0014": -30,
            "food_0015": -95,
            "food_0016": -50,
            "food_0017": -60,
            "food_0018": -50,
            "food_0019": -60,
            "food_0020": -30,
            "food_0021": 120,
            "food_0022": 40,
            "food_0023": 90,
            "food_0024": 110,
            "commodity_0001": -10,

            "commodity_0003": -30,
            "commodity_0004": -40,
            "commodity_0005": -40,
            "commodity_0006": -70,
            "commodity_0007": -100,
            "commodity_0008": 80,
            "commodity_0009": -50,
            "commodity_0010": -70,
            "commodity_0011": -50,
            "commodity_0012": -130,
            "commodity_0013": -100,
            "commodity_0014": -100,

            "commodity_0016": -60,

            "commodity_0018": 70,

            "commodity_0020": -90,
            "commodity_0021": -90,
            "commodity_0022": -100,
            "commodity_0023": -100,
            "commodity_0024": -80,
            "commodity_0025": -80,
            "commodity_0026": -100,
            "commodity_0027": 80,
            "commodity_0028": 100,
            "commodity_0029": 110,

             "commodity_0031": 90,
            "food_0028": 100,
            "food_0029": 100,
        },
        "button_type_list": [
            LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY,
            LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL,
        ],
        "enter_build_config": {
            LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN: "SpecialBuildCity0008Tavern"
        },
    },
    "MWCastle0001": {
        "name": "钢铁烽火要塞",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(16 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0002": {
        "name": "翡翠平原要塞",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(20 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0003": {
        "name": "黑鹰堡",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(20 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0004": {
        "name": "夜幕堡",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(19 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0005": {
        "name": "绿岚堡",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(18 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0006": {
        "name": "金翼堡",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(17 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0007": {
        "name": "烈阳堡",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(19 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWCastle0008": {
        "name": "星之堡",
        "type": LocationConstants.LOCATION_TYPE_ENUM.CASTLE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(18 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

        }
    },
    "MWVillage0001": {
        "name": "奥林塔尔村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(7.0 * LOCATION_SIZE_MAX_FACTOR),

        "specialty_grocery": {

            "food_0005": 200,
            "food_0002": 100,
            "food_0004": 100,
            "commodity_0006": 50,
            "commodity_0007": 50,
            "food_0014": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0002": {
        "name": "古德瑞姆村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.0 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "food_0010": 200,
            "commodity_0002": 100,
            "food_0012": 50,
            "commodity_0004": 50,
            "commodity_0013": 50,
            "commodity_0008": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0003": {
        "name": "斯托尔加德村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "food_0001": 100,
            "commodity_0002": 100,
            "commodity_0001": 100,
            "food_0014": 80,
            "food_0012": 50,
            "food_0005": 50,
            "commodity_0013": 50,
            "commodity_0008": 50,
            "food_0015": 40,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0004": {
        "name": "拉尼斯特拉村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.8 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0003": 100,
            "food_0001": 100,
            "food_0002": 100,
            "food_0005": 100,
            "food_0004": 50,
            "commodity_0009": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0005": {
        "name": "阿尔瓦尼亚村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.7 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0001": 150,
            "commodity_0007": 150,
            "food_0001": 100,
            "food_0004": 50,
            "commodity_0013": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0006": {
        "name": "赫夫宾斯克村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.2 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0001": 150,
            "commodity_0007": 150,
            "food_0004": 100,
            "food_0006": 50,
            "commodity_0014": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0007": {
        "name": "亚拉尼斯村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.2 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0005": 150,
            "commodity_0006": 100,
            "commodity_0013": 100,
            "commodity_0014": 100,
            "food_0014": 60,
            "food_0001": 50,
            "food_0004": 50,
            "food_0006": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0008": {
        "name": "卡拉斯特村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.8 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0001": 200,
            "commodity_0002": 100,
            "commodity_0006": 100,
            "food_0006": 100,
            "commodity_0003": 50,
            "food_0005": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0009": {
        "name": "翡翠村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(7.1 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0002": 150,
            "commodity_0006": 150,
            "food_0005": 100,
            "food_0001": 50,
            "commodity_0013": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0010": {
        "name": "翠林村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.ROAO,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0004": 200,
            "commodity_0013": 100,
            "food_0005": 100,
            "commodity_0006": 50,
            "food_0002": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0011": {
        "name": "水晶之河·丽村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.6 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0005": 150,
            "commodity_0013": 100,
            "food_0002": 100,
            "food_0005": 50,
            "food_0009": 50,
            "commodity_0006": 50,
            "food_0014": 40,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0012": {
        "name": "水晶之河·翼村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.8 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0002": 50,
            "commodity_0004": 100,
            "commodity_0005": 100,
            "food_0009": 100,
            "commodity_0006": 50,
            "commodity_0013": 50,
            "food_0006": 50,
            "food_0014": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0013": {
        "name": "水晶之河·光村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.7 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0007": 100,
            "food_0008": 100,
            "food_0009": 100,
            "food_0014": 70,
            "commodity_0011": 50,
            "food_0005": 50,
            "food_0006": 50,
            "commodity_0005": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0014": {
        "name": "铁锚村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.2 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0008": 200,
            "commodity_0007": 100,
            "food_0008": 100,
            "food_0010": 100,
            "food_0014": 40,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0015": {
        "name": "幻光村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(7.0 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "food_0007": 150,
            "commodity_0005": 100,
            "commodity_0006": 100,
            "food_0009": 100,
            "food_0008": 50,
            "commodity_0016": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0016": {
        "name": "蓝潭村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(7.0 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "food_0009": 150,
            "commodity_0003": 150,
            "commodity_0013": 100,
            "commodity_0008": 50,
            "food_0002": 50,
            "food_0003": 50,
            "food_0007": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0003",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0017": {
        "name": "霞光村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0007": 200,
            "commodity_0013": 100,
            "food_0007": 100,
            "commodity_0002": 50,
            "commodity_0005": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0018": {
        "name": "石碑村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0009": 100,
            "commodity_0010": 100,
            "food_0007": 100,
            "commodity_0007": 100,
            "commodity_0001": 50,
            "commodity_0011": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0019": {
        "name": "白羽村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.2 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0004": 150,
            "commodity_0008": 100,
            "commodity_0009": 50,
            "commodity_0011": 50,
            "commodity_0012": 50,
            "food_0008": 50,
            "food_0009": 50,
            "food_0010": 50
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0020": {
        "name": "松风村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SAINA,
        "location_size_max": int(6.6 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {

            "commodity_0007": 100,
            "commodity_0011": 100,
            "commodity_0012": 100,
            "food_0014": 90,
            "food_0015": 50,
            "commodity_0001": 50,
            "commodity_0009": 50,
            "commodity_0010": 50,
            "food_0001": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0021": {
        "name": "雷鸣村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.4 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0001": 100,
            "food_0004": 100,
            "food_0006": 50,
            "food_0007": 50,
            "commodity_0001": 50,
            "commodity_0005": 50,
            "commodity_0007": 50,
            "commodity_0014": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0022": {
        "name": "晨曦村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.8 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0009": 100,
            "food_0019": 100,
            "food_0013": 50,
            "food_0020": 50,
            "commodity_0013": 100,
            "commodity_0022": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0023": {
        "name": "岩谷村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.9 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0001": 100,
            "food_0007": 50,
            "commodity_0002": 50,
            "commodity_0005": 50,
            "commodity_0026": 100,
            "commodity_0023": 50,
            "commodity_0024": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0024": {
        "name": "野歌村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(7.2 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0019": 100,
            "food_0002": 50,
            "food_0004": 100,
            "commodity_0005": 50,
            "commodity_0022": 50,
            "commodity_0024": 50,
            "commodity_0026": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0003",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0025": {
        "name": "风翼村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(7.0 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0009": 50,
            "food_0007": 50,
            "food_0019": 50,
            "food_0010": 50,
            "commodity_0022": 50,
            "commodity_0025": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0026": {
        "name": "格林贝尔村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.8 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0001": 100,
            "food_0007": 100,
            "food_0018": 50,
            "food_0019": 50,
            "commodity_0005": 50,
            "commodity_0006": 50,
            "commodity_0013": 50,
            "commodity_0023": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0027": {
        "name": "达文村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.7 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0007": 50,
            "food_0008": 50,
            "food_0017": 100,
            "food_0018": 50,
            "commodity_0005": 50,
            "commodity_0023": 50,
            "commodity_0024": 50,
            "commodity_0026": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0028": {
        "name": "里奇村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0001": 50,
            "food_0002": 50,
            "food_0007": 50,
            "food_0010": 50,
            "food_0019": 50,
            "commodity_0013": 100,
            "commodity_0024": 100,
            "commodity_0026": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0029": {
        "name": "斯托姆村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.7 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0001": 50,
            "food_0009": 50,
            "food_0017": 100,
            "commodity_0005": 100,
            "commodity_0022": 100,
            "commodity_0026": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0030": {
        "name": "泰特村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.MARKA,
        "location_size_max": int(6.6 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0001": 100,
            "food_0008": 50,
            "food_0010": 50,
            "food_0017": 50,
            "food_0018": 100,
            "commodity_0022": 50,
            "commodity_0026": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0031": {
        "name": "阿尔沙村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.9 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0016": 100,
            "food_0022": 100,
            "food_0024": 50,
            "commodity_0010": 50,
            "commodity_0028": 50,
            "commodity_0030": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0032": {
        "name": "塔尔基村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.6 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0008": 50,
            "food_0021": 50,
            "food_0024": 50,
            "commodity_0027": 100,
            "commodity_0028": 50,
            "commodity_0029": 100,
            "commodity_0031": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0033": {
        "name": "桑德尔村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0021": 100,
            "food_0024": 50,
            "commodity_0008": 50,
            "commodity_0018": 50,
            "commodity_0027": 100,
            "commodity_0031": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0034": {
        "name": "卡尔鲁村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.1 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0008": 50,
            "food_0023": 50,
            "food_0024": 100,
            "commodity_0028": 100,
            "commodity_0029": 100,
            "commodity_0030": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0035": {
        "name": "塞尔塔村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0021": 100,
            "food_0022": 100,
            "food_0023": 50,
            "food_0024": 50,
            "commodity_0018": 50,
            "commodity_0029": 100,
            "commodity_0030": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0036": {
        "name": "拉戈村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.5 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0008": 50,
            "food_0023": 50,
            "food_0024": 100,
            "commodity_0019": 50,
            "commodity_0028": 50,
            "commodity_0030": 50,
            "commodity_0031": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0037": {
        "name": "霍尔多村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.3 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0016": 100,
            "food_0022": 100,
            "food_0024": 50,
            "commodity_0027": 100,
            "commodity_0028": 50,
            "commodity_0030": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0038": {
        "name": "阿尔比村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.3 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0008": 50,
            "food_0021": 50,
            "food_0023": 50,
            "food_0024": 50,
            "commodity_0010": 50,
            "commodity_0029": 100,
            "commodity_0031": 50,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWVillage0039": {
        "name": "斯特尔村",
        "type": LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        "ethnicity": WSCountryData.ETHNICITY_ENUM.SHALUK,
        "location_size_max": int(6.7 * LOCATION_SIZE_MAX_FACTOR),
        "specialty_grocery": {
            "food_0016": 150,
            "food_0021": 50,
            "food_0023": 50,
            "commodity_0019": 50,
            "commodity_0027": 50,
            "commodity_0028": 50,
            "commodity_0030": 100,
        },
        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWSpecialLocation0001": {
        "name": "隐匿矿洞",
        "type": LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION,
        "description": "一个位于森林深处的隐匿矿洞, 入口被茂密的树木与草丛遮掩，难以被发现. 矿洞外围有一片空旷区域, 似乎是为观察周围环境而设置. 尽管洞中蕴藏着丰富资源, 但也隐藏着未知的危险.",

        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            }
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWSpecialLocation0002": {
        "name": "隐匿森林空地",
        "type": LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION,
        "description": "这是一片隐藏在浓密森林深处的小型空地. 四周环绕着高大的树木和繁茂的灌木, 使其难以被外界发现",

        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWSpecialLocation0003": {
        "name": "悬崖洞穴",
        "type": LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION,
        "description": "悬崖洞穴深藏于陡峭崖壁之下, 入口被交错垂落的枯藤与风化岩层遮蔽, 仅有一条狭窄的砾石小径蜿蜒向下延伸至洞口. 洞外平台残留着断裂的木制支架与焦黑篝火痕迹, 暗示曾有冒险者在此短暂停留.",

        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
    "MWSpecialLocation0004": {
        "name": "沙漠绿洲",
        "type": LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION,
        "description": "一个坐落于荒凉沙海中的绿洲据点, 被炽热的阳光笼罩, 周围生长着几棵高大的棕榈树, 为旅人提供难得的荫蔽. 周边散落着零星的帐篷与简陋的泥砖房, 表明曾有人在此驻足. 尽管这里是沙漠中的生机之地, 但远方的风沙与潜伏的危险时刻提醒着人们, 生存并非易事.",

        "build_slot": [
            {
                "code": "slot_0001",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT
            },
            {
                "code": "slot_0002",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
            {
                "code": "slot_0003",
                "type": LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT
            },
        ],
        "build_type_list": DEFAULT_BUILD_TYPE_LIST,
    },
}

const DEFAULT_BUILD_TYPE_LIST = [
    LocationBuildConstants.BUILD_CODE_ENUM.BARRACKS,
    LocationBuildConstants.BUILD_CODE_ENUM.BARRACKS_SMALL,
    LocationBuildConstants.BUILD_CODE_ENUM.WAREHOUSE,
    LocationBuildConstants.BUILD_CODE_ENUM.WAREHOUSE_SMALL,
]


const DEFAULT_ROAO_RECRUIT_CONFIG = {
    "common": {
        "regular_soldier_0011": 5000,
    },

    "addition": {
        "regular_soldier_0012": 10,
        "regular_soldier_0013": 2,
        "regular_soldier_0016": 2,
        "regular_soldier_0015": 2,
        "wild_soldier_0015": 2,
    }
}


const DEFAULT_SAINA_RECRUIT_CONFIG = {
    "common": {
        "regular_soldier_0003": 5000,
    },


    "addition": {
        "regular_soldier_0004": 10,
        "regular_soldier_0008": 10,
        "regular_soldier_0005": 2,
        "regular_soldier_0006": 2,
        "regular_soldier_0007": 2,
        "wild_soldier_0013_02": 2,
    }
}


const DEFAULT_MARKA_RECRUIT_CONFIG = {
    "common": {
        "regular_soldier_0022": 5000,
    },


    "addition": {
        "regular_soldier_0023": 10,
        "regular_soldier_0024": 2,
        "regular_soldier_0025": 2,
        "regular_soldier_0026": 2,
    }
}


const DEFAULT_SHALUK_RECRUIT_CONFIG = {
    "common": {
        "regular_soldier_0030": 5000,
    },


    "addition": {
        "regular_soldier_0031": 10,
        "regular_soldier_0034": 2,
        "regular_soldier_0033": 2,
    }
}









func load_save_data(_save_data: Dictionary)-> void:
    city_data = _save_data.city_data


    if _save_data.has("building_list_dic"):
        building_list_dic = _save_data.building_list_dic
    else:
        building_list_dic = {}

    init_data()

func get_save_data()-> Dictionary:




    return {
        "city_data": city_data,
        "building_list_dic": building_list_dic,
    }

func clear_data():
    city_data = {}
    hero_location_cache = {}
    building_list_dic = {}




func init_data():

    var _temp_city_system_data: = CITY_SYSTEM_DATA.duplicate(true)
    _location_specialty_grocery_standardize(_temp_city_system_data, "specialty_grocery")


    for _key in CITY_SYSTEM_DATA.keys():
        if city_data.has(_key):

            city_data[_key] = CommonUtils.cover_json(_temp_city_system_data.get(_key).duplicate(true), city_data[_key])
        else:
            var _init_city_data_copy = {}
            if INIT_CITY_DATA.has(_key):
                _init_city_data_copy = INIT_CITY_DATA.get(_key).duplicate(true)


            city_data[_key] = CommonUtils.cover_json(_temp_city_system_data.get(_key).duplicate(true), _init_city_data_copy)

        city_data[_key].location_code = _key
        _handle_location_default_value(city_data[_key])


        _handle_specialty_grocery_positive(city_data[_key])


    _handle_equipment_specialty_data()



    _repair_save_data()


    _init_hero_location_info_cache()




    init_owner_uid()


func get_belong_country(_location_code: String)-> String:

    return get_belong_country_by_city_data(
        get_location_data(_location_code)
    )

func get_belong_country_by_city_data(_location_data: Dictionary)-> String:
    return CommonUtils.get_value(_location_data, "belong_country", WSCountryData.COUNTRY_NAME_ENUM.NONE)

func get_location_name(_location_code: String)-> String:
    var _default_name = "未知地点"
    if StringUtils.is_empty(_location_code):
        return _default_name

    if CITY_SYSTEM_DATA.get(_location_code).has("name"):
        return CITY_SYSTEM_DATA.get(_location_code).get("name")
    else:
        return _default_name


func save_city_goods(_city_name: String, _location_type_enum: String, _json: Array):


    city_data[_city_name][get_goods_field(_location_type_enum)] = _json


func save_city_recruit(_city_name, _recruit_json):
    city_data[_city_name].recruit = _recruit_json

func get_goods_json(_location_code: String, _location_type_enum: String):
    return city_data[_location_code][get_goods_field(_location_type_enum)]

func get_goods_field(_location_type_enum: String)-> String:
    return "goods_" + _location_type_enum.to_lower()

func get_city_data(_location_code: String)-> Dictionary:
    return city_data.get(_location_code)

func get_location_data(_location_code: String)-> Dictionary:
    return get_city_data(_location_code)

func plus_excess_goods(_location_code: String, _plus_excess_goods: int, _plus_consumption_goods: int):
    var _city_data: Dictionary = get_city_data(_location_code)
    _city_data.excess_goods += _plus_excess_goods
    _city_data.consumption_goods += _plus_consumption_goods

    LocationUtils.location_data_repair(_city_data)

func get_shop_money(_location_code: String, _location_type_enum: String)-> int:
    var _field = get_shop_money_field(_location_type_enum)
    return get_city_data(_location_code)[_field]

func get_shop_money_field(_location_type_enum: String)-> String:
    return "money_" + _location_type_enum.to_lower()

func save_shop_money(_location_code: String, _location_type_enum: String, _change_money: int)-> void:
    var _field = get_shop_money_field(_location_type_enum)
    get_city_data(_location_code)[_field] += _change_money



func plus_specialty_grocery(
    _city_name: String, _specialty_grocery_origin: Dictionary,
    _ratio: float, need_standardize: bool
)-> void:
    var _city_data_specialty_grocery: Dictionary = get_city_data(_city_name).specialty_grocery
    for _key: String in _specialty_grocery_origin.keys():

        var _plus_value = int(_specialty_grocery_origin.get(_key) * _ratio)
        if _city_data_specialty_grocery.has(_key):
            _city_data_specialty_grocery[_key] += _plus_value
        else:
            _city_data_specialty_grocery[_key] = _plus_value


    if need_standardize:
        _location_specialty_grocery_standardize3(_city_name, "specialty_grocery")


func recruit_add(_location_code: String, _soldier_uid_list: Array)-> void:
    var _append_array: = []
    for _soldier_uid in _soldier_uid_list:
        var _item_json = {"uid": _soldier_uid}
        SoldierUtils.repair_simple_json(_item_json)
        _append_array.append(_item_json)

    get_city_data(_location_code).recruit.append_array(_append_array)

func recruit_sort(_location_code: String):
    get_city_data(_location_code).recruit.sort_custom(SortUtils.recruit_sort)

func plus_population_working_age_by_nop(
    _location_code: String, _plus_nop: int,
    _discount: = 1.0
)-> void:
    var _value = int(_plus_nop * LocationConfig.POPULATION_WORKING_AGE_REAL_NOP_RATIO * _discount)
    get_city_data(_location_code).population_working_age += _value

func get_button_type_list(_location_code: String)-> Array:
    var _locaiton_data = get_city_data(_location_code)
    return CommonUtils.get_value(_locaiton_data, "button_type_list", _get_default_button_type_list(_locaiton_data.type))

func get_enter_build_name(_location_code: String, _location_type_enum: String)-> String:
    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("enter_build_config"):
        return ""

    return _location_data.enter_build_config.get(_location_type_enum)




















func add_location_static_npc_info(_location_info_code: String, _hero_uid: String)-> void:
    add_location_npc_info(
        _location_info_code,
        {
            "npc_uid": _hero_uid,
            "is_static_npc": true,
        }
    )

func add_location_not_static_npc_info(_location_info_code: String, _hero_uid: String)-> void:
    add_location_npc_info(
        _location_info_code,
        {
            "npc_uid": _hero_uid,

            "is_static_npc": false,
        }
    )







func add_location_npc_info(
    _location_info_code: String, _add_npc_info: Dictionary
)-> void:
    if not _add_npc_info.has("location_info_code"):
        _add_npc_info.location_info_code = _location_info_code

    var str_list: Array = _location_info_code.split(":")
    var _location_code: String = str_list[0]
    var _location_type: String = str_list[1]

    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("npc_info"):
        _location_data.npc_info = {}

    if not _location_data.npc_info.has(_location_type):
        _location_data.npc_info[_location_type] = []


    for _npc_info: Dictionary in _location_data.npc_info[_location_type]:
        if _npc_info.npc_uid == _add_npc_info.npc_uid:
            return

    _location_data.npc_info[_location_type].append(_add_npc_info)
    if SoldierUtils.is_hero_by_uid(_add_npc_info.npc_uid):
        _update_hero_location_cache(_add_npc_info.npc_uid, _location_info_code)


func remove_npc_info(_npc_info: Dictionary)-> void:
    if not _npc_info.has("location_info_code"):
        return

    remove_npc_info_by_uid(_npc_info.location_info_code, _npc_info.npc_uid)

func remove_npc_info_by_uid(_location_info_code: String, _npc_uid: String)-> void:
    if StringUtils.is_empty(_location_info_code):
        return

    var _location_info_code_list: = _location_info_code.split(":")
    var _location_code: = _location_info_code_list[0]
    var _location_type: = _location_info_code_list[1]
    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("npc_info"):
        return

    if not _location_data.npc_info.has(_location_type):
        return

    for _index in range(_location_data.npc_info.get(_location_type).size() - 1, -1, -1):
        if _location_data.npc_info.get(_location_type)[_index].npc_uid == _npc_uid:
            _location_data.npc_info.get(_location_type).remove_at(_index)
            break
    if SoldierUtils.is_hero_by_uid(_npc_uid):
        _update_hero_location_cache(_npc_uid, "")



func remove_npc_from_all_locations(_npc_uid: String)-> void:
    for _location_data: Dictionary in city_data.values():
        if _location_data.type != LocationConstants.LOCATION_TYPE_ENUM.CITY:
            continue
        if not _location_data.has("npc_info"):
            continue
        for _location_type: String in _location_data.npc_info.keys():
            for _index in range(_location_data.npc_info.get(_location_type).size() - 1, -1, -1):
                if _location_data.npc_info.get(_location_type)[_index].npc_uid == _npc_uid:
                    _location_data.npc_info.get(_location_type).remove_at(_index)
    if SoldierUtils.is_hero_by_uid(_npc_uid):
        _update_hero_location_cache(_npc_uid, "")



































func remove_hero_location(_hero_uid: String)-> void:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    if not _hero_json.has("current_location"):
        return

    remove_npc_info_by_uid(_hero_json.current_location.location, _hero_uid)



func list_build_code(_location_code: String)-> Array:








    var _location_info: Dictionary = get_city_data(_location_code)
    return CommonUtils.get_value(_location_info, "build_type_list",[])


func new_build(
    _location_code: String, _slot_code: String,
    _build_code: String, manager_hero_uid: String,
)-> void:
    var _location_data = get_city_data(_location_code)
    if not _location_data.has("build_info"):
        _location_data.build_info = {}

    var _processed_build_info = LocationBuildUtils.get_processed_build_info(_build_code, manager_hero_uid)
    var _end_time = WSData.get_system_counter() + _processed_build_info.build_spend_days

    _location_data.build_info[_slot_code] = {
        "build_code": _build_code,

        "manager_hero_uid": manager_hero_uid,
        "days": _processed_build_info.build_spend_days,
        "start_time": WSData.get_system_counter(),
        "end_time": _end_time,
        "build_level": _processed_build_info.build_level,
        "build_status": LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING,
    }

    _new_building_record(_location_code, _slot_code)


    SoldierUtils.hero_busy(
        manager_hero_uid, _end_time,

        _location_code
    )

func delete_build(_location_code: String, _slot_code: String)-> void:
    var _build_info: = get_build_info(_location_code, _slot_code)
    if _build_info.is_empty():
        return


    if StringUtils.is_not_empty(_build_info.manager_hero_uid):
        SoldierUtils.cancel_busy_task(_build_info.manager_hero_uid)


    _delete_build_info(_location_code, _slot_code)


    GlobalLocationData.refresh_location_tag(_location_code)


func build_upgrade(
    _location_code: String, _slot_code: String,
    _upgrade_level: int, _manager_hero_uid: String,
    _upgrade_days: int
)-> void:
    var _build_info: Dictionary = get_build_info(_location_code, _slot_code)
    if _build_info.is_empty():
        return

    _build_info.manager_hero_uid = _manager_hero_uid
    _build_info.days = _upgrade_days
    _build_info.start_time = WSData.get_system_counter()
    _build_info.end_time = WSData.get_system_counter() + _upgrade_days
    _build_info.build_status = LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE
    _build_info.upgrade_build_level = _upgrade_level

    _new_building_record(_location_code, _slot_code)


    SoldierUtils.hero_busy(
        _manager_hero_uid, _build_info.end_time, _location_code
    )


func build_cancel_upgrade(_location_code: String, _slot_code: String)-> void:
    var _build_info: Dictionary = get_build_info(_location_code, _slot_code)
    if _build_info.is_empty():
        return

    _build_info.build_status = LocationBuildConstants.BUILD_STATUS_ENUM.FINISH


    if StringUtils.is_not_empty(_build_info.manager_hero_uid):
        SoldierUtils.cancel_busy_task(_build_info.manager_hero_uid)


    GlobalLocationData.refresh_location_tag(_location_code)

func get_build_info(_location_code: String, _slot_code: String)-> Dictionary:
    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("build_info"):
        return {}

    if not _location_data.build_info.has(_slot_code):
        return {}

    return _location_data.build_info.get(_slot_code)


func refresh_all_build_status()-> void:
    var _remove_key_list = []
    var _now_system_counter: float = WSData.get_system_counter()
    for _build_list_key: String in building_list_dic:
        var _value_dic: Dictionary = building_list_dic.get(_build_list_key)
        var _build_info: Dictionary = get_build_info(_value_dic.location_code, _value_dic.slot_code)
        if _build_info.is_empty():
            _remove_key_list.append(_build_list_key)
            continue

        if _now_system_counter >= _build_info.end_time:

            _build_info.manager_hero_uid = ""
            _remove_key_list.append(_build_list_key)

            var _location_name: = get_location_name(_value_dic.location_code)
            var _build_name: = LocationBuildConstants.get_build_name(_build_info.build_code)

            match _build_info.build_status:
                LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING:
                    _build_info.build_status = LocationBuildConstants.BUILD_STATUS_ENUM.FINISH

                    GlobalMessageInterface.add_message(
                        MessageConstants.MESSAGE_ENUM.BUILD_FINISH,
                        [_location_name, _build_name]
                    )
                LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE:
                    _build_info.build_status = LocationBuildConstants.BUILD_STATUS_ENUM.FINISH
                    _build_info.build_level = _build_info.upgrade_build_level

                    GlobalMessageInterface.add_message(
                        MessageConstants.MESSAGE_ENUM.BUILD_UPGRADE_FINISH,
                        [_location_name, _build_name]
                    )

        GlobalLocationData.refresh_location_tag(_value_dic.location_code)

    for _remove_key: String in _remove_key_list:
        _remove_building_record2(_remove_key)


func get_finish_build_info_list(_location_code: String)-> Array:
    var _result: = []
    var _location_data: Dictionary = get_city_data(_location_code)

    var _build_info_list: Array = get_build_info_list_sort_by_solt(_location_code)

    for _slot_build_info: Dictionary in _build_info_list:
        match _slot_build_info.build_status:
            LocationBuildConstants.BUILD_STATUS_ENUM.FINISH:
                _result.append({
                    "build_code": _slot_build_info.build_code,
                    "build_level": _slot_build_info.build_level,
                })
            LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE:
                _result.append({
                    "build_code": _slot_build_info.build_code,
                    "build_level": _slot_build_info.build_level,
                })

    return _result

func get_build_info_list_sort_by_solt(_location_code: String)-> Array:
    var _result = []

    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("build_slot") or not _location_data.has("build_info"):
        return _result

    for _build_slot: Dictionary in _location_data.build_slot:
        if _location_data.build_info.has(_build_slot.code):
            _result.append(_location_data.build_info.get(_build_slot.code))

    return _result


func get_barracks_team_info(_location_code: String)-> Array:
    var _location_data: Dictionary = get_city_data(_location_code)
    return CommonUtils.get_value(_location_data, "barracks_team_info",[])


func check_barracks_has_data(_location_code: String)-> bool:
    return get_barracks_team_info(_location_code).size() > 0


func check_warehouse_has_data(_location_code: String)-> bool:
    return get_location_warehouse_json(_location_code).size() > 0

func save_barracks_team_info(_location_code: String, _simple_json_list: Array)-> void:
    var _location_data: Dictionary = get_city_data(_location_code)
    _location_data.barracks_team_info = _simple_json_list



func get_prison_capture_info(_location_code: String)-> Array:
    var _location_data: Dictionary = get_city_data(_location_code)
    return CommonUtils.get_value(_location_data, "prison_capture_info",[])


func save_prison_capture_info(_location_code: String, _simple_json_list: Array)-> void:
    var _location_data: Dictionary = get_city_data(_location_code)
    _location_data.prison_capture_info = _simple_json_list



func get_prison_max_nop(_location_code: String)-> int:
    var _max_nop: int = 0
    var _finish_build_info_list: Array = get_finish_build_info_list(_location_code)
    for _build_info: Dictionary in _finish_build_info_list:
        match _build_info.build_code:
            LocationBuildConstants.BUILD_CODE_ENUM.PRISON, \
            LocationBuildConstants.BUILD_CODE_ENUM.PRISON_SMALL:
                _max_nop += LocationBuildUtils.get_build_config_value(_build_info.build_code, _build_info.build_level)
    return _max_nop




func mod_get_player_prison_location_list()-> Array:
    var _result: Array = []
    var _fief_list: Array = SoldierUtils.get_player_fief_code_list()
    for _loc_code in _fief_list:
        var _max_nop: int = get_prison_max_nop(_loc_code)
        if _max_nop <= 0:
            continue
        var _loc_data: Dictionary = get_city_data(_loc_code)
        var _loc_type: String = _loc_data.get("type", "")
        var _cur_count: int = get_prison_capture_info(_loc_code).size()
        var _available: int = _max_nop - _cur_count
        if _available <= 0:
            continue
        var _is_village: bool = _loc_type == LocationConstants.LOCATION_TYPE_ENUM.VILLAGE
        _result.append({
            "location_code": _loc_code,
            "max_nop": _max_nop,
            "available": _available,
            "is_village": _is_village,
        })

    _result.sort_custom(func(a, b): return int(a.is_village) > int(b.is_village))
    return _result


func get_player_manage_location_code_list()-> Array:
    var _result = []
    for _location_code: String in city_data.keys():
        var _location_data: Dictionary = city_data.get(_location_code)
        if _location_data.type == LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:
            _result.append(_location_code)

    return _result


func handle_barracks_overflow_daily()-> void:
    var _duration_time: = 1.0
    var _player_manage_location_code_list: Array = get_player_manage_location_code_list()
    for _location_code: String in _player_manage_location_code_list:
        if not LocationBuildUtils.check_has_build_barracks(_location_code):
            continue

        var _nop = LocationBuildUtils.get_barracks_nop(_location_code)
        var _max_nop = LocationBuildUtils.get_barracks_max_nop(_location_code)

        if _nop <= _max_nop:
            continue




        var _overflow_nop = _nop - _max_nop

        var _departure_prob: float = _duration_time * LocationConfig.BARRACKS_OVERCROWD_SOLDIER_DEPARTURE_PROB * _overflow_nop
        if CommonUtils.prob_true(_departure_prob):
            var _departure_nop_max = int(_overflow_nop * LocationConfig.BARRACKS_OVERCROWD_SOLDIER_DEPARTURE_MAX_NOP_RATIO)
            if _departure_nop_max < 1:
                _departure_nop_max = 1

            var _departure_nop = CommonUtils.random_num2(1, _departure_nop_max)
            _remove_barracks_soldier(_location_code, _departure_nop)
            GlobalLocationData.refresh_location_tag(_location_code)


func get_location_type(_location_code: String)-> String:
    return get_city_data(_location_code).type


func get_location_warehouse_json(_location_code: String)-> Array:
    return CommonUtils.get_value(get_city_data(_location_code), "warehouse",[])


func get_warehouse_goods_count_limit(_location_code: String)-> int:
    var _count_limit: int = 0

    var _finish_build_info_list = get_finish_build_info_list(_location_code)

    for _build_info: Dictionary in _finish_build_info_list:
        match _build_info.build_code:
            LocationBuildConstants.BUILD_CODE_ENUM.WAREHOUSE, \
            LocationBuildConstants.BUILD_CODE_ENUM.WAREHOUSE_SMALL:
                _count_limit += LocationBuildUtils.get_build_config_value(_build_info.build_code, _build_info.build_level)

    return _count_limit


func save_warehouse_data(_location_code, _data: Array)-> void:
    get_city_data(_location_code).warehouse = _data














func get_npc_info_list(_location_code: String, _location_type_enum: String)-> Array:
    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("npc_info"):
        return[]

    if not _location_data.npc_info.has(_location_type_enum):
        return[]

    var _npc_list: Array = _location_data.npc_info.get(_location_type_enum)
    var _result: = []
    var _player_team: Array = WSData.get_player_team_simple_json_list()
    for _npc_info: Dictionary in _npc_list:
        var _npc_uid: String = _npc_info.npc_uid
        if _npc_uid == "wild_hero_0001" or _npc_uid == "wild_hero_0002":
            var _already_has: bool = false
            for _team_member: Dictionary in _player_team:
                if _team_member.uid == _npc_uid:
                    _already_has = true
                    break

            if not _already_has:
                var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_npc_uid)
                if _hero_json.get("is_appointed_leader", false):
                    _already_has = true
            if _already_has:
                continue
        _result.append(_npc_info)
    return _result

func get_city_code_list()-> Array:
    var _city_code_list: = []
    for _location_data: Dictionary in city_data.values():
        if _location_data.type == LocationConstants.LOCATION_TYPE_ENUM.CITY:
            _city_code_list.append(_location_data.location_code)

    return _city_code_list

func refresh_dynamic_hero_location()-> void:
    for _hero_uid: String in GlobalSoldierInfo.get_refresh_location_hero_uid_list():
        var _hero_data: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)
        if not _hero_data.has("wandering_info") or not _hero_data.has("wandering_config"):
            continue
        if WSData.get_system_counter() > _hero_data.wandering_info.leave_time:
            place_hero_randomly(_hero_data)



func place_hero_randomly(_hero_data: Dictionary)-> void:
    var _city_code_list: Array = get_city_code_list()
    var _pre_location: String = _hero_data.wandering_info.current_location


    remove_npc_info_by_uid(_pre_location, _hero_data.uid)

    var _current_location: String = _pre_location
    while(_pre_location == _current_location):
        _current_location = _city_code_list.pick_random() + ":" + _hero_data.wandering_config.location_type.pick_random()

    add_location_not_static_npc_info(_current_location, _hero_data.uid)
    _hero_data.wandering_info.refresh_time = WSData.get_system_counter()
    _hero_data.wandering_info.current_location = _current_location

    var _days: int = CommonUtils.random_num2(
        _hero_data.wandering_config.duration_days_range[0],
        _hero_data.wandering_config.duration_days_range[1]
    )
    _hero_data.wandering_info.leave_time \
    = WSData.get_system_counter() + _days
    _hero_data.wandering_info.has_been_inquired_location = false

func init_owner_uid()-> void:
    for _location_data: Dictionary in city_data.values():
        _location_data.owner_uid = ""


    for _hero_data: Dictionary in GlobalSoldierInfo.hero_dic.values():
        if _hero_data.uid == SoldierUtils.get_player_hero_uid():
            continue

        if not _hero_data.has("fief_info"):
            continue

        if ArrayUtils.is_empty(_hero_data.fief_info):
            continue

        for _fief_code: String in _hero_data.fief_info:
            var _location_data: Dictionary = get_location_data(_fief_code)
            _location_data.owner_uid = _hero_data.uid


    var _player_field_info: Array = CommonUtils.get_value(SoldierUtils.get_player_hero_json(), "fief_info",[])
    for _player_field_code: String in _player_field_info:
        var _location_data: Dictionary = get_location_data(_player_field_code)
        if StringUtils.is_not_empty(_location_data.owner_uid):
            var _hero_data: Dictionary = SoldierUtils.get_hero_json(_location_data.owner_uid)
            _hero_data.fief_info.erase(_player_field_code)

        _location_data.owner_uid = SoldierUtils.get_player_hero_uid()

func _repair_save_data()-> void:
    for _location_data: Dictionary in city_data.values():
        if _location_data.has("charactar_location"):

            for _location_type: String in _location_data.charactar_location.keys():
                var _location_info_code: String = _location_data.location_code + ":" + _location_type
                for _npc_uid: String in _location_data.charactar_location[_location_type]:
                    add_location_static_npc_info(_location_info_code, _npc_uid)

            _location_data.erase("charactar_location")


        if not _location_data.has("player_relation_value"):
            _location_data.player_relation_value = 0

    _sync_building_records()

func _sync_building_records()-> void:
    for _location_data: Dictionary in city_data.values():
        if not _location_data.has("build_info"):
            continue

        for _slot_code: String in _location_data.build_info.keys():
            var _build_status = _location_data.build_info[_slot_code].get("build_status")
            if[
                    LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING,
                    LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE,
                ].has(_build_status):
                _new_building_record(_location_data.location_code, _slot_code)

    var _stale_key_list: = []
    for _record_key: String in building_list_dic:
        var _record: Dictionary = building_list_dic[_record_key]
        var _info: Dictionary = get_build_info(_record.get("location_code", ""), _record.get("slot_code", ""))
        if _info.is_empty() or not[
                LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING,
                LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE,
            ].has(_info.get("build_status")):
            _stale_key_list.append(_record_key)

    for _stale_key: String in _stale_key_list:
        _remove_building_record2(_stale_key)


















func _handle_specialty_grocery_positive(_city_data: Dictionary)-> void:
    var _specialty_grocery_positive_dic = {}
    for _code: String in _city_data.specialty_grocery.keys():
        var _value: int = _city_data.specialty_grocery.get(_code)
        if _value > 0:
            _specialty_grocery_positive_dic[_code] = _value

    _city_data.specialty_grocery_positive = _specialty_grocery_positive_dic

func _handle_location_default_value(_city_json: Dictionary):
    CommonUtils.set_default_value(_city_json, "prosperity_level", 400)
    CommonUtils.set_default_value(_city_json, "population_total", 400)
    CommonUtils.set_default_value(_city_json, "population_working_age", 400)
    CommonUtils.set_default_value(_city_json, "consumption_goods", 400)
    CommonUtils.set_default_value(_city_json, "excess_goods", 300)
    CommonUtils.set_default_value(_city_json, "happiness_level", 500)
    CommonUtils.set_default_value(_city_json, "location_size_max", 700)

    CommonUtils.set_default_value(_city_json, "development_level", 500)
    CommonUtils.set_default_value(_city_json, "hygiene_level", 500)
    CommonUtils.set_default_value(_city_json, "tax_ratio", 0.2)
    CommonUtils.set_default_value(_city_json, "specialty_grocery",{})

    CommonUtils.set_default_value(_city_json, "goods_refresh_time", -100.0)

    CommonUtils.set_default_value(_city_json, "recruit_refresh_time", -100.0)
    CommonUtils.set_default_value(_city_json, "recruit",[])
    CommonUtils.set_default_value(_city_json, "goods_grocery",[])
    CommonUtils.set_default_value(_city_json, "goods_smithy",[])
    CommonUtils.set_default_value(_city_json, "goods_armour",[])
    CommonUtils.set_default_value(_city_json, "goods_horse",[])
    CommonUtils.set_default_value(_city_json, "money_grocery", 0)
    CommonUtils.set_default_value(_city_json, "money_smithy", 0)
    CommonUtils.set_default_value(_city_json, "money_armour", 0)
    CommonUtils.set_default_value(_city_json, "money_horse", 0)

func _handle_equipment_specialty_data()-> void:


    var _blacksmith_shop_uid_list = []

    var _armour_shop_uid_list = []

    var _horse_market_uid_list = []
    for _part_gd_stript in SoldierPartUtils.get_all_part_gd():
        match _part_gd_stript.get_shop_type_enum():
            ShopConstants.SHOP_TYPE_ENUM.BLACKSMITH_SHOP:
                _blacksmith_shop_uid_list.append_array(_part_gd_stript.get_uid_list())
            ShopConstants.SHOP_TYPE_ENUM.ARMOUR_SHOP:
                _armour_shop_uid_list.append_array(_part_gd_stript.get_uid_list())
            ShopConstants.SHOP_TYPE_ENUM.HORSE_MARKET:
                _horse_market_uid_list.append_array(_part_gd_stript.get_uid_list())

    _process_and_save_equipment_specialty_data(_blacksmith_shop_uid_list, "specialty_smithy")
    _process_and_save_equipment_specialty_data(_armour_shop_uid_list, "specialty_armour")
    _process_and_save_equipment_specialty_data(_horse_market_uid_list, "specialty_horse")

func _process_and_save_equipment_specialty_data(_uid_list: Array, _location_field: String)-> void:

    var _ethnicity_specialty_data = {}

    for _uid: String in _uid_list:
        var equipment_json = GoodsUtils.get_origin_json_by_uid(_uid)
        if not equipment_json.has("location_refresh_config"):
            continue

        var _ethnicity_list = []
        if equipment_json.location_refresh_config.has("ethnicity"):
            if equipment_json.location_refresh_config.ethnicity == WSCountryData.ETHNICITY_ENUM.ALL:
                _ethnicity_list = WSCountryData.ETHNICITY_ENUM.values().duplicate(true)
                _ethnicity_list.erase(WSCountryData.ETHNICITY_ENUM.ALL)
            else:
                _ethnicity_list.append(equipment_json.location_refresh_config.ethnicity)
        elif equipment_json.location_refresh_config.has("ethnicity_exclude"):
            _ethnicity_list = WSCountryData.ETHNICITY_ENUM.values().duplicate(true)
            _ethnicity_list.erase(WSCountryData.ETHNICITY_ENUM.ALL)
            for _item in equipment_json.location_refresh_config.ethnicity_exclude:
                _ethnicity_list.erase(_item)

        for _ethnicity in _ethnicity_list:
            var _specialty_value: int = _get_specialty_value(equipment_json)

            if not _ethnicity_specialty_data.has(_ethnicity):
                _ethnicity_specialty_data[_ethnicity] = {}

            if not _ethnicity_specialty_data[_ethnicity].has(_uid):
                _ethnicity_specialty_data[_ethnicity][_uid] = 0

            _ethnicity_specialty_data[_ethnicity][_uid] += _specialty_value

    for _location_data: Dictionary in city_data.values():
        if _location_data.type != LocationConstants.LOCATION_TYPE_ENUM.CITY:
            continue

        if _ethnicity_specialty_data.has(_location_data.ethnicity):
            _location_data[_location_field] = _ethnicity_specialty_data.get(_location_data.ethnicity)





func _get_specialty_value(_equipment_json: Dictionary)-> int:
    var _star_3_value: = 1000
    if not _equipment_json.has("star"):
        return _star_3_value

    match _equipment_json.star:
        1:
            return 2000
        2:
            return 2000
        3:
            return _star_3_value
        4:
            return 50
        5:
            return 5

    return 0

func _remove_barracks_soldier(_location_code: String, _nop: int)-> void:
    var _location_data: Dictionary = get_city_data(_location_code)
    if _location_data.barracks_team_info.size() <= _nop:
        _location_data.barracks_team_info = []

    for _index in range(_nop):
        _location_data.barracks_team_info.erase(_location_data.barracks_team_info.pick_random())

func _delete_build_info(_location_code: String, _slot_code: String)-> void:
    var _location_data: Dictionary = get_city_data(_location_code)
    if not _location_data.has("build_info"):
        return

    if not _location_data.build_info.has(_slot_code):
        return

    _location_data.build_info.erase(_slot_code)
    _remove_building_record(_location_code, _slot_code)





func _location_specialty_grocery_standardize(_location_data_dic: Dictionary, _field: String)-> void:
    for _location_data: Dictionary in _location_data_dic.values():
        _location_specialty_grocery_standardize2(_location_data, _field)

func _location_specialty_grocery_standardize2(_location_data: Dictionary, _field: String)-> void:

    if not _location_data.has(_field):
        return

    var _total: = 0
    for _value in _location_data[_field].values():
        if _value > 0:
            _total += _value


    var _benchmark_total: = _get_location_benchmark_total(_location_data.type)
    if _total <= 0 or abs(_total - _benchmark_total) <= _benchmark_total / 100:
        return

    var _ratio = _benchmark_total * 1.0 / _total
    for _key in _location_data[_field].keys():
        if _location_data[_field].get(_key) > 0:
            _location_data[_field][_key] = int(_location_data[_field].get(_key) * _ratio)

        if _location_data[_field][_key] == 0:
            _location_data[_field].erase(_key)

func _get_location_benchmark_total(_location_type: String)-> int:

    match _location_type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            return 1000
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            return 600
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            return 300

    return 500

func _location_specialty_grocery_standardize3(_location_code: String, _field: String)-> void:
    var _location_data = get_city_data(_location_code)
    _location_specialty_grocery_standardize2(_location_data, _field)


func _new_building_record(_location_code: String, _slot_code: String)-> void:
    var _key: = _location_code + ";" + _slot_code
    building_list_dic[_key] = {
        "location_code": _location_code,
        "slot_code": _slot_code,
    }


func _remove_building_record(_location_code: String, _slot_code: String)-> void:
    var _key: = _location_code + ";" + _slot_code
    _remove_building_record2(_key)

func _remove_building_record2(_key: String)-> void:
    building_list_dic.erase(_key)

func _get_default_button_type_list(_type)-> Array:
    match _type:
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            return DEFAULT_BUTTON_TYPE_LIST_VILLAGE
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            return DEFAULT_BUTTON_TYPE_LIST_CASTLE
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            return DEFAULT_BUTTON_TYPE_LIST_CITY

    return[]


func _init_hero_location_info_cache()-> void:
    for _location_data: Dictionary in city_data.values():
        if not _location_data.has("npc_info"):
            continue

        for _location_type: String in _location_data.npc_info.keys():
            var _location_code_type_code: String = _location_data.location_code + ":" + _location_type
            for _npc_info: Dictionary in _location_data.npc_info.get(_location_type):
                if SoldierUtils.is_hero_by_uid(_npc_info.npc_uid):
                    _update_hero_location_cache(_npc_info.npc_uid, _location_code_type_code)

func _update_hero_location_cache(_hero_uid: String, _location_code_type_code: String)-> void:
    hero_location_cache[_hero_uid] = _location_code_type_code


func get_location_code_type_code(_hero_uid: String)-> String:
    if not hero_location_cache.has(_hero_uid):
        return ""

    return hero_location_cache.get(_hero_uid)