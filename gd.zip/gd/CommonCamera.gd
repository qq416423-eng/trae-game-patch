class_name CommonCamera extends Camera2D


@export var camera_zoom_update_speed: = 7.0
@export var camera_move_speed: = 12.0
@export var min_zoom: = 0.45
@export var max_zoom: = 1.5

@export var open_mobile_click_event: = false

var origin_camera_zoom_update_speed: = 0
var origin_camera_move_speed: = 0

var target_zoom_x = 0
var disable = false

var trace_node = null

var is_trace: = false

var slow_move: = false
var drag_enabled: = true
var origin_position_smoothing_speed: = 0

signal change_zoom_sign(_zoom)
signal mobile_click_sign(_position: Vector2)

func _ready():
    target_zoom_x = self.zoom.x
    origin_position_smoothing_speed = self.position_smoothing_speed
    if CommonUtils.platform_is_mobile():
        max_zoom += 0.4
    else:
        set_process_input(false)

    origin_camera_zoom_update_speed = camera_zoom_update_speed
    origin_camera_move_speed = camera_move_speed
    GlobalTimeControl.connect("time_scale_update_sign", _time_scale_update)

func _time_scale_update(_time_scale: float)-> void:
    camera_zoom_update_speed = origin_camera_zoom_update_speed / _time_scale

    self.position_smoothing_speed = origin_position_smoothing_speed / _time_scale

func _physics_process(delta):

    if slow_move:
        position.x += 0.4




    if abs(self.zoom.x - target_zoom_x) > 0.01:
        self.zoom = lerp(self.zoom, Vector2(target_zoom_x, target_zoom_x), camera_zoom_update_speed * delta)


        emit_signal("change_zoom_sign", self.zoom)

    if disable:
        return


    if is_trace:
        if trace_node == null:
            is_trace = false
        else:
            self.position = trace_node.global_position


    if GameConfig.PLATFORM == CommonConstants.PLATFORM_ENUM.PC:
        _handle_pc_control(delta)
    else:
        if mobile_touch_start:
            mobile_touch_duration_counter += 1


func _input(_event: InputEvent)-> void:
    if CommonUtils.platform_is_mobile():
        _handle_mobile_control(_event)



var mobile_touch_start: = false

var mobile_touch_duration_counter: = 0
var mobile_initial_positions: = []




var mobile_two_finger_distance: float = 0.0


func mobile_drag_event(_relative)-> void:
    self.move(_relative /((1 if GlobalPlayerConfig.is_view_move_reversal else -1) * self.zoom.x))

func get_global_position_by_position(_position: Vector2)-> Vector2:






    return self.position -((get_viewport_rect().size / 2 - _position) / self.zoom.x)

func _handle_mobile_control(_event: InputEvent):
    if _event is InputEventScreenTouch:
        if _event.pressed:
            if open_mobile_click_event:
                mobile_touch_start = true
                mobile_touch_duration_counter = 0

            if mobile_initial_positions.size() < 2:
                mobile_initial_positions.append(_event.position)

            if mobile_initial_positions.size() == 2:

                mobile_two_finger_distance = mobile_initial_positions[0].distance_to(mobile_initial_positions[1])
        else:
            if open_mobile_click_event:
                if mobile_initial_positions.size() == 1:

                    if mobile_touch_start and mobile_touch_duration_counter < MobileConfig.CLICK_TOUCH_DURATION_COUNTER \
                    and(_event.position - mobile_initial_positions[0]).length_squared() < MobileConfig.CLICK_DISTANCE_MAX_SQUARE:

                        mobile_click_sign.emit(get_global_mouse_position())
                        mobile_touch_start = false

            if mobile_initial_positions.size() > 0:
                mobile_initial_positions.clear()
    elif _event is InputEventScreenDrag and drag_enabled:
        if mobile_initial_positions.size() == 1:

            mobile_drag_event(_event.relative)
        elif mobile_initial_positions.size() == 2:

            if _event.index == 0:
                mobile_initial_positions[0] = _event.position
            elif _event.index == 1:
                mobile_initial_positions[1] = _event.position

            var _new_mobile_two_finger_distance = mobile_initial_positions[0].distance_to(mobile_initial_positions[1])
            var _distance_change = _new_mobile_two_finger_distance - mobile_two_finger_distance
            mobile_two_finger_distance = _new_mobile_two_finger_distance
            self.update_zoom(_distance_change / MobileConfig.DISTANCE_TO_ZOOM_CHANGE_RATIO)















func _handle_pc_control(delta):

    var _udlr_vector = MouseUtils.check_press_udlr()
    if _udlr_vector == Vector2.ZERO:
        pass
    else:
        is_trace = false

        self.move(_udlr_vector * camera_move_speed / self.zoom.x)



    var _mouse_scroll_value = MouseUtils.check_mouse_scroll()
    if _mouse_scroll_value == 0:
        pass
    else:

        self.update_zoom(- _mouse_scroll_value * camera_zoom_update_speed * - delta)


func set_position_x_plus(_x_dif: int)-> void:

    var _tween = get_tree().create_tween()
    _tween.tween_property(self, "position:x", position.x + _x_dif, 0.35)



func set_limit_custom(_vector: Vector2):
    limit_left = 0
    limit_top = 0
    limit_right = _vector.x
    limit_bottom = _vector.y

func set_limit_custom2(_limit_info: Dictionary):
    limit_left = _limit_info.left
    limit_top = _limit_info.top
    limit_right = _limit_info.right
    limit_bottom = _limit_info.bottom


func trace(_node):
    trace_node = _node
    is_trace = true

func func_close():

    disable = true
    if CommonUtils.platform_is_mobile():
        set_process_input(false)

func func_open():

    disable = false
    if CommonUtils.platform_is_mobile():
        set_process_input(true)


func move(_move_vector: Vector2):















    global_position += _move_vector

    var _viewport_to_zoom_scale: = get_viewport_to_zoom_scale()
    var _left_limit = limit_left + _viewport_to_zoom_scale.x / 2
    var _right_limit = limit_right - _viewport_to_zoom_scale.x / 2
    var _top_limit = limit_top + _viewport_to_zoom_scale.y / 2
    var _bottom_limit = limit_bottom - _viewport_to_zoom_scale.y / 2

    global_position.x = clamp(global_position.x, _left_limit, _right_limit)
    global_position.y = clamp(global_position.y, _top_limit, _bottom_limit)



static var VIEWPORT_WIDTH: float = ProjectSettings.get_setting("display/window/size/viewport_width", 0)
static var VIEWPORT_HEIGHT: float = ProjectSettings.get_setting("display/window/size/viewport_height", 0)
static var STANDARD_RATIO: float = VIEWPORT_WIDTH / VIEWPORT_HEIGHT

func get_viewport_to_zoom_scale()-> Vector2:
    var _real_width = VIEWPORT_WIDTH
    var _real_height = VIEWPORT_HEIGHT
    var _real_ratio: float = get_window().size.x * 1.0 / get_window().size.y
    if _real_ratio > STANDARD_RATIO:
        _real_width = _real_height * _real_ratio
    else:
        _real_height = _real_width / _real_ratio

    return Vector2(
        _real_width / zoom.x,
        _real_height / zoom.y
    )


func move_immediately(_move_vector):
    self.position = _move_vector
    self.reset_smoothing()

func update_zoom(_zoom_change: float):
    target_zoom_x += _zoom_change
    if target_zoom_x < min_zoom:
        target_zoom_x = min_zoom
    elif target_zoom_x > max_zoom:
        target_zoom_x = max_zoom

func update_zoom_immediately(_zoom: Vector2)-> void:
    zoom = _zoom
    target_zoom_x = _zoom.x

func update_drag_enabled(_enabled: bool):
    drag_enabled = _enabled