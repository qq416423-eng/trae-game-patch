class_name BubbleTip extends Control

@onready var right_content_node: Label =$RightContent
@onready var left_content_node: Label =$LeftContent
@onready var top_content_node: Label =$TopContent
@onready var down_content_node: Label =$DownContent

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

@export var pre_direction: = CommonConstants.DIRECTION_ENUM.RIGHT

func _ready()-> void:

    pass

func cshow(_content: String, _direction: CommonConstants.DIRECTION_ENUM = CommonConstants.DIRECTION_ENUM.RIGHT)-> void:
    if _direction == CommonConstants.DIRECTION_ENUM.RIGHT:
        right_content_node.show()
        CommonUtils.set_text(right_content_node, _content)
    else:
        left_content_node.show()
        CommonUtils.set_text(left_content_node, _content)

    animation_player_node.play("show")


func cshow02()-> void:
    self.show()
    self.modulate.a = 1.0

func chide()-> void:
    self.hide()
    self.modulate.a = 0.0

func update_text(_content)-> void:
    match pre_direction:
        CommonConstants.DIRECTION_ENUM.LEFT:
            CommonUtils.update_text(left_content_node, _content)
        CommonConstants.DIRECTION_ENUM.RIGHT:
            CommonUtils.update_text(right_content_node, _content)
        CommonConstants.DIRECTION_ENUM.TOP:
            CommonUtils.update_text(top_content_node, _content)
        CommonConstants.DIRECTION_ENUM.DOWN:
            CommonUtils.update_text(down_content_node, _content)

func ani_show_finish()-> void:
    self.queue_free()

func update_direction(_direction: CommonConstants.DIRECTION_ENUM)-> void:
    left_content_node.hide()
    right_content_node.hide()
    top_content_node.hide()
    down_content_node.hide()

    pre_direction = _direction
    match pre_direction:
        CommonConstants.DIRECTION_ENUM.LEFT:
            left_content_node.show()
        CommonConstants.DIRECTION_ENUM.RIGHT:
            right_content_node.show()
        CommonConstants.DIRECTION_ENUM.TOP:
            top_content_node.show()
        CommonConstants.DIRECTION_ENUM.DOWN:
            down_content_node.show()