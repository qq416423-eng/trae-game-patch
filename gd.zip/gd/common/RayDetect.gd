extends Node2D

@export var ray_count: = 2
@export var ray_max_length: = 15
@export var collision_mask: = 1







var danger_list = []
var ray_vector_list = []
var real_ray_count = 0

var debug = true

var launch = false




var counter = randi() % 1000
var direction = Vector2.ZERO

func _physics_process(_delta):
    counter += 1


    if launch and CommonUtils.counter_is_true(counter, 10):


        call_deferred("_refresh_direction")


func create_ray_list(_ray_max_length = null):
    if _ray_max_length != null:
        ray_max_length = _ray_max_length


    _delete_all_ray()

    var _ray_vector_list = []
    var _half_count = ray_count / 2
    var _pre_angle = PI /(_half_count + 1)



    var _center_point = Vector2(ray_max_length / 3.0, 0)


    var _radius_vector = Vector2(ray_max_length / 1.2, 0)
    var _real_ray_count = _half_count * 2 + 1


    danger_list.resize(_real_ray_count)


    _ray_vector_list.append(Vector2(ray_max_length, 0))

    for _index2 in range(_half_count):
        var _angle =(_index2 + 1) * _pre_angle

        _ray_vector_list.append(_center_point + _radius_vector.rotated(_angle))

        _ray_vector_list.append(_center_point + _radius_vector.rotated(- _angle))





    ray_vector_list = _ray_vector_list
    real_ray_count = _real_ray_count


    for _item_vector in _ray_vector_list:
        var ray_instance = RayCast2D.new()
        add_child(ray_instance)
        ray_instance.collision_mask = collision_mask
        ray_instance.target_position = _item_vector
        ray_instance.enabled = true

func create_ray_list_by_param(_ray_count, _ray_max_length):
    ray_count = _ray_count
    ray_max_length = _ray_max_length

    create_ray_list()





func set_danger_list():
    for _index in range(real_ray_count):
        danger_list[_index] = 0


    for _child_index in get_child_count():
        var _ray_node: RayCast2D = get_child(_child_index)
        if _ray_node.is_colliding():
            danger_list[_child_index] = 1

func get_direction(_angle):
    return direction.rotated(_angle)

func get_direction2():
    return direction.rotated(self.rotation)

func get_origin_direction():
    var _direction = Vector2.ZERO

    if not launch:
        _direction = Vector2(1, 0)
        return _direction

    for _index in danger_list.size():
        if danger_list[_index] == 0:
            _direction += ray_vector_list[_index]



    if _direction.y == 0:


        _direction = _get_alive_rag_vector().normalized()
    else:
        _direction = _direction.normalized()

    return _direction

func launch_detect():
    launch = true
    set_physics_process(true)

func delaunch_detect():
    launch = false
    set_physics_process(false)






func _refresh_direction():
    set_danger_list()
    direction = get_origin_direction()

func _get_alive_rag_vector():
    var _index = danger_list.find(0)

    if _index == -1:

        return Vector2(0, 1)

    return ray_vector_list[_index]

func _delete_all_ray():
    danger_list = []
    ray_vector_list = []
    real_ray_count = 0

    for _child in get_children():
        _child.queue_free()