extends Node2D
class_name SelectorTool

@export var select_collision_mask: int = 8

var start_position: Vector2
var end_position: Vector2
var custom_position_switch: = false
var is_active: bool = false


var search_physics_shape_query_parameters2d_node = PhysicsShapeQueryParameters2D.new()
var search_rectangle_shape = RectangleShape2D.new()
var direct_space_state = null


func _ready():
    search_physics_shape_query_parameters2d_node.collide_with_areas = false
    search_physics_shape_query_parameters2d_node.collide_with_bodies = true
    direct_space_state = get_world_2d().direct_space_state
    search_physics_shape_query_parameters2d_node.set_shape(search_rectangle_shape)

    end()
    self.show()

func _physics_process(_delta):
    queue_redraw()




func update_positions(_position1: Vector2, _position2: Vector2)-> void:
    start_position = _position1
    end_position = _position2


func start(_start_position: Vector2)-> void:
    start_position = _start_position
    is_active = true
    set_physics_process(true)


func end():
    is_active = false
    set_physics_process(false)
    queue_redraw()

func get_is_active()-> bool:
    return is_active


func select()-> Array:
    var _current_point = owner.get_mouse_position() if not custom_position_switch else end_position
    var _start_point = Vector2(min(start_position.x, _current_point.x), min(start_position.y, _current_point.y))
    var _end_point = Vector2(max(start_position.x, _current_point.x), max(start_position.y, _current_point.y))


    search_physics_shape_query_parameters2d_node.collision_mask = select_collision_mask

    search_rectangle_shape.size = _end_point - _start_point

    search_physics_shape_query_parameters2d_node.transform = Transform2D(0,(_end_point + _start_point) / 2)
    var _selected_list = direct_space_state.intersect_shape(search_physics_shape_query_parameters2d_node, 1000)

    var _target_node = null
    var _min_distance_square = CommonConstants.INT_MAX

    var _result = []

    for _unit in _selected_list:
        var _collider = _unit.collider
        if SoldierUtils.is_living_by_soldier_node(_collider) \

        and _collider.bs_group == BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP:
            _result.append(_collider)

    return _result

func set_custom_position(_switch: bool):
    custom_position_switch = _switch


func _draw():
    if is_active:
        draw_rect(
            Rect2(
                start_position,
                (owner.get_mouse_position() - start_position) \
                if not custom_position_switch \
                else(end_position - start_position)
            ),
            CommonConstants.COLOR_ENUM.YELLOW, false, 4
        )