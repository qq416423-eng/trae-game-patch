class_name StatusMachineBase extends Node

var call_back_func: Callable




func enter_necessary()-> void:
    pass

func set_callable(_callable: Callable)-> void:
    call_back_func = _callable

func enter_status()-> void:
    pass


func load_init_status()-> void:
    enter_status()

func action()-> void:
    pass

func exit_status(_next_status: int)-> bool:
    return true

func get_action_status()-> int:
    return 0

func get_action_status_str()-> String:
    return "未知状态"