class_name StatusMachineSubBase extends StatusMachineBase

func change_sub_status(_sub_status: int, _callable: Callable = Callable())-> void:
    get_parent().change_sub_status(_sub_status, _callable)

func exit_status(_next_status: int)-> bool:
    return false