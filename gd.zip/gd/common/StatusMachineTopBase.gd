class_name StatusMachineTopBase extends StatusMachineBase

func change_sub_status(_sub_status: int, _callable: Callable = Callable())-> void:
    pass