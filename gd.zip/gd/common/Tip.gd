class_name Tip extends Label

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var timer_node: Timer =$Timer

@export var content: = "已暂停":
    set(_value):
        content = _value
        CommonUtils.set_text(self, _value)
@export var open_ani: = false

func _ready():
    GlobalTimeControl.connect("time_scale_update_sign", _time_scale_update)
    if open_ani:
        animation_player_node.play("tip_effect")

func _time_scale_update(_time_scale: float)-> void:
    animation_player_node.speed_scale = 1.0 / _time_scale


func cshow(_content = "", _seconds: int = 0, _color: Color = CommonConstants.COLOR_ENUM.WHITE)-> void:
    if StringUtils.is_not_empty(_content):
        content = _content

    CommonUtils.update_self_color(self, _color)
    self.modulate.a = 1.0
    self.show()
    animation_player_node.play("tip_effect")
    if _seconds > 0:
        timer_node.start(_seconds)
    else:
        timer_node.stop()

func chide(_compare_content: String = ""):
    if StringUtils.is_not_empty(_compare_content) and content != _compare_content:
        return


    animation_player_node.stop()
    timer_node.stop()
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(self, "modulate:a", 0, 0.2)

func _on_timer_timeout()-> void:
    chide()