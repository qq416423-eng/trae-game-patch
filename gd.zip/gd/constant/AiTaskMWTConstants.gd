class_name AiTaskMWTConstants

enum AI_TASK_TYPE_ENUM {
    MOVE_TO_LOCATION_WITH_FLEE,
    TRADE,

    TRADE_SETTLEMENT,
    DELETE,
}

static func handle_task(_team_node: MWTeam, _task_json: Dictionary)-> void:
    match _task_json.task_type:
        AI_TASK_TYPE_ENUM.DELETE:
            _team_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)




        AI_TASK_TYPE_ENUM.MOVE_TO_LOCATION_WITH_FLEE:
            _team_node.move_to_location(
                _task_json.target_location_code, true, false,
                Callable(_team_node, "ai_task_finish_step")
            )





static func get_location_sub_status(_team_node: MWTeam, _task_json: Dictionary)-> Dictionary:
    var _callable: = Callable()
    var _status: = MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_IN

    match _task_json.task_type:
        AI_TASK_TYPE_ENUM.DELETE:
            _status = MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_DELETE
        AI_TASK_TYPE_ENUM.TRADE_SETTLEMENT:
            _status = MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_TRADE_SETTLEMENT
            _callable = Callable(_team_node, "ai_task_finish_step")
        AI_TASK_TYPE_ENUM.TRADE:
            _status = MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_TRADE
            _callable = Callable(_team_node, "ai_task_finish_step")
        AI_TASK_TYPE_ENUM.MOVE_TO_LOCATION_WITH_FLEE:
            _team_node.move_to_location(
                _task_json.target_location_code, true, false,
            )
            _status = MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_EXIT
            _callable = Callable(_team_node, "ai_task_finish_step")

    return {
        "status": _status,
        "callable": _callable
    }

static func generate_delete_task()-> Dictionary:
    return {
        "task_type": AI_TASK_TYPE_ENUM.DELETE
    }

static func generate_trade_settlement_task()-> Dictionary:
    return {
        "task_type": AI_TASK_TYPE_ENUM.TRADE_SETTLEMENT
    }

static func generate_move_to_location_with_flee_task(_location_code: String)-> Dictionary:
    return {
        "task_type": AI_TASK_TYPE_ENUM.MOVE_TO_LOCATION_WITH_FLEE,
        "target_location_code": _location_code,
    }

static func generate_trade_task()-> Dictionary:
    return {
        "task_type": AI_TASK_TYPE_ENUM.TRADE
    }