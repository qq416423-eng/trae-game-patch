class_name BSSoldierConstants

enum BS_SOLDIER_ACTION_ENUM {

    IDLE,

    MOVE,

    ATTACK,

    MOVE_AND_SE,

    MOVE_TO_ENEMY,

    DIEING,

    DIE,

    PREPARE,

    LANCE_MOVE,

    LANCE_PACK_UP,

    STUN,

    FLEE,

    SET_PIKE,
}











const ANIMATION_NAME_ENUM = {
    "IDLE": {

        "animation_name": "idle",

        "h_animation_name": "idle_horse",

        "ha_animation_name": "idle",
    },
    "MOVE": {
        "animation_name": "move",
        "h_animation_name": "move_horse",
        "ha_animation_name": "move",
    },
    "OH_ATTACK": {
        "animation_name": "oh_attack",
        "h_animation_name": "oh_attack_horse",

        "ha_animation_name": "move",
    },
    "TH_ATTACK": {
        "animation_name": "th_attack",
        "h_animation_name": "th_attack_horse",

        "ha_animation_name": "move",
    },
    "TH_BOW_ATTACK": {
        "animation_name": "th_bow_attack",
        "h_animation_name": "th_bow_attack_horse",
        "mobile_shooting_animation_name": "th_bow_mobile_shooting_horse",
        "ha_animation_name": "idle",
    },
    "TH_CROSSBOW_ATTACK": {
        "animation_name": "th_crossbow_attack",
        "h_animation_name": "th_crossbow_attack_horse",
        "mobile_shooting_animation_name": "th_crossbow_mobile_shooting_horse",
        "ha_animation_name": "idle",
    },
    "TH_FIREARM_ATTACK": {
        "animation_name": "th_firearm_attack",



    },
    "OH_THROW_ATTACK": {
        "animation_name": "oh_throw_attack",
        "h_animation_name": "oh_throw_attack_horse",
        "mobile_shooting_animation_name": "oh_throw_mobile_shooting_horse",
        "ha_animation_name": "idle",
    },
    "DIE": {
        "animation_name": "die",
        "h_animation_name": "die_horse",
        "ha_animation_name": "",
    },
    "LANCE_MOVE": {
        "animation_name": "lance_move",
        "h_animation_name": "lance_move",
        "ha_animation_name": "move",
    },

    "FLAT_LANCE": {
        "animation_name": "flat_lance",
        "h_animation_name": "flat_lance",
        "ha_animation_name": "move",
    },
    "LANCE_PACK_UP": {
        "animation_name": "lance_pack_up",
        "h_animation_name": "lance_pack_up",
        "ha_animation_name": "move",
    },
    "LANCE_PACK_UP_BREAK": {
        "animation_name": "lance_pack_up_break",
        "h_animation_name": "lance_pack_up_break",
        "ha_animation_name": "move",
    },

    "STUN_IDLE": {
        "animation_name": "idle",
        "h_animation_name": "idle_horse",

        "ha_animation_name": "",
    },

    "MOBILE_SHOOTING_TH_BOW": {
        "animation_name": "th_bow_mobile_shooting_horse",
        "h_animation_name": "th_bow_mobile_shooting_horse",

        "ha_animation_name": "move",
    },

    "SET_PIKE": {
        "animation_name": "set_pike",
        "h_animation_name": "",
        "ha_animation_name": "",
    }
}

const BS_BGROUP_ENUM: = {

    "ALLY": {
        "code": "ALLY",
        "against": "ENEMY",
    },
    "ENEMY": {
        "code": "ENEMY",
        "against": "ALLY"
    }
}

const BS_GROUP_ENUM = {
    PLAYER_GROUP = "bs_player",
    ENEMY_GROUP = "bs_enemy",
    TEAMMATE_GROUP = "bs_teammate"
}

enum LIVING_STATUS_ENUM {

    ACTIVE,

    SERIOUS_INJURY,

    DEATH,

    FLEE_SUCCESS,
}


enum MOVE_MODE_ENUM {

    DIRECT_MOVE,

    MAS_MOVE
}


enum GENDER_ENUM {

    MALE,

    FEMALE,

    ALL,
}


enum PREPARE_ACTION_ENUM {

    CHANGE_WEAPON,

    MAIN_WEAPON_BREAK,

    PLACE_L_SHIELD,

    PICK_L_SHIELD
}


const SOLDIER_BODY_EFFECT_NAME_ENUM = {
    DEF = "def",
    DEF_BREAK = "def_break",
    HURT = "hurt",
    BOW_HURT = "bow_hurt",
    DIE_BLOOD = "die_blood",
    STUN = "stun",

    LANCE_BREAK = "lance_break",

    CAPTURE_EFFECT = "capture_effect",

    SHIELD_PIERCE = "shield_pierce",

    FOCUS_EFFECT = "focus_effect",
    FLEE_EFFECT = "flee_effect",
    LANCE_ATTACK = "lance_attack",

    BUFF_DECELERATION = "buff_deceleration",

    BUFF_ACCELERATION = "buff_acceleration",

    SET_PIKE = "set_pike",

    PICK_PIKE = "pick_pike",

    SET_SHIELD = "set_shield",

    PICK_SHIELD = "pick_shield",

    HORSE_RAISE_DUST = "horse_raise_dust",

    WALK_RAISE_DUST = "walk_raise_dust",
    INFANTRY_WALK_WATER = "infantry_walk_water",
    INFANTRY_SPLASH_EFFECT = "infantry_splash_effect",
    CAVALRY_SPLASH_EFFECT = "cavalry_splash_effect",
    ARROW_SPLASH_EFFECT = "arrow_splash_effect",

    MISFIRE = "misfire"
}


enum IC_TYPE {

    INFANTRY,

    CAVALRY
}


const CAVALRY_SPRITE_CONFIG = {
    "vframe": 6,

    "position_update": Vector2(0, -22),
}

const INFANTRY_SPRITE_CONFIG = {
    "vframe": 6,
}


const CANT_INTERRUPT_ACTION_STATUS_LIST: = [
    BS_SOLDIER_ACTION_ENUM.LANCE_PACK_UP,
    BS_SOLDIER_ACTION_ENUM.PREPARE,
    BS_SOLDIER_ACTION_ENUM.STUN
]


enum INJURED_LEVEL_ENUM {
    COMMON,
    SLIGHT_WOUND,
    SEVERE_WOUND
}


enum H_TYPE_ENUM {
    SOLDIER,
    HERO
}


const PROP_SHOW_CONFIG = {
    "hit_ratio": {
        "type": COMPUTE_TYPE_ENUM.PERCENT
    },
    "crit_prob": {
        "type": COMPUTE_TYPE_ENUM.PERCENT
    },
    "crit_atk_ratio": {
        "type": COMPUTE_TYPE_ENUM.PERCENT
    },
    "block_prob": {
        "type": COMPUTE_TYPE_ENUM.PERCENT
    },
    "b_block_prob": {
        "type": COMPUTE_TYPE_ENUM.PERCENT
    },
    "attack_speed": {
        "type": COMPUTE_TYPE_ENUM.THREE_DECIMALS
    }
}

enum COMPUTE_TYPE_ENUM {

    PERCENT,

    THREE_DECIMALS,
}

enum ARMS_TYPE_ENUM {

    CAVALRY,

    INFANTRY
}

enum ARMS_SMALL_TYPE_ENUM {

    CAVALRY_REMOTE,

    CAVALRY_MELEE,

    INFANTRY_REMOTE,

    INFANTRY_MELEE,
}


enum COMBAT_RANGE_TYPE_ENUM {

    MELEE,

    RANGED
}