class_name BattleConstants

const BATTLE_RESULT_ENUM = {
    VICTORY = "VICTORY",
    DEFEAT = "DEFEAT"
}


enum BATTLE_SCENE_MODE_ENUM {

    FORMATION_MODE,

    BATTLE_MODE,
}

static func get_battle_result_inverse(_battle_result):
    match _battle_result:
        BATTLE_RESULT_ENUM.VICTORY:
            return BATTLE_RESULT_ENUM.DEFEAT
        BATTLE_RESULT_ENUM.DEFEAT:
            return BATTLE_RESULT_ENUM.VICTORY