class_name BattleSceneAIConstants

const GROUP_AI_STATUS_ENUM = {

    STOP = "STOP",
    MOVE = "MOVE",
}


const CHECK_INTERVAL = 40


enum AI_BATTLE_STRATEGY_ENUM {

    CHARGE = 0,





    DEFENSIVE = 1,

    ADVANCING_ATTACK = 2,
}