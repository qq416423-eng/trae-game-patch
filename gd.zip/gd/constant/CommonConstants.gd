class_name CommonConstants

const INT_MAX = 2 << 32

enum DIRECTION_ENUM {
    LEFT,
    RIGHT,

    TOP,
    DOWN
}


enum PLATFORM_ENUM {

    PC,

    MOBILE
}

const COLOR_ENUM = {
    YELLOW = Color(1, 0.94, 0.46, 1),
    GRAY = Color(0.74, 0.74, 0.74, 1),
    GRAY_LUCENCY = Color(0.74, 0.74, 0.74, 0.6),
    RED = Color(0.9, 0.27, 0.35, 1),
    RED_LIGHT = Color(1.0, 0.65, 0.7, 1),
    WHITE = Color(1, 1, 1, 1),
    WHITE_LUCENCY = Color(1, 1, 1, 0.5),

    LIGHT_VIOLET = Color(0.8, 0.57, 0.84, 1),
    VIOLET = Color(0.76, 0.32, 0.92, 1),
    VIOLET2 = Color(0.61, 0.15, 0.69, 1),

    GREEN = Color(0.25, 0.74, 0.25, 1),

    DARK = Color(0.4, 0.4, 0.4, 1),

    GREY = Color(0.6, 0.6, 0.6, 1),

    SHALLOW_WHITE = Color(0.8, 0.8, 0.8, 1),

    BLUE = Color(0.28, 0.58, 0.9, 1),
    BLUE_LIGHT = Color(0.38, 0.8, 1.0, 1),
    MOVE_COLOR = Color(1, 1, 1, 1),
    ATTACK_COLOR = Color(0.9, 0.3, 0.25, 1),
    DARK_GRAY = Color("585858"),
    ORANGE = Color.ORANGE,

    BROWN = Color("795548")
}

const MESSAGE_ENUM = {



    ENTER_CITY = "正在进入城镇...",
    ENTER_VILLAGE = "正在进入村庄...",
    ENTER_CASTLE = "正在进入城堡...",
    EXIT_CITY = "正在离开城镇...",
    EXIT_VILLAGE = "正在离开村庄...",
    EXIT_CASTLE = "正在离开城堡...",
}


const GOODS_EXCHANGE_TYPE = {

    LOCATION = "LOCATION",

    MY_ITEMS = "MY_ITEMS",

    TROPHY = "TROPHY",

    WAREHOUSE = "WAREHOUSE"
}

const UUID_PREFIX_ENUM = {
    TEAM = "team",
    BATTLE = "battle"
}

const SEED_KEY_ENUM = {
    NPC_REFRESH = "npc_refresh_",
    REFRESH_GOODS = "refresh_goods_",
}