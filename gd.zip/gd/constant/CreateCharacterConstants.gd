class_name CreateCharacterConstants

const INIT_CHARACTER_SKILL_APTITUDE = 20

const INIT_CHARACTER_INFO = {
    "uid": "",
    "name": "",
    "base_strength": 30,
    "base_agile": 30,
    "base_physical": 30,
    "base_intelligence": 30,
    "level": 1,
    "gender": BSSoldierConstants.GENDER_ENUM.MALE,
    "aptitude_skill_battle_talent": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_medical": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_operation": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_investigation": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_motility": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_manage": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_trade": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_plunder": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_train": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_engineer": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_strength": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_agile": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_physical": INIT_CHARACTER_SKILL_APTITUDE,
    "aptitude_skill_charisma": INIT_CHARACTER_SKILL_APTITUDE,
    "practise_oh_sword": 0,
    "practise_th_sword": 0,
    "practise_oh_axe": 0,
    "practise_th_axe": 0,
    "practise_oh_blunt": 0,
    "practise_oh_lance": 0,
    "practise_oh_pole": 0,
    "practise_th_pole": 0,
    "practise_th_bow": 0,
    "practise_th_crossbow": 0,
    "practise_oh_throw": 0,
    "practise_oh_shield": 0,
    "practise_horse": 0,
    "practise_mobile": 0,
    "skill_medical": 1,
    "skill_operation": 0,
    "skill_investigation": 2,
    "skill_motility": 2,
    "skill_trade": 1,
    "skill_plunder": 1,
    "skill_train": 1,
    "skill_battle_talent": 2,
    "skill_manage": 2,
    "skill_strength": 1,
    "skill_agile": 1,
    "skill_physical": 1,
    "skill_charisma": 0,
    "body": {
        "uid": "body_0001",
    },
    "hair": {
        "uid": "hair_0001",
    },
    "armour": {
        "uid": "armour_0006"
    },
    "helmet": {

    },
    "shoe": {
        "uid": "shoe_0004"
    },
    "shoulder": {

    },
    "weapon1": {

    },
    "weapon2": {

    },
    "weapon3": {

    },
    "horse": {

    },
    "harmour": {

    },
}


const GENDER_PROP_PLUS_CONFIG = {
    BSSoldierConstants.GENDER_ENUM.MALE: {
        "base_strength": 15,
        "base_physical": 15,
        "base_agile": 15,
        "base_intelligence": 15,
        "aptitude_skill_battle_talent": 10,
        "aptitude_skill_manage": 10,
        "aptitude_skill_train": 10,
        "aptitude_skill_plunder": 10,
        "aptitude_skill_engineer": 10,
        "aptitude_skill_physical": 10,
    },
    BSSoldierConstants.GENDER_ENUM.FEMALE: {
        "base_agile": 10,
        "base_intelligence": 15,
        "aptitude_skill_medical": 10,
        "aptitude_skill_operation": 10,
        "aptitude_skill_investigation": 10,
        "aptitude_skill_trade": 10,
        "aptitude_skill_charisma": 30,
        "skill_charisma": 3,
    },
}

const BACKGROUND_CHOOSE_JSON = [
    {
        "question": "我出生于一个 ( ___ ) 的家庭...",
        "remark": "装备(盔甲 or weapon3), 钱, 天赋, 技能",
        "options": [
            {
                "name": "猎人",
                "remark": "弓箭 + 皮甲",
                "value": {
                    "armour": {
                        "uid": "armour_0007",
                    },
                    "weapon1": {
                        "uid": "th_bow_0001"
                    },
                    "shoe": {
                        "uid": "shoe_0006"
                    },

                    "aptitude_skill_investigation": 30,

                    "aptitude_skill_strength": 25,

                    "aptitude_skill_battle_talent": 15,

                    "aptitude_skill_medical": 15,

                    "aptitude_skill_trade": 10,
                    "aptitude_skill_physical": 10,
                    "aptitude_skill_agile": 10,
                }
            },
            {
                "name": "商人",
                "remark": "钱 + 马",
                "value": {
                    "money": 2500,
                    "horse": {
                        "uid": "horse_0002"
                    },
                    "goods": [
                        {
                            "item": {
                                "uid": "food_0015",
                            },
                            "count": 3
                        },
                        {
                            "item": {
                                "uid": "th_crossbow_0001",
                            },
                            "count": 1
                        },
                    ],
                    "aptitude_skill_trade": 35,
                    "aptitude_skill_charisma": 20,
                    "aptitude_skill_motility": 20,
                    "aptitude_skill_manage": 20,
                    "aptitude_skill_plunder": 10,
                    "aptitude_skill_investigation": 10,
                    "practise_horse": 20,
                }
            },
            {
                "name": "草药师",
                "value": {
                    "aptitude_skill_medical": 35,
                    "aptitude_skill_operation": 25,
                    "aptitude_skill_investigation": 25,
                    "aptitude_skill_motility": 10,
                    "aptitude_skill_trade": 10,
                    "aptitude_skill_plunder": 10,
                }
            },
            {
                "name": "退役士兵",
                "value": {
                    "armour": {
                        "uid": "armour_0011"
                    },
                    "shoe": {
                        "uid": "shoe_0001"
                    },
                    "weapon1": {
                        "uid": "oh_shield_0001"
                    },
                    "aptitude_skill_battle_talent": 20,
                    "aptitude_skill_train": 15,
                    "aptitude_skill_strength": 15,
                    "aptitude_skill_physical": 15,
                    "aptitude_skill_agile": 15,
                    "aptitude_skill_motility": 10,
                    "aptitude_skill_manage": 10,
                    "aptitude_skill_plunder": 10,
                    "aptitude_skill_medical": 10,
                }
            },
            {
                "name": "退役骑兵",
                "value": {
                    "armour": {
                        "uid": "armour_0011"
                    },
                    "shoe": {
                        "uid": "shoe_0011"
                    },
                    "horse": {
                        "uid": "horse_0001"
                    },
                    "aptitude_skill_battle_talent": 20,
                    "aptitude_skill_train": 15,
                    "aptitude_skill_motility": 15,
                    "aptitude_skill_manage": 15,
                    "aptitude_skill_physical": 10,
                    "aptitude_skill_strength": 10,
                    "aptitude_skill_agile": 10,
                    "aptitude_skill_plunder": 10,
                    "aptitude_skill_charisma": 10,
                    "practise_horse": 40,
                }
            }
        ]
    },
    {
        "question": "少年时期的我 ( ___ ) ...",
        "remark": "技能",
        "options": [
            {
                "name": "对草药方面的知识很感兴趣",
                "value": {
                    "skill_medical": 6,
                    "skill_investigation": 4,
                    "skill_operation": 2,
                    "skill_physical": 2,
                    "skill_strength": 2,
                    "skill_agile": 2,
                    "skill_motility": 2,
                    "skill_trade": 2,
                    "aptitude_skill_medical": 30,
                    "aptitude_skill_operation": 30,
                    "aptitude_skill_investigation": 20,
                    "aptitude_skill_motility": 20,
                    "aptitude_skill_physical": 20,
                    "practise_oh_sword": 10,
                    "practise_oh_axe": 10,
                    "practise_oh_pole": 10,
                    "practise_oh_throw": 10,
                    "practise_th_bow": 15,
                }
            },
            {
                "name": "喜欢去森林里打猎",
                "value": {
                    "skill_investigation": 6,
                    "skill_motility": 4,
                    "skill_strength": 4,
                    "skill_plunder": 2,
                    "skill_train": 2,
                    "skill_manage": 2,
                    "skill_physical": 2,
                    "skill_agile": 2,
                    "aptitude_skill_investigation": 30,
                    "aptitude_skill_battle_talent": 20,
                    "aptitude_skill_plunder": 20,
                    "aptitude_skill_strength": 20,
                    "aptitude_skill_medical": 10,
                    "aptitude_skill_trade": 10,
                    "aptitude_skill_physical": 10,
                    "practise_oh_sword": 15,
                    "practise_oh_axe": 15,
                    "practise_oh_pole": 15,
                    "practise_oh_throw": 15,
                    "practise_th_bow": 40,
                }
            },
            {
                "name": "喜欢观察大人们谈生意的情景",
                "value": {
                    "skill_trade": 6,
                    "skill_plunder": 2,
                    "skill_manage": 2,
                    "skill_investigation": 2,
                    "skill_train": 2,
                    "aptitude_skill_trade": 50,
                    "aptitude_skill_manage": 40,
                    "aptitude_skill_charisma": 30,
                    "aptitude_skill_plunder": 20,
                    "aptitude_skill_train": 20,
                    "aptitude_skill_motility": 20,
                    "practise_oh_sword": 10,
                    "practise_oh_axe": 10,
                    "practise_oh_pole": 10,
                }
            },
            {
                "name": "是玩伴心中的领导型人物",
                "value": {
                    "skill_manage": 6,
                    "skill_train": 6,
                    "skill_charisma": 2,
                    "skill_physical": 2,
                    "skill_strength": 2,
                    "skill_agile": 2,
                    "aptitude_skill_manage": 60,
                    "aptitude_skill_charisma": 30,
                    "aptitude_skill_train": 20,
                    "aptitude_skill_investigation": 10,
                    "aptitude_skill_motility": 10,
                    "aptitude_skill_physical": 10,
                    "practise_oh_sword": 15,
                    "practise_oh_axe": 15,
                    "practise_oh_pole": 15,
                }
            },
            {
                "name": "身体强壮, 常常练习格斗技巧",
                "value": {
                    "skill_agile": 5,
                    "skill_physical": 5,
                    "skill_strength": 5,
                    "skill_battle_talent": 5,
                    "skill_train": 2,
                    "aptitude_skill_battle_talent": 40,
                    "aptitude_skill_strength": 30,
                    "aptitude_skill_agile": 30,
                    "aptitude_skill_physical": 30,
                    "aptitude_skill_plunder": 10,
                    "aptitude_skill_train": 10,
                    "aptitude_skill_charisma": 10,
                    "practise_oh_sword": 20,
                    "practise_th_sword": 20,
                    "practise_oh_axe": 20,
                    "practise_th_axe": 20,
                    "practise_oh_pole": 20,
                    "practise_oh_shield": 20,
                }
            },
        ]
    },
    {
        "question": "相对的, 我更喜欢 ( ___ )",
        "remark": "武器熟练度",
        "options": [
            {
                "name": "双手剑的力量感",
                "value": {
                    "weapon2": {
                        "uid": "th_sword_0001",
                    },
                    "practise_oh_sword": 10,
                    "practise_oh_axe": 10,
                    "practise_oh_pole": 10,
                    "practise_oh_shield": 10,
                    "practise_th_sword": 20,
                    "practise_th_axe": 20,
                    "practise_th_pole": 15,
                }
            },
            {
                "name": "单手剑加盾牌的作战方式",
                "value": {
                    "weapon2": {
                        "uid": "oh_sword_0015",
                    },
                    "weapon3": {
                        "uid": "oh_shield_0001"
                    },
                    "practise_oh_sword": 20,
                    "practise_oh_axe": 20,
                    "practise_oh_pole": 20,
                    "practise_oh_shield": 20,
                }
            },
        ]
    },
    {
        "question": "我的父母还收养了一个被遗弃的 ( ___ )，" \
        + "他/她叫 ( ___ ), 和我同岁, 力大无穷, 擅长 ( ___ ), " \
        + "打架的话我甚至不是他/她的对手",
        "remark": "初始英雄",
        "options": [
            {
                "name": "男孩, 雷纳德, 打猎",
                "value": {
                    "siblings_gender": BSSoldierConstants.GENDER_ENUM.MALE
                }
            },
            {
                "name": "女孩, 艾琳娜, 剑术",
                "value": {
                    "siblings_gender": BSSoldierConstants.GENDER_ENUM.FEMALE
                }
            },
        ]
    },
]

const INIT_TEAM_JSON = {
    "team_role": MWTeamConstants.TEAM_ROLE_ENUM.RONIN,
    "position": Vector2(1000, 800),
    "money": 3000,
    "morale": TeamConfig.DEFAULT_MORALE,



    "weather": MWorldConstants.WEATHER_TYPE_ENUM.CLEAR,
    "goods": [
        {
            "item": {
                "uid": "food_0001",
            },
            "count": 2,
        },
        {
            "item": {
                "uid": "food_0015",
            },
            "count": 2,
        },
    ],
    "team": [
        {
            "uid": PLAYER_HERO_CODE,
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
            "is_leader": true,
            "is_player": true,
        }
    ]
}

const PLAYER_HERO_CODE = "player_hero_0001"


static func get_siblings_uid(_gender: BSSoldierConstants.GENDER_ENUM)-> String:
    match _gender:
        BSSoldierConstants.GENDER_ENUM.MALE:
            return "wild_hero_0001"
        BSSoldierConstants.GENDER_ENUM.FEMALE:
            return "wild_hero_0002"

    return ""