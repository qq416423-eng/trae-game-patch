class_name DialogueConstants


enum STEP_TYPE_ENUM {

    DIALOG,

    OPTION,
}

enum OPTION_TYPE_ENUM {

    BATTLE,

    BATTLE_HELP_TEAM1,

    BATTLE_HELP_TEAM2,

    BRIBERY_LEAVE,

    LEAVE,

    JOIN_BATTLE,

    EXIT_CONVERSATION,

    INSPECT_TREASURES,

    FLEE,

    TALK,

    HIRE,

    SELL_PRISONER,

    PAY,

    JOIN_COUNTRY,

    EXTORT,

    LEAVE_COUNTRY,

    SUPPORT,
}

const OPTION_TYPE_CONFIG = {
    OPTION_TYPE_ENUM.BATTLE: {
        "icon": "res://resource/icon/locationButtonIcon/attack_icon.png",
        "name": "战斗",
    },
    OPTION_TYPE_ENUM.BATTLE_HELP_TEAM1: {
        "icon": "res://resource/icon/locationButtonIcon/attack_icon.png",
        "name": "战斗",
    },
    OPTION_TYPE_ENUM.BATTLE_HELP_TEAM2: {
        "icon": "res://resource/icon/locationButtonIcon/attack_icon.png",
        "name": "战斗",
    },
    OPTION_TYPE_ENUM.BRIBERY_LEAVE: {
        "icon": "res://resource/icon/locationButtonIcon/bribery_icon.png",
        "name": "贿赂",
    },
    OPTION_TYPE_ENUM.LEAVE: {
        "icon": "res://resource/icon/locationButtonIcon/leave_icon.png",
        "name": "离开",
    },
    OPTION_TYPE_ENUM.JOIN_BATTLE: {

    },
    OPTION_TYPE_ENUM.INSPECT_TREASURES: {
        "icon": "res://resource/icon/locationButtonIcon/exchange_icon.png",
        "name": "交易",
    },
    OPTION_TYPE_ENUM.FLEE: {
        "icon": "res://resource/icon/locationButtonIcon/leave_icon.png",
        "name": "逃跑",
    },
    OPTION_TYPE_ENUM.TALK: {
        "icon": "res://resource/icon/locationButtonIcon/talk_icon.png",
        "name": "谈话",
    },
    OPTION_TYPE_ENUM.HIRE: {
        "icon": "res://resource/icon/locationButtonIcon/hire_icon.png",
        "name": "招聘",
    },
    OPTION_TYPE_ENUM.SELL_PRISONER: {
        "icon": "res://resource/icon/locationButtonIcon/sell_prisoner_icon.png",
        "name": "出售俘虏",
    },
    OPTION_TYPE_ENUM.PAY: {
        "icon": "res://resource/icon/locationButtonIcon/bribery_icon.png",
        "name": "付钱",
    },
    OPTION_TYPE_ENUM.JOIN_COUNTRY: {
        "icon": "res://resource/icon/locationButtonIcon/join_country_icon.png",
        "name": "加入国家",
    },
    OPTION_TYPE_ENUM.EXTORT: {
        "icon": "res://resource/icon/locationButtonIcon/extort_icon.png",
        "name": "勒索",
    },
    OPTION_TYPE_ENUM.LEAVE_COUNTRY: {
        "icon": "res://resource/icon/locationButtonIcon/leave_country_icon.png",
        "name": "退出国家",
    },
    OPTION_TYPE_ENUM.SUPPORT: {
        "icon": "res://resource/icon/locationButtonIcon/attack_icon.png",
        "name": "请求支援",
    },
}


enum SPEAKER_ENUM {

    A,

    B,





}


enum CONTENT_CONDITION_ENUM {

    ALL,

    HAS_EXCHANGE_TREASURE,

    LEADER_IS_MALE,

    LEADER_IS_FEMALE,

    MONEY_ENOUGH,

    MONEY_NOT_ENOUGH,

    NOP_NOT_ENOUGH,

    NOP_ENOUGH,
}


enum EXECUTE_TYPE_ENUM {

    PLUS_MONEY,
    MINUS_ITEM,
}

const DIALOGUE_NARRATOR = {
    WHAT_ARE_OUR_NEXT_STEPS = "(我方要怎么做?)",
    WE_CHOOSE_TO_FLEE = "(我方选择逃跑) (功能尚未完善, 逃跑不会有惩罚)",
    WE_CHOOSE_TO_LEAVE = "(我方选择离开)",
    CONFIRM_DECLARE_WAR = "(此举会被视为对 [#{0}] 宣战, 是否继续?)",
    ENEMY_PREPARES_ATTACK = "(对方准备进攻, 我方要怎么做?)",
    WHAT_ARE_MY_NEXT_STEPS = "(我要怎么做?)",
    WHAT_ARE_MY_NEXT_STEPS_2 = "(#{0}, 我要怎么做?)",
    CONFIRM_LEAVE_COUNTRY = "(此举将归还所有领地, 领地驻军和仓库物品将无法取出, 并大幅降低与国王及领主们的关系. 确定要脱离该王国吗?)"
}


const IMPORTANT_CONTENT_COLOR = "#FF8F00"