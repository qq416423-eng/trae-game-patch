class_name FoodConstants extends Node


const FOOD_TYPE_ENUM = {

    STAPLE = "STAPLE",

    ACCOMPANIMENT = "ACCOMPANIMENT"
}

const FOOD_TYPE_CONFIG = {
    FOOD_TYPE_ENUM.STAPLE: {
        "name": "主食",
    },
    FOOD_TYPE_ENUM.ACCOMPANIMENT: {
        "name": "副食",
    }
}


const FOOD_CONSUME_TYPE_ENUM = {
    FRUGALNESS = "FRUGALNESS",
    COMMON = "COMMON",
    LUXURIOUS = "LUXURIOUS",
}

const FOOD_CONSUME_TYPE_ENUM_CONFIG = {
    FOOD_CONSUME_TYPE_ENUM.FRUGALNESS: {
        "ratio": FoodConfig.FOOD_CONSUME_WAY_1,
    },
    FOOD_CONSUME_TYPE_ENUM.COMMON: {
        "ratio": FoodConfig.FOOD_CONSUME_WAY_2,
    },
    FOOD_CONSUME_TYPE_ENUM.LUXURIOUS: {
        "ratio": FoodConfig.FOOD_CONSUME_WAY_3,
    },
}