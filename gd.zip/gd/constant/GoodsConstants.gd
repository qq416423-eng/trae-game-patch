class_name GoodsConstants


const EQUIPMENT_DETAIL_EXCLUDE_FIELD_LIST = [
    "name", "power_need", "t_path", "cover_path", "color", "color_list",
    "want_attack_range", "place_hold_num", "price", "durability", "throw_texture_path",
    "need_adhere", "uid", "quality", "quality_name", "special_name", "uid_prefix", "fly_speed", "fly_radian",
    "infantry_pause", "change_melee_weapon_distance_square", "take_out_priority", "take_out_at_distance_min_square",
    "texture_equipment_name", "etype", "btype", "oot", "utype", "attack_type", "animation_name_enum",
    "stype", "type_name", "origin", "item_json", "bs_t_path", "place_t_path_up", "place_t_path_down", "weapon_index",
    "shot_radian", "throw_rotate", "flyer_speed", "flyer_path", "price_ratio", "commodity_price_ratio",
    "expired_food", "star", "system_remark",

    "unit_price", "location_refresh_config",
    "lock", "horse_power", "character_y_plus", "horse_animation_speed", "mount_type",
    "shelf_life"

]


const EQUIPMENT_DETAIL_EXCLUDE_FIELD_SUFFIX_LIST = ["_special_plus"]


const ATTRIBUTE_PLUS_FIELD_SUFFIX = "_special_plus"

static var EQUIPMENT_DETAIL_DICTIONARY = {
    "name": {
        "name": "名称",
        "unit": "",

        "c_type": COMPUTE_TYPE_ENUM.NORMAL,

        "s_priority": 0
    },
    "def": {
        "name": "防御力",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 1000
    },
    "crit_def": {
        "name": "暴击防御力",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 990
    },
    "weight": {
        "name": "重量",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 100
    },
    "price": {
        "name": "价格",
        "unit": "德尔",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 0
    },
    "power_need": {
        "name": "装备要求(力量)",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 0
    },
    "speed": {
        "name": "速度",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 1000
    },
    "atk": {
        "name": "攻击力",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 1000
    },
    "hit_ratio": {
        "name": "命中率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 970
    },
    "crit_prob": {
        "name": "暴击率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 990
    },
    "crit_atk_ratio": {
        "name": "暴击伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 980
    },
    "attack_range": {
        "name": "攻击范围",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 500
    },
    "e_hp": {
        "name": "坚固度",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 1010
    },
    "block_prob": {
        "name": "格挡率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 1000
    },
    "b_block_prob": {
        "name": "背击格挡率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 1000
    },
    "block_def": {
        "name": "格挡防御力",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 990
    },
    "block_crit_def": {
        "name": "格挡暴击防御力",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 980
    },
    "shot_count": {
        "name": "弹药数量",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 450
    },
    "description": {
        "name": "简介",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 0
    },
    "morale_plus": {
        "name": "士气增加",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 0
    },
    "effect_type": {
        "name": "治疗类型",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.ENUM,
        "enum_dic": MEDICINE_EFFECT_TYPE_DIC,
        "s_priority": 600
    },
    "medical_effect": {
        "name": "治疗效果",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 500
    },
    "skill_learn_skill_medical": {
        "name": "技能学习速度(医疗)",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "prefix": "+",
        "s_priority": 1000
    },
    "skill_learn_skill_operation": {
        "name": "技能学习速度(手术)",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "prefix": "+",
        "s_priority": 990
    },
    "attack_bonus_shield": {

        "name": "对盾牌伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "prefix": "+",
        "s_priority": 549,



    },
    "attack_bonus_cavalvy": {
        "name": "对骑兵伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "prefix": "+",
        "s_priority": 550,
    },
    "lance_break_prob": {
        "name": "骑枪折断率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },
    "lance_cd": {
        "name": "骑枪冷却时间",
        "unit": "s",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 202,
    },
    "knock_back": {
        "name": "步兵击退",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 100,
    },
    "prevent_lance_sprint_prob": {
        "name": "逼停骑枪冲刺概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 400,
    },
    "cavalvy_forbid": {
        "name": "骑兵无法使用",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 10,
    },
    "infantry_forbid": {
        "name": "步兵无法使用",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 10,
    },
    "remote_attack_on_the_ground": {
        "name": "远程攻击时将巨盾放置地面",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 1,
    },
    "placement_time": {
        "name": "放置/收起耗时",
        "unit": "s",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 0,
    },
    "stun_prop": {
        "name": "击晕概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 220,
    },
    "stun_second": {
        "name": "击晕时间",
        "unit": "s",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 210,
    },
    "ahp": {
        "name": "HP上限",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 400,
        "prefix": "+",
    },
    "shot_accuracy": {
        "name": "射击精度",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 800,
    },

    "shot_radian": {
        "name": "轨迹弧度",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 0,
    },

    "stability": {
        "name": "稳定性",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 300,
    },

    "capture_prob": {
        "name": "俘虏概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },







    "shield_pierce": {
        "name": "对盾牌伤害倍率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 800,
    },
    "food_type": {
        "name": "食物类型",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.ENUM,
        "enum_dic": FoodConstants.FOOD_TYPE_CONFIG,
        "s_priority": 300,
    },
    "consumption_total": {
        "name": "食用总量",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 260,
    },
    "shelf_life": {
        "name": "保质期",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.FUNCTION,
        "function": "get_shelf_life_value_name",
        "s_priority": 250,
    },
    "morale_impact": {
        "name": "士气影响",
        "unit": "",
        "prefix": "+",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 280,
    },
    "edible": {
        "name": "是否可食用",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.BOOL,
        "s_priority": 290,
    },
    "set_pike": {
        "name": "架枪抵御骑枪冲刺",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 15,
    },
    "skin": {
        "name": "皮肤类装备",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 10,
    },
    "interrupt": {
        "name": "打断骑枪冲刺概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },
    "weight_attack_speed_debuff_double": {
        "name": "装备重量对攻速惩罚加倍",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 10,
    },
    "horse_power_1": {

        "name": "放在背包可供1个步兵乘骑, 使步兵在世界地图移动时具有骑兵的移速(需要马匹品质至少是普通级)",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 10,
    },

    "carrying_capacity": {
        "name": "马车负重",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 280,
    },

    "speed_reduction": {
        "name": "移速折损",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },

    "carrying_capacity_remark": {

        "name": "可抵消背包货物重量带来的移速降低的debuff",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 10,
    },















    "speed_damage": {
        "name": "速度和伤害成正比",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 100,
    },
    "horse_armour": {
        "name": "马铠",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 100,
    },
    "camel_armour": {
        "name": "骆驼铠",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 100,
    },
    "lance_forbid": {
        "name": "无法使用骑枪",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 120,
    },
    "desert_resistance": {
        "name": "沙漠适应",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 280,
    },
    "light_speed": {
        "name": "穿戴装备在20重量以下, 移速",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 100,
        "prefix": "+",
    },
    "ignores_strength_bonus_atk": {
        "name": "力量不加成攻击力",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 20,
    },
    "hit_ratio_min": {
        "name": "最小命中率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 970
    },
    "hit_ratio_max": {
        "name": "最大命中率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 960
    },
    "misfire_ratio_rain_min": {
        "name": "下雨天哑火概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 900
    },
    "misfire_ratio_rain_max": {
        "name": "暴雨天哑火概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 890
    },
    "is_close_range_accurate": {
        "name": "目标距离越近命中率越高",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 20,
    },

    "panic_buff_melee_attack_on_infantry": {
        "name": "近战攻击命中时对步兵施加恐慌效果(攻击力-" + str(PANIC_BUFF_MELEE_ATTACK_ON_INFANTRY_ATTACK_REDUCTION_RATIO * 100)
            + "%, 持续" + str(PANIC_BUFF_MELEE_ATTACK_ON_INFANTRY_TIME_LEFT_SECONDS) + "秒)",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 200,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.PANIC,
        "buff_props": {
            "attack_reduction_ratio": PANIC_BUFF_MELEE_ATTACK_ON_INFANTRY_ATTACK_REDUCTION_RATIO,
            "time_left_seconds": PANIC_BUFF_MELEE_ATTACK_ON_INFANTRY_TIME_LEFT_SECONDS,
        },
    },

    "panic_buff_camel_melee_attack": {
        "name": "近战攻击命中时对骑兵(马)/步兵施加恐慌效果(攻击力-" + str(PANIC_BUFF_CAMEL_MELEE_ATTACK_ON_INFANTRY_ATTACK_REDUCTION_RATIO * 100)
            + "%, 持续" + str(PANIC_BUFF_CAMEL_MELEE_ATTACK_ON_INFANTRY_TIME_LEFT_SECONDS) + "秒)",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 200,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.PANIC,
        "buff_props": {
            "attack_reduction_ratio": PANIC_BUFF_CAMEL_MELEE_ATTACK_ON_INFANTRY_ATTACK_REDUCTION_RATIO,
            "time_left_seconds": PANIC_BUFF_CAMEL_MELEE_ATTACK_ON_INFANTRY_TIME_LEFT_SECONDS,
        },
    },

    "panic_buff_weapon_small_to_cavalry": {
        "name": "攻击命中时对骑兵施加恐慌效果(攻击力-" + str(PANIC_BUFF_WEAPON_SMALL_TO_CAVALRY_ATTACK_REDUCTION_RATIO * 100)
            + "%, 持续" + str(PANIC_BUFF_WEAPON_SMALL_TO_CAVALRY_TIME_LEFT_SECONDS) + "秒)",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 200,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.PANIC,
        "buff_props": {
            "attack_reduction_ratio": PANIC_BUFF_WEAPON_SMALL_TO_CAVALRY_ATTACK_REDUCTION_RATIO,
            "time_left_seconds": PANIC_BUFF_WEAPON_SMALL_TO_CAVALRY_TIME_LEFT_SECONDS,
        },
    },

    "panic_buff_weapon_big_to_cavalry": {
        "name": "攻击命中时对骑兵施加恐慌效果(攻击力-" + str(PANIC_BUFF_WEAPON_BIG_TO_CAVALRY_ATTACK_REDUCTION_RATIO * 100)
            + "%, 持续" + str(PANIC_BUFF_WEAPON_BIG_TO_CAVALRY_TIME_LEFT_SECONDS) + "秒)",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 200,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.PANIC,
        "buff_props": {
            "attack_reduction_ratio": PANIC_BUFF_WEAPON_BIG_TO_CAVALRY_ATTACK_REDUCTION_RATIO,
            "time_left_seconds": PANIC_BUFF_WEAPON_BIG_TO_CAVALRY_TIME_LEFT_SECONDS,
        },
    },

    "shield_break_ratio": {

        "name": "破盾概率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 890
    },

    "infantry_speed_plus": {
        "name": "步兵移速",
        "unit": "",
        "prefix": "+",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 280,
    },

    "base_physical_plus": {
        "name": "体力",
        "unit": "",
        "prefix": "+",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 450,
    },

    "attack_damage_plus_oh_melee": {
        "name": "单手近战武器伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 400,
        "prefix": "+",
    },
    "attack_damage_plus_th_melee": {
        "name": "双手近战武器伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 380,
        "prefix": "+",
    },
    "th_bow_plus_crit_prob_ratio": {
        "name": "弓箭暴击率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
        "prefix": "+",
    },
    "th_crossbow_plus_crit_prob_ratio": {
        "name": "弩/火枪暴击率",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 150,
        "prefix": "+",
    },
    "th_bow_attack_plus_ratio": {
        "name": "弓箭伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "prefix": "+",
        "s_priority": 200,
    },
    "attack_damage_plus_oh_throw": {
        "name": "投掷武器伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 400,
        "prefix": "+",
    },
    "attack_speed_plus": {
        "name": "攻速",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 400,


        "positive_prefix": "+",
    },
    "attack_speed_plus_th_bow": {
        "name": "弓箭攻速",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 400,
        "prefix": "+",
    },
    "attack_speed_plus_th_crossbow": {
        "name": "弩/火枪攻速",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 380,
        "prefix": "+",
    },
    "attack_speed_plus_oh_melee": {
        "name": "单手近战武器攻速",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 380,
        "prefix": "+",
    },
    "attack_speed_plus_th_melee": {
        "name": "双手近战武器攻速",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 100,
    },

    "remote_hurt_plus": {
        "name": "受到远程伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },

    "cavalry_charge_damage_plus": {
        "name": "受到的骑枪冲刺/长矛架枪伤害",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 400,
    },
    "base_strength_plus": {
        "name": "力量",
        "unit": "",
        "prefix": "+",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 430,
    },
    "base_agile_plus": {
        "name": "技巧",
        "unit": "",
        "prefix": "+",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 410,
    },
    "melee_attack_range_plus": {
        "name": "近战武器攻击范围",
        "unit": "",
        "prefix": "+",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 210,
    },
    "bow_lethal_strike_5000_rate": {
        "name": "使用弓箭命中敌人时, 有概率对敌人造成5000点伤害, 概率为",
        "unit": "%",
        "prefix": "",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 210,
    },
    "on_kill_atk_boost_30s": {
        "name": "击杀敌人后, 30秒内攻击力增加(可叠加)",
        "unit": "%",
        "prefix": "",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 800,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.PLUS_ATK,
        "buff_props": {
            "time_left_seconds": 30,
            "allow_repeat": true,
        },
    },
    "splash_damage": {
        "name": "范围溅射伤害: 以攻击距离150%为半径的半圆内, 50%范围内造成100%溅射, 100%范围内造成55%溅射, 150%范围内造成25%溅射",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 820,
    },
    "iai_cut": {
        "name": "居合斩: 每次出刀皆为居合, 人随刀走斩穿一线之敌; 平时为小居合快速连斩, 居合就绪时化为大居合, 疾掠更远, 刀光更甚",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 830,
    },
    "iai_cut_dash": {
        "name": "大居合突进距离",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 831,
    },
    "iai_cut_cd": {
        "name": "大居合冷却时间",
        "unit": "s",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 832,
    },
    "melee_stun_second_plus": {
        "name": "近战武器击晕时间延长",
        "unit": "s",
        "prefix": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 200,
    },
    "melee_damage_to_stunned_target_plus": {
        "name": "近战武器对眩晕敌人伤害增加",
        "unit": "%",
        "prefix": "",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },
    "melee_stun_prop_plus": {
        "name": "近战武器击晕概率增加(武器击晕概率必须大于0才能生效)",
        "unit": "%",
        "prefix": "",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 200,
    },
    "bow_crossbow_shot_accuracy": {
        "name": "弓/弩射击精度",
        "prefix": "+",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 800,
    },
    "armor_pen_5_seconds_rate": {
        "name": "攻击时有概率使目标进入破甲状态(装备防御变为0, 不包括盾牌), 持续5秒, 概率为",
        "unit": "%",
        "prefix": "",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 810,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.ARMOR_OPEN,
        "buff_props": {
            "time_left_seconds": 5,
            "allow_repeat": false,
        },
    },
    "disable_back_equip": {
        "name": "无法作为背盾",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 200,
    },
    "attack_ignore_def_by_practise_0_5": {
        "name": "造成的伤害无视敌人n点防御值, n = 对应武器熟练度 * 0.5",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.NONE,
        "s_priority": 200,
    },
    "practise_mobile": {
        "name": "骑射熟练度",
        "prefix": "+",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 800,
    },
    "practise_oh_sword": {
        "name": "单手剑熟练度",
        "prefix": "+",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 800,
    },
    "practise_oh_axe": {
        "name": "单手斧熟练度",
        "prefix": "+",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 800,
    },
    "practise_oh_pole": {
        "name": "单手长杆熟练度",
        "prefix": "+",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 800,
    },
    "practise_oh_blunt": {
        "name": "单手钝器熟练度",
        "prefix": "+",
        "unit": "",
        "c_type": COMPUTE_TYPE_ENUM.INTEGER,
        "s_priority": 800,
    },
    "kill_guaranteed_melee_hit_seconds": {
        "name": "击杀敌人后, 近战攻击命中率变为100%, 持续",
        "prefix": "",
        "unit": "秒",
        "c_type": COMPUTE_TYPE_ENUM.NORMAL,
        "s_priority": 800,
        "buff_type_enum": SoldierBuffConstants.BUFF_TYPE_ENUM.MELEE_PERFECT_HIT,
    },
    "buff_duration_bonus_rate": {
        "name": "作用于自身的增益类buff持续时间增加",
        "prefix": "",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 800,
    },
    "one_hand_no_shield_atk_speed_bonus": {
        "name": "没有手持盾牌时, 攻速增加",
        "prefix": "",
        "unit": "%",
        "c_type": COMPUTE_TYPE_ENUM.PERCENT,
        "s_priority": 800,
    }
}


const PANIC_BUFF_MELEE_ATTACK_ON_INFANTRY_ATTACK_REDUCTION_RATIO: = 0.2

const PANIC_BUFF_MELEE_ATTACK_ON_INFANTRY_TIME_LEFT_SECONDS: = 5.0



const PANIC_BUFF_CAMEL_MELEE_ATTACK_ON_INFANTRY_ATTACK_REDUCTION_RATIO: = 0.1

const PANIC_BUFF_CAMEL_MELEE_ATTACK_ON_INFANTRY_TIME_LEFT_SECONDS: = 5.0

const PANIC_BUFF_WEAPON_SMALL_TO_CAVALRY_ATTACK_REDUCTION_RATIO: = 0.1

const PANIC_BUFF_WEAPON_SMALL_TO_CAVALRY_TIME_LEFT_SECONDS: = 5.0

const PANIC_BUFF_WEAPON_BIG_TO_CAVALRY_ATTACK_REDUCTION_RATIO: = 0.3

const PANIC_BUFF_WEAPON_BIG_TO_CAVALRY_TIME_LEFT_SECONDS: = 5.0

enum COMPUTE_TYPE_ENUM {

    NORMAL,

    INTEGER,

    PERCENT,
    ENUM,

    NONE,
    BOOL,

    FUNCTION
}

const MEDICINE_EFFECT_TYPE_DIC = {
    MEDICINE_EFFECT_TYPE_ENUM.ACESODYNE: {
        "name": "止痛"
    }
}


enum MEDICINE_EFFECT_TYPE_ENUM {
    ACESODYNE
}


const WEAPON_SPECIAL_ATTR_LIST = [

    "attack_bonus_shield",

    "attack_bonus_cavalvy",

    "knock_back",

    "infantry_pause",

    "change_melee_weapon_distance_square",

    "take_out_priority",

    "prevent_lance_sprint_prob",

    "cavalvy_forbid",

    "infantry_forbid",

    "remote_attack_on_the_ground",
    "placement_time",
    "stun_prop",
    "stun_second",

    "lance_break_prob",

    "lance_cd",
    "capture_prob",
    "attack_speed_plus",
    "shield_pierce",
    "remark",

    "set_pike",

    "skin",

    "interrupt",

    "remote_hurt_plus",

    "weight_attack_speed_debuff_double",

    "horse_power_1",
    "carrying_capacity_remark",





    "speed_damage",
    "horse_armour",
    "camel_armour",
    "lance_forbid",

    "cavalry_charge_damage_plus",

    "desert_resistance",
    "attack_damage_plus_oh_throw",
    "attack_speed_plus_th_bow",
    "light_speed",
    "attack_damage_plus_th_melee",

    "ignores_strength_bonus_atk",
    "is_close_range_accurate",
    "panic_buff_melee_attack_on_infantry",
    "panic_buff_camel_melee_attack",
    "panic_buff_weapon_small_to_cavalry",
    "panic_buff_weapon_big_to_cavalry",
    "shield_break_ratio",
    "infantry_speed_plus",
    "base_physical_plus",
    "attack_damage_plus_oh_melee",
    "th_crossbow_plus_crit_prob_ratio",
    "th_bow_attack_plus_ratio",
    "th_bow_plus_crit_prob_ratio",
    "attack_speed_plus_th_crossbow",
    "attack_speed_plus_oh_weapon",
    "attack_speed_plus_oh_melee",

    "attack_speed_plus_th_melee",
    "base_strength_plus",
    "base_agile_plus",
    "melee_attack_range_plus",
    "bow_lethal_strike_5000_rate",
    "on_kill_atk_boost_30s",
    "melee_stun_second_plus",
    "melee_damage_to_stunned_target_plus",
    "melee_stun_prop_plus",
    "bow_crossbow_shot_accuracy",
    "armor_pen_5_seconds_rate",
    "disable_back_equip",
    "attack_ignore_def_by_practise_0_5",
    "practise_mobile",
    "practise_oh_sword",
    "practise_oh_axe",
    "practise_oh_pole",
    "practise_oh_blunt",
    "kill_guaranteed_melee_hit_seconds",
    "buff_duration_bonus_rate",
    "one_hand_no_shield_atk_speed_bonus",
    "splash_damage",
    "iai_cut",
    "iai_cut_dash",
    "iai_cut_cd",
]


enum EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM {
    LEFT_GOODS,
    RIGHT_GOODS,
    MID_GOODS,

    LEFT_GOODS_LOCK,
}


enum GOODS_ORIGIN_ENUM {
    LEFT_GOODS,
    RIGHT_GOODS
}


const STAR_EFFECT_MIN_STAR = 4


enum MOUNT_TYPE_ENUM {

    HORSE,

    CAMEL,

    NONE
}


const ROAO_HORSE_LIST = [
    "horse_0007", "horse_0008", "horse_0009", "horse_0010",
    "horse_0011", "horse_0012", "horse_0013", "horse_0014",
    "horse_0015"
]


const SAINA_HORSE_LIST = [
    "horse_0001", "horse_0002", "horse_0003", "horse_0004",
    "horse_0005", "horse_0006"
]

const ROAO_AND_SAINA_HORSE_LIST = [
    "horse_0001", "horse_0002", "horse_0003", "horse_0004",
    "horse_0005", "horse_0006", "horse_0007", "horse_0008",
    "horse_0009", "horse_0010", "horse_0011", "horse_0012",
    "horse_0013", "horse_0014", "horse_0015"
]


const STEPPE_HORSE_LIST = [
    "horse_0026", "horse_0027", "horse_0028", "horse_0029",
    "horse_0030", "horse_0031", "horse_0032", "horse_0033",
]


const CAMEL_LIST = [
    "horse_0016", "horse_0017", "horse_0018", "horse_0019",
    "horse_0020", "horse_0021", "horse_0022",
    "horse_0023", "horse_0024", "horse_0025"
]


const FORGOTTEN_WATER_UID: = "commodity_0032"