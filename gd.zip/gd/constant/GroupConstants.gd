class_name GroupConstants

const GROUP_ICON_CONFIG = {
    "default": {
        "path": "res://resource/icon/groupCardIcon/default.png"
    },
    "horse_0001": {
        "path": "res://resource/icon/groupCardIcon/horse.png"
    },
    "oh_axe_0001": {
        "path": "res://resource/icon/groupCardIcon/oh_axe.png"
    },
    "th_axe_0001": {
        "path": "res://resource/icon/groupCardIcon/th_axe.png"
    },
    "oh_sword_0001": {
        "path": "res://resource/icon/groupCardIcon/oh_sword.png"
    },
    "th_sword_0001": {
        "path": "res://resource/icon/groupCardIcon/th_sword.png"
    },
    "oh_pole_0001": {
        "path": "res://resource/icon/groupCardIcon/oh_pole.png"
    },
    "th_pole_0001": {
        "path": "res://resource/icon/groupCardIcon/th_pole.png"
    },
    "th_bow_0001": {
        "path": "res://resource/icon/groupCardIcon/th_bow.png"
    },
    "th_crossbow_0001": {
        "path": "res://resource/icon/groupCardIcon/th_crossbow.png"
    },
    "oh_shield_0001": {
        "path": "res://resource/icon/groupCardIcon/oh_shield.png"
    },
    "hshield_0001": {
        "path": "res://resource/icon/groupCardIcon/hshield.png"
    },

    "oh_blunt_0001": {
        "path": "res://resource/icon/groupCardIcon/oh_blunt.png"
    },

    "th_firearm_0001": {
        "path": "res://resource/icon/groupCardIcon/th_firearm.png"
    },

    "camel_0001": {
        "path": "res://resource/icon/groupCardIcon/group_icon_camel.png"
    }
}

const GROUP_ICON_BACKGROUND_COLOR_LIST = [

    Color(0.95, 0.42, 0.37, 1),

    Color(0.74, 0.74, 0.74, 1),

    Color(0.94, 0.38, 0.57, 1),

    Color(0.72, 0.4, 0.78, 1),

    Color(0.58, 0.45, 0.8, 1),

    Color(0.3, 0.76, 0.96, 1),

    Color(0.3, 0.71, 0.67, 1),

    Color(0.68, 0.83, 0.5, 1),

    Color(1.0, 0.93, 0.34, 1),

    Color(1.0, 0.65, 0.14, 1),

    Color(0.55, 0.43, 0.38, 1),

    Color(0.47, 0.56, 0.61, 1),
]