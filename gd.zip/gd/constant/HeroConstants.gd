class_name HeroConstants



const WARLIKE_LEVEL_ENUM = {

    AVOIDANT = -2,

    CAUTIOUS = -1,

    BALANCED = 0,

    AGGRESSIVE = 1,

    BELLIGERENT = 2
}



const INTEGRITY_LEVEL_ENUM = {

    BRUTAL = -2,

    PETTY = -1,

    NEUTRAL = 0,

    RIGHTEOUS = 1,

    NOBLE = 2,
}



const CAUTION_LEVEL_ENUM = {

    CAUTIOUS = -1,

    NEUTRAL = 0,

    RECKLESS = 1
}


const LORD_DECISION_AI_TYPE_ENUM = {

    REPLENISH_TROOPS = "REPLENISH_TROOPS",

    PATROL = "PATROL",

    FOLLOW_PLAYER = "FOLLOW_PLAYER",

    NONE = "NONE",
}

const LORD_DATA_LIVING_STATUS_ENUM = {
    ACTIVE = "ACTIVE",

    DEFEATED = "DEFEATED"
}