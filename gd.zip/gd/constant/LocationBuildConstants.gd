class_name LocationBuildConstants

const BUILD_CONFIG: = {
    BUILD_CODE_ENUM.BARRACKS: {
        "name": "驻军点(大)",

        "system_remark": "兵营(大)",
        "icon_path": "res://resource/icon/buildIcon/build_barracks_big_icon.png",
        "ideal_skill": {
            "skill_engineer": 0.7,
            "skill_manage": 0.3,
        },
        "value_base": 90,
        "value_level_plus": 50,

        "build_spend_days": 30,
        "build_spend_money_base": 12000,
        "build_spend_money_level_plus": 1500,

        "upgrade_spend_days": 15,

        "upgrade_spend_money_level_plus": 2000,


        "effect_description": "可容纳 #{value} 名士兵",
        "description": "一个设施齐全的兵营, 可作为士兵的驻扎点, 可随时补充和调度兵力资源",

        "slot_type": BUILD_SLOT_TYPE_ENUM.BIG_SLOT,
    },
    BUILD_CODE_ENUM.BARRACKS_SMALL: {
        "name": "驻军点(小)",

        "system_remark": "兵营(小)",
        "icon_path": "res://resource/icon/buildIcon/build_barracks_icon.png",
        "ideal_skill": {
            "skill_engineer": 0.7,
            "skill_manage": 0.3,
        },
        "value_base": 50,
        "value_level_plus": 30,

        "build_spend_days": 20,
        "build_spend_money_base": 7000,
        "build_spend_money_level_plus": 1000,

        "upgrade_spend_days": 10,

        "upgrade_spend_money_level_plus": 1200,



        "effect_description": "可容纳 #{value} 名士兵",
        "description": "一个设施齐全的小型兵营, 可作为士兵的驻扎点, 可随时补充和调度兵力资源",

        "slot_type": BUILD_SLOT_TYPE_ENUM.SMALL_SLOT,
    },
    BUILD_CODE_ENUM.WAREHOUSE: {
        "name": "仓库(大)",

        "system_remark": "仓库(大)",
        "icon_path": "res://resource/icon/buildIcon/build_warehouse_big_icon.png",
        "ideal_skill": {
            "skill_engineer": 1.0,
        },
        "value_base": 140,
        "value_level_plus": 50,

        "build_spend_days": 30,
        "build_spend_money_base": 8000,
        "build_spend_money_level_plus": 1000,

        "upgrade_spend_days": 15,

        "upgrade_spend_money_level_plus": 1200,
        "effect_description": "可放置 #{value} 件物品",
        "description": "一个用于储存物资与装备的大型仓库",

        "slot_type": BUILD_SLOT_TYPE_ENUM.BIG_SLOT,
    },
    BUILD_CODE_ENUM.WAREHOUSE_SMALL: {
        "name": "仓库(小)",

        "system_remark": "仓库(小)",
        "icon_path": "res://resource/icon/buildIcon/build_warehouse_small_icon.png",
        "ideal_skill": {
            "skill_engineer": 1.0,
        },
        "value_base": 70,
        "value_level_plus": 30,

        "build_spend_days": 20,
        "build_spend_money_base": 5000,
        "build_spend_money_level_plus": 600,

        "upgrade_spend_days": 10,

        "upgrade_spend_money_level_plus": 800,
        "effect_description": "可放置 #{value} 件物品",
        "description": "一个用于储存物资与装备的小型仓库",

        "slot_type": BUILD_SLOT_TYPE_ENUM.SMALL_SLOT,
    },

    BUILD_CODE_ENUM.PRISON: {
        "name": "监狱(大)",

        "system_remark": "监狱(大)",
        "icon_path": "res://resource/icon/buildIcon/build_barracks_big_icon.png",
        "ideal_skill": {
            "skill_engineer": 0.7,
            "skill_manage": 0.3,
        },
        "value_base": 135,
        "value_level_plus": 75,

        "build_spend_days": 30,
        "build_spend_money_base": 12000,
        "build_spend_money_level_plus": 1500,

        "upgrade_spend_days": 15,

        "upgrade_spend_money_level_plus": 2000,


        "effect_description": "可关押 #{value} 名俘虏",
        "description": "一个设施齐全的大型监狱, 可用于关押俘虏, 防止俘虏逃跑",

        "slot_type": BUILD_SLOT_TYPE_ENUM.BIG_SLOT,
    },

    BUILD_CODE_ENUM.PRISON_SMALL: {
        "name": "监狱(小)",

        "system_remark": "监狱(小)",
        "icon_path": "res://resource/icon/buildIcon/build_barracks_icon.png",
        "ideal_skill": {
            "skill_engineer": 0.7,
            "skill_manage": 0.3,
        },
        "value_base": 75,
        "value_level_plus": 45,

        "build_spend_days": 20,
        "build_spend_money_base": 7000,
        "build_spend_money_level_plus": 1000,

        "upgrade_spend_days": 10,

        "upgrade_spend_money_level_plus": 1200,


        "effect_description": "可关押 #{value} 名俘虏",
        "description": "一个设施齐全的小型监狱, 可用于关押俘虏, 防止俘虏逃跑",

        "slot_type": BUILD_SLOT_TYPE_ENUM.SMALL_SLOT,
    },


    BUILD_CODE_ENUM.MINT: {
        "name": "铸钱厂(大)",

        "system_remark": "铸钱厂(大)",
        "icon_path": "res://resource/icon/buildIcon/mod_mint_big_icon.png",
        "ideal_skill": {
            "skill_engineer": 0.4,
            "skill_manage": 0.6,
        },
        "value_base": 60,
        "value_level_plus": 28,

        "build_spend_days": 30,
        "build_spend_money_base": 12000,
        "build_spend_money_level_plus": 1500,

        "upgrade_spend_days": 15,

        "upgrade_spend_money_level_plus": 2000,


        "effect_description": "2个熔炼槽·白框容量 #{value}",
        "description": "一座大型铸钱工坊, 可将矿石熔铸为钱币, 是领地的重要财源",

        "slot_type": BUILD_SLOT_TYPE_ENUM.BIG_SLOT,
    },


    BUILD_CODE_ENUM.MINT_SMALL: {
        "name": "铸钱厂(小)",

        "system_remark": "铸钱厂(小)",
        "icon_path": "res://resource/icon/buildIcon/mod_mint_icon.png",
        "ideal_skill": {
            "skill_engineer": 0.4,
            "skill_manage": 0.6,
        },
        "value_base": 60,
        "value_level_plus": 20,

        "build_spend_days": 20,
        "build_spend_money_base": 7000,
        "build_spend_money_level_plus": 1000,

        "upgrade_spend_days": 10,

        "upgrade_spend_money_level_plus": 1200,


        "effect_description": "2个熔炼槽·白框容量 #{value}",
        "description": "一座小型铸钱工坊, 可将矿石熔铸为钱币, 是领地的重要财源",

        "slot_type": BUILD_SLOT_TYPE_ENUM.SMALL_SLOT,
    },
}

const BUILD_CODE_ENUM = {

    BARRACKS = "BARRACKS",
    BARRACKS_SMALL = "BARRACKS_SMALL",

    WAREHOUSE = "WAREHOUSE",
    WAREHOUSE_SMALL = "WAREHOUSE_SMALL",

    PRISON = "PRISON",
    PRISON_SMALL = "PRISON_SMALL",

    MINT = "MINT",
    MINT_SMALL = "MINT_SMALL",
}


const BARRACKS_CODE_LIST = [BUILD_CODE_ENUM.BARRACKS, BUILD_CODE_ENUM.BARRACKS_SMALL]


const PRISON_CODE_LIST = [BUILD_CODE_ENUM.PRISON, BUILD_CODE_ENUM.PRISON_SMALL]


const MINT_CODE_LIST = [BUILD_CODE_ENUM.MINT, BUILD_CODE_ENUM.MINT_SMALL]


const MOD_SPECIAL_CODE_LIST = [BUILD_CODE_ENUM.PRISON, BUILD_CODE_ENUM.PRISON_SMALL, BUILD_CODE_ENUM.MINT, BUILD_CODE_ENUM.MINT_SMALL]



const BUILD_SLOT_TYPE_ENUM = {

    BIG_SLOT = "BIG_SLOT",

    SMALL_SLOT = "SMALL_SLOT"
}

const BUILD_SLOT_TYPE_CONFIG = {
    BUILD_SLOT_TYPE_ENUM.BIG_SLOT: {
        "name": "大型栏位",
    },
    BUILD_SLOT_TYPE_ENUM.SMALL_SLOT: {
        "name": "小型栏位",
    },
}

enum BUILD_STATUS_ENUM {
    EMPTY,

    BUILDING,

    FINISH,

    UPGRADE,
}

enum BUILD_MODE_ENUM {
    BUILD,
    UPGRADE,
}

static func get_build_config(_build_code: String)-> Dictionary:
    return BUILD_CONFIG.get(_build_code)

static func get_slot_type_name(_slot_type: String)-> String:
    return BUILD_SLOT_TYPE_CONFIG.get(_slot_type).name

static func get_build_name(_build_code: String)-> String:
    return BUILD_CONFIG.get(_build_code).name