class_name LocationConstants


enum LOCATION_CARD_STYLE_TYPE_ENUM {

    SHOP,

    FUNC,

    SPECIAL
}


const CITY_LOCATION_TYPE_ENUM = {

    SMITHY = "Smithy",

    PIAZZA = "Piazza",

    GROCERY = "Grocery",

    ARMOUR = "Armour",

    HORSE = "Horse",

    HOTEL = "Hotel",

    TAVERN = "Tavern",

    BARRACKS = "Barracks",

    WAREHOUSE = "Warehouse",

    MOD_VILLAGE_HALL = "ModVillageHall",

    MOD_ARMORY = "ModArmory",

    PRISON = "Prison",

    MINT = "Mint",
}

const CITY_LOCATION_TYPE_CONFIG = {
    "Castle": {
        "icon": "res://resource/icon/locationButtonIcon/castle_icon.png",
        "big_icon": "",
        "button_name": "城堡",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.FUNC
    },
    "Smithy": {
        "icon": "res://resource/icon/locationButtonIcon/weapon_shop_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/weapon_shop_icon.png",
        "button_name": "武器铺",

        "sell_etype": [
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON,
        ],
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SHOP
    },
    "Armour": {
        "icon": "res://resource/icon/locationButtonIcon/armour_shop_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/armour_shop_icon.png",
        "button_name": "防具店",

        "sell_etype": [
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET,
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER,
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR,
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE,
        ],
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SHOP
    },
    "Grocery": {
        "icon": "res://resource/icon/locationButtonIcon/grocery_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/grocery_shop_icon.png",
        "button_name": "杂货铺",
        "sell_etype": [WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.FOOD, WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.COMMODITY],
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SHOP
    },
    "Horse": {
        "icon": "res://resource/icon/locationButtonIcon/horse_shop_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/horse_shop_icon.png",
        "button_name": "马市",
        "sell_etype": [
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HORSE,
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HARMOUR,
            WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.CARRIAGE,
        ],
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SHOP
    },
    "Tavern": {
        "icon": "res://resource/icon/locationButtonIcon/tavern_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/tavern_icon.png",
        "button_name": "酒馆",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.FUNC,
    },
    "Hotel": {
        "icon": "res://resource/icon/locationButtonIcon/hotel_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/camping_icon.png",
        "button_name": "休息",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.FUNC
    },
    "Piazza": {
        "icon": "res://resource/icon/locationButtonIcon/piazza_icon.png",
        "big_icon": "res://resource/icon/locationButtonIcon/big/piazza_icon.png",
        "button_name": "广场",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.FUNC
    },

    CITY_LOCATION_TYPE_ENUM.BARRACKS: {
        "icon": "res://resource/icon/locationButtonIcon/barracks_icon.png",
        "big_icon": "",
        "button_name": "驻军点",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SPECIAL
    },

    CITY_LOCATION_TYPE_ENUM.WAREHOUSE: {
        "icon": "res://resource/icon/locationButtonIcon/warehouse_icon.png",
        "big_icon": "",
        "button_name": "仓库",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SPECIAL
    },

    CITY_LOCATION_TYPE_ENUM.MOD_VILLAGE_HALL: {
        "icon": "res://resource/icon/locationButtonIcon/weapon_shop_icon.png",
        "big_icon": "",
        "button_name": "铁匠铺",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.FUNC
    },

    CITY_LOCATION_TYPE_ENUM.MOD_ARMORY: {
        "icon": "res://resource/icon/locationButtonIcon/piazza_icon.png",
        "big_icon": "",
        "button_name": "军械场",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.FUNC
    },


    CITY_LOCATION_TYPE_ENUM.PRISON: {
        "icon": "res://resource/icon/locationButtonIcon/barracks_icon.png",
        "big_icon": "",
        "button_name": "监狱",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SPECIAL
    },


    CITY_LOCATION_TYPE_ENUM.MINT: {
        "icon": "res://resource/icon/locationButtonIcon/mod_mint_icon.png",
        "big_icon": "",
        "button_name": "铸钱厂",
        "button_style_type": LOCATION_CARD_STYLE_TYPE_ENUM.SPECIAL
    },
}

const LOCATION_TYPE_ENUM = {
    CITY = "CITY",
    CASTLE = "CASTLE",
    VILLAGE = "VILLAGE",

    SPECIAL_LOCATION = "SPECIAL_LOCATION"
}

const SHOP_MONEY_FIELD_LIST: = [
    "money_smithy", "money_grocery",
    "money_armour", "money_horse"
]


const NPC_FUNC_TYPE_ENUM = {

    MERCENARY = "MERCENARY"
}

static func get_sell_etype(_location_type_enum: String)-> Array:
    var _info = get_city_location_type_config(_location_type_enum)
    if not _info.has("sell_etype"):
        return[]
    else:
        return _info.sell_etype

static func get_city_location_type_config(_location_type: String)-> Dictionary:
    return CITY_LOCATION_TYPE_CONFIG.get(_location_type)

static func get_city_location_type_enum(_etype: String)-> String:
    for _key: String in CITY_LOCATION_TYPE_CONFIG.keys():
        var _config: Dictionary = CITY_LOCATION_TYPE_CONFIG.get(_key)
        if _config.has("sell_etype") and _config.sell_etype.has(_etype):
            return _key

    return ""