class_name LordConstants


enum MEET_LORD_TYPE_ENUM {

    MEET_BY_ATTENDANT,

    MEET_PERSONALLY,
}