class_name MWTeamConstants

enum MW_TEAM_ACTION_STATUS_ENUM {

    MOVE,

    IDLE,

    ATTACK,

    DELETE,

    ACROSS_GATE,

    LOCATION_STAY,

    THINKING,

    TRADE,

    TRADE_SETTLEMENT,

    LOCATION_STAY_SUB_ENTER,

    LOCATION_STAY_SUB_IN,

    LOCATION_STAY_SUB_EXIT,

    LOCATION_STAY_SUB_TRADE,

    LOCATION_STAY_SUB_TRADE_SETTLEMENT,

    LOCATION_STAY_SUB_THINKING,

    LOCATION_STAY_SUB_DELETE,

    LOCATION_STAY_SUB_NPC_REPLENISH,

    LOCATION_OUTSIDE_REPLENISH,

    TRAIN
}



enum TEAM_ROLE_ENUM {

    VILLAGER,

    ROBBER,

    RONIN,

    MERCHANT_CONVOY,

    LORD,


    IMPERIAL_UNION,
}


enum TEAM_REL_TYPE_ENUM {

    HOSTILE,

    NEUTRAL,

    ALLIED
}


const TEAM_ROLE_REL_INFO = {
    TEAM_ROLE_ENUM.ROBBER: {
        TEAM_ROLE_ENUM.VILLAGER: {
            "rel": -100,

            "is_danger": false,
        },
        TEAM_ROLE_ENUM.RONIN: {
            "rel": -100
        },
        TEAM_ROLE_ENUM.LORD: {
            "rel": -100
        },

        TEAM_ROLE_ENUM.MERCHANT_CONVOY: {
            "rel": -100,

            "is_danger": false,
        },

        TEAM_ROLE_ENUM.IMPERIAL_UNION: {
            "rel": -100
        },
    },
    TEAM_ROLE_ENUM.VILLAGER: {
        TEAM_ROLE_ENUM.ROBBER: {
            "rel": -100
        },

        TEAM_ROLE_ENUM.IMPERIAL_UNION: {
            "rel": 0
        },
    },

    TEAM_ROLE_ENUM.RONIN: {
        TEAM_ROLE_ENUM.ROBBER: {
            "rel": -100
        },

        TEAM_ROLE_ENUM.IMPERIAL_UNION: {
            "rel": -100
        },
    },
    TEAM_ROLE_ENUM.MERCHANT_CONVOY: {
        TEAM_ROLE_ENUM.ROBBER: {
            "rel": -100
        },

        TEAM_ROLE_ENUM.IMPERIAL_UNION: {
            "rel": 0
        },
    },
    TEAM_ROLE_ENUM.LORD: {
        TEAM_ROLE_ENUM.ROBBER: {
            "rel": -100
        },

        TEAM_ROLE_ENUM.IMPERIAL_UNION: {
            "rel": 0
        },
    },

    TEAM_ROLE_ENUM.IMPERIAL_UNION: {
        TEAM_ROLE_ENUM.ROBBER: {
            "rel": -100,
            "is_danger": true,
        },
        TEAM_ROLE_ENUM.VILLAGER: {
            "rel": 0,
        },
        TEAM_ROLE_ENUM.LORD: {
            "rel": 0,
        },
        TEAM_ROLE_ENUM.MERCHANT_CONVOY: {
            "rel": 0,
        },
        TEAM_ROLE_ENUM.RONIN: {
            "rel": -100,
        },
    },
}

enum MOVE_TYPE_ENUM {

    NONE,

    FIXED,

    DYNAMIC,

    LOCATION,

    FLEE,

    PURSUE,
}

enum LIVING_STATUS_ENUM {

    ACTIVE,

    DEATH
}

enum STATUS_ICON_TYPE_ENUM {
    REST,
    BATTLE,
    MOVE,
    NONE,
    TRAIN
}


const BATTLE_TEAM_TYPE_ENUM = {
    TEAM1 = "team1",
    TEAM2 = "team2"
}



const TEAM_SMALL_TYPE_ENUM = {

    ROBBER = "ROBBER",

    FOREST_BANDIT = "FOREST_BANDIT",

    PIRATE = "PIRATE",

    MARKA_CRIMSON_WARBAND = "MARKA_CRIMSON_WARBAND",

    DESERT_BANDITS = "DESERT_BANDITS",

    ROAO_VILLAGER = "ROAO_VILLAGER",

    SAINA_VILLAGER = "SAINA_VILLAGER",

    MARKA_VILLAGER = "MARKA_VILLAGER",

    SHALUK_VILLAGER = "SHALUK_VILLAGER",

    MERCHANT_CONVOY = "MERCHANT_CONVOY",

    DESERT_CARAVAN = "DESERT_CARAVAN",

    LUCIANA_LORD = "LUCIANA_LORD",

    EDRAS_LORD = "EDRAS_LORD",
    DORDAR_LORD = "DORDAR_LORD",
    HASKAL_LORD = "HASKAL_LORD",
    COMMON_LORD = "COMMON_LORD",

    EVIL_EAGLE_MERCENARY = "EVIL_EAGLE_MERCENARY",

    SCORCHING_SOUL_SECT = "SCORCHING_SOUL_SECT",

    CALANT_EXILES = "CALANT_EXILES",


    IMPERIAL_UNION_ARMY = "IMPERIAL_UNION_ARMY",

    NEUTRAL_NUN = "NEUTRAL_NUN",


    BLACK_MOON_PAPACY = "BLACK_MOON_PAPACY",


    SLAVE_DUEL_HOST = "SLAVE_DUEL_HOST",


    BUXIAO = "BUXIAO",
}



const MONEY_FACTOR: = 1.0

const TEAM_SMALL_TYPE_CONFIG = {

    TEAM_SMALL_TYPE_ENUM.ROBBER: {
        "soldier_list": ["wild_soldier_0001", "wild_soldier_0002", "wild_soldier_0003"],
        "current_food_morale_config": [2, 10],
        "food_stock_factor": [2.0, 4.0],

        "money_factor": [5 * MONEY_FACTOR, 15 * MONEY_FACTOR],

        "food_config": {
            "food_0001": 200,
            "food_0002": 50,
            "food_0004": 50,
            "food_0009": 20,
            "food_0010": 20,
            "food_0011": 50,
            "food_0012": 50,
            "food_0008": 5
        },
        "info_color": Color(0.5, 0.5, 0.5, 1),
    },

    TEAM_SMALL_TYPE_ENUM.FOREST_BANDIT: {
        "soldier_list": ["wild_soldier_0004", "wild_soldier_0005", "wild_soldier_0006"],
        "current_food_morale_config": [5, 15],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [5 * MONEY_FACTOR, 15 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 200,
            "food_0002": 50,
            "food_0004": 50,
            "food_0009": 20,
            "food_0010": 20,
            "food_0011": 50,
            "food_0012": 50,
            "food_0008": 5
        },
        "info_color": Color(0.13, 0.55, 0.13, 1),
    },

    TEAM_SMALL_TYPE_ENUM.PIRATE: {
        "soldier_list": ["wild_soldier_0007", "wild_soldier_0008", "wild_soldier_0009_02", "wild_soldier_0009"],
        "current_food_morale_config": [10, 20],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0002": 50,
            "food_0004": 50,
            "food_0005": 50,
            "food_0010": 50,
            "food_0012": 80,
            "food_0007": 30,
            "food_0008": 5
        },
        "info_color": Color(0.25, 0.25, 0.75, 1)
    },

    TEAM_SMALL_TYPE_ENUM.MARKA_CRIMSON_WARBAND: {
        "soldier_list": ["wild_soldier_0017", "wild_soldier_0018", "wild_soldier_0019"],
        "current_food_morale_config": [10, 15],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0002": 50,
            "food_0017": 30,
            "food_0018": 50,
            "food_0019": 100,
            "food_0020": 100,
        },
        "info_color": Color(0.55, 0.35, 0.05, 1)
    },

    TEAM_SMALL_TYPE_ENUM.DESERT_BANDITS: {
        "soldier_list": ["wild_soldier_0020", "wild_soldier_0021", "wild_soldier_0022"],
        "current_food_morale_config": [10, 15],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0021": 150,
            "food_0022": 80,
            "food_0023": 30,
            "food_0024": 150,
        },
        "info_color": Color(0.72, 0.53, 0.04, 1)
    },

    TEAM_SMALL_TYPE_ENUM.EVIL_EAGLE_MERCENARY: {
        "team_name": "雄鹰劫掠者",
        "soldier_list": ["wild_soldier_0030", "wild_soldier_0031"],
        "current_food_morale_config": [10, 20],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 25.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0002": 50,
            "food_0004": 50,
            "food_0007": 50,
            "food_0011": 50,
            "food_0015": 50,
            "food_0008": 50,
        },

        "info_color": Color("#7A1818")
    },

    TEAM_SMALL_TYPE_ENUM.SCORCHING_SOUL_SECT: {
        "team_name": "烙魂教",
        "soldier_list": ["wild_soldier_0028", "wild_soldier_0029"],
        "current_food_morale_config": [10, 20],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0002": 50,
            "food_0006": 50,
            "food_0011": 50,
            "food_0012": 50,
            "food_0015": 50,
            "food_0027": 50,
        },

        "info_color": Color("#68241C")
    },

    TEAM_SMALL_TYPE_ENUM.CALANT_EXILES: {
        "team_name": "卡兰特流放者",
        "soldier_list": ["wild_soldier_0035", "wild_soldier_0036"],
        "current_food_morale_config": [10, 20],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 20.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0002": 100,
            "food_0005": 50,
            "food_0006": 50,
            "food_0025": 100,
            "food_0026": 100,
        },

        "info_color": Color("#582020")
    },

    TEAM_SMALL_TYPE_ENUM.ROAO_VILLAGER: {
        "soldier_list": ["regular_soldier_0001"],
        "current_food_morale_config": [2, 10],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [5.0 * MONEY_FACTOR, 10.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 200,
            "food_0002": 50,
            "food_0005": 50,
            "food_0009": 20,
            "food_0010": 20,
            "food_0011": 50,
            "food_0012": 20,
        }
    },

    TEAM_SMALL_TYPE_ENUM.SAINA_VILLAGER: {
        "soldier_list": ["regular_soldier_0002"],
        "current_food_morale_config": [2, 10],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [5.0 * MONEY_FACTOR, 10.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 200,
            "food_0002": 50,
            "food_0009": 20,
            "food_0010": 20,
            "food_0004": 20,
            "food_0011": 20,
            "food_0012": 50,
        }
    },

    TEAM_SMALL_TYPE_ENUM.MARKA_VILLAGER: {
        "soldier_list": ["regular_soldier_0020"],
        "current_food_morale_config": [2, 10],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [5.0 * MONEY_FACTOR, 10.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 200,
        }
    },

    TEAM_SMALL_TYPE_ENUM.SHALUK_VILLAGER: {
        "soldier_list": ["regular_soldier_0021"],
        "current_food_morale_config": [2, 10],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [5.0 * MONEY_FACTOR, 10.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 200,
        }
    },

    TEAM_SMALL_TYPE_ENUM.MERCHANT_CONVOY: {
        "soldier_list": ["wild_soldier_0010", "wild_soldier_0011", "wild_soldier_0012"],
        "current_food_morale_config": [15, 25],
        "food_stock_factor": [4.0, 6.0],
        "money_factor": [10.0 * MONEY_FACTOR, 20.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0002": 100,
            "food_0004": 50,
            "food_0005": 50,
            "food_0006": 5,
            "food_0007": 50,
            "food_0011": 50,
            "food_0012": 50,
        }
    },

    TEAM_SMALL_TYPE_ENUM.DESERT_CARAVAN: {
        "soldier_list": ["wild_soldier_0023", "wild_soldier_0024", "wild_soldier_0025", "wild_soldier_0009"],
        "current_food_morale_config": [15, 25],
        "food_stock_factor": [4.0, 6.0],
        "money_factor": [10.0 * MONEY_FACTOR, 20.0 * MONEY_FACTOR],
        "food_config": {
            "food_0021": 150,
            "food_0022": 80,
            "food_0023": 80,
            "food_0024": 150,
        }
    },
    TEAM_SMALL_TYPE_ENUM.LUCIANA_LORD: {


        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 220,
            "food_0002": 130,
            "food_0003": 60,
            "food_0007": 40,
            "food_0009": 30,
            "food_0010": 80,
            "food_0012": 140,
            "food_0013": 120,
            "food_0006": 150,
            "food_0008": 50,
        }
    },
    TEAM_SMALL_TYPE_ENUM.EDRAS_LORD: {


        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0007": 155,
            "food_0008": 110,
            "food_0009": 140,
            "food_0011": 145,
            "food_0001": 170,
            "food_0010": 50,
            "food_0003": 110,
            "food_0013": 50,
        }
    },
    TEAM_SMALL_TYPE_ENUM.DORDAR_LORD: {


        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 100,
            "food_0006": 50,
            "food_0007": 100,
            "food_0009": 80,
            "food_0017": 100,
            "food_0018": 100,
            "food_0019": 100,
            "food_0020": 80,
        }
    },
    TEAM_SMALL_TYPE_ENUM.HASKAL_LORD: {


        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0008": 50,
            "food_0016": 100,
            "food_0021": 100,
            "food_0022": 150,
            "food_0023": 100,
            "food_0024": 100,
        }
    },
    TEAM_SMALL_TYPE_ENUM.COMMON_LORD: {


        "food_stock_factor": [2.0, 4.0],
        "money_factor": [10.0 * MONEY_FACTOR, 15.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 220,
            "food_0002": 130,
            "food_0003": 60,
            "food_0007": 40,
            "food_0009": 30,
            "food_0010": 80,
            "food_0012": 140,
            "food_0013": 120,
            "food_0006": 150,
            "food_0008": 50,
        }
    },

    TEAM_SMALL_TYPE_ENUM.IMPERIAL_UNION_ARMY: {
        "team_name": "帝国联盟军",
        "soldier_list": [
            "regular_soldier_0014", "regular_soldier_0017", "regular_soldier_0018",
            "regular_soldier_0005_02", "regular_soldier_0007", "regular_soldier_0009_02",
            "regular_soldier_0027", "regular_soldier_0028", "regular_soldier_0029",
            "regular_soldier_0035", "regular_soldier_0036", "regular_soldier_0037",
        ],
        "current_food_morale_config": [15, 25],
        "food_stock_factor": [3.0, 5.0],
        "money_factor": [15.0 * MONEY_FACTOR, 25.0 * MONEY_FACTOR],
        "food_config": {
            "food_0001": 200,
            "food_0002": 100,
            "food_0004": 80,
            "food_0005": 50,
            "food_0007": 50,
            "food_0011": 50,
            "food_0012": 80,
        },
        "info_color": Color(0.6, 0.2, 0.8, 1),
    },

    TEAM_SMALL_TYPE_ENUM.NEUTRAL_NUN: {
        "team_name": "多明尼卡教·褐斯修女",
        "soldier_list": [],
        "current_food_morale_config": [10, 15],
        "food_stock_factor": [1.0, 2.0],
        "money_factor": [5.0 * MONEY_FACTOR, 10.0 * MONEY_FACTOR],
        "food_config": {"food_0001": 50},
        "info_color": Color(0.9, 0.85, 0.75, 1),
    },

    TEAM_SMALL_TYPE_ENUM.BLACK_MOON_PAPACY: {
        "team_name": "黑月教廷",
        "soldier_list": [],
        "current_food_morale_config": [15, 25],
        "food_stock_factor": [2.0, 4.0],
        "money_factor": [0.0, 0.0],
        "food_config": {"food_0021": 200, "food_0022": 100},
        "info_color": Color(0.1, 0.05, 0.15, 1),
    },

    TEAM_SMALL_TYPE_ENUM.SLAVE_DUEL_HOST: {
        "team_name": "斗奴主·薇拉",
        "soldier_list": [],
        "current_food_morale_config": [15, 25],
        "food_stock_factor": [1.0, 2.0],
        "money_factor": [5.0 * MONEY_FACTOR, 10.0 * MONEY_FACTOR],
        "food_config": {"food_0001": 50},
        "info_color": Color(0.85, 0.55, 0.25, 1),
    },

    TEAM_SMALL_TYPE_ENUM.BUXIAO: {
        "team_name": "不笑",
        "soldier_list": [],
        "current_food_morale_config": [15, 25],
        "food_stock_factor": [1.0, 2.0],
        "money_factor": [0.0, 0.0],
        "food_config": {"food_0001": 50},
        "info_color": Color(0.15, 0.15, 0.18, 1),
    },
}

const DANGER_CONFIG = {
    0.5: {
        "name": "没有威胁",
        "color": CommonConstants.COLOR_ENUM.GREY,
    },
    0.8: {
        "name": "轻度威胁",
        "color": CommonConstants.COLOR_ENUM.SHALLOW_WHITE,
    },
    1.2: {
        "name": "谨慎对待",
        "color": CommonConstants.COLOR_ENUM.BLUE,
    },
    2.0: {
        "name": "高度危险",
        "color": CommonConstants.COLOR_ENUM.VIOLET,
    },
    100.0: {
        "name": "极度危险",
        "color": CommonConstants.COLOR_ENUM.RED,
    }
}


enum LORD_PATROL_STRATEGY_ENUM {

    HOMELAND,

    FRONTLINE_OWN,

    FRONTLINE_ENEMY,
}


const TEAM_EVENT_LOG_FIELD_ENUM: = {

    LAST_MEET_TIME_COUNTER = "event_last_meet_time_counter",

    WAS_EXTORTED_BY_PLAYER = "event_was_extorted_by_player"
}

static func get_npc_random_morale(_config: Dictionary):
    return CommonUtils.random_num2(_config.current_food_morale_config[0], _config.current_food_morale_config[1])

static func get_npc_random_food_stock_value(_config: Dictionary, _nop: int)-> int:
    return int(_nop * CommonUtils.random_float(_config.food_stock_factor[0], _config.food_stock_factor[1]))

static func get_npc_random_food_stock_value2(_team_small_type: String, _nop: int)-> int:
    var _config: Dictionary = MWTeamConstants.TEAM_SMALL_TYPE_CONFIG.get(_team_small_type)
    return int(_nop * CommonUtils.random_float(_config.food_stock_factor[0], _config.food_stock_factor[1]))


static func get_random_money(_config: Dictionary, _nop: int)-> int:
    return int(_nop * CommonUtils.random_float(_config.money_factor[0], _config.money_factor[1]))







const ROBBER_FACTION_COLOR: = Color(0.8, 0.2, 0.2, 1)


const ROBBER_RELATION_INTERVAL: = [-100.0, 100.0]


const PLAYER_JOIN_ROBBER_REPUTATION_REQUIREMENT: = 100