class_name MWorldConstants


const VIEW_FOCUS_COLOR: Color = Color(1, 1, 1, 0.4)

const VIEW_SELECT_COLOR: Color = Color(1, 1, 1, 1)


const DEFAULT_TERRAIN_TYPE: = TERRAIN_TYPE_ENUM.FLATLANDS


enum TERRAIN_TYPE_ENUM {

    FLATLANDS,

    FOREST,

    FOREST_SHOAL,

    SHOAL,

    DESERT
}


const DEFAULT_WEATHER_TYPE: = WEATHER_TYPE_ENUM.CLEAR


enum WEATHER_TYPE_ENUM {

    CLEAR,

    SMALL_RAIN,

    BIG_RAIN,

    RAIN,
}

const WEATHER_CONFIG = {
    "CLEAR_DAY": {
        "cover_path": "res://resource/map/mapCover/clear_day.png",
        "content": "晴天",
        "weather": WEATHER_TYPE_ENUM.CLEAR,
        "is_day": true,
        "color": Color("bde8fd"),
    },
    "CLEAR_NIGHT": {
        "cover_path": "res://resource/map/mapCover/clear_night.png",
        "content": "夜晚",
        "weather": WEATHER_TYPE_ENUM.CLEAR,
        "is_day": false,
        "color": Color("898bc5"),
    },
    "RAIN_DAY": {
        "cover_path": "res://resource/map/mapCover/rain_day.png",
        "content": "白天小雨",
        "weather": WEATHER_TYPE_ENUM.SMALL_RAIN,
        "is_day": true,
        "color": Color("bde8fd"),
    },
    "RAIN_NIGHT": {
        "cover_path": "res://resource/map/mapCover/rain_night.png",
        "content": "夜晚小雨",
        "weather": WEATHER_TYPE_ENUM.SMALL_RAIN,
        "is_day": false,
        "color": Color("898bc5"),
    },
    "HEAVY_RAIN_DAY": {
        "cover_path": "res://resource/map/mapCover/heavy_rain_day.png",
        "content": "白天暴雨",
        "weather": WEATHER_TYPE_ENUM.BIG_RAIN,
        "is_day": true,
        "color": Color("bde8fd"),
    },
    "HEAVY_RAIN_NIGHT": {
        "cover_path": "res://resource/map/mapCover/heavy_rain_night.png",
        "content": "夜晚暴雨",
        "weather": WEATHER_TYPE_ENUM.BIG_RAIN,
        "is_day": false,
        "color": Color("898bc5"),
    },
}


enum TERRAIN_BUFF_ENUM {

    DESERT
}

const TERRAIN_BUFF_CONFIG = {
    TERRAIN_BUFF_ENUM.DESERT: {
        "small_icon_path": "res://resource/icon/battlebuff/desert_buff_small.png",
        "icon_path": "res://resource/icon/battlebuff/desert_buff.png",
        "content": "沙漠debuff: 持续掉血"
    }
}