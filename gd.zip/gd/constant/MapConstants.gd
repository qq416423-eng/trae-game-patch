class_name MapConstants

const MAP_NODE_CONFIG = {
    MWorldConstants.TERRAIN_TYPE_ENUM.FLATLANDS: [
        "res://tscn/game/map/bMap/BMapPlain0001.tscn",
        "res://tscn/game/map/bMap/BMapPlain0002.tscn",
    ],
    MWorldConstants.TERRAIN_TYPE_ENUM.FOREST: [
        "res://tscn/game/map/bMap/BMapForest0001.tscn",
        "res://tscn/game/map/bMap/BMapForest0002.tscn",
    ],
    MWorldConstants.TERRAIN_TYPE_ENUM.SHOAL: [
        "res://tscn/game/map/bMap/BMapShoal0001.tscn",
    ],
    MWorldConstants.TERRAIN_TYPE_ENUM.FOREST_SHOAL: [
        "res://tscn/game/map/bMap/BMapForestShoal0001.tscn",
    ],
    MWorldConstants.TERRAIN_TYPE_ENUM.DESERT: [
        "res://tscn/game/map/bMap/BMapDesert0001.tscn",
    ],
}

const MAP_CONFIG = {
    "BMapPlain0001": {
        "path": "res://tscn/game/map/bMap/BMapPlain0001.tscn",
        "cover_path": "res://resource/map/mapCover/BMapPlain0001.png",
        "content": "平原 01",
    },
    "BMapPlain0002": {
        "path": "res://tscn/game/map/bMap/BMapPlain0002.tscn",
        "cover_path": "res://resource/map/mapCover/BMapPlain0002.png",
        "content": "平原 02",
    },
    "BMapForest0001": {
        "path": "res://tscn/game/map/bMap/BMapForest0001.tscn",
        "cover_path": "res://resource/map/mapCover/BMapForest0001.png",
        "content": "森林 01",
    },
    "BMapForest0002": {
        "path": "res://tscn/game/map/bMap/BMapForest0002.tscn",
        "cover_path": "res://resource/map/mapCover/BMapForest0002.png",
        "content": "森林 02",
    },
    "BMapShoal0001": {
        "path": "res://tscn/game/map/bMap/BMapShoal0001.tscn",
        "cover_path": "res://resource/map/mapCover/BMapShoal0001.png",
        "content": "平原浅滩 01",
    },
    "BMapForestShoal0001": {
        "path": "res://tscn/game/map/bMap/BMapForestShoal0001.tscn",
        "cover_path": "res://resource/map/mapCover/BMapForestShoal0001.png",
        "content": "森林浅滩 01",
    },
    "BMapDesert0001": {
        "path": "res://tscn/game/map/bMap/BMapDesert0001.tscn",
        "cover_path": "res://resource/map/mapCover/BMapDesert0001.png",
        "content": "沙漠 01",
    },
}