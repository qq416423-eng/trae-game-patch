class_name SkillConstants

static var SKILL_CONFIG: = {
    "skill_physical": {
        "name": "强健体魄",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[个人技能]\n. 增加角色的体力值, 每一级增加"
            + str(SkillConfig.SKILL_BASE_PROP_PLUS) + "点体力",
        "is_intelligence_related": false,
    },
    "skill_strength": {
        "name": "猛虎之力",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[个人技能]\n. 增加角色的力量值, 每一级增加"
            + str(SkillConfig.SKILL_BASE_PROP_PLUS) + "点力量",
        "is_intelligence_related": false,
    },
    "skill_agile": {
        "name": "近战技巧",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[个人技能]\n. 增加角色的技巧值, 每一级增加"
            + str(SkillConfig.SKILL_BASE_PROP_PLUS) + "点技巧",
        "is_intelligence_related": false,
    },
    "skill_battle_talent": {
        "name": "战斗天赋",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[个人技能]\n. 增加武器熟练度升级速度, 每一级增加"
            + str(SkillConfig.SKILL_BATTLE_TALENT_EFFECT_WEIGHT_CONFIG * 100) + "%",
        "is_intelligence_related": false,
    },
    "skill_medical": {
        "name": "医疗",
        "type": SKILL_TYPE.TEAM,

        "remark": "[智力技能]\n[团队技能]\n. 增加部队HP恢复速度, 处于扎营/休息状态时, 恢复速度更加显著",
        "is_intelligence_related": true,
    },
    "skill_operation": {
        "name": "手术",
        "type": SKILL_TYPE.TEAM,

        "remark": "[智力技能]\n[团队技能]\n. 增加战斗结束后, 士兵由死亡状态转化为重伤状态的比例\n"
            + ". 士兵可以更快速的由重伤状态恢复成可战斗状态",
        "is_intelligence_related": true,
    },
    "skill_investigation": {
        "name": "侦查",
        "type": SKILL_TYPE.TEAM,

        "remark": "[智力技能]\n[团队技能]\n. 增加部队的视野范围, 每级增加"
            + str(SkillConfig.SKILL_INVESTIGATION_CONFIG.gain) + "px",
        "is_intelligence_related": true,
    },
    "skill_motility": {
        "name": "机动",
        "type": SKILL_TYPE.TEAM,

        "remark": "[智力技能]\n[团队技能]\n. 增加部队的行军速度, 每级增加"
            + str(SkillConfig.SKILL_MOTILITY_SPEED_RATIO * 100) + "%",
        "is_intelligence_related": true,
    },
    "skill_manage": {
        "name": "管理",
        "type": SKILL_TYPE.TEAM,



        "remark": "[智力技能]\n[团队技能]\n. 增加部队人数上限和士气, 每级增加 " \
        + str(SkillConfig.MANAGE_SKILL_EFFECT_NOP_LIMIT) \
        + "个人数上限和" + str(SkillConfig.MANAGE_SKILL_EFFECT_MORALE_FACTOR)
            + "点士气" + ".\n. 重伤状态下, 管理技能依然有效",
        "is_intelligence_related": true,
    },
    "skill_trade": {
        "name": "交易",
        "type": SKILL_TYPE.TEAM,

        "remark": "[智力技能]\n[团队技能]\n. 可以以更高的价格出售物品. 每级影响价格"
            + str(SkillConfig.SKILL_TRADE_EFFECT_WEIGHT_CONFIG * 100) + "%\n" + ". 可以以更少的价格购买物品. 每级影响价格"
            + str(SkillConfig.SKILL_TRADE_EFFECT_WEIGHT_CONFIG * 100) + "%",
        "is_intelligence_related": true,
    },
    "skill_plunder": {
        "name": "掠夺",
        "type": SKILL_TYPE.TEAM,

        "remark": "[团队技能]\n. 提高战利品的掉落概率, 每级增加"
            + str(SkillConfig.SKILL_PLUNDER_EFFECT_WEIGHT_CONFIG * 100) + "%",
        "is_intelligence_related": false,
    },
    "skill_train": {
        "name": "训练",
        "type": SKILL_TYPE.TEAM,

        "remark": "[团队技能]\n"
            + ". 技能等级越高获得的训练经验值越多\n"
            + ". 每人每天可获得的经验值 = " + str(SkillConfig.TRAIN_EXP_BASE_PRE) + " + (训练技能等级 * " + str(SkillConfig.SKILL_TRAIN_EFFECT_WEIGHT_CONFIG) + ")\n"
            + ". 每人分配到的经验值会有一定比例的减益. 减益效果与部队人数成正比\n"
            + ". 可以额外增加训练量\n"
            + ". 士气为0时无法获得训练经验值",
        "is_intelligence_related": false,
    },
    "skill_charisma": {
        "name": "魅力",
        "type": SKILL_TYPE.ALL,
        "remark": "[智力技能]\n[个人技能]\n. 增加英雄数量上限(未实装)\n" \
        + "[团队技能]\n. 减少士兵招聘价格, 每级减少"
                + str(SkillConfig.SKILL_CHARISMA_EFFECT_RECRUIT_PRICE_FACTOR * 100)
                + "%\n. 提高俘虏的招降概率\n" + ". 减弱士兵相性debuff(未实装)\n",
        "is_intelligence_related": true,
    },
    "skill_engineer": {
        "name": "工程",
        "type": SKILL_TYPE.TEAM,
        "remark": "[智力技能]\n[团队技能]\n. 建造设施时提高设施等级",
        "is_intelligence_related": true,
    },
    "skill_special_methodical": {
        "name": "井井有条",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[智力技能]\n[特有技能]\n[个人技能]\n. 增加基础士气, 每一级增加1点",
        "is_intelligence_related": true,
    },
    "skill_special_blunt_master": {
        "name": "钝器大师",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[特有技能]\n[个人技能]\n. 增加单手/双手钝器攻速(5 + 技能等级)%",
        "is_intelligence_related": false,
    },
    "skill_special_fear_ride": {
        "name": "畏惧骑马",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[个人特性]\n[负面]\n. 畏惧骑马, 即使装备马匹也无法骑马\n. 该技能升至10级可以克服此困难",
        "is_intelligence_related": false,
    },
    "skill_special_vampire": {
        "name": "嗜血",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[特有技能]\n[个人技能]\n. 近战命中造成伤害时, 回复(基础力量 × 50% × 技能等级)的生命值",
        "is_intelligence_related": false,
    },
    "skill_special_bite": {
        "name": "撕咬",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[特有技能]\n[个人技能]\n. 近战命中时有(3% × 技能等级)几率触发撕咬: 整个人贴到目标身上, 每0.5秒咬一口造成(基础力量 × 2.5)的近战伤害并全额吸血, 直至目标死亡\n. 自己被眩晕或失去战斗能力时会松口",
        "is_intelligence_related": false,
    },
    "skill_stop_leveling": {
        "name": "停止升级",
        "type": SKILL_TYPE.INDIVIDUAL,

        "remark": "[个人技能]\n[特殊]\n. 此技能升满后角色最大等级上限变为100不再无限升级",
        "is_intelligence_related": false,
    }
}


enum SKILL_TYPE {
    INDIVIDUAL,
    TEAM,

    ALL,
}

static func get_skill_name(_field_name: String)-> String:
    return SKILL_CONFIG.get(_field_name).name