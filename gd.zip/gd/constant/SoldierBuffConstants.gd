class_name SoldierBuffConstants

const BUFF_TYPE_ENUM = {

    PANIC = "PANIC",

    PLUS_ATK = "PLUS_ATK",

    ARMOR_OPEN = "ARMOR_OPEN",

    MELEE_PERFECT_HIT = "MELEE_PERFECT_HIT"
}

static var BUFF_TYPE_CONFIG = {
    BUFF_TYPE_ENUM.PANIC: {
        "preload_node": preload("res://tscn/game/bs/soldierBuff/PanicBuff.tscn")
    },
    BUFF_TYPE_ENUM.PLUS_ATK: {
        "preload_node": preload("res://tscn/game/bs/soldierBuff/PlusAtkBuff.tscn")
    },
    BUFF_TYPE_ENUM.ARMOR_OPEN: {
        "preload_node": preload("res://tscn/game/bs/soldierBuff/ArmorOpenBuff.tscn")
    },
    BUFF_TYPE_ENUM.MELEE_PERFECT_HIT: {
        "preload_node": preload("res://tscn/game/bs/soldierBuff/MeleePerfectHitBuff.tscn")
    },
}