class_name SoldierPractiseConstants

const PRACTISE_CONFIG = {
    "practise_mobile": {

        "max": 350,
    },
    "practise_horse": {
        "max": 350,
    },



    "default": {
        "max": 500,
    }
}

const PRACTISE_FIELD_LIST = [
    "practise_oh_sword", "practise_th_sword", "practise_oh_axe", "practise_th_axe",
    "practise_oh_blunt", "practise_th_blunt",
    "practise_oh_lance", "practise_oh_shield", "practise_oh_pole",
    "practise_th_pole", "practise_th_bow", "practise_th_firearm", "practise_th_crossbow",
    "practise_oh_throw", "practise_horse", "practise_mobile"
]

static func get_practise_config(_field: String)-> Dictionary:
    if PRACTISE_CONFIG.has(_field):
        return PRACTISE_CONFIG.get(_field)

    return PRACTISE_CONFIG.get("default")