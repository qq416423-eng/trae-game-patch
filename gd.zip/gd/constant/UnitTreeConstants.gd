class_name UnitTreeConstants


static var UNIT_TREE_DATA = {
    "ROAO_REGULAR_ARMY": {
        "name": "罗奥正规军",
        "data": {
            "regular_soldier_0011": [
                "regular_soldier_0012"
            ],
            "regular_soldier_0012": [
                "regular_soldier_0013", "regular_soldier_0016", "regular_soldier_0015",
            ],
            "regular_soldier_0013": [
                "regular_soldier_0014"
            ],
            "regular_soldier_0015": [
                "regular_soldier_0017", "regular_soldier_0018"
            ]
        },

        "default_unlock": true,
    },
    "ROAO_ELITE_ARMY": {
        "name": "罗奥精锐军",
        "data": {
            "regular_soldier_0014": [
                "regular_soldier_0014_02"
            ],
            "regular_soldier_0017": [
                "regular_soldier_0017_02"
            ],
            "regular_soldier_0018": [
                "regular_soldier_0018_02"
            ]
        },

        "default_unlock": false,
        "remark": "露西安纳王国精英战士.",
        "unlock_instructions": "加入[露西安纳王国]后解锁.",
    },
    "BLACK_FANG_ELITE_ARMY": {
        "name": "强寇阵营",
        "data": {
            "wild_soldier_0003": [
                "wild_soldier_0038"
            ],
            "wild_soldier_0006": [
                "wild_soldier_0039"
            ],
            "wild_soldier_0009": [
                "wild_soldier_0040"
            ]
        },
        "default_unlock": false,
        "remark": "强寇阵营兵种.",
        "unlock_instructions": "加入[强寇阵营]后解锁.",
    },
    "SAINA_REGULAR_ARMY": {
        "name": "赛娜正规军",
        "data": {
            "regular_soldier_0003": [
                "regular_soldier_0004", "regular_soldier_0008"
            ],
            "regular_soldier_0004": [
                "regular_soldier_0005", "regular_soldier_0006",
            ],
            "regular_soldier_0006": [
                "regular_soldier_0007"
            ],
            "regular_soldier_0008": [
                "regular_soldier_0009"
            ],
        },
        "default_unlock": true,
    },
    "SAINA_ELITE_ARMY": {
        "name": "赛娜精锐军",
        "data": {
            "regular_soldier_0005": [
                "regular_soldier_0005_02"
            ],
            "regular_soldier_0007": [
                "regular_soldier_0007_02"
            ],
            "regular_soldier_0009": [
                "regular_soldier_0009_02"
            ]
        },
        "default_unlock": false,
        "remark": "艾德拉斯王国精英战士.",
        "unlock_instructions": "加入[艾德拉斯王国]后解锁.",
    },
    "MARKA_REGULAR_ARMY": {
        "name": "马尔克正规军",
        "data": {
            "regular_soldier_0022": [
                "regular_soldier_0023"
            ],
            "regular_soldier_0023": [
                "regular_soldier_0024", "regular_soldier_0025", "regular_soldier_0026"
            ],
            "regular_soldier_0025": [
                "regular_soldier_0027", "regular_soldier_0028"
            ],
            "regular_soldier_0026": [
                "regular_soldier_0029"
            ],
        },
        "default_unlock": true,
    },
    "MARKA_ELITE_ARMY": {
        "name": "马尔克精锐军",
        "data": {
            "regular_soldier_0027": [
                "regular_soldier_0027_02"
            ],
            "regular_soldier_0028": [
                "regular_soldier_0028_02"
            ],
            "regular_soldier_0029": [
                "regular_soldier_0029_02"
            ]
        },
        "default_unlock": false,
        "remark": "多尔达尔王国精英战士.",
        "unlock_instructions": "加入[多尔达尔王国]后解锁.",
    },
    "SHALUK_REGULAR_ARMY": {
        "name": "沙鲁克正规军",
        "data": {
            "regular_soldier_0030": [
                "regular_soldier_0031"
            ],
            "regular_soldier_0031": [
                "regular_soldier_0034", "regular_soldier_0032", "regular_soldier_0033"
            ],
            "regular_soldier_0032": [
                "regular_soldier_0035", "regular_soldier_0036"
            ],
            "regular_soldier_0033": [
                "regular_soldier_0037"
            ]
        },
        "default_unlock": true,
    },
    "SHALUK_ELITE_ARMY": {
        "name": "沙鲁克精锐军",
        "data": {
            "regular_soldier_0035": [
                "regular_soldier_0035_02"
            ],
            "regular_soldier_0036": [
                "regular_soldier_0036_02"
            ],
            "regular_soldier_0037": [
                "regular_soldier_0037_02"
            ]
        },
        "default_unlock": false,
        "remark": "哈斯卡尔王国精英战士.",
        "unlock_instructions": "加入[哈斯卡尔王国]后解锁.",
    },
    "CARAVAN_GUARD": {
        "name": "雇佣兵",
        "data": {
            "wild_soldier_0010": [
                "wild_soldier_0011"
            ],
            "wild_soldier_0011": [
                "wild_soldier_0012"
            ],
        },


        "default_unlock": true,
    },
    "DESERT_CARAVAN_GUARD": {
        "name": "沙鲁克雇佣兵",
        "data": {
            "wild_soldier_0023": [
                "wild_soldier_0024", "wild_soldier_0025"
            ],
        },

        "default_unlock": true,
    },

    "ROBBER": {
        "name": "强盗",
        "data": {
            "wild_soldier_0001": [
                "wild_soldier_0002"
            ],
            "wild_soldier_0002": [
                "wild_soldier_0003"
            ],
        },
        "default_unlock": true,
    },

    "FOREST_BANDIT": {
        "name": "森林强盗",
        "data": {
            "wild_soldier_0004": [
                "wild_soldier_0005"
            ],
            "wild_soldier_0005": [
                "wild_soldier_0006"
            ],
        },
        "default_unlock": true,
    },

    "PIRATE": {
        "name": "海寇",
        "data": {
            "wild_soldier_0007": [
                "wild_soldier_0008"
            ],
            "wild_soldier_0008": [
                "wild_soldier_0009", "wild_soldier_0009_02"
            ],
        },
        "default_unlock": true,
    },
    "MARKA_CRIMSON_WARBAND": {
        "name": "马尔克赤那旅",
        "data": {
            "wild_soldier_0017": [
                "wild_soldier_0018", "wild_soldier_0019"
            ],
        },
        "default_unlock": true,
    },
    "DESERT_BANDITS": {
        "name": "沙漠强盗",
        "data": {
            "wild_soldier_0020": [
                "wild_soldier_0021", "wild_soldier_0022"
            ],
        },
        "default_unlock": true,
    },

    "JUDICATOR_OF_THE_SHACKLE_KING": {
        "name": "枷王裁决者",
        "data": {
            "wild_soldier_0026": [],
        },
        "default_unlock": false,
        "remark": "奴隶收藏家·图格训练出的专属兵种.",
    },

    "GOLDEN_ARBALEST_GUARD": {
        "name": "金弩护卫",
        "data": {
            "wild_soldier_0027": [],
        },
        "default_unlock": false,
        "remark": "地狱之矛·库德鲁的专属护卫."
    },

    "SCORCHING_SOUL_SECT": {
        "name": "烙魂教",
        "data": {
            "wild_soldier_0028": [
                "wild_soldier_0029"
            ],
        },
        "default_unlock": true,
        "remark": "来自雷瑟托大陆的异教徒, 奉行极端的信条: 以肉体折磨惩戒有罪之人. 他们相信: 唯有经受身体上的痛苦, 才能洗净灵魂的罪恶. 刑罚之后, 被惩罚者若尚存一息, 便被强迫成为新的信徒, 继续扩散他们扭曲的教义."
    },

    "EAGLE_MERCENARY_CORPS": {
        "name": "雄鹰佣兵团",
        "data": {
            "wild_soldier_0030": [
                "wild_soldier_0031"
            ],
        },
        "default_unlock": true,
        "remark": "雄鹰佣兵团并没有严格的组织结构, 更多是一种装备流派的代称. 因\"雄鹰\"系列装备兼具优良的实用性与出众的外观, 大量实力不俗的罗德里佣兵选择了这一系列的装备, 逐渐形成了如今的\"雄鹰佣兵团\"群体."
    },

    "CALANT_MERCENARIES": {
        "name": "卡兰特雇佣兵",
        "data": {
            "wild_soldier_0033": [
                "wild_soldier_0032", "wild_soldier_0034"
            ],
        },
        "default_unlock": true,
        "remark": "来自克瑞弗大陆的雇佣兵, 配备着更先进的战斗装备和技术."
    },
    "CALANT_BANISHED": {
        "name": "卡兰特流放者",
        "data": {
            "wild_soldier_0035": [
                "wild_soldier_0037"
            ],
            "wild_soldier_0036": [

            ],
        },
        "default_unlock": true,
        "remark": "来自克瑞弗大陆的雇佣兵. 这些士兵抛弃了作为战士的底线, 他们不再为了荣誉或契约而战, 金币和劫掠后的余烬才是他们唯一的信仰."
    },
    "NOBLES_GUARD_01": {
        "name": "贵族亲卫队01",
        "data": {
            "regular_soldier_0040": [],
            "regular_soldier_0041": [],
            "regular_soldier_0042": [],
        },
        "is_show": true,
        "default_unlock": false,
        "remark": "露西安纳王国(原)领主亲卫队"
    },
    "SHADOW_KNIGHTS_02": {
        "name": "有天赋的猎人升级分支",
        "data": {
            "wild_soldier_0015": [
                "regular_soldier_0013"
            ]
        },
        "is_show": false,
        "default_unlock": true,
    },
    "SHADOW_KNIGHTS": {
        "name": "幽影骑士团",
        "data": {
            "wild_soldier_0015": [
                "wild_soldier_0016"
            ],
            "wild_soldier_0016": [
                "wild_soldier_0014"
            ],
            "wild_soldier_0014": []
        },
        "unlock_instructions": "...",
    },
    "ALICE_BATTLE_MAID_KNIGHT_02": {
        "name": "赛娜女战士升级分支",
        "data": {
            "wild_soldier_0013_02": [
                "regular_soldier_0006"
            ],
        },
        "is_show": false,
        "default_unlock": true,
    },
    "ALICE_BATTLE_MAID_KNIGHT": {
        "name": "爱丽丝战斗女仆骑士团",
        "data": {
            "wild_soldier_0013_02": [
                "wild_soldier_0013_03"
            ],
            "wild_soldier_0013_03": [
                "wild_soldier_0013"
            ],
            "wild_soldier_0013": [],
        },
        "unlock_instructions": "完成NPC[战斗女仆骑士团团长 - 波琳娜·爱丽丝]的任务:[爱丽丝的信任](未实装)",
    },
    "LUCIANA_ROYAL_GUARD": {
        "name": "黯金王近卫队",
        "data": {
            "regular_soldier_0019": []
        },
        "unlock_instructions": "...",
    },
    "EDRAS_ROYAL_GUARD": {
        "name": "塞瑞雅女王亲卫队",
        "data": {
            "regular_soldier_0010": []
        },
        "unlock_instructions": "拥有城镇建筑: [艾德拉斯皇家训练基地](未实装)",
    },
    "DORDAR_ROYAL_GUARD": {
        "name": "铁木尔可汗御卫队",
        "data": {
            "regular_soldier_0039": []
        },
        "unlock_instructions": "...",
    },
    "HASKAL_ROYAL_GUARD": {
        "name": "阿舒兰帝王亲卫队",
        "data": {
            "regular_soldier_0038": []
        },
        "unlock_instructions": "...",
    },

    "MOD_PLAYER_GUARD_TREE": {
        "name": "私卫兵种树",
        "data": {
            "mod_player_guard": [
                "mod_player_guard_4"
            ],
            "mod_player_guard_4": [
                "mod_player_guard_5"
            ],
            "mod_player_guard_5": []
        },
        "default_unlock": true,
        "remark": "玩家私卫升级树，装备保持不变。",
    },


}



static var UNIT_TREE_UPGRADE_DATA = {}


static func repair_unit_tree_data():
    for _key in UNIT_TREE_DATA.keys():
        var _data = UNIT_TREE_DATA.get(_key)
        _data["code"] = _key


        var _soldier_uid_list = _get_soldier_uid_list(_key)
        var _max_star = SoldierUtils.get_max_star(_soldier_uid_list)

        _data["max_star"] = _max_star

        if not _data.has("default_unlock"):
            _data["default_unlock"] = false


    handle_unit_tree_upgrade_data()









































static func get_unit_upgrade_tree_data(_unit_tree_code: String)-> Array:
    var _data: Dictionary = UNIT_TREE_DATA.get(_unit_tree_code).data
    var _value_soldier_uid_list: = []
    for _upgrade_soldier_uid_list: Array in _data.values():
        _value_soldier_uid_list.append_array(_upgrade_soldier_uid_list)

    var _result = [{}]
    for _root_soldier_uid: String in _data.keys():
        if not _value_soldier_uid_list.has(_root_soldier_uid):
            _result[0][_root_soldier_uid] = []

    var is_break = false
    while(not is_break):
        var _all_no_up = true
        var _next_row_list = []
        var _row_index = _result.size() - 1
        for _soldier_uid: String in _result[_row_index].keys():
            if not _data.has(_soldier_uid):
                continue

            _result[_row_index][_soldier_uid] = _data.get(_soldier_uid)
            _next_row_list.append_array(_data.get(_soldier_uid))

            _all_no_up = false

        var _next_item = {}
        for _uid in _next_row_list:
            _next_item[_uid] = []

        if _next_item.size() != 0:
            _result.append(_next_item)
        else:
            is_break = true

        if _all_no_up:
            is_break = true

    return _result

static func get_unit_tree_data(_code):
    return UNIT_TREE_DATA.get(_code)


static func unit_tree_upgrade_data(_soldier_uid)-> Dictionary:
    if UNIT_TREE_UPGRADE_DATA.has(_soldier_uid):
        var _result = UNIT_TREE_UPGRADE_DATA.get(_soldier_uid).duplicate(true)

        var _new_upgrade_list = []
        var _upgrade_uid_list = []
        for _upgrade_info: Dictionary in _result.upgrade_list:
            if WSData.unit_tree_is_unlock(_upgrade_info.unit_tree_code):
                _new_upgrade_list.append(_upgrade_info)
                _upgrade_uid_list.append(_upgrade_info.uid)

        _result.upgrade_list = _new_upgrade_list
        _result["upgrade_uid_list"] = _upgrade_uid_list

        return _result
    else:
        return {
            "upgrade_list": {},
            "upgrade_uid_list": [],
            "need_exp": 0,
        }

static func get_upgrade_need_exp(_soldier_uid: String)-> int:
    if not UNIT_TREE_UPGRADE_DATA.has(_soldier_uid):
        return 0

    return UNIT_TREE_UPGRADE_DATA.get(_soldier_uid).need_exp

static func handle_unit_tree_upgrade_data()-> void:
    var _result = {}

    for _unit_tree_code: String in UNIT_TREE_DATA.keys():
        var _unit_tree_data: Dictionary = UNIT_TREE_DATA.get(_unit_tree_code)
        if not WSData.unit_tree_is_unlock(_unit_tree_code):
            continue

        for _soldier_uid: String in _unit_tree_data.data.keys():
            if _result.has(_soldier_uid):
                for _up_soldier_uid: String in _unit_tree_data.data.get(_soldier_uid):
                    _result[_soldier_uid].upgrade_list.append(
                        {
                            "uid": _up_soldier_uid,
                            "unit_tree_code": _unit_tree_data.code
                        }
                    )
            else:
                _result[_soldier_uid] = {
                    "upgrade_list": [],
                    "need_exp": 0
                }
                for _up_soldier_uid: String in _unit_tree_data.data.get(_soldier_uid):
                    _result[_soldier_uid].upgrade_list.append(
                        {
                            "uid": _up_soldier_uid,
                            "unit_tree_code": _unit_tree_data.code
                        }
                    )


                if ArrayUtils.is_not_empty(_result[_soldier_uid].upgrade_list):
                    var _need_exp = SoldierUtils.get_upgrade_need_exp02(_soldier_uid, _result[_soldier_uid].upgrade_list[0].uid)
                    _result[_soldier_uid].need_exp = _need_exp

    UNIT_TREE_UPGRADE_DATA = _result

static func _get_soldier_uid_list(_unit_tree_code: String):
    var _data: Dictionary = CommonUtils.get_value(get_unit_tree_data(_unit_tree_code), "data",{})
    var _uid_list = []
    for _key in _data.keys():
        _uid_list.append(_key)
        _uid_list.append_array(_data.get(_key))

    return ArrayUtils.distinct(_uid_list)