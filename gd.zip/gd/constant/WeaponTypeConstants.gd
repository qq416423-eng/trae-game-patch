class_name WeaponTypeConstants extends Node

const EQUIPMENT_TYPE_ENUM = {

    WEAPON = "WEAPON",

    HELMET = "HELMET",

    SHOULDER = "SHOULDER",

    ARMOUR = "ARMOUR",

    SHOE = "SHOE",

    HORSE = "HORSE",

    HARMOUR = "HARMOUR",



    FOOD = "FOOD",

    COMMODITY = "COMMODITY",

    CARRIAGE = "CARRIAGE"
}

const FORBID_EQUIP_ETYPE_LIST = [
    EQUIPMENT_TYPE_ENUM.FOOD,
    EQUIPMENT_TYPE_ENUM.COMMODITY,
    EQUIPMENT_TYPE_ENUM.CARRIAGE
]


const WEAPON_STYPE_DIC: = {

    "oh_sword": {

        "btype": "oh_weapon",

        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,

        "default_prop": {
            "want_attack_range": 200,
        },
        "type_name": "武器-单手剑",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "one_hand_no_shield_atk_speed_bonus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "oh_axe": {

        "btype": "oh_weapon",

        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,

        "default_prop": {
            "want_attack_range": 200,

            "shield_pierce": 3.0,
        },
        "type_name": "武器-单手斧",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "one_hand_no_shield_atk_speed_bonus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "oh_blunt": {

        "btype": "oh_weapon",

        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,

        "default_prop": {

            "capture_prob": 0.4,
            "want_attack_range": 200,
        },
        "type_name": "武器-单手钝器",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "one_hand_no_shield_atk_speed_bonus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "th_blunt": {

        "btype": "th_weapon",

        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,

        "default_prop": {

            "capture_prob": 0.4,
            "want_attack_range": 200,
            "stun_prop": 0.1,
            "stun_second": 2.0,
        },
        "type_name": "武器-双手钝器",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "th_sword": {
        "btype": "th_weapon",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "stun_prop": 0.1,
            "stun_second": 2.0,
            "want_attack_range": 200,
        },
        "type_name": "武器-双手剑",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "th_axe": {
        "btype": "th_weapon",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "stun_prop": 0.1,
            "stun_second": 2.0,
            "shield_pierce": 4.0,
            "want_attack_range": 200,
        },
        "type_name": "武器-双手斧",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "th_bow": {
        "btype": "th_bow",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "knock_back": 10,
            "shot_radian": 80,
            "want_attack_range": 800,
            "attack_range": 800,

            "weight_attack_speed_debuff_double": true,
            "flyer_speed": 70,
        },
        "type_name": "武器-弓箭",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_mobile": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "th_crossbow": {
        "btype": "th_crossbow",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "knock_back": 10,
            "shot_radian": 40,
            "want_attack_range": 850,
            "attack_range": 850,
            "flyer_speed": 80,
            "attack_bonus_cavalvy": 0.2,
            "ignores_strength_bonus_atk": true,
        },
        "type_name": "武器-弩",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_mobile": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "th_firearm": {
        "btype": "th_firearm",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "knock_back": 20,
            "want_attack_range": 1000,
            "attack_range": 1000,
            "shield_pierce": 3.0,

            "ignores_strength_bonus_atk": true,
            "cavalvy_forbid": true,

            "is_close_range_accurate": true,
        },
        "type_name": "武器-火枪",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "oh_throw": {
        "btype": "oh_throw",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "knock_back": 20,
            "shot_radian": 80,
            "flyer_speed": 50,
            "want_attack_range": 350,
            "attack_range": 350,
            "stun_prop": 0.2,
            "stun_second": 2.0,
            "shield_break_ratio": 0.2,
        },
        "type_name": "武器-投掷武器",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "oh_shield": {
        "btype": "oh_shield",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {

        },
        "type_name": "武器-盾牌",
        "quality_config": {
            "e_hp": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "crit_def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
        }
    },

    "oh_lance": {
        "btype": "oh_lance",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "knock_back": 130,
            "stun_prop": 0.7,
            "stun_second": 2,
            "infantry_forbid": true,

            "want_attack_range": 350,


            "speed_damage": true,
            "shield_pierce": 3.0,
        },
        "type_name": "武器-骑枪",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "kill_guaranteed_melee_hit_seconds": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "oh_pole": {
        "btype": "oh_weapon",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,

        "default_prop": {
            "attack_bonus_cavalvy": 0.5,
            "want_attack_range": 200,
            "panic_buff_weapon_small_to_cavalry": true,
        },
        "type_name": "武器-单手长柄",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "th_pole": {
        "btype": "th_pole",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,

        "default_prop": {
            "attack_bonus_cavalvy": 0.5,
            "knock_back": 20,
            "cavalvy_forbid": true,
            "want_attack_range": 200,

            "set_pike": true,
            "panic_buff_weapon_big_to_cavalry": true,
        },
        "type_name": "武器-双手长柄",
        "quality_config": {
            "atk": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

            "armor_pen_5_seconds_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "on_kill_atk_boost_30s": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },

    "l_shield": {
        "btype": "l_shield",
        "etype": EQUIPMENT_TYPE_ENUM.WEAPON,
        "default_prop": {
            "cavalvy_forbid": true,
            "remote_attack_on_the_ground": true
        },
        "type_name": "武器-巨盾",
        "quality_config": {
            "e_hp": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
        }
    },
    "helmet": {
        "etype": EQUIPMENT_TYPE_ENUM.HELMET,
        "default_prop": {

        },
        "type_name": "头盔",
        "quality_config": {
            "def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "crit_def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
            "attack_speed_plus_th_bow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "infantry_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_physical_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_crossbow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_attack_plus_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_throw": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "remote_hurt_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "cavalry_charge_damage_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "attack_speed_plus_th_crossbow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_strength_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_agile_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "bow_lethal_strike_5000_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_second_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_prop_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_sword": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_axe": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_pole": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_blunt": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "buff_duration_bonus_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "shoulder": {
        "etype": EQUIPMENT_TYPE_ENUM.SHOULDER,
        "default_prop": {

        },
        "type_name": "肩甲",
        "quality_config": {
            "def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "crit_def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
            "attack_speed_plus_th_bow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "infantry_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_physical_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_crossbow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_attack_plus_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_throw": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "remote_hurt_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "cavalry_charge_damage_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "attack_speed_plus_th_crossbow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_strength_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_agile_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "bow_lethal_strike_5000_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_second_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_prop_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_sword": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_axe": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_pole": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_blunt": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "buff_duration_bonus_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "armour": {
        "etype": EQUIPMENT_TYPE_ENUM.ARMOUR,
        "default_prop": {

        },
        "type_name": "盔甲",
        "quality_config": {
            "def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "crit_def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
            "attack_speed_plus_th_bow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "infantry_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_physical_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_crossbow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_attack_plus_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_throw": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "remote_hurt_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "cavalry_charge_damage_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "attack_speed_plus_th_crossbow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_strength_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_agile_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "bow_lethal_strike_5000_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_second_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_prop_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_sword": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_axe": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_pole": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_blunt": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "buff_duration_bonus_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "shoe": {
        "etype": EQUIPMENT_TYPE_ENUM.SHOE,
        "default_prop": {

        },
        "type_name": "鞋子",
        "quality_config": {
            "def": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,
            "attack_speed_plus_th_bow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "infantry_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_physical_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_crossbow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_attack_plus_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_damage_plus_oh_throw": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "th_bow_plus_crit_prob_ratio": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "remote_hurt_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "cavalry_charge_damage_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW,
            "attack_speed_plus_th_crossbow": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_oh_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "attack_speed_plus_th_melee": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_strength_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "base_agile_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "bow_lethal_strike_5000_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_second_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_damage_to_stunned_target_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "melee_stun_prop_plus": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_sword": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_axe": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_pole": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "practise_oh_blunt": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
            "buff_duration_bonus_rate": DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST,
        }
    },
    "horse": {
        "etype": EQUIPMENT_TYPE_ENUM.HORSE,
        "default_prop": {
            "stability": 60,
            "horse_power": 1,
            "horse_power_1": true,

            "light_speed": 0.1,
            "melee_attack_range_plus": 10,
        },
        "type_name": "马匹",
        "quality_config": {
            "speed": HORSE_QUALITY_PLUS_ATTRIBUTE_LIST,
            "ahp": DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST,
            "price": DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST,

        }
    },
    "harmour": {
        "etype": EQUIPMENT_TYPE_ENUM.HARMOUR,
        "default_prop": {
            "skin": true,
        },
        "type_name": "马铠",
    },
    "commodity": {
        "etype": EQUIPMENT_TYPE_ENUM.COMMODITY,
        "default_prop": {

        },
        "type_name": "贸易品",
    },
    "food": {
        "etype": EQUIPMENT_TYPE_ENUM.FOOD,
        "default_prop": {

        },
        "type_name": "食物",
    },
    "carriage": {
        "etype": EQUIPMENT_TYPE_ENUM.CARRIAGE,
        "default_prop": {

        },
        "type_name": "马车",
    },
}


const weapon_btype_dic: = {
    "oh_weapon": {
        "animation_name_enum": "OH_ATTACK",

        "oot": OOT_ENUM.ONE,
        "utype": USER_TYPE_ENUM.CLOSE_IN_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.CLOSE_IN,
    },
    "th_weapon": {
        "animation_name_enum": "TH_ATTACK",

        "oot": OOT_ENUM.TWO,
        "utype": USER_TYPE_ENUM.CLOSE_IN_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.CLOSE_IN,
    },
    "th_pole": {
        "animation_name_enum": "OH_ATTACK",
        "oot": OOT_ENUM.TWO,
        "utype": USER_TYPE_ENUM.REMOTE_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.CLOSE_IN,
    },
    "th_bow": {
        "animation_name_enum": "TH_BOW_ATTACK",
        "oot": OOT_ENUM.TWO,
        "utype": USER_TYPE_ENUM.REMOTE_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.REMOTE,
    },
    "oh_throw": {
        "animation_name_enum": "OH_THROW_ATTACK",
        "oot": OOT_ENUM.ONE,
        "utype": USER_TYPE_ENUM.REMOTE_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.REMOTE,
    },
    "th_crossbow": {
        "animation_name_enum": "TH_CROSSBOW_ATTACK",
        "oot": OOT_ENUM.TWO,
        "utype": USER_TYPE_ENUM.REMOTE_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.REMOTE,
    },
    "th_firearm": {
        "animation_name_enum": "TH_FIREARM_ATTACK",
        "oot": OOT_ENUM.TWO,
        "utype": USER_TYPE_ENUM.REMOTE_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.REMOTE,
    },
    "oh_shield": {
        "oot": OOT_ENUM.ONE,
        "utype": USER_TYPE_ENUM.SHIELD,
    },
    "l_shield": {
        "oot": OOT_ENUM.TWO,
        "utype": USER_TYPE_ENUM.LARGE_SHIELD,
    },
    "oh_lance": {
        "oot": OOT_ENUM.ONE,
        "utype": USER_TYPE_ENUM.REMOTE_SWITCH,
        "attack_type": ATTACK_TYPE_ENUM.CLOSE_IN,
    }
}

const STYPE_ENUM = {
    HORSE = "horse",
    TH_BOW = "th_bow",
    TH_CROSSBOW = "th_crossbow",
    TH_FIREARM = "th_firearm",
    OH_THROW = "oh_throw",
    OH_LANCE = "oh_lance",
    CARRIAGE = "carriage",

    OH_POLE = "oh_pole",
    TH_POLE = "th_pole",

    OH_BLUNT = "oh_blunt",
    TH_BLUNT = "th_blunt",

    OH_SWORD = "oh_sword",
    TH_SWORD = "th_sword",

    OH_AXE = "oh_axe",
    TH_AXE = "th_axe",
}

const WEAPON_BTYPE_ENUM = {
    OH_LANCE = "oh_lance",
    L_SHIELD = "l_shield",
    OH_THROW = "oh_throw",
}


const USER_TYPE_ENUM = {

    "REMOTE_SWITCH" = "REMOTE_SWITCH",

    CLOSE_IN_SWITCH = "CLOSE_IN_SWITCH",

    SHIELD = "SHIELD",

    LARGE_SHIELD = "LARGE_SHIELD",
}


const MAIN_WEAPON_USER_TYPE_LIST = [USER_TYPE_ENUM.REMOTE_SWITCH, USER_TYPE_ENUM.CLOSE_IN_SWITCH]


const OOT_ENUM = {
    ONE = "ONE",
    TWO = "TWO"
}


const ATTACK_TYPE_ENUM = {
    REMOTE = "REMOTE",
    CLOSE_IN = "CLOSE_IN"
}



const REMOTE_SOLDIER_WEAPON_STYPE_LIST = [
    STYPE_ENUM.TH_BOW,
    STYPE_ENUM.TH_CROSSBOW,
    STYPE_ENUM.TH_FIREARM,
]


const ALLOW_REMOTE_WEAPON_STYPE_LIST = [
    STYPE_ENUM.TH_BOW,
    STYPE_ENUM.TH_CROSSBOW,
    STYPE_ENUM.TH_FIREARM,
    STYPE_ENUM.OH_THROW,

]



const DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTRIBUTE_LIST = [0.5, 0.8, 1, 1.1, 1.25, 1.4, 1.6]

const DEFAULT_EQUIPMENT_QUALITY_PLUS_PRICE_LIST = [0.2, 0.4, 1.0, 1.3, 2, 3, 5]
const DEFAULT_EQUIPMENT_QUALITY_PLUS_CRIT_ATK_RATIO_LIST = [0.8, 0.9, 1, 1.1, 1.2, 1.4, 1.6]
const DEFAULT_EQUIPMENT_QUALITY_PLUS_ATTACK_RANGE_LIST = [0.7, 0.9, 1, 1.02, 1.05, 1.1, 1.15]
const DEFAULT_EQUIPMENT_QUALITY_PLUS_SHOOT_COUNT_LIST = [1, 1, 1, 1, 1.1, 1.2, 1.3]
const DEFAULT_EQUIPMENT_QUALITY_PLUS_BLOCK_PROB_LIST = [0.8, 0.9, 1, 1.05, 1.1, 1.2, 1.3]

const DEFAULT_EQUIPMENT_QUALITY_REDUCE_ATTRIBUTE_LIST = [1.2, 1.1, 1, 0.9, 0.8, 0.7, 0.6]

const DEFAULT_EQUIPMENT_QUALITY_LITTLE_CHANGE_LIST = [0.9, 0.95, 1.0, 1.05, 1.1, 1.15, 1.2]

const HORSE_QUALITY_PLUS_ATTRIBUTE_LIST = [0.5, 0.8, 1.0, 1.0, 1.0, 1.0, 1.0]

const DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST = [0.6, 0.8, 1.0, 1.2, 1.4, 1.8, 2.2]
const DEFAULT_EQUIPMENT_QUALITY_PLUS_SPECIAL_PROB_LIST_LOW = [0.6, 0.8, 1.0, 1.1, 1.2, 1.4, 1.6]



enum EQUIPMENT_QUALITY_ENUM {

    DEFECTIVE,

    FLAW,

    COMMON,

    FINE,

    EXCELLENT,

    LEGEND,

    GOD,
}


const EQUIPMENT_QUALITY_CONFIG = {
    EQUIPMENT_QUALITY_ENUM.DEFECTIVE: {
        "button_color": CommonConstants.COLOR_ENUM.DARK,
        "color": CommonConstants.COLOR_ENUM.DARK,
        "drop_weight": 600,
    },
    EQUIPMENT_QUALITY_ENUM.FLAW: {
        "button_color": CommonConstants.COLOR_ENUM.GREY,
        "color": CommonConstants.COLOR_ENUM.GREY,
        "drop_weight": 420,
    },
    EQUIPMENT_QUALITY_ENUM.COMMON: {
        "button_color": CommonConstants.COLOR_ENUM.SHALLOW_WHITE,
        "color": CommonConstants.COLOR_ENUM.SHALLOW_WHITE,
        "drop_weight": 150,
    },
    EQUIPMENT_QUALITY_ENUM.FINE: {
        "button_color": CommonConstants.COLOR_ENUM.BLUE,
        "color": CommonConstants.COLOR_ENUM.BLUE,
        "drop_weight": 50,
    },
    EQUIPMENT_QUALITY_ENUM.EXCELLENT: {
        "button_color": Color("79547a"),
        "color": CommonConstants.COLOR_ENUM.VIOLET,
        "drop_weight": 20,
    },
    EQUIPMENT_QUALITY_ENUM.LEGEND: {
        "button_color": Color("a18c3b"),
        "color": CommonConstants.COLOR_ENUM.YELLOW,
        "drop_weight": 8,
    },
    EQUIPMENT_QUALITY_ENUM.GOD: {
        "button_color":("984242"),
        "color": CommonConstants.COLOR_ENUM.RED,
        "drop_weight": 0,
    },
}


static var EQUIPMENT_QUALITY_DROP_WEIGHT_TOTAL = 0

const EQUIPMENT_FIELD_ENUM = {
    ARMOUR = "armour",
    HELMET = "helmet",
    HORSE = "horse",
    SHOE = "shoe",
    SHOULDER = "shoulder",
    WEAPON1 = "weapon1",
    WEAPON2 = "weapon2",
    WEAPON3 = "weapon3",
    HARMOUR = "harmour"
}


const L_SHIELD_PLACE_MAIN_WEAPON_STYPE_LIST = [
    STYPE_ENUM.TH_BOW, STYPE_ENUM.TH_CROSSBOW, STYPE_ENUM.TH_FIREARM
]


const WEIGHT_EFFECT_ATTACK_SPEED_WEAPON_STYPE_LIST = [
    STYPE_ENUM.TH_BOW,



]


const ALLOW_MOBILE_SHOOTING_WEAPON_STYPE_LIST = [
    STYPE_ENUM.TH_BOW, STYPE_ENUM.TH_CROSSBOW,
    STYPE_ENUM.TH_FIREARM, STYPE_ENUM.OH_THROW
]


const SOLDIER_PART_FIELD_LIST = [
    "armour", "helmet", "shoe", "shoulder", "weapon1",
    "weapon2", "weapon3", "horse", "body", "hair", "harmour"
]

static func init_equipment_quality_drop_weight_total():
    var _total = 0
    for _json in EQUIPMENT_QUALITY_CONFIG.values():
        _total += _json.drop_weight

    EQUIPMENT_QUALITY_DROP_WEIGHT_TOTAL = _total

static func get_stype(_part_uid: String)-> String:
    for _prefix in WEAPON_STYPE_DIC.keys():
        if _part_uid.begins_with(_prefix):
            return _prefix

    return ""


static func replenish_info(_json)-> Dictionary:
    var _stype = get_stype(_json.uid)
    if StringUtils.is_empty(_stype):
        return _json

    _json.stype = _stype
    _json = CommonUtils.cover_json(WEAPON_STYPE_DIC.get(_stype), _json,["default_prop", "quality_config"])
    if _json.has("btype"):
        _json = CommonUtils.cover_json(weapon_btype_dic.get(_json.btype), _json)

    return _json

static func get_field(_uid: String):
    var _stype = get_stype(_uid)
    return WEAPON_STYPE_DIC.get(_stype).etype.to_lower()

static func get_etype(_uid: String)-> String:
    var _stype = get_stype(_uid)
    return WEAPON_STYPE_DIC.get(_stype).etype