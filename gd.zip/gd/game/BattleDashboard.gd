extends CanvasLayer









const _UPDATE_INTERVAL: float = 0.25
const _TOGGLE_KEY: int = KEY_F6

var _panel: Panel
var _info_label: Label
var _update_accum: float = 0.0

func _ready():
    layer = 100
    visible = false
    _build_ui()

func _build_ui():
    _panel = Panel.new()
    var _style_box = StyleBoxFlat.new()
    _style_box.bg_color = Color(0, 0, 0, 0.55)
    _panel.add_theme_stylebox_override("panel", _style_box)
    _panel.position = Vector2(10, 10)
    _panel.size = Vector2(330, 175)
    add_child(_panel)

    _info_label = Label.new()
    _info_label.position = Vector2(10, 8)
    _info_label.size = Vector2(310, 160)
    _info_label.add_theme_font_size_override("font_size", 13)
    _info_label.add_theme_color_override("font_color", Color(1, 0.95, 0.6))
    _info_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    _info_label.add_theme_constant_override("outline_size", 2)
    _panel.add_child(_info_label)

func _input(_event):
    if _event is InputEventKey and _event.pressed and not _event.echo:
        if _event.keycode == _TOGGLE_KEY:
            visible = not visible

func _process(_delta):
    if not visible:
        return
    _update_accum += _delta
    if _update_accum < _UPDATE_INTERVAL:
        return
    _update_accum = 0.0
    _refresh_text()

func _refresh_text():
    var _fps: int = Engine.get_frames_per_second()
    var _frame_ms: float = 0.0 if _fps <= 0 else 1000.0 / float(_fps)

    var _physics_ms: float = Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
    var _logic_ms: float = Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
    var _draw_calls: int = int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))
    var _node_count: int = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
    var _orphan_count: int = int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT))

    var _text: String = "性能仪表盘 (F6 开关)\n"
    _text += "FPS: %d  (%.1f ms/帧)\n" % [_fps, _frame_ms]
    _text += "物理回调: %.2f ms   逻辑回调: %.2f ms\n" % [_physics_ms, _logic_ms]
    _text += "绘制调用: %d   场景节点: %d\n" % [_draw_calls, _node_count]
    _text += "孤儿节点: %d   物理帧率: %d\n" % [_orphan_count, Engine.physics_ticks_per_second]

    var _soldier_count: int = _count_living_soldiers()
    if _soldier_count >= 0:
        _text += "活跃士兵(战场清单): %d" % _soldier_count

    _info_label.text = _text


func _count_living_soldiers()-> int:
    var _battle_scene = GlobalNode.battle_scene
    if _battle_scene == null or not is_instance_valid(_battle_scene):
        return -1
    var _total: int = 0
    _total += _battle_scene.living_player_soldier_node_list.size()
    _total += _battle_scene.living_enemy_soldier_node_list.size()
    _total += _battle_scene.living_teammate_soldier_node_list.size()
    return _total