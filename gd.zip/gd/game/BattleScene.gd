class_name BattleScene extends Node2D

@onready var soldier_root_node =$ObjectRoot / SoldierRoot
@onready var common_camera_node =$CommonCamera as CommonCamera
@onready var flyer_root_node =$ObjectRoot / FlyerRoot
@onready var bs_solider_count_bar_node =$CanvasLayer / BSSoliderCountBar
@onready var click_effect_node = preload("res://tscn/game/effect/ClickEffect.tscn")
@onready var click_effect_root_node =$ClickEffectRoot

@onready var selector_tool_node =$SelectorTool as SelectorTool
@onready var target_point_show_node =$ClickEffectRoot / TargetPointShow as TargetPointShow
@onready var formation_direction_node =$ClickEffectRoot / FormationDirection as TargetPointShow
@onready var animation_player_node =$AnimationPlayer
@onready var settlement_interface_ani_node =$CanvasLayer / SettlementInterfaceAni as SettlementInterfaceAni
@onready var map_node =$ObjectRoot / Map
@onready var battle_animation_node =$CanvasLayer / BattleAnimation as BattleAnimation
@onready var l_shield_root_node =$ObjectRoot / LShieldRoot
@onready var trophy_interface_node =$CanvasLayer / TrophyInterface as GoodsExchangeInterface
@onready var my_team_morale_box_node =$CanvasLayer / BSSoliderCountBar / MyTeamMoraleBox as MoraleBox
@onready var enemy_morale_box_node =$CanvasLayer / BSSoliderCountBar / EnemyMoraleBox as MoraleBox
@onready var focus_fire_circle_node = preload("res://tscn/game/soldier/FocusFireCircle02.tscn")
@onready var group_card_list_box_node =$CanvasLayer / GroupCardListBox
@onready var soldier_body_effect_node = preload("res://tscn/game/soldier/SoldierBodyEffect.tscn")
@onready var effect_root_node =$ObjectRoot / EffectRoot
@onready var remote_switch_button_node =$CanvasLayer / RightButtonRoot / VBoxContainer / RemoteSwitchButton
@onready var b_cloud_root_node =$ObjectRoot / BCloudRoot
@onready var bird_root_node =$ObjectRoot / BirdRoot
@onready var day_and_night_effect_node =$DayAndNightEffect
@onready var canvas_layer_node: CanvasLayer =$CanvasLayer
@onready var charge_timer_node: Timer =$ChargeTimer
@onready var charge_button_node: BSButton =$CanvasLayer / RightButtonRoot / VBoxContainer / ChargeButton
@onready var formation_prepare_effect_node: FormationPrepareEffect =$CanvasLayer / FormationPrepareEffect
@onready var box_select_button_node: SwitchButton =$CanvasLayer / LeftButtonRoot / VBoxContainer / BoxSelectButton
@onready var move_mode_button_node: SwitchButton =$CanvasLayer / LeftButtonRoot / VBoxContainer / MoveModeButton
@onready var tip_node: Tip =$CanvasLayer / Tip
@onready var time_control_button_node: SwitchButton =$CanvasLayer / LeftButtonRoot / VBoxContainer / TimeControlButton
@onready var shadow_dashed_line_node: ShadowDashedLine =$ObjectRoot / ShadowDashedLine
@onready var formation_title_tip_node: Tip =$CanvasLayer / FormationTitleTip
@onready var battle_start_button_node: BattleStartButton =$CanvasLayer / BattleStartButton
@onready var battle_buff_info_node: BattleBuffInfo =$CanvasLayer / BattleBuffInfo
@onready var bs_buff_list_node: BSBuffList =$CanvasLayer / BSSoliderCountBar / BSBuffList
@onready var auto_invisible_wall_node: AutoInvisibleWall =$AutoInvisibleWall
@onready var battle_sfx_node: BattleSFX =$BattleSFX
@onready var bullet_trajectory_rffect_root: Node2D =$ObjectRoot / BulletTrajectoryRffectRoot
@onready var right_top_button_root_node: Control =$CanvasLayer / RightTopButtonRoot
@onready var pause_run_button_node: CommonButton =$CanvasLayer / RightTopButtonRoot / PauseRunButtonRoot / PauseRunButton
@onready var back_to_main_menu_button_node: CommonButton =$CanvasLayer / RightTopButtonRoot / PauseRunButtonRoot / BackToMainMenuButton
@onready var enemy_ai_node: BattleSceneNpcTeamDefaultAI =$EnemyAI
@onready var ally_ai_node: BattleSceneNpcTeamDefaultAI =$AllyAI
@onready var dialogue_interface_node: DialogueInterface =$CanvasLayer / DialogueInterface

const FIREARM_SHOOT_SMOKE_EFFECT = preload("res://tscn/game/bs/FirearmShootSmokeEffect.tscn")
const BULLET_TRAJECTORY_EFFECT = preload("res://tscn/game/bs/BulletTrajectoryEffect.tscn")
const BS_SOLDIER_PLAYER_HERO_OR_LEADER = preload("res://tscn/game/soldier/BSSoldierPlayerHeroOrLeader.tscn")
const BS_SOLDIER_PLAYER = preload("res://tscn/game/soldier/BSSoldierPlayer.tscn")
const BS_SOLDIER_ENEMY = preload("res://tscn/game/soldier/BSSoldierEnemy.tscn")
const BS_SOLDIER_TEAMMATE = preload("res://tscn/game/soldier/BSSoldierTeammate.tscn")
const BS_SOLDIER_ENEMY_HERO_OR_LEADER = preload("res://tscn/game/soldier/BSSoldierEnemyHeroOrLeader.tscn")
const BS_SOLDIER_TEAMMATE_HERO_OR_LEADER = preload("res://tscn/game/soldier/BSSoldierTeammateHeroOrLeader.tscn")


@export var is_test: bool = false


@export var init_army_distance: int = 0

@export var hide_module: = false
@export var init_camera_offset_x: = 600

@export var init_allow_control: = true
@export var init_camera_slow_move: = false

@export var player_charge_wait_time: = -1

@export var hide_soldier_choose_effect: = false
@export var init_zoom: = 0.0
@export var random_day_or_night: = false

@export var need_settlement: = true

@export var play_draw_sword_sound: = true

@export var formation_mode_range_vector: = Vector2(1000, 1000)

@export var scene_mode: = BattleConstants.BATTLE_SCENE_MODE_ENUM.FORMATION_MODE

@export var scene_mode_use_player_config: = true

@export var init_check_enemy_0_end: = true

@export var is_show_back_to_main_menu_button: bool = false


@export var is_battle_unit_limit: = true


var control_soldier_node_list: = []





var player_soldier_count: = 0
var teammate_soldier_count: = 0
var enemy_soldier_count: = 0



var player_soldier_total: = 0
var teammate_soldier_total: = 0
var enemy_soldier_total: = 0



var player_hero_total: = 0
var teammate_hero_total: = 0
var enemy_hero_total: = 0


var my_team_soldier_morale_item: = 0.0
var my_team_hero_morale_item: = 0.0
var enemy_soldier_morale_item: = 0.0
var enemy_hero_morale_item: = 0.0
var teammate_soldier_morale_item: = 0.0
var teammate_hero_morale_item: = 0.0



var player_die_or_injured_soldier_json_list = []
var teammate_die_or_injured_soldier_json_list = []
var enemy_die_or_injured_soldier_json_list = []

























var mouse_is_clicking = false

var mouse_right_is_clicking = false
var mouse_click_duration_counter = -1
var mouse_click_start_point: Vector2
var mouse_click_start_local_point: Vector2
var is_selector_action = false
var is_set_formation_direction = false

var is_ready = false

var battle_result: String
var current_battle_id: String

var player_is_charge_ready: = false





var _mod_slave_duel_active: bool = false
var _mod_slave_duel_spectator: bool = false

var _mod_duel_map_offset: Dictionary = {}




var search_physics_shape_query_parameters2d_node: = PhysicsShapeQueryParameters2D.new()
var search_circle_shape: = CircleShape2D.new()
var direct_space_state = null
var selecter_radius: = 92


var all_soldier_node: = []
var group_soldier_node_dic: = {}
var group_hero_node_dic: = {}




var living_player_soldier_node_list: = []
var living_enemy_soldier_node_list: = []
var living_teammate_soldier_node_list: = []


var init_map_node: Resource


var is_day: = true

var is_battle_end: = false

var _is_settlement_inited: = false
var is_interface_module_show: = false
var player_center_point: = Vector2.ZERO






var mobile_touch_start: = false

var mobile_touch_duration_counter: = 0
var mobile_initial_positions: = []
var mobile_two_finger_distance: float = 0.0

var mobile_double_click_check_counter: = 0
var mobile_double_click_need_check: = false
var mobile_click_position: = Vector2.ZERO


var mobile_need_check_long_press: = false

var mobile_formation_direction_settings_open: = false


var mobile_box_select_start: = false


var terrain_type: MWorldConstants.TERRAIN_TYPE_ENUM = MWorldConstants.TERRAIN_TYPE_ENUM.FLATLANDS
var is_pause: = false
var origin_camera_zoom: = Vector2.ZERO

var is_custom_map_and_weather: = false






var is_mult_turn_end: = false




var ally_relation_gain_after_battle_factor: = 0.0
var player_leader_soldier_node: BSSoldier

signal back_to_main_menu_sign()

signal change_zoom_sign(_zoom: Vector2)

func _ready():





    if scene_mode_use_player_config:




        update_scene_mode_use_player_config()

    search_physics_shape_query_parameters2d_node.collide_with_areas = false
    search_physics_shape_query_parameters2d_node.collide_with_bodies = true
    search_physics_shape_query_parameters2d_node.collision_mask = 32
    direct_space_state = get_world_2d().direct_space_state
    if hide_module:
        canvas_layer_node.hide()
    if not init_allow_control:
        common_camera_node.func_close()
    if init_camera_slow_move:
        common_camera_node.slow_move = true
    if player_charge_wait_time > 0:
        charge_timer_node.start(player_charge_wait_time)

    origin_camera_zoom = common_camera_node.zoom

    if init_zoom > 0.0:
        common_camera_node.update_zoom_immediately(Vector2(init_zoom, init_zoom))

    formation_prepare_effect_node.update_ani_time(MobileConfig.LONG_PRESS_COUNTER_MIN - MobileConfig.CLICK_TOUCH_DURATION_COUNTER)











    if not GlobalPlayerConfig.is_default_forced_move:

        move_mode_button_node.update_value(false)

    battle_animation_node.play_draw_sword_sound = play_draw_sword_sound


    if not battle_animation_node.is_connected("close_finish", Callable(self, "_on_battle_animation_close_finish")):
        battle_animation_node.connect("close_finish", Callable(self, "_on_battle_animation_close_finish"))
    if not battle_animation_node.is_connected("open_finish", Callable(self, "_on_battle_animation_open_finish")):
        battle_animation_node.connect("open_finish", Callable(self, "_on_battle_animation_open_finish"))

    if is_show_back_to_main_menu_button:
        pause_run_button_node.hide()
        back_to_main_menu_button_node.show()
    else:
        pause_run_button_node.show()
        back_to_main_menu_button_node.hide()






func _physics_process(_delta):
    if CommonUtils.platform_is_mobile():
        if mobile_touch_start:
            mobile_touch_duration_counter += 1

            if mobile_need_check_long_press \
            and mobile_touch_duration_counter == MobileConfig.CLICK_TOUCH_DURATION_COUNTER:
                formation_prepare_effect_node.ani_start(mobile_initial_positions[0])
            elif mobile_need_check_long_press and mobile_touch_duration_counter >= MobileConfig.LONG_PRESS_COUNTER_MIN:


                common_camera_node.update_drag_enabled(false)
                mobile_formation_direction_settings_open = true
                mobile_need_check_long_press = false
                control_soldier_node_list = SoldierUtils.retain_combat_unit(control_soldier_node_list)
                formation_direction_node.set_formation_direction(control_soldier_node_list, get_mouse_position())

        if mobile_double_click_need_check:
            mobile_double_click_check_counter += 1
            if mobile_double_click_check_counter > MobileConfig.DOUBLE_CLICK_COUNTER_MAX:
                mobile_double_click_check_counter = 0
                mobile_double_click_need_check = false


        if mobile_box_select_start:

            if mobile_initial_positions.size() == 1:
                pass
            elif mobile_initial_positions.size() == 2:

                selector_tool_node.update_positions(mobile_initial_positions[0], mobile_initial_positions[1])

            if selector_tool_node.get_is_active():
                var _soldier_list = selector_tool_node.select()
                _choose_soldier(_soldier_list, true)
    else:
        mouse_click_duration_counter += 1
        if is_selector_action:
            var _soldier_list = selector_tool_node.select()
            _choose_soldier(_soldier_list, true)

        if(mouse_is_clicking
            and not is_selector_action

            and CommonUtils.get_distance_square2(mouse_click_start_local_point, get_mouse_local_position()) > BattleSceneConfig.SELECTING_SOLDIERS_BEHAVIOR_DISTANCE_SQUARE
        ):

            is_selector_action = true
            selector_tool_node.start(mouse_click_start_point)
            mouse_click_duration_counter = -1

            group_card_list_box_node.unchoose_all_card()
        if(
            mouse_right_is_clicking
            and not is_set_formation_direction
            and mouse_click_duration_counter > 20
        ):

            control_soldier_node_list = SoldierUtils.retain_combat_unit(control_soldier_node_list)
            is_set_formation_direction = true
            formation_direction_node.set_formation_direction(control_soldier_node_list, mouse_click_start_point)
            mouse_click_duration_counter = -1

func _unhandled_input(event):
    if not is_ready:
        return


    if _mod_slave_duel_spectator:
        return

    if CommonUtils.platform_is_pc():
        _handle_pc_control(event)
    else:
        _handle_mobile_control(event)

func _handle_mobile_control(_event: InputEvent):
    if _event is InputEventScreenTouch:
        if _event.pressed:
            mobile_need_check_long_press = true
            mobile_touch_start = true
            mobile_touch_duration_counter = 0
            if mobile_initial_positions.size() < 2:
                mobile_initial_positions.append(_event.position)

            if mobile_box_select_start:
                mobile_need_check_long_press = false
                group_card_list_box_node.unchoose_all_card()
                selector_tool_node.start(get_mouse_position())
                if mobile_initial_positions.size() >= 2:
                    selector_tool_node.set_custom_position(true)
        else:
            mobile_need_check_long_press = false
            formation_prepare_effect_node.stop()
            if mobile_initial_positions.size() == 1:
                if mobile_formation_direction_settings_open:
                    if _is_formation_mode():
                        if not shadow_dashed_line_node.is_within_range(formation_direction_node.get_refer_point()):
                            _send_message_need_within_formation_range()
                            _add_forbid_click_effect(formation_direction_node.get_refer_point())
                            GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)

                            mobile_formation_direction_settings_open = false
                            common_camera_node.update_drag_enabled(true)
                            formation_direction_node.disappear()
                            if mobile_initial_positions.size() > 0:
                                mobile_initial_positions.clear()
                            return


                    var _position_list = formation_direction_node.get_formation_position_list()

                    if _is_formation_mode():

                        WSData.update_formation_mode_data(
                            player_center_point,
                            group_card_list_box_node.get_choose_group_num_list(),
                            formation_direction_node.get_refer_point(),
                            formation_direction_node.get_direction_vector())

                    var _direction_enum = formation_direction_node.get_direction_enum()
                    _control_move(_position_list, _direction_enum)
                    mobile_formation_direction_settings_open = false
                    common_camera_node.update_drag_enabled(true)

                elif mobile_touch_start \
                and(_event.position - mobile_initial_positions[0]).length_squared() < MobileConfig.CLICK_DISTANCE_MAX_SQUARE:
                    if mobile_touch_duration_counter < MobileConfig.CLICK_TOUCH_DURATION_COUNTER:

                        var _is_double_click: = false
                        if mobile_double_click_need_check \
                        and mobile_click_position.distance_squared_to(_event.position) < MobileConfig.DOUBLE_CLICK_DISTANCE_MAX_SQUARE:
                            _is_double_click = true

                        if not mobile_double_click_need_check:
                            mobile_double_click_need_check = true

                        mobile_click_position = _event.position

                        if _is_double_click:
                            mobile_double_click_need_check = false
                            mobile_double_click_check_counter = 0
                            if move_mode_button_node.get_current_value():
                                _control_attack_move()
                            else:
                                _control_move()
                        else:

                            if move_mode_button_node.get_current_value():
                                _control_move()
                            else:
                                _control_attack_move()

                mobile_touch_start = false

            if mobile_box_select_start:
                mobile_box_select_start = false
                tip_node.chide("请开始框选士兵")
                selector_tool_node.end()
                common_camera_node.update_drag_enabled(true)
                box_select_button_node.update_value(true)
                selector_tool_node.set_custom_position(false)

            if mobile_initial_positions.size() > 0:
                mobile_initial_positions.clear()

    elif _event is InputEventScreenDrag:

        if mobile_need_check_long_press:
            if(_event.position - mobile_initial_positions[0]).length_squared() > MobileConfig.CLICK_DISTANCE_MAX_SQUARE:
                mobile_need_check_long_press = false
                mobile_touch_start = false
                formation_prepare_effect_node.stop()


        if mobile_box_select_start:
            if _event.index == 0:

                mobile_initial_positions[0] = common_camera_node.get_global_position_by_position(_event.position)
            elif _event.index == 1:

                mobile_initial_positions[1] = common_camera_node.get_global_position_by_position(_event.position)

func _handle_pc_control(event)-> void:

    if GameConfig.ENABLE_INSTA_KILL and Input.is_action_pressed("key_k"):
        _insta_kill()

    if MouseUtils.check_mouse_left_click(event):

        _mouse_click_start()
    elif MouseUtils.check_mouse_left_release(event):

        if is_selector_action:
            selector_tool_node.end()

        else:
            if mouse_is_clicking:
                _control_move()

        _mouse_release_clear()
    elif MouseUtils.check_mouse_right_click(event):

        _mouse_right_click_start()
    elif MouseUtils.check_mouse_right_release(event):
        if is_set_formation_direction:
            if _is_formation_mode():
                if not shadow_dashed_line_node.is_within_range(formation_direction_node.get_refer_point()):
                    _send_message_need_within_formation_range()
                    _add_forbid_click_effect(formation_direction_node.get_refer_point())
                    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)
                    _mouse_release_clear()
                    formation_direction_node.disappear()
                    return


            var _position_list = formation_direction_node.get_formation_position_list()

            if _is_formation_mode():

                WSData.update_formation_mode_data(
                    player_center_point,
                    group_card_list_box_node.get_choose_group_num_list(),
                    formation_direction_node.get_refer_point(),
                    formation_direction_node.get_direction_vector())

            var _direction_enum = formation_direction_node.get_direction_enum()
            _control_move(_position_list, _direction_enum)
        else:

            _control_attack_move()

        _mouse_release_clear()

func _is_formation_mode():
    return scene_mode == BattleConstants.BATTLE_SCENE_MODE_ENUM.FORMATION_MODE


func _control_attack_move():
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_RIGHT)
    var _target_vector_list = _team_move(control_soldier_node_list, get_mouse_position(), true);

    if not _is_formation_mode():
        _add_target_point_show_effect(_target_vector_list, get_mouse_position(), CommonConstants.COLOR_ENUM.ATTACK_COLOR)

        var is_focus_success: bool = _handle_focus_fire()
        if CommonUtils.is_not_null(player_leader_soldier_node):
            if is_focus_success:
                player_leader_soldier_node.custom_attack_chat()
            else:
                player_leader_soldier_node.custom_move_chat()


func _insta_kill()-> void:
    if ArrayUtils.is_not_empty(living_player_soldier_node_list) \
    and ArrayUtils.is_not_empty(living_enemy_soldier_node_list):

        var _attack_origin_bs_soldier: BSSoldier = living_player_soldier_node_list[0]
        for _soldier_node: BSSoldier in living_enemy_soldier_node_list:
            _soldier_node.hurt(
                100000, _attack_origin_bs_soldier.bs_soldier_prop.get_attack_type(),
                _attack_origin_bs_soldier, _soldier_node.global_position - _attack_origin_bs_soldier.global_position,
                _attack_origin_bs_soldier.bs_soldier_prop.weapon_special_attr_dic,
                false, true
            )


func init_map(_map_node: Resource):
    init_map_node = _map_node

func init_by_battle_id(_battle_id)-> void:
    current_battle_id = _battle_id



    var _battle_data: Dictionary = WSData.get_battle_data(_battle_id)





    if CommonUtils.get_value(_battle_data, "mod_slave_duel", false):
        _mod_slave_duel_active = true
        _mod_slave_duel_spectator = bool(_battle_data.get("duel_spectator", false))
        is_test = true
        is_battle_unit_limit = false
        GlobalTempData.reset_mult_battle_data()
        if _mod_slave_duel_spectator:
            init_maybe_mult_turn(
                [],
                (_battle_data.get("enemy_team",[]) as Array).duplicate(true),
                (_battle_data.get("teammate_team",[]) as Array).duplicate(true)
            )
        else:
            init_maybe_mult_turn(
                (_battle_data.get("ally_team",[]) as Array).duplicate(true),
                (_battle_data.get("enemy_team",[]) as Array).duplicate(true),
                []
            )
        if _mod_slave_duel_spectator:

            var _map_size: Vector2 = _get_map_size()
            common_camera_node.move_immediately(Vector2(
                float(_mod_duel_map_offset.get("left", 0)) + _map_size.x / 2.0,
                float(_mod_duel_map_offset.get("top", 0)) + _map_size.y / 2.0
            ))
        return
    var _load_by_team_node: bool = CommonUtils.get_value(_battle_data, "load_by_team_node", true)
    if _load_by_team_node:
        var _team_node_info = WSData.get_battle_team_type_info(_battle_id, WSData.get_player_team_node().get_uid())
        init_by_team_node(_team_node_info.enemy, _team_node_info.ally)
    else:

        init_by_enemy_team_data(_battle_data.enemy_team)


func init_by_enemy_team_data(_enemy_team: Array)-> void:


    GlobalTempData.mult_battle_enemy_combat_power_total = SoldierUtils.get_combat_power_total_by_simple_json_list(_enemy_team)

    var _player_combat_power: int = WSData.get_player_combat_power()








    GlobalTempData.mult_battle_victory_reputation_value = BattleSceneUtils.get_reputation_value(
        _player_combat_power,
        GlobalTempData.mult_battle_enemy_combat_power_total,
        0
    )


    init_maybe_mult_turn(
        WSData.get_player_team_simple_json_list(),
        _enemy_team,[]
    )

func init_by_team_node(
    _enemy_team_node_list,
    _ally_team_node_list
):
    GlobalTempData.mult_battle_enemy_team_node_list = _enemy_team_node_list
    GlobalTempData.mult_battle_ally_team_node_list = _ally_team_node_list


    GlobalTempData.mult_battle_enemy_combat_power_total = \
    TeamUtils.get_combat_power_total(_enemy_team_node_list, false)


    var _player_combat_power: int = WSData.get_player_combat_power()
    var _allies_combat_power: int = TeamUtils.get_combat_power_total(_ally_team_node_list, false)
    GlobalTempData.mult_battle_ally_combat_power_total = _allies_combat_power

    GlobalTempData.mult_battle_victory_reputation_value = BattleSceneUtils.get_reputation_value(
        _player_combat_power,
        GlobalTempData.mult_battle_enemy_combat_power_total,
        _allies_combat_power
    )

    var _enemy_simple_json_list = TeamUtils.get_simple_json_list(_enemy_team_node_list)
    var _ally_simple_json_list = TeamUtils.get_simple_json_list(_ally_team_node_list)



    init_maybe_mult_turn(
        WSData.get_player_team_simple_json_list(),
        _enemy_simple_json_list,
        _ally_simple_json_list
    )

var custom_map_weather_info: = {}

func init_map_weather(_map_key: String, _weather_key: String)-> void:
    is_custom_map_and_weather = true


    var _day_or_night_info = {}
    var _weather = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR
    if _weather_key == "random":
        _day_or_night_info = GlobalNode.get_random_day_and_night_info()
        _weather = CommonUtils.random_enum(MWorldConstants.WEATHER_TYPE_ENUM)
    else:
        var _weather_config: Dictionary = MWorldConstants.WEATHER_CONFIG.get(_weather_key)
        _day_or_night_info = {
            "color": _weather_config.color,
            "is_day": _weather_config.is_day,
        }
        _weather = _weather_config.weather

    custom_map_weather_info.day_or_night_info = _day_or_night_info
    custom_map_weather_info.weather = _weather


    var _map_path: = ""
    if _map_key == "random":
        _map_path = MapConstants.MAP_CONFIG.values().pick_random().path
    else:
        _map_path = MapConstants.MAP_CONFIG.get(_map_key).path

    custom_map_weather_info.map_path = _map_path
    init_map_node = load(_map_path)

func _filter_living_not_busy_simple_json_list()-> void:
    GlobalTempData.mult_battle_player_simple_json_list = TeamUtils.list_living_and_not_busy_simple_json(
        GlobalTempData.mult_battle_player_simple_json_list
    )
    GlobalTempData.mult_battle_enemy_simple_json_list = TeamUtils.list_living_and_not_busy_simple_json(
        GlobalTempData.mult_battle_enemy_simple_json_list
    )
    GlobalTempData.mult_battle_ally_simple_json_list = TeamUtils.list_living_and_not_busy_simple_json(
        GlobalTempData.mult_battle_ally_simple_json_list
    )

func init_maybe_mult_turn(
    _player_simple_json_list: Array,
    _enemy_simple_json_list: Array,
    _ally_simple_json_list: Array,


)-> void:

    if not is_battle_unit_limit:

        init(_player_simple_json_list, _enemy_simple_json_list, _ally_simple_json_list)
        return

    if GlobalTempData.mult_battle_is_first_init:
        GlobalTempData.mult_battle_player_simple_json_list = _player_simple_json_list
        GlobalTempData.mult_battle_enemy_simple_json_list = _enemy_simple_json_list
        GlobalTempData.mult_battle_ally_simple_json_list = _ally_simple_json_list
        GlobalTempData.mult_battle_is_first_init = false

    if GlobalTempData.mult_battle_need_filter_living_not_busy:
        _filter_living_not_busy_simple_json_list()
        GlobalTempData.mult_battle_need_filter_living_not_busy = false



    var _turn_sides_soldier_info: Dictionary = TeamUtils.get_turn_sides_soldier_info(
        GlobalPlayerConfig.get_battle_unit_limit(),
        GlobalTempData.mult_battle_player_simple_json_list,
        GlobalTempData.mult_battle_ally_simple_json_list,
        GlobalTempData.mult_battle_enemy_simple_json_list
    )


    init(
        _turn_sides_soldier_info.player_simple_json_list,
        _turn_sides_soldier_info.enemy_simple_json_list,
        _turn_sides_soldier_info.ally_simple_json_list,
    )


func init(_player_simple_json_list: Array, _enemy_simple_json_list: Array, _ally_simple_json_list: = []):

    _player_simple_json_list = TeamUtils.list_living_and_not_busy_simple_json(_player_simple_json_list)
    _enemy_simple_json_list = TeamUtils.list_living_and_not_busy_simple_json(_enemy_simple_json_list)
    _ally_simple_json_list = TeamUtils.list_living_and_not_busy_simple_json(_ally_simple_json_list)


    if init_army_distance <= 0:
        init_army_distance = BattleSceneUtils.get_army_distance(
            _player_simple_json_list.size() + _enemy_simple_json_list.size() + _ally_simple_json_list.size()
        )


    var day_or_night_info: Dictionary = {}
    if random_day_or_night:
        day_or_night_info = GlobalNode.get_random_day_and_night_info()
    else:
        day_or_night_info = GlobalNode.get_day_and_night_info()

    if is_custom_map_and_weather:
        day_or_night_info = custom_map_weather_info.day_or_night_info

    day_and_night_effect_node.color = day_or_night_info.color
    is_day = day_or_night_info.is_day


    var _weather: MWorldConstants.WEATHER_TYPE_ENUM = WSData.get_player_weather()

    if _weather != MWorldConstants.WEATHER_TYPE_ENUM.CLEAR \
    and WSData.get_player_terrain_type() == MWorldConstants.TERRAIN_TYPE_ENUM.DESERT:
        _weather = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR

    if is_custom_map_and_weather:
        _weather = custom_map_weather_info.weather

    var _init_player_count = _player_simple_json_list.size()
    var _init_teammate_count = _ally_simple_json_list.size()
    var _init_enemy_count = _enemy_simple_json_list.size()


    var _map_info: = MapUtils.get_map_info(
        WSData.get_player_terrain_type(),
        _init_player_count + _init_teammate_count + _init_enemy_count
    )
    auto_invisible_wall_node.init(
        _map_info.corner_positions[0],
        _map_info.corner_positions[1],
        _map_info.corner_positions[2],
        _map_info.corner_positions[3],
    )

    var _map_instance = _map_info.map_node.instantiate()

    if is_test and init_map_node != null:
        _map_instance = init_map_node.instantiate()

    map_node.add_child(_map_instance)
    terrain_type = _map_instance.terrain_type
    _map_instance.update_weather(_weather)
    GlobalSoundManager.handle_weather_sfx(_weather)



    var _map_size: Vector2 = _map_info.map_size
    var _map_offset: Dictionary = _map_info.offset
    common_camera_node.set_limit_custom2(_map_offset)

    _mod_duel_map_offset = _map_offset

    player_soldier_count = _init_player_count
    player_soldier_total = _init_player_count


    for _index in range(_init_player_count):
        var _simple_json: Dictionary = _player_simple_json_list[_index]

        var _bs_soldier_player_instance

        if SoldierUtils.is_hero_or_leader(_simple_json):
            player_hero_total += 1
            _bs_soldier_player_instance = BS_SOLDIER_PLAYER_HERO_OR_LEADER.instantiate()
            if CommonUtils.is_null(player_leader_soldier_node):
                player_leader_soldier_node = _bs_soldier_player_instance

            if SoldierUtils.is_leader(_simple_json):
                player_leader_soldier_node = _bs_soldier_player_instance
        else:
            _bs_soldier_player_instance = BS_SOLDIER_PLAYER.instantiate()

        soldier_root_node.add_child(_bs_soldier_player_instance)
        _connect_soldier_sign(_bs_soldier_player_instance)
        _bs_soldier_player_instance.init(_simple_json, is_day, _weather)
        all_soldier_node.append(_bs_soldier_player_instance)
        control_soldier_node_list.append(_bs_soldier_player_instance)
        living_player_soldier_node_list.append(_bs_soldier_player_instance)
        _handle_group_soldier_node_dic(_bs_soldier_player_instance)

    player_center_point = Vector2(
        _map_offset.left +(_map_size.x - init_army_distance) / 2,
        _map_offset.top + _map_size.y / 2
    )


    _choose_soldier(control_soldier_node_list)

    var _target_vector_list = SoldierUtils.soldier_formation2(
        control_soldier_node_list,
        player_center_point,
        Vector2.RIGHT,
    )


    for _index in range(control_soldier_node_list.size()):
        control_soldier_node_list[_index].global_position = _target_vector_list[_index]

    if not WSData.formation_mode_data.is_empty():
        _load_formation_mode_data()


    common_camera_node.move_immediately(player_center_point + Vector2(init_camera_offset_x, 0))


    if _is_formation_mode():
        shadow_dashed_line_node.cshow()
        shadow_dashed_line_node.init(player_center_point, formation_mode_range_vector)

    if player_is_charge_ready:
        for _player_soldier_node in control_soldier_node_list:
            _player_soldier_node.charge()


    teammate_soldier_count = _init_teammate_count
    teammate_soldier_total = _init_teammate_count
    if ArrayUtils.is_not_empty(_ally_simple_json_list):

        for _index: int in range(_ally_simple_json_list.size()):
            var _bs_soldier_teammate_instance: BSSoldier
            if SoldierUtils.is_hero_or_leader(_ally_simple_json_list[_index]):
                _bs_soldier_teammate_instance = BS_SOLDIER_TEAMMATE_HERO_OR_LEADER.instantiate()
            else:
                _bs_soldier_teammate_instance = BS_SOLDIER_TEAMMATE.instantiate()

            soldier_root_node.add_child(_bs_soldier_teammate_instance)
            _connect_soldier_sign(_bs_soldier_teammate_instance)

            _bs_soldier_teammate_instance.init(_ally_simple_json_list[_index], is_day, _weather)

            living_teammate_soldier_node_list.append(_bs_soldier_teammate_instance)
            if SoldierUtils.is_hero_or_leader2(_bs_soldier_teammate_instance):
                teammate_hero_total += 1





























    enemy_soldier_count = _init_enemy_count
    enemy_soldier_total = _init_enemy_count

    for _index: int in range(_init_enemy_count):

        var _bs_soldier_enemy_instance: BSSoldier
        if SoldierUtils.is_hero_or_leader(_enemy_simple_json_list[_index]):
            _bs_soldier_enemy_instance = BS_SOLDIER_ENEMY_HERO_OR_LEADER.instantiate()
        else:
            _bs_soldier_enemy_instance = BS_SOLDIER_ENEMY.instantiate()

        soldier_root_node.add_child(_bs_soldier_enemy_instance)
        _connect_soldier_sign(_bs_soldier_enemy_instance)

        _bs_soldier_enemy_instance.init(_enemy_simple_json_list[_index], is_day, _weather)

        living_enemy_soldier_node_list.append(_bs_soldier_enemy_instance)
        if SoldierUtils.is_hero_or_leader2(_bs_soldier_enemy_instance):
            enemy_hero_total += 1






    var _mod_is_guard_battle: = false
    var _mod_is_defender_battle: = false
    # 只有玩家显式选择"进攻村庄"的目标守军参战时, 才启用村庄布防(栅栏);
    # 其余情况(包括附近守军被卷入的野战)一律不布防
    var _mod_assault_target_uid: String = GlobalNode._mod_village_assault_target_uid
    if not current_battle_id.is_empty() and _mod_assault_target_uid != "":
        var _enemy_teams = WSData.get_team_node_by_battle_id(current_battle_id, MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2)
        for _team_node in _enemy_teams:
            if is_instance_valid(_team_node) and _team_node.get_uid() == _mod_assault_target_uid \
            and _team_node._is_village_garrison():
                _mod_is_guard_battle = true
                if _team_node.json.get("leader_uid", "") == "village_defender":
                    _mod_is_defender_battle = true

    GlobalNode._mod_village_assault_target_uid = ""

    GlobalNode._mod_village_guard_battle = _mod_is_guard_battle
    GlobalNode._mod_village_defender_battle = _mod_is_defender_battle

    if _mod_is_guard_battle and not _mod_is_defender_battle:
        var _camera_center: Vector2 = Vector2(
            _map_offset.left + _map_size.x / 2.0,
            _map_offset.top + _map_size.y / 2.0
        )
        var _guard_rect: Rect2 = Rect2(
            _camera_center.x + 700, _camera_center.y - 900,
            2200, 1800
        )
        for _enemy_node in living_enemy_soldier_node_list:
            _enemy_node.guard_rect = _guard_rect



    if _mod_is_guard_battle:
        GlobalNode._mod_recreate_obstacles(self)


    ally_ai_node.init(
            living_teammate_soldier_node_list,
            Vector2(
                _map_offset.left +(_map_size.x - init_army_distance) / 2,
                _map_offset.top +(_map_size.y / 2) + 250
            ),
            living_enemy_soldier_node_list,
            MWTeamConstants.TEAM_REL_TYPE_ENUM.ALLIED
        )

    enemy_ai_node.init(
        living_enemy_soldier_node_list,
        Vector2(
            _map_offset.left + _map_size.x -(_map_size.x - init_army_distance) / 2,
            _map_offset.top + _map_size.y / 2,
        ),

        ArrayUtils.append_to_new_list(
            living_player_soldier_node_list,
            living_teammate_soldier_node_list,
        ),
        MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE
    )


    for _soldier_node: BSSoldierEnemy in living_enemy_soldier_node_list:
        _soldier_node.update_direction2(Vector2.LEFT)





    bs_solider_count_bar_node.init(_init_player_count, _init_enemy_count, _init_teammate_count);


    _init_morale()


    _init_group_card()

    group_card_list_box_node.choose_all_card()


    if _is_formation_mode():
        _formation_mode_ani()
    else:



        if is_test:
            _battle_animation_open()


    b_cloud_root_node.init(Vector2(6000, 3600))
    bird_root_node.init(Vector2(6000, 3600))


    b_cloud_root_node.open_or_close_by_weather(_weather)
    bird_root_node.open_or_close_by_weather(_weather)


    if not _is_formation_mode() and _init_enemy_count <= 0:
        _goto_battle_end(BattleConstants.BATTLE_RESULT_ENUM.VICTORY)

func transition_ani_fade_in_follow()-> void:
    if not _is_formation_mode():
        _battle_animation_open()











    if scene_mode == BattleConstants.BATTLE_SCENE_MODE_ENUM.BATTLE_MODE \
    and GlobalPlayerConfig.is_show_button_tip:
        _show_button_tip()

func allow_control_battle(_allow_control: bool = true)-> void:
    if _allow_control:

        init_camera_slow_move = false
        init_allow_control = true
        hide_module = false

        player_charge_wait_time = 0
        hide_soldier_choose_effect = false

        charge_timer_node.stop()
        canvas_layer_node.show()
        if not is_battle_end:
            common_camera_node.func_open()

        common_camera_node.slow_move = false
        battle_animation_node.play_draw_sword_sound = true

    else:
        init_camera_slow_move = true
        init_allow_control = false
        hide_module = true

        hide_soldier_choose_effect = true

        canvas_layer_node.hide()
        common_camera_node.func_close()
        common_camera_node.slow_move = true
        battle_animation_node.play_draw_sword_sound = false


func update_scene_mode_use_player_config()-> void:
    if GlobalPlayerConfig.enable_pre_battle_deployment:
        scene_mode = BattleConstants.BATTLE_SCENE_MODE_ENUM.FORMATION_MODE
        time_control_button_node.hide()
        move_mode_button_node.hide()
        box_select_button_node.hide()
        battle_start_button_node.show()
        group_card_list_box_node.modulate.a = 1.0
    else:
        scene_mode = BattleConstants.BATTLE_SCENE_MODE_ENUM.BATTLE_MODE
        _button_hide_or_show()

func update_is_for_start_interface_battle(_is_for_start_interface_battle: bool)-> void:
    settlement_interface_ani_node.update_is_for_start_interface_battle(
        _is_for_start_interface_battle
    )


func _battle_animation_open()-> void:
    battle_animation_node.open()

    _handle_terrain_buff()


func _handle_terrain_buff()-> void:
    match terrain_type:
        MWorldConstants.TERRAIN_TYPE_ENUM.DESERT:
            var _buff_info: Dictionary = MWorldConstants.TERRAIN_BUFF_CONFIG.get(
                MWorldConstants.TERRAIN_BUFF_ENUM.DESERT
            )
            battle_buff_info_node.show_and_play_ani(
                _buff_info.icon_path, _buff_info.content
            )
            bs_buff_list_node.add_icon(_buff_info.small_icon_path)

func _button_hide_or_show()-> void:
    if GlobalPlayerConfig.is_show_time_control_button:
        time_control_button_node.show()
    else:
        time_control_button_node.hide()

    if GlobalPlayerConfig.is_show_move_mode_button:
        move_mode_button_node.show()
    else:
        move_mode_button_node.hide()

    if GlobalPlayerConfig.is_show_box_select_button:
        box_select_button_node.show()
    else:
        box_select_button_node.hide()

func _goto_battle_end(_battle_result_enum: String)-> void:





    if is_battle_end:
        return


    if _battle_result_enum == BattleConstants.BATTLE_RESULT_ENUM.VICTORY:
        for _node in living_enemy_soldier_node_list:
            if _node is BSSoldier and _node.simple_json.has("uid") and _node.simple_json.uid == "mod_boss_conquest_knight":
                if _node.mod_boss_invulnerable:
                    print("[Mod] BOSS阶段转换中, 阻止战斗结束")
                    return

    is_battle_end = true
    battle_result = _battle_result_enum




    if _mod_slave_duel_active:
        DialogueCustomUtils.duel_host_on_visual_battle_end(
            _battle_result_enum == BattleConstants.BATTLE_RESULT_ENUM.VICTORY
        )
        is_ready = false
        _is_settlement_inited = true
        _close_terrain_buff()
        _interface_module_disappear()
        common_camera_node.func_close()
        GlobalTimeControl.time_normal()
        var _duel_end_timer: SceneTreeTimer = get_tree().create_timer(1.5)
        _duel_end_timer.timeout.connect(_mod_slave_duel_back_to_world)
        return



    if _battle_result_enum == BattleConstants.BATTLE_RESULT_ENUM.VICTORY:

        if CommonUtils.is_not_null(player_leader_soldier_node):
            player_leader_soldier_node.custom_vectory_chat()

        if CommonUtils.is_not_null(ally_ai_node.get_leader_soldier_node()):
            ally_ai_node.get_leader_soldier_node().custom_vectory_chat()


        AchievementMetaDataUtils.plus_battle_win_count(1)
    else:
        if CommonUtils.is_not_null(enemy_ai_node.get_leader_soldier_node()):
            enemy_ai_node.get_leader_soldier_node().custom_vectory_chat()

    _save_soldier_data()





    _handle_is_need_contine_mult_turn()



    _battle_settlement()



    _close_terrain_buff()





func _mod_slave_duel_back_to_world()-> void:
    if WSData.has_battle_id(current_battle_id):
        WSData.delete_battle_data(current_battle_id)
    _on_trophy_interface_close_sign()


func _handle_player_help_npc_plus_relation_value()-> void:
    if _is_player_help_npc():
        ally_relation_gain_after_battle_factor = \

        minf(GlobalTempData.mult_battle_enemy_combat_power_total * 1.0 / GlobalTempData.mult_battle_ally_combat_power_total, 5.0) \

        *(GlobalTempData.mult_battle_player_kill_soldier_combat_power_total * 1.0 / GlobalTempData.mult_battle_enemy_combat_power_total) \

        * minf((1 +(GlobalTempData.mult_battle_enemy_combat_power_total * 1.0 / 8000)), 3.0) \

        +(GlobalTempData.mult_battle_player_kill_soldier_combat_power_total * 1.0 / 4000)
    else:
        ally_relation_gain_after_battle_factor = 0

    BattleUtils.add_battle_data_prop(
        current_battle_id, "ally_relation_gain_after_battle_factor",
        ally_relation_gain_after_battle_factor
    )


func _is_player_help_npc()-> bool:
    var _battle_data: Dictionary = BattleUtils.get_battle_data(current_battle_id)
    if not _battle_data.has("option_type"):
        return false

    return[
        DialogueConstants.OPTION_TYPE_ENUM.BATTLE_HELP_TEAM1, DialogueConstants.OPTION_TYPE_ENUM.BATTLE_HELP_TEAM2
    ].has(_battle_data.option_type)

func _handle_is_need_contine_mult_turn()-> void:
    if not is_battle_unit_limit:
        is_mult_turn_end = true

    if is_mult_turn_end:
        return

    _filter_living_not_busy_simple_json_list()

    if ArrayUtils.is_empty(GlobalTempData.mult_battle_enemy_simple_json_list):
        is_mult_turn_end = true

    if ArrayUtils.is_empty(GlobalTempData.mult_battle_player_simple_json_list) \
    and ArrayUtils.is_empty(GlobalTempData.mult_battle_ally_simple_json_list):
        is_mult_turn_end = true















func _contine_mult_turn()-> void:
    GlobalTempData.mult_battle_current_round_num += 1


    GlobalNode.game_root.contine_mult_turn_battle_ani(current_battle_id)


func _load_formation_mode_data()-> void:
    if WSData.formation_mode_data.is_empty():
        return

    for _group_num_list: Array in WSData.formation_mode_data.keys():
        var _data: Dictionary = WSData.formation_mode_data.get(_group_num_list)
        var _soldier_node_list: Array = _list_soldier_node_by_group_num_list(_group_num_list)
        _soldier_node_list.sort_custom(SortUtils.sort_by_sort_desc)
        var _target_vector_list = SoldierUtils.soldier_formation2(
            _soldier_node_list,
            player_center_point + _data.relative_point,
            _data.direction_vector,
        )


        for _index in range(_soldier_node_list.size()):
            _soldier_node_list[_index].global_position = _target_vector_list[_index]

func _show_button_tip()-> void:
    time_control_button_node.show_tip()
    move_mode_button_node.show_tip()
    box_select_button_node.show_tip()
    charge_button_node.show_tip()
    remote_switch_button_node.show_tip()

func add_flyer(_node: Flyer):


    if _node.get_parent() != null:
        if _node.get_parent() == flyer_root_node:
            return
        _node.get_parent().remove_child(_node)
    flyer_root_node.add_child(_node)


func add_horse_raise_dust(_global_position: Vector2, _direction_opposite: bool = false):
    _add_effect(BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.HORSE_RAISE_DUST, _global_position, _direction_opposite)

func add_walk_raise_dust(_global_position: Vector2, _direction_opposite: bool = false):
    _add_effect(BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.WALK_RAISE_DUST, _global_position, _direction_opposite)

func get_mouse_position():
    return common_camera_node.get_global_mouse_position()

func get_mouse_local_position():
    return common_camera_node.get_local_mouse_position()

func get_max_xy():
    return map_node.get_children()[0].get_max_xy()


func add_l_shield(_l_shield_place_node: LShieldPlace):
    l_shield_root_node.add_child(_l_shield_place_node)


func get_flee_target(_origin_point: Vector2)-> Vector2:
    var _map_size = _get_map_size()
    var _extra_distance = 500
    var _target_point_list: Array[Vector2] = [



        Vector2(_map_size.x + _extra_distance, _origin_point.y),



        Vector2(0 - _extra_distance, _origin_point.y),
    ]

    var _target_point: Vector2 = CommonUtils.get_nearest_point(_target_point_list, _origin_point)

    return CommonUtils.random_position(_target_point + Vector2(-500, -500), _target_point + Vector2(500, 500))

func check_out_map_edge(_position: Vector2):
    var _map_size = _get_map_size()
    var _a = 64
    if _position.x < 0 + _a or _position.x > _map_size.x - _a \
    or _position.y < 0 + _a or _position.y > _map_size.y - _a:
        return true

    return false


func list_search_target_soldier_node(_enemy_group_list: Array):
    var _result: = []
    if _enemy_group_list.has(BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP):
        _result.append_array(living_player_soldier_node_list)

    if _enemy_group_list.has(BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP):
        _result.append_array(living_enemy_soldier_node_list)

    if _enemy_group_list.has(BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP):
        _result.append_array(living_teammate_soldier_node_list)

    return _result

func set_camera_position_x_plus(_x_dif: int)-> void:
    common_camera_node.set_position_x_plus(_x_dif)


func charge(_show_icon: bool = false)-> void:
    for _soldier_node in control_soldier_node_list:
        _soldier_node.charge(_show_icon)

func camera_disable(_disable: bool)-> void:
    common_camera_node.enabled = not _disable

func get_camera_zoom()-> float:
    return common_camera_node.zoom.x

func maybe_get_sfx_steam(_sfx_type_enum: BattleSFX.SFX_TYPE_ENUM):
    return battle_sfx_node.maybe_get_sfx_steam(_sfx_type_enum)



func create_firearm_shoot_effect(_soldier_position: Vector2, _end_position: Vector2)-> void:

    var _smoke_node: FirearmShootSmokeEffect = FIREARM_SHOOT_SMOKE_EFFECT.instantiate()
    effect_root_node.add_child(_smoke_node)
    _smoke_node.init(_soldier_position, _end_position.x < _soldier_position.x)


    var _effect_node: BulletTrajectoryEffect = BULLET_TRAJECTORY_EFFECT.instantiate()
    bullet_trajectory_rffect_root.add_child(_effect_node)
    _effect_node.init(_smoke_node.get_muzzle_position(), _end_position)


func create_misfire_effect(_soldier_position: Vector2, is_mirrored: = false)-> void:

    var _smoke_node: FirearmShootSmokeEffect = FIREARM_SHOOT_SMOKE_EFFECT.instantiate()
    effect_root_node.add_child(_smoke_node)
    _smoke_node.misfire_effect(_soldier_position, is_mirrored)

func reset_camera_zoom()-> void:
    common_camera_node.update_zoom_immediately(origin_camera_zoom)

func show_or_hide_soldier_select_effect(_is_show: bool)-> void:
    for _soldier_node: BSSoldier in control_soldier_node_list:
        if _is_show:
            _soldier_node.choose()
        else:
            _soldier_node.unchoose()

func _formation_mode_ani()-> void:
    battle_animation_node.formation_start_ani()
    formation_title_tip_node.show()

func _handle_group_soldier_node_dic(_soldier_node: BSSoldier):
    var _group_num = WSData.get_group_num(_soldier_node.get_split_group_uid())
    if group_soldier_node_dic.has(_group_num):
        group_soldier_node_dic.get(_group_num).append(_soldier_node)
    else:
        group_soldier_node_dic[_group_num] = [_soldier_node]

    if SoldierUtils.is_hero_or_leader2(_soldier_node):
        if group_hero_node_dic.has(_group_num):
            group_hero_node_dic.get(_group_num).append(_soldier_node)
        else:
            group_hero_node_dic[_group_num] = [_soldier_node]

func _add_effect(
    _effect_name_enum: String, _global_position: Vector2,
    _direction_opposite: = false
):
        var soldier_body_effect_instance = soldier_body_effect_node.instantiate()
        effect_root_node.add_child(soldier_body_effect_instance)
        soldier_body_effect_instance.global_position = _global_position

        if _direction_opposite:
            soldier_body_effect_instance.flip_h = true

        soldier_body_effect_instance.animation_play(_effect_name_enum)

func _init_group_card():
    var _init_data = {}
    for _key: int in group_soldier_node_dic.keys():
        var _hero_node_list = []
        if group_hero_node_dic.has(_key):
            _hero_node_list = group_hero_node_dic.get(_key)

        _init_data[_key] = {
            "group_num": _key,
            "nop": group_soldier_node_dic.get(_key).size(),
            "hero_node_list": _hero_node_list
        }

    group_card_list_box_node.init(_init_data)


func _get_map_size():
    return map_node.get_children()[0].get_size()


func _handle_focus_fire()-> bool:
    var focus_fire_circle_instance = focus_fire_circle_node.instantiate() as FocusFireCircle02
    click_effect_root_node.add_child(focus_fire_circle_instance)
    focus_fire_circle_instance.global_position = get_mouse_position()
    focus_fire_circle_instance.start()


    var _node_list = SoldierUtils.select_node_circle(
        search_physics_shape_query_parameters2d_node, search_circle_shape,
        direct_space_state, get_mouse_position(), selecter_radius
    )

    var _target_node_list = []
    for _unit in _node_list:
        var _collider = _unit.collider
        if(
            SoldierUtils.is_living_by_soldier_node(_collider)
            and _collider.is_in_group(BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP)
        ):
            _target_node_list.append(_collider)


    for _node in _target_node_list:
        if _node is BSSoldier:
            _node.focus_effect()


    _change_attack_target(_target_node_list)

    return ArrayUtils.is_not_empty(_target_node_list)


func _change_attack_target(_target_node_list):
    for _node: BSSoldier in control_soldier_node_list:
        _node.set_attack_target_list(_target_node_list)

func _team_move(_soldier_node_list: Array, _target_position, need_se = false, _direction_enum = null):
    _soldier_node_list = SoldierUtils.retain_combat_unit(_soldier_node_list)

    var _target_vector_list: Array = []
    if _is_formation_mode():













        if not shadow_dashed_line_node.is_within_range(_target_position):
            _send_message_need_within_formation_range()
            _add_forbid_click_effect()
            return


        WSData.update_formation_mode_data(
            player_center_point,
            group_card_list_box_node.get_choose_group_num_list(),
            _target_position
        )

        _target_vector_list = SoldierUtils.soldier_formation2(
            _soldier_node_list, _target_position, Vector2.RIGHT,
        )
    else:

        var _center_position = SoldierUtils.get_center_position(_soldier_node_list)
        _target_vector_list = SoldierUtils.soldier_formation2(
            _soldier_node_list, _target_position, _target_position - _center_position,
        )

    return _team_move2(_soldier_node_list, _target_vector_list, need_se)

func _send_message_need_within_formation_range():
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.DEPLOY_NEED_WITHIN_THE_RANGE)



func _team_move2(_soldier_node_list, _target_vector_list, need_se = false, _direction_enum = null):
    if _is_formation_mode():
        for _index in range(_soldier_node_list.size()):
            _soldier_node_list[_index].position = _target_vector_list[_index]

        return _target_vector_list

    for _index in range(_soldier_node_list.size()):
        _soldier_node_list[_index].cancel_charge()

        if need_se:
            _soldier_node_list[_index].move_and_se(_target_vector_list[_index], true, _direction_enum)
        else:
            _soldier_node_list[_index].move_to_target(_target_vector_list[_index], true, CommonConstants.COLOR_ENUM.WHITE, _direction_enum)

    return _target_vector_list

func _connect_soldier_sign(_bs_soldier_node):
    _bs_soldier_node.connect("soldier_die_sign", _soldier_die)



func _soldier_die(
    _bs_group: String,
    _soldier_json: Dictionary,
    _murderer_bgroup: String,
    _is_flee_success: = false,
    _soldier_node: Node = null):
    var _json = _soldier_json

    var _plus_morale: = 0.0
    match _bs_group:
        BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP:
            player_soldier_count -= 1
            bs_solider_count_bar_node.update_player_count(player_soldier_count)
            player_die_or_injured_soldier_json_list.append(_json)
            _plus_morale = _get_plus_morale(_soldier_json, - my_team_soldier_morale_item, - my_team_hero_morale_item)
            group_card_list_box_node.update_count(SoldierUtils.get_split_group_uid(_soldier_json), -1)

            if _soldier_node != null and living_player_soldier_node_list.has(_soldier_node):
                living_player_soldier_node_list.erase(_soldier_node)
            else:
                living_player_soldier_node_list = SoldierUtils.list_living_soldier_node(living_player_soldier_node_list)
        BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP:
            enemy_soldier_count -= 1
            bs_solider_count_bar_node.update_enemy_count(enemy_soldier_count)
            enemy_die_or_injured_soldier_json_list.append(_json)
            _plus_morale = _get_plus_morale(_soldier_json, - enemy_soldier_morale_item, - enemy_hero_morale_item)

            if _soldier_node != null and living_enemy_soldier_node_list.has(_soldier_node):
                living_enemy_soldier_node_list.erase(_soldier_node)
            else:
                living_enemy_soldier_node_list = SoldierUtils.list_living_soldier_node(living_enemy_soldier_node_list)
        BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP:
            teammate_soldier_count -= 1
            bs_solider_count_bar_node.update_teammate_count(teammate_soldier_count)
            teammate_die_or_injured_soldier_json_list.append(_json)
            _plus_morale = _get_plus_morale(_soldier_json, - teammate_soldier_morale_item, - teammate_hero_morale_item)

            if _soldier_node != null and living_teammate_soldier_node_list.has(_soldier_node):
                living_teammate_soldier_node_list.erase(_soldier_node)
            else:
                living_teammate_soldier_node_list = SoldierUtils.list_living_soldier_node(living_teammate_soldier_node_list)


    _update_morale(_bs_group, _plus_morale, false, SoldierUtils.is_hero_or_leader(_soldier_json))



    if StringUtils.is_not_empty(_murderer_bgroup):
        match _murderer_bgroup:
            BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP:

                if not SoldierUtils.is_conquest_knight_soldier(_soldier_json):
                    GlobalTempData.mult_battle_player_kill_soldier_simple_json.append(_soldier_json)

                _plus_morale = _get_plus_morale(_soldier_json, my_team_soldier_morale_item, my_team_hero_morale_item)
            BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP:

                _plus_morale = _get_plus_morale(_soldier_json, enemy_soldier_morale_item, enemy_hero_morale_item)
            BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP:

                _plus_morale = _get_plus_morale(_soldier_json, teammate_soldier_morale_item, teammate_hero_morale_item)


        _update_morale(_murderer_bgroup, _plus_morale * BattleSceneConfig.KILL_PLUS_MORALE_RATIO, false, SoldierUtils.is_hero_or_leader(_soldier_json))


    if player_soldier_count + teammate_soldier_count <= 0:





        _goto_battle_end(BattleConstants.BATTLE_RESULT_ENUM.DEFEAT)
    elif enemy_soldier_count <= 0:
        _goto_battle_end(BattleConstants.BATTLE_RESULT_ENUM.VICTORY)







func _get_plus_morale(_soldier_json: Dictionary, _soldier_morale_item: float, _hero_morale_item: float):
    if SoldierUtils.is_hero_or_leader(_soldier_json):
        return _hero_morale_item
    else:
        return _soldier_morale_item

func _battle_settlement()-> void:
    if not need_settlement:
        return

    if is_mult_turn_end:

        if WSData.get_player_team_node() != null:
            var _win_team_type = WSData.get_player_team_node().get_battle_team_type_enum()
            if battle_result == BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
                _win_team_type = TeamUtils.get_battle_team_type_opposite(_win_team_type)

            GlobalTempData.save_current_battle_info(
                current_battle_id, _win_team_type, battle_result
            )


        GlobalTempData.compute_mult_battle_player_kill_soldier_combat_power_total()

        if not is_test:

            _handle_player_help_npc_plus_relation_value()


    if not is_test:
        WSData.update_player_morale(GlobalTempData.get_morale(BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP))





    if not is_test:
        self._handle_team_skill_operation()


    if not is_test and is_mult_turn_end:
        self._remove_death_soldier_json()

    _interface_module_disappear()
    common_camera_node.func_close()
    GlobalTimeControl.time_normal()


    battle_animation_node.update_battle_result(battle_result)
    battle_animation_node.close()



    _is_settlement_inited = false
    var _settlement_timer = get_tree().create_timer(2.0)
    _settlement_timer.timeout.connect(_on_battle_animation_close_finish)













































func _handle_team_skill_operation():
    match battle_result:
        BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:

            for _node: MWTeam in GlobalTempData.mult_battle_enemy_team_node_list:
                _node.handle_team_skill_operation()
        BattleConstants.BATTLE_RESULT_ENUM.VICTORY:



            var _handle_info = WSData.get_player_team_node().handle_team_skill_operation()

            for _node: MWTeam in GlobalTempData.mult_battle_ally_team_node_list:
                _node.handle_team_skill_operation()










func _remove_death_soldier_json():


    WSData.get_player_team_node().remove_death_soldier_json()

    for _node: MWTeam in GlobalTempData.mult_battle_enemy_team_node_list:
        _node.remove_death_soldier_json()

    for _node: MWTeam in GlobalTempData.mult_battle_ally_team_node_list:
        _node.remove_death_soldier_json()

func _save_soldier_data():
    for _soldier_node: BSSoldier in soldier_root_node.get_children():
        _soldier_node.save()

func _interface_module_disappear():
    if not is_interface_module_show:
        return

    is_interface_module_show = false
    animation_player_node.play("module_disappear")
    if group_card_list_box_node.modulate.a == 1.0:
        var _tween = get_tree().create_tween()
        _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _tween.tween_property(group_card_list_box_node, "modulate:a", 0, 0.5)

    var _tween = get_tree().create_tween()
    _tween.tween_property(right_top_button_root_node, "modulate:a", 0.0, 0.5)

func _interface_module_show_ani():
    if is_interface_module_show:
        return

    is_interface_module_show = true
    animation_player_node.play_backwards("module_disappear")
    if group_card_list_box_node.modulate.a == 0.0:
        var _tween = get_tree().create_tween()
        _tween.tween_property(group_card_list_box_node, "modulate:a", 1.0, 0.5)


    right_top_button_root_node.show()
    var _tween = get_tree().create_tween()
    _tween.tween_property(right_top_button_root_node, "modulate:a", 1.0, 0.5)













func _add_forbid_click_effect(_position = null)-> void:
    var click_effect_instance = click_effect_node.instantiate() as ClickEffect
    click_effect_root_node.add_child(click_effect_instance)

    if _position != null:
        click_effect_instance.global_position = _position
    else:
        click_effect_instance.global_position = get_mouse_position()

    click_effect_instance.play_forbid_click()

func _add_target_point_show_effect(_target_vector_list, _click_point, _point_color: Color):


    target_point_show_node.init(_target_vector_list, _click_point, _point_color)





func _mouse_click_start():

    mouse_is_clicking = true
    mouse_click_duration_counter = 0
    mouse_click_start_point = get_mouse_position()
    mouse_click_start_local_point = get_mouse_local_position()

func _mouse_right_click_start():
    mouse_right_is_clicking = true
    mouse_click_duration_counter = 0
    mouse_click_start_point = get_mouse_position()
    mouse_click_start_local_point = get_mouse_local_position()

func _mouse_release_clear():
    mouse_is_clicking = false
    mouse_right_is_clicking = false
    mouse_click_duration_counter = -1
    mouse_click_start_point = Vector2.ZERO
    mouse_click_start_local_point = Vector2.ZERO
    is_selector_action = false
    is_set_formation_direction = false


func _control_move(_position_list = null, _direction_enum = null):
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)

    if CommonUtils.is_not_null(player_leader_soldier_node) and not _is_formation_mode():
        player_leader_soldier_node.custom_move_chat()

    if _position_list == null:
        _position_list = _team_move(control_soldier_node_list, get_mouse_position(), false, _direction_enum)
    else:
        _team_move2(control_soldier_node_list, _position_list, false, _direction_enum)

    if _is_formation_mode():
        pass
    else:
        _add_target_point_show_effect(_position_list, get_mouse_position(), CommonConstants.COLOR_ENUM.MOVE_COLOR)



func _choose_soldier(_node_list: Array, _only_style: = false):

    for _node in control_soldier_node_list:
        _node.unchoose()

    for _node in _node_list:
        if not hide_soldier_choose_effect:
            _node.choose()

    control_soldier_node_list = _node_list

    if not _only_style:




        control_soldier_node_list.sort_custom(SortUtils.sort_by_sort_desc)
        _show_or_hide_button()

func _show_or_hide_button():
    if _is_formation_mode():
        return


    if _mod_slave_duel_spectator:
        remote_switch_button_node.hide()
        charge_button_node.hide()
        return

    var _show_remote_switch_button = false
    var _default_choose_value: = true
    for _node: BSSoldier in control_soldier_node_list:
        if not _show_remote_switch_button and _node.bs_soldier_prop.is_has_remote_weapon:
            _show_remote_switch_button = true

        if _show_remote_switch_button and not _node.bs_soldier_prop.allow_remote:
            _default_choose_value = false

    if _show_remote_switch_button:
        remote_switch_button_node.show()
        remote_switch_button_node.set_default_value(_default_choose_value)
    else:
        remote_switch_button_node.hide()

    if ArrayUtils.is_not_empty(control_soldier_node_list):
        charge_button_node.show()
    else:
        charge_button_node.hide()

func _clear_data():
    animation_player_node.play("RESET")

    CommonUtils.clear_node(soldier_root_node)
    CommonUtils.clear_node(flyer_root_node)
    CommonUtils.clear_node(l_shield_root_node)
    b_cloud_root_node.clear()
    bird_root_node.clear()
    CommonUtils.delete_node(map_node)

    control_soldier_node_list = []


    player_die_or_injured_soldier_json_list = []
    teammate_die_or_injured_soldier_json_list = []
    enemy_die_or_injured_soldier_json_list = []
    player_soldier_count = 0
    teammate_soldier_count = 0
    enemy_soldier_count = 0
    player_soldier_total = 0
    teammate_soldier_total = 0
    enemy_soldier_total = 0
    mouse_is_clicking = false
    mouse_right_is_clicking = false
    mouse_click_duration_counter = -1
    mouse_click_start_point = Vector2.ZERO
    mouse_click_start_local_point = Vector2.ZERO
    is_selector_action = false
    is_set_formation_direction = false


    is_ready = false
    battle_result = ""
    current_battle_id = ""






    player_hero_total = 0
    teammate_hero_total = 0
    enemy_hero_total = 0
    my_team_soldier_morale_item = 0.0
    my_team_hero_morale_item = 0.0
    enemy_soldier_morale_item = 0.0
    enemy_hero_morale_item = 0.0
    teammate_soldier_morale_item = 0.0
    teammate_hero_morale_item = 0.0
    living_player_soldier_node_list = []
    living_enemy_soldier_node_list = []
    living_teammate_soldier_node_list = []
    is_battle_end = false
    _is_settlement_inited = false



    is_mult_turn_end = false
    ally_relation_gain_after_battle_factor = 0.0















func _handle_exp():




    var _exp = int(GlobalTempData.mult_battle_player_kill_soldier_combat_power_total * BattleSceneConfig.COMBAT_POWER_EXP_RATIO)

    TeamUtils.team_add_exp(WSData.get_player_team_simple_json_list(), _exp, false)
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.ACQUIRE_EXP_BATTLE_TRAIN,[_exp])


func _init_morale():

    if player_soldier_total > 0:
        _update_morale(
            BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP,
            TeamUtils.get_morale_value([WSData.get_player_team_node()]),
            true
        )


    if enemy_soldier_count > 0:
        _update_morale(
            BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP,
            TeamUtils.get_morale_value(GlobalTempData.mult_battle_enemy_team_node_list),
            true
        )


    if teammate_soldier_total > 0:
        _update_morale(
            BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP,
            TeamUtils.get_morale_value(
                GlobalTempData.mult_battle_ally_team_node_list
            ),
            true
        )

func _formation_tip_hide_ani_finish()-> void:
    tip_node.hide()
    formation_title_tip_node.hide()
    shadow_dashed_line_node.hide()

    _battle_animation_open()

func _update_morale(_bs_group_enum: String, _value: float, _is_init: = false, _is_hero: = false):
    match _bs_group_enum:
        BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP:
            if _is_init:
                GlobalTempData.my_team_morale_value = min(_value, TeamConfig.MORALE_MAX)
                my_team_morale_box_node.set_value(_value)

                var _plus_morale_info: Dictionary = _get_plus_morale_info(
                    _value, player_soldier_total, player_hero_total
                )
                my_team_soldier_morale_item = _plus_morale_info.soldier_morale_item
                my_team_hero_morale_item = _plus_morale_info.hero_morale_item
            else:
                if not GameConfig.OPEN_MORALE_SYSTEM:
                    return
                GlobalTempData.my_team_morale_value = min(GlobalTempData.my_team_morale_value + _value, TeamConfig.MORALE_MAX)
                my_team_morale_box_node.plus_value(_value, _is_hero)

        BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP:
            if _is_init:
                GlobalTempData.enemy_morale_value = min(_value, TeamConfig.MORALE_MAX)
                enemy_morale_box_node.set_value(_value)

                var _plus_morale_info: Dictionary = _get_plus_morale_info(
                    _value, enemy_soldier_total, enemy_hero_total
                )
                enemy_soldier_morale_item = _plus_morale_info.soldier_morale_item
                enemy_hero_morale_item = _plus_morale_info.hero_morale_item
            else:
                if not GameConfig.OPEN_MORALE_SYSTEM:
                    return
                GlobalTempData.enemy_morale_value = min(GlobalTempData.enemy_morale_value + _value, TeamConfig.MORALE_MAX)
                enemy_morale_box_node.plus_value(_value, _is_hero)

        BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP:
            if _is_init:
                GlobalTempData.teammate_morale_value = min(_value, TeamConfig.MORALE_MAX)

                var _plus_morale_info: Dictionary = _get_plus_morale_info(
                    _value, teammate_soldier_total, teammate_hero_total
                )
                teammate_soldier_morale_item = _plus_morale_info.soldier_morale_item
                teammate_hero_morale_item = _plus_morale_info.hero_morale_item
            else:
                if not GameConfig.OPEN_MORALE_SYSTEM:
                    return
                GlobalTempData.teammate_morale_value = min(GlobalTempData.teammate_morale_value + _value, TeamConfig.MORALE_MAX)

func _get_plus_morale_info(
    _morale_total: int,

    _soldier_count: int,
    _hero_count: int
)-> Dictionary:
    var _soldier_morale_item: float = 0.0
    var _hero_morale_item: float = 0.0
    if _hero_count > 0:
        _soldier_morale_item = _morale_total *(1.0 - BattleSceneConfig.HERO_MORALE_RATIO) / _soldier_count
        _hero_morale_item =(_morale_total * BattleSceneConfig.HERO_MORALE_RATIO / _hero_count) + _soldier_morale_item
    else:
        _soldier_morale_item = _morale_total / _soldier_count
        _hero_morale_item = _soldier_morale_item

    return {
        "soldier_morale_item": _soldier_morale_item,
        "hero_morale_item": _hero_morale_item,
    }



func _list_soldier_node_by_group_num_list(_group_num_list: Array)-> Array:
    var _result: = []

    if ArrayUtils.is_empty(_group_num_list):
        return _result

    for _group_num: int in _group_num_list:
        if group_soldier_node_dic.has(_group_num):
            _result.append_array(group_soldier_node_dic.get(_group_num))

    return _result


func _on_battle_animation_close_finish():

    if _is_settlement_inited:
        return
    _is_settlement_inited = true

    var _enemy_hero_simple_json_list: Array = []
    if is_mult_turn_end:
        _enemy_hero_simple_json_list = _handle_capture_hero_prepare(GlobalTempData.mult_battle_player_kill_soldier_simple_json)

    if settlement_interface_ani_node != null:
        settlement_interface_ani_node.init2(
            player_die_or_injured_soldier_json_list,
            enemy_die_or_injured_soldier_json_list,
            battle_result, player_soldier_total,
            enemy_soldier_total,

            GlobalTempData.mult_battle_player_kill_soldier_simple_json if is_mult_turn_end else[]
        )
    else:
        _mod_show_debug_overlay("[异常] settlement_interface_ani_node为null!")

    if teammate_soldier_total > 0:
        settlement_interface_ani_node.init_teammate(teammate_die_or_injured_soldier_json_list, teammate_soldier_total)
    else:
        settlement_interface_ani_node.hide_teammate_box()

    if is_mult_turn_end and battle_result == BattleConstants.BATTLE_RESULT_ENUM.VICTORY:
        settlement_interface_ani_node.show_or_hide_capture_page_button(true)
    else:
        settlement_interface_ani_node.show_or_hide_capture_page_button(false)

    settlement_interface_ani_node.cshow()
    is_ready = false


    if settlement_interface_ani_node != null and settlement_interface_ani_node.get("mod_error_text") != null:
        var _err = str(settlement_interface_ani_node.get("mod_error_text"))
        if _err != "":
            _mod_show_debug_overlay(_err)



    if not is_test \
    and battle_result == BattleConstants.BATTLE_RESULT_ENUM.VICTORY \
    and is_mult_turn_end:
        _handle_exp()



    if is_mult_turn_end:
        _handle_enemy_hero_capture(_enemy_hero_simple_json_list)


func _on_battle_animation_open_finish():
    is_ready = true
    battle_animation_node.chide()
    _interface_module_show_ani()
    if _is_formation_mode():
        scene_mode = BattleConstants.BATTLE_SCENE_MODE_ENUM.BATTLE_MODE








        _button_hide_or_show()
        _show_or_hide_button()

    battle_animation_node.open_outside_input()

    group_card_list_box_node.choose_all()


    _open_terrain_buff()


    if ArrayUtils.is_not_empty(living_teammate_soldier_node_list):
        ally_ai_node.start()

    if ArrayUtils.is_not_empty(living_enemy_soldier_node_list):
        enemy_ai_node.start()

    if enemy_soldier_count <= 0 and init_check_enemy_0_end:
        _goto_battle_end(BattleConstants.BATTLE_RESULT_ENUM.VICTORY)

func _open_terrain_buff()-> void:
    if terrain_type != MWorldConstants.TERRAIN_TYPE_ENUM.DESERT:
        return

    for _soldier_node: BSSoldier in living_player_soldier_node_list:
        _soldier_node.open_terrain_buff_handler()

    for _soldier_node: BSSoldier in living_enemy_soldier_node_list:
        _soldier_node.open_terrain_buff_handler()

    for _soldier_node: BSSoldier in living_teammate_soldier_node_list:
        _soldier_node.open_terrain_buff_handler()


func _close_terrain_buff()-> void:
    for _soldier_node: BSSoldier in living_player_soldier_node_list:
        _soldier_node.close_terrain_buff_handler()

    for _soldier_node: BSSoldier in living_enemy_soldier_node_list:
        _soldier_node.close_terrain_buff_handler()

    for _soldier_node: BSSoldier in living_teammate_soldier_node_list:
        _soldier_node.close_terrain_buff_handler()




func _handle_capture_hero_prepare(_all_simple_json_list: Array)-> Array:
    var _hero_simple_json_list: Array = []

    if ArrayUtils.is_empty(_all_simple_json_list):
        return _hero_simple_json_list

    for _simple_json: Dictionary in _all_simple_json_list:
        if SoldierUtils.is_hero_by_simple_json(_simple_json):

            if _simple_json.has("uid") and _simple_json.uid == "mod_boss_conquest_knight":
                continue
            _hero_simple_json_list.append(_simple_json)


    if _hero_simple_json_list.is_empty():
        return _hero_simple_json_list

    var _capture_prob: float = BattleSceneConfig.HERO_CAPTURE_PROB / sqrt(_hero_simple_json_list.size())

    for _simple_json: Dictionary in _hero_simple_json_list:
        if CommonUtils.prob_true(_capture_prob) or GameConfig.ALWAYS_CAPTURE_HERO:

            SoldierUtils.handle_hero_is_captured_by_simlpe_json(_simple_json, true)
        else:

            SoldierUtils.handle_hero_is_captured_by_simlpe_json(_simple_json, false)

    return _hero_simple_json_list



func _handle_enemy_hero_capture(_hero_simple_json_list: Array)-> void:
    if ArrayUtils.is_empty(_hero_simple_json_list):
        return

    for _hero_simple_json: Dictionary in _hero_simple_json_list:
        if CommonUtils.get_value(_hero_simple_json, "is_captured", false):
            WSData.capture_enemy([_hero_simple_json])

            GlobalMessageInterface.add_capture_hero_message(_hero_simple_json.uid)
        else:

            GlobalMessageInterface.add_hero_flee_message(_hero_simple_json.uid)


func _on_settlement_interface_ani_next_sign():

    if not is_mult_turn_end:
        _contine_mult_turn()
        return


    if battle_result == BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
        _on_trophy_interface_close_sign()
        return


    var _player_team_node: MWTeam = WSData.get_player_team_node()


    var _skill_plunder_ratio = SkillUtils.get_skill_plunder_effect_ratio(_player_team_node.team_info.skill_plunder)

    var _trophy_list: Array = []



    var _ratio: float = GlobalTempData.mult_battle_player_kill_soldier_combat_power_total * MWConfig.TROPHY_ROB_RATIO_FROM_ITEMS \
    / GlobalTempData.mult_battle_enemy_combat_power_total

    var _battle_data: Dictionary = WSData.get_battle_data(current_battle_id)
    var _load_by_team_node: bool = CommonUtils.get_value(_battle_data, "load_by_team_node", true)
    var _money: = 0
    if _load_by_team_node:

        var _team_node_info = WSData.get_battle_team_type_info(current_battle_id, _player_team_node.get_uid())


        GoodsUtils.generate_npc_goods(_team_node_info.enemy)



        var _trophy_items_json: Array = GoodsUtils.random_trophy_items(_team_node_info.enemy, _ratio *(1 + _skill_plunder_ratio))
        _trophy_list.append_array(_trophy_items_json)


        _trophy_list.append_array(
            GoodsUtils.random_trophy(
                GlobalTempData.mult_battle_player_kill_soldier_simple_json,
                1 + _skill_plunder_ratio,

                _team_node_info.enemy[0].get_uid()
            )
        )




        var _money_ratio: float = GlobalTempData.mult_battle_player_kill_soldier_combat_power_total * 1.0 \
        / GlobalTempData.mult_battle_enemy_combat_power_total

        _money = GoodsUtils.random_trophy_money(_team_node_info.enemy, _money_ratio)
    else:

        _trophy_list.append_array(
            GoodsUtils.random_trophy(_battle_data.enemy_team, 1 + _skill_plunder_ratio)
        )
        _money = int(CommonUtils.get_value(_battle_data, "trophy_money", 0) *(1 + _skill_plunder_ratio))



    if _load_by_team_node:
        var _ck_team_info = WSData.get_battle_team_type_info(current_battle_id, _player_team_node.get_uid())
        for _enemy_node in _ck_team_info.enemy:
            if _enemy_node is MWTeam and _enemy_node.get_npc_team_code() == NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT:
                _trophy_list.clear()
                _money = 0
                var _ruby_count: int = CommonUtils.random_num2(30, 50)
                _trophy_list.append({"item": {"uid": "commodity_0027"}, "count": _ruby_count})
                break


    _trophy_list = GoodsUtils.organize_goods(_trophy_list)


    _trophy_list.sort_custom(SortUtils.sort_by_price_desc)

    trophy_interface_node.show()
    trophy_interface_node.init(_trophy_list)
    trophy_interface_node.set_change_money(_money)






func _on_trophy_interface_close_sign():








    BattleSceneTransition.connect("fade_out_ani_finish_sign", _change_to_main_world)
    BattleSceneTransition.play_fade_out(false)

func _change_to_main_world()-> void:
    BattleSceneTransition.disconnect("fade_out_ani_finish_sign", _change_to_main_world)


    GlobalNode.game_root.change_to_mworld()
    BattleSceneTransition.play_fade_in()


func _on_group_card_list_box_update_choose_sign(_group_num_list: Array):

    if _group_num_list.has(-1):

        all_soldier_node = SoldierUtils.list_living_soldier_node(all_soldier_node)
        _choose_soldier(all_soldier_node)
    else:
        var _choose_node_list: = []










        _choose_soldier(_list_soldier_node_by_group_num_list(_group_num_list))


func _on_remote_switch_button_change_value_sign(_allow_remote: bool):
    for _soldier_node in control_soldier_node_list:
        _soldier_node.update_allow_remote(_allow_remote)

    if _allow_remote:
        tip_node.cshow("允许远程攻击", 3.0)
    else:
        tip_node.cshow("禁用远程攻击", 3.0, CommonConstants.COLOR_ENUM.YELLOW)

func _on_charge_timer_timeout()-> void:
    charge()


func _on_charge_button_cpressed()-> void:
    charge(true)
    tip_node.cshow("全军冲锋", 3.0, CommonConstants.COLOR_ENUM.YELLOW)


func _on_box_select_button_change_value_sign(_current_value: bool)-> void:
    if not _current_value:
        tip_node.cshow("请开始框选士兵", 3.5, CommonConstants.COLOR_ENUM.YELLOW)

        mobile_box_select_start = true
        common_camera_node.update_drag_enabled(false)
    else:
        mobile_box_select_start = false
        tip_node.chide("请开始框选士兵")
        common_camera_node.update_drag_enabled(true)


func _on_move_mode_button_change_value_sign(_current_value: bool)-> void:
    if _current_value:
        tip_node.cshow("已切换为[强制移动]模式", 3.5)
    else:
        tip_node.cshow("已切换为[移动攻击]模式", 3.5, CommonConstants.COLOR_ENUM.YELLOW)

func _on_time_control_button_change_value_sign(_current_value: bool)-> void:
    if _current_value:
        tip_node.cshow("时间流速恢复正常", 3.5)
        GlobalTimeControl.time_normal()
    else:
        tip_node.cshow("时间流速减缓", 3.5, CommonConstants.COLOR_ENUM.YELLOW)
        GlobalTimeControl.time_slow()


func _on_battle_start_button_pressed_sign()-> void:
    battle_animation_node.stop_outside_input()
    battle_animation_node.color_rect_dark_ani()
    animation_player_node.play("formation_tip_hide")

func _on_battle_animation_formation_start_ani_finish()-> void:
    is_ready = true


func _on_pause_run_button_pressed()-> void:
    is_pause = not is_pause
    if is_pause:
        get_tree().paused = true
        _interface_module_disappear()
        tip_node.cshow("暂停中")
        pause_run_button_node.update_icon("res://resource/icon/run_icon_30.png")
    else:
        get_tree().paused = false
        tip_node.chide()
        pause_run_button_node.update_icon("res://resource/icon/stop_icon_30.png")
        _interface_module_show_ani()

func _on_settlement_interface_ani_back_to_main_sign()-> void:

    back_to_main_menu_sign.emit()
    show_or_hide_soldier_select_effect(false)

func _on_back_to_main_menu_button_custom_pressed()-> void:
    back_to_main_menu_sign.emit()
    show_or_hide_soldier_select_effect(false)

func _on_common_camera_change_zoom_sign(_zoom: Vector2)-> void:
    change_zoom_sign.emit(_zoom)


func _on_settlement_interface_ani_talk_to_prisoner_hero_sign(_hero_uid: String)-> void:
    var _dialogue_gd: BaseDialogue = DialogueUtils.get_dialogue_gd_by_hero_uid(_hero_uid)

    if _dialogue_gd == null:
        print("[Mod] 该英雄没有对话文件, 无法对话: ", _hero_uid)
        return
    dialogue_interface_node.cshow()
    dialogue_interface_node.init(
        _dialogue_gd.get_captured_dialogue_after_battle(),
        TeamUtils.get_player_team_node().get_dialogue_info(),
        DialogueUtils.get_dialogue_info(_hero_uid)
    )

func _on_dialogue_interface_finish(_result_option_type: Variant, _dialogue_json: Variant)-> void:
    dialogue_interface_node.chide()


func _mod_show_debug_overlay(_text: String)-> void:

    var _cl = CanvasLayer.new()
    _cl.layer = 1000
    _cl.name = "ModDebugOverlay"
    add_child(_cl)


    var _panel = Panel.new()
    _panel.position = Vector2(20, 20)
    _panel.size = Vector2(700, 600)
    _panel.modulate.a = 0.95
    var _stylebox = StyleBoxFlat.new()
    _stylebox.bg_color = Color(0, 0, 0, 0.9)
    _stylebox.border_color = Color(1, 1, 0, 1)
    _stylebox.set_border_width_all(2)
    _stylebox.set_content_margin_all(5)
    _panel.add_theme_stylebox_override("panel", _stylebox)
    _cl.add_child(_panel)


    var _scroll = ScrollContainer.new()
    _scroll.position = Vector2(5, 5)
    _scroll.size = Vector2(690, 590)
    _panel.add_child(_scroll)

    var _label = Label.new()
    _label.text = _text
    _label.size = Vector2(670, 0)
    _label.add_theme_font_size_override("font_size", 14)
    _label.add_theme_color_override("font_color", Color(1, 1, 0.3))
    _label.add_theme_color_override("font_outline_color", Color.BLACK)
    _label.add_constant_override("outline_size", 2)
    _label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    _label.vertical_alignment = VERTICAL_ALIGNMENT_TOP

    _label.custom_minimum_size = Vector2(660, 0)
    _scroll.add_child(_label)