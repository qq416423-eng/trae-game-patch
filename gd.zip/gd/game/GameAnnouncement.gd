class_name GameAnnouncement extends Control

@onready var custom_team_button_root_node: TextureRect =$CustomTeamButtonRoot

signal sponsor_button_click_sign()
signal custom_team_button_sign()
signal control_battle_sign()

func _ready()-> void:
    if GameConfig.is_sponsor_edition:
        custom_team_button_root_node.show()
    else:
        custom_team_button_root_node.hide()


func _on_sponsor_button_custom_pressed()-> void:
    sponsor_button_click_sign.emit()

func _on_custom_team_button_custom_pressed()-> void:
    custom_team_button_sign.emit()

func _on_control_battle_button_custom_pressed()-> void:
    control_battle_sign.emit()