class_name InputArea extends Node2D

var is_active: = true

func _unhandled_input(event):
    owner._c_unhandled_input(event)

func stop()-> void:
    is_active = false
    set_process_unhandled_input(false)

func run()-> void:
    is_active = true
    set_process_unhandled_input(true)

func is_c_active()-> bool:
    return is_active