@tool
class_name MWorldScene extends Node2D

@onready var team_root_node =$ObjectRoot / TeamRoot
@onready var common_camera_node =$CommonCamera as CommonCamera
@onready var team_manage_interface_node =$CanvasLayer / InterfaceRoot / TeamManageInterface
@onready var city_root_node =$ObjectRoot / MapObjectRoot / CityRoot
@onready var button_root_node =$CanvasLayer / ButtonRoot
@onready var location_enter_interface_node =$CanvasLayer / InterfaceRoot / LocationEnterInterface as LocationEnterInterface
@onready var goods_exchange_interface_node =$CanvasLayer / InterfaceRoot / GoodsExchangeInterface as GoodsExchangeInterface
@onready var recruit_interface_node =$CanvasLayer / InterfaceRoot / RecruitInterface as RecruitInterface
@onready var dialogue_interface_node =$CanvasLayer / InterfaceRoot / DialogueInterface as DialogueInterface
@onready var village_root_node =$ObjectRoot / MapObjectRoot / VillageRoot
@onready var click_effect_node = preload("res://tscn/game/effect/ClickEffect.tscn")
@onready var click_effect_root_node =$ClickEffectRoot
@onready var module_root_node =$CanvasLayer / ModuleRoot
@onready var mw_clock_and_day_light_controller_node: MWClockAndDayLightController =$CanvasLayer / ModuleRoot / MWClockAndDayLightController
@onready var animation_player_node =$AnimationPlayer
@onready var items_interface_node =$CanvasLayer / InterfaceRoot / ItemsInterface as GoodsExchangeInterface
@onready var upgrade_icon_node =$CanvasLayer / ButtonRoot / RBSpace / HBoxContainer / TeamMenuButton / UpgradeIcon as UpgradeIcon
@onready var m_world_left_info_area_node =$CanvasLayer / ModuleRoot / MWorldLeftInfoArea as MWorldLeftInfoArea
@onready var castle_root_node =$ObjectRoot / MapObjectRoot / CastleRoot
@onready var canvas_layer_node =$CanvasLayer

@onready var wild_soldier_generate_area_root_node =$ObjectRoot / WildSoldierGenerateAreaRoot

@onready var view_func_root_node =$CanvasLayer / InterfaceRoot / ViewFuncRoot
@onready var bird_root_node =$ObjectRoot / MapObjectRoot / BirdRoot
@onready var m_cloud_root_node =$ObjectRoot / MapObjectRoot / MCloudRoot
@onready var mw_top_box_node =$CanvasLayer / ModuleRoot / MWTopBox
@onready var mwb_rain_root_node =$MapRoot / MWBRainRoot
@onready var m_world_main_menu_node: MWorldMainMenu =$CanvasLayer / InterfaceRoot / MWorldMainMenu
@onready var weather_executor_node: WeatherExecutor =$WeatherExecutor
@onready var input_area_node: InputArea =$InputArea
@onready var player_path_line_node: Line2D =$PlayerPathLine
@onready var settings_interface_node: SettingsInterface =$CanvasLayer / InterfaceRoot / SettingsInterface
@onready var game_info_button_node: CommonButton =$CanvasLayer / ButtonRoot / RBSpace / HBoxContainer / GameInfoButton
@onready var team_info_button_node: CommonButton =$CanvasLayer / ButtonRoot / RBSpace / HBoxContainer / TeamInfoButton
@onready var team_menu_button_node: CommonButton =$CanvasLayer / ButtonRoot / RBSpace / HBoxContainer / TeamMenuButton
@onready var items_button_node: CommonButton =$CanvasLayer / ButtonRoot / RBSpace / HBoxContainer / ItemsButton
@onready var main_menu_button_node: CommonButton =$CanvasLayer / ButtonRoot / RTSpace / MainMenuButton
@onready var tip_node: Tip =$CanvasLayer / ModuleRoot / Tip
@onready var special_build_interface_node: SpecialBuildInterface =$CanvasLayer / InterfaceRoot / SpecialBuildInterface
@onready var special_location_root_node: Node2D =$ObjectRoot / MapObjectRoot / SpecialLocationRoot
@onready var team_exchange_interface_node: TeamExchangeInterface =$CanvasLayer / InterfaceRoot / TeamExchangeInterface
@onready var warehouse_interface_node: WarehouseInterface =$CanvasLayer / InterfaceRoot / WarehouseInterface
@onready var soldier_info_interface_node: SoldierInfoInterface =$CanvasLayer / InterfaceRoot / SoldierInfoInterface


var mod_forge_interface_node: Control = null
var _mod_blacksmith_dialogue_active: bool = false
var _mod_current_forge_type: String = ""
var _mod_current_dialogue_name: String = ""
var _mod_current_npc_name: String = ""
var _mod_current_is_quartermaster: bool = false
var mod_equip_distribute_node: Control = null

var mod_prison_interface_node: Control = null

var mod_mint_interface_node: Control = null

var mod_dice_gamble_interface_node: Control = null
var _mod_gambler_dialogue_active: bool = false



var mod_appraiser_gamble_interface_node: Control = null

var _mod_typhoon_active: bool = false
var _mod_typhoon_end_day: float = -1.0
var _mod_typhoon_prev_weather: int = 0

var _mod_player_on_island: bool = false

const MOD_TYPHOON_DAILY_CHANCE: float = 0.095
const MOD_TYPHOON_DURATION_DAYS: float = 2.0

var _mod_lumber_mill_dialogue_active: bool = false
var _mod_lumber_mill_owned: bool = false
var _mod_lumber_mill_rent_end_day: float = -1.0
var _mod_lumber_mill_capacity: int = 0
var _mod_lumber_mill_workers: Array = []
var _mod_lumber_mill_food: Array = []
var _mod_lumber_mill_wood: float = 0.0
var _mod_lumber_mill_food_depleted: bool = false
var _mod_lumber_mill_prisoners_out: int = 0
var _mod_lumber_mill_manage_context: String = ""

var _mod_lumber_mill_forest_stock: float = 7000.0
var _mod_lumber_mill_tool_durability: float = 100.0
var _mod_lumber_mill_morale: float = 50.0
const MOD_LUMBER_MILL_FOREST_MAX: float = 7000.0


const MOD_LUMBER_MILL_FOREST_RECOVER_RATIO: float = 0.01
const MOD_LUMBER_MILL_FOREST_REGEN_MIN: float = 70.0








const MOD_LUMBER_MILL_INTIM_STRONG: float = 0.5
const MOD_LUMBER_MILL_INTIM_FULL: float = 1.0






const MOD_LUMBER_MILL_GUIDE_MAX: int = 30
const MOD_LUMBER_MILL_GUIDE_COVER_PER: int = 20
const MOD_LUMBER_MILL_GUIDE_COVER_EFFECT: float = 0.95
const MOD_LUMBER_MILL_LOST_RATE_FLOOR: float = 0.001

var mod_lumber_mill_interface_node: Control = null
var mod_mine_interface_node: Control = null

var _mod_mine_dialogue_active: bool = false
var _mod_mine_owned: bool = false
var _mod_mine_rent_end_day: float = -1.0
var _mod_mine_capacity: int = 0
var _mod_mine_workers: Array = []
var _mod_mine_food: Array = []
var _mod_mine_food_total: int = 0
var _mod_mine_food_depleted: bool = false
var _mod_mine_prisoners_out: int = 0
var _mod_mine_manage_context: String = ""
var _mod_mine_tool_durability: float = 100.0
var _mod_mine_morale: float = 50.0
var _mod_mine_ore_stock: Dictionary = {"copper": 0.0, "iron": 0.0, "silver": 0.0}
var _mod_mine_vein_stock: float = 5000.0
const MOD_MINE_VEIN_MAX: float = 5000.0
var _mod_mine_depth: int = 1
var _mod_mine_timber_support: float = 100.0
var _mod_mine_water_level: float = 0.0

var _mod_last_lm_settlement_day: int = -1
var _mod_last_mine_settlement_day: int = -1

var _mod_last_lm_regen_day: int = -1


const MOD_MINE_ORE_COPPER_UID: String = "commodity_0002"
const MOD_MINE_ORE_IRON_UID: String = "commodity_0001"
const MOD_MINE_ORE_SILVER_UID: String = "commodity_0003"




var _mod_mint_loc_data: Dictionary = {}
var _mod_mint_current_loc: String = ""
var _mod_mint_today_income: int = 0
var _mod_mint_total_income: int = 0
var _mod_mint_slots: Array = []
var _mod_last_mint_settlement_day: int = -1

var _mod_mint_legacy_ore: int = 0
var _mod_mint_legacy_wood: int = 0
const MOD_MINT_COPPER_UID: String = "commodity_0002"
const MOD_MINT_INGOT_UID: String = "commodity_0033"
const MOD_MINT_WOOD_UID: String = "commodity_0013"
const MOD_MINT_SLOT_COUNT: int = 2
const MOD_MINT_INPUT_CAP_BASE: int = 60

const MOD_AUCTION_EXCLUDED_UIDS: Array = [
    "oh_sword_0034",

    "oh_sword_0013", "oh_sword_0024",

    "th_blunt_0007", "shoulder_0074", "armour_0108", "shoe_0086",

    "armour_0105", "helmet_0132", "shoe_0084", "shoulder_0072",
    "th_blunt_0006", "oh_shield_0037", "horse_0001",

    "armour_0106", "helmet_0133", "shoe_0024", "shoulder_0020",
    "oh_lance_0016", "oh_sword_0012", "oh_shield_0011", "harmour_0001",

    "armour_0107", "helmet_0134", "shoe_0085", "shoulder_0073",
    "oh_throw_0003", "oh_sword_0026", "oh_shield_0016",
]

var _mod_auction_active: bool = false
var _mod_auction_current_level: int = 0
var _mod_auction_ticket_high: bool = false
var _mod_auction_ticket_mid: bool = false
var _mod_auction_ticket_low: bool = false
var _mod_auction_dialogue_active: bool = false

var _mod_auction_current_item_idx: int = -1
var _mod_auction_bid_round: int = 0
var _mod_auction_current_bid: int = 0

var _mod_auction_bidders: Array = []
var _mod_auction_last_bidder_text: String = ""
var _mod_auction_last_host_text: String = ""
var _mod_auction_opening_shown: bool = false

var _mod_auction_wait_round: int = 0
var _mod_auction_item_value: int = 0
var _mod_auction_bidder_budgets: Array = []
var _mod_auction_list_page: int = 0
var _mod_auction_last_bidder_is_player: bool = false

var _mod_auction_next_start_day: float = -1.0
var _mod_auction_end_day: float = -1.0
var _mod_auction_is_active: bool = false


const MOD_AUCTION_ICON_PATH = "res://resource/icon/locationButtonIcon/auction_icon.png"

func _mod_customize_auction_button()-> void:

    if GlobalTempData.current_location_code != ISLAND_CITY_CODE:
        return
    if not is_instance_valid(location_enter_interface_node):
        return
    var _planform = location_enter_interface_node.current_node
    if not is_instance_valid(_planform):
        return
    var _card_list = _planform.location_card_list_node
    if not is_instance_valid(_card_list):
        return
    var _h_box = _card_list.h_box_container_node
    if not is_instance_valid(_h_box):
        return

    var _icon_tex = load(MOD_AUCTION_ICON_PATH)

    for _card in _h_box.get_children():
        if _card is LocationCard and _card.type == LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN:

            if _icon_tex != null:
                _card.small_icon_node.texture = _icon_tex

            _card.button_name = "拍卖行"
            CommonUtils.set_text(_card.title_node, "拍卖行")
            print("[MapMod] Tavern按钮已替换为拍卖行按钮")
            break










const MOD_AUCTION_TICKET_GOLD: Dictionary = {1: 5000, 2: 12000, 3: 22000}

const MOD_AUCTION_TICKET_ITEM_COUNT: Dictionary = {1: 0, 2: 3, 3: 2}

const MOD_AUCTION_BIDDER_NAMES: Array = [
    "穿红袍的商人", "退役军官", "神秘蒙面客", "富家公子",
    "老练的收藏家", "雇佣兵队长", "贵族管家", "行脚商人",
    "铸剑师", "马场主", "盐商", "绸缎庄老板"
]


func _mod_auction_level_name(_level: int)-> String:
    match _level:
        3:
            return "高级"
        2:
            return "中级"
        1:
            return "低级"
        _:
            return ""



func _mod_open_auction()-> void:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        return
    var _city_data: Dictionary = WSLocationData.city_data.get(ISLAND_CITY_CODE)

    if not _mod_is_auction_active():

        _mod_auction_active = true
        special_build_interface_node.init("", "", "")
        special_build_interface_node._mod_fix_title_text("拍卖行")
        special_build_interface_node.show()
        _mod_auction_show_inactive_dialog()
        return
    _mod_refresh_auction_goods_if_needed(_city_data)
    _mod_auction_active = true
    _mod_auction_current_level = 0

    special_build_interface_node.init("", "", "")
    special_build_interface_node._mod_fix_title_text("拍卖行")
    special_build_interface_node.show()

    _mod_auction_show_entry_dialog()
    print("[MapMod] 拍卖行入口界面已打开 (空参数init + 对话驱动)")


func _mod_auction_reset_tickets()-> void:
    _mod_auction_ticket_high = false
    _mod_auction_ticket_mid = false
    _mod_auction_ticket_low = false
    _mod_auction_dialogue_active = false
    _mod_auction_current_item_idx = -1
    _mod_auction_current_bid = 0
    _mod_auction_bid_round = 0
    _mod_auction_wait_round = 0
    _mod_auction_item_value = 0
    _mod_auction_bidders.clear()
    _mod_auction_bidder_budgets.clear()
    _mod_auction_opening_shown = false
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_last_bidder_is_player = false
    _mod_auction_list_page = 0
    print("[MapMod] 拍卖行入场券已重置 (离开斯卡城)")


func _mod_is_player_on_island()-> bool:
    return _mod_player_on_island


func _mod_is_auction_active()-> bool:
    return _mod_auction_is_active


func _mod_auction_days_until_next()-> int:
    if _mod_auction_next_start_day < 0.0:
        return 0
    var _days: int = int(_mod_auction_next_start_day - WSData.system_counter)
    if _days < 0:
        _days = 0
    return _days



func _mod_auction_init_bidders()-> void:
    var _pool: Array = MOD_AUCTION_BIDDER_NAMES.duplicate()
    _mod_auction_bidders.clear()
    _mod_auction_bidder_budgets.clear()
    for _i in range(4):
        if _pool.is_empty():
            break
        var _idx: int = CommonUtils.random_num2(0, _pool.size() - 1)
        _mod_auction_bidders.append(_pool[_idx])
        _pool.remove_at(_idx)
    _mod_auction_opening_shown = false
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_list_page = 0
    print("[MapMod] 拍卖会到场竞拍者: ", _mod_auction_bidders)


func _mod_auction_pick_bidder()-> String:
    if _mod_auction_bidders.is_empty():
        return ""
    return _mod_auction_bidders[CommonUtils.random_num2(0, _mod_auction_bidders.size() - 1)]



func _mod_auction_pick_active_bidder()-> String:
    var _active_indices: Array = []
    for _i in range(_mod_auction_bidder_budgets.size()):
        if _mod_auction_bidder_budgets[_i] > 0 and _i < _mod_auction_bidders.size():
            _active_indices.append(_i)
    if _active_indices.is_empty():
        return ""
    var _pick: int = _active_indices[CommonUtils.random_num2(0, _active_indices.size() - 1)]
    return _mod_auction_bidders[_pick]




func _mod_auction_show_inactive_dialog()-> void:
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _days: int = _mod_auction_days_until_next()
    var _msg: String = "抱歉,拍卖会还没举办。还有" + str(_days) + "天后开始,届时再来看看吧。"
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE, "oname": "告辞", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["好的,我到时候再来。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)



func _mod_auction_show_entry_dialog()-> void:
    _mod_auction_current_level = 0
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "高级拍卖场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要进入高级拍卖场。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "中级拍卖场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要进入中级拍卖场。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "低级拍卖场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要进入低级拍卖场。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE, "oname": "告辞", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我先走了。"]}]},
        ],
    }
    var _greeting2: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["本拍卖行设有三个拍卖场:高级拍卖场汇聚5星稀有装备,中级拍卖场有4星装备,低级拍卖场有3星实用装备。您要去哪个拍卖场?"]}],
        "next": _options,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["欢迎来到斯卡城拍卖行!我是拍卖师。"]}],
        "next": _greeting2,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)





func _mod_auction_show_ticket_dialog(_level: int)-> void:
    _mod_auction_current_level = _level
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _lv_name: String = _mod_auction_level_name(_level)
    var _ticket_msg: String = _mod_auction_ticket_info(_level)
    var _option_list: Array = []
    if _level == 3:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "交2件5星武器", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我交2件5星普通品质武器作为入场券。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "交22000金币", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我交22000金币作为入场券。"]}]})
    elif _level == 2:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "交3件4星传说装", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我交3件4星传说及以上品质装备作为入场券。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "交12000金币", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我交12000金币作为入场券。"]}]})
    else:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "交5000金币", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我交5000金币作为入场券。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑一下。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["进入" + _lv_name + "拍卖场需要入场券。" + _ticket_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_auction_enter_or_pay_ticket(_level: int)-> void:
    if _mod_auction_has_ticket(_level):
        _mod_auction_current_level = _level
        _mod_auction_dialogue_active = false
        _mod_auction_init_bidders()
        _mod_auction_show_item_list_dialog()
    else:
        _mod_auction_dialogue_active = false
        _mod_auction_show_ticket_dialog(_level)


func _mod_auction_ticket_info(_level: int)-> String:
    var _gold: int = int(MOD_AUCTION_TICKET_GOLD.get(_level, 0))
    if _level == 3:
        return "入场券: 2件5星普通品质武器 或 " + str(_gold) + "金币"
    elif _level == 2:
        return "入场券: 3件4星传说及以上品质装备 或 " + str(_gold) + "金币"
    else:
        return "入场券: " + str(_gold) + "金币"


func _mod_auction_has_ticket(_level: int)-> bool:
    match _level:
        3:
            return _mod_auction_ticket_high
        2:
            return _mod_auction_ticket_mid
        1:
            return _mod_auction_ticket_low
        _:
            return false


func _mod_auction_set_ticket(_level: int, _val: bool)-> void:
    match _level:
        3:
            _mod_auction_ticket_high = _val
        2:
            _mod_auction_ticket_mid = _val
        1:
            _mod_auction_ticket_low = _val




func _mod_auction_pay_with_item(_level: int)-> void:
    var _player_goods: Array = WSData.get_player_goods()
    var _indices: Array = _mod_find_ticket_items(_player_goods, _level)
    var _need_count: int = int(MOD_AUCTION_TICKET_ITEM_COUNT.get(_level, 0))
    if _indices.size() < _need_count:
        _mod_msg("符合要求的装备不足,无法支付入场券!", 2.5, false)

        _mod_auction_dialogue_active = false
        _mod_auction_show_ticket_dialog(_level)
        return

    _indices.sort()
    _indices.reverse()
    for _i in range(_need_count):
        var _idx: int = int(_indices[_i])
        var _goods_json: Dictionary = _player_goods[_idx]
        var _count: int = int(_goods_json.get("count", 1))
        if _count > 1:
            _goods_json["count"] = _count - 1
        else:
            _player_goods.remove_at(_idx)
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)
    _mod_auction_set_ticket(_level, true)
    _mod_msg("已用装备支付入场券,进入拍卖场!", 2.5, true)
    _mod_auction_dialogue_active = false
    _mod_auction_init_bidders()
    _mod_auction_show_item_list_dialog()


func _mod_auction_pay_with_gold(_level: int)-> void:
    var _gold: int = int(MOD_AUCTION_TICKET_GOLD.get(_level, 0))
    var _player_money: int = WSData.get_player_money()
    if _player_money < _gold:
        _mod_msg("金币不足,无法支付入场券!", 2.5, false)
        _mod_auction_dialogue_active = false
        _mod_auction_show_ticket_dialog(_level)
        return
    WSData.update_money(- _gold, false)
    _mod_auction_set_ticket(_level, true)
    _mod_msg("已支付" + str(_gold) + "金币入场券,进入拍卖场!", 2.5, true)
    _mod_auction_dialogue_active = false
    _mod_auction_init_bidders()
    _mod_auction_show_item_list_dialog()




func _mod_find_ticket_items(_player_goods: Array, _level: int)-> Array:
    var _indices: Array = []
    var _weapon_etype = WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON
    var _fine_q = WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.FINE
    var _excellent_q = WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.EXCELLENT
    var _allowed_etypes: Array = [
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HORSE,
    ]
    for _i in range(_player_goods.size()):
        var _goods_json = _player_goods[_i]
        if not(_goods_json is Dictionary):
            continue
        var _item_json = _goods_json.get("item", null)
        if _item_json == null or not(_item_json is Dictionary):
            continue
        var _uid: String = _item_json.get("uid", "")
        if _uid.is_empty():
            continue
        var _etype = WeaponTypeConstants.get_etype(_uid)
        if _etype == null:
            continue
        var _part_json = GlobalBsPart.bs_part_dic.get(_uid)
        if _part_json == null:
            continue
        var _star: int = int(_part_json.get("star", 0))
        var _quality: int = _mod_get_item_quality(_item_json, _part_json)
        if _level == 3:

            if _etype == _weapon_etype and _star == 5 and _quality < _fine_q:
                _indices.append(_i)
        elif _level == 2:

            if _allowed_etypes.has(_etype) and _star == 4 and _quality >= _excellent_q:
                _indices.append(_i)
    return _indices


func _mod_get_item_quality(_item_json: Dictionary, _part_json: Dictionary)-> int:
    if _item_json.has("quality"):
        return int(_item_json.get("quality", 0))
    if _part_json != null and _part_json.has("quality"):
        return int(_part_json.get("quality", 0))
    return 0






func _mod_quality_to_str(_quality: int)-> String:
    var _fine_q = WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.FINE
    var _excellent_q = WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.EXCELLENT
    if _quality >= 6:
        return "神品"
    elif _quality >= _excellent_q:
        return "传说"
    elif _quality >= _fine_q:
        return "精良"
    else:
        return "普通"



func _mod_get_part_name(_uid: String)-> String:
    if StringUtils.is_empty(_uid):
        return "未知物品"

    var _part_json = GlobalBsPart.bs_part_dic.get(_uid,{})
    if _part_json != null and _part_json is Dictionary and _part_json.has("name"):
        return _part_json.get("name", _uid)

    for _part_gd in SoldierPartUtils.get_all_part_gd():
        var _data: Dictionary = _part_gd.get_data()
        if _data.has(_uid):
            var _json = _data.get(_uid)
            if _json is Dictionary and _json.has("name"):
                return _json.get("name", _uid)
    return _uid




const MOD_AUCTION_ITEMS_PER_PAGE: int = 4




func _mod_auction_show_item_list_dialog()-> void:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        return
    var _goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    var _lv_name: String = _mod_auction_level_name(_mod_auction_current_level)

    if _goods.is_empty():
        _mod_auction_dialogue_active = false
        _mod_auction_show_end_dialog()
        return

    var _total: int = _goods.size()
    var _total_pages: int = int(ceil(float(_total) / float(MOD_AUCTION_ITEMS_PER_PAGE)))
    if _total_pages < 1:
        _total_pages = 1

    if _mod_auction_list_page >= _total_pages:
        _mod_auction_list_page = _total_pages - 1
    if _mod_auction_list_page < 0:
        _mod_auction_list_page = 0
    var _start: int = _mod_auction_list_page * MOD_AUCTION_ITEMS_PER_PAGE
    var _end: int = min(_start + MOD_AUCTION_ITEMS_PER_PAGE, _total)

    var _option_list: Array = []
    for _i in range(_start, _end):
        var _goods_json = _goods[_i]
        var _item_json = _goods_json.get("item",{})
        var _uid: String = _item_json.get("uid", "")
        var _item_name: String = _mod_get_part_name(_uid)
        var _base_price: int = int(_goods_json.get("base_price", 0))
        var _part_json = GlobalBsPart.bs_part_dic.get(_uid,{})
        var _part_star: int = int(_part_json.get("star", 0)) if _part_json != null else 0
        var _quality: int = int(_part_json.get("quality", 0)) if _part_json != null else 0
        var _star_str: String = str(_part_star) + "星"
        var _quality_str: String = _mod_quality_to_str(_quality)
        var _display: String = _item_name + " [" + _star_str + "] [" + _quality_str + "] (起拍价: " + str(_base_price) + "金币)"
        _option_list.append({
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": _display,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": [_display]}],
        })

    if _mod_auction_list_page > 0:
        _option_list.append({
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "上一页",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["上一页"]}],
        })
    if _mod_auction_list_page < _total_pages - 1:
        _option_list.append({
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "下一页",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["下一页"]}],
        })

    _option_list.append({
        "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
        "oname": "返回入口",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [{"clist": ["我先看看其他拍卖场。"]}],
    })
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }

    var _page_info: String = ""
    if _total_pages > 1:
        _page_info = " (第" + str(_mod_auction_list_page + 1) + "/" + str(_total_pages) + "页)"
    var _list_greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["欢迎来到" + _lv_name + "拍卖场!以下是今日拍卖品" + _page_info + ":"]}],
        "next": _options,
    }

    var _entry: Dictionary = _list_greeting
    if not _mod_auction_opening_shown:
        _mod_auction_opening_shown = true

        var _bidder_desc: String = "今天到场的有几位贵宾。"
        if not _mod_auction_bidders.is_empty():
            var _names: String = ""
            for _i in range(_mod_auction_bidders.size()):
                if _i > 0:
                    _names += "、"
                _names += _mod_auction_bidders[_i]
            _bidder_desc = "今天到场的有" + _names + "等" + str(_mod_auction_bidders.size()) + "位贵宾。"
        var _open3: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_auction_host",
            "content": [{"clist": ["下面开始竞拍,请看第一件拍品。"]}],
            "next": _list_greeting,
        }
        var _open2: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_auction_host",
            "content": [{"clist": [_bidder_desc]}],
            "next": _open3,
        }
        var _open1: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_auction_host",
            "content": [{"clist": ["各位贵宾,欢迎参加今日的拍卖会!我是今天的拍卖师。"]}],
            "next": _open2,
        }
        _entry = _open1
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": _lv_name + "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_entry, WSData.get_player_team_node().get_dialogue_info(), _right_info)



func _mod_auction_show_end_dialog()-> void:
    var _option_list: Array = [
        {
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "今日告辞",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["今日收获颇丰,告辞。"]}],
        },
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _end2: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["散场时,各位竞拍者陆续离席。"]}],
        "next": _options,
    }
    var _end1: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["今日的拍卖会到此结束,感谢各位贵宾的光临!"]}],
        "next": _end2,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_end1, WSData.get_player_team_node().get_dialogue_info(), _right_info)



func _mod_auction_start_bid(_item_idx: int)-> void:
    var _goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    if _item_idx < 0 or _item_idx >= _goods.size():
        return
    var _goods_json = _goods[_item_idx]
    var _base_price: int = int(_goods_json.get("base_price", 0))
    _mod_auction_current_item_idx = _item_idx
    _mod_auction_current_bid = _base_price
    _mod_auction_bid_round = 1
    _mod_auction_wait_round = 0

    _mod_auction_item_value = int(_base_price * 1.2)


    _mod_auction_bidder_budgets.clear()
    var _budget_max_rate: float = 1.5
    if _mod_auction_current_level == 2:
        _budget_max_rate = 3.0
    elif _mod_auction_current_level == 3:
        _budget_max_rate = 6.0
    for _i in range(_mod_auction_bidders.size()):
        var _rate: float = 0.8 + randf() *(_budget_max_rate - 0.8)
        _mod_auction_bidder_budgets.append(int(_mod_auction_item_value * _rate))
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_last_bidder_is_player = false
    _mod_auction_show_bid_dialog()




func _mod_auction_show_bid_dialog()-> void:
    var _goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    if _mod_auction_current_item_idx < 0 or _mod_auction_current_item_idx >= _goods.size():

        _mod_msg("拍卖会已结束,感谢参与!", 3.0, true)
        _mod_auction_close()
        return
    var _goods_json = _goods[_mod_auction_current_item_idx]
    var _item_json = _goods_json.get("item",{})
    var _uid: String = _item_json.get("uid", "")
    var _item_name: String = _mod_get_part_name(_uid)
    var _price: int = _mod_auction_current_bid
    var _round: int = _mod_auction_bid_round

    var _price_20: int = int(_price * 1.2)
    var _price_50: int = int(_price * 1.5)
    var _price_70: int = int(_price * 1.7)

    var _player_money: int = WSData.get_player_money()

    var _intro: String = "当前拍品:" + _item_name + ",当前价格:" + str(_price) + "金币。"
    if _round > 1:
        _intro = "当前价格:" + str(_price) + "金币,请出价或等待。"
    if _player_money < _price:
        _intro += "(警告:你的金币不足以支付当前价格,若拍得将无法成交!)"
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                "oname": "加价20%",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["加价20%出价(" + str(_price_20) + "金币)"]}],
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                "oname": "加价50%",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["加价50%出价(" + str(_price_50) + "金币)"]}],
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                "oname": "加价70%",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["加价70%出价(" + str(_price_70) + "金币)"]}],
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                "oname": "等待",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["等待,看看情况"]}],
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                "oname": "放弃",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["放弃竞拍。"]}],
            },
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_intro]}],
        "next": _options,
    }

    var _entry: Dictionary = _greeting
    if _round > 1 and _mod_auction_last_bidder_text != "":
        var _host_comment: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_auction_host",
            "content": [{"clist": [_mod_auction_last_host_text]}],
            "next": _greeting,
        }
        var _bidder_call: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_auction_host",
            "content": [{"clist": [_mod_auction_last_bidder_text]}],
            "next": _host_comment,
        }
        _entry = _bidder_call
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_entry, WSData.get_player_team_node().get_dialogue_info(), _right_info)




func _mod_auction_generate_bidder_reaction(_new_price: int)-> void:
    var _bidder: String = _mod_auction_pick_active_bidder()
    if _bidder == "":
        _mod_auction_last_bidder_text = ""
        _mod_auction_last_host_text = ""
        return
    var _price_str: String = str(_new_price)

    var _bidder_templates: Array = [
        "{name}举牌喊道:'{price}金币!'",
        "{name}不甘示弱:'我出{price}金币!'",
        "{name}沉思片刻后加价:'{price}金币。'",
        "{name}果断举牌:'{price}!'",
    ]

    var _host_templates: Array = [
        "场内气氛热烈,{name}率先加价!",
        "好的,{name}出价{price}金币,还有更高的吗?",
        "{name}志在必得,出价{price}金币!",
    ]
    var _bt: String = _bidder_templates[CommonUtils.random_num2(0, _bidder_templates.size() - 1)]
    var _ht: String = _host_templates[CommonUtils.random_num2(0, _host_templates.size() - 1)]
    _mod_auction_last_bidder_text = _bt.replace("{name}", _bidder).replace("{price}", _price_str)
    _mod_auction_last_host_text = _ht.replace("{name}", _bidder).replace("{price}", _price_str)








func _mod_auction_check_npc_bid(_current_price: int)-> bool:
    var _value: int = _mod_auction_item_value
    if _value <= 0:
        _value = _current_price

    for _i in range(_mod_auction_bidder_budgets.size()):
        if _mod_auction_bidder_budgets[_i] > 0 and _mod_auction_bidder_budgets[_i] < _current_price:
            _mod_auction_bidder_budgets[_i] = 0

    if _mod_auction_pick_active_bidder() == "":
        return false

    var _prob: float = 0.5
    if float(_current_price) < float(_value):
        _prob = 0.8
    elif float(_current_price) <= float(_value) * 1.2:
        _prob = 0.5
    elif float(_current_price) <= float(_value) * 1.5:
        _prob = 0.25
    else:
        _prob = 0.1

    if randf() > _prob:
        return false

    var _increase_rate: float = 0.08 + randf() * 0.67
    var _new_price: int = int(_current_price *(1.0 + _increase_rate))
    if _new_price <= _current_price:
        _new_price = _current_price + 1
    _mod_auction_current_bid = _new_price
    _mod_auction_last_bidder_is_player = false
    return true




func _mod_auction_process_bid(_bid_type: String)-> void:
    var _price: int = _mod_auction_current_bid

    var _new_price: int = _price
    var _win_prob: float = 0.3
    if _bid_type == "加价20%":
        _new_price = int(_price * 1.2)
        _win_prob = 0.3
    elif _bid_type == "加价50%":
        _new_price = int(_price * 1.5)
        _win_prob = 0.6
    elif _bid_type == "加价70%":
        _new_price = int(_price * 1.7)
        _win_prob = 0.9
    else:
        _new_price = int(_price * 1.2)
        _win_prob = 0.3
    if _new_price <= _price:
        _new_price = _price + 1

    var _player_money: int = WSData.get_player_money()
    if _player_money < _new_price:
        _mod_msg("金币不足,无法出价!", 2.5, false)
        _mod_auction_dialogue_active = false
        _mod_auction_show_bid_dialog()
        return

    _mod_auction_current_bid = _new_price
    _mod_auction_bid_round += 1
    _mod_auction_wait_round = 0
    _mod_auction_last_bidder_is_player = true

    if randf() < _win_prob:
        _mod_auction_win_bid()
        return

    if _mod_auction_check_npc_bid(_new_price):

        _mod_auction_generate_bidder_reaction(_mod_auction_current_bid)
        _mod_auction_dialogue_active = false
        _mod_auction_show_bid_dialog()
    else:

        _mod_auction_win_bid()








func _mod_auction_process_wait()-> void:
    _mod_auction_wait_round += 1
    _mod_auction_bid_round += 1
    var _price: int = _mod_auction_current_bid

    if _mod_auction_check_npc_bid(_price):

        if _mod_auction_wait_round >= 3:

            _mod_auction_generate_bidder_reaction(_mod_auction_current_bid)
            _mod_auction_dialogue_active = false
            _mod_auction_show_fail_dialog()
            return

        _mod_auction_generate_bidder_reaction(_mod_auction_current_bid)
        _mod_auction_dialogue_active = false
        _mod_auction_show_bid_dialog()
    else:



        if _mod_auction_last_bidder_is_player:
            _mod_auction_win_bid()
        else:

            _mod_auction_npc_win_bid()



func _mod_auction_show_fail_dialog()-> void:
    var _option_list: Array = [
        {
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "继续竞拍",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["继续看看其他拍品。"]}],
        },
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }

    var _bidder_react: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_mod_auction_last_bidder_text]}],
        "next": _options,
    }

    var _host_text: String = "这件拍品流拍了,我们看下一件。"
    if _mod_auction_last_host_text != "":
        _host_text = _mod_auction_last_host_text + " 这件拍品流拍了,我们看下一件。"
    var _host_fail: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_host_text]}],
        "next": _bidder_react,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }

    if _mod_auction_current_item_idx >= 0:
        var _fail_goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
        if _mod_auction_current_item_idx < _fail_goods.size():
            _fail_goods.remove_at(_mod_auction_current_item_idx)
            _mod_auction_save_goods_list(_mod_auction_current_level, _fail_goods)

    _mod_auction_current_item_idx = -1
    _mod_auction_current_bid = 0
    _mod_auction_bid_round = 0
    _mod_auction_wait_round = 0
    _mod_auction_item_value = 0
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_last_bidder_is_player = false
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_host_fail, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_auction_win_bid()-> void:
    var _price: int = _mod_auction_current_bid
    var _goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    if _mod_auction_current_item_idx < 0 or _mod_auction_current_item_idx >= _goods.size():
        return

    var _player_money: int = WSData.get_player_money()
    if _player_money < _price:
        _mod_msg("金币不足,无法拍得此物品!", 3.0, false)

        _mod_auction_current_item_idx = -1
        _mod_auction_current_bid = 0
        _mod_auction_bid_round = 0
        _mod_auction_wait_round = 0
        _mod_auction_item_value = 0
        _mod_auction_last_bidder_text = ""
        _mod_auction_last_host_text = ""
        _mod_auction_last_bidder_is_player = false
        _mod_auction_dialogue_active = false
        _mod_auction_show_item_list_dialog()
        return
    var _goods_json = _goods[_mod_auction_current_item_idx]
    var _item_json = _goods_json.get("item",{})
    var _uid: String = _item_json.get("uid", "")

    WSData.update_money(- _price, false)

    var _player_goods: Array = WSData.get_player_goods()
    _player_goods.append({"item": {"uid": _uid}, "count": 1})
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)

    _goods.remove_at(_mod_auction_current_item_idx)
    _mod_auction_save_goods_list(_mod_auction_current_level, _goods)
    var _item_name: String = _mod_get_part_name(_uid)
    _mod_msg("竞拍成功!获得" + _item_name + ",花费" + str(_price) + "金币", 3.0, true)

    _mod_auction_current_item_idx = -1
    _mod_auction_current_bid = 0
    _mod_auction_bid_round = 0
    _mod_auction_wait_round = 0
    _mod_auction_item_value = 0
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_last_bidder_is_player = false

    _mod_auction_dialogue_active = false
    _mod_auction_show_win_dialog(_price, _item_name)



func _mod_auction_npc_win_bid()-> void:
    var _price: int = _mod_auction_current_bid
    var _goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    if _mod_auction_current_item_idx < 0 or _mod_auction_current_item_idx >= _goods.size():
        _mod_auction_current_item_idx = -1
        _mod_auction_current_bid = 0
        _mod_auction_bid_round = 0
        _mod_auction_wait_round = 0
        _mod_auction_item_value = 0
        _mod_auction_last_bidder_text = ""
        _mod_auction_last_host_text = ""
        _mod_auction_last_bidder_is_player = false
        _mod_auction_dialogue_active = false
        _mod_auction_show_item_list_dialog()
        return
    var _goods_json = _goods[_mod_auction_current_item_idx]
    var _item_json = _goods_json.get("item",{})
    var _uid: String = _item_json.get("uid", "")
    var _item_name: String = _mod_get_part_name(_uid)

    _goods.remove_at(_mod_auction_current_item_idx)
    _mod_auction_save_goods_list(_mod_auction_current_level, _goods)

    var _bidder_name: String = "一位竞拍者"
    if not _mod_auction_bidders.is_empty():
        _bidder_name = _mod_auction_bidders[0]
    _mod_msg(_bidder_name + "以" + str(_price) + "金币拍得了" + _item_name, 3.0, false)

    _mod_auction_current_item_idx = -1
    _mod_auction_current_bid = 0
    _mod_auction_bid_round = 0
    _mod_auction_wait_round = 0
    _mod_auction_item_value = 0
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_last_bidder_is_player = false

    _mod_auction_show_npc_win_dialog(_price, _item_name, _bidder_name)


func _mod_auction_show_npc_win_dialog(_price: int, _item_name: String, _bidder_name: String)-> void:
    var _option_list: Array = [
        {
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "继续竞拍",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["继续看看其他拍品。"]}],
        },
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }

    var _bystander_react: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["啧, " + _bidder_name + "倒是捡了个实惠。下次可得果断些, 犹豫可赚不到便宜。"]}],
        "next": _options,
    }

    var _host_text: String = "成交!" + _bidder_name + "以" + str(_price) + "金币拍得" + _item_name + "!"
    var _host_deal: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_host_text]}],
        "next": _bystander_react,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_host_deal, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_auction_show_win_dialog(_price: int, _item_name: String)-> void:
    var _option_list: Array = [
        {
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "继续竞拍",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["继续竞拍其他拍品。"]}],
        },
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }

    var _bidder: String = _mod_auction_pick_bidder()
    var _bystander_templates: Array = [
        "场内响起一阵掌声。",
        "其他竞拍者纷纷摇头叹息。",
        "人群中传来议论声:'这价格可不便宜啊。'",
    ]
    if _bidder != "":
        _bystander_templates.append(_bidder + "无奈地放下了号牌。")
    var _bystander_text: String = _bystander_templates[CommonUtils.random_num2(0, _bystander_templates.size() - 1)]
    var _bystander: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_bystander_text]}],
        "next": _options,
    }

    var _deal_text: String = "成交!" + str(_price) + "金币,这位客人拍得" + _item_name + "!"
    var _host_deal: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_deal_text]}],
        "next": _bystander,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_host_deal, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_auction_show_abandon_dialog()-> void:
    var _option_list: Array = [
        {
            "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
            "oname": "继续竞拍",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["继续看看其他拍品。"]}],
        },
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }

    var _bidder: String = _mod_auction_pick_bidder()
    var _bidder_text: String = "其他竞拍者似乎松了一口气。"
    if _bidder != "":
        _bidder_text = _bidder + "似乎松了一口气。"
    var _bidder_react: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": [_bidder_text]}],
        "next": _options,
    }

    var _host_ask: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_auction_host",
        "content": [{"clist": ["这位客人放弃了,还有谁感兴趣?"]}],
        "next": _bidder_react,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_auction_host",
        "leader_name": "拍卖师",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    _mod_auction_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_host_ask, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_auction_find_item_idx_by_uid(_uid: String)-> int:
    var _goods: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    for _i in range(_goods.size()):
        var _goods_json = _goods[_i]
        var _item_json = _goods_json.get("item",{})
        if _item_json.get("uid", "") == _uid:
            return _i
    return -1


func _mod_auction_close()-> void:
    _mod_auction_dialogue_active = false
    _mod_auction_active = false
    _mod_auction_current_level = 0
    _mod_auction_current_item_idx = -1
    _mod_auction_current_bid = 0
    _mod_auction_bid_round = 0
    _mod_auction_wait_round = 0
    _mod_auction_item_value = 0
    _mod_auction_bidders.clear()
    _mod_auction_bidder_budgets.clear()
    _mod_auction_opening_shown = false
    _mod_auction_last_bidder_text = ""
    _mod_auction_last_host_text = ""
    _mod_auction_last_bidder_is_player = false
    _mod_auction_list_page = 0
    if is_instance_valid(special_build_interface_node) and special_build_interface_node.visible:
        special_build_interface_node.chide()
    if is_instance_valid(location_enter_interface_node):
        location_enter_interface_node.show_button()
    print("[MapMod] 拍卖行界面已关闭")





func _mod_auction_handle_dialogue_finish(_result_option_type)-> void:
    var _oname: String = dialogue_interface_node.last_selected_oname

    if is_instance_valid(special_build_interface_node) and special_build_interface_node.visible:
        special_build_interface_node.unchoose_charactar_card()

    if _oname == "高级拍卖场":
        _mod_auction_dialogue_active = false
        _mod_auction_enter_or_pay_ticket(3)
        return
    if _oname == "中级拍卖场":
        _mod_auction_dialogue_active = false
        _mod_auction_enter_or_pay_ticket(2)
        return
    if _oname == "低级拍卖场":
        _mod_auction_dialogue_active = false
        _mod_auction_enter_or_pay_ticket(1)
        return

    if _oname == "告辞":
        _mod_auction_dialogue_active = false
        _mod_auction_close()
        return

    if _oname == "交2件5星武器":
        _mod_auction_dialogue_active = false
        _mod_auction_pay_with_item(3)
        return
    if _oname == "交3件4星蓝装":
        _mod_auction_dialogue_active = false
        _mod_auction_pay_with_item(2)
        return

    if _oname == "交22000金币":
        _mod_auction_dialogue_active = false
        _mod_auction_pay_with_gold(3)
        return
    if _oname == "交12000金币":
        _mod_auction_dialogue_active = false
        _mod_auction_pay_with_gold(2)
        return
    if _oname == "交5000金币":
        _mod_auction_dialogue_active = false
        _mod_auction_pay_with_gold(1)
        return

    if _oname == "返回":
        _mod_auction_dialogue_active = false
        _mod_auction_show_entry_dialog()
        return

    if _oname == "返回入口":
        _mod_auction_dialogue_active = false
        _mod_auction_list_page = 0
        _mod_auction_show_entry_dialog()
        return

    if _oname == "上一页":
        _mod_auction_dialogue_active = false
        _mod_auction_list_page -= 1
        if _mod_auction_list_page < 0:
            _mod_auction_list_page = 0
        _mod_auction_show_item_list_dialog()
        return
    if _oname == "下一页":
        _mod_auction_dialogue_active = false
        _mod_auction_list_page += 1
        _mod_auction_show_item_list_dialog()
        return

    if _oname == "加价20%" or _oname == "加价50%" or _oname == "加价70%":
        _mod_auction_dialogue_active = false
        _mod_auction_process_bid(_oname)
        return

    if _oname == "等待":
        _mod_auction_dialogue_active = false
        _mod_auction_process_wait()
        return

    if _oname == "放弃":
        _mod_auction_current_item_idx = -1
        _mod_auction_current_bid = 0
        _mod_auction_bid_round = 0
        _mod_auction_wait_round = 0
        _mod_auction_item_value = 0
        _mod_auction_last_bidder_text = ""
        _mod_auction_last_host_text = ""
        _mod_auction_dialogue_active = false
        _mod_auction_show_abandon_dialog()
        return

    if _oname == "继续竞拍":
        _mod_auction_dialogue_active = false
        _mod_auction_show_item_list_dialog()
        return

    if _oname == "今日告辞":
        _mod_auction_dialogue_active = false
        _mod_auction_close()
        return

    var _goods_list: Array = _mod_auction_get_goods_list(_mod_auction_current_level)
    for _gi in range(_goods_list.size()):
        var _gj = _goods_list[_gi]
        var _item_uid: String = _gj.get("item",{}).get("uid", "")
        var _item_display: String = _mod_get_part_name(_item_uid)
        var _part_j = GlobalBsPart.bs_part_dic.get(_item_uid,{})
        var _p_star: int = int(_part_j.get("star", 0)) if _part_j != null else 0
        var _p_quality: int = int(_part_j.get("quality", 0)) if _part_j != null else 0
        var _p_star_str: String = str(_p_star) + "星"
        var _p_quality_str: String = _mod_quality_to_str(_p_quality)
        var _p_price: int = int(_gj.get("base_price", 0))
        var _expected: String = _item_display + " [" + _p_star_str + "] [" + _p_quality_str + "] (起拍价: " + str(_p_price) + "金币)"
        if _oname == _expected:
            _mod_auction_dialogue_active = false
            _mod_auction_start_bid(_gi)
            return

    _mod_auction_dialogue_active = false




func _mod_auction_get_goods_list(_level: int)-> Array:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        return[]
    var _city_data: Dictionary = WSLocationData.city_data.get(ISLAND_CITY_CODE)
    var _key: String = "mod_auction_low_goods"
    if _level == 3:
        _key = "mod_auction_high_goods"
    elif _level == 2:
        _key = "mod_auction_mid_goods"
    var _goods: Array = _city_data.get(_key,[])

    var _filtered: Array = []
    for _g in _goods:
        var _item_uid: String = _g.get("item",{}).get("uid", "")
        if MOD_AUCTION_EXCLUDED_UIDS.has(_item_uid):
            continue
        _filtered.append(_g)
    return _filtered


func _mod_auction_save_goods_list(_level: int, _goods: Array)-> void:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        return
    var _city_data: Dictionary = WSLocationData.city_data.get(ISLAND_CITY_CODE)
    var _key: String = "mod_auction_low_goods"
    if _level == 3:
        _key = "mod_auction_high_goods"
    elif _level == 2:
        _key = "mod_auction_mid_goods"
    _city_data[_key] = _goods


func _mod_refresh_auction_goods_if_needed(_city_data: Dictionary = {})-> void:
    if _city_data.is_empty():
        if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
            return
        _city_data = WSLocationData.city_data.get(ISLAND_CITY_CODE)


    if _mod_auction_is_active:
        var _high: Array = _mod_auction_get_goods_list(3)
        var _mid: Array = _mod_auction_get_goods_list(2)
        var _low: Array = _mod_auction_get_goods_list(1)
        if _high.is_empty() and _mid.is_empty() and _low.is_empty():
            _mod_generate_auction_goods(_city_data)
            _city_data["mod_auction_refresh_day"] = WSData.system_counter


func _mod_refresh_auction_if_needed()-> void:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        return
    var _city_data: Dictionary = WSLocationData.city_data.get(ISLAND_CITY_CODE)
    _mod_refresh_auction_goods_if_needed(_city_data)


func _mod_check_auction_daily_refresh()-> void:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        return
    var _city_data: Dictionary = WSLocationData.city_data.get(ISLAND_CITY_CODE)
    var _current_day: float = WSData.system_counter

    if _mod_auction_next_start_day < 0.0:
        var _saved_start: float = float(_city_data.get("mod_auction_next_start_day", -1.0))
        if _saved_start >= 0.0:
            _mod_auction_next_start_day = _saved_start
            _mod_auction_is_active = bool(_city_data.get("mod_auction_is_active", false))
            _mod_auction_end_day = float(_city_data.get("mod_auction_end_day", -1.0))
        else:
            _mod_auction_next_start_day = _current_day + 2.0
            print("[MapMod] 拍卖会首次开始时间设置: ", _mod_auction_next_start_day)
    print("[MapMod] 拍卖会周期检查: active=", _mod_auction_is_active, " counter=", _current_day, " next_start=", _mod_auction_next_start_day, " end=", _mod_auction_end_day)

    if not _mod_auction_is_active and _current_day >= _mod_auction_next_start_day:

        _mod_auction_is_active = true
        _mod_auction_end_day = _current_day + 3.0
        _mod_generate_auction_goods(_city_data)
        _city_data["mod_auction_refresh_day"] = _current_day
        _city_data["mod_auction_next_start_day"] = _mod_auction_next_start_day
        _city_data["mod_auction_is_active"] = true
        _city_data["mod_auction_end_day"] = _mod_auction_end_day

        var _msg: String = "斯卡城拍卖会今日开幕!持续3天,快去看看吧!"
        _mod_msg(_msg, 3.0, true)
        print("[MapMod] 拍卖会开始! end_day=", _mod_auction_end_day)
        return

    if _mod_auction_is_active and _current_day >= _mod_auction_end_day:
        _mod_auction_is_active = false
        _mod_auction_next_start_day = _current_day + 12.0
        _city_data["mod_auction_is_active"] = false
        _city_data["mod_auction_next_start_day"] = _mod_auction_next_start_day
        _city_data["mod_auction_end_day"] = -1.0

        _city_data["mod_auction_high_goods"] = []
        _city_data["mod_auction_mid_goods"] = []
        _city_data["mod_auction_low_goods"] = []
        var _msg2: String = "斯卡城拍卖会已结束,下次将在" + str(int(_mod_auction_next_start_day - _current_day)) + "天后举行。"
        _mod_msg(_msg2, 3.0, true)
        print("[MapMod] 拍卖会结束! next_start=", _mod_auction_next_start_day)


func _mod_generate_auction_goods(_city_data: Dictionary)-> void:

    var _high_goods: Array = _mod_pick_auction_items(5, 4, 6)
    if randf() < 0.4:
        var _legend_item: Array = _mod_pick_auction_items_by_quality(6, 1, 1, -1)
        if _legend_item.size() > 0:
            _high_goods.append(_legend_item[0])
    _city_data["mod_auction_high_goods"] = _high_goods

    var _mid_goods: Array = _mod_pick_auction_items(4, 4, 6)
    var _rare_count: int = CommonUtils.random_num2(1, 2)
    var _rare_items: Array = _mod_pick_auction_items_by_quality(5, _rare_count, _rare_count, 2)
    for _item in _rare_items:
        _mid_goods.append(_item)
    _city_data["mod_auction_mid_goods"] = _mid_goods

    var _low_goods: Array = _mod_pick_auction_items(3, 4, 6)
    var _hq_item: Array = _mod_pick_auction_items_by_quality(4, 1, 1, 1)
    if _hq_item.size() > 0:
        _low_goods.append(_hq_item[0])
    _city_data["mod_auction_low_goods"] = _low_goods
    print("[MapMod] 拍卖品生成完成: 高级", _city_data["mod_auction_high_goods"].size(),
          "件, 中级", _city_data["mod_auction_mid_goods"].size(),
          "件, 低级", _city_data["mod_auction_low_goods"].size(), "件")


func _mod_pick_auction_items(_star: int, _min_count: int, _max_count: int)-> Array:
    var _candidate_uids: Array = []
    var _allowed_etypes: Array = [
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HORSE,
    ]

    for _uid in GlobalBsPart.bs_part_dic.keys():
        if MOD_AUCTION_EXCLUDED_UIDS.has(_uid):
            continue
        var _part_json = GlobalBsPart.bs_part_dic.get(_uid)
        if _part_json == null:
            continue
        var _etype = WeaponTypeConstants.get_etype(_uid)
        if _etype == null or not _allowed_etypes.has(_etype):
            continue
        var _part_star: int = int(_part_json.get("star", 0))
        if _part_star != _star:
            continue
        _candidate_uids.append(_uid)
    if _candidate_uids.is_empty():
        return[]

    var _count: int = CommonUtils.random_num2(_min_count, _max_count)
    _count = min(_count, _candidate_uids.size())
    var _picked_uids: Array = ArrayUtils.random_ele_list(_candidate_uids, _count)
    var _result: Array = []
    for _uid in _picked_uids:
        var _base_price: int = _mod_calc_base_price(_uid, _star)
        _result.append({
            "item": {"uid": _uid},
            "count": 1,
            "base_price": _base_price,
        })
    return _result




func _mod_pick_auction_items_by_quality(_star: int, _min_count: int, _max_count: int, _quality_filter: int)-> Array:
    var _candidate_uids: Array = []
    var _allowed_etypes: Array = [
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE,
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HORSE,
    ]
    var _fine_q = WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.FINE
    var _excellent_q = WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.EXCELLENT
    for _uid in GlobalBsPart.bs_part_dic.keys():
        if MOD_AUCTION_EXCLUDED_UIDS.has(_uid):
            continue
        var _part_json = GlobalBsPart.bs_part_dic.get(_uid)
        if _part_json == null:
            continue
        var _etype = WeaponTypeConstants.get_etype(_uid)
        if _etype == null or not _allowed_etypes.has(_etype):
            continue
        var _part_star: int = int(_part_json.get("star", 0))
        if _part_star != _star:
            continue
        var _quality: int = int(_part_json.get("quality", 0))

        if _quality_filter == -1:

            if _quality >= _fine_q:
                continue
        elif _quality_filter == 1:

            if _quality < _excellent_q:
                continue
        elif _quality_filter == 2:

            if _quality < _excellent_q:
                continue

        _candidate_uids.append(_uid)
    if _candidate_uids.is_empty():
        return[]
    var _count: int = CommonUtils.random_num2(_min_count, _max_count)
    _count = min(_count, _candidate_uids.size())
    var _picked_uids: Array = ArrayUtils.random_ele_list(_candidate_uids, _count)
    var _result: Array = []
    for _uid in _picked_uids:
        var _base_price: int = _mod_calc_base_price(_uid, _star)
        _result.append({
            "item": {"uid": _uid},
            "count": 1,
            "base_price": _base_price,
        })
    return _result


func _mod_calc_base_price(_uid: String, _star: int)-> int:
    var _part_json = GlobalBsPart.bs_part_dic.get(_uid,{})
    var _base: int = 0
    if _part_json != null and _part_json.has("price"):
        _base = int(_part_json.get("price", 0))
    if _base <= 0:

        _base = _star * _star * 200

    var _rate: float = float(CommonUtils.random_num2(50, 80)) / 100.0
    var _price: int = int(_base * _rate)
    if _price < 100:
        _price = 100
    return _price







func _mod_init_auction_schedule(_world_data: Dictionary)-> void:
    if _world_data.has("mod_auction_next_start_day"):
        _mod_auction_next_start_day = float(_world_data.get("mod_auction_next_start_day", -1.0))
    if _world_data.has("mod_auction_is_active"):
        _mod_auction_is_active = bool(_world_data.get("mod_auction_is_active", false))
    if _world_data.has("mod_auction_end_day"):
        _mod_auction_end_day = float(_world_data.get("mod_auction_end_day", -1.0))
    print("[MapMod] 拍卖会周期恢复: next_start=", _mod_auction_next_start_day, " active=", _mod_auction_is_active, " end=", _mod_auction_end_day)

const MOD_MINT_SMELT_PER_DAY: int = 30
const MOD_MINT_COINS_PER_INGOT: int = 450

var _mod_tip_timer: Timer = null

var _mod_migration_save_timer: Timer = null

var _mod_cg_overlay: TextureRect = null

const MOD_JOIN_COUNTRY_CG_PATH: Dictionary = {
    WSCountryData.COUNTRY_NAME_ENUM.LUCIANA: "res://resource/cg/join_luciana.png",
    WSCountryData.COUNTRY_NAME_ENUM.HASKAL: "res://resource/cg/join_haskal.png",
    WSCountryData.COUNTRY_NAME_ENUM.DORDAR: "res://resource/cg/join_dordar.png",
}
@onready var day_and_night_sync_node: DayAndNightSync =$DayAndNightSync
@onready var game_info_interface_root_node: Control =$CanvasLayer / InterfaceRoot / GameInfoInterfaceRoot
@onready var player_rel_info_interface_root_node: Control =$CanvasLayer / InterfaceRoot / PlayerRelInfoInterfaceRoot

const GAME_INFO_INTERFACE = preload("res://tscn/game/interface/ws/GameInfoInterface.tscn")
const PLAYER_REL_INFO_INTERFACE = preload("res://tscn/game/interface/ws/PlayerRelInfoInterface.tscn")

const TIP_ENUM = {
    PAUSE = "暂停中",
    RUN = "流逝中",
    ACCELERATE = "加速中",
    CAMPING = "露营休息中",
    TRAIN = "训练中",
    LOCATION_REST = "休息中",
}

@export var right_goods_name: String

var player_team_node: MWTeamPlayer

var choose_location_node: MWLocationBase

var choose_team_node: MWTeam

var view_choose_team_node: MWTeam

var view_choose_location_node: MWLocationBase

var player_meet_node = null
var map_size = Vector2.ZERO

var is_day: = true
var is_first_stop = true


var _mod_dialogue_active: bool = false
var _mod_dialogue_watchdog: Timer = null
var _mod_dialogue_start_time: float = 0.0


var mobile_touch_start: = false

var mobile_touch_duration_counter: = 0
var mobile_initial_positions: = []

var mobile_two_finger_distance: float = 0.0


signal location_light()
signal location_turn_off_light()

func _ready():

    GlobalMessageInterface.connect("important_message_box_close_sign", _important_message_box_close_follow_up)


    if not Engine.is_editor_hint():
        var _am_script = load("res://gd/global/AchievementManager.gd")
        if _am_script != null:
            var _am = _am_script.new()
            _am.name = "AchievementManager"
            add_child(_am)













    dialogue_interface_node.mod_show_join_country_cg_sign.connect(_mod_show_join_country_cg)



    _mod_dialogue_watchdog = Timer.new()
    _mod_dialogue_watchdog.name = "DialogueWatchdog"
    _mod_dialogue_watchdog.wait_time = 5.0
    _mod_dialogue_watchdog.autostart = true
    _mod_dialogue_watchdog.timeout.connect(_mod_dialogue_watchdog_tick)

    _mod_dialogue_watchdog.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(_mod_dialogue_watchdog)

func _c_unhandled_input(event):
    if CommonUtils.platform_is_pc():
        if MouseUtils.check_mouse_left_click(event):
            if view_func_root_node.show_mode:
                return


            _player_move_land(common_camera_node.get_global_mouse_position())

        if Input.is_action_pressed("hide_menu"):
            canvas_layer_node.visible = not canvas_layer_node.visible
            GlobalMessageInterface.visible = not GlobalMessageInterface.visible
            for _location_node in city_root_node.get_children():
                _location_node.hide_or_show_tag(canvas_layer_node.visible)
            for _location_node in village_root_node.get_children():
                _location_node.hide_or_show_tag(canvas_layer_node.visible)
            for _location_node in castle_root_node.get_children():
                _location_node.hide_or_show_tag(canvas_layer_node.visible)
    else:
        _handle_mobile_control(event)

func _handle_mobile_control(_event: InputEvent):
    if _event is InputEventScreenTouch:
        if _event.pressed:
            mobile_touch_start = true
            mobile_touch_duration_counter = 0
            if mobile_initial_positions.size() < 2:
                mobile_initial_positions.append(_event.position)
        else:
            if mobile_initial_positions.size() == 1:

                if mobile_touch_start and mobile_touch_duration_counter < MobileConfig.CLICK_TOUCH_DURATION_COUNTER \
                and(_event.position - mobile_initial_positions[0]).length_squared() < MobileConfig.CLICK_DISTANCE_MAX_SQUARE:

                    mobile_touch_start = false
                    if not view_func_root_node.show_mode:
                        _player_move_land(common_camera_node.get_global_mouse_position())

            if mobile_initial_positions.size() > 0:
                mobile_initial_positions.clear()
            mobile_touch_start = false
    elif _event is InputEventScreenDrag:
        if mobile_initial_positions.size() == 1 and(_event.position - mobile_initial_positions[0]).length_squared() > MobileConfig.CLICK_DISTANCE_MAX_SQUARE:
            mobile_touch_start = false


func init(_world_data: Dictionary = {})-> void:

    _mod_log("init: START")
    GlobalCountryData.handle_country_data()
    _mod_log("init: handle_country_data done")


    _mod_log("init: skip clear")



    if common_camera_node:
        common_camera_node.limit_bottom = EXPANDED_BOTTOM
    _mod_log("init: camera limit done")

    _reload_world_data(_world_data)
    _mod_log("init: reload_world_data done")


    map_size = Vector2(common_camera_node.limit_right, common_camera_node.limit_bottom)

    mwb_rain_root_node.update_size(map_size)
    _mod_log("init: rain update done")


    _init_all_location()
    _mod_log("init: init_all_location done")


    for _root in[village_root_node, castle_root_node, city_root_node, special_location_root_node]:
        for _loc in _root.get_children():
            GlobalLocationData.set_location_node(_loc.get_location_code(), _loc)
    _mod_log("init: re-register done")



    _place_island_city()
    _mod_log("init: place_island_city done")


    _place_lumber_mill()
    _mod_log("init: place_lumber_mill done")


    _place_mine()
    _mod_log("init: place_mine done")

    var _team_idx = 0
    for _team_data in WSData.other_team_data.values():
        _mod_log("init: creating team #", _team_idx, "uid=", CommonUtils.get_value(_team_data, "uid", "?"))
        _init_mw_team(_team_data)
        _team_idx += 1
    _mod_log("init: init NPC teams done, count=", WSData.other_team_data.size())



    var _node = _init_mw_team(WSData.player_data)
    _mod_log("init: player team created")


    _connect_player_node_sign(_node)

    player_team_node = _node
    WSData.set_player_team_node(_node)
    _mod_log("init: player node connected")

    if _world_data.has("current_weather"):
        weather_executor_node.init(_world_data.current_weather, _world_data.rain_remain_counter)
        mwb_rain_root_node.update_weather(_world_data.current_weather)
        change_weather(_world_data.current_weather)
    _mod_log("init: weather done")


    if _mod_tip_timer == null:
        _mod_tip_timer = Timer.new()
        _mod_tip_timer.name = "ModTipTimer"
        _mod_tip_timer.wait_time = 3.0
        _mod_tip_timer.one_shot = true
        _mod_tip_timer.timeout.connect(func(): tip_node.chide())
        add_child(_mod_tip_timer)


    _mod_init_typhoon(_world_data)
    _mod_log("init: typhoon init done")


    if _world_data.has("mod_player_on_island"):
        _mod_player_on_island = bool(_world_data.get("mod_player_on_island", false))
    elif is_instance_valid(player_team_node):

        _mod_player_on_island = player_team_node.global_position.y > 4000.0
    _mod_log("init: player region restored, on_island=" + str(_mod_player_on_island))


    _mod_init_auction_schedule(_world_data)
    _mod_log("init: auction schedule init done")


    _mod_init_lumber_mill(_world_data)
    _mod_log("init: lumber mill init done")


    _mod_init_mine(_world_data)
    _mod_log("init: mine init done")


    _mod_init_mint(_world_data)
    _mod_log("init: mint init done")


    _mod_migrate_prisoners_to_capture()
    _mod_log("init: prisoners migration done")


    _mod_validate_workers_integrity()
    _mod_log("init: workers integrity validation done")

    _register_wild_generate_area()
    _mod_log("init: register_wild done")

    mw_clock_and_day_light_controller_node.start()

    day_and_night_sync_node.start()
    _mod_log("init: clock start done")



    _camera_to_player()
    _mod_log("init: camera_to_player done")

    _refresh_upgrade_soldier_icon()

    m_world_left_info_area_node.refresh()
    m_world_left_info_area_node.speed_button_init()

    self.stop()
    _mod_log("init: stop done")





    bird_root_node.init(map_size)
    m_cloud_root_node.init(map_size)
    mw_top_box_node.update_day()
    _mod_log("init: birds/clouds done")


    _init_new_lord()
    _mod_log("init: init_new_lord done")

    WSData.refresh_wages()
    _mod_log("init: refresh_wages done")


    m_world_left_info_area_node.maybe_hide_train_and_camping_button()

    _handle_lord_disappear_bug()
    _mod_log("init: handle_lord_disappear done")


    _generate_neutral_nun_if_not_exist()
    _mod_log("init: generate_nun done")


    TeamUtils.generate_slave_duel_host_if_not_exist(self)
    _mod_log("init: generate_slave_duel_host done")


    _generate_conquest_knight_if_not_exist()
    _mod_log("init: generate_conquest_knight done")



    call_deferred("_setup_new_map")
    _mod_log("init: DEFERRED setup_new_map queued")


    if WSData.mod_migration_pending_save:
        WSData.mod_migration_pending_save = false
        if _mod_migration_save_timer == null:
            _mod_migration_save_timer = Timer.new()
            _mod_migration_save_timer.name = "ModMigrationSaveTimer"
            _mod_migration_save_timer.one_shot = true
            _mod_migration_save_timer.timeout.connect(_mod_do_force_save)
            add_child(_mod_migration_save_timer)
        _mod_migration_save_timer.start(1.0)
        _mod_log("init: migration save timer started (1s)")



func _mod_do_force_save()-> void:
    GlobalSave.save(false, false)
    print("[ModMigration] 迁移数据已强制存档完成")










func _mod_migrate_prisoners_to_capture()-> void:
    var _flag_key: String = "prisoners_to_capture_migrated"
    if WSData.mod_migration_flags.get(_flag_key, false):
        return

    var _capture: Array = WSData.get_capture()
    var _replaced_total: int = 0


    var _lm_replaced: int = _mod_replace_fake_prisoners_in_workers(_mod_lumber_mill_workers, "mod_prisoner_worker_", _capture)
    _replaced_total += _lm_replaced


    var _mine_replaced: int = _mod_replace_fake_prisoners_in_workers(_mod_mine_workers, "mod_mine_prisoner_worker_", _capture)
    _replaced_total += _mine_replaced

    if _replaced_total > 0:
        WSData.update_capture(_capture)
        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)


    _mod_lumber_mill_prisoners_out = 0
    _mod_mine_prisoners_out = 0


    WSData.mod_migration_flags[_flag_key] = true
    WSData.mod_migration_pending_save = true

    if _replaced_total > 0:
        print("[ModMigration] 俘虏数据迁移完成: 替换", _replaced_total, "个假俘虏为真实数据")



func _mod_replace_fake_prisoners_in_workers(_workers: Array, _fake_uid_prefix: String, _capture: Array)-> int:
    var _replaced: int = 0
    for _i in range(_workers.size() - 1, -1, -1):
        var _worker = _workers[_i]
        if not bool(_worker.get("is_prisoner", false)):
            continue
        var _uid: String = str(_worker.get("uid", ""))
        if not _uid.begins_with(_fake_uid_prefix):
            continue

        if _capture.is_empty():

            _workers.remove_at(_i)
            print("[ModMigration] 移除无对应真实俘虏的假俘虏: ", _uid)
        else:
            var _real_prisoner: Dictionary = _capture.pop_back()
            _real_prisoner["is_prisoner"] = true
            _workers[_i] = _real_prisoner
            _replaced += 1
    return _replaced






func _mod_validate_workers_integrity()-> void:
    var _team: Array = WSData.player_data.team


    var _cleaned_flags: int = 0
    for _soldier in _team:
        if _soldier is Dictionary and _soldier.has("is_prisoner"):
            _soldier.erase("is_prisoner")
            _cleaned_flags += 1
    if _cleaned_flags > 0:
        print("[MapMod] 验证: 清理队伍中残留is_prisoner标记: ", _cleaned_flags, "个")









    print("[MapMod] 验证: 伐木场工人=", _mod_lumber_mill_workers.size(), " 采矿场工人=", _mod_mine_workers.size(), " (按UID去重已禁用: uid非唯一实例ID)")

    if _cleaned_flags > 0:
        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)

        WSData.mod_migration_pending_save = true








func _mod_remove_duplicate_workers(_workers: Array, _team_uids: Dictionary, _capture_uids: Dictionary, _facility_name: String)-> int:

    var _type_match_count: int = 0
    for _worker in _workers:
        if _worker is Dictionary:
            var _uid: String = str(_worker.get("uid", ""))
            if _uid != "" and _team_uids.has(_uid):
                _type_match_count += 1
    if _type_match_count > 0:
        print("[MapMod] 诊断: ", _facility_name, "有", _type_match_count, "名工人与队伍兵种相同(uid=", "共类型, 非重复实例", "), 已按设计保留不去重")
    return 0







func _mod_purge_duplicate_workers_daily(_workers: Array, _facility_name: String)-> void:
    var _team: Array = WSData.player_data.team

    var _team_uids: Dictionary = {}
    for _s in _team:
        if _s is Dictionary:
            var _uid: String = str(_s.get("uid", ""))
            if _uid != "":
                _team_uids[_uid] = true
    var _type_match_count: int = 0
    for _worker in _workers:
        if _worker is Dictionary:
            var _uid: String = str(_worker.get("uid", ""))
            if _uid != "" and _team_uids.has(_uid):
                _type_match_count += 1
    if _type_match_count > 0:
        print("[MapMod] 诊断: ", _facility_name, "有", _type_match_count, "/", _workers.size(), "名工人与队伍兵种同类型(共享uid, 非重复实例), 保留不去重")
    return


func _generate_neutral_nun_if_not_exist()-> void:
    var _npc_team_code: String = NpcTeamConstants.NPC_TEAM_CODE.NEUTRAL_NUN

    if not GlobalNpcTeamData.spawn_trigger_power_value_data.has(_npc_team_code):
        GlobalNpcTeamData.spawn_trigger_power_value_data[_npc_team_code] = {
            "current_value": 0,
            "is_team_exist": false,
        }
    var _data: Dictionary = GlobalNpcTeamData.spawn_trigger_power_value_data.get(_npc_team_code)
    if _data.is_team_exist:
        return
    var _success: bool = generate_neutral_nun_team()
    if _success:
        _data.is_team_exist = true


func _generate_conquest_knight_if_not_exist()-> void:
    var _ck_code: String = NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT
    if not GlobalNpcTeamData.spawn_trigger_power_value_data.has(_ck_code):
        GlobalNpcTeamData.spawn_trigger_power_value_data[_ck_code] = {
            "current_value": 0,
            "is_team_exist": false,
            "is_revival_allowed": true,
        }
    var _ck_data: Dictionary = GlobalNpcTeamData.spawn_trigger_power_value_data[_ck_code]

    if _ck_data.get("is_team_exist", false):
        return

    if _ck_data.has("death_days"):
        return

    var _success: bool = generate_villain_boss_team(_ck_code)
    if _success:
        _ck_data.current_value = 0
        _ck_data.is_team_exist = true
        _mod_log("init: 征伐骑士(黑月教廷)已在沙漠生成")


func stop():
    GlobalTimeControl.time_normal()
    get_tree().paused = true

    if is_first_stop:
        PhysicsServer2D.set_active(true)
        is_first_stop = false

    mw_clock_and_day_light_controller_node.stop()
    tip_node.cshow(TIP_ENUM.PAUSE)

func stop_include_camera():
    stop()
    _forbid_operation()

func run():
    get_tree().paused = false


    mw_clock_and_day_light_controller_node.restart()
    common_camera_node.func_open()
    input_area_node.run()










    if not[
        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE,
        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.TRAIN,

        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.THINKING
    ].has(TeamUtils.get_player_action_status()):
        tip_node.chide()

func stop_and_show_module():
    m_world_left_info_area_node.stop_button()

    _show_module()

func stop_and_hide_module()-> void:
    m_world_left_info_area_node.stop_button()
    stop_include_camera()
    _hide_button_module_root()

func _show_module():
    common_camera_node.func_open()
    _show_button_module_root()
    input_area_node.run()


func create_team(_team_json: Dictionary):
    _init_mw_team(_team_json)


    WSData.save_other_team(_team_json)



func spawn_npc_team(_team_json: Dictionary)-> void:
    create_team(_team_json)


func switch_back():
    m_world_left_info_area_node.stop_button()
    m_world_left_info_area_node.refresh()



    stop_and_show_module()


    var _battle_data: Dictionary = _handle_player_battle_end()


    if CommonUtils.get_value(_battle_data, "need_plus_morality_value", false):
        var _ally_relation_gain_after_battle_factor: float = CommonUtils.get_value(_battle_data, "ally_relation_gain_after_battle_factor", 0.0)
        SoldierUtils.plus_player_morality_value(_ally_relation_gain_after_battle_factor)


    _camera_to_player()
    _refresh_upgrade_soldier_icon()
    _refresh_player_team_info()

    if player_team_node.get_count() == 0:
        player_team_node.hide()

        _on_main_menu_button_pressed(true)
        player_path_line_node.hide()


        GlobalTempData.reset_mult_battle_data()
        return
    else:
        if GlobalPlayerConfig.is_auto_save and CommonUtils.get_value(_battle_data, "need_auto_save", true):
            GlobalSave.save(true, true)


    WSData.plus_player_reputation_value(GlobalTempData.mult_battle_victory_reputation_value)





    var _duel_result_msg: String = DialogueCustomUtils.duel_host_consume_result_message()
    if _duel_result_msg != "":
        GlobalMessageInterface.show_center_message(_duel_result_msg, 4.5)


    if CommonUtils.get_value(_battle_data, "event_end", false):
        GlobalEventData.remove_active_event(_battle_data.event_code)


    if _battle_data.has("battle_win_dialogue"):
        var _gd_node: BaseDialogue = CommonUtils.load_gd(_battle_data.battle_win_dialogue)
        var dialogue_template: Dictionary = _gd_node.get_current_dialogue_template()
        dialogue_interface_node.cshow()

        _mod_dialogue_active = true
        _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0

        var _win_b_info: Dictionary = DialogueUtils.get_dialogue_info(_gd_node.get_hero_uid())
        GlobalTempData.update_dialogue_info(player_team_node.get_dialogue_info(), _win_b_info)
        dialogue_interface_node.init(dialogue_template, player_team_node.get_dialogue_info(), _win_b_info)


    if GlobalTempData.mw_team_node_to_thank != null:
        dialogue_interface_node.cshow()

        _mod_dialogue_active = true
        _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0

        var _thank_a_info: Dictionary = player_team_node.get_dialogue_info()
        var _thank_b_info: Dictionary = GlobalTempData.mw_team_node_to_thank.get_dialogue_info()
        GlobalTempData.update_dialogue_info(_thank_a_info, _thank_b_info)
        dialogue_interface_node.init(
            GlobalTempData.mw_team_node_to_thank.get_after_battle_thank_dialogue_template(
                GlobalTempData.ally_relation_gain_after_battle_factor
            ),
            _thank_a_info,
            _thank_b_info
        )

        GlobalTempData.mw_team_node_to_thank = null
        GlobalTempData.ally_relation_gain_after_battle_factor = 0.0


    GlobalTempData.reset_mult_battle_data()

func get_is_show_mode():
    return view_func_root_node.show_mode

func get_zoom():
    return common_camera_node.zoom

func update_terrain_type_info(_terrain_type: int)-> void:
    mw_top_box_node.update_ferrain_type(_terrain_type)

func get_save_data():
    return {


        "current_weather": weather_executor_node.current_weather,
        "rain_remain_counter": weather_executor_node.rain_remain_counter,
        "wild_area_data": _get_wild_area_save_data(),
        "is_day": is_day,

        "mod_typhoon_active": _mod_typhoon_active,
        "mod_typhoon_end_day": _mod_typhoon_end_day,
        "mod_typhoon_prev_weather": _mod_typhoon_prev_weather,

        "mod_player_on_island": _mod_player_on_island,

        "mod_auction_next_start_day": _mod_auction_next_start_day,
        "mod_auction_is_active": _mod_auction_is_active,
        "mod_auction_end_day": _mod_auction_end_day,

        "mod_lumber_mill_owned": _mod_lumber_mill_owned,
        "mod_lumber_mill_rent_end_day": _mod_lumber_mill_rent_end_day,
        "mod_lumber_mill_capacity": _mod_lumber_mill_capacity,
        "mod_lumber_mill_workers": _mod_lumber_mill_workers.duplicate(true),
        "mod_lumber_mill_food": _mod_lumber_mill_food.duplicate(true),
        "mod_lumber_mill_wood": _mod_lumber_mill_wood,
        "mod_lumber_mill_food_depleted": _mod_lumber_mill_food_depleted,
        "mod_lumber_mill_prisoners_out": _mod_lumber_mill_prisoners_out,

        "mod_lumber_mill_forest_stock": _mod_lumber_mill_forest_stock,
        "mod_lumber_mill_tool_durability": _mod_lumber_mill_tool_durability,
        "mod_lumber_mill_morale": _mod_lumber_mill_morale,

        "mod_mine_owned": _mod_mine_owned,
        "mod_mine_rent_end_day": _mod_mine_rent_end_day,
        "mod_mine_capacity": _mod_mine_capacity,
        "mod_mine_workers": _mod_mine_workers.duplicate(true),
        "mod_mine_food": _mod_mine_food.duplicate(true),
        "mod_mine_food_depleted": _mod_mine_food_depleted,
        "mod_mine_prisoners_out": _mod_mine_prisoners_out,
        "mod_mine_tool_durability": _mod_mine_tool_durability,
        "mod_mine_morale": _mod_mine_morale,
        "mod_mine_ore_stock": _mod_mine_ore_stock.duplicate(true),
        "mod_mine_vein_stock": _mod_mine_vein_stock,
        "mod_mine_depth": _mod_mine_depth,
        "mod_mine_timber_support": _mod_mine_timber_support,
        "mod_mine_water_level": _mod_mine_water_level,

        "mod_mint_loc_data": _mod_mint_export_loc_data(),
    }

func update_player_path_line_points(_points: PackedVector2Array)-> void:





    player_path_line_node.cshow()
    player_path_line_node.points = _points

func is_input_active()-> bool:
    return input_area_node.is_c_active()


func generate_villain_boss_team(_npc_team_code: String)-> bool:
    var _villain_boss_config: = NpcTeamConfig.get_villain_boss_config(_npc_team_code)
    if _villain_boss_config == null or _villain_boss_config.is_empty():
        return false

    var _team_small_type: String = _villain_boss_config.team_small_type

    var _position_type: String = _team_small_type
    if _npc_team_code == NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT:
        _position_type = MWTeamConstants.TEAM_SMALL_TYPE_ENUM.DESERT_BANDITS
    var _position: Vector2 = _get_npc_team_random_position(_position_type)

    if _position == Vector2.ZERO:

        print_debug("[Boss生成] %s (类型:%s) 找不到生成位置，检查是否有对应的WildSoldierGenerateArea" % [_npc_team_code, _team_small_type])
        return false

    var _team_json: Dictionary = TeamUtils.generate_villain_boss_team_json(_npc_team_code, _position)
    create_team(_team_json)


    print_debug("[Boss生成] %s 成功生成于位置: %s" % [_npc_team_code, str(_position)])

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
        [_team_json.team_name]
    )

    return true


func generate_imperial_union_army_team(_npc_team_code: String)-> bool:
    var _position: Vector2 = _get_imperial_union_army_position()
    if _position == Vector2.ZERO:
        return false

    var _team_json: Dictionary = TeamUtils.generate_villain_boss_team_json(_npc_team_code, _position)
    create_team(_team_json)

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
        [_team_json.team_name]
    )

    return true


func _get_imperial_union_army_position()-> Vector2:
    var _player_position: Vector2 = WSData.get_player_team_node().global_position
    var _random_angle: float = deg_to_rad(CommonUtils.random_num2(0, 360))
    var _random_distance: float = CommonUtils.random_num2(300, 600)
    var _result_position: Vector2 = _player_position + Vector2.RIGHT.rotated(_random_angle) * _random_distance


    _result_position.x = clampf(_result_position.x, 50, map_size.x - 50)
    _result_position.y = clampf(_result_position.y, 50, map_size.y - 50)

    return _result_position



func is_npc_team_alive(_npc_team_code: String)-> bool:
    if not is_instance_valid(team_root_node):
        return true
    for _child in team_root_node.get_children():
        if _child is MWTeam and is_instance_valid(_child) \
        and _child.get_npc_team_code() == _npc_team_code:
            return true
    return false


func generate_neutral_nun_team()-> bool:
    var _npc_team_code: String = NpcTeamConstants.NPC_TEAM_CODE.NEUTRAL_NUN
    var _villain_boss_config: = NpcTeamConfig.get_villain_boss_config(_npc_team_code)
    if _villain_boss_config == null or _villain_boss_config.is_empty():
        return false


    var _player_origin: Vector2 = Vector2(1000, 800)
    var _random_angle: float = deg_to_rad(CommonUtils.random_num2(0, 360))
    var _random_distance: float = CommonUtils.random_num2(10, 50)
    var _position: Vector2 = _player_origin + Vector2.RIGHT.rotated(_random_angle) * _random_distance

    _position.x = clampf(_position.x, 50, map_size.x - 50)
    _position.y = clampf(_position.y, 50, map_size.y - 50)

    var _team_json: Dictionary = TeamUtils.generate_villain_boss_team_json(_npc_team_code, _position)


    _team_json.origin_location_code = "MWCity0001"
    _team_json.target_location_code = "MWCity0003"
    if not _team_json.has("behavior_data"):
        _team_json.behavior_data = {}
    _team_json.behavior_data["nun_current_target"] = "MWCity0003"

    create_team(_team_json)

    return true

func create_lord_team(_team_json: Dictionary)-> void:
    create_team(_team_json)
    WSData.save_lord_data(_team_json.leader_uid, _team_json.uid)

func get_day_light_color()-> Color:
    return mw_clock_and_day_light_controller_node.get_day_light_color()

func hide_player_path_line()-> void:



    player_path_line_node.chide()

func tip_cshow_camping()-> void:
    tip_node.cshow(TIP_ENUM.CAMPING)


func _init_new_lord()-> void:
    for _lord_hero_uid: String in LordConfig.LORD_CONFIG.keys():
        var _lord_config: Dictionary = LordConfig.LORD_CONFIG.get(_lord_hero_uid)
        if not _lord_config.active:
            continue

        if WSData.lord_data.has(_lord_hero_uid):
            continue

        _init_new_lord_by_hero_uid(_lord_hero_uid)

func _init_new_lord_by_hero_uid(_hero_uid: String)-> void:

    SoldierUtils.repair_lord_json(_hero_uid)

    var _team_json: Dictionary = TeamUtils.generate_lord_team_json(_hero_uid)

    create_lord_team(_team_json)


func _forbid_operation()-> void:
    common_camera_node.func_close()
    input_area_node.stop()

func _get_npc_team_random_position(_team_small_type: String)-> Vector2:
    var _alternative_area_node_list: = []
    var _result_position: = Vector2.ZERO

    for _node: WildSoldierGenerateArea in wild_soldier_generate_area_root_node.get_children():
        if _node.wild_team_type == _team_small_type:
            _alternative_area_node_list.append(_node)


    if _alternative_area_node_list.is_empty():
        return Vector2.ZERO

    for _index in range(10):
        _result_position = _alternative_area_node_list.pick_random().get_random_point()
        if CommonUtils.get_distance_square2(_result_position, WSData.get_player_team_node().global_position) < 200 * 200:

            continue

        return _result_position

    return Vector2.ZERO

func _refresh_player_team_info()-> void:
    player_team_node.refresh_team_info(false)
    m_world_left_info_area_node.refresh()


func _get_wild_area_save_data()-> Dictionary:
    var _save_data: = {}
    for _node: WildSoldierGenerateArea in wild_soldier_generate_area_root_node.get_children():
        _save_data[_node.name] = _node.get_save_data()

    return _save_data

func _load_wild_area_save_data(_save_data: Dictionary)-> void:
    for _node: WildSoldierGenerateArea in wild_soldier_generate_area_root_node.get_children():
        if _save_data.has(_node.name):
            _node.load_save_data(_save_data.get(_node.name))

func _reload_world_data(_world_data: Dictionary)-> void:






    var _day_ratio: float = WSData.system_counter - int(WSData.system_counter)

    mw_clock_and_day_light_controller_node.update_init_seek(_day_ratio)

    if _world_data.has("wild_area_data"):
        _load_wild_area_save_data(_world_data.wild_area_data)

    if _world_data.has("is_day"):
        is_day = _world_data.is_day

func _view_mode_unchoose():
    if view_choose_team_node != null:
        view_choose_team_node.view_mode_unchoose()
    if view_choose_location_node != null:
        view_choose_location_node.view_mode_unchoose()

    view_choose_team_node = null
    view_choose_location_node = null


func _register_wild_generate_area():
    WSData.register_wild_generate_area(wild_soldier_generate_area_root_node.get_children())

func _camera_to_player():
    common_camera_node.move_immediately(player_team_node.global_position)


func _handle_player_battle_end()-> Dictionary:
    var _battle_uid = GlobalTempData.current_battle_uid
    player_team_node.clear_battle_data()



    GlobalTempData.current_battle_uid = ""

    if StringUtils.is_empty(_battle_uid):
        return {}



    var _battle_data: Dictionary = {}
    if WSData.has_battle_id(_battle_uid):
        _battle_data = WSData.get_battle_data(_battle_uid)

    var _load_by_team_node: bool = CommonUtils.get_value(_battle_data, "load_by_team_node", true)
    if not _load_by_team_node:
        WSData.delete_battle_data(_battle_uid)
        return _battle_data


    var _battle_node_dic = WSData.get_battle_team_type_info(
        _battle_uid, WSData.get_player_team_node().get_uid()
    )

    WSData.delete_battle_data(_battle_uid)


    if GlobalTempData.player_battle_result == BattleConstants.BATTLE_RESULT_ENUM.VICTORY:
        BattleUtils.handle_battle_end(
            _battle_node_dic.enemy,
            BattleConstants.BATTLE_RESULT_ENUM.DEFEAT
        )


        var _ally_relation_gain_after_battle_factor: float = CommonUtils.get_value(_battle_data, "ally_relation_gain_after_battle_factor", 0.0)
        BattleUtils.handle_battle_end(
            _battle_node_dic.ally,
            BattleConstants.BATTLE_RESULT_ENUM.VICTORY,
            _ally_relation_gain_after_battle_factor
        )



        var _dialogue_team_node: MWTeam = null
        for _mw_team_node: MWTeam in _battle_node_dic.ally:
            if _mw_team_node.get_active_nop() > 0:
                _dialogue_team_node = _mw_team_node
                break

        GlobalTempData.mw_team_node_to_thank = _dialogue_team_node
        GlobalTempData.ally_relation_gain_after_battle_factor = _ally_relation_gain_after_battle_factor
    else:

        BattleUtils.handle_battle_end(
            _battle_node_dic.ally,
            BattleConstants.BATTLE_RESULT_ENUM.DEFEAT
        )

    return _battle_data

func _init_all_location():
    for _child in village_root_node.get_children():
        _init_location(_child)

    for _child in castle_root_node.get_children():
        _init_location(_child)

    for _child in city_root_node.get_children():
        _init_location(_child)

    for _child in special_location_root_node.get_children():
        _init_location(_child)


    if not is_day:
        _location_light()

func _init_location(_location_node):
    _location_node.init(WSLocationData.city_data.get(_location_node.name))
    _location_node.connect("choose", _choose_location)
    self.connect("location_light", _location_node.light)
    self.connect("location_turn_off_light", _location_node.turn_off_light)
    _location_node.connect("mobile_drag_sign", common_camera_node.mobile_drag_event)
    _location_node.connect("update_camera_zoom_sign", common_camera_node.update_zoom)


func _connect_player_node_sign(_player_node: MWTeam):
    _player_node.connect("player_meet_sign", _player_meet)
    _player_node.connect("reach_point_sign", _player_reach_point)
    _player_node.connect("enter_location_sign", _player_enter_location)
    _player_node.connect("in_location_sign", _player_in_location)
    _player_node.connect("exit_location_begin_sign", _player_exit_location_begin)
    _player_node.connect("exit_location_end_sign", _player_exit_location_end)
    _player_node.connect("path_points_update_sign", update_player_path_line_points)

func _player_reach_point()-> void:
    m_world_left_info_area_node.stop_button()
    _check_port_teleport()

func _player_enter_location(_location_code: String)-> void:

    _forbid_operation()
    _hide_button_module_root()
    player_path_line_node.chide()

    var _location_data: Dictionary = WSLocationData.get_location_data(_location_code)

    var _content = ""
    var _need_show_center_message: = true
    match _location_data.type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            _content = CommonConstants.MESSAGE_ENUM.ENTER_CITY

            AchievementMetaDataUtils.add_visited_city(_location_code)
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            _content = CommonConstants.MESSAGE_ENUM.ENTER_VILLAGE
            _need_show_center_message = false
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            _content = CommonConstants.MESSAGE_ENUM.ENTER_CASTLE
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:
            _content = "正在进入" + _location_data.name + "..."
            _need_show_center_message = false

    if _need_show_center_message:
        GlobalMessageInterface.show_center_message(_content, 0);


    m_world_left_info_area_node.hide_train_and_camping_button()

func _player_in_location()-> void:
    GlobalMessageInterface.hide_center_message()

    if module_root_node.visible:
        _hide_button_module_root()


    _show_enter_location_interface()
    GlobalTempData.set_current_location_code(choose_location_node.get_location_code())

    choose_location_node.refresh_goods_and_money_and_recruit()

    choose_location_node.refresh_npc_info()

func _player_exit_location_begin(_location_code: String)-> void:





    var _location_data: Dictionary = WSLocationData.get_location_data(_location_code)

    var _content = ""
    var _need_show_center_message: = true
    match _location_data.type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            _content = CommonConstants.MESSAGE_ENUM.EXIT_CITY
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            _content = CommonConstants.MESSAGE_ENUM.EXIT_VILLAGE
            _need_show_center_message = false
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            _content = CommonConstants.MESSAGE_ENUM.EXIT_CASTLE
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:
            _content = "正在离开" + _location_data.name + "..."
            _need_show_center_message = false

    if _need_show_center_message:
        _forbid_operation()
        _hide_button_module_root()
        GlobalMessageInterface.show_center_message(_content, 0)

func _player_exit_location_end(_location_code: String)-> void:
    player_path_line_node.cshow()

    var _location_type: = LocationUtils.get_location_type(_location_code)

    if not[
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION
    ].has(_location_type):
        _show_module()
        GlobalMessageInterface.hide_center_message()


    if _location_code == ISLAND_CITY_CODE:
        _mod_auction_reset_tickets()
        print("[MapMod] 已离开斯卡城, 拍卖行入场券已重置")

    if GlobalPlayerConfig.is_auto_save:
        GlobalSave.save(true, true)

var temp_join_battle_team_info: Dictionary = {}


func _player_meet(_meet_node: MWTeam):

    if _mod_dialogue_active:
        return
    if not is_instance_valid(_meet_node):
        return
    _mod_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0

    player_team_node.change_status_to_idle()
    player_meet_node = _meet_node


    if player_meet_node.get_leader_uid() == "mod_boss_conquest_knight":
        dialogue_interface_node.cshow()
        m_world_left_info_area_node.disable_button(true)
        stop_include_camera()
        _hide_button_module_root()

        var _a_info: Dictionary = player_team_node.get_dialogue_info()
        var _b_info: Dictionary = _meet_node.get_dialogue_info()
        GlobalTempData.update_dialogue_info(_a_info, _b_info)



        var _trade_options: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
            "option_content": "(选择你想要的装备, 以沙漠红宝石支付)",
            "option_list": [
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "180红宝石 → 征伐护靴",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "exchange_ruby_for_conquest_equipment", "params": ["shoe_0084", 180]},
                    "content": [{"clist": ["#{0}"], "str_from_func": [{"func_name": "get_conquest_exchange_result"}]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "210红宝石 → 征伐肩甲",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "exchange_ruby_for_conquest_equipment", "params": ["shoulder_0072", 210]},
                    "content": [{"clist": ["#{0}"], "str_from_func": [{"func_name": "get_conquest_exchange_result"}]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "260红宝石 → 惊悚头盔",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "exchange_ruby_for_conquest_equipment", "params": ["helmet_0132", 260]},
                    "content": [{"clist": ["#{0}"], "str_from_func": [{"func_name": "get_conquest_exchange_result"}]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "290红宝石 → 征伐护甲",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "exchange_ruby_for_conquest_equipment", "params": ["armour_0105", 290]},
                    "content": [{"clist": ["#{0}"], "str_from_func": [{"func_name": "get_conquest_exchange_result"}]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "330红宝石 → 烙印(双手锤)",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "exchange_ruby_for_conquest_equipment", "params": ["th_blunt_0006", 330]},
                    "content": [{"clist": ["#{0}"], "str_from_func": [{"func_name": "get_conquest_exchange_result"}]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "返回",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["还是算了."]}],
                },
            ]
        }

        var _boss_dialogue: Dictionary = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_boss_conquest_knight",
            "content": [{"clist": [
                "黑月之子教廷的征伐骑士注视着你, 铠甲上的肋骨花纹在阴影中若隐若现.",
                "你感受到了一股令人窒息的恐惧气息, 那把沉重的战锤似乎在渴求着什么.",
            ]}],
            "next": {
                "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                "option_list": [
                    {
                        "otype": DialogueConstants.OPTION_TYPE_ENUM.BATTLE,
                        "oname": "应战",
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [{"clist": ["来吧, 我不会退缩!"]}],
                    },
                    {
                        "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                        "oname": "交易",
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [{"clist": ["我希望能与你交易些装备."]}],
                        "next": _trade_options,
                    },
                    {
                        "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                        "oname": "撤退",
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [{"clist": ["这家伙太强了, 先撤退再说."]}],
                    },
                ]
            }
        }


        for _i in range(5):
            _trade_options.option_list[_i].next = _trade_options
        _trade_options.option_list[5].next = _boss_dialogue.next

        var _buxiao_entry: Dictionary = CommonUtils.load_gd(
            DialogueUtils.get_dialogue_path("ModHero0003Dialogue")
        ).get_entry_option()
        if not _buxiao_entry.is_empty():
            _boss_dialogue.next.option_list.insert(2, _buxiao_entry)

        dialogue_interface_node.init(_boss_dialogue, _a_info, _b_info)

        var _join_battle_team_info: Dictionary = player_team_node.get_join_battle_team_info(_meet_node)
        temp_join_battle_team_info = _join_battle_team_info
        dialogue_interface_node.update_join_battle_team(
            _join_battle_team_info.left_team_node_list,
            _join_battle_team_info.right_team_node_list,
        )
        stop()
        return




    dialogue_interface_node.cshow()
    m_world_left_info_area_node.disable_button(true)

    stop_include_camera()
    _hide_button_module_root()









    var _a_info: Dictionary = player_team_node.get_dialogue_info()
    var _b_info: Dictionary = _meet_node.get_dialogue_info()

    GlobalTempData.update_dialogue_info(_a_info, _b_info)

    var _dialogue_template = _meet_node.get_dialogue_template(
        _a_info,
        _b_info
    )


    dialogue_interface_node.init(_dialogue_template, _a_info, _b_info)


    var _join_battle_team_info: Dictionary = player_team_node.get_join_battle_team_info(_meet_node)
    temp_join_battle_team_info = _join_battle_team_info

    dialogue_interface_node.update_join_battle_team(
        _join_battle_team_info.left_team_node_list,
        _join_battle_team_info.right_team_node_list,
    )

    stop()









func _change_to_battle_scene_ani(_battle_id: String)-> void:
    GlobalNode.game_root.change_to_battle_scene_ani(_battle_id)

func _player_move_land(_target_position):
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)

    m_world_left_info_area_node.run_button()
    _cancel_choose_location()
    _cancel_choose_team()
    _player_move(_target_position)
    _click_effect(_target_position)

func _click_effect(_target_position):
    var click_effect_instance = click_effect_node.instantiate() as ClickEffect
    click_effect_root_node.add_child(click_effect_instance)
    click_effect_instance.global_position = _target_position
    click_effect_instance.play_left_click03()

func _location_light():
    emit_signal("location_light")

func _location_turn_off_light():
    emit_signal("location_turn_off_light")


func _choose_location(_location_node: MWLocationBase):



    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)

    if view_func_root_node.show_mode:

        _view_mode_unchoose()


        view_func_root_node.init_location_info(_location_node.city_data)
        view_choose_location_node = _location_node
        return

    m_world_left_info_area_node.run_button()

    _cancel_choose_team()
    if _location_node != choose_location_node:
        _cancel_choose_location()


    var _loc_on_island = _location_node.global_position.y > 4000.0
    if _mod_player_on_island != _loc_on_island:
        _mod_msg("无法直接前往该地点，请通过港口乘船前往", 3.0, false)
        m_world_left_info_area_node.stop_button()
        return

    choose_location_node = _location_node


    _player_move_to_location(_location_node.get_location_code())

    _click_effect(_location_node.get_near_entrance_position(player_team_node.global_position))

func _choose_team(_team_node: MWTeam, _is_left_click: bool = true):



    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)

    if view_func_root_node.show_mode:
        _view_mode_unchoose()

        view_choose_team_node = _team_node
        var _view_level = SkillUtils.get_view_level(_team_node.global_position)
        view_func_root_node.init_team_info(_team_node.team_info, null, _team_node.is_player, _view_level)
        return

    if _is_left_click:
        m_world_left_info_area_node.run_button()

        _cancel_choose_location()
        if choose_team_node != _team_node:
            _cancel_choose_team()


        choose_team_node = _team_node


        var _team_on_island = _team_node.global_position.y > 4000.0
        if _mod_player_on_island != _team_on_island:
            _mod_msg("无法直接前往该地点，请通过港口乘船前往", 3.0, false)
            _cancel_choose_team()
            m_world_left_info_area_node.stop_button()
            return

        player_team_node.move_to_team(_team_node)
        _team_node.target_effect()
        tip_node.chide()
    else:

        common_camera_node.trace(_team_node)

func _cancel_choose_location():
    _hide_port_select()
    _hide_lumber_mill_select()
    _lumber_mill_pending = false
    _hide_mine_select()
    _mine_pending = false

    _port_teleport_pending = false
    _island_port_teleport_pending = false
    if choose_location_node != null:
        choose_location_node.cancel_click()
        choose_location_node = null

func _cancel_choose_team():
    if is_instance_valid(choose_team_node):

        choose_team_node.unchoose()
        choose_team_node = null

func _player_move_to_location(_location_code: String)-> void:

    var _target_pos = GlobalLocationData.get_location_point(_location_code)
    if _target_pos is Vector2 and _target_pos != Vector2.ZERO:
        var _target_on_island = _target_pos.y > 4000.0
        if _mod_player_on_island != _target_on_island:
            _mod_msg("无法直接前往该地点，请通过港口乘船前往", 3.0, false)
            return
    player_team_node.move_to_location(_location_code)
    tip_node.chide()

func _player_move(_target_position):
    if _target_position != PORT_POS:
        if _port_select_effect and is_instance_valid(_port_select_effect):
            _port_select_effect.visible = false
        _port_teleport_pending = false
    if _target_position != ISLAND_PORT_POS:
        if _island_port_select_effect and is_instance_valid(_island_port_select_effect):
            _island_port_select_effect.visible = false
        _island_port_teleport_pending = false
    if _target_position != LUMBER_MILL_POS:
        if _lumber_mill_select_effect and is_instance_valid(_lumber_mill_select_effect):
            _lumber_mill_select_effect.visible = false
        _lumber_mill_pending = false
    if _target_position != MINE_POS:
        if _mine_select_effect and is_instance_valid(_mine_select_effect):
            _mine_select_effect.visible = false
        _mine_pending = false
    player_team_node.move_to_target(_target_position)
    tip_node.chide()

func _init_mw_team(_json: Dictionary)-> MWTeam:

    TeamUtils.repair_mw_team_json(_json)



    var _mw_team_node = TeamUtils.get_mw_team_node(_json)
    var mw_team_instance = _mw_team_node.instantiate()
    team_root_node.add_child(mw_team_instance)
    mw_team_instance.init(_json)

    mw_team_instance.connect("choose_team_sign", _choose_team)

    mw_clock_and_day_light_controller_node.connect("to_day_sign", mw_team_instance.to_day)
    mw_clock_and_day_light_controller_node.connect("to_night_sign", mw_team_instance.to_night)

    return mw_team_instance

func _hide_button_module_root():
    _button_disable(true)
    animation_player_node.play("button_module_disappear")

func _show_button_module_root():


    _button_disable(false)

    animation_player_node.play("button_module_show")

func _button_disable(_disable: bool)-> void:
    if _disable:
        game_info_button_node.disable()
        team_info_button_node.disable()
        team_menu_button_node.disable()
        items_button_node.disable()
        main_menu_button_node.disable()
        m_world_left_info_area_node.disable_button(true)
    else:
        game_info_button_node.cancel_disable()
        team_info_button_node.cancel_disable()
        team_menu_button_node.cancel_disable()
        items_button_node.cancel_disable()
        main_menu_button_node.cancel_disable()
        m_world_left_info_area_node.disable_button(false)

func _follow_up_close_menu():

    stop_and_show_module()
    _refresh_player_team_info()


func _show_enter_location_interface():

    stop_include_camera()


    var _event_data: Dictionary = EventUtils.get_enter_location_event_detail(choose_location_node.get_location_code())
    if not _event_data.is_empty():

        match _event_data.event_type:



            EventBase.TYPE_ENUM.DIALOG:

                _mod_dialogue_active = true
                _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
                dialogue_interface_node.cshow()
                dialogue_interface_node.update_event_code(_event_data.event_code)
                dialogue_interface_node.init(_event_data.dialogue, player_team_node.get_dialogue_info(),{})

        return


    location_enter_interface_node.init(choose_location_node)
    location_enter_interface_node.show()


    _mod_customize_auction_button.call_deferred()


func _refresh_upgrade_soldier_icon():
    var _has_upgrade_soldier = SoldierUtils.check_has_upgradable_soldier(WSData.get_player_team_simple_json_list())
    if _has_upgrade_soldier:
        upgrade_icon_node.show_effect()
    else:
        upgrade_icon_node.chide()


func _maybe_generate_wild():
    for _wild_generate_node: WildSoldierGenerateArea in wild_soldier_generate_area_root_node.get_children():
        _wild_generate_node.maybe_generate_wild()

func change_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM):

    var _apparent_weather: = _weather
    if _apparent_weather != MWorldConstants.WEATHER_TYPE_ENUM.CLEAR \
    and WSData.get_player_terrain_type() == MWorldConstants.TERRAIN_TYPE_ENUM.DESERT:
            _apparent_weather = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR




    mw_top_box_node.update_weather(_apparent_weather)
    mwb_rain_root_node.update_weather(_apparent_weather)

    WSData.save_player_weather(_weather)

    if _weather != MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
        player_team_node.open_weather_light2d()
    else:
        player_team_node.close_weather_light2d()

    GlobalSoundManager.handle_weather_sfx(_weather)


func _view_soldier_info(_soldier_prop: BSSoldierProp)-> void:
    soldier_info_interface_node.init_by_soldier_prop(_soldier_prop)
    soldier_info_interface_node.cshow()


func _player_location_rest():
    location_enter_interface_node.chide()


    m_world_left_info_area_node.disable_button(false)
    m_world_left_info_area_node.run_button()
    _show_button_module_root()
    player_path_line_node.chide()
    tip_node.cshow(TIP_ENUM.LOCATION_REST)


func _on_team_menu_button_pressed():
    stop_include_camera()
    _hide_button_module_root()
    team_manage_interface_node.show()

    team_manage_interface_node.init(
        WSData.player_data.team,
        WSData.get_player_team_info().nop_limit
    )

func _on_team_manage_interface_close():
    _follow_up_close_menu()
    _refresh_upgrade_soldier_icon()
    WSData.refresh_field_wages()

func _on_location_enter_interface_close():
    _follow_up_close_menu()

    var _location_code: = player_team_node.in_location_code
    if[
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE,
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION
    ].has(WSLocationData.get_location_type(_location_code)):
        player_team_node.move_to_target(
            GlobalLocationData.get_random_entrance_position(_location_code)
        )






func _on_location_enter_interface_enter_city_location(_node: LocationCard):
    var _location_type_enum = _node.get_type()


    match _location_type_enum:
        LocationConstants.CITY_LOCATION_TYPE_ENUM.SMITHY, \
        LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY, \
        LocationConstants.CITY_LOCATION_TYPE_ENUM.ARMOUR, \
        LocationConstants.CITY_LOCATION_TYPE_ENUM.HORSE:

            goods_exchange_interface_node.init_location_shop(GlobalTempData.current_location_code, _location_type_enum)
            goods_exchange_interface_node.cshow()

        LocationConstants.CITY_LOCATION_TYPE_ENUM.PIAZZA:

            _mod_ensure_city_recruit_not_empty()
            recruit_interface_node.init()
            recruit_interface_node.show()
        LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL:
            _player_location_rest()
        LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN:

            if GlobalTempData.current_location_code == ISLAND_CITY_CODE:
                _mod_refresh_auction_if_needed()
                _mod_open_auction()
            else:
                special_build_interface_node.init(
                    GlobalTempData.current_location_code,
                    _location_type_enum,
                    WSLocationData.get_enter_build_name(GlobalTempData.current_location_code, _location_type_enum)
                )
                special_build_interface_node.show()
        LocationConstants.CITY_LOCATION_TYPE_ENUM.BARRACKS:

            team_exchange_interface_node.cshow()

            team_exchange_interface_node.init_by_location_code(GlobalTempData.get_current_location_code())
        LocationConstants.CITY_LOCATION_TYPE_ENUM.WAREHOUSE:
            warehouse_interface_node.cshow()
            warehouse_interface_node.init_warehouse(GlobalTempData.get_current_location_code())

        LocationConstants.CITY_LOCATION_TYPE_ENUM.MOD_VILLAGE_HALL:
            special_build_interface_node.init(
                GlobalTempData.current_location_code,
                _location_type_enum,
                ""
            )
            special_build_interface_node.show()

        LocationConstants.CITY_LOCATION_TYPE_ENUM.MOD_ARMORY:

            GlobalTempData.mod_is_armory_recruit = true
            _mod_add_player_guard_to_recruit()
            recruit_interface_node.init()
            recruit_interface_node.show()

        LocationConstants.CITY_LOCATION_TYPE_ENUM.PRISON:


            if mod_prison_interface_node == null:
                var _prison_script = load("res://gd/game/mwBuild/specialBuild/ModPrisonExchangeInterface.gd")
                if _prison_script == null:
                    _mod_msg("俘虏交换界面加载失败(MOD文件缺失)", 3.0, false)
                    print("[MapMod] WARNING: ModPrisonExchangeInterface.gd 加载失败")
                    return
                var _prison_scene = load("res://tscn/game/interface/soldier/TeamExchangeInterface.tscn")
                mod_prison_interface_node = _prison_scene.instantiate()
                mod_prison_interface_node.set_script(_prison_script)
                mod_prison_interface_node.connect("close_page_sign", _on_mod_prison_close_page_sign)

                team_exchange_interface_node.get_parent().add_child(mod_prison_interface_node)
            mod_prison_interface_node.init_by_location_code(GlobalTempData.get_current_location_code())
            mod_prison_interface_node.cshow()

        LocationConstants.CITY_LOCATION_TYPE_ENUM.MINT:

            _mod_open_mint_interface()


func _mod_open_mint_interface()-> void:


    _mod_mint_bind_loc(GlobalTempData.get_current_location_code())
    if mod_mint_interface_node == null:
        var _mint_script = load("res://gd/game/mwBuild/specialBuild/ModMintInterface.gd")
        if _mint_script == null:
            _mod_msg("铸钱厂面板加载失败(MOD文件缺失)", 3.0, false)
            print("[MapMod] WARNING: ModMintInterface.gd 加载失败")
            return
        mod_mint_interface_node = Control.new()
        mod_mint_interface_node.set_script(_mint_script)
        mod_mint_interface_node.connect("close_page_sign", _on_mod_mint_panel_close)
        mod_mint_interface_node.connect("slot_add_ore_sign", _on_mod_mint_slot_add_ore)
        mod_mint_interface_node.connect("slot_add_ingot_sign", _on_mod_mint_slot_add_ingot)
        mod_mint_interface_node.connect("slot_add_wood_sign", _on_mod_mint_slot_add_wood)
        mod_mint_interface_node.connect("slot_take_ore_sign", _on_mod_mint_slot_take_ore)
        mod_mint_interface_node.connect("slot_take_ingot_sign", _on_mod_mint_slot_take_ingot)
        mod_mint_interface_node.connect("slot_take_wood_sign", _on_mod_mint_slot_take_wood)
        mod_mint_interface_node.connect("slot_take_product_ingot_sign", _on_mod_mint_slot_take_product_ingot)
        mod_mint_interface_node.connect("slot_take_money_sign", _on_mod_mint_slot_take_money)
        canvas_layer_node.add_child(mod_mint_interface_node)
    mod_mint_interface_node.show_interface()

    if _mod_mint_legacy_ore > 0 or _mod_mint_legacy_wood > 0:
        if _mod_mint_legacy_ore > 0:
            _mod_mint_add_to_bag(MOD_MINT_COPPER_UID, _mod_mint_legacy_ore)
        if _mod_mint_legacy_wood > 0:
            _mod_mint_add_to_bag(MOD_MINT_WOOD_UID, _mod_mint_legacy_wood)
        _mod_mint_feedback("旧版厂仓剩余原料已退回背包(铜矿 " + str(_mod_mint_legacy_ore) + " · 木材 " + str(_mod_mint_legacy_wood) + ")", "info", 5.0)
        _mod_mint_legacy_ore = 0
        _mod_mint_legacy_wood = 0
    _mod_mint_refresh_panel()
    print("[MapMod] 铸钱厂界面已打开")


func _on_mod_mint_panel_close()-> void:


    location_enter_interface_node.show_button()

    _mod_mint_flush()
    if mod_mint_interface_node:
        mod_mint_interface_node.hide_interface()





func _mod_mint_get_level_for_loc(_loc_code: String)-> String:
    if _loc_code == "":
        return ""
    var _best: String = ""
    for _build_info: Dictionary in WSLocationData.get_finish_build_info_list(_loc_code):
        if _build_info.build_code == LocationBuildConstants.BUILD_CODE_ENUM.MINT:
            return "big"
        elif _build_info.build_code == LocationBuildConstants.BUILD_CODE_ENUM.MINT_SMALL:
            _best = "small"
    return _best



func _mod_mint_get_level()-> String:
    return _mod_mint_get_level_for_loc(_mod_mint_current_loc)



func _mod_mint_is_available()-> bool:
    return _mod_mint_get_level() != ""



func _mod_mint_get_slot_count()-> int:
    return MOD_MINT_SLOT_COUNT



func _mod_mint_input_cap_for_loc(_loc_code: String)-> int:
    if _loc_code == "":
        return MOD_MINT_INPUT_CAP_BASE
    var _best: int = 0
    for _build_info: Dictionary in WSLocationData.get_finish_build_info_list(_loc_code):
        var _code: String = _build_info.build_code
        if _code == LocationBuildConstants.BUILD_CODE_ENUM.MINT \
        or _code == LocationBuildConstants.BUILD_CODE_ENUM.MINT_SMALL:
            _best = maxi(_best, LocationBuildUtils.get_build_config_value(_code, int(_build_info.get("build_level", 0))))
    return _best if _best > 0 else MOD_MINT_INPUT_CAP_BASE



func _mod_mint_input_cap()-> int:
    return _mod_mint_input_cap_for_loc(_mod_mint_current_loc)





func _mod_mint_loc_entry(_loc_code: String)-> Dictionary:
    if not _mod_mint_loc_data.has(_loc_code):
        _mod_mint_loc_data[_loc_code] = {
            "slots": [],
            "today_income": 0,
            "total_income": 0,
            "last_day": -1,
            "legacy_ore": 0,
            "legacy_wood": 0,
        }
    return _mod_mint_loc_data[_loc_code]



func _mod_mint_flush()-> void:
    if _mod_mint_current_loc == "":
        return
    var _d: Dictionary = _mod_mint_loc_entry(_mod_mint_current_loc)
    _d["slots"] = _mod_mint_slots
    _d["today_income"] = _mod_mint_today_income
    _d["total_income"] = _mod_mint_total_income
    _d["last_day"] = _mod_last_mint_settlement_day
    _d["legacy_ore"] = _mod_mint_legacy_ore
    _d["legacy_wood"] = _mod_mint_legacy_wood



func _mod_mint_export_loc_data()-> Dictionary:
    _mod_mint_flush()
    return _mod_mint_loc_data.duplicate(true)




func _mod_mint_bind_loc(_loc_code: String)-> void:
    if _loc_code == _mod_mint_current_loc:
        return
    _mod_mint_flush()
    _mod_mint_current_loc = _loc_code
    var _d: Dictionary = _mod_mint_loc_entry(_loc_code)
    _mod_mint_slots = _d.get("slots",[])
    _mod_mint_today_income = int(_d.get("today_income", 0))
    _mod_mint_total_income = int(_d.get("total_income", 0))
    _mod_last_mint_settlement_day = int(_d.get("last_day", -1))
    _mod_mint_legacy_ore = int(_d.get("legacy_ore", 0))
    _mod_mint_legacy_wood = int(_d.get("legacy_wood", 0))



func _mod_mint_first_mint_loc()-> String:
    for _loc_code in SoldierUtils.get_player_fief_code_list():
        if _mod_mint_get_level_for_loc(str(_loc_code)) != "":
            return str(_loc_code)
    return ""



func _mod_mint_migrate_slots(_raw)-> Array:
    var _out: Array = []
    if not(_raw is Array):
        return _out
    for _slot in _raw:
        if not(_slot is Dictionary):
            continue
        if _slot.has("elapsed"):

            _out.append({"ore": int(_slot.get("ore", 0)), "ingot": 0, "wood": 2, "out_ingot": 0, "money": 0})
        else:

            _out.append({
                "ore": int(_slot.get("ore", 0)),
                "ingot": int(_slot.get("ingot", 0)),
                "wood": int(_slot.get("wood", 0)),
                "out_ingot": int(_slot.get("out_ingot", 0)),
                "money": int(_slot.get("money", int(_slot.get("coins", 0)))),
            })
    return _out



func _mod_mint_wood_cap()-> int:
    return maxi(int(float(_mod_mint_input_cap()) * 2.0 / 3.0), 10)



func _mod_mint_active_count()-> int:
    var _n: int = 0
    for _slot in _mod_mint_slots:
        if int(_slot.get("wood", 0)) > 0 \
        and(int(_slot.get("ore", 0)) > 0 or int(_slot.get("ingot", 0)) > 0):
            _n += 1
    return _n




func _mod_mint_align_slots()-> void:
    var _slot_count: int = _mod_mint_get_slot_count()
    var _cap_in: int = _mod_mint_input_cap()
    var _cap_wd: int = _mod_mint_wood_cap()
    var _returned: int = 0

    while _mod_mint_slots.size() > _slot_count:
        var _s: Dictionary = _mod_mint_slots.pop_back()
        var _r_ore: int = int(_s.get("ore", 0)) + 0
        var _r_ingot: int = int(_s.get("ingot", 0)) + int(_s.get("out_ingot", 0))
        var _r_wood: int = int(_s.get("wood", 0))
        var _r_money: int = int(_s.get("money", 0))
        if _r_ore > 0:
            _mod_mint_add_to_bag(MOD_MINT_COPPER_UID, _r_ore)
        if _r_ingot > 0:
            _mod_mint_add_to_bag(MOD_MINT_INGOT_UID, _r_ingot)
        if _r_wood > 0:
            _mod_mint_add_to_bag(MOD_MINT_WOOD_UID, _r_wood)
        if _r_money > 0:
            WSData.update_money(_r_money, false)
        _returned += _r_ore + _r_ingot + _r_wood

    while _mod_mint_slots.size() < _slot_count:
        _mod_mint_slots.append({"ore": 0, "ingot": 0, "wood": 0, "out_ingot": 0, "money": 0})

    for _slot: Dictionary in _mod_mint_slots:
        var _ore_o: int = maxi(int(_slot.get("ore", 0)) - _cap_in, 0)
        if _ore_o > 0:
            _slot["ore"] = int(_slot.get("ore", 0)) - _ore_o
            _mod_mint_add_to_bag(MOD_MINT_COPPER_UID, _ore_o)
            _returned += _ore_o
        var _ingot_o: int = maxi(int(_slot.get("ingot", 0)) - _cap_in, 0)
        if _ingot_o > 0:
            _slot["ingot"] = int(_slot.get("ingot", 0)) - _ingot_o
            _mod_mint_add_to_bag(MOD_MINT_INGOT_UID, _ingot_o)
            _returned += _ingot_o
        var _wood_o: int = maxi(int(_slot.get("wood", 0)) - _cap_wd, 0)
        if _wood_o > 0:
            _slot["wood"] = int(_slot.get("wood", 0)) - _wood_o
            _mod_mint_add_to_bag(MOD_MINT_WOOD_UID, _wood_o)
            _returned += _wood_o
    if _returned > 0:
        print("[MapMod] 铸钱厂槽位/容量对齐: 退回背包材料共 ", _returned, " 件(旧档迁移不亏玩家)")



func _mod_mint_slot_valid(_idx: int)-> bool:
    return _idx >= 0 and _idx < _mod_mint_slots.size() and _mod_mint_is_available()



func _mod_mint_get_furnace_state()-> String:
    if not _mod_mint_is_available():
        return "cold"
    var _burning: bool = false
    var _need_wood: bool = false
    for _slot in _mod_mint_slots:
        var _has_input: bool = int(_slot.get("ore", 0)) > 0 or int(_slot.get("ingot", 0)) > 0
        if _has_input:
            if int(_slot.get("wood", 0)) > 0:
                _burning = true
            else:
                _need_wood = true
    if _burning:
        return "burning"
    if _need_wood:
        return "no_wood"
    return "idle"



func _mod_mint_count_bag(_uid: String)-> int:
    var _total: int = 0
    for _entry in WSData.get_player_goods():
        if _entry.get("item",{}).get("uid", "") == _uid:
            _total += int(_entry.get("count", 0))
    return _total



func _mod_mint_remove_from_bag(_uid: String, _count: int)-> int:
    if _count <= 0:
        return 0
    var _player_goods: Array = WSData.get_player_goods()
    var _remaining: int = _count
    var _i: int = 0
    while _i < _player_goods.size() and _remaining > 0:
        var _entry = _player_goods[_i]
        if _entry.get("item",{}).get("uid", "") == _uid:
            var _have: int = int(_entry.get("count", 0))
            if _have <= _remaining:
                _remaining -= _have
                _player_goods.remove_at(_i)
                continue
            else:
                _entry["count"] = _have - _remaining
                _remaining = 0
        _i += 1
    var _actual: int = _count - _remaining
    if _actual > 0:
        GoodsUtils.organize_goods(_player_goods)
        WSData.save_my_goods(_player_goods)
    return _actual



func _mod_mint_add_to_bag(_uid: String, _count: int)-> void:
    if _count <= 0:
        return
    var _goods: Array = WSData.get_player_goods()
    var _found: bool = false
    for _entry in _goods:
        if _entry.get("item",{}).get("uid", "") == _uid:
            _entry["count"] = int(_entry.get("count", 0)) + _count
            _found = true
            break
    if not _found:
        _goods.append({"item": {"uid": _uid}, "count": _count})
    GoodsUtils.organize_goods(_goods)
    WSData.save_my_goods(_goods)











func _mod_mint_feedback(_text: String, _kind: String = "ok", _duration: float = 2.6)-> void:
    if mod_mint_interface_node != null and is_instance_valid(mod_mint_interface_node):
        mod_mint_interface_node.show_feedback(_text, _kind, _duration)



func _mod_mint_refresh_panel()-> void:
    if mod_mint_interface_node == null:
        return
    var _warnings: Array = []
    var _level: String = _mod_mint_get_level()
    var _slot_count: int = _mod_mint_get_slot_count()
    if _level == "":
        _warnings.append("未检测到已建成的铸钱厂")
    _mod_mint_align_slots()

    var _bag_copper: int = _mod_mint_count_bag(MOD_MINT_COPPER_UID)
    var _bag_ingot: int = _mod_mint_count_bag(MOD_MINT_INGOT_UID)
    var _bag_wood: int = _mod_mint_count_bag(MOD_MINT_WOOD_UID)
    var _cap_in: int = _mod_mint_input_cap()
    var _cap_wd: int = _mod_mint_wood_cap()
    var _slots_ui: Array = []
    for _slot: Dictionary in _mod_mint_slots:
        var _ore: int = int(_slot.get("ore", 0))
        var _ingot: int = int(_slot.get("ingot", 0))
        var _wood: int = int(_slot.get("wood", 0))
        var _out_ingot: int = int(_slot.get("out_ingot", 0))
        var _money: int = int(_slot.get("money", 0))
        var _state: String = "empty"
        if _ore > 0 or _ingot > 0:
            _state = "burning" if _wood > 0 else "no_wood"

        var _ore_space: int = 0 if _ingot > 0 else maxi(_cap_in - _ore, 0)
        var _ingot_space: int = 0 if _ore > 0 else maxi(_cap_in - _ingot, 0)
        var _wood_space: int = maxi(_cap_wd - _wood, 0)
        _slots_ui.append({
            "state": _state, "ore": _ore, "ingot": _ingot, "wood": _wood,
            "out_ingot": _out_ingot, "money": _money,
            "ore_max": mini(_ore_space, _bag_copper),
            "ingot_max": mini(_ingot_space, _bag_ingot),
            "wood_max": mini(_wood_space, _bag_wood),
        })
    if _furnace_state_has_no_wood() and _bag_wood > 0:
        _warnings.append("有熔炼槽缺木材 — 拖该槽的绿色滑条补充")
    var _data: Dictionary = {
        "level": _level,
        "slot_count": _slot_count,
        "slots": _slots_ui,
        "furnace_state": _mod_mint_get_furnace_state(),
        "bag_copper": _bag_copper,
        "bag_ingot": _bag_ingot,
        "bag_wood": _bag_wood,
        "input_max": _cap_in,
        "wood_max": _cap_wd,
        "coins_per_ingot": MOD_MINT_COINS_PER_INGOT,
        "today_income": _mod_mint_today_income,
        "total_income": _mod_mint_total_income,
        "warnings": _warnings,
    }
    mod_mint_interface_node.update_status(_data)

    _mod_mint_flush()



func _furnace_state_has_no_wood()-> bool:
    for _slot in _mod_mint_slots:
        if(int(_slot.get("ore", 0)) > 0 or int(_slot.get("ingot", 0)) > 0) \
        and int(_slot.get("wood", 0)) <= 0:
            return true
    return false



func _on_mod_mint_slot_add_ore(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx) or _amount <= 0:
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    if int(_slot.get("ingot", 0)) > 0:
        _mod_mint_feedback("这槽已经放了铜锭, 先取出锭才能放铜矿石", "err")
        _mod_mint_refresh_panel()
        return
    var _space: int = maxi(_mod_mint_input_cap() - int(_slot.get("ore", 0)), 0)
    var _bag: int = _mod_mint_count_bag(MOD_MINT_COPPER_UID)
    var _n: int = mini(mini(_amount, _space), _bag)
    if _n <= 0:
        _mod_mint_feedback("放不进去(已满或背包没有铜矿石)", "err")
        _mod_mint_refresh_panel()
        return
    _mod_mint_remove_from_bag(MOD_MINT_COPPER_UID, _n)
    _slot["ore"] = int(_slot.get("ore", 0)) + _n
    _mod_mint_feedback("放入 " + str(_n) + " 铜矿石", "ok")
    print("[MapMod] 铸钱厂槽", _idx, "加矿 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_add_ingot(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx) or _amount <= 0:
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    if int(_slot.get("ore", 0)) > 0:
        _mod_mint_feedback("这槽已经放了铜矿石, 先取出矿才能放铜锭", "err")
        _mod_mint_refresh_panel()
        return
    var _space: int = maxi(_mod_mint_input_cap() - int(_slot.get("ingot", 0)), 0)
    var _bag: int = _mod_mint_count_bag(MOD_MINT_INGOT_UID)
    var _n: int = mini(mini(_amount, _space), _bag)
    if _n <= 0:
        _mod_mint_feedback("放不进去(已满或背包没有铜锭)", "err")
        _mod_mint_refresh_panel()
        return
    _mod_mint_remove_from_bag(MOD_MINT_INGOT_UID, _n)
    _slot["ingot"] = int(_slot.get("ingot", 0)) + _n
    _mod_mint_feedback("放入 " + str(_n) + " 铜锭", "ok")
    print("[MapMod] 铸钱厂槽", _idx, "加锭 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_add_wood(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx) or _amount <= 0:
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    var _space: int = maxi(_mod_mint_wood_cap() - int(_slot.get("wood", 0)), 0)
    var _bag: int = _mod_mint_count_bag(MOD_MINT_WOOD_UID)
    var _n: int = mini(mini(_amount, _space), _bag)
    if _n <= 0:
        _mod_mint_feedback("放不进去(已满或背包没有木材)", "err")
        _mod_mint_refresh_panel()
        return
    _mod_mint_remove_from_bag(MOD_MINT_WOOD_UID, _n)
    _slot["wood"] = int(_slot.get("wood", 0)) + _n
    _mod_mint_feedback("放入 " + str(_n) + " 木材", "ok")
    print("[MapMod] 铸钱厂槽", _idx, "加木 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_take_ore(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx):
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    var _ore: int = int(_slot.get("ore", 0))
    if _ore <= 0:
        _mod_mint_feedback("这个白框里没有铜矿石", "err")
        _mod_mint_refresh_panel()
        return
    var _to_remove: int = _amount if _amount > 0 else _ore
    var _n: int = mini(_to_remove, _ore)
    _slot["ore"] = _ore - _n
    _mod_mint_add_to_bag(MOD_MINT_COPPER_UID, _n)
    _mod_mint_feedback("取回白框铜矿石 " + str(_n), "ok")
    print("[MapMod] 铸钱厂槽", _idx, "取出白框铜矿石 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_take_ingot(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx):
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    var _ingot: int = int(_slot.get("ingot", 0))
    if _ingot <= 0:
        _mod_mint_feedback("这个白框里没有铜锭", "err")
        _mod_mint_refresh_panel()
        return
    var _to_remove: int = _amount if _amount > 0 else _ingot
    var _n: int = mini(_to_remove, _ingot)
    _slot["ingot"] = _ingot - _n
    _mod_mint_add_to_bag(MOD_MINT_INGOT_UID, _n)
    _mod_mint_feedback("取回白框铜锭 " + str(_n), "ok")
    print("[MapMod] 铸钱厂槽", _idx, "取出白框铜锭 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_take_wood(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx):
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    var _wood: int = int(_slot.get("wood", 0))
    if _wood <= 0:
        _mod_mint_feedback("燃料框是空的", "err")
        _mod_mint_refresh_panel()
        return
    var _to_remove: int = _amount if _amount > 0 else _mod_mint_wood_cap()
    var _n: int = mini(_to_remove, _wood)
    _slot["wood"] = _wood - _n
    _mod_mint_add_to_bag(MOD_MINT_WOOD_UID, _n)
    _mod_mint_feedback("取回 " + str(_n) + " 木材", "ok")
    print("[MapMod] 铸钱厂槽", _idx, "取出木材 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_take_product_ingot(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx):
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    var _out_ingot: int = int(_slot.get("out_ingot", 0))
    if _out_ingot <= 0:
        _mod_mint_feedback("金框里没有产出铜锭", "err")
        _mod_mint_refresh_panel()
        return
    var _n: int = mini(_amount if _amount > 0 else _out_ingot, _out_ingot)
    _slot["out_ingot"] = _out_ingot - _n
    _mod_mint_add_to_bag(MOD_MINT_INGOT_UID, _n)
    _mod_mint_feedback("取出产出铜锭 " + str(_n), "ok")
    print("[MapMod] 铸钱厂槽", _idx, "取出产出铜锭 ", _n)
    _mod_mint_refresh_panel()



func _on_mod_mint_slot_take_money(_idx: int, _amount: int)-> void:
    if not _mod_mint_slot_valid(_idx):
        _mod_mint_refresh_panel()
        return
    var _slot: Dictionary = _mod_mint_slots[_idx]
    var _money: int = int(_slot.get("money", 0))
    if _money <= 0:
        _mod_mint_feedback("金框里没有德里", "err")
        _mod_mint_refresh_panel()
        return
    var _n: int = mini(_amount if _amount > 0 else _money, _money)
    _slot["money"] = _money - _n
    WSData.update_money(_n, false)
    _mod_mint_feedback("取出德里 " + str(_n), "ok")
    print("[MapMod] 铸钱厂槽", _idx, "取出德里 ", _n)
    _mod_mint_refresh_panel()







func _mod_mint_daily_settlement()-> void:
    var _today: int = int(WSData.system_counter)
    var _prev_loc: String = _mod_mint_current_loc
    for _loc_code in SoldierUtils.get_player_fief_code_list():
        if _mod_mint_get_level_for_loc(str(_loc_code)) == "":
            continue
        _mod_mint_bind_loc(str(_loc_code))
        if _mod_last_mint_settlement_day == _today:
            continue
        _mod_last_mint_settlement_day = _today
        _mod_mint_today_income = 0
        _mod_mint_align_slots()
        for _slot: Dictionary in _mod_mint_slots:
            var _ore: int = int(_slot.get("ore", 0))
            var _ingot: int = int(_slot.get("ingot", 0))
            var _wood: int = int(_slot.get("wood", 0))
            if _wood <= 0:
                continue
            if _ore > 0:

                var _n: int = mini(MOD_MINT_SMELT_PER_DAY, _ore)
                _slot["ore"] = _ore - _n
                _slot["wood"] = _wood - 1
                _slot["out_ingot"] = int(_slot.get("out_ingot", 0)) + _n
            elif _ingot > 0:

                var _n: int = mini(MOD_MINT_SMELT_PER_DAY, _ingot)
                var _coins: int = _n * MOD_MINT_COINS_PER_INGOT
                _slot["ingot"] = _ingot - _n
                _slot["wood"] = _wood - 1
                _slot["money"] = int(_slot.get("money", 0)) + _coins
                _mod_mint_today_income += _coins
                _mod_mint_total_income += _coins
        _mod_mint_flush()
        if _mod_mint_today_income > 0:
            print("[MapMod] 铸钱厂结算[", _loc_code, "]: 出钱", _mod_mint_today_income, "德里(入槽待取) 累计=", _mod_mint_total_income)

    if _prev_loc != "":
        _mod_mint_bind_loc(_prev_loc)
        if mod_mint_interface_node != null and is_instance_valid(mod_mint_interface_node) and mod_mint_interface_node.visible:
            _mod_mint_refresh_panel()


func _on_dialogue_interface_finish(_result_option_type, _dialogue_json: Dictionary)-> void:

    _mod_dialogue_active = false






    GlobalSoundManager.stop_nun_music()
    dialogue_interface_node.chide()
    m_world_left_info_area_node.disable_button(false)




    var _mod_duel_host_meet: bool = player_meet_node != null \
    and is_instance_valid(player_meet_node) \
    and player_meet_node.get_leader_uid() == "mod_slave_duel_host"
    if _mod_duel_host_meet \
    and _result_option_type == DialogueConstants.OPTION_TYPE_ENUM.TALK \
    and DialogueCustomUtils.duel_host_has_pending_duel():
        player_meet_node = null
        dialogue_interface_node.immediately_hide()
        var _duel_battle_id: String = DialogueCustomUtils.duel_host_prepare_pending_battle()
        if StringUtils.is_empty(_duel_battle_id):

            stop_and_show_module()
        else:
            _change_to_battle_scene_ani(_duel_battle_id)
        return


    if player_meet_node != null and is_instance_valid(player_meet_node) \
    and player_meet_node.get_leader_uid() == "mod_hero_0003" \
    and WSData.has_hero_in_team("mod_hero_0003"):
        GlobalNpcTeamData.clear_npc_team_exist_flag(NpcTeamConstants.NPC_TEAM_CODE.BUXIAO)
        player_meet_node.delete(false)
        player_meet_node = null
    match _result_option_type:
        DialogueConstants.OPTION_TYPE_ENUM.BATTLE:
            dialogue_interface_node.immediately_hide()
            if _dialogue_json.has("enemy_team"):




                var _battle_id: String = WSData.create_battle_by_dialogue_json(_dialogue_json)
                _change_to_battle_scene_ani(_battle_id)
            else:

                if not is_instance_valid(player_meet_node):
                    stop_and_show_module()
                    return
                var _battle_id = TeamUtils.join_battle(player_team_node, player_meet_node)
                TeamUtils.join_battle_by_player_allied_hostile_team_node_list(
                    _battle_id,
                    temp_join_battle_team_info.left_team_node_list,
                    temp_join_battle_team_info.right_team_node_list
                )
                temp_join_battle_team_info = {}

                _change_to_battle_scene_ani(_battle_id)

        DialogueConstants.OPTION_TYPE_ENUM.BATTLE_HELP_TEAM1, DialogueConstants.OPTION_TYPE_ENUM.BATTLE_HELP_TEAM2:
            dialogue_interface_node.immediately_hide()

            if not is_instance_valid(player_meet_node):
                stop_and_show_module()
                return
            var _battle_id: String = player_meet_node.get_current_battle_id()

            var _help_team_type_enum: String = MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM1
            if _result_option_type == DialogueConstants.OPTION_TYPE_ENUM.BATTLE_HELP_TEAM2:
                _help_team_type_enum = MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2

            BattleUtils.add_battle_data_prop(_battle_id, "option_type", _result_option_type)


            var _origin_help_team_node: MWTeam = BattleUtils.get_origin_team_node(_battle_id, _help_team_type_enum)
            if[
                MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER,
                MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY
            ].has(_origin_help_team_node.get_team_role()):
                BattleUtils.add_battle_data_prop(_battle_id, "need_plus_morality_value", _result_option_type)

            player_team_node.join_battle(_battle_id, _help_team_type_enum)
            _change_to_battle_scene_ani(_battle_id)

        DialogueConstants.OPTION_TYPE_ENUM.BRIBERY_LEAVE, \

        DialogueConstants.OPTION_TYPE_ENUM.FLEE:

            if is_instance_valid(player_meet_node):
                player_meet_node.not_attack_player()
            stop_and_show_module()

        _:

            var _has_message: bool = GlobalMessageInterface.maybe_show_important_message_box()

            if not location_enter_interface_node.visible and not _has_message and not team_manage_interface_node.visible:
                stop_and_show_module()
            else:

                stop_and_show_module()


    player_meet_node = null

    if special_build_interface_node.visible:
        special_build_interface_node.unchoose_charactar_card()



    if _mod_auction_dialogue_active:
        _mod_auction_handle_dialogue_finish(_result_option_type)

        if _mod_auction_dialogue_active:
            _mod_dialogue_active = true
            _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
        return


    if _mod_lumber_mill_dialogue_active:
        _mod_lumber_mill_handle_dialogue_finish()

        if _mod_lumber_mill_dialogue_active:
            _mod_dialogue_active = true
            _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
        return


    if _mod_mine_dialogue_active:
        _mod_mine_handle_dialogue_finish()

        if _mod_mine_dialogue_active:
            _mod_dialogue_active = true
            _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
        return


    if _mod_gambler_dialogue_active:
        _mod_gambler_dialogue_active = false
        if _result_option_type == DialogueConstants.OPTION_TYPE_ENUM.TALK:
            var _oname: String = dialogue_interface_node.last_selected_oname
            if _oname == "来一把骰子":
                _mod_show_dice_gamble_interface()
                return

        return



    if DialogueCustomUtils.appraiser_has_pending_open():
        DialogueCustomUtils.appraiser_consume_pending_open()
        _mod_show_appraiser_gamble_interface()
        return


    if _mod_blacksmith_dialogue_active:
        _mod_blacksmith_dialogue_active = false
        if _result_option_type == DialogueConstants.OPTION_TYPE_ENUM.TALK:

            if _mod_current_is_quartermaster:

                var _mode: String = "armor"
                var _oname: String = dialogue_interface_node.last_selected_oname
                match _oname:
                    "分发装备":
                        _mode = "armor"
                    "分发主武器":
                        _mode = "weapon1"
                    "分发副武器":
                        _mode = "weapon2"
                    "分发备用武器":
                        _mode = "weapon3"
                    "分发马匹":
                        _mode = "horse"
                    "分发马铠":
                        _mode = "harmour"
                _mod_show_equip_distribute_interface(_mode)
            else:
                _mod_show_forge_interface()
            _mod_current_is_quartermaster = false
            return

        if _result_option_type == DialogueConstants.OPTION_TYPE_ENUM.LEAVE:
            _mod_current_is_quartermaster = false
            if special_build_interface_node.visible:
                return




func _mod_dialogue_watchdog_tick()-> void:

    var _any_active: bool = _mod_dialogue_active \
    or _mod_auction_dialogue_active \
    or _mod_lumber_mill_dialogue_active \
    or _mod_mine_dialogue_active \
    or _mod_blacksmith_dialogue_active \
    or _mod_gambler_dialogue_active
    if not _any_active:
        return



    var _now: float = Time.get_ticks_msec() / 1000.0

    if is_instance_valid(dialogue_interface_node) and dialogue_interface_node.visible:
        _mod_dialogue_start_time = _now
        return

    var _elapsed: float = _now - _mod_dialogue_start_time
    if _elapsed < 60.0:
        return
    print("[MOD] 对话看门狗: 检测到对话卡死(", _elapsed, "秒), 强制恢复")
    _mod_dialogue_active = false

    if is_instance_valid(dialogue_interface_node):
        dialogue_interface_node.chide()
        GlobalSoundManager.stop_nun_music()

    if is_instance_valid(m_world_left_info_area_node):
        m_world_left_info_area_node.disable_button(false)

    player_meet_node = null
    temp_join_battle_team_info = {}

    _mod_auction_dialogue_active = false
    _mod_lumber_mill_dialogue_active = false
    _mod_mine_dialogue_active = false
    _mod_blacksmith_dialogue_active = false
    _mod_gambler_dialogue_active = false
    _mod_current_is_quartermaster = false

    if get_tree().paused:
        run()

    _show_module()

    if is_instance_valid(tip_node):
        tip_node.cshow("对话异常已自动恢复", 3.0)




func _mod_show_join_country_cg(_country_code: String)-> void:

    if not MOD_JOIN_COUNTRY_CG_PATH.has(_country_code):
        printerr("[MOD] 未配置该国CG: ", _country_code)
        return
    var _cg_path: String = MOD_JOIN_COUNTRY_CG_PATH[_country_code]
    var _texture: Texture2D = CommonUtils._load_texture(_cg_path)
    if _texture == null:
        printerr("[MOD] 无法加载CG图片: ", _cg_path)
        return


    var _bg: ColorRect = ColorRect.new()
    _bg.color = Color.BLACK
    _bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    _bg.mouse_filter = Control.MOUSE_FILTER_STOP
    _bg.z_index = 999
    _bg.modulate.a = 0.0


    _mod_cg_overlay = TextureRect.new()
    _mod_cg_overlay.texture = _texture
    _mod_cg_overlay.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
    _mod_cg_overlay.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    _mod_cg_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    _mod_cg_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    _mod_cg_overlay.z_index = 1000
    _mod_cg_overlay.modulate.a = 0.0


    canvas_layer_node.add_child(_bg)
    canvas_layer_node.add_child(_mod_cg_overlay)


    var _tween_in: = get_tree().create_tween()
    _tween_in.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween_in.tween_property(_bg, "modulate:a", 1.0, 0.5)
    _tween_in.parallel().tween_property(_mod_cg_overlay, "modulate:a", 1.0, 0.5)


    _tween_in.chain().tween_interval(3.0)
    _tween_in.chain().tween_property(_bg, "modulate:a", 0.0, 0.5)
    _tween_in.parallel().tween_property(_mod_cg_overlay, "modulate:a", 0.0, 0.5)
    _tween_in.chain().connect("finished", _mod_hide_join_country_cg.bind(_bg))



func _mod_hide_join_country_cg(_bg: ColorRect = null)-> void:
    if _mod_cg_overlay != null and is_instance_valid(_mod_cg_overlay):
        _mod_cg_overlay.queue_free()
        _mod_cg_overlay = null
    if _bg != null and is_instance_valid(_bg):
        _bg.queue_free()


func _on_mw_clock_and_day_light_controller_to_day_sign()-> void:
    is_day = true
    _location_turn_off_light()




    _mod_lumber_mill_regenerate_forest()





    if TeamUtils.get_player_morale() > 0:

        TeamUtils.player_team_add_learn_skill_exp()



        var _exp: = SkillUtils.get_exp_by_skill_train(WSData.get_player_team_node().team_info.skill_train, WSData.get_player_team_node().team_info.total)
        TeamUtils.team_add_exp(WSData.get_player_team_simple_json_list(), _exp, false)
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.ACQUIRE_EXP_DAILY_TRAIN,[_exp])
        _refresh_upgrade_soldier_icon()



    var _team_info: TeamInfo = WSData.get_player_team_info()
    var _food_depletion: bool = FoodUtils.handle_food_consume_alteration(
        WSData.get_player_data().goods, 0.5,
        _team_info.food_consume_type,

        _team_info.total + int(_team_info.capture_count * BSSoldierConfig.CAPTURE_FOOD_CONSUME_MULT)
    )
    _team_info.refresh_morale()
    if _food_depletion:
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.FOOD_DEPLETION_MESSAGE)



    WSData.handle_prisoner_surrend_and_flee()

    mw_top_box_node.update_day_or_night(is_day)


    _refresh_build_info_and_hero_busy()


    call_deferred("_handle_barracks_overflow_daily")


    GlobalNpcTeamData.plus_power_value_by_time(1.0)


    GlobalNpcTeamData.check_imperial_union_army_daily()


    WSLocationData.refresh_dynamic_hero_location()


    WSData.handle_lord_revive()



    var _mod_money_before_wage: int = WSData.get_player_money()
    WSData.maybe_pay_wage()






    var _wage_script_res = load("res://gd/game/mwBuild/specialBuild/ModWageSystem.gd")
    if _wage_script_res != null:
        var _wage_obj = _wage_script_res.new()
        var _wage_result: Dictionary = _wage_obj.pay_facility_extra_wage(_mod_money_before_wage, _mod_lumber_mill_workers, _mod_mine_workers)
        if not _wage_result.get("paid", false) and _wage_result.get("reason", "") == "insufficient_money":
            if _mod_lumber_mill_is_available():
                _mod_lumber_mill_morale = clampf(_mod_lumber_mill_morale - 15.0, 0.0, 100.0)
            if _mod_mine_is_available():
                _mod_mine_morale = clampf(_mod_mine_morale - 15.0, 0.0, 100.0)
        _wage_obj.show_wage_message(_wage_result)
    else:
        print("[MapMod] WARNING: ModWageSystem.gd 加载失败, 跳过军饷结算")


    GlobalCountryData.handle_toggle_war_status()


    _handle_player_income()


    if WSLocationData.city_data.has(ISLAND_CITY_CODE):
        _mod_check_auction_daily_refresh()

    _mod_trigger_ska_economy_daily()

    _mod_check_typhoon_daily()

    _mod_lumber_mill_daily_settlement()

    _mod_mine_daily_settlement()

    _mod_mint_daily_settlement()

    call_deferred("_mod_fix_island_npc_navigation")

    _mod_teleport_chihiro_home_daily()


func _mod_teleport_chihiro_home_daily()-> void:
    var _current_day: int = int(WSData.system_counter)
    if _current_day <= 0 or _current_day % 20 != 0:
        return

    var _island_lord_spawn: Dictionary = {
        "mod_lord_hero_0001": Vector2(4350, 6570),
        "mod_lord_hero_0002": Vector2(4150, 6750),
    }
    for _lord_uid in _island_lord_spawn.keys():
        var _spawn_pos: Vector2 = _island_lord_spawn[_lord_uid]
        for _team_node in WSData.team_node_info.values():
            if not is_instance_valid(_team_node):
                continue
            if not(_team_node is MWTeamLord):
                continue
            if _team_node.get_leader_uid() != _lord_uid:
                continue

            if _team_node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
                continue

            _team_node.global_position = _spawn_pos
            _team_node.json.position = _spawn_pos
            _team_node.set_move_target(_spawn_pos)

            if _team_node.json.has("behavior_data"):
                _team_node.json.behavior_data.patrol_origin_position = _spawn_pos

            _team_node.reset_flee_pursue_setting()
            print("[MapMod] 岛屿领主(", _lord_uid, ")每20天强制传送回原点: ", _spawn_pos)
            break


func _handle_player_income()-> void:

    for _location_code: String in SoldierUtils.get_player_fief_code_list():
        LocationUtils.handle_pending_income(_location_code)



    var _settlement_interval_days: = TeamConfig.WAGES_INTERVAL_DAYS

    if int(WSData.get_system_counter()) % _settlement_interval_days != 0:
        return

    var _pending_income_total: int = 0
    for _location_code: String in SoldierUtils.get_player_fief_code_list():
        _pending_income_total += LocationUtils.reset_pending_income_and_save_pre(_location_code)

    if _pending_income_total <= 0:
        return

    WSData.update_money(_pending_income_total, false)


    GlobalMessageInterface.add_settlement_income_message(_pending_income_total)

func _handle_barracks_overflow_daily()-> void:
    WSLocationData.handle_barracks_overflow_daily()

func _refresh_build_info_and_hero_busy()-> void:
    WSLocationData.refresh_all_build_status()
    SoldierUtils.refresh_hero_busy_info()

func _important_message_box_close_follow_up()-> void:

    _show_module()

func _handle_lord_disappear_bug()-> void:
    for _lord_hero_uid: String in WSData.fix_lord_disappear_bug_wait_list:
        WSData.handle_lord_defeated(_lord_hero_uid, Vector2.ZERO)



func player_release_hero_hook(_hero_uid: String)-> void:
    team_manage_interface_node.player_release_hero_hook(_hero_uid)



func _on_mw_clock_and_day_light_controller_to_night_sign()-> void:
    is_day = false
    _location_light()



    var _team_info: TeamInfo = WSData.get_player_team_info()
    var _food_depletion: bool = FoodUtils.handle_food_consume_alteration(WSData.get_player_data().goods, 0.5, _team_info.food_consume_type, _team_info.total)
    _team_info.refresh_morale()
    if _food_depletion:
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.FOOD_DEPLETION_MESSAGE)

    mw_top_box_node.update_day_or_night(is_day)


func _on_items_button_pressed():
    stop_include_camera()
    _hide_button_module_root()
    items_interface_node.init()
    items_interface_node.cshow()
    items_interface_node.left_show_save_category_and_need_save()


func _on_items_interface_close_sign():
    _follow_up_close_menu()

func _on_m_world_left_info_area_stop_or_run_sign(_value):
    if _value:
        run()
    else:
        stop()


func _on_common_camera_change_zoom_sign(_zoom):
    GlobalApplication.mw_update_zoom(_zoom)


func _on_team_info_button_pressed():
    stop_include_camera()
    _hide_button_module_root()



    var _node: = PLAYER_REL_INFO_INTERFACE.instantiate()
    player_rel_info_interface_root_node.add_child(_node)
    _node.connect("close_page_sign", _on_team_info_interface_close_sign)

    _node.init()

func _on_team_info_interface_close_sign():
    _follow_up_close_menu()

    player_team_node.refresh_banner()


func _on_mw_clock_system_time_pass_sign(_plus_time):
    mw_top_box_node.update_day()








func _on_game_info_button_pressed():
    stop_include_camera()
    _hide_button_module_root()

    var _node: GameInfoInterface = GAME_INFO_INTERFACE.instantiate()
    game_info_interface_root_node.add_child(_node)

    _node.connect("close_page_sign", _on_game_info_interface_close_page_sign)
    _node.connect("view_info_sign", _on_game_info_interface_view_info_sign)

    _node.init()

func _on_game_info_interface_close_page_sign():
    _follow_up_close_menu()


func _on_m_world_left_info_area_view_mode_sign():
    WSData.get_player_team_node().allow_choose()
    stop()
    _hide_button_module_root()
    view_func_root_node.cshow()


func _on_view_func_root_exit_view_mode_sign():
    WSData.get_player_team_node().forbid_choose()
    _follow_up_close_menu()
    _view_mode_unchoose()


func _on_weather_executor_change_weather_sign(_weather: MWorldConstants.WEATHER_TYPE_ENUM):

    if _mod_typhoon_active:
        change_weather(MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN)
        return
    change_weather(_weather)


func _on_main_menu_button_pressed(_is_defeat_menu: = false)-> void:
    m_world_main_menu_node.cshow(_is_defeat_menu)
    stop_include_camera()
    _hide_button_module_root()


func _on_m_world_main_menu_back_game_sign()-> void:
    _follow_up_close_menu()


func _on_m_world_main_menu_save_game_sign()-> void:
    GlobalSave.save(true)
    _follow_up_close_menu()


func _on_m_world_main_menu_back_main_menu_sign()-> void:
    GlobalNode.game_root.change_to_start_interface()


func _on_m_world_main_menu_load_recent_save_sign()-> void:
    GlobalNode.game_root.load_recent_save()


func _on_common_camera_mobile_click_sign(_position: Vector2)-> void:
    if not view_func_root_node.show_mode:
        _player_move_land(_position)


func _on_m_world_main_menu_open_settings_page_sign()-> void:
    stop_include_camera()
    settings_interface_node.cshow()

func _on_goods_exchange_interface_close_sign()-> void:
    location_enter_interface_node.show_button()



func _on_recruit_interface_close_page_sign()-> void:
    location_enter_interface_node.show_button()

    WSData.refresh_field_wages()

func _on_special_build_interface_close_page_sign()-> void:

    if mod_forge_interface_node != null and mod_forge_interface_node.visible:
        mod_forge_interface_node.hide_interface()
    if mod_equip_distribute_node != null and mod_equip_distribute_node.visible:
        mod_equip_distribute_node.hide_interface()

    if mod_lumber_mill_interface_node != null and mod_lumber_mill_interface_node.visible:
        mod_lumber_mill_interface_node.hide_interface()

    if mod_mine_interface_node != null and mod_mine_interface_node.visible:
        mod_mine_interface_node.hide_interface()

    if _mod_auction_active:
        _mod_auction_active = false
        _mod_auction_current_level = 0
        _mod_auction_dialogue_active = false
        _mod_auction_current_item_idx = -1
        _mod_auction_current_bid = 0
        _mod_auction_bid_round = 0
        _mod_auction_wait_round = 0
        _mod_auction_item_value = 0
        _mod_auction_bidders.clear()
        _mod_auction_bidder_budgets.clear()
        _mod_auction_opening_shown = false
        _mod_auction_last_bidder_text = ""
        _mod_auction_last_host_text = ""
        _mod_auction_list_page = 0
        print("[MapMod] 拍卖行界面已关闭")
    location_enter_interface_node.show_button()


func _on_special_build_interface_interact_with_charactar_sign(_npc_info: Dictionary)-> void:

    if mod_forge_interface_node != null and mod_forge_interface_node.visible:
        return
    if mod_equip_distribute_node != null and mod_equip_distribute_node.visible:
        return
    var _uid: String = _npc_info.get("npc_uid", "")


    if _uid == "mod_gambler":
        _mod_gambler_dialogue_active = true
        _mod_dialogue_active = true
        _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
        _mod_current_npc_name = _npc_info.get("npc_name", "赌徒老鬼")

        var _gambler_template: Dictionary = _mod_build_gambler_dialogue_template()
        var _gambler_right_info: Dictionary = {
            "leader_uid": _uid,
            "leader_name": _mod_current_npc_name,
            "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
        }
        dialogue_interface_node.cshow()
        dialogue_interface_node.init(
            _gambler_template,
            WSData.get_player_team_node().get_dialogue_info(),
            _gambler_right_info
        )
        return





    if _uid.begins_with("mod_blacksmith_") or _uid == "mod_quartermaster":
        _mod_blacksmith_dialogue_active = true

        _mod_dialogue_active = true
        _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
        if _uid == "mod_quartermaster":
            _mod_current_is_quartermaster = true
        _mod_current_forge_type = _npc_info.get("mod_forge_type", "")
        _mod_current_npc_name = _npc_info.get("npc_name", "")


        var _template: Dictionary = _mod_build_dialogue_template(_uid, _mod_current_npc_name)
        var _right_info: Dictionary = {
            "leader_uid": _uid,
            "leader_name": _mod_current_npc_name,
            "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
        }
        dialogue_interface_node.cshow()
        dialogue_interface_node.init(
            _template,
            WSData.get_player_team_node().get_dialogue_info(),
            _right_info
        )
    else:
        dialogue_interface_node.cshow()
        dialogue_interface_node.interact_with_charactar_by_npc_info(_npc_info)



func _mod_build_dialogue_template(_uid: String, _npc_name: String)-> Dictionary:
    var _greeting_text: String = ""
    var _greeting_text2: String = ""
    var _action_text: String = ""

    match _uid:
        "mod_blacksmith_armour":
            _greeting_text = "（盔甲铁匠正在敲打一副胸甲，叮叮当当的声音不绝于耳。看到你走近，他放下锤子擦了擦汗）"
            _greeting_text2 = "大人好！我专打盔甲，头盔、胸甲、护肩、靴子，样样在行。您要锻造什么防具？"
            _action_text = "我想锻造一些防具。"
        "mod_blacksmith_weapon":
            _greeting_text = "（武器铁匠正往剑刃上淬火，嗤的一声白烟升腾。他举起剑端详片刻，才注意到你）"
            _greeting_text2 = "大人！刀剑弓弩，只要您说得出，我就打得出。需要什么兵器？"
            _action_text = "我想锻造一些兵器。"
        "mod_blacksmith_harmour":
            _greeting_text = "（马铠铁匠正在给一副马面甲抛光，金属的光泽映在他专注的脸上。他听到脚步声抬起头）"
            _greeting_text2 = "大人来了！我别的不会，专打马铠。战马披上我打的甲，刀枪不入！您要锻什么马铠？"
            _action_text = "我想锻造一些马铠。"
        "mod_quartermaster":
            _greeting_text = "（军需人员正在清点物资，手里拿着一本厚厚的账册。看到你走近，他合上册子行了个礼）"
            _greeting_text2 = "大人！您的私卫们装备还缺不少。我这里可以帮您把背包里的装备分发给随行的私卫，您要看一看吗？"
            _action_text = "好，我来挑几件装备分发下去。"
        _:
            _greeting_text = "大人好！"
            _greeting_text2 = "需要什么？"
            _action_text = "锻造装备"


    var _options: Dictionary
    if _uid == "mod_quartermaster":

        _options = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "分发装备",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["好，我来挑几件防具分发下去。"]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "分发主武器",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["我来分发一些主武器给私卫。"]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "分发副武器",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["我来分发一些副武器给私卫。"]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "分发备用武器",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["我来分发一些备用武器给私卫。"]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "分发马匹",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["我来挑几匹马分发下去。"]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "分发马铠",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["我来挑几副马铠分发下去。"]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                    "oname": "告辞",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["先不打扰你了，回头见。"]}],
                }
            ]
        }
    else:
        _options = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                    "oname": "锻造装备",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": [_action_text]}],
                },
                {
                    "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                    "oname": "告辞",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["先不打扰你了，回头见。"]}],
                }
            ]
        }
    var _greeting2: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": _uid,
        "content": [{"clist": [_greeting_text2]}],
        "next": _options,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": _uid,
        "content": [{"clist": [_greeting_text]}],
        "next": _greeting2,
    }
    return _greeting



func _mod_build_gambler_dialogue_template()-> Dictionary:
    var _uid: String = "mod_gambler"
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                "oname": "来一把骰子",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["来，陪我玩一把骰子。"]}],
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                "oname": "聊聊",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["你在这酒馆里混了多久了？"]}],
                "next": {
                    "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "turn_hero_uid": _uid,
                    "content": [{"clist": ["嘿，我在这酒馆里混了大半辈子了。什么人没见过？有钱的没钱的，赢了欢天喜地的，输了捶胸顿足的……"]}],
                    "next": {
                        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                        "turn_hero_uid": _uid,
                        "content": [{"clist": ["不过嘛，十赌九输这句话可不是白说的。你要是手痒痒想来一把，我奉陪。但别怪我没提醒你——见好就收才是真本事。"]}],
                        "next": {
                            "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": DialogueConstants.OPTION_TYPE_ENUM.TALK,
                                    "oname": "来一把骰子",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [{"clist": ["说得有理。来，掷一把。"]}],
                                },
                                {
                                    "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "告辞",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [{"clist": ["今天就聊到这吧，回头见。"]}],
                                }
                            ]
                        },
                    },
                },
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                "oname": "告辞",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["不打扰你了，回头见。"]}],
            }
        ]
    }
    var _greeting2: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": _uid,
        "content": [{"clist": ["哟，新面孔？坐下来，陪我老鬼玩两把骰子怎么样？小赌怡情嘛。"]}],
        "next": _options,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": _uid,
        "content": [{"clist": ["（角落里一个瘦削的老头正独自掷着骰子玩，骰子在木桌上滚来滚去。他抬起头，浑浊的眼睛里闪过一丝精光）"]}],
        "next": _greeting2,
    }
    return _greeting


func _on_team_exchange_interface_close_page_sign()-> void:
    location_enter_interface_node.show_button()
    WSData.refresh_garrison_wages_interval_by_location_code(GlobalTempData.get_current_location_code())
    WSData.refresh_field_wages()

func _on_warehouse_interface_close_sign()-> void:
    location_enter_interface_node.show_button()





func _mod_add_player_guard_to_recruit()-> void:
    var _location_code: String = GlobalTempData.current_location_code
    var _city_data: Dictionary = WSLocationData.get_city_data(_location_code)
    if not _city_data.has("recruit"):
        _city_data["recruit"] = []
    var _recruit_list: Array = _city_data["recruit"]


    var _saved_list: Array = []
    for _entry in _recruit_list:
        if _entry is Dictionary and _entry.get("uid", "") == "mod_player_guard":
            continue
        _saved_list.append(_entry)
    GlobalTempData.mod_armory_saved_recruit = _saved_list


    _city_data["recruit"] = []
    _recruit_list = _city_data["recruit"]


    var _guard_name: String = SoldierUtils.get_player_name() + "私卫"
    if GlobalSoldierInfo.soldier_dic.has("mod_player_guard"):
        GlobalSoldierInfo.soldier_dic["mod_player_guard"]["name"] = _guard_name


    var _player_team_json: Dictionary = TeamUtils.get_player_team_json()
    if not _player_team_json.has("mod_armory_refresh_time"):
        _player_team_json["mod_armory_refresh_time"] = {}
    if not _player_team_json.has("mod_armory_recruited"):
        _player_team_json["mod_armory_recruited"] = {}

    var _last_refresh: float = _player_team_json["mod_armory_refresh_time"].get(_location_code, -100.0)
    var _current_day: float = WSData.system_counter
    var _days_since: float = _current_day - _last_refresh


    if _days_since >= 5.0 or _last_refresh < 0:
        _player_team_json["mod_armory_recruited"][_location_code] = 0
        _player_team_json["mod_armory_refresh_time"][_location_code] = _current_day


    var _recruited_count: int = int(_player_team_json["mod_armory_recruited"].get(_location_code, 0))
    var _guards_to_show: int = max(0, 5 - _recruited_count)


    for _i in range(_guards_to_show):
        var _simple_json: Dictionary = {"uid": "mod_player_guard"}
        SoldierUtils.repair_simple_json(_simple_json)
        _recruit_list.append(_simple_json)



func _mod_ensure_city_recruit_not_empty()-> void:
    var _location_code: String = GlobalTempData.current_location_code
    var _city_data: Dictionary = WSLocationData.get_city_data(_location_code)
    if not _city_data.has("recruit"):
        _city_data["recruit"] = []
    var _recruit_list: Array = _city_data["recruit"]

    var _normal_list: Array = []
    for _entry in _recruit_list:
        if _entry is Dictionary and _entry.get("uid", "") == "mod_player_guard":
            continue



        if _entry is Dictionary and not _entry.has("living_status"):
            SoldierUtils.repair_simple_json(_entry)
        _normal_list.append(_entry)

    if _normal_list.is_empty():



        var _player_team_json: Dictionary = TeamUtils.get_player_team_json()
        var _last_refresh: float = TeamUtils.get_refresh_time_recruit(_player_team_json, _location_code)
        var _interval: float = WSData.system_counter - _last_refresh

        if _last_refresh < 0.0 or _interval >= LocationConfig.COMPLETE_REFRESH_RECRUIT_DAYS:
            var _recruit_config: Dictionary = LocationUtils._get_recruit_config(_city_data)
            var _random_config: Dictionary = {}
            if _recruit_config.has("common"):
                for _key in _recruit_config.common.keys():
                    _random_config[_key] = _recruit_config.common.get(_key)
            for _i in range(10):
                var _soldier_uid = CommonUtils.random_item_weight(_random_config)
                if _soldier_uid != null:



                    var _item_json: Dictionary = {"uid": _soldier_uid}
                    SoldierUtils.repair_simple_json(_item_json)
                    _normal_list.append(_item_json)

            TeamUtils.update_refresh_time_recruit(_location_code)
    _city_data["recruit"] = _normal_list


func _mod_show_forge_interface()-> void:
    if mod_forge_interface_node == null:
        var _script = load("res://gd/game/mwBuild/specialBuild/ModForgeInterface.gd")
        if _script == null:
            _mod_msg("锻造界面加载失败(MOD文件缺失)", 3.0, false)
            print("[MapMod] WARNING: ModForgeInterface.gd 加载失败")
            return
        mod_forge_interface_node = Control.new()
        mod_forge_interface_node.set_script(_script)
        mod_forge_interface_node.connect("close_page_sign", _on_mod_forge_close_page_sign)

        special_build_interface_node.add_child(mod_forge_interface_node)
    mod_forge_interface_node.set_forge_type(_mod_current_forge_type)
    mod_forge_interface_node.show_interface()


func _on_mod_forge_close_page_sign()-> void:

    if special_build_interface_node.visible:
        special_build_interface_node.chide()
    location_enter_interface_node.show_button()



func _mod_show_equip_distribute_interface(_mode: String = "armor")-> void:
    if mod_equip_distribute_node == null:
        var _script = load("res://gd/game/mwBuild/specialBuild/ModEquipDistributeInterface.gd")
        if _script == null:
            _mod_msg("装备分发界面加载失败(MOD文件缺失)", 3.0, false)
            print("[MapMod] WARNING: ModEquipDistributeInterface.gd 加载失败")
            return
        mod_equip_distribute_node = Control.new()
        mod_equip_distribute_node.set_script(_script)
        mod_equip_distribute_node.connect("close_page_sign", _on_mod_equip_distribute_close_page_sign)
        special_build_interface_node.add_child(mod_equip_distribute_node)
    mod_equip_distribute_node.distribute_mode = _mode
    mod_equip_distribute_node.show_interface()


func _on_mod_equip_distribute_close_page_sign()-> void:
    if special_build_interface_node.visible:
        special_build_interface_node.chide()
    location_enter_interface_node.show_button()



func _mod_show_dice_gamble_interface()-> void:
    if mod_dice_gamble_interface_node == null:
        var _script = load("res://gd/game/interface/ModDiceGambleInterface.gd")
        if _script == null:
            print("[MapMod] WARNING: ModDiceGambleInterface.gd 加载失败")
            return
        mod_dice_gamble_interface_node = Control.new()
        mod_dice_gamble_interface_node.set_script(_script)
        mod_dice_gamble_interface_node.connect("close_page_sign", _on_mod_dice_gamble_close_page_sign)

        special_build_interface_node.add_child(mod_dice_gamble_interface_node)
    mod_dice_gamble_interface_node.show_interface()


func _on_mod_dice_gamble_close_page_sign()-> void:

    if special_build_interface_node.visible:
        special_build_interface_node.unchoose_charactar_card()



func _mod_show_appraiser_gamble_interface()-> void:
    if mod_appraiser_gamble_interface_node == null:
        var _script = load("res://gd/game/interface/ModAppraiserGambleInterface.gd")
        if _script == null:
            print("[MapMod] WARNING: ModAppraiserGambleInterface.gd 加载失败")
            return
        mod_appraiser_gamble_interface_node = Control.new()
        mod_appraiser_gamble_interface_node.set_script(_script)
        mod_appraiser_gamble_interface_node.connect("close_page_sign", _on_mod_appraiser_gamble_close_page_sign)

        special_build_interface_node.add_child(mod_appraiser_gamble_interface_node)
    mod_appraiser_gamble_interface_node.init(GlobalTempData.current_location_code)
    mod_appraiser_gamble_interface_node.show_interface()


func _on_mod_appraiser_gamble_close_page_sign()-> void:

    if special_build_interface_node.visible:
        special_build_interface_node.unchoose_charactar_card()



func _on_mod_prison_close_page_sign()-> void:
    location_enter_interface_node.show_button()


func _on_game_info_interface_view_info_sign(_soldier_prop: BSSoldierProp)-> void:
    _view_soldier_info(_soldier_prop)

func _on_special_build_interface_view_soldier_info_sign(_uid: String)-> void:
    var _soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_uid(_uid)
    _view_soldier_info(_soldier_prop)

func _on_recruit_interface_view_soldier_info_sign(_soldier_prop: BSSoldierProp)-> void:
    _view_soldier_info(_soldier_prop)


func _on_m_world_left_info_area_player_camping_sign()-> void:
    player_team_node.camping()
    hide_player_path_line()
    tip_cshow_camping()


func _on_m_world_left_info_area_player_train_sign()-> void:
    player_team_node.train()
    hide_player_path_line()
    tip_node.cshow(TIP_ENUM.TRAIN)

func _on_team_manage_interface_talk_to_prisoner_hero_sign(_hero_uid: String)-> void:
    var _dialogue_gd: BaseDialogue = DialogueUtils.get_dialogue_gd_by_hero_uid(_hero_uid)

    if _dialogue_gd == null:
        print("[Mod] 该英雄没有对话文件, 无法对话: ", _hero_uid)
        return

    _mod_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    dialogue_interface_node.cshow()
    dialogue_interface_node.init(
        _dialogue_gd.get_captured_wait_for_release_dialogue(),
        TeamUtils.get_player_team_node().get_dialogue_info(),
        DialogueUtils.get_dialogue_info(_hero_uid)
    )




const EXPANDED_BOTTOM = 8000


static var _mod_log_enabled: bool = true
static var _mod_log_file: FileAccess = null

static func _mod_log(_msg: String, _v1 = "", _v2 = "", _v3 = "")-> void:
    if not _mod_log_enabled:
        return
    if _mod_log_file == null:
        _mod_log_file = FileAccess.open("user://mod_crash_log.txt", FileAccess.WRITE)
        if _mod_log_file == null:
            _mod_log_enabled = false
            return
    var _line = str(Time.get_ticks_msec()) + " " + _msg
    if str(_v1) != "":
        _line += " " + str(_v1)
    if str(_v2) != "":
        _line += " " + str(_v2)
    if str(_v3) != "":
        _line += " " + str(_v3)
    _mod_log_file.store_line(_line)
    _mod_log_file.flush()
    print("[MapMod] ", _line)

func _setup_new_map()-> void:
    _mod_log("setup_new_map: START")
    print("[MapMod] 开始初始化新地图...")

    var map_root = get_node_or_null("MapRoot")
    if not map_root:
        print("[MapMod] 错误: MapRoot 不存在")
        return


    var water_tex = _load_map_tex("map02/water_base.png")
    if water_tex:
        var water_w = water_tex.get_width()
        var water_h = water_tex.get_height()
        var water_scale = 2.0
        var tile_display_w = water_w * water_scale
        var tile_display_h = water_h * water_scale

        var tile_positions = [
            Vector2(tile_display_w / 2.0, 4000 + tile_display_h / 2.0),
            Vector2(tile_display_w * 1.5, 4000 + tile_display_h / 2.0),
        ]

        for i in range(tile_positions.size()):
            var water_sprite = Sprite2D.new()
            water_sprite.name = "NewMapWater" + str(i)
            water_sprite.position = tile_positions[i]
            water_sprite.scale = Vector2(water_scale, water_scale)
            water_sprite.z_index = -10
            water_sprite.texture = water_tex
            map_root.add_child(water_sprite)
    else:
        print("[MapMod] 警告: 海水纹理加载失败")


    var island_tex = _load_map_tex("newisland/newisland_base.png")
    if island_tex:
        var island_w = island_tex.get_width()
        var island_h = island_tex.get_height()
        var island_target_h = 3500.0
        var island_scale = island_target_h / island_h
        var island_sprite = Sprite2D.new()
        island_sprite.name = "NewMapIsland"
        island_sprite.position = Vector2(4000, 6000)
        island_sprite.scale = Vector2(island_scale, island_scale)
        island_sprite.z_index = -9
        island_sprite.texture = island_tex
        map_root.add_child(island_sprite)
        print("[MapMod] 岛屿已添加: ", island_w, "x", island_h, " scale=", island_scale)
    else:
        print("[MapMod] 警告: 岛屿纹理加载失败")


    map_size = Vector2(common_camera_node.limit_right, common_camera_node.limit_bottom)


    if mwb_rain_root_node:
        mwb_rain_root_node.update_size(map_size)



    var _nav_timer = Timer.new()
    _nav_timer.name = "NavSetupTimer"
    _nav_timer.one_shot = true
    _nav_timer.wait_time = 0.5
    _nav_timer.timeout.connect(_setup_island_navigation)
    add_child(_nav_timer)
    _nav_timer.start()
    _setup_island_boundary_walls()
    _mod_log("setup_new_map: boundary walls done")


    _place_island_trees()
    _place_port()
    _mod_log("setup_new_map: port placed")




    var _port_timer = Timer.new()
    _port_timer.name = "PortTeleportTimer"
    _port_timer.wait_time = 0.2
    _port_timer.timeout.connect(_check_port_teleport)
    _port_timer.timeout.connect(_check_lumber_mill_arrival)
    _port_timer.timeout.connect(_check_mine_arrival)
    add_child(_port_timer)
    _port_timer.start()


    var _nav_fix_timer = Timer.new()
    _nav_fix_timer.name = "IslandNavFixTimer"
    _nav_fix_timer.wait_time = 2.0
    _nav_fix_timer.timeout.connect(_mod_fix_island_npc_navigation)
    add_child(_nav_fix_timer)
    _nav_fix_timer.start()

    _mod_log("setup_new_map: ALL DONE")
    print("[MapMod] 初始化完成")






const MOD_NAV_AIRWALL_DATA = "3429,4250,336,112;3429,4362,448,112;3989,4362,224,112;4102,4362,560,112;3429,4474,784,112;4102,4474,784,112;3429,4586,784,112;4102,4586,784,112;3429,4698,784,112;4102,4698,672,112;4886,4810,336,112;3317,4922,896,112;4102,4922,672,112;4774,4922,448,112;2756,5034,336,112;3317,5034,896,112;4102,5034,1120,112;2756,5146,448,112;3205,5146,1008,112;4102,5146,1120,112;2756,5258,448,112;3093,5258,1120,112;4102,5258,1120,112;2756,5371,448,112;3093,5371,1120,112;4102,5371,1120,112;2756,5483,448,112;3093,5483,1120,112;4102,5483,1120,112;2756,5595,448,112;3093,5595,336,112;3877,5595,336,112;4102,5595,1120,112;2756,5707,448,112;3093,5707,448,112;4550,5707,672,112;2756,5819,448,112;3093,5819,336,112;4774,5819,336,112;2756,5931,448,112;3093,5931,336,112;4774,5931,336,112;2756,6043,448,112;3093,6043,336,112;4774,6043,224,112;2868,6155,336,112;3093,6155,224,112;4662,6155,448,112;2868,6267,336,112;4662,6267,560,112;2868,6380,336,112;4662,6380,560,112;2868,6492,336,112;4662,6492,672,112;2868,6604,336,112;4662,6604,672,112;2980,6716,224,112;4662,6716,672,112;2980,6828,224,112;3093,6828,224,112;4662,6828,672,112;2980,6940,224,112;3093,6940,224,112;4662,6940,672,112;2980,7052,224,112;3093,7052,336,112;4774,7052,448,112;2980,7164,224,112;3093,7164,336,112;2868,7276,336,112;3093,7276,336,112;2980,7389,224,112;3093,7389,336,112"

const MOD_NAV_CITY_WALL_POS = Vector2(3820, 7320)
const MOD_NAV_CITY_WALL_RADIUS = 120.0

func _find_nav_region_recursive(node: Node)-> NavigationRegion2D:
    if node is NavigationRegion2D:
        return node
    for child in node.get_children():
        var result = _find_nav_region_recursive(child)
        if result != null:
            return result
    return null

func _setup_island_navigation()-> void:



    var coast_data = "3483,4250;3670,4312;3886,4441;4310,4341;4450,4344;4625,4397;4775,4529;4829,4656;4816,4752;4692,4929;4711,4985;4762,4985;4980,4799;5026,4799;5078,4857;5143,5010;5174,5244;5174,5531;5100,5838;5100,6077;5154,6227;5174,6698;5217,6744;5260,6942;5260,7112;5228,7149;5237,7303;5271,7367;5311,7614;5345,7689;5286,7737;4711,7737;4565,7630;4369,7717;4315,7706;4235,7643;4035,7674;3928,7654;3628,7674;3495,7612;3364,7641;3247,7578;3188,7476;3049,7445;2959,7484;3008,7552;2956,7598;2889,7505;2895,7419;2838,7337;2743,7380;2727,7318;2698,7301;2653,7344;2696,7245;2698,6751;2772,6539;2770,6163;2718,6059;2691,5773;2693,5347;2738,5200;2741,5099;2785,5039;2860,5052;3040,5199;3122,5334;3158,5323;3243,5105;3424,4350;3483,4251"
    var coords = coast_data.split(";")

    var coast_points = PackedVector2Array()
    for coord in coords:
        var xy = coord.split(",")
        coast_points.append(Vector2(int(xy[0]), int(xy[1])))

    var map_root = get_node_or_null("MapRoot")
    if not map_root:
        print("[MapMod] 警告: MapRoot不存在")
        return

    var existing_region = _find_nav_region_recursive(map_root)
    if existing_region == null:
        print("[MapMod] 未找到现有 NavigationRegion2D")
        return

    var old_poly = existing_region.navigation_polygon
    if old_poly == null:
        print("[MapMod] 现有 NavigationRegion2D 没有 NavigationPolygon")
        return

    var old_vert_count = old_poly.vertices.size()
    var old_poly_count = old_poly.get_polygon_count()
    print("[MapMod] 现有导航: ", old_vert_count, " 顶点, ", old_poly_count, " 多边形")


    var center = Vector2.ZERO
    for p in coast_points:
        center += p
    center /= coast_points.size()


    var baked_island_poly = _bake_island_nav_with_airwalls(coast_points, old_poly.agent_radius)


    var new_poly = NavigationPolygon.new()
    new_poly.agent_radius = old_poly.agent_radius


    var all_vertices = PackedVector2Array()
    for v in old_poly.vertices:
        all_vertices.append(v)


    for i in range(old_poly_count):
        new_poly.add_polygon(old_poly.get_polygon(i))

    if baked_island_poly != null and baked_island_poly.get_polygon_count() > 0:

        var island_vert_offset = all_vertices.size()
        for v in baked_island_poly.vertices:
            all_vertices.append(v)
        new_poly.vertices = all_vertices
        for i in range(baked_island_poly.get_polygon_count()):
            var poly = baked_island_poly.get_polygon(i)
            var adjusted = PackedInt32Array()
            for idx in poly:
                adjusted.append(idx + island_vert_offset)
            new_poly.add_polygon(adjusted)
        print("[MapMod] 岛屿导航使用烘焙方案(含空气墙障碍): ", baked_island_poly.get_polygon_count(), " 岛屿多边形")
    else:

        var center_idx = all_vertices.size()
        all_vertices.append(center)
        for p in coast_points:
            all_vertices.append(p)
        new_poly.vertices = all_vertices

        var n = coast_points.size()
        var added_count = 0
        var skipped_count = 0
        for i in range(n):
            var v1 = coast_points[i]
            var v2 = coast_points[(i + 1) % n]
            var centroid =(center + v1 + v2) / 3.0
            if _is_point_in_airwall(centroid) or _is_point_in_airwall(v1) or _is_point_in_airwall(v2):
                skipped_count += 1
                continue
            var tri = PackedInt32Array()
            tri.append(center_idx)
            tri.append(center_idx + 1 + i)
            tri.append(center_idx + 1 +(i + 1) % n)
            new_poly.add_polygon(tri)
            added_count += 1
        print("[MapMod] 岛屿导航使用过滤方案: 保留 ", added_count, " 跳过 ", skipped_count, " (空气墙区域)")

    existing_region.navigation_polygon = new_poly

    if get_world_2d():
        NavigationServer2D.map_force_update(get_world_2d().navigation_map)

    print("[MapMod] 岛屿导航完成! 总多边形: ", new_poly.get_polygon_count())


func _bake_island_nav_with_airwalls(coast_points: PackedVector2Array, agent_radius: float)-> NavigationPolygon:

    if not ClassDB.class_exists("NavigationMeshSourceGeometryData2D"):
        print("[MapMod] NavigationMeshSourceGeometryData2D 不可用, 使用过滤方案")
        return null
    if not NavigationServer2D.has_method("bake_from_source_geometry_data"):
        print("[MapMod] bake_from_source_geometry_data 不可用, 使用过滤方案")
        return null

    var source_data = NavigationMeshSourceGeometryData2D.new()


    source_data.add_traversable_outline(coast_points)


    var wall_rects = MOD_NAV_AIRWALL_DATA.split(";")
    var obstruction_count = 0
    for rect_str in wall_rects:
        var parts = rect_str.split(",")
        if parts.size() < 4:
            continue
        var x = int(parts[0])
        var y = int(parts[1])
        var w = int(parts[2])
        var h = int(parts[3])
        var outline = PackedVector2Array([
            Vector2(x, y),
            Vector2(x + w, y),
            Vector2(x + w, y + h),
            Vector2(x, y + h)
        ])
        source_data.add_obstruction_outline(outline)
        obstruction_count += 1


    var city_outline = PackedVector2Array()
    for i in range(16):
        var angle = i * TAU / 16.0
        city_outline.append(MOD_NAV_CITY_WALL_POS + Vector2(cos(angle), sin(angle)) * MOD_NAV_CITY_WALL_RADIUS)
    source_data.add_obstruction_outline(city_outline)
    obstruction_count += 1

    print("[MapMod] 烘焙: ", obstruction_count, " 个障碍物轮廓")

    var island_poly = NavigationPolygon.new()
    island_poly.agent_radius = agent_radius
    NavigationServer2D.bake_from_source_geometry_data(island_poly, source_data)

    if island_poly.get_polygon_count() == 0:
        print("[MapMod] 烘焙失败: 无多边形生成")
        return null

    print("[MapMod] 烘焙成功: ", island_poly.get_polygon_count(), " 多边形, ", island_poly.vertices.size(), " 顶点")
    return island_poly


func _is_point_in_airwall(point: Vector2)-> bool:
    var wall_rects = MOD_NAV_AIRWALL_DATA.split(";")
    for rect_str in wall_rects:
        var parts = rect_str.split(",")
        if parts.size() < 4:
            continue
        var x = float(parts[0])
        var y = float(parts[1])
        var w = float(parts[2])
        var h = float(parts[3])
        if point.x >= x and point.x <= x + w and point.y >= y and point.y <= y + h:
            return true

    if point.distance_to(MOD_NAV_CITY_WALL_POS) < MOD_NAV_CITY_WALL_RADIUS:
        return true
    return false





const MOD_ISLAND_NPC_BOUNDS_X_MIN = 2900.0
const MOD_ISLAND_NPC_BOUNDS_X_MAX = 5200.0
const MOD_ISLAND_NPC_BOUNDS_Y_MIN = 4350.0
const MOD_ISLAND_NPC_BOUNDS_Y_MAX = 7700.0
var _mod_npc_prev_positions: Dictionary = {}

func _mod_fix_island_npc_navigation()-> void:
    if not is_instance_valid(team_root_node):
        return
    for _child in team_root_node.get_children():
        if not(_child is MWTeam):
            continue

        if _child.is_player:
            continue

        if _child.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY:
            continue


        var _is_fleeing = _child.flee_speed_boost_mult > 1.0

        if _child.global_position.y <= 4000.0:
            continue

        var _nav_agent = _child.get_node_or_null("NavigationAgent2D")
        if _nav_agent == null:
            continue

        var _target: Vector2 = _nav_agent.target_position
        if _target.y <= 4000.0:
            var _new_x: float = float(CommonUtils.random_num2(int(MOD_ISLAND_NPC_BOUNDS_X_MIN), int(MOD_ISLAND_NPC_BOUNDS_X_MAX)))
            var _new_y: float = float(CommonUtils.random_num2(int(MOD_ISLAND_NPC_BOUNDS_Y_MIN), int(MOD_ISLAND_NPC_BOUNDS_Y_MAX)))
            _nav_agent.target_position = Vector2(_new_x, _new_y)
            print("[MapMod] 岛屿NPC导航修复: ", _child.name, " 目标从(", _target.x, ",", _target.y, ")重置到(", _new_x, ",", _new_y, ")")
            continue

        var _uid = _child.get_uid()
        var _cur_pos = _child.global_position

        var _stuck_threshold = 3 if not _is_fleeing else 2
        if _mod_npc_prev_positions.has(_uid):
            var _prev = _mod_npc_prev_positions[_uid]
            var _dist = _cur_pos.distance_to(_prev.pos)
            if _dist < 20.0:

                _prev.stuck_count += 1
                if _prev.stuck_count >= _stuck_threshold:
                    var _safe_target
                    if _is_fleeing:


                        _safe_target = _find_safe_island_target(_cur_pos)
                        _child.global_position = _safe_target
                        _nav_agent.target_position = _safe_target
                        print("[MapMod] 岛屿NPC卡墙传送脱困: ", _child.name, " 从(", _cur_pos.x, ",", _cur_pos.y, ")传送到(", _safe_target.x, ",", _safe_target.y, ")")
                    else:

                        _safe_target = _find_safe_island_target(_cur_pos)
                        _nav_agent.target_position = _safe_target
                        print("[MapMod] 岛屿NPC卡墙修复: ", _child.name, " 从(", _cur_pos.x, ",", _cur_pos.y, ")重定向到(", _safe_target.x, ",", _safe_target.y, ")")
                    _prev.stuck_count = 0
                    _prev.pos = _child.global_position
            else:
                _prev.stuck_count = 0
                _prev.pos = _cur_pos
        else:
            _mod_npc_prev_positions[_uid] = {"pos": _cur_pos, "stuck_count": 0}


    if _mod_npc_prev_positions.size() > 200:
        var _valid_uids = {}
        for _child2 in team_root_node.get_children():
            if _child2 is MWTeam:
                _valid_uids[_child2.get_uid()] = true
        var _keys_to_remove = []
        for _k in _mod_npc_prev_positions.keys():
            if not _valid_uids.has(_k):
                _keys_to_remove.append(_k)
        for _k in _keys_to_remove:
            _mod_npc_prev_positions.erase(_k)


func _find_safe_island_target(_from_pos: Vector2)-> Vector2:
    for _attempt in range(10):
        var _x = float(CommonUtils.random_num2(int(MOD_ISLAND_NPC_BOUNDS_X_MIN), int(MOD_ISLAND_NPC_BOUNDS_X_MAX)))
        var _y = float(CommonUtils.random_num2(int(MOD_ISLAND_NPC_BOUNDS_Y_MIN), int(MOD_ISLAND_NPC_BOUNDS_Y_MAX)))
        var _candidate = Vector2(_x, _y)
        if not _is_point_in_airwall(_candidate):
            return _candidate

    return ISLAND_CITY_POS + Vector2(200, 200)


func _mod_trigger_ska_economy_daily()-> void:
    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        print("[MapMod] DEBUG: city_data无MWCity0009")
        return

    var _city_node = GlobalLocationData.city_node_dic.get(ISLAND_CITY_CODE, null)
    if _city_node == null or not is_instance_valid(_city_node):
        print("[MapMod] DEBUG: city_node_dic中无MWCity0009, keys=", GlobalLocationData.city_node_dic.keys())
        return
    print("[MapMod] DEBUG: 城市节点=", _city_node.name, " open_econ=", _city_node.open_economic_system, " trade_list=", _city_node.trade_city_code_list)

    if _city_node.open_economic_system:
        _city_node.open_economic_system = false
        _city_node.trade_city_code_list = []
        print("[MapMod] 斯卡城经济系统已关闭 (不生成商队)")

    var _econ = _city_node.get_node_or_null("EconomicSystem")
    if _econ:
        print("[MapMod] DEBUG: EconomicSystem存在, has to_day=", _econ.has_method("to_day"))
        if _econ.has_method("to_day"):
            _econ.to_day()
            print("[MapMod] DEBUG: EconomicSystem.to_day()已调用")
    else:
        print("[MapMod] DEBUG: EconomicSystem子节点不存在, 检查子节点: ", _city_node.get_children().size())
        for _c in _city_node.get_children():
            print("[MapMod] DEBUG: 子节点: ", _c.name, " (", _c.get_class(), ")")

    if _city_node.has_method("to_day"):
        _city_node.to_day()
        print("[MapMod] 斯卡城to_day已调用 (经济活动触发)")
    else:
        print("[MapMod] DEBUG: 斯卡城无to_day方法")

    if get_world_2d():
        var _path = NavigationServer2D.map_get_path(
            get_world_2d().navigation_map,
            ISLAND_CITY_POS,
            PORT_POS,
            false
        )
        print("[MapMod] DEBUG: 岛屿→大陆港口 路径点数=", _path.size())

    var _caravan_count: int = 0
    for _child in team_root_node.get_children():
        if not(_child is MWTeam) or _child.is_player:
            continue
        if _child.get_team_role() != MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY:
            continue
        var _tj = WSData.other_team_data.get(_child.uid,{})
        var _o = _tj.get("origin_location_code", "")
        var _t = _tj.get("target_location_code", "")
        if _o == ISLAND_CITY_CODE or _t == ISLAND_CITY_CODE:
            _caravan_count += 1
    print("[MapMod] DEBUG: 当前斯卡城商队数量=", _caravan_count)




func _setup_island_boundary_walls()-> void:
    var _island_data_script = load("res://gd/game/map/ModIslandData.gd")
    if not _island_data_script:
        push_error("[MapMod] ModIslandData.gd not found — boundary walls skipped")
        return
    var wall_data: String = _island_data_script.WALL_DATA
    var rects = wall_data.split(";")

    var map_root = get_node_or_null("MapRoot")
    if not map_root:
        map_root = self



    var mountain_body = StaticBody2D.new()
    mountain_body.name = "MountainWalls"
    mountain_body.collision_layer = 1024
    mountain_body.collision_mask = 0
    map_root.add_child(mountain_body)

    var wall_count = 0
    for rect_str in rects:
        var parts = rect_str.split(",")
        if parts.size() < 4:
            continue
        var x = int(parts[0])
        var y = int(parts[1])
        var w = int(parts[2])
        var h = int(parts[3])

        var col_shape = CollisionShape2D.new()
        var rect_shape = RectangleShape2D.new()
        rect_shape.size = Vector2(w, h)
        col_shape.shape = rect_shape
        col_shape.position = Vector2(x + w / 2.0, y + h / 2.0)
        mountain_body.add_child(col_shape)
        wall_count += 1

    print("[MapMod] 山体空气墙创建完成: ", wall_count, " 个碰撞体")


const ISLAND_CITY_POS = Vector2(3820, 7320)
const ISLAND_CITY_CODE = "MWCity0009"

func _place_island_city()-> void:
    var city_root = get_node_or_null("ObjectRoot/MapObjectRoot/CityRoot")
    if not city_root:
        print("[MapMod] CityRoot不存在, 无法放置斯卡城")
        return


    var existing = city_root.get_node_or_null(ISLAND_CITY_CODE)
    if existing:
        existing.free()


    if not WSLocationData.city_data.has(ISLAND_CITY_CODE):
        var _city_data = {
            "location_code": ISLAND_CITY_CODE,
            "name": "斯卡",
            "type": "CITY",
            "ethnicity": "Saina",
            "belong_country": "Edras",
            "owner_uid": "",
            "location_size_max": 2600,
            "mercenary_spawn_prob": 1.3,
            "population_total": 2000,
            "population_working_age": 2000,
            "consumption_goods": 1800,
            "excess_goods": 1200,
            "happiness_level": 550,
            "tax_ratio": 0.2,
            "prosperity_level": 400,
            "development_level": 500,
            "hygiene_level": 500,
            "specialty_grocery": {

                "commodity_0001": 100,
                "commodity_0002": 100,
                "commodity_0003": 100,

                "food_0007": 100,
                "food_0011": 100,
                "food_0012": 100,
                "food_0015": 100,
                "food_0017": 100,
                "food_0019": 100,
                "food_0022": 100,
                "food_0025": 100,
                "food_0026": 100,
                "food_0027": 100,
                "food_0029": 100,
            },
            "goods_refresh_time": -100.0,
            "recruit_refresh_time": -100.0,
            "recruit": [],
            "goods_grocery": [],
            "goods_smithy": [],
            "goods_armour": [],
            "goods_horse": [],
            "money_grocery": 0,
            "money_smithy": 0,
            "money_armour": 0,
            "money_horse": 0,

            "goods_auction": [],
            "money_auction": 999999,
            "mod_auction_refresh_time": -100.0,
            "mod_auction_next_interval": 15,

            "mod_auction_high_goods": [],
            "mod_auction_mid_goods": [],
            "mod_auction_low_goods": [],
            "mod_auction_refresh_day": -100.0,
            "button_type_list": [
                "Piazza",
                "Smithy",
                "Armour",
                "Horse",
                "Grocery",
                "Hotel",
                "Tavern",
            ],
        }
        WSLocationData.city_data[ISLAND_CITY_CODE] = _city_data
        print("[MapMod] 斯卡城数据已构建: ", _city_data.name)



    var _ska_city_data = WSLocationData.city_data.get(ISLAND_CITY_CODE)
    if _ska_city_data:


        _ska_city_data.specialty_grocery = {
            "commodity_0001": 100,
            "commodity_0002": 100,
            "commodity_0003": 100,
            "food_0007": 100,
            "food_0011": 100,
            "food_0012": 100,
            "food_0015": 100,
            "food_0017": 100,
            "food_0019": 100,
            "food_0022": 100,
            "food_0025": 100,
            "food_0026": 100,
            "food_0027": 100,
            "food_0029": 100,
        }

        var _positive_dic = {}
        for _code in _ska_city_data.specialty_grocery.keys():
            var _val = _ska_city_data.specialty_grocery.get(_code)
            if _val > 0:
                _positive_dic[_code] = _val
        _ska_city_data.specialty_grocery_positive = _positive_dic

        if not _ska_city_data.has("specialty_smithy") or _ska_city_data.specialty_smithy.is_empty():
            _ska_city_data.specialty_smithy = {}
        if not _ska_city_data.has("specialty_armour") or _ska_city_data.specialty_armour.is_empty():
            _ska_city_data.specialty_armour = {}
        if not _ska_city_data.has("specialty_horse") or _ska_city_data.specialty_horse.is_empty():
            _ska_city_data.specialty_horse = {}

        if not _ska_city_data.has("refresh_goods_current_excess_goods"):
            _ska_city_data.refresh_goods_current_excess_goods = _ska_city_data.excess_goods

        if not _ska_city_data.has("goods_auction"):
            _ska_city_data.goods_auction = []
        if not _ska_city_data.has("money_auction"):
            _ska_city_data.money_auction = 999999
        if not _ska_city_data.has("mod_auction_refresh_time"):
            _ska_city_data.mod_auction_refresh_time = -100.0
        if not _ska_city_data.has("mod_auction_next_interval"):
            _ska_city_data.mod_auction_next_interval = 15

        if not _ska_city_data.has("mod_auction_high_goods"):
            _ska_city_data.mod_auction_high_goods = []
        if not _ska_city_data.has("mod_auction_mid_goods"):
            _ska_city_data.mod_auction_mid_goods = []
        if not _ska_city_data.has("mod_auction_low_goods"):
            _ska_city_data.mod_auction_low_goods = []
        if not _ska_city_data.has("mod_auction_refresh_day"):
            _ska_city_data.mod_auction_refresh_day = -100.0


        var _btn_list = _ska_city_data.get("button_type_list",[])
        if _btn_list.has("Auction"):
            _btn_list.erase("Auction")
            print("[MapMod] 已从button_type_list中移除无效的Auction类型")
        if not _btn_list.has("Tavern"):
            _btn_list.append("Tavern")
            print("[MapMod] 已向button_type_list中添加Tavern(拍卖行按钮)")
        _ska_city_data.button_type_list = _btn_list
        print("[MapMod] 斯卡城数据补全: specialty_grocery_positive=", _positive_dic.size(), " 项")


    var city_scene_path = "res://tscn/game/mwBuild/city/MWCity0002.tscn"
    if not ResourceLoader.exists(city_scene_path):
        print("[MapMod] 城市场景不存在: ", city_scene_path)
        return

    var city_scene = load(city_scene_path)
    var city_node = city_scene.instantiate()
    city_node.name = ISLAND_CITY_CODE
    city_node.position = ISLAND_CITY_POS

    city_node.open_economic_system = false
    city_node.trade_city_code_list = []


    city_root.add_child(city_node)


    var city_data = WSLocationData.city_data.get(ISLAND_CITY_CODE)
    if city_data:
        city_node.init(city_data)

        city_node.open_economic_system = false
        city_node.trade_city_code_list = []
        print("[MapMod] 斯卡城经济系统: open=", city_node.open_economic_system, " (已关闭, 不生成商队)")
        city_node.connect("choose", _choose_location)
        self.connect("location_light", city_node.light)
        self.connect("location_turn_off_light", city_node.turn_off_light)
        city_node.connect("mobile_drag_sign", common_camera_node.mobile_drag_event)
        city_node.connect("update_camera_zoom_sign", common_camera_node.update_zoom)

        var _tag_node = city_node.get_node_or_null("Shape/InfoRoot/HBoxRoot/LocationInfoTag")
        if _tag_node and _tag_node.has_method("update_name"):
            _tag_node.update_name("斯卡")

        _create_city_air_wall(city_node)


        city_node.need_show_section = true
        print("[MapMod] 斯卡城势力范围(Section)已启用: 默认大小")
        print("[MapMod] 斯卡城放置完成 at ", ISLAND_CITY_POS, " 名称: 斯卡")
    else:
        print("[MapMod] 错误: MWCity0009数据初始化失败")

func _create_island_territory_polygon()-> void:

    var map_root = get_node_or_null("MapRoot")
    if not map_root:
        return

    var coast_data = "3483,4250;3670,4312;3886,4441;4310,4341;4450,4344;4625,4397;4775,4529;4829,4656;4816,4752;4692,4929;4711,4985;4762,4985;4980,4799;5026,4799;5078,4857;5143,5010;5174,5244;5174,5531;5100,5838;5100,6077;5154,6227;5174,6698;5217,6744;5260,6942;5260,7112;5228,7149;5237,7303;5271,7367;5311,7614;5345,7689;5286,7737;4711,7737;4565,7630;4369,7717;4315,7706;4235,7643;4035,7674;3928,7654;3628,7674;3495,7612;3364,7641;3247,7578;3188,7476;3049,7445;2959,7484;3008,7552;2956,7598;2889,7505;2895,7419;2838,7337;2743,7380;2727,7318;2698,7301;2653,7344;2696,7245;2698,6751;2772,6539;2770,6163;2718,6059;2691,5773;2693,5347;2738,5200;2741,5099;2785,5039;2860,5052;3040,5199;3122,5334;3158,5323;3243,5105;3424,4350;3483,4251"
    var coords = coast_data.split(";")
    var points = PackedVector2Array()
    for coord in coords:
        var xy = coord.split(",")
        points.append(Vector2(int(xy[0]), int(xy[1])))

    var poly_node = Polygon2D.new()
    poly_node.name = "IslandTerritoryPolygon"

    poly_node.color = Color(1.0, 0.6, 0.2, 0.25)
    poly_node.polygon = points
    poly_node.z_index = 1
    map_root.add_child(poly_node)
    print("[MapMod] 岛屿势力范围多边形已创建")

func _create_city_air_wall(_city_node: Node2D)-> void:



    var map_root = get_node_or_null("MapRoot")
    if not map_root:
        return

    var air_wall = StaticBody2D.new()
    air_wall.name = "CityAirWall_MWCity0009"
    air_wall.position = ISLAND_CITY_POS
    air_wall.collision_layer = 1024
    air_wall.collision_mask = 0
    map_root.add_child(air_wall)

    var _wall_radius = 110.0


    var base_sprite = _city_node.get_node_or_null("Shape/Base")
    if base_sprite and base_sprite is Sprite2D and base_sprite.texture:
        var _tex_size = base_sprite.texture.get_size()
        _wall_radius = min(_tex_size.x, _tex_size.y) / 2.0 * base_sprite.scale.x
        print("[MapMod] 城市空气墙: Base贴图 tex=", _tex_size, " scale=", base_sprite.scale, " r=", _wall_radius)


    if _wall_radius < 80.0:
        var checked_box = _city_node.get_node_or_null("Shape/CheckedBox")
        if checked_box:
            for child in checked_box.get_children():
                if child is CollisionShape2D and child.shape and child.shape is CircleShape2D:
                    _wall_radius = child.shape.radius * 1.5
                    print("[MapMod] 城市空气墙: CheckedBox fallback r=", child.shape.radius, " x1.5=", _wall_radius)
                    break


    var col = CollisionShape2D.new()
    var circle = CircleShape2D.new()
    circle.radius = _wall_radius
    col.shape = circle
    air_wall.add_child(col)

    print("[MapMod] 城市空气墙创建完成: r=", _wall_radius)

func _load_map_tex(tex_path: String)-> Texture2D:
    var full_path = "res://resource/mw/" + tex_path
    if ResourceLoader.exists(full_path):
        return load(full_path)
    print("[MapMod] 纹理不存在: ", full_path)
    return null



func _place_island_trees()-> void:
    var map_root = get_node_or_null("MapRoot")
    if not map_root:
        return

    var tree_root = Node2D.new()
    tree_root.name = "NewIslandTreeRoot"
    var obj_root = get_node_or_null("ObjectRoot/MapObjectRoot")
    if obj_root:
        obj_root.add_child(tree_root)
    else:
        map_root.add_child(tree_root)


    var _buildings = [
        {"pos": ISLAND_CITY_POS, "radius": 350.0},
        {"pos": PORT_POS, "radius": 120.0},
        {"pos": ISLAND_PORT_POS, "radius": 120.0},
        {"pos": LUMBER_MILL_POS, "radius": 120.0},
        {"pos": MINE_POS, "radius": 120.0},
    ]


    var _mountain_rects = [
        [3429, 4250, 336, 112],[3429, 4362, 448, 112],[3989, 4362, 224, 112],[4102, 4362, 560, 112],
        [3429, 4474, 784, 112],[4102, 4474, 784, 112],[3429, 4586, 784, 112],[4102, 4586, 784, 112],
        [3429, 4698, 784, 112],[4102, 4698, 672, 112],[4886, 4810, 336, 112],[3317, 4922, 896, 112],
        [4102, 4922, 672, 112],[4774, 4922, 448, 112],[2756, 5034, 336, 112],[3317, 5034, 896, 112],
        [4102, 5034, 1120, 112],[2756, 5146, 448, 112],[3205, 5146, 1008, 112],[4102, 5146, 1120, 112],
        [2756, 5258, 448, 112],[3093, 5258, 1120, 112],[4102, 5258, 1120, 112],[2756, 5371, 448, 112],
        [3093, 5371, 1120, 112],[4102, 5371, 1120, 112],[2756, 5483, 448, 112],[3093, 5483, 1120, 112],
        [4102, 5483, 1120, 112],[2756, 5595, 448, 112],[3093, 5595, 336, 112],[3877, 5595, 336, 112],
        [4102, 5595, 1120, 112],[2756, 5707, 448, 112],[3093, 5707, 448, 112],[4550, 5707, 672, 112],
        [2756, 5819, 448, 112],[3093, 5819, 336, 112],[4774, 5819, 336, 112],[2756, 5931, 448, 112],
        [3093, 5931, 336, 112],[4774, 5931, 336, 112],[2756, 6043, 448, 112],[3093, 6043, 336, 112],
        [4774, 6043, 224, 112],[2868, 6155, 336, 112],[3093, 6155, 224, 112],[4662, 6155, 448, 112],
        [2868, 6267, 336, 112],[4662, 6267, 560, 112],[2868, 6380, 336, 112],[4662, 6380, 560, 112],
        [2868, 6492, 336, 112],[4662, 6492, 672, 112],[2868, 6604, 336, 112],[4662, 6604, 672, 112],
        [2980, 6716, 224, 112],[4662, 6716, 672, 112],[2980, 6828, 224, 112],[3093, 6828, 224, 112],
        [4662, 6828, 672, 112],[2980, 6940, 224, 112],[3093, 6940, 224, 112],[4662, 6940, 672, 112],
        [2980, 7052, 224, 112],[3093, 7052, 336, 112],[4774, 7052, 448, 112],[2980, 7164, 224, 112],
        [3093, 7164, 336, 112],[2868, 7276, 336, 112],[3093, 7276, 336, 112],[2980, 7389, 224, 112],
        [3093, 7389, 336, 112],
    ]

    var _coast_poly = PackedVector2Array([
        Vector2(3483, 4250), Vector2(3670, 4312), Vector2(3886, 4441), Vector2(4310, 4341),
        Vector2(4450, 4344), Vector2(4625, 4397), Vector2(4775, 4529), Vector2(4829, 4656),
        Vector2(4816, 4752), Vector2(4692, 4929), Vector2(4711, 4985), Vector2(4762, 4985),
        Vector2(4980, 4799), Vector2(5026, 4799), Vector2(5078, 4857), Vector2(5143, 5010),
        Vector2(5174, 5244), Vector2(5174, 5531), Vector2(5100, 5838), Vector2(5100, 6077),
        Vector2(5154, 6227), Vector2(5174, 6698), Vector2(5217, 6744), Vector2(5260, 6942),
        Vector2(5260, 7112), Vector2(5228, 7149), Vector2(5237, 7303), Vector2(5271, 7367),
        Vector2(5311, 7614), Vector2(5345, 7689), Vector2(5286, 7737), Vector2(4711, 7737),
        Vector2(4565, 7630), Vector2(4369, 7717), Vector2(4315, 7706), Vector2(4235, 7643),
        Vector2(4035, 7674), Vector2(3928, 7654), Vector2(3628, 7674), Vector2(3495, 7612),
        Vector2(3364, 7641), Vector2(3247, 7578), Vector2(3188, 7476), Vector2(3049, 7445),
        Vector2(2959, 7484), Vector2(3008, 7552), Vector2(2956, 7598), Vector2(2889, 7505),
        Vector2(2895, 7419), Vector2(2838, 7337), Vector2(2743, 7380), Vector2(2727, 7318),
        Vector2(2698, 7301), Vector2(2653, 7344), Vector2(2696, 7245), Vector2(2698, 6751),
        Vector2(2772, 6539), Vector2(2770, 6163), Vector2(2718, 6059), Vector2(2691, 5773),
        Vector2(2693, 5347), Vector2(2738, 5200), Vector2(2741, 5099), Vector2(2785, 5039),
        Vector2(2860, 5052), Vector2(3040, 5199), Vector2(3122, 5334), Vector2(3158, 5323),
        Vector2(3243, 5105), Vector2(3424, 4350), Vector2(3483, 4251),
    ])
    var _placed_count = 0
    var _island_data_script = load("res://gd/game/map/ModIslandData.gd")
    if not _island_data_script:
        push_error("[MapMod] ModIslandData.gd not found — trees skipped")
        return
    var _trees: Array = _island_data_script.TREES
    for tree_data in _trees:
        var _tree_pos: Vector2 = tree_data["pos"]
        var _skip = false
        for _bld in _buildings:
            if _tree_pos.distance_to(_bld["pos"]) < _bld["radius"]:
                _skip = true
                break
        if _skip:
            continue

        var _on_mtn = false
        for r in _mountain_rects:
            if _tree_pos.x >= r[0] - 50.0 and _tree_pos.x <= r[0] + r[2] + 50.0 and _tree_pos.y >= r[1] - 50.0 and _tree_pos.y <= r[1] + r[3] + 50.0:
                _on_mtn = true
                break
        if _on_mtn:
            continue

        if not Geometry2D.is_point_in_polygon(_tree_pos, _coast_poly):
            continue

        var tex = _load_map_tex("tree/" + tree_data["tex"] + ".png")
        if not tex:
            continue

        var sprite = Sprite2D.new()
        sprite.name = "NewIslandTree_" + tree_data["tex"]
        sprite.position = _tree_pos
        sprite.scale = Vector2(tree_data["scale"], tree_data["scale"])
        sprite.z_index = 5
        sprite.texture = tex
        tree_root.add_child(sprite)
        _placed_count += 1

    print("[MapMod] 岛屿树木放置完成: ", _placed_count, "/", _trees.size(), " 棵 (石山中间盆地, 避开山体/海岸/建筑)")




    _setup_island_forest_slow_zone(tree_root)






func _setup_island_forest_slow_zone(_parent_node: Node)-> void:




    var _island_data_script = load("res://gd/game/map/ModIslandData.gd")
    if not _island_data_script:
        push_error("[MapMod] ModIslandData.gd not found — forest slow zone skipped")
        return
    var _forest_rects_data: String = _island_data_script.FOREST_RECTS_DATA
    var _rects = _forest_rects_data.split(";")


    var _area = Area2D.new()
    _area.name = "IslandForestSlowZone"
    _area.collision_layer = 0
    _area.collision_mask = 2147483647
    _area.monitoring = true
    _parent_node.add_child(_area)


    var _count = 0
    for _rect_str in _rects:
        if _rect_str.strip_edges() == "":
            continue
        var _parts = _rect_str.split(",")
        if _parts.size() < 4:
            continue
        var _x = int(_parts[0])
        var _y = int(_parts[1])
        var _w = int(_parts[2])
        var _h = int(_parts[3])
        var _col_shape = CollisionShape2D.new()
        var _rect_shape = RectangleShape2D.new()
        _rect_shape.size = Vector2(_w, _h)
        _col_shape.shape = _rect_shape

        _col_shape.position = Vector2(_x + _w / 2.0, _y + _h / 2.0)
        _area.add_child(_col_shape)
        _count += 1


    _area.body_entered.connect(_on_island_forest_body_entered)
    _area.body_exited.connect(_on_island_forest_body_exited)
    print("[MapMod] 小岛森林减速带已创建: ", _count, " 个矩形, 覆盖整个小岛陆地 (排除建筑周围, speed_mult=0.7 减速30%)")



func _on_island_forest_body_entered(_body: Node2D)-> void:
    var _team: MWTeam = _body as MWTeam
    if _team == null:
        return

    _team.terrain_enter(MWorldConstants.TERRAIN_TYPE_ENUM.FOREST)

    if _body == player_team_node:
        _mod_player_on_island = true



func _on_island_forest_body_exited(_body: Node2D)-> void:
    var _team: MWTeam = _body as MWTeam
    if _team == null:
        return

    if GlobalNode.get_is_in_battle():
        return

    _team.terrain_exit(MWorldConstants.TERRAIN_TYPE_ENUM.FOREST)


    if _body == player_team_node:
        if player_team_node.global_position.y <= 4000.0:
            _mod_player_on_island = false




var _port_node: Node2D = null
var _port_select_effect: Sprite2D = null
var _port_area: Area2D = null
var _port_click_start_pos: Vector2 = Vector2.ZERO
var _port_click_duration: int = 0
var _port_is_clicking: bool = false
var _port_teleport_pending: bool = false
const PORT_POS = Vector2(930, 2940)
const PORT_TELEPORT_TARGET = Vector2(5210, 7270)


var _island_port_node: Node2D = null
var _island_port_select_effect: Sprite2D = null
var _island_port_area: Area2D = null
var _island_port_click_start_pos: Vector2 = Vector2.ZERO
var _island_port_click_duration: int = 0
var _island_port_is_clicking: bool = false
var _island_port_teleport_pending: bool = false
const ISLAND_PORT_POS = Vector2(5210, 7270)
const ISLAND_PORT_TELEPORT_TARGET = Vector2(930, 2940)

func _place_port()-> void:
    var obj_root = get_node_or_null("ObjectRoot/MapObjectRoot")
    if not obj_root:
        return

    var port_tex = _load_map_tex("mw_port.png")
    if not port_tex:
        print("[MapMod] 港口纹理加载失败")
        return


    var circle_size = 160
    var img = Image.create(circle_size, circle_size, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var circle_center = circle_size / 2.0
    var circle_radius = circle_size / 2.0 - 4
    for angle in range(0, 360, 5):
        var rad = deg_to_rad(angle)
        for r in range(int(circle_radius - 3), int(circle_radius + 1)):
            var px = int(circle_center + cos(rad) * r)
            var py = int(circle_center + sin(rad) * r)
            if px >= 0 and px < circle_size and py >= 0 and py < circle_size:
                img.set_pixel(px, py, Color(1, 0.9, 0, 0.9))
    var circle_tex = ImageTexture.create_from_image(img)


    _port_node = Node2D.new()
    _port_node.name = "PortBuilding"
    _port_node.position = PORT_POS
    _port_node.z_index = 10
    obj_root.add_child(_port_node)

    var port_sprite = Sprite2D.new()
    port_sprite.name = "Base"
    port_sprite.scale = Vector2(1.3, 1.3)
    port_sprite.flip_h = true
    port_sprite.texture = port_tex
    _port_node.add_child(port_sprite)

    _port_select_effect = Sprite2D.new()
    _port_select_effect.name = "SelectEffect"
    _port_select_effect.scale = Vector2(1.3, 1.3)
    _port_select_effect.z_index = 11
    _port_select_effect.visible = false
    _port_select_effect.texture = circle_tex
    _port_node.add_child(_port_select_effect)

    _port_area = Area2D.new()
    _port_area.name = "PortClickArea"
    _port_area.position = PORT_POS
    _port_area.z_index = 10
    _port_area.collision_layer = 2048
    _port_area.collision_mask = 0
    _port_area.input_pickable = true
    obj_root.add_child(_port_area)

    var col_shape = CircleShape2D.new()
    col_shape.radius = 78.0
    var col_node = CollisionShape2D.new()
    col_node.shape = col_shape
    _port_area.add_child(col_node)

    _port_area.input_event.connect(_on_port_input_event)


    var map_root_p = get_node_or_null("MapRoot")
    if map_root_p:
        var port_body = StaticBody2D.new()
        port_body.name = "PortPhysicsBody"
        port_body.position = PORT_POS
        port_body.collision_layer = 4096
        port_body.collision_mask = 0
        map_root_p.add_child(port_body)
        var port_body_col = CollisionShape2D.new()
        var port_body_shape = CircleShape2D.new()
        port_body_shape.radius = 50.0
        port_body_col.shape = port_body_shape
        port_body.add_child(port_body_col)

    print("[MapMod] 主大陆港口放置完成 at ", PORT_POS)


    _island_port_node = Node2D.new()
    _island_port_node.name = "IslandPortBuilding"
    _island_port_node.position = ISLAND_PORT_POS
    _island_port_node.z_index = 10
    obj_root.add_child(_island_port_node)

    var island_port_sprite = Sprite2D.new()
    island_port_sprite.name = "Base"
    island_port_sprite.scale = Vector2(1.3, 1.3)
    island_port_sprite.texture = port_tex
    _island_port_node.add_child(island_port_sprite)

    _island_port_select_effect = Sprite2D.new()
    _island_port_select_effect.name = "SelectEffect"
    _island_port_select_effect.scale = Vector2(1.3, 1.3)
    _island_port_select_effect.z_index = 11
    _island_port_select_effect.visible = false
    _island_port_select_effect.texture = circle_tex
    _island_port_node.add_child(_island_port_select_effect)

    _island_port_area = Area2D.new()
    _island_port_area.name = "IslandPortClickArea"
    _island_port_area.position = ISLAND_PORT_POS
    _island_port_area.z_index = 10
    _island_port_area.collision_layer = 2048
    _island_port_area.collision_mask = 0
    _island_port_area.input_pickable = true
    obj_root.add_child(_island_port_area)

    var island_col_shape = CircleShape2D.new()
    island_col_shape.radius = 78.0
    var island_col_node = CollisionShape2D.new()
    island_col_node.shape = island_col_shape
    _island_port_area.add_child(island_col_node)

    _island_port_area.input_event.connect(_on_island_port_input_event)


    var map_root_ip = get_node_or_null("MapRoot")
    if map_root_ip:
        var island_port_body = StaticBody2D.new()
        island_port_body.name = "IslandPortPhysicsBody"
        island_port_body.position = ISLAND_PORT_POS
        island_port_body.collision_layer = 4096
        island_port_body.collision_mask = 0
        map_root_ip.add_child(island_port_body)
        var island_port_body_col = CollisionShape2D.new()
        var island_port_body_shape = CircleShape2D.new()
        island_port_body_shape.radius = 50.0
        island_port_body_col.shape = island_port_body_shape
        island_port_body.add_child(island_port_body_col)

    print("[MapMod] 岛屿港口放置完成 at ", ISLAND_PORT_POS)

func _on_port_input_event(_viewport, event, _shape_idx):
    if event is InputEventScreenTouch:
        if event.pressed:
            _port_is_clicking = true
            _port_click_start_pos = event.position
            _port_click_duration = 0
        else:
            if _port_is_clicking:
                var dist =(event.position - _port_click_start_pos).length_squared()
                if dist < MobileConfig.CLICK_DISTANCE_MAX_SQUARE and _port_click_duration < MobileConfig.CLICK_TOUCH_DURATION_COUNTER:
                    _on_port_clicked()
            _port_is_clicking = false
    elif event is InputEventMouseButton:
        if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
            _on_port_clicked()

func _on_island_port_input_event(_viewport, event, _shape_idx):
    if event is InputEventScreenTouch:
        if event.pressed:
            _island_port_is_clicking = true
            _island_port_click_start_pos = event.position
            _island_port_click_duration = 0
        else:
            if _island_port_is_clicking:
                var dist =(event.position - _island_port_click_start_pos).length_squared()
                if dist < MobileConfig.CLICK_DISTANCE_MAX_SQUARE and _island_port_click_duration < MobileConfig.CLICK_TOUCH_DURATION_COUNTER:
                    _on_island_port_clicked()
            _island_port_is_clicking = false
    elif event is InputEventMouseButton:
        if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
            _on_island_port_clicked()

func _on_port_clicked():

    if _mod_typhoon_active:
        _mod_msg("台风肆虐,港口已封锁!", 3.0, false)
        return
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)
    _cancel_choose_location()
    _cancel_choose_team()
    if _port_select_effect:
        _port_select_effect.visible = true
    _click_effect(PORT_POS)
    _port_teleport_pending = true
    _player_move(PORT_POS)
    print("[MapMod] 主大陆港口选中")

func _on_island_port_clicked():

    if _mod_typhoon_active:
        _mod_msg("台风肆虐,港口已封锁!", 3.0, false)
        return
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)
    _cancel_choose_location()
    _cancel_choose_team()
    if _island_port_select_effect:
        _island_port_select_effect.visible = true
    _click_effect(ISLAND_PORT_POS)
    _island_port_teleport_pending = true
    _player_move(ISLAND_PORT_POS)
    print("[MapMod] 岛屿港口选中")

var _port_immunity_timer: Timer = null

func _start_port_collision_immunity():


    player_team_node.collision_mask = 1025
    if _port_immunity_timer and is_instance_valid(_port_immunity_timer):
        _port_immunity_timer.stop()
    else:
        _port_immunity_timer = Timer.new()
        _port_immunity_timer.one_shot = true
        _port_immunity_timer.timeout.connect(_end_port_collision_immunity)
        add_child(_port_immunity_timer)
    _port_immunity_timer.wait_time = 6.0
    _port_immunity_timer.start()
    print("[MapMod] 港口碰撞免疫6秒开始")

func _end_port_collision_immunity():

    if is_instance_valid(player_team_node):
        player_team_node.collision_mask = 5121
        print("[MapMod] 港口碰撞免疫结束, 恢复碰撞")

func _hide_port_select():
    if _port_select_effect and is_instance_valid(_port_select_effect):
        _port_select_effect.visible = false
    if _island_port_select_effect and is_instance_valid(_island_port_select_effect):
        _island_port_select_effect.visible = false

func _check_port_teleport():

    if _port_teleport_pending and is_instance_valid(player_team_node):
        var dist = player_team_node.global_position.distance_to(PORT_POS)
        if dist < 100:
            _port_teleport_pending = false
            _hide_port_select()
            var nav_agent = player_team_node.get_node_or_null("NavigationAgent2D")

            player_team_node.collision_mask = 1025
            player_team_node.global_position = PORT_TELEPORT_TARGET
            player_team_node.change_status_to_idle()
            if nav_agent:
                nav_agent.target_position = player_team_node.global_position
            _start_port_collision_immunity()
            _mod_player_on_island = true
            print("[MapMod] 主大陆→岛屿传送完成！位置: ", player_team_node.global_position)


    if _island_port_teleport_pending and is_instance_valid(player_team_node):
        var dist2 = player_team_node.global_position.distance_to(ISLAND_PORT_POS)
        if dist2 < 100:
            _island_port_teleport_pending = false
            _hide_port_select()
            var nav_agent2 = player_team_node.get_node_or_null("NavigationAgent2D")

            player_team_node.collision_mask = 1025
            player_team_node.global_position = ISLAND_PORT_TELEPORT_TARGET
            player_team_node.change_status_to_idle()
            if nav_agent2:
                nav_agent2.target_position = player_team_node.global_position
            _start_port_collision_immunity()
            _mod_player_on_island = false
            print("[MapMod] 岛屿→主大陆传送完成！位置: ", player_team_node.global_position)



const LUMBER_MILL_POS = Vector2(3980, 6920)
var _lumber_mill_node: Node2D = null
var _lumber_mill_select_effect: Sprite2D = null
var _lumber_mill_area: Area2D = null
var _lumber_mill_click_start_pos: Vector2 = Vector2.ZERO
var _lumber_mill_click_duration: int = 0
var _lumber_mill_is_clicking: bool = false
var _lumber_mill_pending: bool = false

func _place_lumber_mill()-> void:
    var obj_root = get_node_or_null("ObjectRoot/MapObjectRoot")
    if not obj_root:
        print("[MapMod] MapObjectRoot不存在, 无法放置砍木场")
        return

    var existing = obj_root.get_node_or_null("LumberMillBuilding")
    if existing:
        existing.free()

    var tex = _load_map_tex("localtion/specialLocation/special_location_0005.png")
    if not tex:
        print("[MapMod] 砍木场贴图加载失败")
        return


    var circle_size = 160
    var img = Image.create(circle_size, circle_size, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var circle_center = circle_size / 2.0
    var circle_radius = circle_size / 2.0 - 4
    for angle in range(0, 360, 5):
        var rad = deg_to_rad(angle)
        for r in range(int(circle_radius - 3), int(circle_radius + 1)):
            var px = int(circle_center + cos(rad) * r)
            var py = int(circle_center + sin(rad) * r)
            if px >= 0 and px < circle_size and py >= 0 and py < circle_size:
                img.set_pixel(px, py, Color(1, 0.9, 0, 0.9))
    var circle_tex = ImageTexture.create_from_image(img)


    _lumber_mill_node = Node2D.new()
    _lumber_mill_node.name = "LumberMillBuilding"
    _lumber_mill_node.position = LUMBER_MILL_POS
    _lumber_mill_node.z_index = 10
    obj_root.add_child(_lumber_mill_node)


    var mill_sprite = Sprite2D.new()
    mill_sprite.name = "Base"
    mill_sprite.texture = tex
    mill_sprite.scale = Vector2(0.6, 0.6)
    _lumber_mill_node.add_child(mill_sprite)


    _lumber_mill_select_effect = Sprite2D.new()
    _lumber_mill_select_effect.name = "SelectEffect"
    _lumber_mill_select_effect.scale = Vector2(0.8, 0.8)
    _lumber_mill_select_effect.z_index = 11
    _lumber_mill_select_effect.visible = false
    _lumber_mill_select_effect.texture = circle_tex
    _lumber_mill_node.add_child(_lumber_mill_select_effect)


    _lumber_mill_area = Area2D.new()
    _lumber_mill_area.name = "LumberMillClickArea"
    _lumber_mill_area.position = LUMBER_MILL_POS
    _lumber_mill_area.z_index = 10
    _lumber_mill_area.collision_layer = 2048
    _lumber_mill_area.collision_mask = 0
    _lumber_mill_area.input_pickable = true
    obj_root.add_child(_lumber_mill_area)

    var col_shape = CircleShape2D.new()
    col_shape.radius = 80.0
    var col_node = CollisionShape2D.new()
    col_node.shape = col_shape
    _lumber_mill_area.add_child(col_node)

    _lumber_mill_area.input_event.connect(_on_lumber_mill_input_event)


    var map_root_lm = get_node_or_null("MapRoot")
    if map_root_lm:
        var mill_body = StaticBody2D.new()
        mill_body.name = "LumberMillPhysicsBody"
        mill_body.position = LUMBER_MILL_POS
        mill_body.collision_layer = 4096
        mill_body.collision_mask = 0
        map_root_lm.add_child(mill_body)
        var mill_body_col = CollisionShape2D.new()
        var mill_body_shape = CircleShape2D.new()
        mill_body_shape.radius = 50.0
        mill_body_col.shape = mill_body_shape
        mill_body.add_child(mill_body_col)

    print("[MapMod] 砍木场放置完成 at ", LUMBER_MILL_POS)

func _on_lumber_mill_input_event(_viewport, event, _shape_idx):
    if event is InputEventScreenTouch:
        if event.pressed:
            _lumber_mill_is_clicking = true
            _lumber_mill_click_start_pos = event.position
            _lumber_mill_click_duration = 0
        else:
            if _lumber_mill_is_clicking:
                var dist =(event.position - _lumber_mill_click_start_pos).length_squared()
                if dist < MobileConfig.CLICK_DISTANCE_MAX_SQUARE and _lumber_mill_click_duration < MobileConfig.CLICK_TOUCH_DURATION_COUNTER:
                    _on_lumber_mill_clicked()
            _lumber_mill_is_clicking = false
    elif event is InputEventMouseButton:
        if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
            _on_lumber_mill_clicked()

func _on_lumber_mill_clicked():
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)
    _cancel_choose_location()
    _cancel_choose_team()
    if _lumber_mill_select_effect:
        _lumber_mill_select_effect.visible = true
    _click_effect(LUMBER_MILL_POS)
    _lumber_mill_pending = true
    _player_move(LUMBER_MILL_POS)
    print("[MapMod] 砍木场选中")

func _hide_lumber_mill_select():
    if _lumber_mill_select_effect and is_instance_valid(_lumber_mill_select_effect):
        _lumber_mill_select_effect.visible = false

func _check_lumber_mill_arrival():
    if _lumber_mill_pending and is_instance_valid(player_team_node):
        var dist = player_team_node.global_position.distance_to(LUMBER_MILL_POS)
        if dist < 100:
            _lumber_mill_pending = false
            _hide_lumber_mill_select()
            _start_port_collision_immunity()
            _open_lumber_mill_interface()

func _open_lumber_mill_interface():


    if mod_lumber_mill_interface_node == null:
        var _script = load("res://gd/game/mwBuild/specialBuild/ModLumberMillInterface.gd")
        if _script == null:
            _mod_msg("伐木场面板加载失败(MOD文件缺失)", 3.0, false)
            print("[MapMod] WARNING: ModLumberMillInterface.gd 加载失败")
            return
        mod_lumber_mill_interface_node = Control.new()
        mod_lumber_mill_interface_node.set_script(_script)
        mod_lumber_mill_interface_node.connect("close_page_sign", _on_mod_lumber_mill_panel_close)
        mod_lumber_mill_interface_node.connect("manage_workers_sign", _on_mod_lumber_mill_panel_manage_workers)
        mod_lumber_mill_interface_node.connect("manage_food_sign", _on_mod_lumber_mill_panel_manage_food)

        mod_lumber_mill_interface_node.connect("take_wood_confirm_sign", _on_mod_lumber_mill_panel_take_wood_confirm)
        mod_lumber_mill_interface_node.connect("supply_tools_sign", _on_mod_lumber_mill_panel_supply_tools)
        mod_lumber_mill_interface_node.connect("talk_manager_sign", _on_mod_lumber_mill_panel_talk_manager)
        canvas_layer_node.add_child(mod_lumber_mill_interface_node)
    mod_lumber_mill_interface_node.show_interface()
    _mod_lumber_mill_refresh_panel()
    print("[MapMod] 伐木场经营面板已打开")


func _mod_lumber_mill_refresh_panel()-> void:
    if mod_lumber_mill_interface_node == null:
        return
    if not _mod_lumber_mill_is_available():
        mod_lumber_mill_interface_node.update_status({
            "idle": true,
            "idle_hint": "伐木场空闲\n可租用(2000金/天起)\n或购买(90万金币永久拥有)",
        }, "")
        return

    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    var _guide_count: int = 0
    var _star_count: Dictionary = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for _worker in _mod_lumber_mill_workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        elif bool(_worker.get("is_guide", false)):
            _guide_count += 1
        else:
            _soldier_count += 1
            var _star: int = _mod_worker_star(_worker)
            if _star_count.has(_star):
                _star_count[_star] += 1
            else:
                _star_count[1] += 1

    var _warnings: Array = []
    if _mod_lumber_mill_tool_durability <= 0.0:
        _warnings.append("工具已损坏,工人无法产出 → 点「补给工具」")
    elif _mod_lumber_mill_tool_durability < 20.0:
        _warnings.append("工具耐久不足 → 建议点「补给工具」")
    if _mod_lumber_mill_food_depleted:
        _warnings.append("粮食耗尽,士气大降 → 点「管理粮库」")
    else:

        var _daily_food_chk: int = _mod_lumber_mill_calc_daily_food()
        if _daily_food_chk > 0 and _mod_get_edible_food_points(_mod_lumber_mill_food) < _daily_food_chk * 3:
            _warnings.append("存粮不足3天 → 点「管理粮库」")
    if _mod_lumber_mill_morale < 30.0:
        _warnings.append("士气低落!产出-30%,走失+50%")
    if not _mod_lumber_mill_owned:
        var _rent_chk: int = int(_mod_lumber_mill_rent_end_day - WSData.system_counter)
        if _rent_chk <= 3:
            _warnings.append("租期仅剩" + str(_rent_chk) + "天!到期工人解散 → 点「与管理员对话」")

    var _daily_wood: int = int(_mod_lumber_mill_calc_daily_wood())
    var _daily_food: int = _mod_lumber_mill_calc_daily_food()
    var _food_pts: int = _mod_get_edible_food_points(_mod_lumber_mill_food)
    var _food_days: int = 99999
    if _daily_food > 0:
        _food_days = int(_food_pts / _daily_food)
    var _stats: Array = [
        {"k": "工人", "v": str(_mod_lumber_mill_workers.size()) + "/" + str(_mod_lumber_mill_capacity), "c": "white"},
        {"k": "构成", "v": "兵" + str(_soldier_count) + " · 俘" + str(_prisoner_count) + " · 导" + str(_guide_count), "c": "dim"},
        {"k": "木材存量", "v": str(int(_mod_lumber_mill_wood)) + "个", "c": "white"},
    ]
    if _mod_typhoon_active:
        _stats.append({"k": "预计日产", "v": "0(台风停工)", "c": "red"})
    else:
        _stats.append({"k": "预计日产", "v": str(_daily_wood) + "木/天", "c": "green"})

    var _food_pts_txt: String = _mod_format_points(_food_pts) + "点"
    if _food_days >= 9999:
        _stats.append({"k": "粮库", "v": _food_pts_txt, "c": "dim"})
    elif _food_days <= 2:
        _stats.append({"k": "粮库", "v": _food_pts_txt + " · 够" + str(_food_days) + "天", "c": "red"})
    else:
        _stats.append({"k": "粮库", "v": _food_pts_txt + " · 够" + str(_food_days) + "天", "c": "white"})
    if _mod_lumber_mill_owned:
        _stats.append({"k": "产权", "v": "永久拥有", "c": "blue"})
    else:
        var _days_left: int = int(_mod_lumber_mill_rent_end_day - WSData.system_counter)
        var _rent_c: String = "red" if _days_left <= 3 else "white"
        _stats.append({"k": "租期剩余", "v": str(_days_left) + "天", "c": _rent_c})

    var _bars: Array = [
        {"label": "林木蓄积", "value": _mod_lumber_mill_forest_stock, "max": 7000.0, "text": str(int(_mod_lumber_mill_forest_stock)) + "/7000 · 日+" + str(int(_mod_lumber_mill_get_daily_forest_regen()))},
        {"label": "工具耐久", "value": _mod_lumber_mill_tool_durability, "max": 100.0, "text": str(int(_mod_lumber_mill_tool_durability)) + "/100"},
        {"label": "士气", "value": _mod_lumber_mill_morale, "max": 100.0, "text": str(int(_mod_lumber_mill_morale)) + "/100"},
    ]

    var _chips: Array = []
    var _weather_mod: float = _mod_lumber_mill_get_weather_modifier()
    if _mod_typhoon_active:
        _chips.append({"text": "台风停工", "c": "red"})
    elif _weather_mod >= 1.1:
        _chips.append({"text": "晴天+10%", "c": "green"})
    elif _weather_mod <= 0.3:
        _chips.append({"text": "暴雨-70%", "c": "yellow"})
    elif _weather_mod <= 0.5:
        _chips.append({"text": "雨天-50%", "c": "yellow"})
    else:
        _chips.append({"text": "天气正常", "c": "dim"})
    var _intim: Dictionary = _mod_lumber_mill_get_intimidation_info()
    if int(_intim.get("prisoners", 0)) <= 0:
        _chips.append({"text": "无俘虏", "c": "dim"})
    elif int(_intim.get("level", 0)) >= 2:
        _chips.append({"text": "威慑满·俘虏不敢逃", "c": "green"})
    elif int(_intim.get("level", 0)) == 1:
        _chips.append({"text": "威慑强·逃跑-75%", "c": "green"})
    else:
        _chips.append({"text": "威慑不足·俘虏易逃", "c": "yellow"})


    var _worker_total_v9: int = _mod_lumber_mill_workers.size()
    var _guide_req_v9: int = ceili(float(_worker_total_v9) / float(MOD_LUMBER_MILL_GUIDE_COVER_PER))
    var _guide_cov_v9: float = clampf(float(_guide_count) / float(maxi(_guide_req_v9, 1)), 0.0, 1.0)
    if _worker_total_v9 <= 40:

        if _guide_count > 0:
            _chips.append({"text": "引路" + str(_guide_count) + "/" + str(_guide_req_v9) + " · 41人起生效", "c": "dim"})
    else:
        var _cov_rate_txt: String = "%.1f" %(_mod_lumber_mill_get_lost_rate(_guide_count, _worker_total_v9) * 100.0)
        var _typhoon_tag: String = "(台风)" if _mod_typhoon_active else ""
        if _guide_cov_v9 >= 1.0:
            _chips.append({"text": "引路满 " + str(_guide_count) + "/" + str(_guide_req_v9) + " · 走失" + _cov_rate_txt + "%" + _typhoon_tag, "c": "green"})
        else:
            _chips.append({"text": "引路 " + str(_guide_count) + "/" + str(_guide_req_v9) + " · 覆盖" + str(int(_guide_cov_v9 * 100.0)) + "% 走失" + _cov_rate_txt + "%" + _typhoon_tag, "c": "blue"})



    var _intim_v8: Dictionary = _mod_lumber_mill_get_intimidation_info(_mod_lumber_mill_food_depleted)
    var _intim_lvl: int = int(_intim_v8.get("level", 0))
    var _prisoner_cnt: int = int(_intim_v8.get("prisoners", 0))
    var _intim_eff: float = float(_intim_v8.get("intim_effective", 0.0))
    var _intim_ratio_v15: float = float(_intim_v8.get("ratio", 0.0))
    var _req_full_v9: int = int(_intim_v8.get("req_full", 0))
    var _intim_c: String = "red"
    var _intim_text: String = "无俘虏"
    if _prisoner_cnt <= 0:
        _intim_c = "dim"
    elif _intim_ratio_v15 >= 1.0:
        _intim_c = "green"
        _intim_text = "镇压" + str(int(_intim_eff)) + "/" + str(_req_full_v9) + " 满额 · 俘虏不逃"
    else:
        _intim_c = "yellow" if _intim_lvl == 1 else "red"
        var _need_v15: int = maxi(_req_full_v9 - int(_intim_eff), 0)
        _intim_text = "镇压" + str(int(_intim_eff)) + "/" + str(_req_full_v9) + " · 抵扣" + str(int(_intim_ratio_v15 * 100.0)) + "%逃跑 · 差" + str(_need_v15) + "点" + _mod_intim_soldier_hint(_need_v15)

    if _prisoner_cnt > 0 and _mod_lumber_mill_food_depleted:
        _intim_text += " [缺粮镇压减半]"




    var _risk: float = 0.08 if _mod_lumber_mill_food_depleted else 0.02
    if _prisoner_cnt <= 0:
        _risk = 0.0
    else:
        _risk = _mod_escape_rate_after_suppression(_risk, _intim_ratio_v15)
    if _mod_lumber_mill_morale < 30.0 and _risk > 0.0:
        _risk *= 1.5
    if _worker_total_v9 > 40:
        var _lost_rate_v8: float = _mod_lumber_mill_get_lost_rate(int(_intim_v8.get("guides", 0)), _worker_total_v9)
        if _mod_lumber_mill_morale < 30.0:
            _lost_rate_v8 *= 1.5
        _risk += _lost_rate_v8
    _risk = clampf(_risk, 0.0, 0.18)
    var _safety: float =(0.18 - _risk) / 0.18 * 100.0
    var _safety_text: String = "无俘虏 · 无逃跑/走失风险"
    if _prisoner_cnt > 0:
        _safety_text = "引路" + str(_guide_count) + "/" + str(_guide_req_v9) + " · 俘虏日损率" + "%.1f" %(_risk * 100.0) + "% · 安全度" + str(int(_safety)) + "%"
    var _sliders: Array = [
        {"label": "镇压值", "value":(_intim_eff if _prisoner_cnt > 0 else 0.0), "max": maxf(float(_req_full_v9), 1.0), "text": _intim_text, "c": _intim_c},
        {"label": "防走失", "value": _safety, "max": 100.0, "text": _safety_text},
    ]

    var _detail: String = "1星" + str(_star_count[1]) + " · 2星" + str(_star_count[2]) + " · 3星" + str(_star_count[3]) + " · 4星" + str(_star_count[4]) + " · 5星" + str(_star_count[5])
    _detail += "\n日耗" + _mod_format_points(_daily_food) + "点粮/天 · 稀有木材每40木出1 · 补工具50金/次"
    _detail += "\n镇压规则: 士兵镇压值vs俘虏被镇压值同表(1/2/3/5/8), 比例即抵扣(7/10抵扣70%逃跑, 10/10不逃); 缺粮减半"
    _detail += "\n引路规则: 每" + str(MOD_LUMBER_MILL_GUIDE_COVER_PER) + "人需1名向导, 满覆盖俘虏走失2%→0.1%"
    mod_lumber_mill_interface_node.update_status({
        "warnings": _warnings,
        "stats": _stats,
        "bars": _bars,
        "sliders": _sliders,
        "chips": _chips,
        "detail": _detail,

        "wood_stock": _mod_lumber_mill_wood,
    }, "")


func _on_mod_lumber_mill_panel_close()-> void:
    if mod_lumber_mill_interface_node:
        mod_lumber_mill_interface_node.hide_interface()
    print("[MapMod] 伐木场经营面板已关闭")


func _on_mod_lumber_mill_panel_manage_workers()-> void:
    if mod_lumber_mill_interface_node:
        mod_lumber_mill_interface_node.hide_interface()
    _mod_lumber_mill_show_manage_workers_dialog()


func _on_mod_lumber_mill_panel_manage_food()-> void:
    if mod_lumber_mill_interface_node:
        mod_lumber_mill_interface_node.hide_interface()
    _mod_lumber_mill_show_manage_food_dialog()



func _on_mod_lumber_mill_panel_take_wood_confirm(_ratio: float)-> void:
    print("[MapMod][伐木场] 面板滑动条取出木材: ratio=", _ratio)
    _mod_lumber_mill_take_wood(clampf(_ratio, 0.0, 1.0))


func _on_mod_lumber_mill_panel_supply_tools()-> void:
    if mod_lumber_mill_interface_node:
        mod_lumber_mill_interface_node.hide_interface()
    _mod_lumber_mill_show_supply_tools_dialog()


func _on_mod_lumber_mill_panel_talk_manager()-> void:
    print("[MapMod][伐木场] 面板按钮: 与管理员对话")
    if mod_lumber_mill_interface_node:
        mod_lumber_mill_interface_node.hide_interface()
    _mod_lumber_mill_show_manager_dialog()



func _mod_lumber_mill_return_to_main()-> void:
    if mod_lumber_mill_interface_node != null and is_instance_valid(mod_lumber_mill_interface_node):

        mod_lumber_mill_interface_node.show_interface()
        _mod_lumber_mill_refresh_panel()
    else:

        _mod_lumber_mill_show_manager_dialog()





func _mod_lumber_mill_show_manager_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _greeting_msg: String = _mod_lumber_mill_get_status_msg()
    var _option_list: Array = []

    if not _mod_lumber_mill_is_available():
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用伐木场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想租用伐木场。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "购买伐木场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想购买伐木场。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "了解伐木场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想了解一下伐木场怎么运作。"]}]})
    else:

        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "管理工人", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要管理伐木场的工人。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "管理粮库", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要管理粮库。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "查看状态", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["让我看看伐木场的状态。"]}]})
        if not _mod_lumber_mill_owned:
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "购买伐木场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想购买伐木场。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE, "oname": "告辞", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["告辞。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_greeting_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }

    if not is_instance_valid(dialogue_interface_node):
        print("[MapMod][伐木场] 管理员对话失败: dialogue_interface_node 无效")
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_return_to_main()
        return
    var _left_info: Dictionary = {}
    var _ptn = WSData.get_player_team_node()
    if _ptn != null and is_instance_valid(_ptn):
        _left_info = _ptn.get_dialogue_info()
    else:
        print("[MapMod][伐木场] 警告: 玩家队伍节点无效, 用空信息打开对话")
    print("[MapMod][伐木场] 打开管理员对话: 选项数=", _option_list.size())
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(_left_info, _right_info)
    dialogue_interface_node.init(_greeting, _left_info, _right_info)
    print("[MapMod][伐木场] 管理员对话已初始化")


func _mod_lumber_mill_is_available()-> bool:
    if _mod_lumber_mill_owned:
        return true
    if _mod_lumber_mill_rent_end_day > 0.0 and WSData.system_counter < _mod_lumber_mill_rent_end_day:
        return true
    return false


func _mod_lumber_mill_get_status_msg()-> String:
    if not _mod_lumber_mill_is_available():
        return "伐木场空闲\n可租用/购买"

    var _intim: Dictionary = _mod_lumber_mill_get_intimidation_info(_mod_lumber_mill_food_depleted)

    var _msg: String = "工人" + str(_mod_lumber_mill_workers.size()) + "(导" + str(_intim.get("guides", 0)) + ")/" + str(_mod_lumber_mill_capacity)
    _msg += " 木" + str(int(_mod_lumber_mill_wood))
    _msg += " 粮" + _mod_format_points(_mod_get_edible_food_points(_mod_lumber_mill_food)) + "点"
    _msg += "\n蓄积" + str(int(_mod_lumber_mill_forest_stock)) + "/7000"
    _msg += " 工具" + str(int(_mod_lumber_mill_tool_durability)) + "/100"
    _msg += " 士气" + str(int(_mod_lumber_mill_morale)) + "/100"

    var _weather_mod: float = _mod_lumber_mill_get_weather_modifier()
    var _weather_text: String = ""
    if _mod_typhoon_active:
        _weather_text = "台风停工"
    elif _weather_mod >= 1.1:
        _weather_text = "晴+10%"
    elif _weather_mod <= 0.3:
        _weather_text = "暴雨-70%"
    elif _weather_mod <= 0.5:
        _weather_text = "雨-50%"
    else:
        _weather_text = "正常"

    var _intim_text: String = "-"
    if _intim.get("prisoners", 0) > 0:
        var _ratio_v15: float = float(_intim.get("ratio", 0.0))
        if _ratio_v15 >= 1.0:
            _intim_text = "满额" + str(int(_intim.get("intim_effective", 0))) + "/" + str(int(_intim.get("req_full", 0))) + "(不逃)"
        else:
            _intim_text = "镇" + str(int(_intim.get("intim_effective", 0))) + "/" + str(int(_intim.get("req_full", 0))) + "·抵扣" + str(int(_ratio_v15 * 100.0)) + "%"
        if _mod_lumber_mill_food_depleted:
            _intim_text += "[缺粮减半]"
    _msg += "\n天气:" + _weather_text + " 镇压:" + _intim_text

    if _mod_lumber_mill_tool_durability <= 0.0:
        _msg += " [工具坏!]"
    elif _mod_lumber_mill_tool_durability < 20.0:
        _msg += " [工具低]"
    if _mod_lumber_mill_morale < 30.0:
        _msg += " [士气低!]"
    if _mod_lumber_mill_food_depleted:
        _msg += " [缺粮!]"
    if _mod_lumber_mill_owned:
        _msg += " 已拥有"
    else:
        var _days_left: int = int(_mod_lumber_mill_rent_end_day - WSData.system_counter)
        _msg += " 租期" + str(_days_left) + "天"
    return _msg


func _mod_lumber_mill_get_food_total()-> int:
    var _total: int = 0
    for _food_entry in _mod_lumber_mill_food:
        _total += int(_food_entry.get("count", 0))
    return _total


func _mod_lumber_mill_show_rent_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用1天(2000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用1天,容量30人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用7天(18000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用7天,容量80人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用30天(80000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用30天,容量150人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用90天(180000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用90天,容量220人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": ["租用价格(长期投入才有回报):\n1天2000金(30人) 7天18000金(80人)\n30天80000金(150人)\n90天180000金(220人)"]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_show_tutorial_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0

    var _tutorial_content: Array = [
        {"clist": ["【伐木场是什么】", "伐木场可以安排士兵和俘虏砍树产出木材。", "产出的木材存放在伐木场, 你可以随时取出, 卖给杂货铺换金币。", "想用伐木场, 先花金币租用或购买, 然后分配工人进去。"]},
        {"clist": ["【怎么开始用】", "第一步: 租用或购买伐木场。", "  租用按天收费, 容量有限; 购买一次付清, 永久拥有。", "  对话里选「租用伐木场」或「购买伐木场」即可。"]},
        {"clist": ["【运作优先级 (最重要!)】", "伐木场每天自动结算, 按以下顺序检查:", "1. 有没有工人? 没工人就不产出。", "2. 粮食够不够? 粮食耗尽工人会逃跑!", "3. 工具耐久够不够? 耐久低产出减半。", "4. 林木蓄积够不够? 蓄积耗尽当天0产出。", "5. 以上都满足, 才会正常产出木材。", "记住: 粮食 > 工具 > 蓄积, 这是维持运作的优先级!"]},
        {"clist": ["【必须做的三件事】", "1. 分配工人: 选「管理工人」把士兵/俘虏放进去。", "   俘虏也能砍树, 是不错的劳动力。", "2. 存粮食: 选「管理粮库」放入食物。", "   士兵和俘虏每天都要吃饭, 不喂会逃跑!", "3. 补给工具: 选「补给工具」放入工具。", "   工具每天消耗耐久, 耐久低了产出减半。", "这三件事不做, 伐木场就转不起来。"]},
        {"clist": ["【怎么赚钱】", "工人每天自动砍树, 木材存进伐木场。", "选「取出木材」把木材拿到背包。", "然后去杂货铺把木材卖掉换金币。", "木材分普通和稀有两种, 稀有木材卖价更高。", "记住: 砍出来的木材不会自动卖, 要自己取出自己卖!", "注意: 安排士兵到伐木场军饷比随行多20%, 俘虏不收军饷。"]},
        {"clist": ["【林木蓄积】", "岛上的树是有限的, 砍多了会变少。", "蓄积就是剩余的林木量, 每天都会自动恢复。", "蓄积越高恢复越快, 并保底每天至少恢复70。", "就算一次性砍到0, 树林也会慢慢长回来。", "蓄积耗尽当天产不出木头, 等恢复后再继续。"]},
        {"clist": ["【工人会逃跑和走失】", "逃跑: 粮食耗尽时才发生, 高星级士兵不会逃。", "  俘虏不管饿不饿都有可能逃, 要留意。", "走失: 工人超过40人时可能走失, 任何工人都会。", "  台风天走失概率大幅增加, 要特别注意。", "逃跑的士兵会回队伍, 走失的也是; 俘虏则直接没了。", "【镇压机制】", "士兵有「镇压值」, 俘虏有「被镇压值」, 同一张表:", "  1星=1点 / 2星=2点 / 3星=3点 / 4星=5点 / 5星=8点。", "镇压按比例抵扣俘虏逃跑率, 派多少有效多少:", "  镇压值1/10 → 抵扣10%逃跑率。", "  镇压值7/10 → 抵扣70%逃跑率。", "  镇压值10/10 → 抵扣100%, 俘虏完全不逃!", "例: 10个1星俘被镇压值=10, 基础逃跑率2%/天:", "  派7个1星兵(7点) → 逃跑率2%×0.3=0.6%/天。", "  派满10点 → 逃跑率归零, 一个都不逃。", "高星兵更顶用: 1名5星兵(8点)抵扣8个1星俘的80%。", "高星俘更难缠: 1个3星俘占3点被镇压值。", "注意: 缺粮时镇压值减半, 抵扣也跟着减半。", "【向导机制】", "管理工人里可把4-5星士兵指派为向导。", "向导占工人位但不砍树, 专职带路。", "引路需求与总人数成正比: 每20人只需1名向导。", "人数≤40不会走失, 此时不需向导; 41人起引路才生效。", "例: 40人需2名 / 100人需5名 / 300人满编也只需15名。", "覆盖率=向导数÷需求数, 满覆盖走失率2%→0.1%。", "向导照常提供镇压值(按星级), 派了不吃亏。", "不足时按比例减免, 派1名就有1名的效果。", "士兵走失会回队伍, 向导只保护俘虏。", "向导自己识路, 永远不会走失。"]},
        {"clist": ["【台风的影响】", "台风天伐木场停工, 当天产不出木头。", "台风结束会损失一些金币和食物。", "台风天工人走失概率暴增。", "台风来之前建议: 存足粮食, 忍耐过去就好。"]},
        {"clist": ["【士气很重要】", "粮食充足、工具耐久高, 士气就高。", "士气低落时: 产出下降, 逃跑和走失概率增加。", "保持粮食和工具充足, 士气自然就稳住了。"]},
        {"clist": ["【日常操作顺序】", "1. 分配工人进去 (管理工人)", "2. 存入粮食 (管理粮库)", "3. 存入工具 (补给工具)", "4. 等待自动产出 (每天自动)", "5. 取出木材去卖 (取出木材)", "6. 随时查看状态 (查看状态)", "粮食和工具会持续消耗, 记得定期补充!", "不确定的时候就选「查看状态」看一眼。"]},
    ]
    var _current_step: Variant = null

    var _i: int = _tutorial_content.size() - 1
    _current_step = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": "教程结束, 感谢聆听",
        "option_list": [{"otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE, "oname": "明白了", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我明白了, 谢谢管理员!"]}]}],
    }

    while _i >= 0:
        var _options_step: Variant = _current_step
        _current_step = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_lumber_mill_manager",
            "content": [_tutorial_content[_i]],
            "next": _options_step,
        }
        _i -= 1
    var _greeting: Dictionary = _current_step
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_show_buy_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "确认购买(90万金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我确认购买伐木场,90万金币。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": ["购买伐木场需90万金币\n永久拥有,容量300人\n确认购买吗?"]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_do_rent(_days: int, _cost: int, _capacity: int)-> void:
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法租用!", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        return
    WSData.update_money(- _cost, false)
    _mod_lumber_mill_owned = false
    _mod_lumber_mill_rent_end_day = WSData.system_counter + float(_days)
    _mod_lumber_mill_capacity = _capacity

    while _mod_lumber_mill_workers.size() > _capacity:
        _mod_lumber_mill_return_worker_to_player(_mod_lumber_mill_workers.size() - 1)
    _mod_msg("已租用伐木场\n租期" + str(_days) + "天\n花费" + str(_cost) + "金币")
    print("[MapMod] 伐木场租用: days=", _days, " cost=", _cost, " capacity=", _capacity)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_return_to_main()


func _mod_lumber_mill_do_buy()-> void:
    var _cost: int = 900000
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法购买!", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        return
    WSData.update_money(- _cost, false)
    _mod_lumber_mill_owned = true
    _mod_lumber_mill_rent_end_day = -1.0
    _mod_lumber_mill_capacity = 300
    while _mod_lumber_mill_workers.size() > _mod_lumber_mill_capacity:
        _mod_lumber_mill_return_worker_to_player(_mod_lumber_mill_workers.size() - 1)
    _mod_msg("已购买伐木场!\n花费90万金币\n永久拥有")
    print("[MapMod] 伐木场购买完成")
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_return_to_main()


func _mod_lumber_mill_show_supply_tools_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _worker_count: int = _mod_lumber_mill_workers.size()
    var _cost: int = 50 * _worker_count
    var _msg: String = "补给工具\n工人" + str(_worker_count) + "人,50金/把\n共需" + str(_cost) + "金"
    if _worker_count <= 0:
        _msg += "\n无工人,无需补给"
    elif _mod_lumber_mill_tool_durability >= 100.0:
        _msg += "\n耐久已满,无需补给"
    var _option_list: Array = []
    if _worker_count > 0 and _mod_lumber_mill_tool_durability < 100.0:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "确认补给工具(50金/把)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["确认补给,花费" + str(_cost) + "金币。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_do_supply_tools()-> void:
    var _worker_count: int = _mod_lumber_mill_workers.size()
    if _worker_count <= 0:
        _mod_msg("当前无工人,无需补给")
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_return_to_main()
        return
    if _mod_lumber_mill_tool_durability >= 100.0:
        _mod_msg("工具耐久已满,无需补给")
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_return_to_main()
        return
    var _cost: int = 50 * _worker_count
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法补给!", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_return_to_main()
        return
    WSData.update_money(- _cost, false)
    _mod_lumber_mill_tool_durability = 100.0
    _mod_msg("已补给工具!\n花费" + str(_cost) + "金币\n耐久已满")
    print("[MapMod] 伐木场补给工具: workers=", _worker_count, " cost=", _cost)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_return_to_main()





func _mod_add_soldier_to_persistent(_simple_json_list: Array)-> void:
    TeamUtils.repair_simple_json(_simple_json_list, false)
    for _simple_json: Dictionary in _simple_json_list:
        _simple_json.erase("is_leader")
    WSData.player_data.team.append_array(_simple_json_list)


func _mod_lumber_mill_return_worker_to_player(_idx: int)-> void:
    if _idx < 0 or _idx >= _mod_lumber_mill_workers.size():
        return
    var _worker = _mod_lumber_mill_workers[_idx]
    var _is_prisoner: bool = bool(_worker.get("is_prisoner", false))
    var _worker_name: String = str(_worker.get("name", "未知"))
    if not _is_prisoner:


        _worker.erase("is_prisoner")
        _worker.erase("is_guide")
        var _simple_json_list: Array = [_worker]
        if is_instance_valid(player_team_node):
            player_team_node.add_soldier(_simple_json_list)
            player_team_node.refresh_team_info(false)
            _mod_msg(_worker_name + " 已回到你的队伍")
            print("[MapMod] 伐木场士兵回填队伍: ", _worker_name, " uid=", _worker.get("uid", ""))
        else:


            _mod_add_soldier_to_persistent(_simple_json_list)
            print("[MapMod] 伐木场士兵回填(节点无效,走持久化兜底): ", _worker_name, " uid=", _worker.get("uid", ""))
    else:

        _worker.erase("is_prisoner")
        var _capture: Array = WSData.get_capture()
        _capture.append(_worker)
        WSData.update_capture(_capture)
        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)
        print("[MapMod] 伐木场俘虏回到capture: ", _worker_name)
    _mod_lumber_mill_workers.remove_at(_idx)




func _mod_msg(_content: String, _duration: float = 3.0, _is_success: bool = true)-> void:
    print("[MapMod] ", _content)
    if _mod_is_player_on_island():

        tip_node.cshow(_content)
        if is_instance_valid(_mod_tip_timer):
            _mod_tip_timer.start(_duration)
    else:

        GlobalMessageInterface.add_message(
            MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
            [_content]
        )




func _mod_msg_add_goods(_goods_name: String, _count: int)-> void:
    var _msg: String = "获得: " + _goods_name + " x" + str(_count)
    _mod_msg(_msg, 3.0, true)

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.ADD_ONE_GOODS,
        [_goods_name + " x" + str(_count)]
    )





func _mod_lumber_mill_take_wood(_ratio: float = 1.0)-> void:
    _ratio = clampf(_ratio, 0.0, 1.0)
    var _wood_f: float = _mod_lumber_mill_wood
    var _wood_int: int = int(_wood_f * _ratio)
    if _wood_int <= 0:
        if _ratio < 1.0 and int(_wood_f) > 0:
            _mod_msg("按" + str(int(_ratio * 100.0)) + "%比例取不出整数木材, 请调大取出比例", 3.0, false)
        else:
            _mod_msg("伐木场没有木材可取", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_return_to_main()
        return



    var _rare_wood: int = _wood_int / 40
    var _normal_wood: int = _wood_int - _rare_wood
    var _normal_uid: String = "commodity_0013"
    var _rare_uid: String = "commodity_0014"
    var _normal_part = GlobalBsPart.bs_part_dic.get(_normal_uid, null)
    var _rare_part = GlobalBsPart.bs_part_dic.get(_rare_uid, null)
    var _wood_to_goods: Array = []

    if _normal_wood > 0 and _normal_part != null:
        _wood_to_goods.append({"item": {"uid": _normal_uid}, "count": _normal_wood})

    if _rare_wood > 0 and _rare_part != null:
        _wood_to_goods.append({"item": {"uid": _rare_uid}, "count": _rare_wood})

    if not _wood_to_goods.is_empty():
        var _player_goods: Array = WSData.get_player_goods()
        for _new_item in _wood_to_goods:
            var _found: bool = false
            for _goods_json in _player_goods:
                if _goods_json.get("item",{}).get("uid", "") == _new_item["item"]["uid"]:
                    _goods_json["count"] = int(_goods_json.get("count", 0)) + _new_item["count"]
                    _found = true
                    break
            if not _found:
                _player_goods.append(_new_item)
        GoodsUtils.organize_goods(_player_goods)
        WSData.save_my_goods(_player_goods)
    var _msg: String = "取出木材(" + str(int(_ratio * 100.0)) + "%):\n普通木材" + str(_normal_wood) + "个"
    if _rare_wood > 0:
        _msg += "\n稀有木材" + str(_rare_wood) + "个"
    _msg += "\n请前往杂货铺售出换金"
    _mod_msg(_msg, 3.5)

    if _normal_wood > 0:
        _mod_msg_add_goods("普通木材", _normal_wood)
    if _rare_wood > 0:
        _mod_msg_add_goods("稀有木材", _rare_wood)
    print("[MapMod] 伐木场取出木材: normal=", _normal_wood, " rare=", _rare_wood, " 余数: ", _wood_f - float(_wood_int))

    _mod_lumber_mill_wood = _wood_f - float(_wood_int)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_return_to_main()



func _mod_lumber_mill_show_status_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _msg: String = _mod_lumber_mill_get_status_msg()
    var _option_list: Array = [
        {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "取出木材", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要取出木材。"]}]},
        {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "补给工具", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要补给工具。"]}]},
        {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回主菜单", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回主菜单。"]}]},
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)




func _mod_lumber_mill_show_manage_workers_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_lumber_mill_manage_context = "workers"
    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    var _guide_count: int = 0
    for _worker in _mod_lumber_mill_workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        elif bool(_worker.get("is_guide", false)):
            _guide_count += 1
            _soldier_count += 1
        else:
            _soldier_count += 1
    var _player_soldiers: int = WSData.player_data.team.size()
    var _team_info = WSData.get_player_team_info()

    var _player_prisoners: int = 0
    for _p in WSData.get_capture():
        if not _mod_is_hero_soldier(_p):
            _player_prisoners += 1
    var _remain_capacity: int = _mod_lumber_mill_capacity - _mod_lumber_mill_workers.size()
    var _msg: String = "工人管理。"
    _msg += "工人" + str(_mod_lumber_mill_workers.size()) + "/" + str(_mod_lumber_mill_capacity)
    _msg += "(兵" + str(_soldier_count) + " 俘" + str(_prisoner_count) + " 导" + str(_guide_count) + ")"
    _msg += "\n背包兵" + str(_player_soldiers) + " 俘" + str(_player_prisoners) + " 余量" + str(_remain_capacity)
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派士兵工作", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要派士兵到伐木场工作。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派俘虏工作", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要派俘虏到伐木场干活。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "指派向导", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要安排向导。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "召回全部士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["召回所有士兵。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "召回全部俘虏", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["召回所有俘虏。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_show_send_soldier_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_lumber_mill_manage_context = "workers"

    var _player_soldiers: int = 0
    for _s in WSData.player_data.team:
        if not _mod_is_hero_soldier(_s):
            _player_soldiers += 1
    var _remain_capacity: int = _mod_lumber_mill_capacity - _mod_lumber_mill_workers.size()
    var _max_send: int = min(_player_soldiers, _remain_capacity)
    var _msg: String = "派士兵到伐木场"
    _msg += "\n背包" + str(_player_soldiers) + "人 余量" + str(_remain_capacity) + "人"
    if _max_send <= 0:
        _msg += "\n无法派兵(容量不足或无兵)"
    else:
        _msg += " 最多派" + str(_max_send) + "人"
    var _option_list: Array = []
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派10名士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派10名士兵。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派50名士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派50名士兵。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派100名士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派100名士兵。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派全部士兵(最多" + str(_max_send) + "名)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["把能派的士兵都派去。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_show_send_prisoner_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_lumber_mill_manage_context = "workers"
    var _team_info = WSData.get_player_team_info()

    var _capture: Array = WSData.get_capture()
    var _available: int = 0
    for _p in _capture:
        if not _mod_is_hero_soldier(_p):
            _available += 1
    var _remain_capacity: int = _mod_lumber_mill_capacity - _mod_lumber_mill_workers.size()
    var _max_send: int = min(_available, _remain_capacity)
    var _msg: String = "派俘虏到伐木场"
    _msg += "\n可用俘" + str(_available) + " 余量" + str(_remain_capacity)
    if _max_send <= 0:
        _msg += "\n无法派俘虏(容量不足或无俘虏)"
    else:
        _msg += "\n最多派" + str(_max_send) + "人"
    var _option_list: Array = []
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派10名俘虏", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派10名俘虏。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派50名俘虏", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派50名俘虏。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派全部俘虏(最多" + str(_max_send) + "名)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["把能派的俘虏都派去。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_do_send_soldiers(_count: int)-> void:
    var _player_team: Array = WSData.player_data.team
    var _remain_capacity: int = _mod_lumber_mill_capacity - _mod_lumber_mill_workers.size()

    var _available: int = 0
    for _s in _player_team:
        if not _mod_is_hero_soldier(_s):
            _available += 1
    var _actual: int = min(_count, _available, _remain_capacity)
    if _actual <= 0:
        _mod_msg("无法派兵: 容量不足或无可用士兵(英雄不能派入伐木场)", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_manage_workers_dialog()
        return


    var _sent: int = 0
    var _i: int = _player_team.size() - 1
    while _i >= 0 and _sent < _actual:
        var _soldier = _player_team[_i]
        if not _mod_is_hero_soldier(_soldier) and _soldier is Dictionary:
            _player_team.remove_at(_i)
            _soldier["is_prisoner"] = false
            _mod_lumber_mill_workers.append(_soldier)
            _sent += 1
        _i -= 1

    if is_instance_valid(player_team_node):
        player_team_node.refresh_team_info(false)
    _mod_msg("已派" + str(_sent) + "名士兵到伐木场")
    print("[MapMod] 伐木场派士兵: ", _sent)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_manage_workers_dialog()


func _mod_lumber_mill_do_send_prisoners(_count: int)-> void:
    var _team_info = WSData.get_player_team_info()

    var _capture: Array = WSData.get_capture()
    var _available: int = 0
    for _p in _capture:
        if not _mod_is_hero_soldier(_p):
            _available += 1
    var _remain_capacity: int = _mod_lumber_mill_capacity - _mod_lumber_mill_workers.size()
    var _actual: int = min(_count, _available, _remain_capacity)
    if _actual <= 0:
        _mod_msg("无法派俘虏: 容量不足或无可用俘虏(英雄不能派入伐木场)", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_manage_workers_dialog()
        return


    var _sent: int = 0
    var _i: int = _capture.size() - 1
    while _i >= 0 and _sent < _actual:
        var _prisoner = _capture[_i]
        if _prisoner is Dictionary and not _mod_is_hero_soldier(_prisoner):
            _capture.remove_at(_i)
            _prisoner["is_prisoner"] = true
            _mod_lumber_mill_workers.append(_prisoner)
            _sent += 1
        _i -= 1
    WSData.update_capture(_capture)
    if is_instance_valid(player_team_node):
        player_team_node.refresh_team_info(false)
    _mod_msg("已派" + str(_sent) + "名俘虏到伐木场")
    print("[MapMod] 伐木场派俘虏: ", _sent, " 剩余俘虏=", _capture.size())
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_manage_workers_dialog()


func _mod_lumber_mill_do_recall_soldiers()-> void:
    var _recalled: int = 0
    var _simple_json_list: Array = []
    var _i: int = _mod_lumber_mill_workers.size() - 1
    while _i >= 0:
        var _worker = _mod_lumber_mill_workers[_i]
        if not bool(_worker.get("is_prisoner", false)):
            _worker.erase("is_prisoner")
            _worker.erase("is_guide")
            _simple_json_list.append(_worker)
            _mod_lumber_mill_workers.remove_at(_i)
            _recalled += 1
        _i -= 1
    if _recalled > 0:

        if is_instance_valid(player_team_node):
            player_team_node.add_soldier(_simple_json_list)
            player_team_node.refresh_team_info(false)
        else:

            _mod_add_soldier_to_persistent(_simple_json_list)
            print("[MapMod] 伐木场召回士兵(节点无效,走持久化兜底): ", _recalled)
    _mod_msg("召回" + str(_recalled) + "名士兵")
    print("[MapMod] 伐木场召回士兵: ", _recalled)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_manage_workers_dialog()


func _mod_lumber_mill_do_recall_prisoners()-> void:
    var _recalled: int = 0
    var _capture: Array = WSData.get_capture()
    var _i: int = _mod_lumber_mill_workers.size() - 1
    while _i >= 0:
        var _worker = _mod_lumber_mill_workers[_i]
        if bool(_worker.get("is_prisoner", false)):
            _mod_lumber_mill_workers.remove_at(_i)
            _worker.erase("is_prisoner")
            _capture.append(_worker)
            _recalled += 1
        _i -= 1
    if _recalled > 0:
        WSData.update_capture(_capture)
        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)
    _mod_msg("召回" + str(_recalled) + "名俘虏")
    print("[MapMod] 伐木场召回俘虏: ", _recalled)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_manage_workers_dialog()






func _mod_worker_star(_worker: Dictionary)-> int:
    if _worker.has("star"):
        var _s: int = int(_worker["star"])
        if _s > 0:
            return _s
    var _cfg: Dictionary = SoldierUtils.get_json_by_uid(str(_worker.get("uid", "")))
    if not _cfg.is_empty() and _cfg.has("star"):
        return clampi(int(_cfg["star"]), 1, 5)
    return 1




func _mod_lumber_mill_show_guide_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_lumber_mill_manage_context = "workers"
    var _guide_count: int = 0
    var _eligible: int = 0
    for _worker in _mod_lumber_mill_workers:
        if bool(_worker.get("is_prisoner", false)):
            continue
        if bool(_worker.get("is_guide", false)):
            _guide_count += 1
        elif _mod_worker_star(_worker) >= 4:
            _eligible += 1
    var _can_assign: int = min(MOD_LUMBER_MILL_GUIDE_MAX - _guide_count, _eligible)

    var _worker_total_g: int = _mod_lumber_mill_workers.size()
    var _guide_req: int = ceili(float(_worker_total_g) / float(MOD_LUMBER_MILL_GUIDE_COVER_PER))
    var _guide_cov: float = clampf(float(_guide_count) / float(maxi(_guide_req, 1)), 0.0, 1.0)

    var _lost_rate: float = _mod_lumber_mill_get_lost_rate(_guide_count, _worker_total_g)
    var _lost_pct: String = "%.1f" %(_lost_rate * 100.0)
    var _msg: String = "向导管理\n"
    _msg += "向导" + str(_guide_count) + "/" + str(MOD_LUMBER_MILL_GUIDE_MAX) + "(引路需求" + str(_guide_req) + "名)"
    _msg += " 覆盖" + str(int(_guide_cov * 100.0)) + "%"
    _msg += " 俘虏走失率" + _lost_pct + "%/天"
    _msg += "\n向导只带路不砍树(不产木), 需4-5星士兵"
    _msg += "\n引路需求与人数成正比: 每" + str(MOD_LUMBER_MILL_GUIDE_COVER_PER) + "人需1名向导"

    _msg += "\n向导照常提供镇压值(星级1/2/3/5/8), 满覆盖后多派仍增强镇压"
    if _worker_total_g <= 40:

        _msg += "\n现" + str(_worker_total_g) + "人≤40, 不会走失, 向导引路暂无作用"
        _msg += "\n满编需" + str(ceili(float(_mod_lumber_mill_capacity) / float(MOD_LUMBER_MILL_GUIDE_COVER_PER))) + "名(按容量" + str(_mod_lumber_mill_capacity) + "人算)"
        if _guide_count > 0:
            _msg += "\n已派向导仍提供镇压值, 但引路要41人起才生效"
    else:
        _msg += "\n现" + str(_worker_total_g) + "人需" + str(_guide_req) + "名, 满覆盖走失率2%→0.1%"

        if _guide_cov < 1.0:
            var _next_cov: float = clampf(float(_guide_count + 1) / float(maxi(_guide_req, 1)), 0.0, 1.0)
            var _next_lost: float = _mod_lumber_mill_get_lost_rate(_guide_count + 1, _worker_total_g)
            _msg += "\n再派1名向导: 覆盖" + str(int(_next_cov * 100.0)) + "% 走失率→" +("%.1f" %(_next_lost * 100.0)) + "%"
        else:
            _msg += "\n引路已满覆盖, 无需再派向导"
    _msg += "\n(士兵走失会回队伍, 向导只保俘虏)"
    _msg += "\n可指派" + str(_can_assign) + "名(先5星后4星)"
    if _eligible <= 0 and _guide_count < MOD_LUMBER_MILL_GUIDE_MAX:
        _msg += "\n[提示: 伐木场内无4-5星士兵, 请先派入]"
    var _option_list: Array = []
    if _can_assign > 0:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "指派5名向导", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["指派5名向导。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "指派10名向导", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["指派10名向导。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "指派全部可指派(最多" + str(_can_assign) + "名)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["把符合条件的都转为向导。"]}]})
    if _guide_count > 0:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "召回全部向导", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["召回所有向导, 让他们回去砍树。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_do_assign_guides(_count: int)-> void:
    var _current_guides: int = 0
    for _w in _mod_lumber_mill_workers:
        if not bool(_w.get("is_prisoner", false)) and bool(_w.get("is_guide", false)):
            _current_guides += 1
    var _slots: int = MOD_LUMBER_MILL_GUIDE_MAX - _current_guides
    if _slots <= 0:
        _mod_msg("向导已满" + str(MOD_LUMBER_MILL_GUIDE_MAX) + "名, 无法再指派", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_guide_dialog()
        return

    var _assigned: int = 0
    for _target_star in[5, 4]:
        if _assigned >= _slots or _assigned >= _count:
            break
        for _i in range(_mod_lumber_mill_workers.size()):
            if _assigned >= _slots or _assigned >= _count:
                break
            var _w = _mod_lumber_mill_workers[_i]
            if bool(_w.get("is_prisoner", false)) or bool(_w.get("is_guide", false)):
                continue
            if _mod_worker_star(_w) == _target_star:
                _w["is_guide"] = true
                _assigned += 1
    if _assigned <= 0:
        _mod_msg("无法指派: 伐木场内无4-5星士兵, 请先派入", 3.0, false)
    else:
        var _new_lost: float = _mod_lumber_mill_get_lost_rate(_current_guides + _assigned, _mod_lumber_mill_workers.size())
        _mod_msg("已指派" + str(_assigned) + "名向导(4-5星)\n俘虏走失率降至" +("%.1f" %(_new_lost * 100.0)) + "%/天")
        print("[MapMod] 伐木场指派向导: ", _assigned, " 当前向导总数: ", _current_guides + _assigned)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_guide_dialog()


func _mod_lumber_mill_do_recall_guides()-> void:
    var _recalled: int = 0
    for _w in _mod_lumber_mill_workers:
        if bool(_w.get("is_guide", false)):
            _w.erase("is_guide")
            _recalled += 1
    if _recalled > 0:
        _mod_msg("已召回" + str(_recalled) + "名向导\n转为普通工人恢复产木")
        print("[MapMod] 伐木场召回向导: ", _recalled)
    else:
        _mod_msg("当前没有向导", 3.0, false)
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_guide_dialog()


func _mod_lumber_mill_show_manage_food_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_lumber_mill_manage_context = "food"
    var _player_food: int = _mod_lumber_mill_count_player_food()
    var _food_pts: int = _mod_get_edible_food_points(_mod_lumber_mill_food)
    var _player_food_pts: int = _mod_get_edible_food_points(WSData.get_player_goods())
    var _msg: String = "粮库管理\n"

    _msg += "粮库" + _mod_format_points(_food_pts) + "点 · 背包" + _mod_format_points(_player_food_pts) + "点(" + str(_player_food) + "份)"
    var _daily_food_pts: int = _mod_lumber_mill_calc_daily_food()
    if _daily_food_pts > 0:
        var _food_days_left: int = int(_food_pts / _daily_food_pts)
        _msg += "\n日耗" + _mod_format_points(_daily_food_pts) + "点 · 存粮够撑" + str(_food_days_left) + "天"
    else:
        _msg += "\n无工人不消耗粮食"
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入粮食", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要放入粮食。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "取出全部粮食", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["取出全部粮食。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_count_player_food()-> int:
    var _player_goods: Array = WSData.get_player_goods()
    var _total: int = 0
    for _entry in FoodUtils.get_food_list_info(_player_goods).collect:
        _total += int(_entry.get("count", 0))
    return _total


func _mod_lumber_mill_show_put_food_dialog()-> void:
    _mod_lumber_mill_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_lumber_mill_manage_context = "food"
    var _player_food: int = _mod_lumber_mill_count_player_food()
    var _player_food_pts: int = _mod_get_edible_food_points(WSData.get_player_goods())
    var _msg: String = "放入粮食到伐木场粮库。"

    _msg += "\n背包粮食" + str(_player_food) + "份 · " + _mod_format_points(_player_food_pts) + "点"
    if _player_food > 0:
        _msg += " · 平均每份" + _mod_format_points(int(_player_food_pts / _player_food)) + "点"
    if _player_food <= 0:
        _msg += "\n您没有粮食可放入。"
    var _avg_per_portion: float = float(_player_food_pts) / float(maxi(_player_food, 1))
    var _option_list: Array = []

    for _n in[50, 100, 500]:
        var _est_pts: int = int(_avg_per_portion * mini(_n, _player_food))
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入" + str(_n) + "份(" + _mod_format_points(_est_pts) + "点)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入" + str(_n) + "份粮食。"]}]})

    var _daily_pts: int = _mod_lumber_mill_calc_daily_food()
    if _daily_pts > 0 and _player_food > 0:
        var _need30: int = maxi(_daily_pts * 30 - _mod_get_edible_food_points(_mod_lumber_mill_food), 0)
        if _need30 > 0:
            var _portions30: int = ceili(_need30 / maxf(_avg_per_portion, 1.0))
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入够30天(约" + str(mini(_portions30, _player_food)) + "份)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入够吃30天的粮食。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入全部粮食(共" + str(_player_food) + "份)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入全部粮食。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_lumber_mill_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_lumber_mill_manager",
        "leader_name": "伐木场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_lumber_mill_do_put_food(_count: int)-> void:
    var _player_goods: Array = WSData.get_player_goods()

    var _edible_uids: Dictionary = _mod_get_edible_uid_set(_player_goods)
    var _food_indices: Array = []
    var _food_total: int = 0
    for _i in range(_player_goods.size()):
        var _entry = _player_goods[_i]
        var _uid: String = _entry.get("item",{}).get("uid", "")
        if _edible_uids.has(_uid):
            _food_indices.append(_i)
            _food_total += int(_entry.get("count", 0))
    var _actual: int = min(_count, _food_total)
    if _actual <= 0:
        _mod_msg("无食物可放入", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_manage_food_dialog()
        return

    var _remaining: int = _actual
    var _to_add: Array = []
    while _remaining > 0 and not _food_indices.is_empty():
        var _idx: int = _food_indices[0]
        var _entry = _player_goods[_idx]
        var _count_in_entry: int = int(_entry.get("count", 0))
        if _count_in_entry <= _remaining:

            _to_add.append(_entry.duplicate(true))
            _remaining -= _count_in_entry
            _player_goods.remove_at(_idx)
            _food_indices.remove_at(0)

            for _j in range(_food_indices.size()):
                if _food_indices[_j] > _idx:
                    _food_indices[_j] -= 1
        else:

            var _new_entry: Dictionary = _entry.duplicate(true)
            _new_entry["count"] = _remaining
            _to_add.append(_new_entry)
            _entry["count"] = _count_in_entry - _remaining
            _remaining = 0

    var _added_pts: int = 0
    for _food in _to_add:
        _added_pts += _mod_entry_food_points(_food)
        _mod_lumber_mill_food.append(_food)
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)

    _mod_msg("放入" + str(_actual) + "份 · 粮库+" + _mod_format_points(_added_pts) + "点")
    print("[MapMod] 伐木场放入粮食: ", _actual, "份 ", _added_pts, "点")
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_manage_food_dialog()


func _mod_lumber_mill_do_take_food()-> void:
    if _mod_lumber_mill_food.is_empty():
        _mod_msg("粮库是空的", 3.0, false)
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_manage_food_dialog()
        return
    var _player_goods: Array = WSData.get_player_goods()
    var _taken: int = 0
    var _taken_pts: int = _mod_get_edible_food_points(_mod_lumber_mill_food)
    for _food_entry in _mod_lumber_mill_food:
        var _uid: String = _food_entry.get("item",{}).get("uid", "")
        var _count: int = int(_food_entry.get("count", 0))
        if _count <= 0:
            continue

        var _found: bool = false
        for _goods_entry in _player_goods:
            if _goods_entry.get("item",{}).get("uid", "") == _uid:
                _goods_entry["count"] = int(_goods_entry.get("count", 0)) + _count
                _found = true
                break
        if not _found:
            _player_goods.append({"item": {"uid": _uid}, "count": _count})
        _taken += _count
    _mod_lumber_mill_food.clear()
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)
    _mod_msg("取出" + str(_taken) + "份(" + _mod_format_points(_taken_pts) + "点)")
    print("[MapMod] 伐木场取出粮食: ", _taken, "份 ", _taken_pts, "点")
    _mod_lumber_mill_dialogue_active = false
    _mod_lumber_mill_show_manage_food_dialog()






func _mod_lumber_mill_get_weather_modifier()-> float:

    if _mod_typhoon_active:
        return 0.0
    if is_instance_valid(weather_executor_node):
        var _w: int = int(weather_executor_node.current_weather)
        match _w:
            MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
                return 1.1
            MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN:
                return 0.5
            MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
                return 0.3
            _:
                return 1.0
    return 1.0



func _mod_lumber_mill_get_efficiency_modifier(_worker_count: int)-> float:
    if _worker_count <= 0:
        return 0.0
    var _total_eff: float = 0.0

    var _tier1: int = min(_worker_count, 30)
    _total_eff += float(_tier1) * 1.0

    if _worker_count > 30:
        var _tier2: int = min(_worker_count - 30, 50)
        _total_eff += float(_tier2) * 0.85

    if _worker_count > 80:
        var _tier3: int = min(_worker_count - 80, 70)
        _total_eff += float(_tier3) * 0.7

    if _worker_count > 150:
        var _tier4: int = min(_worker_count - 150, 70)
        _total_eff += float(_tier4) * 0.55

    if _worker_count > 220:
        var _tier5: int = _worker_count - 220
        _total_eff += float(_tier5) * 0.4
    return _total_eff / float(_worker_count)



func _mod_lumber_mill_consume_food_with_morale(_need: int)-> int:
    var _consumed: int = 0
    var _morale_weighted_sum: float = 0.0
    var _morale_total_count: int = 0
    var _remaining: int = _need
    while _remaining > 0 and not _mod_lumber_mill_food.is_empty():
        var _entry = _mod_lumber_mill_food[0]
        var _count: int = int(_entry.get("count", 0))
        var _uid: String = str(_entry.get("item",{}).get("uid", ""))

        var _impact: float = 10.0
        var _food_part = null
        if GlobalBsPart.bs_part_dic != null:
            _food_part = GlobalBsPart.bs_part_dic.get(_uid, null)
        if _food_part != null:
            _impact = float(_food_part.get("morale_impact", 10))
        if _count <= _remaining:
            _remaining -= _count
            _consumed += _count
            _morale_weighted_sum += _impact * float(_count)
            _morale_total_count += _count
            _mod_lumber_mill_food.remove_at(0)
        else:
            _entry["count"] = _count - _remaining
            _consumed += _remaining
            _morale_weighted_sum += _impact * float(_remaining)
            _morale_total_count += _remaining
            _remaining = 0


    if _morale_total_count > 0:
        var _avg_impact: float = _morale_weighted_sum / float(_morale_total_count)
        var _morale_delta: float =(_avg_impact - 10.0) * 0.5
        _mod_lumber_mill_morale = clampf(_mod_lumber_mill_morale + _morale_delta, 0.0, 100.0)

    if _consumed < _need:
        _mod_lumber_mill_morale = clampf(_mod_lumber_mill_morale - 20.0, 0.0, 100.0)
    return _consumed


func _mod_lumber_mill_calc_daily_wood()-> float:
    if _mod_lumber_mill_workers.is_empty():
        return 0.0


    var _base_total: float = 0.0
    for _worker in _mod_lumber_mill_workers:
        if bool(_worker.get("is_guide", false)):
            continue
        var _is_prisoner: bool = bool(_worker.get("is_prisoner", false))
        if _is_prisoner:
            _base_total += 0.8
        else:
            var _star: int = _mod_worker_star(_worker)
            match _star:
                1: _base_total += 0.4
                2: _base_total += 0.6
                3: _base_total += 1.0
                4: _base_total += 1.5
                5: _base_total += 2.0
                _: _base_total += 0.4

    var _eff: float = _mod_lumber_mill_get_efficiency_modifier(_mod_lumber_mill_workers.size())

    var _weather: float = _mod_lumber_mill_get_weather_modifier()

    var _morale_mod: float = 1.0 if _mod_lumber_mill_morale >= 30.0 else 0.7

    var _tool_mod: float = _mod_lumber_mill_tool_durability / 100.0

    var _produced: float = _base_total * _eff * _weather * _morale_mod * _tool_mod * 1.3
    return _produced




func _mod_lumber_mill_calc_daily_food()-> int:
    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    for _worker in _mod_lumber_mill_workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        else:
            _soldier_count += 1

    var _nop: int = _soldier_count + int(_prisoner_count * BSSoldierConfig.CAPTURE_FOOD_CONSUME_MULT)
    return int(_nop * 1.0 * FoodConfig.CONSUME_RATIO_CONFIG)


func _mod_lumber_mill_daily_settlement()-> void:

    var _today: int = int(WSData.system_counter)
    if _mod_last_lm_settlement_day == _today:
        print("[MapMod] 伐木场今日已结算, 跳过重复调用 (day=", _today, ")")
        return
    _mod_last_lm_settlement_day = _today



    _mod_lumber_mill_regenerate_forest()

    if not _mod_lumber_mill_owned and _mod_lumber_mill_rent_end_day > 0.0:
        if WSData.system_counter >= _mod_lumber_mill_rent_end_day:
            print("[MapMod] 伐木场租期到期, 解散工人")
            _mod_lumber_mill_expire_rent()
            return
    if not _mod_lumber_mill_is_available():
        return
    if _mod_lumber_mill_workers.is_empty():
        return

    _mod_purge_duplicate_workers_daily(_mod_lumber_mill_workers, "伐木场")
    if _mod_lumber_mill_workers.is_empty():
        return
    print("[MapMod] 伐木场每日结算(v2): workers=", _mod_lumber_mill_workers.size(), " forest=", _mod_lumber_mill_forest_stock, " tool=", _mod_lumber_mill_tool_durability, " morale=", _mod_lumber_mill_morale)

    _mod_lumber_mill_tool_durability = clampf(_mod_lumber_mill_tool_durability - 5.0, 0.0, 100.0)

    var _food_result: Dictionary = _mod_consume_food_by_marching_system(_mod_lumber_mill_food, _mod_lumber_mill_workers)
    var _food_depleted_today: bool = bool(_food_result.get("depleted", false))
    if _food_depleted_today:
        _mod_lumber_mill_food_depleted = true
        _mod_lumber_mill_morale = clampf(_mod_lumber_mill_morale - 20.0, 0.0, 100.0)
        print("[MapMod] 伐木场粮食耗尽! 士气大幅下降")
    else:
        _mod_lumber_mill_food_depleted = false
        _mod_lumber_mill_morale = clampf(_mod_lumber_mill_morale + float(_food_result.get("morale_delta", 0.0)), 0.0, 100.0)

    var _raw_produced: float = _mod_lumber_mill_calc_daily_wood()

    var _actual_produced: float = min(_raw_produced, _mod_lumber_mill_forest_stock)
    if _actual_produced < 0.0:
        _actual_produced = 0.0

    _mod_lumber_mill_forest_stock = clampf(_mod_lumber_mill_forest_stock - _actual_produced, 0.0, MOD_LUMBER_MILL_FOREST_MAX)

    _mod_lumber_mill_wood += _actual_produced
    print("[MapMod] 伐木场产出木材: raw=", _raw_produced, " actual=", _actual_produced, " (蓄积限制) 存量: ", _mod_lumber_mill_wood)

    _mod_lumber_mill_check_escape(_food_depleted_today)



func _mod_lumber_mill_get_daily_forest_regen()-> float:
    return max(
        _mod_lumber_mill_forest_stock * MOD_LUMBER_MILL_FOREST_RECOVER_RATIO,
        MOD_LUMBER_MILL_FOREST_REGEN_MIN
    )



func _mod_lumber_mill_regenerate_forest()-> void:
    var _today: int = int(WSData.system_counter)
    if _mod_last_lm_regen_day == _today:
        return
    _mod_last_lm_regen_day = _today
    if _mod_lumber_mill_forest_stock >= MOD_LUMBER_MILL_FOREST_MAX:
        return
    _mod_lumber_mill_forest_stock = clampf(
        _mod_lumber_mill_forest_stock + _mod_lumber_mill_get_daily_forest_regen(),
        0.0, MOD_LUMBER_MILL_FOREST_MAX
    )



func _mod_intim_star_points(_star: int)-> int:
    match _star:
        2: return 2
        3: return 3
        4: return 5
        5: return 8
        _: return 1








func _mod_lumber_mill_get_intimidation_info(_food_depleted: bool = false)-> Dictionary:
    var _soldier_intim: int = 0
    var _prisoner_count: int = 0
    var _prisoner_demand: int = 0
    var _guide_count: int = 0
    for _worker in _mod_lumber_mill_workers:
        var _star: int = _mod_worker_star(_worker)
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
            _prisoner_demand += _mod_intim_star_points(_star)
            continue
        if bool(_worker.get("is_guide", false)):
            _guide_count += 1

        _soldier_intim += _mod_intim_star_points(_star)

    var _intim_effective: float = float(_soldier_intim) *(0.5 if _food_depleted else 1.0)
    var _ratio: float = 0.0
    if _prisoner_demand > 0:
        _ratio = clampf(_intim_effective / float(_prisoner_demand), 0.0, 1.0)
    var _level: int = 0
    if _ratio >= MOD_LUMBER_MILL_INTIM_FULL:
        _level = 2
    elif _ratio >= MOD_LUMBER_MILL_INTIM_STRONG:
        _level = 1
    var _req_full: int = _prisoner_demand
    return {"intimidation": _soldier_intim, "intim_effective": _intim_effective, "prisoners": _prisoner_count, "ratio": _ratio, "demand": _prisoner_demand, "req_full": _req_full, "level": _level, "guides": _guide_count}




func _mod_escape_rate_after_suppression(_base_rate: float, _suppress_ratio: float)-> float:
    return _base_rate *(1.0 - clampf(_suppress_ratio, 0.0, 1.0))





func _mod_intim_soldier_hint(_need_points: int)-> String:
    if _need_points <= 0:
        return ""
    var _soldiers: int = ceili(float(_need_points) / 3.0)
    return "(≈" + str(_soldiers) + "名3星兵)"






func _mod_lumber_mill_get_lost_rate(_guide_count: int, _total_workers: int = 0)-> float:
    var _required: int = ceili(float(maxi(_total_workers, 1)) / float(MOD_LUMBER_MILL_GUIDE_COVER_PER))
    var _coverage: float = clampf(float(_guide_count) / float(_required), 0.0, 1.0)
    var _rate: float = clampf(0.02 *(1.0 - MOD_LUMBER_MILL_GUIDE_COVER_EFFECT * _coverage), MOD_LUMBER_MILL_LOST_RATE_FLOOR, 0.02)
    if _mod_typhoon_active:
        _rate = minf(_rate * 5.0, 0.1)
    return _rate







func _mod_lumber_mill_check_escape(_food_depleted: bool)-> void:
    var _escaped_count: int = 0
    var _lost_count: int = 0

    var _intim: Dictionary = _mod_lumber_mill_get_intimidation_info(_food_depleted)

    var _i: int = _mod_lumber_mill_workers.size() - 1
    while _i >= 0:
        var _worker = _mod_lumber_mill_workers[_i]
        var _is_prisoner: bool = bool(_worker.get("is_prisoner", false))
        var _star: int = _mod_worker_star(_worker)
        var _escape_rate: float = 0.0
        if _is_prisoner:

            _escape_rate = 0.02

            if _food_depleted:
                _escape_rate = 0.08

            _escape_rate = _mod_escape_rate_after_suppression(_escape_rate, float(_intim.get("ratio", 0.0)))
        else:

            if bool(_worker.get("is_guide", false)):
                _i -= 1
                continue

            if _food_depleted:
                match _star:
                    1: _escape_rate = 0.06
                    2: _escape_rate = 0.04
                    3: _escape_rate = 0.02
                    4: _escape_rate = 0.0
                    5: _escape_rate = 0.0
                    _: _escape_rate = 0.06

        if _mod_lumber_mill_morale < 30.0 and _escape_rate > 0.0:
            _escape_rate *= 1.5

        if randf() < _escape_rate:
            _escaped_count += 1
            if _is_prisoner:
                _mod_lumber_mill_workers.remove_at(_i)
                print("[MapMod] 伐木场俘虏逃跑: ", _worker.get("name", "未知"))
            else:
                _mod_lumber_mill_return_worker_to_player(_i)
                print("[MapMod] 伐木场士兵逃跑(缺粮,回队伍): ", _worker.get("name", "未知"))
        _i -= 1

    var _worker_count: int = _mod_lumber_mill_workers.size()
    if _worker_count > 40:

        var _prisoner_lost_rate: float = _mod_lumber_mill_get_lost_rate(_intim.get("guides", 0), _worker_count)

        var _soldier_lost_rate: float = 0.1 if _mod_typhoon_active else 0.02

        if _mod_lumber_mill_morale < 30.0:
            _prisoner_lost_rate *= 1.5
            _soldier_lost_rate *= 1.5
        if _intim.get("guides", 0) > 0:
            var _guide_req_st: int = ceili(float(_worker_count) / float(MOD_LUMBER_MILL_GUIDE_COVER_PER))
            var _guide_cov_st: float = clampf(float(_intim.get("guides", 0)) / float(maxi(_guide_req_st, 1)), 0.0, 1.0)
            print("[MapMod] 伐木场向导", _intim.get("guides", 0), "/", _guide_req_st, "名(引路覆盖", int(_guide_cov_st * 100.0), "%), 俘虏走失率: ", _prisoner_lost_rate * 100.0, "% (士兵走失率: ", _soldier_lost_rate * 100.0, "%)")
        var _j: int = _mod_lumber_mill_workers.size() - 1
        while _j >= 0:
            var _worker2 = _mod_lumber_mill_workers[_j]

            if bool(_worker2.get("is_guide", false)):
                _j -= 1
                continue
            var _is_prisoner2: bool = bool(_worker2.get("is_prisoner", false))

            var _lost_rate: float = _prisoner_lost_rate if _is_prisoner2 else _soldier_lost_rate
            if randf() < _lost_rate:
                _lost_count += 1
                if _is_prisoner2:
                    _mod_lumber_mill_workers.remove_at(_j)
                    print("[MapMod] 伐木场俘虏走失: ", _worker2.get("name", "未知"))
                else:
                    _mod_lumber_mill_return_worker_to_player(_j)
                    print("[MapMod] 伐木场士兵走失(回队伍): ", _worker2.get("name", "未知"))
            _j -= 1

    if _escaped_count > 0 and _lost_count > 0:
        _mod_msg("伐木场有" + str(_escaped_count) + "名工人逃跑, " + str(_lost_count) + "名工人走失", 3.0, false)
    elif _escaped_count > 0:
        _mod_msg("伐木场有" + str(_escaped_count) + "名工人逃跑", 3.0, false)
    elif _lost_count > 0:
        var _lost_msg: String = "伐木场有" + str(_lost_count) + "名工人走失"
        if _mod_typhoon_active:
            _lost_msg += "(台风天)"
        _mod_msg(_lost_msg, 3.0, false)
    if _escaped_count > 0 or _lost_count > 0:

        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)




func _mod_return_food_to_player(_food_list: Array)-> int:
    if _food_list.is_empty():
        return 0
    var _player_goods: Array = WSData.get_player_goods()
    var _taken: int = 0
    for _food_entry in _food_list:
        var _uid: String = _food_entry.get("item",{}).get("uid", "")
        var _count: int = int(_food_entry.get("count", 0))
        if _count <= 0:
            continue
        if GlobalBsPart.bs_part_dic.get(_uid, null) == null:
            continue
        var _found: bool = false
        for _goods_entry in _player_goods:
            if _goods_entry.get("item",{}).get("uid", "") == _uid:
                _goods_entry["count"] = int(_goods_entry.get("count", 0)) + _count
                _found = true
                break
        if not _found:
            _player_goods.append({"item": {"uid": _uid}, "count": _count})
        _taken += _count
    if _taken > 0:
        GoodsUtils.organize_goods(_player_goods)
        WSData.save_my_goods(_player_goods)
        _mod_msg_add_goods("粮食", _taken)
    _food_list.clear()
    return _taken



func _mod_settle_goods_to_player(_normal_uid: String, _rare_uid: String, _stock: float, _rare_per: int)-> int:
    var _stock_int: int = int(_stock)
    if _stock_int <= 0:
        return 0
    var _rare: int = 0
    if _rare_per > 0:
        _rare = _stock_int / _rare_per
    var _normal: int = _stock_int - _rare
    if _normal <= 0 and _rare <= 0:
        return 0
    var _goods_list: Array = []
    if _normal > 0 and GlobalBsPart.bs_part_dic.get(_normal_uid, null) != null:
        _goods_list.append({"item": {"uid": _normal_uid}, "count": _normal})
    if _rare > 0 and GlobalBsPart.bs_part_dic.get(_rare_uid, null) != null:
        _goods_list.append({"item": {"uid": _rare_uid}, "count": _rare})
    if _goods_list.is_empty():
        return 0
    var _player_goods: Array = WSData.get_player_goods()
    var _total: int = 0
    for _new_item in _goods_list:
        var _found: bool = false
        for _goods_json in _player_goods:
            if _goods_json.get("item",{}).get("uid", "") == _new_item["item"]["uid"]:
                _goods_json["count"] = int(_goods_json.get("count", 0)) + _new_item["count"]
                _found = true
                break
        if not _found:
            _player_goods.append(_new_item)
        _total += int(_new_item["count"])
    if _total > 0:
        GoodsUtils.organize_goods(_player_goods)
        WSData.save_my_goods(_player_goods)
    return _total





func _mod_lumber_mill_expire_rent()-> void:
    var _soldier_list: Array = []
    var _capture: Array = WSData.get_capture()
    var _prisoner_back: int = 0
    for _worker in _mod_lumber_mill_workers:
        if not(_worker is Dictionary):
            continue
        if bool(_worker.get("is_prisoner", false)):
            _worker.erase("is_prisoner")
            _capture.append(_worker)
            _prisoner_back += 1
        else:
            _worker.erase("is_prisoner")
            _worker.erase("is_guide")
            _soldier_list.append(_worker)
    _mod_lumber_mill_workers.clear()
    if _prisoner_back > 0:
        WSData.update_capture(_capture)
    if not _soldier_list.is_empty():
        if is_instance_valid(player_team_node):
            player_team_node.add_soldier(_soldier_list)
        else:
            _mod_add_soldier_to_persistent(_soldier_list)

    var _food_back: int = _mod_return_food_to_player(_mod_lumber_mill_food)

    var _wood_back: int = _mod_settle_goods_to_player("commodity_0013", "commodity_0014", _mod_lumber_mill_wood, 40)
    if _wood_back > 0:
        _mod_lumber_mill_wood = maxf(_mod_lumber_mill_wood - float(_wood_back), 0.0)
        _mod_msg_add_goods("木材", _wood_back)
    _mod_lumber_mill_capacity = 0
    _mod_lumber_mill_rent_end_day = -1.0
    var _msg: String = "伐木场租期已到,工人已解散"
    if not _soldier_list.is_empty() or _prisoner_back > 0:
        _msg += "(" + str(_soldier_list.size()) + "名士兵归队"
        if _prisoner_back > 0:
            _msg += ", " + str(_prisoner_back) + "名俘虏收回"
        _msg += ")"
    if _food_back > 0:
        _msg += "\n粮库食物" + str(_food_back) + "份已退回背包"
    if _wood_back > 0:
        _msg += "\n木材" + str(_wood_back) + "个已入背包"
    _mod_msg(_msg, 5.0, false)
    print("[MapMod] 伐木场租期到期: 士兵=", _soldier_list.size(), " 俘虏=", _prisoner_back, " 退回食物=", _food_back, " 结算木材=", _wood_back)

    if is_instance_valid(player_team_node):
        player_team_node.refresh_team_info(false)


func _mod_lumber_mill_handle_dialogue_finish()-> void:
    var _oname: String = dialogue_interface_node.last_selected_oname
    print("[MapMod][伐木场] 对话结束路由: oname=", _oname)
    if is_instance_valid(special_build_interface_node) and special_build_interface_node.visible:
        special_build_interface_node.unchoose_charactar_card()

    if _oname == "租用伐木场":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_rent_dialog()
        return
    if _oname == "购买伐木场":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_buy_dialog()
        return
    if _oname == "了解伐木场":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_tutorial_dialog()
        return
    if _oname == "管理工人":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_manage_workers_dialog()
        return
    if _oname == "管理粮库":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_manage_food_dialog()
        return
    if _oname == "取出木材":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_take_wood()
        return
    if _oname == "补给工具":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_supply_tools_dialog()
        return
    if _oname == "查看状态":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_status_dialog()
        return

    if _oname == "租用1天(2000金币)":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_rent(1, 2000, 30)
        return
    if _oname == "租用7天(18000金币)":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_rent(7, 18000, 80)
        return
    if _oname == "租用30天(80000金币)":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_rent(30, 80000, 150)
        return
    if _oname == "租用90天(180000金币)":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_rent(90, 180000, 220)
        return
    if _oname == "确认购买(90万金币)":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_buy()
        return

    if _oname == "确认补给工具(50金/把)":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_supply_tools()
        return

    if _oname == "派士兵工作":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_send_soldier_dialog()
        return
    if _oname == "派俘虏工作":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_send_prisoner_dialog()
        return
    if _oname == "召回全部士兵":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_recall_soldiers()
        return
    if _oname == "召回全部俘虏":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_recall_prisoners()
        return

    if _oname == "指派向导":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_guide_dialog()
        return
    if _oname == "指派5名向导":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_assign_guides(5)
        return
    if _oname == "指派10名向导":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_assign_guides(10)
        return
    if _oname.begins_with("指派全部可指派"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_assign_guides(99999)
        return
    if _oname == "召回全部向导":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_recall_guides()
        return

    if _oname == "放入粮食":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_show_put_food_dialog()
        return
    if _oname == "取出全部粮食":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_take_food()
        return

    if _oname == "派10名士兵":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_soldiers(10)
        return
    if _oname == "派50名士兵":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_soldiers(50)
        return
    if _oname == "派100名士兵":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_soldiers(100)
        return
    if _oname.begins_with("派全部士兵"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_soldiers(99999)
        return

    if _oname == "派10名俘虏":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_prisoners(10)
        return
    if _oname == "派50名俘虏":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_prisoners(50)
        return
    if _oname.begins_with("派全部俘虏"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_send_prisoners(99999)
        return

    if _oname.begins_with("放入50份"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_put_food(50)
        return
    if _oname.begins_with("放入100份"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_put_food(100)
        return
    if _oname.begins_with("放入500份"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_put_food(500)
        return

    if _oname.begins_with("放入够"):
        _mod_lumber_mill_dialogue_active = false
        var _days_target: int = _oname.split("够")[1].split("天")[0].to_int()
        if _days_target <= 0:
            _days_target = 30
        var _daily_rt: int = _mod_lumber_mill_calc_daily_food()
        if _daily_rt <= 0:
            _mod_msg("无工人不消耗粮食, 无需放入", 3.0, false)
        else:
            var _need_rt: int = maxi(_daily_rt * _days_target - _mod_get_edible_food_points(_mod_lumber_mill_food), 0)
            if _need_rt <= 0:
                _mod_msg("存粮已够" + str(_days_target) + "天, 无需放入")
            else:
                var _bag_pts_rt: int = _mod_get_edible_food_points(WSData.get_player_goods())
                var _bag_cnt_rt: int = _mod_lumber_mill_count_player_food()
                if _bag_pts_rt <= 0 or _bag_cnt_rt <= 0:
                    _mod_msg("背包无可食用粮食", 3.0, false)
                else:
                    var _avg_rt: float = float(_bag_pts_rt) / float(_bag_cnt_rt)
                    _mod_lumber_mill_do_put_food(ceili(_need_rt / maxf(_avg_rt, 1.0)))
        return
    if _oname.begins_with("放入全部粮食"):
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_do_put_food(99999)
        return

    if _oname == "返回管理":
        _mod_lumber_mill_dialogue_active = false
        if _mod_lumber_mill_manage_context == "food":
            _mod_lumber_mill_show_manage_food_dialog()
        else:
            _mod_lumber_mill_show_manage_workers_dialog()
        return

    if _oname == "告辞":
        _mod_lumber_mill_dialogue_active = false

        if mod_lumber_mill_interface_node != null and is_instance_valid(mod_lumber_mill_interface_node):
            mod_lumber_mill_interface_node.hide_interface()
        return
    if _oname == "返回" or _oname == "返回主菜单":
        _mod_lumber_mill_dialogue_active = false
        _mod_lumber_mill_return_to_main()
        return
    _mod_lumber_mill_dialogue_active = false



const MINE_POS = Vector2(3520, 5710)
var _mine_node: Node2D = null
var _mine_select_effect: Sprite2D = null
var _mine_area: Area2D = null
var _mine_click_start_pos: Vector2 = Vector2.ZERO
var _mine_click_duration: int = 0
var _mine_is_clicking: bool = false
var _mine_pending: bool = false

func _place_mine()-> void:
    var obj_root = get_node_or_null("ObjectRoot/MapObjectRoot")
    if not obj_root:
        print("[MapMod] MapObjectRoot不存在, 无法放置采矿场")
        return

    var existing = obj_root.get_node_or_null("MineBuilding")
    if existing:
        existing.free()

    var tex = _load_map_tex("localtion/specialLocation/special_location_0006.png")
    if not tex:
        print("[MapMod] 采矿场贴图加载失败")
        return


    var circle_size = 160
    var img = Image.create(circle_size, circle_size, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var circle_center = circle_size / 2.0
    var circle_radius = circle_size / 2.0 - 4
    for angle in range(0, 360, 5):
        var rad = deg_to_rad(angle)
        for r in range(int(circle_radius - 3), int(circle_radius + 1)):
            var px = int(circle_center + cos(rad) * r)
            var py = int(circle_center + sin(rad) * r)
            if px >= 0 and px < circle_size and py >= 0 and py < circle_size:
                img.set_pixel(px, py, Color(1, 0.9, 0, 0.9))
    var circle_tex = ImageTexture.create_from_image(img)


    _mine_node = Node2D.new()
    _mine_node.name = "MineBuilding"
    _mine_node.position = MINE_POS
    _mine_node.z_index = 10
    obj_root.add_child(_mine_node)


    var mine_sprite = Sprite2D.new()
    mine_sprite.name = "Base"
    mine_sprite.texture = tex
    mine_sprite.scale = Vector2(0.6, 0.6)
    _mine_node.add_child(mine_sprite)


    _mine_select_effect = Sprite2D.new()
    _mine_select_effect.name = "SelectEffect"
    _mine_select_effect.scale = Vector2(0.8, 0.8)
    _mine_select_effect.z_index = 11
    _mine_select_effect.visible = false
    _mine_select_effect.texture = circle_tex
    _mine_node.add_child(_mine_select_effect)


    _mine_area = Area2D.new()
    _mine_area.name = "MineClickArea"
    _mine_area.position = MINE_POS
    _mine_area.z_index = 10
    _mine_area.collision_layer = 2048
    _mine_area.collision_mask = 0
    _mine_area.input_pickable = true
    obj_root.add_child(_mine_area)

    var col_shape = CircleShape2D.new()
    col_shape.radius = 80.0
    var col_node = CollisionShape2D.new()
    col_node.shape = col_shape
    _mine_area.add_child(col_node)

    _mine_area.input_event.connect(_on_mine_input_event)


    var map_root_mn = get_node_or_null("MapRoot")
    if map_root_mn:
        var mine_body = StaticBody2D.new()
        mine_body.name = "MinePhysicsBody"
        mine_body.position = MINE_POS
        mine_body.collision_layer = 4096
        mine_body.collision_mask = 0
        map_root_mn.add_child(mine_body)
        var mine_body_col = CollisionShape2D.new()
        var mine_body_shape = CircleShape2D.new()
        mine_body_shape.radius = 50.0
        mine_body_col.shape = mine_body_shape
        mine_body.add_child(mine_body_col)

    print("[MapMod] 采矿场放置完成 at ", MINE_POS)

func _on_mine_input_event(_viewport, event, _shape_idx):
    if event is InputEventScreenTouch:
        if event.pressed:
            _mine_is_clicking = true
            _mine_click_start_pos = event.position
            _mine_click_duration = 0
        else:
            if _mine_is_clicking:
                var dist =(event.position - _mine_click_start_pos).length_squared()
                if dist < MobileConfig.CLICK_DISTANCE_MAX_SQUARE and _mine_click_duration < MobileConfig.CLICK_TOUCH_DURATION_COUNTER:
                    _on_mine_clicked()
            _mine_is_clicking = false
    elif event is InputEventMouseButton:
        if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
            _on_mine_clicked()

func _on_mine_clicked():
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.CLICK_LEFT)
    _cancel_choose_location()
    _cancel_choose_team()
    if _mine_select_effect:
        _mine_select_effect.visible = true
    _click_effect(MINE_POS)
    _mine_pending = true
    _player_move(MINE_POS)
    print("[MapMod] 采矿场选中")

func _hide_mine_select():
    if _mine_select_effect and is_instance_valid(_mine_select_effect):
        _mine_select_effect.visible = false

func _check_mine_arrival():
    if _mine_pending and is_instance_valid(player_team_node):
        var dist = player_team_node.global_position.distance_to(MINE_POS)
        if dist < 100:
            _mine_pending = false
            _hide_mine_select()
            _start_port_collision_immunity()
            _open_mine_interface()

func _open_mine_interface():

    if mod_mine_interface_node == null:
        var _script = load("res://gd/game/mwBuild/specialBuild/ModMineInterface.gd")
        if _script == null:
            _mod_msg("采矿场面板加载失败(MOD文件缺失)", 3.0, false)
            print("[MapMod] WARNING: ModMineInterface.gd 加载失败")
            return
        mod_mine_interface_node = Control.new()
        mod_mine_interface_node.set_script(_script)
        mod_mine_interface_node.connect("close_page_sign", _on_mod_mine_panel_close)
        mod_mine_interface_node.connect("manage_workers_sign", _on_mod_mine_panel_manage_workers)
        mod_mine_interface_node.connect("manage_food_sign", _on_mod_mine_panel_manage_food)

        mod_mine_interface_node.connect("take_ore_confirm_sign", _on_mod_mine_panel_take_ore_confirm)
        mod_mine_interface_node.connect("supply_tools_sign", _on_mod_mine_panel_supply_tools)
        mod_mine_interface_node.connect("deepen_mine_sign", _on_mod_mine_panel_deepen_mine)
        mod_mine_interface_node.connect("drain_water_sign", _on_mod_mine_panel_drain_water)
        mod_mine_interface_node.connect("supply_timber_sign", _on_mod_mine_panel_supply_timber)
        mod_mine_interface_node.connect("talk_manager_sign", _on_mod_mine_panel_talk_manager)
        canvas_layer_node.add_child(mod_mine_interface_node)
    mod_mine_interface_node.show_interface()
    _mod_mine_refresh_panel()
    print("[MapMod] 采矿场界面已打开")



func _on_mod_mine_panel_close()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()

func _on_mod_mine_panel_manage_workers()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_manage_workers_dialog()

func _on_mod_mine_panel_manage_food()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_manage_food_dialog()


func _on_mod_mine_panel_take_ore_confirm(_ratio: float)-> void:
    print("[MapMod][采矿场] 面板滑动条取出矿石: ratio=", _ratio)
    _mod_mine_take_ore(clampf(_ratio, 0.0, 1.0))

func _on_mod_mine_panel_supply_tools()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_supply_tools_dialog()

func _on_mod_mine_panel_deepen_mine()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_deepen_dialog()

func _on_mod_mine_panel_drain_water()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_drain_dialog()

func _on_mod_mine_panel_supply_timber()-> void:
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_timber_dialog()

func _on_mod_mine_panel_talk_manager()-> void:
    print("[MapMod][采矿场] 面板按钮: 与管理员对话")
    if mod_mine_interface_node:
        mod_mine_interface_node.hide_interface()
    _mod_mine_show_manager_dialog()

func _create_stone_icon()-> ImageTexture:
    var s = 32
    var img = Image.create(s, s, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))

    var c_light = Color(0.75, 0.75, 0.75, 1.0)
    var c_mid = Color(0.55, 0.55, 0.55, 1.0)
    var c_dark = Color(0.35, 0.35, 0.35, 1.0)
    var c_outline = Color(0.2, 0.2, 0.2, 1.0)

    for x in range(4, 18):
        for y in range(14, 28):
            var dx = x - 11
            var dy = y - 21
            if dx * dx + dy * dy <= 49:
                if dy < -3:
                    img.set_pixel(x, y, c_light)
                elif dy < 2:
                    img.set_pixel(x, y, c_mid)
                else:
                    img.set_pixel(x, y, c_dark)

    for x in range(4, 18):
        for y in range(14, 28):
            if img.get_pixel(x, y).a > 0:
                if x == 4 or x == 17 or y == 14 or y == 27:
                    img.set_pixel(x, y, c_outline)

    for x in range(16, 28):
        for y in range(4, 16):
            var dx = x - 22
            var dy = y - 10
            if dx * dx + dy * dy <= 25:
                if dy < -2:
                    img.set_pixel(x, y, c_light)
                elif dy < 1:
                    img.set_pixel(x, y, c_mid)
                else:
                    img.set_pixel(x, y, c_dark)
    for x in range(16, 28):
        for y in range(4, 16):
            if img.get_pixel(x, y).a > 0:
                if x == 16 or x == 27 or y == 4 or y == 15:
                    img.set_pixel(x, y, c_outline)

    for x in range(20, 29):
        for y in range(18, 27):
            var dx = x - 24
            var dy = y - 22
            if dx * dx + dy * dy <= 16:
                if dy < -1:
                    img.set_pixel(x, y, c_light)
                else:
                    img.set_pixel(x, y, c_mid)
    for x in range(20, 29):
        for y in range(18, 27):
            if img.get_pixel(x, y).a > 0:
                if x == 20 or x == 28 or y == 18 or y == 26:
                    img.set_pixel(x, y, c_outline)
    return ImageTexture.create_from_image(img)






func _mod_mine_refresh_panel()-> void:
    if mod_mine_interface_node == null or not is_instance_valid(mod_mine_interface_node):
        return
    if not _mod_mine_is_available():
        mod_mine_interface_node.update_status({
            "idle": true,
            "idle_hint": "采矿场空闲\n可租用(1500金/天起)\n或购买(150万金币永久拥有)",
        }, "")
        return

    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    for _worker in _mod_mine_workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        else:
            _soldier_count += 1
    var _copper: int = int(_mod_mine_ore_stock.get("copper", 0.0))
    var _iron: int = int(_mod_mine_ore_stock.get("iron", 0.0))
    var _silver: int = int(_mod_mine_ore_stock.get("silver", 0.0))

    var _warnings: Array = []
    if _mod_mine_water_level >= 80.0:
        _warnings.append("积水严重已停工! → 点「排水」")
    elif _mod_mine_water_level >= 60.0:
        _warnings.append("积水较高 → 建议点「排水」")
    if _mod_mine_timber_support < 20.0:
        _warnings.append("支撑不足,矿难风险大增 → 点「补充木材支撑」")
    if _mod_mine_tool_durability <= 0.0:

        _warnings.append("工具已损坏,工人无法产出 → 点「补给工具」")
    elif _mod_mine_tool_durability < 20.0:
        _warnings.append("工具耐久低 → 建议点「补给工具」")
    if _mod_mine_food_depleted:
        _warnings.append("粮食耗尽,工人会逃跑 → 点「管理粮库」")
    else:

        var _daily_food_chk: int = _mod_mine_calc_daily_food()
        if _daily_food_chk > 0 and _mod_get_edible_food_points(_mod_mine_food) < _daily_food_chk * 3:
            _warnings.append("存粮不足3天 → 点「管理粮库」")
    if _mod_mine_morale < 30.0:
        _warnings.append("士气低落!产出-30%,意外+50%")
    if not _mod_mine_owned:
        var _rent_chk: int = int(_mod_mine_rent_end_day - WSData.system_counter)
        if _rent_chk <= 3:
            _warnings.append("租期仅剩" + str(_rent_chk) + "天!到期工人解散 → 点「与管理员对话」")

    var _daily_food: int = _mod_mine_calc_daily_food()
    var _food_pts: int = _mod_get_edible_food_points(_mod_mine_food)
    var _food_days: int = 99999
    if _daily_food > 0:
        _food_days = int(_food_pts / _daily_food)
    var _stats: Array = [
        {"k": "工人", "v": str(_mod_mine_workers.size()) + "/" + str(_mod_mine_capacity), "c": "white"},
        {"k": "构成", "v": "兵" + str(_soldier_count) + " · 俘" + str(_prisoner_count), "c": "dim"},
        {"k": "矿石存量", "v": "铜" + str(_copper) + " · 铁" + str(_iron) + " · 银" + str(_silver), "c": "white"},
        {"k": "矿井深度", "v": str(_mod_mine_depth) + "层", "c": "dim"},
    ]

    var _mine_food_pts_txt: String = _mod_format_points(_food_pts) + "点"
    if _food_days >= 9999:
        _stats.append({"k": "粮库", "v": _mine_food_pts_txt, "c": "dim"})
    elif _food_days <= 2:
        _stats.append({"k": "粮库", "v": _mine_food_pts_txt + " · 够" + str(_food_days) + "天", "c": "red"})
    else:
        _stats.append({"k": "粮库", "v": _mine_food_pts_txt + " · 够" + str(_food_days) + "天", "c": "white"})
    if _mod_mine_owned:
        _stats.append({"k": "产权", "v": "永久拥有", "c": "blue"})
    else:
        var _days_left: int = int(_mod_mine_rent_end_day - WSData.system_counter)
        var _rent_c: String = "red" if _days_left <= 3 else "white"
        _stats.append({"k": "租期剩余", "v": str(_days_left) + "天", "c": _rent_c})

    var _bars: Array = [
        {"label": "本层矿量", "value": _mod_mine_vein_stock, "max": 5000.0, "text": str(int(_mod_mine_vein_stock)) + "/5000 · 挖完可加深"},
        {"label": "工具耐久", "value": _mod_mine_tool_durability, "max": 100.0, "text": str(int(_mod_mine_tool_durability)) + "/100"},
        {"label": "士气", "value": _mod_mine_morale, "max": 100.0, "text": str(int(_mod_mine_morale)) + "/100"},
        {"label": "木材支撑", "value": _mod_mine_timber_support, "max": 100.0, "text": str(int(_mod_mine_timber_support)) + "/100"},
        {"label": "积水", "value": _mod_mine_water_level, "max": 100.0, "text": str(int(_mod_mine_water_level)) + "/100", "bad_high": true},
    ]


    var _intim: Dictionary = _mod_mine_get_intimidation_info(_mod_mine_food_depleted)
    var _chips: Array = [{"text": "地下作业·不受天气", "c": "dim"}]
    if int(_intim.get("prisoners", 0)) <= 0:
        _chips.append({"text": "无俘虏·镇压不生效", "c": "dim"})
    else:
        var _m_eff: int = int(_intim.get("intim_effective", 0))
        var _m_full: int = int(_intim.get("req_full", 0))
        var _m_ratio: float = float(_intim.get("ratio", 0.0))
        var _m_food_tag: String = "[缺粮减半]" if _mod_mine_food_depleted else ""
        if _m_ratio >= 1.0:
            _chips.append({"text": "镇压" + str(_m_eff) + "/" + str(_m_full) + "·满额 俘不逃" + _m_food_tag, "c": "green"})
        else:
            var _m_need: int = maxi(_m_full - _m_eff, 0)
            _chips.append({"text": "镇压" + str(_m_eff) + "/" + str(_m_full) + "·抵扣" + str(int(_m_ratio * 100.0)) + "% 差" + str(_m_need) + "点" + _mod_intim_soldier_hint(_m_need) + _m_food_tag, "c": "yellow" if _m_ratio >= 0.5 else "red"})


    var _intim_lvl_m: int = int(_intim.get("level", 0))
    var _m_pris: int = int(_intim.get("prisoners", 0))
    var _m_eff_v8: int = int(_intim.get("intim_effective", 0))
    var _m_full_v8: int = int(_intim.get("req_full", 0))
    var _m_ratio_v8: float = float(_intim.get("ratio", 0.0))
    var _intim_c_m: String = "red"
    var _intim_text_m: String = "无俘虏"
    if _m_pris <= 0:
        _intim_c_m = "dim"
    elif _m_ratio_v8 >= 1.0:
        _intim_c_m = "green"
        _intim_text_m = "镇压" + str(_m_eff_v8) + "/" + str(_m_full_v8) + " 满额 · 俘虏不逃"
    else:
        _intim_c_m = "yellow" if _intim_lvl_m == 1 else "red"
        var _m_need_v8: int = maxi(_m_full_v8 - _m_eff_v8, 0)
        _intim_text_m = "镇压" + str(_m_eff_v8) + "/" + str(_m_full_v8) + " · 抵扣" + str(int(_m_ratio_v8 * 100.0)) + "%逃跑 · 差" + str(_m_need_v8) + "点" + _mod_intim_soldier_hint(_m_need_v8)
    if _m_pris > 0 and _mod_mine_food_depleted:
        _intim_text_m += " [缺粮镇压减半]"



    var _risk_m: float = 0.08 if _mod_mine_food_depleted else 0.02
    if _m_pris <= 0:
        _risk_m = 0.0
    else:
        _risk_m = _mod_escape_rate_after_suppression(_risk_m, _m_ratio_v8)
    if _mod_mine_morale < 30.0 and _risk_m > 0.0:
        _risk_m *= 1.5
    _risk_m = clampf(_risk_m, 0.0, 0.12)
    var _safety_m: float =(0.12 - _risk_m) / 0.12 * 100.0
    var _safety_text_m: String = "无俘虏 · 无逃跑风险"
    if _m_pris > 0:
        _safety_text_m = "俘虏日逃跑率" + "%.1f" %(_risk_m * 100.0) + "% · 安全度" + str(int(_safety_m)) + "%"
    var _sliders_m: Array = [
        {"label": "镇压值", "value":(_m_eff_v8 if _m_pris > 0 else 0.0), "max": maxf(float(_m_full_v8), 1.0), "text": _intim_text_m, "c": _intim_c_m},
        {"label": "防逃跑", "value": _safety_m, "max": 100.0, "text": _safety_text_m},
    ]

    var _detail: String = "浅层产铜为主 · 深层产银为主 · 每层5000挖完不恢复"
    _detail += "\n日耗粮" + _mod_format_points(_daily_food) + "点 · 支撑满100可大幅降低矿难风险"
    _detail += "\n镇压规则: 士兵镇压值vs俘虏被镇压值同表(1/2/3/5/8), 比例即抵扣(7/10抵扣70%逃跑, 10/10不逃); 缺粮减半"
    mod_mine_interface_node.update_status({
        "warnings": _warnings,
        "stats": _stats,
        "bars": _bars,
        "sliders": _sliders_m,
        "chips": _chips,
        "detail": _detail,

        "ore_stock": {
            "copper": float(_mod_mine_ore_stock.get("copper", 0.0)),
            "iron": float(_mod_mine_ore_stock.get("iron", 0.0)),
            "silver": float(_mod_mine_ore_stock.get("silver", 0.0)),
        },
    }, "")


func _mod_mine_return_to_main()-> void:
    _mod_mine_show_manager_dialog()


func _mod_mine_show_manager_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _greeting_msg: String = _mod_mine_get_status_msg()
    var _option_list: Array = []

    if not _mod_mine_is_available():
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用采矿场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想租用采矿场。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "购买采矿场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想购买采矿场。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "了解采矿场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想了解一下采矿场怎么运作。"]}]})
    else:

        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "管理工人", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要管理采矿场的工人。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "管理粮库", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要管理粮库。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "矿井维护", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要维护矿井(加深/排水/木材支撑)。"]}]})
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "查看状态", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["让我看看采矿场的状态。"]}]})
        if not _mod_mine_owned:
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "购买采矿场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想购买采矿场。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE, "oname": "告辞", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["告辞。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_greeting_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }

    if not is_instance_valid(dialogue_interface_node):
        print("[MapMod][采矿场] 管理员对话失败: dialogue_interface_node 无效")
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    var _left_info: Dictionary = {}
    var _ptn = WSData.get_player_team_node()
    if _ptn != null and is_instance_valid(_ptn):
        _left_info = _ptn.get_dialogue_info()
    else:
        print("[MapMod][采矿场] 警告: 玩家队伍节点无效, 用空信息打开对话")
    print("[MapMod][采矿场] 打开管理员对话: 选项数=", _option_list.size())
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(_left_info, _right_info)
    dialogue_interface_node.init(_greeting, _left_info, _right_info)
    print("[MapMod][采矿场] 管理员对话已初始化")


func _mod_mine_is_available()-> bool:
    if _mod_mine_owned:
        return true
    if _mod_mine_rent_end_day > 0.0 and WSData.system_counter < _mod_mine_rent_end_day:
        return true
    return false


func _mod_mine_get_status_msg()-> String:
    if not _mod_mine_is_available():
        return "采矿场空闲\n可租用/购买"
    var _msg: String = "工人" + str(_mod_mine_workers.size()) + "/" + str(_mod_mine_capacity)
    _msg += " 深度" + str(_mod_mine_depth) + "层"
    _msg += " 粮" + _mod_format_points(_mod_get_edible_food_points(_mod_mine_food)) + "点"
    _msg += "\n矿层" + str(int(_mod_mine_vein_stock)) + "/5000"
    _msg += " 工具" + str(int(_mod_mine_tool_durability)) + "/100"
    _msg += " 士气" + str(int(_mod_mine_morale)) + "/100"

    _msg += "\n铜" + str(int(_mod_mine_ore_stock.get("copper", 0.0))) + " 铁" + str(int(_mod_mine_ore_stock.get("iron", 0.0))) + " 银" + str(int(_mod_mine_ore_stock.get("silver", 0.0)))
    _msg += " 支撑" + str(int(_mod_mine_timber_support)) + "/100"
    _msg += " 积水" + str(int(_mod_mine_water_level)) + "/100"

    var _intim: Dictionary = _mod_mine_get_intimidation_info(_mod_mine_food_depleted)
    var _intim_text: String = "-"
    if int(_intim.get("prisoners", 0)) > 0:
        var _st_eff: int = int(_intim.get("intim_effective", 0))
        var _st_full: int = int(_intim.get("req_full", 0))
        var _st_ratio: float = float(_intim.get("ratio", 0.0))
        if _st_ratio >= 1.0:
            _intim_text = "满额" + str(_st_eff) + "/" + str(_st_full) + "(不逃)"
        else:
            _intim_text = "镇" + str(_st_eff) + "/" + str(_st_full) + "·抵扣" + str(int(_st_ratio * 100.0)) + "%"
    _msg += " 镇压:" + _intim_text

    if _mod_mine_tool_durability <= 0.0:
        _msg += "\n[工具坏!]"
    elif _mod_mine_tool_durability < 20.0:
        _msg += "\n[工具低]"
    if _mod_mine_morale < 30.0:
        _msg += " [士气低!]"
    if _mod_mine_food_depleted:
        _msg += " [缺粮!]"
    if _mod_mine_water_level >= 80.0:
        _msg += " [积水停工!]"
    if _mod_mine_timber_support <= 0.0:
        _msg += " [无支撑!]"
    if _mod_mine_owned:
        _msg += " 已拥有"
    else:
        var _days_left: int = int(_mod_mine_rent_end_day - WSData.system_counter)
        _msg += " 租期" + str(_days_left) + "天"
    return _msg


func _mod_mine_get_food_total()-> int:
    var _total: int = 0
    for _food_entry in _mod_mine_food:
        _total += int(_food_entry.get("count", 0))
    _mod_mine_food_total = _total
    return _total


func _mod_mine_show_rent_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用1天(1500金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用1天,容量30人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用7天(18000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用7天,容量80人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用30天(80000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用30天,容量150人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "租用90天(180000金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["租用90天,容量220人。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": ["租用价格(长期投入才有回报):\n1天1500金(30人) 7天18000金(80人)\n30天80000金(150人)\n90天180000金(220人)"]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_show_tutorial_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _tutorial_content: Array = [
        {"clist": ["【采矿场是什么】", "采矿场可以安排士兵和俘虏挖矿, 产出矿石。", "矿石存放在采矿场, 取出后可卖给杂货铺换金币, 后期可自行熔炼。", "想用采矿场, 先花金币租用或购买, 然后分配工人进去。"]},
        {"clist": ["【怎么开始用】", "第一步: 租用或购买采矿场。", "  租用按天收费, 容量有限; 购买一次付清, 永久拥有。", "  对话里选「租用采矿场」或「购买采矿场」即可。"]},
        {"clist": ["【运作优先级 (最重要!)】", "采矿场每天自动结算, 按以下顺序检查:", "1. 有没有工人? 没工人就不产出。", "2. 粮食够不够? 粮食耗尽工人会逃跑!", "3. 工具耐久够不够? 耐久低产出减半。", "4. 积水有没有超过80%? 超过则透水停工。", "5. 以上都满足, 才会正常产出矿石。", "记住: 粮食 > 工具 > 积水, 这是维持运作的优先级!"]},
        {"clist": ["【必须做的三件事】", "1. 分配工人: 选「管理工人」把士兵/俘虏放进去。", "   俘虏也能挖矿, 是不错的劳动力。", "2. 存粮食: 选「管理粮库」放入食物。", "   士兵和俘虏每天都要吃饭, 不喂会逃跑!", "3. 补给工具: 选「补给工具」放入工具。", "   工具每天消耗耐久, 耐久低了产出减半。", "这三件事不做, 采矿场就转不起来。"]},
        {"clist": ["【矿井深度 (采矿场核心!)】", "矿井可无限加深, 每层有5000矿脉储量, 不恢复。", "矿层挖空后需加深到下一层才能继续产出。", "深度越深, 矿难概率越高(硬上限20%), 积水越快!", "深度影响矿石种类分布: 浅层铜为主(60%), 深层银为主(50%)。", "加深费用: 1→2(15万) 2→3(35万) 3→4(70万) 4→5(140万)", "5层起每层递增70%, 越深越贵但矿层无限。", "选「矿井维护」→「加深矿井」即可升级。"]},
        {"clist": ["【矿难系统 (采矿场独有!)】", "矿难有两种: 塌方和透水, 每日结算时随机触发。", "塌方: 概率=2%+深度×1%(硬上限20%), 木材支撑满时-2%, 无支撑时+5%.50%概率永久死亡不回队伍+损失10%矿石。", "透水: 积水达到80%时触发, 当天停工0产出。", "  每日积水增加3+深度×2, 需定期排水。", "保持木材支撑充足、定期排水, 可大幅降低矿难。"]},
        {"clist": ["【木材支撑 (联动伐木场!)】", "矿井需要木材做支撑, 防止塌方。", "木材支撑储量0-100, 每日减少(深度×5)。", "支撑满100时, 塌方概率-2%; 支撑为0时, 塌方概率+5%。", "选「补充木材支撑」可从背包放入木材, 每根+5支撑。", "建议从伐木场取出木材后, 拿来补充采矿场支撑。"]},
        {"clist": ["【积水排水 (采矿场独有!)】", "矿井会积水, 每日积水增加3+深度×2。", "积水达到80%时触发透水, 当天停工0产出。", "选「排水」可花金币排水, 每1%积水费用=深度×150金。", "深度越深排水越贵, 要定期排水避免停工。"]},
        {"clist": ["【矿山储量】", "每层矿脉有5000储量, 挖空后需加深到下一层。", "矿层不会恢复, 挖完就没了。", "深度可无限扩展, 每层都是5000, 加深需花金币。", "所以要定期加深矿井, 才能持续产出。"]},
        {"clist": ["【怎么赚钱】", "工人每天自动挖矿, 矿石(铜铁银)存进采矿场。", "选「取出矿石」把三种矿石拿到背包。", "然后去杂货铺把矿石卖掉换金币, 银矿最值钱。", "后期可自行熔炼, 提升价值。", "记住: 挖出来的矿石不会自动卖, 要自己取出自己卖!", "注意: 安排士兵到采矿场军饷比随行多20%, 俘虏不收军饷。"]},
        {"clist": ["【工人会逃跑和意外死亡】", "逃跑: 粮食耗尽时才发生, 高星级士兵不会逃。", "  俘虏不管饿不饿都有可能逃, 要留意。", "意外死亡: 工人超过40人时可能发生事故死亡, 永久损失不回队伍。", "  死亡率按星级递减: 1星0.8%/2星0.6%/3星0.5%/4星0.3%/5星0.2%。", "  台风天死亡率翻3倍, 士气低死亡率+50%。", "塌方也有50%概率永久死亡, 老兵比新兵更安全。"]},
        {"clist": ["【镇压机制 (新)】", "镇压: 士兵在场能镇住俘虏, 按比例抵扣逃跑。", "  士兵出「镇压值」, 俘虏出「被镇压值」, 同一张表:", "  1星=1点/2星=2点/3星=3点/4星=5点/5星=8点。", "  镇压比例即抵扣比例, 派多少有效多少:", "  镇压1/10 → 抵扣10%逃跑率; 7/10 → 抵扣70%。", "  镇压10/10 → 抵扣100%, 俘虏完全不逃!", "  例: 10个1星俘(被镇压值10), 派7个1星兵:", "  逃跑率2%→0.6%; 派满10点 → 归零。", "  1名5星兵(8点)可抵扣8个1星俘的80%。", "  注意: 缺粮时镇压值减半(饿兵吓不住人)。", "提示: 镇压值来自正在挖矿的士兵, 不影响产能, 无额外成本。"]},
        {"clist": ["【日常操作顺序】", "1. 分配工人进去 (管理工人)", "2. 存入粮食 (管理粮库)", "3. 存入工具 (补给工具)", "4. 补充木材支撑 (补充木材支撑)", "5. 排水 (排水) - 积水高时", "6. 加深矿井 (加深矿井) - 有钱时", "7. 等待自动产出 (每天自动)", "8. 取出矿石去卖 (取出矿石)", "9. 随时查看状态 (查看状态)", "粮食和工具会持续消耗, 记得定期补充!"]},
    ]
    var _current_step: Variant = null
    var _i: int = _tutorial_content.size() - 1
    _current_step = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": "教程结束, 感谢聆听",
        "option_list": [{"otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE, "oname": "明白了", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我明白了, 谢谢管理员!"]}]}],
    }
    while _i >= 0:
        var _options_step: Variant = _current_step
        _current_step = {
            "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "turn_hero_uid": "mod_mine_manager",
            "content": [_tutorial_content[_i]],
            "next": _options_step,
        }
        _i -= 1
    var _greeting: Dictionary = _current_step
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_show_buy_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "确认购买(150万金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我确认购买采矿场,150万金币。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": ["购买采矿场需150万金币\n永久拥有,容量300人\n确认购买吗?"]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_do_rent(_days: int, _cost: int, _capacity: int)-> void:
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法租用!", 3.0, false)
        _mod_mine_dialogue_active = false
        return
    WSData.update_money(- _cost, false)
    _mod_mine_owned = false
    _mod_mine_rent_end_day = WSData.system_counter + float(_days)
    _mod_mine_capacity = _capacity

    while _mod_mine_workers.size() > _capacity:
        _mod_mine_return_worker_to_player(_mod_mine_workers.size() - 1)
    _mod_msg("已租用采矿场\n租期" + str(_days) + "天\n花费" + str(_cost) + "金币")
    print("[MapMod] 采矿场租用: days=", _days, " cost=", _cost, " capacity=", _capacity)
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_do_buy()-> void:
    var _cost: int = 1500000
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法购买!", 3.0, false)
        _mod_mine_dialogue_active = false
        return
    WSData.update_money(- _cost, false)
    _mod_mine_owned = true
    _mod_mine_rent_end_day = -1.0
    _mod_mine_capacity = 300
    while _mod_mine_workers.size() > _mod_mine_capacity:
        _mod_mine_return_worker_to_player(_mod_mine_workers.size() - 1)
    _mod_msg("已购买采矿场!\n花费150万金币\n永久拥有")
    print("[MapMod] 采矿场购买完成")
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_show_supply_tools_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _worker_count: int = _mod_mine_workers.size()
    var _cost: int = 50 * _worker_count
    var _msg: String = "补给工具\n工人" + str(_worker_count) + "人,50金/把\n共需" + str(_cost) + "金"
    if _worker_count <= 0:
        _msg += "\n无工人,无需补给"
    elif _mod_mine_tool_durability >= 100.0:
        _msg += "\n耐久已满,无需补给"
    var _option_list: Array = []
    if _worker_count > 0 and _mod_mine_tool_durability < 100.0:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "确认补给工具(50金/把)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["确认补给,花费" + str(_cost) + "金币。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_do_supply_tools()-> void:
    var _worker_count: int = _mod_mine_workers.size()
    if _worker_count <= 0:
        _mod_msg("当前无工人,无需补给")
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    if _mod_mine_tool_durability >= 100.0:
        _mod_msg("工具耐久已满,无需补给")
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    var _cost: int = 50 * _worker_count
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法补给!", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    WSData.update_money(- _cost, false)
    _mod_mine_tool_durability = 100.0
    _mod_msg("已补给工具!\n花费" + str(_cost) + "金币\n耐久已满")
    print("[MapMod] 采矿场补给工具: workers=", _worker_count, " cost=", _cost)
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_return_worker_to_player(_idx: int)-> void:
    if _idx < 0 or _idx >= _mod_mine_workers.size():
        return
    var _worker = _mod_mine_workers[_idx]
    var _is_prisoner: bool = bool(_worker.get("is_prisoner", false))
    var _worker_name: String = str(_worker.get("name", "未知"))
    if not _is_prisoner:


        _worker.erase("is_prisoner")
        _worker.erase("is_guide")
        var _simple_json_list: Array = [_worker]
        if is_instance_valid(player_team_node):
            player_team_node.add_soldier(_simple_json_list)
            player_team_node.refresh_team_info(false)
            _mod_msg(_worker_name + " 已回到你的队伍")
            print("[MapMod] 采矿场士兵回填队伍: ", _worker_name, " uid=", _worker.get("uid", ""))
        else:


            _mod_add_soldier_to_persistent(_simple_json_list)
            print("[MapMod] 采矿场士兵回填(节点无效,走持久化兜底): ", _worker_name, " uid=", _worker.get("uid", ""))
    else:

        _worker.erase("is_prisoner")
        var _capture: Array = WSData.get_capture()
        _capture.append(_worker)
        WSData.update_capture(_capture)
        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)
        print("[MapMod] 采矿场俘虏回到capture: ", _worker_name)
    _mod_mine_workers.remove_at(_idx)





func _mod_mine_take_ore(_ratio: float = 1.0)-> void:
    var _r: float = clampf(_ratio, 0.0, 1.0)
    if _r <= 0.0:
        _mod_msg("取出比例为0, 未取出任何矿石", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    var _copper_f: float = float(_mod_mine_ore_stock.get("copper", 0.0))
    var _iron_f: float = float(_mod_mine_ore_stock.get("iron", 0.0))
    var _silver_f: float = float(_mod_mine_ore_stock.get("silver", 0.0))
    var _copper: int = int(_copper_f * _r)
    var _iron: int = int(_iron_f * _r)
    var _silver: int = int(_silver_f * _r)
    var _total: int = _copper + _iron + _silver
    if _total <= 0:
        _mod_msg("采矿场没有矿石可取", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    var _ore_to_goods: Array = []
    if _copper > 0:
        _ore_to_goods.append({"item": {"uid": MOD_MINE_ORE_COPPER_UID}, "count": _copper})
    if _iron > 0:
        _ore_to_goods.append({"item": {"uid": MOD_MINE_ORE_IRON_UID}, "count": _iron})
    if _silver > 0:
        _ore_to_goods.append({"item": {"uid": MOD_MINE_ORE_SILVER_UID}, "count": _silver})

    for _ore_item in _ore_to_goods:
        var _uid: String = _ore_item["item"]["uid"]
        var _part = GlobalBsPart.bs_part_dic.get(_uid, null)
        if _part == null:
            _mod_msg("矿石物品未注册(uid:" + _uid + "), 无法取出", 3.0, false)
            _mod_mine_dialogue_active = false
            _mod_mine_return_to_main()
            return

    var _player_goods: Array = WSData.get_player_goods()
    for _new_item in _ore_to_goods:
        var _found: bool = false
        for _goods_json in _player_goods:
            if _goods_json.get("item",{}).get("uid", "") == _new_item["item"]["uid"]:
                _goods_json["count"] = int(_goods_json.get("count", 0)) + _new_item["count"]
                _found = true
                break
        if not _found:
            _player_goods.append(_new_item)
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)

    _mod_mine_ore_stock["copper"] = _copper_f - float(_copper)
    _mod_mine_ore_stock["iron"] = _iron_f - float(_iron)
    _mod_mine_ore_stock["silver"] = _silver_f - float(_silver)

    var _msg: String = "取出矿石:\n铜矿" + str(_copper) + "个  铁矿" + str(_iron) + "个  银矿" + str(_silver) + "个"
    if _r < 1.0:
        _msg = "按" + str(int(_r * 100.0)) + "%取出矿石:\n铜矿" + str(_copper) + "个  铁矿" + str(_iron) + "个  银矿" + str(_silver) + "个"
    _msg += "\n请前往杂货铺售出换金, 或后期自行熔炼"
    _mod_msg(_msg, 3.5)
    _mod_msg_add_goods("矿石", _total)
    print("[MapMod] 采矿场取出矿石: ratio=", _r, " copper=", _copper, " iron=", _iron, " silver=", _silver, " 余数: ", _mod_mine_ore_stock)
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_show_status_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _msg: String = _mod_mine_get_status_msg()
    var _option_list: Array = [
        {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "取出矿石", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要取出矿石。"]}]},
        {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "补给工具", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要补给工具。"]}]},
        {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回主菜单", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回主菜单。"]}]},
    ]
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)




func _mod_mine_show_manage_workers_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_mine_manage_context = "workers"
    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    for _worker in _mod_mine_workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        else:
            _soldier_count += 1
    var _player_soldiers: int = WSData.player_data.team.size()
    var _team_info = WSData.get_player_team_info()

    var _player_prisoners: int = 0
    for _p in WSData.get_capture():
        if not _mod_is_hero_soldier(_p):
            _player_prisoners += 1
    var _remain_capacity: int = _mod_mine_capacity - _mod_mine_workers.size()
    var _msg: String = "工人管理。"
    _msg += "工人" + str(_mod_mine_workers.size()) + "/" + str(_mod_mine_capacity)
    _msg += "(兵" + str(_soldier_count) + " 俘" + str(_prisoner_count) + ")"
    _msg += "\n背包兵" + str(_player_soldiers) + " 俘" + str(_player_prisoners) + " 余量" + str(_remain_capacity)
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派士兵工作", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要派士兵到采矿场工作。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派俘虏工作", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要派俘虏到采矿场干活。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "召回全部士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["召回所有士兵。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "召回全部俘虏", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["召回所有俘虏。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_show_send_soldier_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_mine_manage_context = "workers"

    var _player_soldiers: int = 0
    for _s in WSData.player_data.team:
        if not _mod_is_hero_soldier(_s):
            _player_soldiers += 1
    var _remain_capacity: int = _mod_mine_capacity - _mod_mine_workers.size()
    var _max_send: int = min(_player_soldiers, _remain_capacity)
    var _msg: String = "派士兵到采矿场"
    _msg += "\n背包" + str(_player_soldiers) + "人 余量" + str(_remain_capacity) + "人"
    if _max_send <= 0:
        _msg += "\n无法派兵(容量不足或无兵)"
    else:
        _msg += " 最多派" + str(_max_send) + "人"
    var _option_list: Array = []
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派10名士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派10名士兵。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派50名士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派50名士兵。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派100名士兵", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派100名士兵。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派全部士兵(最多" + str(_max_send) + "名)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["把能派的士兵都派去。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_show_send_prisoner_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_mine_manage_context = "workers"
    var _team_info = WSData.get_player_team_info()

    var _capture: Array = WSData.get_capture()
    var _available: int = 0
    for _p in _capture:
        if not _mod_is_hero_soldier(_p):
            _available += 1
    var _remain_capacity: int = _mod_mine_capacity - _mod_mine_workers.size()
    var _max_send: int = min(_available, _remain_capacity)
    var _msg: String = "派俘虏到采矿场"
    _msg += "\n可用俘" + str(_available) + " 余量" + str(_remain_capacity)
    if _max_send <= 0:
        _msg += "\n无法派俘虏(容量不足或无俘虏)"
    else:
        _msg += "\n最多派" + str(_max_send) + "人"
    var _option_list: Array = []
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派10名俘虏", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派10名俘虏。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派50名俘虏", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["派50名俘虏。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "派全部俘虏(最多" + str(_max_send) + "名)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["把能派的俘虏都派去。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_is_hero_soldier(_soldier)-> bool:
    if _soldier == null or not(_soldier is Dictionary):
        return false
    if bool(_soldier.get("is_leader", false)):
        return true
    if int(_soldier.get("htype", -1)) == BSSoldierConstants.H_TYPE_ENUM.HERO:
        return true
    return false






func _mod_consume_food_by_marching_system(_food_list: Array, _workers: Array)-> Dictionary:
    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    for _worker in _workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        else:
            _soldier_count += 1
    var _nop: int = _soldier_count + int(_prisoner_count * BSSoldierConfig.CAPTURE_FOOD_CONSUME_MULT)
    var _food_consume_type: String = FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS
    var _team_info = WSData.get_player_team_info()
    if _team_info != null:
        _food_consume_type = _team_info.food_consume_type
    var _edible: Dictionary = FoodUtils.get_food_list_info(_food_list)
    var _staple: Array = _edible.staple
    var _accompaniment: Array = _edible.accompaniment
    if ArrayUtils.is_empty(_staple) and ArrayUtils.is_empty(_accompaniment):
        return {"depleted": true, "morale_delta": 0.0}

    var _points_before: Dictionary = _mod_food_points_by_impact(_food_list)

    FoodUtils._handle_food_consume(_staple, 1.0, _food_consume_type, _nop)
    FoodUtils._handle_food_consume(_accompaniment, 1.0, _food_consume_type, _nop)
    var _organized: Array = GoodsUtils.organize_goods(_food_list)
    _food_list.clear()
    _food_list.append_array(_organized)

    var _points_after: Dictionary = _mod_food_points_by_impact(_food_list)
    var _consumed_points: float = 0.0
    var _impact_weighted: float = 0.0
    for _imp in _points_before.keys():
        var _eaten: float = float(_points_before[_imp]) - float(_points_after.get(_imp, 0))
        if _eaten > 0.0:
            _consumed_points += _eaten
            _impact_weighted += float(_imp) * _eaten
    var _morale_delta: float = 0.0
    if _consumed_points > 0.0:
        _morale_delta =(_impact_weighted / _consumed_points - 10.0) * 0.5
    var _edible_after: Dictionary = FoodUtils.get_food_list_info(_food_list)
    return {"depleted": ArrayUtils.is_empty(_edible_after.collect), "morale_delta": _morale_delta}





func _mod_format_points(_pts: int)-> String:
    var _disp: float = float(_pts) / 100.0
    if _disp >= 10000.0:
        return "%.1f万" %(_disp / 10000.0)
    if absf(_disp - roundf(_disp)) < 0.05:
        return str(int(roundf(_disp)))
    return "%.1f" % _disp


func _mod_get_edible_food_points(_food_list: Array)-> int:
    var _total: int = 0
    for _entry in FoodUtils.get_food_list_info(_food_list).collect:
        _total += _mod_entry_food_points(_entry)
    return _total


func _mod_entry_food_points(_entry: Dictionary)-> int:
    var _count: int = int(_entry.get("count", 0))
    if _count <= 0:
        return 0
    var _pts: int = 0
    if _entry.has("detail"):
        for _d in _entry.get("detail"):
            _pts += int(_d.get("consumption", 0))
    if _pts <= 0:
        var _json = GoodsUtils.get_json_by_uid(str(_entry.get("item",{}).get("uid", "")))
        if _json != null and _json.has("consumption_total"):
            _pts = int(_json.consumption_total) * _count
    return _pts


func _mod_food_points_by_impact(_food_list: Array)-> Dictionary:
    var _result: Dictionary = {}
    for _entry in FoodUtils.get_food_list_info(_food_list).collect:
        var _uid: String = str(_entry.get("item",{}).get("uid", ""))
        var _impact: float = 10.0
        if GlobalBsPart.bs_part_dic != null:
            var _food_part = GlobalBsPart.bs_part_dic.get(_uid, null)
            if _food_part != null:
                _impact = float(_food_part.get("morale_impact", 10))
        _result[_impact] = float(_result.get(_impact, 0.0)) + float(_mod_entry_food_points(_entry))
    return _result


func _mod_get_edible_uid_set(_goods: Array)-> Dictionary:
    var _result: Dictionary = {}
    for _entry in FoodUtils.get_food_list_info(_goods).collect:
        _result[str(_entry.get("item",{}).get("uid", ""))] = true
    return _result


func _mod_mine_do_send_soldiers(_count: int)-> void:
    var _player_team: Array = WSData.player_data.team
    var _remain_capacity: int = _mod_mine_capacity - _mod_mine_workers.size()

    var _available: int = 0
    for _s in _player_team:
        if not _mod_is_hero_soldier(_s):
            _available += 1
    var _actual: int = min(_count, _available, _remain_capacity)
    if _actual <= 0:
        _mod_msg("无法派兵: 容量不足或无可用士兵(英雄不能派入采矿场)", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_show_manage_workers_dialog()
        return


    var _sent: int = 0
    var _i: int = _player_team.size() - 1
    while _i >= 0 and _sent < _actual:
        var _soldier = _player_team[_i]
        if not _mod_is_hero_soldier(_soldier) and _soldier is Dictionary:
            _player_team.remove_at(_i)
            _soldier["is_prisoner"] = false
            _mod_mine_workers.append(_soldier)
            _sent += 1
        _i -= 1

    if is_instance_valid(player_team_node):
        player_team_node.refresh_team_info(false)
    _mod_msg("已派" + str(_sent) + "名士兵到采矿场")
    print("[MapMod] 采矿场派士兵: ", _sent)
    _mod_mine_dialogue_active = false
    _mod_mine_show_manage_workers_dialog()


func _mod_mine_do_send_prisoners(_count: int)-> void:
    var _team_info = WSData.get_player_team_info()

    var _capture: Array = WSData.get_capture()
    var _available: int = 0
    for _p in _capture:
        if not _mod_is_hero_soldier(_p):
            _available += 1
    var _remain_capacity: int = _mod_mine_capacity - _mod_mine_workers.size()
    var _actual: int = min(_count, _available, _remain_capacity)
    if _actual <= 0:
        _mod_msg("无法派俘虏: 容量不足或无可用俘虏(英雄不能派入采矿场)", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_show_manage_workers_dialog()
        return


    var _sent: int = 0
    var _i: int = _capture.size() - 1
    while _i >= 0 and _sent < _actual:
        var _prisoner = _capture[_i]
        if _prisoner is Dictionary and not _mod_is_hero_soldier(_prisoner):
            _capture.remove_at(_i)
            _prisoner["is_prisoner"] = true
            _mod_mine_workers.append(_prisoner)
            _sent += 1
        _i -= 1
    WSData.update_capture(_capture)
    if is_instance_valid(player_team_node):
        player_team_node.refresh_team_info(false)
    _mod_msg("已派" + str(_sent) + "名俘虏到采矿场")
    print("[MapMod] 采矿场派俘虏: ", _sent, " 剩余俘虏=", _capture.size())
    _mod_mine_dialogue_active = false
    _mod_mine_show_manage_workers_dialog()


func _mod_mine_do_recall_soldiers()-> void:
    var _recalled: int = 0
    var _simple_json_list: Array = []
    var _i: int = _mod_mine_workers.size() - 1
    while _i >= 0:
        var _worker = _mod_mine_workers[_i]
        if not bool(_worker.get("is_prisoner", false)):
            _worker.erase("is_prisoner")
            _worker.erase("is_guide")
            _simple_json_list.append(_worker)
            _mod_mine_workers.remove_at(_i)
            _recalled += 1
        _i -= 1
    if _recalled > 0:

        if is_instance_valid(player_team_node):
            player_team_node.add_soldier(_simple_json_list)
            player_team_node.refresh_team_info(false)
        else:

            _mod_add_soldier_to_persistent(_simple_json_list)
            print("[MapMod] 采矿场召回士兵(节点无效,走持久化兜底): ", _recalled)
    _mod_msg("召回" + str(_recalled) + "名士兵")
    print("[MapMod] 采矿场召回士兵: ", _recalled)
    _mod_mine_dialogue_active = false
    _mod_mine_show_manage_workers_dialog()


func _mod_mine_do_recall_prisoners()-> void:
    var _recalled: int = 0
    var _capture: Array = WSData.get_capture()
    var _i: int = _mod_mine_workers.size() - 1
    while _i >= 0:
        var _worker = _mod_mine_workers[_i]
        if bool(_worker.get("is_prisoner", false)):
            _mod_mine_workers.remove_at(_i)
            _worker.erase("is_prisoner")
            _capture.append(_worker)
            _recalled += 1
        _i -= 1
    if _recalled > 0:
        WSData.update_capture(_capture)
        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)
    _mod_msg("召回" + str(_recalled) + "名俘虏")
    print("[MapMod] 采矿场召回俘虏: ", _recalled)
    _mod_mine_dialogue_active = false
    _mod_mine_show_manage_workers_dialog()


func _mod_mine_show_manage_food_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_mine_manage_context = "food"
    var _player_food: int = _mod_mine_count_player_food()
    var _food_pts: int = _mod_get_edible_food_points(_mod_mine_food)
    var _player_food_pts: int = _mod_get_edible_food_points(WSData.get_player_goods())
    var _msg: String = "粮库管理\n"

    _msg += "粮库" + _mod_format_points(_food_pts) + "点 · 背包" + _mod_format_points(_player_food_pts) + "点(" + str(_player_food) + "份)"
    var _daily_food_pts: int = _mod_mine_calc_daily_food()
    if _daily_food_pts > 0:
        var _food_days_left: int = int(_food_pts / _daily_food_pts)
        _msg += "\n日耗" + _mod_format_points(_daily_food_pts) + "点 · 存粮够撑" + str(_food_days_left) + "天"
    else:
        _msg += "\n无工人不消耗粮食"
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入粮食", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要放入粮食。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "取出全部粮食", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["取出全部粮食。"]}]},
            {"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]},
        ],
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_count_player_food()-> int:
    var _player_goods: Array = WSData.get_player_goods()
    var _total: int = 0
    for _entry in FoodUtils.get_food_list_info(_player_goods).collect:
        _total += int(_entry.get("count", 0))
    return _total


func _mod_mine_show_put_food_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    _mod_mine_manage_context = "food"
    var _player_food: int = _mod_mine_count_player_food()
    var _player_food_pts: int = _mod_get_edible_food_points(WSData.get_player_goods())
    var _msg: String = "放入粮食到采矿场粮库。"

    _msg += "\n背包粮食" + str(_player_food) + "份 · " + _mod_format_points(_player_food_pts) + "点"
    if _player_food > 0:
        _msg += " · 平均每份" + _mod_format_points(int(_player_food_pts / _player_food)) + "点"
    if _player_food <= 0:
        _msg += "\n您没有粮食可放入。"
    var _avg_per_portion: float = float(_player_food_pts) / float(maxi(_player_food, 1))
    var _option_list: Array = []

    for _n in[50, 100, 500]:
        var _est_pts: int = int(_avg_per_portion * mini(_n, _player_food))
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入" + str(_n) + "份(" + _mod_format_points(_est_pts) + "点)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入" + str(_n) + "份粮食。"]}]})

    var _daily_pts: int = _mod_mine_calc_daily_food()
    if _daily_pts > 0 and _player_food > 0:
        var _need30: int = maxi(_daily_pts * 30 - _mod_get_edible_food_points(_mod_mine_food), 0)
        if _need30 > 0:
            var _portions30: int = ceili(_need30 / maxf(_avg_per_portion, 1.0))
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入够30天(约" + str(mini(_portions30, _player_food)) + "份)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入够吃30天的粮食。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入全部粮食(共" + str(_player_food) + "份)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入全部粮食。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回管理", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_do_put_food(_count: int)-> void:
    var _player_goods: Array = WSData.get_player_goods()

    var _edible_uids: Dictionary = _mod_get_edible_uid_set(_player_goods)
    var _food_indices: Array = []
    var _food_total: int = 0
    for _i in range(_player_goods.size()):
        var _entry = _player_goods[_i]
        var _uid: String = _entry.get("item",{}).get("uid", "")
        if _edible_uids.has(_uid):
            _food_indices.append(_i)
            _food_total += int(_entry.get("count", 0))
    var _actual: int = min(_count, _food_total)
    if _actual <= 0:
        _mod_msg("无食物可放入", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_show_manage_food_dialog()
        return

    var _remaining: int = _actual
    var _to_add: Array = []
    while _remaining > 0 and not _food_indices.is_empty():
        var _idx: int = _food_indices[0]
        var _entry = _player_goods[_idx]
        var _count_in_entry: int = int(_entry.get("count", 0))
        if _count_in_entry <= _remaining:

            _to_add.append(_entry.duplicate(true))
            _remaining -= _count_in_entry
            _player_goods.remove_at(_idx)
            _food_indices.remove_at(0)

            for _j in range(_food_indices.size()):
                if _food_indices[_j] > _idx:
                    _food_indices[_j] -= 1
        else:

            var _new_entry: Dictionary = _entry.duplicate(true)
            _new_entry["count"] = _remaining
            _to_add.append(_new_entry)
            _entry["count"] = _count_in_entry - _remaining
            _remaining = 0

    var _added_pts: int = 0
    for _food in _to_add:
        _added_pts += _mod_entry_food_points(_food)
        _mod_mine_food.append(_food)
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)

    _mod_msg("放入" + str(_actual) + "份 · 粮库+" + _mod_format_points(_added_pts) + "点")
    print("[MapMod] 采矿场放入粮食: ", _actual, "份 ", _added_pts, "点")
    _mod_mine_dialogue_active = false
    _mod_mine_show_manage_food_dialog()


func _mod_mine_do_take_food()-> void:
    if _mod_mine_food.is_empty():
        _mod_msg("粮库是空的", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_show_manage_food_dialog()
        return
    var _player_goods: Array = WSData.get_player_goods()
    var _taken: int = 0
    var _taken_pts: int = _mod_get_edible_food_points(_mod_mine_food)
    for _food_entry in _mod_mine_food:
        var _uid: String = _food_entry.get("item",{}).get("uid", "")
        var _count: int = int(_food_entry.get("count", 0))
        if _count <= 0:
            continue

        var _found: bool = false
        for _goods_entry in _player_goods:
            if _goods_entry.get("item",{}).get("uid", "") == _uid:
                _goods_entry["count"] = int(_goods_entry.get("count", 0)) + _count
                _found = true
                break
        if not _found:
            _player_goods.append({"item": {"uid": _uid}, "count": _count})
        _taken += _count
    _mod_mine_food.clear()
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)
    _mod_msg("取出" + str(_taken) + "份(" + _mod_format_points(_taken_pts) + "点)")
    print("[MapMod] 采矿场取出粮食: ", _taken, "份 ", _taken_pts, "点")
    _mod_mine_dialogue_active = false
    _mod_mine_show_manage_food_dialog()






func _mod_mine_get_efficiency_modifier(_worker_count: int)-> float:
    if _worker_count <= 0:
        return 0.0
    var _total_eff: float = 0.0

    var _tier1: int = min(_worker_count, 30)
    _total_eff += float(_tier1) * 1.0

    if _worker_count > 30:
        var _tier2: int = min(_worker_count - 30, 50)
        _total_eff += float(_tier2) * 0.85

    if _worker_count > 80:
        var _tier3: int = min(_worker_count - 80, 70)
        _total_eff += float(_tier3) * 0.7

    if _worker_count > 150:
        var _tier4: int = min(_worker_count - 150, 70)
        _total_eff += float(_tier4) * 0.55

    if _worker_count > 220:
        var _tier5: int = _worker_count - 220
        _total_eff += float(_tier5) * 0.4
    return _total_eff / float(_worker_count)



func _mod_mine_consume_food_with_morale(_need: int)-> int:
    var _consumed: int = 0
    var _morale_weighted_sum: float = 0.0
    var _morale_total_count: int = 0
    var _remaining: int = _need
    while _remaining > 0 and not _mod_mine_food.is_empty():
        var _entry = _mod_mine_food[0]
        var _count: int = int(_entry.get("count", 0))
        var _uid: String = str(_entry.get("item",{}).get("uid", ""))

        var _impact: float = 10.0
        var _food_part = null
        if GlobalBsPart.bs_part_dic != null:
            _food_part = GlobalBsPart.bs_part_dic.get(_uid, null)
        if _food_part != null:
            _impact = float(_food_part.get("morale_impact", 10))
        if _count <= _remaining:
            _remaining -= _count
            _consumed += _count
            _morale_weighted_sum += _impact * float(_count)
            _morale_total_count += _count
            _mod_mine_food.remove_at(0)
        else:
            _entry["count"] = _count - _remaining
            _consumed += _remaining
            _morale_weighted_sum += _impact * float(_remaining)
            _morale_total_count += _remaining
            _remaining = 0


    if _morale_total_count > 0:
        var _avg_impact: float = _morale_weighted_sum / float(_morale_total_count)
        var _morale_delta: float =(_avg_impact - 10.0) * 0.5
        _mod_mine_morale = clampf(_mod_mine_morale + _morale_delta, 0.0, 100.0)

    if _consumed < _need:
        _mod_mine_morale = clampf(_mod_mine_morale - 20.0, 0.0, 100.0)
    return _consumed



func _mod_mine_calc_daily_ore_total()-> float:
    if _mod_mine_workers.is_empty():
        return 0.0

    var _base_total: float = 0.0
    for _worker in _mod_mine_workers:
        var _is_prisoner: bool = bool(_worker.get("is_prisoner", false))
        if _is_prisoner:
            _base_total += 0.4
        else:
            var _star: int = _mod_worker_star(_worker)
            match _star:
                1: _base_total += 0.2
                2: _base_total += 0.3
                3: _base_total += 0.5
                4: _base_total += 0.75
                5: _base_total += 1.0
                _: _base_total += 0.2

    var _eff: float = _mod_mine_get_efficiency_modifier(_mod_mine_workers.size())

    var _morale_mod: float = 1.0 if _mod_mine_morale >= 30.0 else 0.7

    var _tool_mod: float = _mod_mine_tool_durability / 100.0

    var _produced: float = _base_total * _eff * _morale_mod * _tool_mod * 1.4
    return _produced



func _mod_mine_calc_daily_ore()-> Dictionary:
    var _total: float = _mod_mine_calc_daily_ore_total()
    if _total <= 0.0:
        return {"copper": 0.0, "iron": 0.0, "silver": 0.0}

    var _copper_ratio: float = 0.5
    var _iron_ratio: float = 0.35
    var _silver_ratio: float = 0.15
    match _mod_mine_depth:
        1:
            _copper_ratio = 0.6
            _iron_ratio = 0.3
            _silver_ratio = 0.1
        2:
            _copper_ratio = 0.5
            _iron_ratio = 0.35
            _silver_ratio = 0.15
        3:
            _copper_ratio = 0.4
            _iron_ratio = 0.35
            _silver_ratio = 0.25
        4:
            _copper_ratio = 0.3
            _iron_ratio = 0.35
            _silver_ratio = 0.35
        _:
            _copper_ratio = 0.2
            _iron_ratio = 0.3
            _silver_ratio = 0.5
    var _copper: float = _total * _copper_ratio
    var _iron: float = _total * _iron_ratio
    var _silver: float = _total - _copper - _iron
    return {"copper": _copper, "iron": _iron, "silver": _silver}




func _mod_mine_calc_daily_food()-> int:
    var _soldier_count: int = 0
    var _prisoner_count: int = 0
    for _worker in _mod_mine_workers:
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
        else:
            _soldier_count += 1

    var _nop: int = _soldier_count + int(_prisoner_count * BSSoldierConfig.CAPTURE_FOOD_CONSUME_MULT)
    return int(_nop * 1.0 * FoodConfig.CONSUME_RATIO_CONFIG)


func _mod_mine_daily_settlement()-> void:

    var _today: int = int(WSData.system_counter)
    if _mod_last_mine_settlement_day == _today:
        print("[MapMod] 采矿场今日已结算, 跳过重复调用 (day=", _today, ")")
        return
    _mod_last_mine_settlement_day = _today

    if not _mod_mine_owned and _mod_mine_rent_end_day > 0.0:
        if WSData.system_counter >= _mod_mine_rent_end_day:
            print("[MapMod] 采矿场租期到期, 解散工人")
            _mod_mine_expire_rent()
            return
    if not _mod_mine_is_available():
        return
    if _mod_mine_workers.is_empty():
        return

    _mod_purge_duplicate_workers_daily(_mod_mine_workers, "采矿场")
    if _mod_mine_workers.is_empty():
        return
    print("[MapMod] 采矿场每日结算: workers=", _mod_mine_workers.size(), " depth=", _mod_mine_depth, " tool=", _mod_mine_tool_durability, " morale=", _mod_mine_morale, " water=", _mod_mine_water_level, " timber=", _mod_mine_timber_support)

    _mod_mine_tool_durability = clampf(_mod_mine_tool_durability - 5.0, 0.0, 100.0)

    var _food_result: Dictionary = _mod_consume_food_by_marching_system(_mod_mine_food, _mod_mine_workers)
    var _food_depleted_today: bool = bool(_food_result.get("depleted", false))
    if _food_depleted_today:
        _mod_mine_food_depleted = true
        _mod_mine_morale = clampf(_mod_mine_morale - 20.0, 0.0, 100.0)
        print("[MapMod] 采矿场粮食耗尽! 士气大幅下降")
    else:
        _mod_mine_food_depleted = false
        _mod_mine_morale = clampf(_mod_mine_morale + float(_food_result.get("morale_delta", 0.0)), 0.0, 100.0)

    _mod_mine_water_level = clampf(_mod_mine_water_level + 3.0 + float(_mod_mine_depth) * 2.0, 0.0, 100.0)

    _mod_mine_timber_support = clampf(_mod_mine_timber_support - float(_mod_mine_depth) * 5.0, 0.0, 100.0)

    var _waterlogged: bool = _mod_mine_water_level >= 80.0
    if not _waterlogged:

        var _raw_ore: Dictionary = _mod_mine_calc_daily_ore()
        var _produced_total: float = float(_raw_ore.get("copper", 0.0)) + float(_raw_ore.get("iron", 0.0)) + float(_raw_ore.get("silver", 0.0))

        if _produced_total > 0.0:
            if _mod_mine_vein_stock >= _produced_total:
                _mod_mine_vein_stock -= _produced_total
            else:

                var _ratio: float = _mod_mine_vein_stock / _produced_total
                _raw_ore["copper"] = float(_raw_ore.get("copper", 0.0)) * _ratio
                _raw_ore["iron"] = float(_raw_ore.get("iron", 0.0)) * _ratio
                _raw_ore["silver"] = float(_raw_ore.get("silver", 0.0)) * _ratio
                _produced_total = _mod_mine_vein_stock
                _mod_mine_vein_stock = 0.0
                _mod_msg("当前矿层已挖空!需加深矿井才能继续产出", 4.0, false)

        _mod_mine_ore_stock["copper"] = float(_mod_mine_ore_stock.get("copper", 0.0)) + float(_raw_ore.get("copper", 0.0))
        _mod_mine_ore_stock["iron"] = float(_mod_mine_ore_stock.get("iron", 0.0)) + float(_raw_ore.get("iron", 0.0))
        _mod_mine_ore_stock["silver"] = float(_mod_mine_ore_stock.get("silver", 0.0)) + float(_raw_ore.get("silver", 0.0))
        print("[MapMod] 采矿场产出矿石: ", _raw_ore, " 存量: ", _mod_mine_ore_stock, " 矿脉: ", _mod_mine_vein_stock)
    else:
        print("[MapMod] 采矿场透水停工! 积水=", _mod_mine_water_level)
        _mod_msg("采矿场积水严重,当天停工!", 3.0, false)


    var _cave_in_rate: float = 0.02 + float(_mod_mine_depth) * 0.01
    if _mod_mine_timber_support >= 100.0:
        _cave_in_rate -= 0.02
    if _mod_mine_timber_support <= 0.0:
        _cave_in_rate += 0.05
    _cave_in_rate = maxf(_cave_in_rate, 0.0)

    _cave_in_rate = minf(_cave_in_rate, 0.2)
    if randf() < _cave_in_rate:

        var _loss: int =(randi() % 3) + 1
        _loss = min(_loss, _mod_mine_workers.size())
        var _dead_count: int = 0
        var _injured_count: int = 0
        for _i in range(_loss):
            if not _mod_mine_workers.is_empty():
                var _victim_idx: int = _mod_mine_workers.size() - 1
                var _victim = _mod_mine_workers[_victim_idx]
                var _is_prisoner: bool = bool(_victim.get("is_prisoner", false))

                if randf() < 0.5:
                    _dead_count += 1
                    _mod_mine_workers.remove_at(_victim_idx)
                    if _is_prisoner:
                        print("[MapMod] 采矿场塌方: 俘虏永久死亡: ", _victim.get("name", "未知"))
                    else:
                        print("[MapMod] 采矿场塌方: 士兵永久死亡: ", _victim.get("name", "未知"))
                else:
                    _injured_count += 1
                    _mod_mine_return_worker_to_player(_victim_idx)

        _mod_mine_ore_stock["copper"] = float(_mod_mine_ore_stock.get("copper", 0.0)) * 0.9
        _mod_mine_ore_stock["iron"] = float(_mod_mine_ore_stock.get("iron", 0.0)) * 0.9
        _mod_mine_ore_stock["silver"] = float(_mod_mine_ore_stock.get("silver", 0.0)) * 0.9
        var _cave_msg: String = "矿难发生!塌方损失" + str(_loss) + "名工人"
        if _dead_count > 0:
            _cave_msg += "(其中" + str(_dead_count) + "人永久死亡)"
        _cave_msg += ", 矿石存量-10%"
        _mod_msg(_cave_msg, 4.0, false)
        print("[MapMod] 采矿场塌方! 损失工人=", _loss, " 死亡=", _dead_count, " 受伤=", _injured_count, " 概率=", _cave_in_rate)

        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)

    _mod_mine_check_escape(_food_depleted_today)






func _mod_mine_get_intimidation_info(_food_depleted: bool = false)-> Dictionary:
    var _soldier_intim: int = 0
    var _prisoner_count: int = 0
    var _prisoner_demand: int = 0
    for _worker in _mod_mine_workers:
        var _star: int = _mod_worker_star(_worker)
        if bool(_worker.get("is_prisoner", false)):
            _prisoner_count += 1
            _prisoner_demand += _mod_intim_star_points(_star)
            continue
        _soldier_intim += _mod_intim_star_points(_star)
    var _intim_effective: float = float(_soldier_intim) *(0.5 if _food_depleted else 1.0)
    var _ratio: float = 0.0
    if _prisoner_demand > 0:
        _ratio = clampf(_intim_effective / float(_prisoner_demand), 0.0, 1.0)
    var _level: int = 0
    if _ratio >= MOD_LUMBER_MILL_INTIM_FULL:
        _level = 2
    elif _ratio >= MOD_LUMBER_MILL_INTIM_STRONG:
        _level = 1
    var _req_full: int = _prisoner_demand
    return {"intimidation": _soldier_intim, "intim_effective": _intim_effective, "prisoners": _prisoner_count, "ratio": _ratio, "demand": _prisoner_demand, "req_full": _req_full, "level": _level, "guides": 0}






func _mod_mine_check_escape(_food_depleted: bool)-> void:
    var _escaped_count: int = 0
    var _dead_count: int = 0

    var _intim: Dictionary = _mod_mine_get_intimidation_info(_food_depleted)

    var _i: int = _mod_mine_workers.size() - 1
    while _i >= 0:
        var _worker = _mod_mine_workers[_i]
        var _is_prisoner: bool = bool(_worker.get("is_prisoner", false))
        var _star: int = _mod_worker_star(_worker)
        var _escape_rate: float = 0.0
        if _is_prisoner:

            _escape_rate = 0.02

            if _food_depleted:
                _escape_rate = 0.08

            _escape_rate = _mod_escape_rate_after_suppression(_escape_rate, float(_intim.get("ratio", 0.0)))
        else:

            if _food_depleted:
                match _star:
                    1: _escape_rate = 0.06
                    2: _escape_rate = 0.04
                    3: _escape_rate = 0.02
                    4: _escape_rate = 0.0
                    5: _escape_rate = 0.0
                    _: _escape_rate = 0.06

        if _mod_mine_morale < 30.0 and _escape_rate > 0.0:
            _escape_rate *= 1.5

        if randf() < _escape_rate:
            _escaped_count += 1
            if _is_prisoner:
                _mod_mine_workers.remove_at(_i)
                print("[MapMod] 采矿场俘虏逃跑: ", _worker.get("name", "未知"))
            else:
                _mod_mine_return_worker_to_player(_i)
                print("[MapMod] 采矿场士兵逃跑(缺粮,回队伍): ", _worker.get("name", "未知"))
        _i -= 1

    var _worker_count: int = _mod_mine_workers.size()
    if _worker_count > 40:

        var _typhoon_mult: float = 3.0 if _mod_typhoon_active else 1.0

        var _morale_mult: float = 1.5 if _mod_mine_morale < 30.0 else 1.0
        var _j: int = _mod_mine_workers.size() - 1
        while _j >= 0:
            var _worker2 = _mod_mine_workers[_j]
            var _is_prisoner2: bool = bool(_worker2.get("is_prisoner", false))


            var _base_death_rate: float = 0.008
            if not _is_prisoner2:
                var _star2: int = _mod_worker_star(_worker2)
                match _star2:
                    1: _base_death_rate = 0.008
                    2: _base_death_rate = 0.006
                    3: _base_death_rate = 0.005
                    4: _base_death_rate = 0.003
                    5: _base_death_rate = 0.002
                    _: _base_death_rate = 0.008
            var _death_rate: float = _base_death_rate * _typhoon_mult * _morale_mult
            if randf() < _death_rate:
                _dead_count += 1

                _mod_mine_workers.remove_at(_j)
                if _is_prisoner2:
                    print("[MapMod] 采矿场俘虏意外死亡: ", _worker2.get("name", "未知"))
                else:
                    print("[MapMod] 采矿场士兵意外死亡(永久损失, star=", _mod_worker_star(_worker2), "): ", _worker2.get("name", "未知"))
            _j -= 1

    if _escaped_count > 0 and _dead_count > 0:
        _mod_msg("采矿场有" + str(_escaped_count) + "名工人逃跑, " + str(_dead_count) + "名工人意外死亡", 3.0, false)
    elif _escaped_count > 0:
        _mod_msg("采矿场有" + str(_escaped_count) + "名工人逃跑", 3.0, false)
    elif _dead_count > 0:
        var _dead_msg: String = "采矿场有" + str(_dead_count) + "名工人意外死亡"
        if _mod_typhoon_active:
            _dead_msg += "(台风天)"
        _mod_msg(_dead_msg, 3.0, false)
    if _escaped_count > 0 or _dead_count > 0:

        if is_instance_valid(player_team_node):
            player_team_node.refresh_team_info(false)



func _mod_return_ore_to_player()-> int:
    var _player_goods: Array = WSData.get_player_goods()
    var _ores: Array = [
        {"key": "copper", "uid": MOD_MINE_ORE_COPPER_UID},
        {"key": "iron", "uid": MOD_MINE_ORE_IRON_UID},
        {"key": "silver", "uid": MOD_MINE_ORE_SILVER_UID},
    ]
    var _total: int = 0
    var _changed: bool = false
    for _ore in _ores:
        var _key: String = _ore["key"]
        var _uid: String = _ore["uid"]
        var _stock_f: float = float(_mod_mine_ore_stock.get(_key, 0.0))
        var _count: int = int(_stock_f)
        if _count <= 0:
            continue
        if GlobalBsPart.bs_part_dic.get(_uid, null) == null:
            continue
        var _found: bool = false
        for _goods_json in _player_goods:
            if _goods_json.get("item",{}).get("uid", "") == _uid:
                _goods_json["count"] = int(_goods_json.get("count", 0)) + _count
                _found = true
                break
        if not _found:
            _player_goods.append({"item": {"uid": _uid}, "count": _count})
        _mod_mine_ore_stock[_key] = _stock_f - float(_count)
        _total += _count
        _changed = true
    if _changed:
        GoodsUtils.organize_goods(_player_goods)
        WSData.save_my_goods(_player_goods)
        if _total > 0:
            _mod_msg_add_goods("矿石", _total)
    return _total






func _mod_mine_expire_rent()-> void:
    var _soldier_list: Array = []
    var _capture: Array = WSData.get_capture()
    var _prisoner_back: int = 0
    for _worker in _mod_mine_workers:
        if not(_worker is Dictionary):
            continue
        if bool(_worker.get("is_prisoner", false)):
            _worker.erase("is_prisoner")
            _capture.append(_worker)
            _prisoner_back += 1
        else:
            _worker.erase("is_prisoner")
            _worker.erase("is_guide")
            _soldier_list.append(_worker)
    _mod_mine_workers.clear()
    if _prisoner_back > 0:
        WSData.update_capture(_capture)
    if not _soldier_list.is_empty():
        if is_instance_valid(player_team_node):
            player_team_node.add_soldier(_soldier_list)
        else:
            _mod_add_soldier_to_persistent(_soldier_list)

    var _food_back: int = _mod_return_food_to_player(_mod_mine_food)

    var _ore_back: int = _mod_return_ore_to_player()
    _mod_mine_capacity = 0
    _mod_mine_rent_end_day = -1.0
    var _msg: String = "采矿场租期已到,工人已解散"
    if not _soldier_list.is_empty() or _prisoner_back > 0:
        _msg += "(" + str(_soldier_list.size()) + "名士兵归队"
        if _prisoner_back > 0:
            _msg += ", " + str(_prisoner_back) + "名俘虏收回"
        _msg += ")"
    if _food_back > 0:
        _msg += "\n粮库食物" + str(_food_back) + "份已退回背包"
    if _ore_back > 0:
        _msg += "\n矿石" + str(_ore_back) + "个已入背包"
    _mod_msg(_msg, 5.0, false)
    print("[MapMod] 采矿场租期到期: 士兵=", _soldier_list.size(), " 俘虏=", _prisoner_back, " 退回食物=", _food_back, " 结算矿石=", _ore_back)

    if is_instance_valid(player_team_node):
        player_team_node.refresh_team_info(false)





func _mod_mine_show_maintenance_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _msg: String = "矿井维护\n"
    _msg += "深度: " + str(_mod_mine_depth) + "层  "
    _msg += "积水: " + str(int(_mod_mine_water_level)) + "/100  "
    _msg += "支撑: " + str(int(_mod_mine_timber_support)) + "/100"
    var _option_list: Array = []
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "加深矿井", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要加深矿井。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "排水", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要处理矿井积水。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "补充木材支撑", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我要补充矿井的木材支撑。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "了解采矿场", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我想了解一下采矿场怎么运作。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回主菜单", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["返回。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)

func _mod_mine_show_deepen_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _cost: int = _mod_mine_get_deepen_cost(_mod_mine_depth)
    var _msg: String = "加深矿井\n当前深度: " + str(_mod_mine_depth) + "层"
    _msg += "\n当前矿层剩余: " + str(int(_mod_mine_vein_stock)) + "/5000"
    _msg += "\n加深到第" + str(_mod_mine_depth + 1) + "层需" + str(_cost) + "金币"
    _msg += "\n新层满储量5000, 不恢复, 耗尽需再次加深"
    _msg += "\n深度越深矿难/积水更严重, 但矿层无限"
    var _option_list: Array = []
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "确认加深(" + str(_cost) + "金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["确认加深矿井到第" + str(_mod_mine_depth + 1) + "层。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_get_deepen_cost(_current_depth: int)-> int:
    match _current_depth:
        1: return 150000
        2: return 350000
        3: return 700000
        4: return 1400000

        var _n: return int(1400000.0 * pow(1.7, float(_current_depth - 4)))
        _: return int(1400000.0 * pow(1.7, float(_current_depth - 4)))


func _mod_mine_do_deepen()-> void:
    var _cost: int = _mod_mine_get_deepen_cost(_mod_mine_depth)
    var _player_money: int = WSData.get_player_money()
    if _player_money < _cost:
        _mod_msg("金币不足,无法加深!", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    WSData.update_money(- _cost, false)
    _mod_mine_depth += 1
    _mod_mine_vein_stock = MOD_MINE_VEIN_MAX
    _mod_msg("矿井已加深到" + str(_mod_mine_depth) + "层!\n花费" + str(_cost) + "金币\n新矿层储量: 5000")
    print("[MapMod] 采矿场加深矿井: depth=", _mod_mine_depth, " cost=", _cost, " vein=", _mod_mine_vein_stock)
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_show_drain_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0
    var _water_pct: int = int(_mod_mine_water_level)
    var _cost_per_pct: int = _mod_mine_depth * 150
    var _total_cost: int = _water_pct * _cost_per_pct
    var _msg: String = "矿井排水\n当前积水: " + str(_water_pct) + "/100"
    _msg += "\n每1%排水费用: 深度" + str(_mod_mine_depth) + "×150=" + str(_cost_per_pct) + "金"
    if _water_pct >= 80:
        _msg += "\n[警告]积水严重,已停工!"
    if _water_pct > 0:
        _msg += "\n排干全部积水需" + str(_total_cost) + "金币"
    else:
        _msg += "\n无积水,无需排水"
    var _option_list: Array = []
    if _water_pct > 0:
        _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "排干全部积水(" + str(_total_cost) + "金币)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["排干全部积水。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_do_drain()-> void:
    var _water_pct: int = int(_mod_mine_water_level)
    if _water_pct <= 0:
        _mod_msg("无积水,无需排水")
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    var _cost_per_pct: int = _mod_mine_depth * 150
    var _total_cost: int = _water_pct * _cost_per_pct
    var _player_money: int = WSData.get_player_money()
    if _player_money < _total_cost:
        _mod_msg("金币不足,无法排水!", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    WSData.update_money(- _total_cost, false)
    _mod_mine_water_level = 0.0
    _mod_msg("已排干积水!\n花费" + str(_total_cost) + "金币")
    print("[MapMod] 采矿场排水: pct=", _water_pct, " cost=", _total_cost)
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_show_timber_dialog()-> void:
    _mod_mine_dialogue_active = true
    _mod_dialogue_start_time = Time.get_ticks_msec() / 1000.0

    var _player_wood: int = 0
    var _player_goods: Array = WSData.get_player_goods()
    for _entry in _player_goods:
        var _uid: String = _entry.get("item",{}).get("uid", "")
        if _uid == "commodity_0013":
            _player_wood += int(_entry.get("count", 0))
    var _msg: String = "补充木材支撑\n当前支撑: " + str(int(_mod_mine_timber_support)) + "/100"
    _msg += "\n每根木材+5支撑, 每日消耗深度×5"
    _msg += "\n背包木材: " + str(_player_wood) + "根"
    if _mod_mine_timber_support >= 100.0:
        _msg += "\n支撑已满,无需补充"
    elif _player_wood <= 0:
        _msg += "\n无木材可补充"
    var _option_list: Array = []
    if _player_wood > 0 and _mod_mine_timber_support < 100.0:


        var _max_add: int = min(_player_wood, ceili((100.0 - _mod_mine_timber_support) / 5.0))
        if _max_add > 0:
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入5根木材(+25支撑)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入5根木材。"]}]})
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放入10根木材(+50支撑)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["放入10根木材。"]}]})
            _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "放满支撑(最多" + str(_max_add) + "根)", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["把能放的木材都放进去。"]}]})
    _option_list.append({"otype": DialogueConstants.OPTION_TYPE_ENUM.TALK, "oname": "返回", "turn": DialogueConstants.SPEAKER_ENUM.A, "content": [{"clist": ["我再考虑考虑。"]}]})
    var _options: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }
    var _greeting: Dictionary = {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": "mod_mine_manager",
        "content": [{"clist": [_msg]}],
        "next": _options,
    }
    var _right_info: Dictionary = {
        "leader_uid": "mod_mine_manager",
        "leader_name": "采矿场管理员",
        "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
    }
    dialogue_interface_node.cshow()
    GlobalTempData.update_dialogue_info(WSData.get_player_team_node().get_dialogue_info(), _right_info)
    dialogue_interface_node.init(_greeting, WSData.get_player_team_node().get_dialogue_info(), _right_info)


func _mod_mine_do_supply_timber(_count: int)-> void:
    var _player_goods: Array = WSData.get_player_goods()

    var _wood_indices: Array = []
    var _wood_total: int = 0
    for _i in range(_player_goods.size()):
        var _entry = _player_goods[_i]
        var _uid: String = _entry.get("item",{}).get("uid", "")
        if _uid == "commodity_0013":
            _wood_indices.append(_i)
            _wood_total += int(_entry.get("count", 0))


    var _max_by_support: int = ceili((100.0 - _mod_mine_timber_support) / 5.0)
    var _actual: int = min(_count, _wood_total, _max_by_support)
    if _actual <= 0:
        _mod_msg("无法补充木材: 木材不足或支撑已满", 3.0, false)
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return

    var _remaining: int = _actual
    while _remaining > 0 and not _wood_indices.is_empty():
        var _idx: int = _wood_indices[0]
        var _entry = _player_goods[_idx]
        var _count_in_entry: int = int(_entry.get("count", 0))
        if _count_in_entry <= _remaining:
            _remaining -= _count_in_entry
            _player_goods.remove_at(_idx)
            _wood_indices.remove_at(0)

            for _j in range(_wood_indices.size()):
                if _wood_indices[_j] > _idx:
                    _wood_indices[_j] -= 1
        else:
            _entry["count"] = _count_in_entry - _remaining
            _remaining = 0

    _mod_mine_timber_support = clampf(_mod_mine_timber_support + float(_actual) * 5.0, 0.0, 100.0)
    GoodsUtils.organize_goods(_player_goods)
    WSData.save_my_goods(_player_goods)
    _mod_msg("补充木材" + str(_actual) + "根\n支撑+" + str(_actual * 5) + "\n当前支撑" + str(int(_mod_mine_timber_support)) + "/100")
    print("[MapMod] 采矿场补充木材: count=", _actual, " support=", _mod_mine_timber_support)
    _mod_mine_dialogue_active = false
    _mod_mine_return_to_main()


func _mod_mine_handle_dialogue_finish()-> void:
    var _oname: String = dialogue_interface_node.last_selected_oname
    print("[MapMod][采矿场] 对话结束路由: oname=", _oname)
    if is_instance_valid(special_build_interface_node) and special_build_interface_node.visible:
        special_build_interface_node.unchoose_charactar_card()

    if _oname == "租用采矿场":
        _mod_mine_dialogue_active = false
        _mod_mine_show_rent_dialog()
        return
    if _oname == "购买采矿场":
        _mod_mine_dialogue_active = false
        _mod_mine_show_buy_dialog()
        return
    if _oname == "了解采矿场":
        _mod_mine_dialogue_active = false
        _mod_mine_show_tutorial_dialog()
        return
    if _oname == "管理工人":
        _mod_mine_dialogue_active = false
        _mod_mine_show_manage_workers_dialog()
        return
    if _oname == "管理粮库":
        _mod_mine_dialogue_active = false
        _mod_mine_show_manage_food_dialog()
        return
    if _oname == "取出矿石":
        _mod_mine_dialogue_active = false
        _mod_mine_take_ore()
        return
    if _oname == "补给工具":
        _mod_mine_dialogue_active = false
        _mod_mine_show_supply_tools_dialog()
        return
    if _oname == "矿井维护":
        _mod_mine_dialogue_active = false
        _mod_mine_show_maintenance_dialog()
        return
    if _oname == "返回主菜单":
        _mod_mine_dialogue_active = false
        _mod_mine_show_manager_dialog()
        return
    if _oname == "加深矿井":
        _mod_mine_dialogue_active = false
        _mod_mine_show_deepen_dialog()
        return
    if _oname == "排水":
        _mod_mine_dialogue_active = false
        _mod_mine_show_drain_dialog()
        return
    if _oname == "补充木材支撑":
        _mod_mine_dialogue_active = false
        _mod_mine_show_timber_dialog()
        return
    if _oname == "查看状态":
        _mod_mine_dialogue_active = false
        _mod_mine_show_status_dialog()
        return

    if _oname == "租用1天(1500金币)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_rent(1, 1500, 30)
        return
    if _oname == "租用7天(18000金币)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_rent(7, 18000, 80)
        return
    if _oname == "租用30天(80000金币)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_rent(30, 80000, 150)
        return
    if _oname == "租用90天(180000金币)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_rent(90, 180000, 220)
        return
    if _oname == "确认购买(150万金币)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_buy()
        return

    if _oname == "确认补给工具(50金/把)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_supply_tools()
        return

    if _oname.begins_with("确认加深"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_deepen()
        return

    if _oname.begins_with("排干全部积水"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_drain()
        return

    if _oname == "放入5根木材(+25支撑)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_supply_timber(5)
        return
    if _oname == "放入10根木材(+50支撑)":
        _mod_mine_dialogue_active = false
        _mod_mine_do_supply_timber(10)
        return
    if _oname.begins_with("放满支撑"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_supply_timber(99999)
        return

    if _oname == "派士兵工作":
        _mod_mine_dialogue_active = false
        _mod_mine_show_send_soldier_dialog()
        return
    if _oname == "派俘虏工作":
        _mod_mine_dialogue_active = false
        _mod_mine_show_send_prisoner_dialog()
        return
    if _oname == "召回全部士兵":
        _mod_mine_dialogue_active = false
        _mod_mine_do_recall_soldiers()
        return
    if _oname == "召回全部俘虏":
        _mod_mine_dialogue_active = false
        _mod_mine_do_recall_prisoners()
        return

    if _oname == "放入粮食":
        _mod_mine_dialogue_active = false
        _mod_mine_show_put_food_dialog()
        return
    if _oname == "取出全部粮食":
        _mod_mine_dialogue_active = false
        _mod_mine_do_take_food()
        return

    if _oname == "派10名士兵":
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_soldiers(10)
        return
    if _oname == "派50名士兵":
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_soldiers(50)
        return
    if _oname == "派100名士兵":
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_soldiers(100)
        return
    if _oname.begins_with("派全部士兵"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_soldiers(99999)
        return

    if _oname == "派10名俘虏":
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_prisoners(10)
        return
    if _oname == "派50名俘虏":
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_prisoners(50)
        return
    if _oname.begins_with("派全部俘虏"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_send_prisoners(99999)
        return

    if _oname.begins_with("放入50份"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_put_food(50)
        return
    if _oname.begins_with("放入100份"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_put_food(100)
        return
    if _oname.begins_with("放入500份"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_put_food(500)
        return

    if _oname.begins_with("放入够"):
        _mod_mine_dialogue_active = false
        var _days_target: int = _oname.split("够")[1].split("天")[0].to_int()
        if _days_target <= 0:
            _days_target = 30
        var _daily_rt: int = _mod_mine_calc_daily_food()
        if _daily_rt <= 0:
            _mod_msg("无工人不消耗粮食, 无需放入", 3.0, false)
        else:
            var _need_rt: int = maxi(_daily_rt * _days_target - _mod_get_edible_food_points(_mod_mine_food), 0)
            if _need_rt <= 0:
                _mod_msg("存粮已够" + str(_days_target) + "天, 无需放入")
            else:
                var _bag_pts_rt: int = _mod_get_edible_food_points(WSData.get_player_goods())
                var _bag_cnt_rt: int = _mod_mine_count_player_food()
                if _bag_pts_rt <= 0 or _bag_cnt_rt <= 0:
                    _mod_msg("背包无可食用粮食", 3.0, false)
                else:
                    var _avg_rt: float = float(_bag_pts_rt) / float(_bag_cnt_rt)
                    _mod_mine_do_put_food(ceili(_need_rt / maxf(_avg_rt, 1.0)))
        return
    if _oname.begins_with("放入全部粮食"):
        _mod_mine_dialogue_active = false
        _mod_mine_do_put_food(99999)
        return

    if _oname == "返回管理":
        _mod_mine_dialogue_active = false
        if _mod_mine_manage_context == "food":
            _mod_mine_show_manage_food_dialog()
        else:
            _mod_mine_show_manage_workers_dialog()
        return

    if _oname == "明白了":
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return

    if _oname == "告辞":
        _mod_mine_dialogue_active = false

        if mod_mine_interface_node != null and is_instance_valid(mod_mine_interface_node):
            mod_mine_interface_node.hide_interface()
        return
    if _oname == "返回":
        _mod_mine_dialogue_active = false
        _mod_mine_return_to_main()
        return
    _mod_mine_dialogue_active = false











func _mod_lumber_mill_consume_food(_amount: int)-> void:
    var _remaining: int = _amount
    while _remaining > 0 and not _mod_lumber_mill_food.is_empty():
        var _entry = _mod_lumber_mill_food[0]
        var _count: int = int(_entry.get("count", 0))
        if _count <= _remaining:
            _remaining -= _count
            _mod_lumber_mill_food.remove_at(0)
        else:
            _entry["count"] = _count - _remaining
            _remaining = 0




func _mod_init_lumber_mill(_world_data: Dictionary)-> void:
    if _world_data.has("mod_lumber_mill_owned"):
        _mod_lumber_mill_owned = bool(_world_data.get("mod_lumber_mill_owned", false))
    if _world_data.has("mod_lumber_mill_rent_end_day"):
        _mod_lumber_mill_rent_end_day = float(_world_data.get("mod_lumber_mill_rent_end_day", -1.0))
    if _world_data.has("mod_lumber_mill_capacity"):
        _mod_lumber_mill_capacity = int(_world_data.get("mod_lumber_mill_capacity", 0))
    if _world_data.has("mod_lumber_mill_workers"):
        var _workers_data = _world_data.get("mod_lumber_mill_workers",[])
        _mod_lumber_mill_workers = _workers_data.duplicate(true) if _workers_data is Array else[]
    if _world_data.has("mod_lumber_mill_food"):
        var _food_data = _world_data.get("mod_lumber_mill_food",[])
        _mod_lumber_mill_food = _food_data.duplicate(true) if _food_data is Array else[]
    if _world_data.has("mod_lumber_mill_wood"):
        _mod_lumber_mill_wood = float(_world_data.get("mod_lumber_mill_wood", 0.0))
    if _world_data.has("mod_lumber_mill_food_depleted"):
        _mod_lumber_mill_food_depleted = bool(_world_data.get("mod_lumber_mill_food_depleted", false))
    if _world_data.has("mod_lumber_mill_prisoners_out"):
        _mod_lumber_mill_prisoners_out = int(_world_data.get("mod_lumber_mill_prisoners_out", 0))

    if _world_data.has("mod_lumber_mill_forest_stock"):
        _mod_lumber_mill_forest_stock = float(_world_data.get("mod_lumber_mill_forest_stock", MOD_LUMBER_MILL_FOREST_MAX))
    if _world_data.has("mod_lumber_mill_tool_durability"):
        _mod_lumber_mill_tool_durability = float(_world_data.get("mod_lumber_mill_tool_durability", 100.0))
    if _world_data.has("mod_lumber_mill_morale"):
        _mod_lumber_mill_morale = float(_world_data.get("mod_lumber_mill_morale", 50.0))
    print("[MapMod] 伐木场初始化: owned=", _mod_lumber_mill_owned, " rent_end=", _mod_lumber_mill_rent_end_day, " capacity=", _mod_lumber_mill_capacity, " workers=", _mod_lumber_mill_workers.size(), " wood=", _mod_lumber_mill_wood, " forest=", _mod_lumber_mill_forest_stock, " tool=", _mod_lumber_mill_tool_durability, " morale=", _mod_lumber_mill_morale)

    if GlobalBsPart.bs_part_dic != null:
        for _uid in GlobalBsPart.bs_part_dic.keys():
            var _part = GlobalBsPart.bs_part_dic.get(_uid)
            if _part != null:
                var _name = str(_part.get("name", ""))
                if _name.find("木") >= 0 or _name.find("材") >= 0 or _uid.find("wood") >= 0 or _uid.find("timber") >= 0:
                    print("[MapMod] DEBUG 物品库发现木材类: uid=", _uid, " name=", _name, " price=", _part.get("price", 0))


func _mod_init_typhoon(_world_data: Dictionary)-> void:

    if _world_data.has("mod_typhoon_active"):
        _mod_typhoon_active = bool(_world_data.get("mod_typhoon_active", false))
    if _world_data.has("mod_typhoon_end_day"):
        _mod_typhoon_end_day = float(_world_data.get("mod_typhoon_end_day", -1.0))
    if _world_data.has("mod_typhoon_prev_weather"):
        _mod_typhoon_prev_weather = int(_world_data.get("mod_typhoon_prev_weather", 0))

    if _mod_typhoon_active and _mod_typhoon_end_day > 0.0 and _mod_typhoon_end_day <= WSData.system_counter:
        print("[MapMod] 台风在加载时已过期(end_day=", _mod_typhoon_end_day, " <= counter=", WSData.system_counter, "), 自动结束")
        _mod_end_typhoon()

    if _mod_typhoon_active:
        _mod_apply_typhoon_weather()
        print("[MapMod] 台风状态恢复: active=true end_day=", _mod_typhoon_end_day)
    print("[MapMod] 台风初始化完成: active=", _mod_typhoon_active, " end_day=", _mod_typhoon_end_day)








func _mod_check_typhoon_daily()-> void:
    if _mod_typhoon_active:

        if _mod_typhoon_end_day > 0.0 and WSData.system_counter >= _mod_typhoon_end_day:
            _mod_end_typhoon()
    else:

        if randf() < MOD_TYPHOON_DAILY_CHANCE:
            _mod_start_typhoon()


func _mod_start_typhoon()-> void:
    _mod_typhoon_active = true
    _mod_typhoon_end_day = WSData.system_counter + MOD_TYPHOON_DURATION_DAYS

    if is_instance_valid(weather_executor_node):
        _mod_typhoon_prev_weather = int(weather_executor_node.current_weather)
    _mod_apply_typhoon_weather()
    _mod_msg("台风来袭!港口已封锁,暴雨肆虐中...", 4.0, false)
    print("[MapMod] 台风开始: end_day=", _mod_typhoon_end_day)


func _mod_end_typhoon()-> void:
    _mod_typhoon_active = false

    if is_instance_valid(weather_executor_node):
        change_weather(_mod_typhoon_prev_weather)
        weather_executor_node.current_weather = _mod_typhoon_prev_weather

    _mod_apply_typhoon_damage()
    _mod_msg("台风已过,港口恢复通行", 4.0, false)
    print("[MapMod] 台风结束, 港口恢复")


func _mod_apply_typhoon_weather()-> void:
    if is_instance_valid(mwb_rain_root_node):
        mwb_rain_root_node.update_weather(MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN)
    if is_instance_valid(mw_top_box_node):
        mw_top_box_node.update_weather(MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN)
    if is_instance_valid(player_team_node):
        player_team_node.open_weather_light2d()
    if is_instance_valid(weather_executor_node):
        weather_executor_node.current_weather = MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN


func _mod_apply_typhoon_damage()-> void:
    if not is_instance_valid(player_team_node):
        return

    if not _mod_player_on_island:
        print("[MapMod] 台风物资损失: 玩家不在岛屿, 跳过")
        return

    var _player_money: int = WSData.get_player_money()
    var _money_loss_rate: int = CommonUtils.random_num2(0, 3)
    var _money_loss: int = int(_player_money * _money_loss_rate / 100.0)
    if _money_loss > 0:
        WSData.update_money(- _money_loss, false)
        _mod_msg("台风肆虐,损失金币: " + str(_money_loss), 3.0, false)

    var _player_goods: Array = WSData.get_player_goods()
    var _food_loss_total: int = 0
    for _goods_json in _player_goods:
        if not(_goods_json is Dictionary):
            continue
        var _item_json = _goods_json.get("item", null)
        if _item_json == null or not(_item_json is Dictionary):
            continue
        var _uid: String = _item_json.get("uid", "")
        if _uid.is_empty():
            continue
        var _etype = WeaponTypeConstants.get_etype(_uid)
        if _etype == WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.FOOD:
            var _count: int = int(_goods_json.get("count", 0))
            var _loss: int = int(float(_count) * 0.03)
            if _loss > 0:
                _goods_json["count"] = _count - _loss
                _food_loss_total += _loss
    if _food_loss_total > 0:
        GoodsUtils.organize_goods(_player_goods)
        WSData.save_my_goods(_player_goods)
        _mod_msg("台风肆虐,损失食物: " + str(_food_loss_total), 3.0, false)
    print("[MapMod] 台风物资损失: money=", _money_loss, " food=", _food_loss_total)







func _mod_init_mine(_world_data: Dictionary)-> void:
    if _world_data.has("mod_mine_owned"):
        _mod_mine_owned = bool(_world_data.get("mod_mine_owned", false))
    if _world_data.has("mod_mine_rent_end_day"):
        _mod_mine_rent_end_day = float(_world_data.get("mod_mine_rent_end_day", -1.0))
    if _world_data.has("mod_mine_capacity"):
        _mod_mine_capacity = int(_world_data.get("mod_mine_capacity", 0))
    if _world_data.has("mod_mine_workers"):
        var _workers_data = _world_data.get("mod_mine_workers",[])
        _mod_mine_workers = _workers_data.duplicate(true) if _workers_data is Array else[]
    if _world_data.has("mod_mine_food"):
        var _food_data = _world_data.get("mod_mine_food",[])
        _mod_mine_food = _food_data.duplicate(true) if _food_data is Array else[]
    if _world_data.has("mod_mine_food_depleted"):
        _mod_mine_food_depleted = bool(_world_data.get("mod_mine_food_depleted", false))
    if _world_data.has("mod_mine_prisoners_out"):
        _mod_mine_prisoners_out = int(_world_data.get("mod_mine_prisoners_out", 0))
    if _world_data.has("mod_mine_tool_durability"):
        _mod_mine_tool_durability = float(_world_data.get("mod_mine_tool_durability", 100.0))
    if _world_data.has("mod_mine_morale"):
        _mod_mine_morale = float(_world_data.get("mod_mine_morale", 50.0))
    if _world_data.has("mod_mine_ore_stock"):
        var _ore_data = _world_data.get("mod_mine_ore_stock",{})
        if _ore_data is Dictionary:
            _mod_mine_ore_stock = _ore_data.duplicate(true)

            if _mod_mine_ore_stock.has("ore") and not _mod_mine_ore_stock.has("copper"):
                var _old_ore: float = float(_mod_mine_ore_stock.get("ore", 0.0))
                _mod_mine_ore_stock.erase("ore")
                _mod_mine_ore_stock["copper"] = _old_ore * 0.5
                _mod_mine_ore_stock["iron"] = _old_ore * 0.3
                _mod_mine_ore_stock["silver"] = _old_ore - _old_ore * 0.5 - _old_ore * 0.3
                if _old_ore > 0:
                    print("[MapMod] 采矿场旧格式矿石拆分: ore=", _old_ore, " -> copper/iron/silver")

            _mod_mine_ore_stock.erase("gold")
        else:
            _mod_mine_ore_stock = {"copper": 0.0, "iron": 0.0, "silver": 0.0}
    if _world_data.has("mod_mine_vein_stock"):
        _mod_mine_vein_stock = float(_world_data.get("mod_mine_vein_stock", MOD_MINE_VEIN_MAX))
    if _world_data.has("mod_mine_depth"):
        _mod_mine_depth = int(_world_data.get("mod_mine_depth", 1))
    if _world_data.has("mod_mine_timber_support"):
        _mod_mine_timber_support = float(_world_data.get("mod_mine_timber_support", 100.0))
    if _world_data.has("mod_mine_water_level"):
        _mod_mine_water_level = float(_world_data.get("mod_mine_water_level", 0.0))

    _mod_mine_food_total = 0
    for _food_entry in _mod_mine_food:
        if _food_entry is Dictionary:
            _mod_mine_food_total += int(_food_entry.get("count", 0))
    print("[MapMod] 采矿场初始化: owned=", _mod_mine_owned, " rent_end=", _mod_mine_rent_end_day, " capacity=", _mod_mine_capacity, " workers=", _mod_mine_workers.size(), " depth=", _mod_mine_depth, " vein=", _mod_mine_vein_stock)








func _mod_init_mint(_world_data: Dictionary)-> void:
    _mod_mint_loc_data.clear()
    _mod_mint_current_loc = ""
    _mod_mint_slots = []
    _mod_mint_today_income = 0
    _mod_mint_total_income = 0
    _mod_last_mint_settlement_day = -1
    _mod_mint_legacy_ore = 0
    _mod_mint_legacy_wood = 0


    if _world_data.has("mod_mint_loc_data"):
        var _saved: Dictionary = _world_data.get("mod_mint_loc_data",{})
        for _loc_code in _saved.keys():
            var _d = _saved[_loc_code]
            if not(_d is Dictionary):
                continue
            var _entry: Dictionary = _mod_mint_loc_entry(str(_loc_code))
            _entry["slots"] = _mod_mint_migrate_slots(_d.get("slots",[]))
            _entry["today_income"] = int(_d.get("today_income", 0))
            _entry["total_income"] = int(_d.get("total_income", 0))
            _entry["last_day"] = int(_d.get("last_day", -1))
            _entry["legacy_ore"] = int(_d.get("legacy_ore", 0))
            _entry["legacy_wood"] = int(_d.get("legacy_wood", 0))
        print("[MapMod] 铸钱厂初始化(v32每村独立): 村数=", _mod_mint_loc_data.size())
        return


    var _legacy_slots: Array = _mod_mint_migrate_slots(_world_data.get("mod_mint_slots",[]))
    var _legacy_today: int = int(_world_data.get("mod_mint_today_income", 0))
    var _legacy_total: int = int(_world_data.get("mod_mint_total_income", 0))

    var _legacy_money: int = int(_world_data.get("mod_mint_money_box", 0))
    if _legacy_money > 0:
        if _legacy_slots.is_empty():
            _legacy_slots.append({"ore": 0, "ingot": 0, "wood": 0, "out_ingot": 0, "money": _legacy_money})
        else:
            _legacy_slots[0]["money"] = int(_legacy_slots[0].get("money", 0)) + _legacy_money
    var _target_loc: String = _mod_mint_first_mint_loc()
    if _target_loc == "":

        var _fiefs: Array = SoldierUtils.get_player_fief_code_list()
        _target_loc = str(_fiefs[0]) if _fiefs.size() > 0 else ""
    if _target_loc == "":
        print("[MapMod] 铸钱厂旧档迁移: 无可用村庄, 旧数据暂不迁移")
        return
    var _entry2: Dictionary = _mod_mint_loc_entry(_target_loc)
    _entry2["slots"] = _legacy_slots
    _entry2["today_income"] = _legacy_today
    _entry2["total_income"] = _legacy_total

    var _legacy_ore_f: float = float(_world_data.get("mod_mint_copper_stock", 0.0))
    var _legacy_wood: int = int(_world_data.get("mod_mint_wood_stock", 0))
    for _slot: Dictionary in _legacy_slots:
        if _legacy_ore_f < 1.0 and _legacy_wood <= 0:
            break
        if int(_slot.get("ore", 0)) <= 0 and int(_slot.get("ingot", 0)) <= 0 \
        and int(_slot.get("out_ingot", 0)) <= 0 and int(_slot.get("money", 0)) <= 0:
            var _fill_ore: int = mini(int(_legacy_ore_f), _mod_mint_input_cap_for_loc(_target_loc))
            var _fill_wood: int = mini(_legacy_wood, 2)
            _slot["ore"] = _fill_ore
            _slot["wood"] = _fill_wood
            _legacy_ore_f -= float(_fill_ore)
            _legacy_wood -= _fill_wood
    _entry2["legacy_ore"] = maxi(int(_legacy_ore_f), 0)
    _entry2["legacy_wood"] = maxi(_legacy_wood, 0)
    print("[MapMod] 铸钱厂旧档迁移(v32): → 村庄 ", _target_loc, " slots=", _legacy_slots.size(), " total_income=", _legacy_total, " legacy_return=(ore ", _entry2["legacy_ore"], ", wood ", _entry2["legacy_wood"], ")")