class_name SettingsInterface extends Control

@onready var common_settings_v_box_container: VBoxContainer =$SettingsPage / BaseScrollContainer / VBoxContainer / CommonSettingsRoot / VBoxContainer
@onready var battle_settings_v_box_container: VBoxContainer =$SettingsPage / BaseScrollContainer / VBoxContainer / BattleSettingsRoot / VBoxContainer
@onready var part_select_button_list_node: PartSelectButtonList =$PartSelectButtonList
@onready var settings_page_node: Control =$SettingsPage
@onready var instructions_page_node: Control =$InstructionsPage
@onready var d_log_page_node: Control =$DLogPage
@onready var special_function_page_node: Control =$SpecialFunctionPage
@onready var repair_goods_count_confirm_box_node: ConfirmBox =$RepairGoodsCountConfirmBox

signal close_page_sign()

var _force_repair_btn_added: bool = false

func _ready()-> void:
    for _node in common_settings_v_box_container.get_children():
        if _node is SliderButton:
            _node.connect("change_end_sign", _change_end)
        elif _node is SettingSwitch:
            _node.connect("switch_sign", _switch)

    for _node in battle_settings_v_box_container.get_children():
        if _node is SliderButton:
            _node.connect("change_end_sign", _change_end)
        elif _node is SettingSwitch:
            _node.connect("switch_sign", _switch)



func cshow()-> void:
    load_config()
    part_select_button_list_node.select(0)
    self.show()

func chide()-> void:
    GlobalSave.save_player_config()
    self.hide()

func load_config()-> void:
    for _node in common_settings_v_box_container.get_children():
        _node.update_value(GlobalPlayerConfig.get(_node.setting_field))

    for _node in battle_settings_v_box_container.get_children():
        _node.update_value(GlobalPlayerConfig.get(_node.setting_field))

func _change_end(_field: String, _value: int)-> void:
    GlobalPlayerConfig.update_config(_field, _value)
    match _field:
        "sfx_value":
            SystemUtils.set_sfx_volume(_value, true)
        "bg_music_value":
            SystemUtils.set_bg_music_volume(_value)

func _switch(_field: String, _value: bool)-> void:
    GlobalPlayerConfig.update_config(_field, _value)
    match _field:
        "is_show_fps":
            GlobalMessageInterface.show_or_hide_fps(GlobalPlayerConfig.is_show_fps)
        "enable_screen_rotation":
            SystemUtils.enable_screen_rotation(GlobalPlayerConfig.enable_screen_rotation)

func _on_close_button_pressed()-> void:
    chide()
    close_page_sign.emit()

func _on_part_select_button_list_choose_sign(_value: String)-> void:
    instructions_page_node.hide()
    settings_page_node.hide()
    d_log_page_node.hide()
    special_function_page_node.hide()

    match _value:
        "settings":
            settings_page_node.show()
            $SettingsPage / BaseScrollContainer.scroll_vertical = 0
        "instructions":
            instructions_page_node.show()
            $InstructionsPage / BaseScrollContainer.scroll_vertical = 0
        "dLog":
            d_log_page_node.show()
            $DLogPage / BaseScrollContainer.scroll_vertical = 0
        "specialFunction":
            special_function_page_node.show()
            $SpecialFunctionPage / BaseScrollContainer.scroll_vertical = 0
            _ensure_force_repair_button()


func _ensure_force_repair_button()-> void:
    if _force_repair_btn_added:
        return
    _force_repair_btn_added = true




    var _btn: Button = Button.new()
    _btn.text = "重载游戏(修复切后台卡死/白屏/人物消失)"
    _btn.custom_minimum_size = Vector2(0, 70)
    _btn.add_theme_font_size_override("font_size", 18)
    _btn.add_theme_color_override("font_color", Color(1, 0.3, 0.3))
    _btn.add_theme_color_override("font_hover_color", Color(1, 0.5, 0.5))
    _btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _btn.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    _btn.offset_top = -80
    _btn.offset_bottom = -10
    _btn.offset_left = 10
    _btn.offset_right = -10
    _btn.pressed.connect(_on_reload_game_button_pressed)
    special_function_page_node.add_child(_btn)


func _on_reload_game_button_pressed()-> void:



    if GlobalNode.game_root != null and is_instance_valid(GlobalNode.game_root):
        GlobalNode.game_root.load_recent_save()



func _on_special_function_interface_repair_goods_count_sign()-> void:
    repair_goods_count_confirm_box_node.show()


func _on_repair_goods_count_confirm_box_confirm()-> void:
    WSData.delete_goods_count_ge(1000)