class_name SponsorInfo extends Control

signal close_page_sign()

func _on_close_button_pressed()-> void:
    close_page_sign.emit()