class_name SponsorInterface extends Control

@onready var part_select_button_list_for_scroll_node: PartSelectButtonList =$ButtonScrollContainer / PartSelectButtonListForScroll
@onready var grid_container_node: GridContainer =$Background / SponsorScrollContainer / HFlowContainer / GridContainer
@onready var title_node: Label =$Background / SponsorScrollContainer / HFlowContainer / Control / Title
@onready var button_scroll_container_node: ScrollContainer =$ButtonScrollContainer
@onready var sponsor_scroll_container_node: ScrollContainer =$Background / SponsorScrollContainer

const SPONSOR_NAME = preload("res://tscn/game/SponsorName.tscn")

signal close_page_sign()

func _ready()-> void:
    var _date_str_list: = SponsorData.SPONSOR_DATA.keys()
    var _new_date_list: = []
    for _date_str: String in _date_str_list:
        _new_date_list.append(
            {
                "name": _date_str,
                "value": _date_str,
            }
        )
    part_select_button_list_for_scroll_node.init(_new_date_list)

func cshow()-> void:
    self.show()
    part_select_button_list_for_scroll_node.select(0, true)
    part_select_button_list_for_scroll_node._resize()

func chide()-> void:
    CommonUtils.clear_node(grid_container_node)
    self.hide()
    close_page_sign.emit()
    button_scroll_container_node.scroll_vertical = 0
    sponsor_scroll_container_node.scroll_vertical = 0

func _on_part_select_button_list_for_scroll_choose_sign(_value: String)-> void:
    CommonUtils.set_text(title_node, _value + " 赞助者名单")

    CommonUtils.clear_node(grid_container_node)
    var _name_list: Array = SponsorData.SPONSOR_DATA.get(_value)
    for _name: String in _name_list:
        var _node: Label = SPONSOR_NAME.instantiate()
        grid_container_node.add_child(_node)
        CommonUtils.set_text(_node, _name)

    sponsor_scroll_container_node.scroll_vertical = 0

func _on_close_button_custom_pressed()-> void:
    chide()