class_name StartInterface extends Control

const START_INTERFACE_BATTLE_NODE_PRE = preload("res://tscn/game/StartInterfaceBattle.tscn")

@onready var title_node: Label =$CanvasLayer / StartAnimationModule / Title
@onready var content_node: Label =$CanvasLayer / StartAnimationModule / Content
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

@onready var mask_node: ColorRect =$CanvasLayer / StartAnimationModule / Mask
@onready var create_character_interface_node: CreateCharacterInterface =$CanvasLayer / ChildPageRoot / CreateCharacterInterface
@onready var load_game_interface_node: LoadGameInterface =$CanvasLayer / ChildPageRoot / LoadGameInterface






@onready var tips_node: Label =$CanvasLayer / StartAnimationModule / Tips
@onready var tips_animation_player_node: AnimationPlayer =$CanvasLayer / StartAnimationModule / Tips / TipsAnimationPlayer
@onready var settings_interface_node: SettingsInterface =$CanvasLayer / ChildPageRoot / SettingsInterface
@onready var heart_avatar_button_node: CommonButton =$CanvasLayer / HeartAvatarButton
@onready var sponsor_info_node: Control =$CanvasLayer / ChildPageRoot / SponsorInfo
@onready var wall_extend_node: TextureRect =$CanvasLayer / LeftRoot / WallExtend
@onready var version_node: Label =$CanvasLayer / StartAnimationModule / Version
@onready var sponsor_interface_node: SponsorInterface =$CanvasLayer / ChildPageRoot / SponsorInterface
@onready var custom_team_interface_node: CustomTeamInterface =$CanvasLayer / ChildPageRoot / CustomTeamInterface
@onready var button_root_node: Control =$CanvasLayer / LeftRoot / ButtonRoot
@onready var battle_scene_mask_node: Control =$CanvasLayer / BattleSceneMask
@onready var left_root_node: Control =$CanvasLayer / LeftRoot


var conent = "目前游戏处于开发初期阶段\n许多功能尚未完善, 敬请谅解"
var title = "AMFIG"
var current_wall_pic_index: = -1
var wall_pic_list: = []
var start_interface_battle_node: StartInterfaceBattle = null

var is_to_world: = false
var is_first_open_custom_battle_page: = true



signal enter_new_world_sign()

signal enter_save_world_sign()
signal allow_load_world_sign()
signal enter_world_ani_finish_sign()
signal recover_animation_part01_finish_sign(_is_to_world: bool)

func _ready()-> void:
    create_battle_scene()

    wall_pic_list = wall_extend_node.get_children()
    CommonUtils.set_text(title_node, title)

    if GameConfig.is_sponsor_edition:
        conent = "此版本为赞助者特供版\n请勿擅自修改, 分享或上传\n感谢您对作者的尊重与支持"

    CommonUtils.set_text(content_node, conent)
    _change_wall_pic()

    if GameConfig.SKIP_OPENING_CINEMATIC:
        mask_node.hide()
        _menu_show()
    else:
        animation_player_node.play("title_show")

    CommonUtils.set_text(version_node, "v" + ProjectSettings.get("application/config/version"))
    GlobalSoundManager.change_music(GlobalSoundManager.BG_MUSIC_TYPE_ENUM.DEFAULT)

    GlobalSave.load_custom_battle_data()

func create_battle_scene(_need_init_random: = true)-> void:
    var _node = START_INTERFACE_BATTLE_NODE_PRE.instantiate()
    add_child(_node)
    start_interface_battle_node = _node
    if _need_init_random:
        start_interface_battle_node.init_random()

    start_interface_battle_node.update_is_for_start_interface_battle(true)
    start_interface_battle_node.connect("back_to_main_menu_sign", _battle_scene_back_to_main_menu)

func play_ani_enter_wall_part01()-> void:
    animation_player_node.play("enter_world_wall_animation_part01")

func play_ani_enter_wall_part02()-> void:

    clear()
    animation_player_node.play("enter_world_wall_animation_part02")















func play_recover_node_animation_part01(_is_to_world: = false):
    is_to_world = _is_to_world
    animation_player_node.play("recover_animation_part01")

func play_recover_node_animation_part02():
    animation_player_node.play("recover_animation_part02")

    _menu_button_disable(false)


func clear()-> void:
    if CommonUtils.is_not_null(start_interface_battle_node):


        start_interface_battle_node.queue_free()
        start_interface_battle_node = null

func clear_custom_battle_soldier_box_list_node()-> void:
    custom_team_interface_node.clear_custom_battle_soldier_box_list_node()



func _battle_scene_back_to_main_menu(_need_create_new_battle: = true)-> void:
    _allow_control_battle(false)
    _menu_show()
    _show_wall_ani()

func _allow_control_battle(_allow_control: bool = true)-> void:
    if _allow_control:
        battle_scene_mask_node.hide()
    else:
        battle_scene_mask_node.show()

    start_interface_battle_node.allow_control_battle(_allow_control)

func _menu_hide()-> void:
    animation_player_node.play("menu_hide")
    _menu_button_disable(true)

func _menu_show()-> void:
    animation_player_node.play("menu_show")
    _menu_button_disable(false)

func _title_show_end()-> void:
    animation_player_node.play("content_menu_show")

func _camera_move_right()-> void:
    start_interface_battle_node.set_camera_position_x_plus(-80)

func _camera_move_left()-> void:
    start_interface_battle_node.set_camera_position_x_plus(80)

func _start_animation_end()-> void:
    mask_node.hide()

func _change_wall_pic():
    if current_wall_pic_index > -1:
        wall_pic_list[current_wall_pic_index].hide()





    var _new_index = current_wall_pic_index
    if wall_pic_list.size() == 1:
        _new_index = 0
    else:
        while(_new_index == current_wall_pic_index):
            _new_index = CommonUtils.random_num(wall_pic_list.size() - 1)

    current_wall_pic_index = _new_index

    wall_pic_list[_new_index].show()

func _ani_enter_world_part01_finish()-> void:
    allow_load_world_sign.emit()


func _menu_button_disable(_disable: = true)-> void:
    for _button_node: CommonButton in button_root_node.get_children():
        _button_node.disabled = _disable

func _ani_enter_world_part02_finish()-> void:
    _change_wall_pic()
    enter_world_ani_finish_sign.emit()

func _recover_animation_part01_finish()-> void:
    recover_animation_part01_finish_sign.emit(is_to_world)

func _recover_animation_part02_finish()-> void:
    _change_wall_pic()

func _show_tips():
    var tip: String = TipsConstants.TIPS.pick_random()
    CommonUtils.set_text(tips_node, tip)
    tips_animation_player_node.play("show")

func _hide_tips():
    tips_animation_player_node.play_backwards("show")

func disable_heart_avatar_button(_disable: bool)-> void:
    if _disable:
        heart_avatar_button_node.disable()
    else:
        heart_avatar_button_node.cancel_disable()


func _save_custom_battle_data()-> void:
    GlobalSave.save_custom_battle_data(
        custom_team_interface_node.get_left_simple_json_list(),
        custom_team_interface_node.get_right_simple_json_list(),
        custom_team_interface_node.get_map_key(),
        custom_team_interface_node.get_weather_key(),
    )

func _hide_wall_ani()-> void:
    var _tween = get_tree().create_tween()
    _tween.tween_property(left_root_node, "modulate:a", 0, 0.5)

func _show_wall_ani()-> void:
    var _tween = get_tree().create_tween()
    _tween.tween_property(left_root_node, "modulate:a", 1.0, 0.5)


func _on_start_game_button_pressed()-> void:
    _menu_hide()
    create_character_interface_node.show()

func _on_create_character_interface_close_sign()-> void:
    _menu_show()

func _on_create_character_interface_create_character_success_sign()-> void:

    WSData.clear_formation_data()
    create_character_interface_node.save()
    enter_new_world_sign.emit()


func _on_load_game_button_pressed()-> void:
    _menu_hide()
    load_game_interface_node.init()
    load_game_interface_node.show()

func _on_load_game_interface_close_sign()-> void:
    _menu_show()

func _on_load_game_interface_load_save_success_sign()-> void:
    enter_save_world_sign.emit()

func _on_quit_game_button_pressed()-> void:
    get_tree().quit()

func _on_setting_button_pressed()-> void:
    _menu_hide()
    settings_interface_node.cshow()

func _on_settings_interface_close_page_sign()-> void:
    _menu_show()

func _on_heart_avatar_button_pressed()-> void:
    _menu_hide()
    sponsor_info_node.show()

func _on_sponsor_info_close_page_sign()-> void:
    _menu_show()
    sponsor_info_node.hide()


func _on_game_announcement_sponsor_button_click_sign()-> void:
    _menu_hide()
    sponsor_interface_node.cshow()

func _on_sponsor_interface_close_page_sign()-> void:
    _menu_show()

func _on_game_announcement_custom_team_button_sign()-> void:
    _menu_hide()

    if is_first_open_custom_battle_page:
        is_first_open_custom_battle_page = false
        custom_team_interface_node.init(
            WSData.custom_battle_left_simple_json_list,
            WSData.custom_battle_right_simple_json_list,
        )

    custom_team_interface_node.heal_all_soldier()

    custom_team_interface_node.cshow()

func _on_custom_team_interface_close_page_sign()-> void:
    _menu_show()
    _save_custom_battle_data()


func _on_custom_team_interface_start_battle_sign(
    _map_key: String, _weather_key: String
)-> void:

    clear()
    create_battle_scene(false)

    _allow_control_battle(true)
    start_interface_battle_node.reset_camera_zoom()

    start_interface_battle_node.update_scene_mode_use_player_config()

    start_interface_battle_node.init_map_weather(_map_key, _weather_key)

    start_interface_battle_node.init(
        custom_team_interface_node.get_left_simple_json_list(),
        custom_team_interface_node.get_right_simple_json_list()
    )

    _save_custom_battle_data()

    _hide_wall_ani()

func _on_game_announcement_control_battle_sign()-> void:
    _menu_hide()
    _hide_wall_ani()
    _allow_control_battle(true)
    start_interface_battle_node.show_or_hide_soldier_select_effect(true)