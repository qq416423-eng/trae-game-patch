class_name StartInterfaceBattle extends Node2D

@onready var battle_scene_node =$BattleScene as BattleScene


@export var team_money = 18000



signal back_to_main_menu_sign()

func _ready():
    GlobalNode.battle_scene = battle_scene_node

func init_random()-> void:




    var _result: = _handle_random_soldier_team()
    _random_weather()

    var _pre_map_node = MapUtils.random_map_node()
    battle_scene_node.init_map(_pre_map_node)

    battle_scene_node.init(
        _result.left_simple_json_list,
        _result.right_simple_json_list
    )

func set_camera_position_x_plus(_x_dif: int)-> void:
    battle_scene_node.set_camera_position_x_plus(_x_dif)

func camera_disable(_disable: bool)-> void:
    battle_scene_node.camera_disable(_disable)

func allow_control_battle(_allow_control: bool = true)-> void:
    battle_scene_node.allow_control_battle(_allow_control)

func update_scene_mode_use_player_config()-> void:
    battle_scene_node.update_scene_mode_use_player_config()

func update_is_for_start_interface_battle(_is_for_start_interface_battle: bool)-> void:
    battle_scene_node.update_is_for_start_interface_battle(_is_for_start_interface_battle)

func init_map_weather(_map_key: String, _weather_key: String)-> void:
    battle_scene_node.init_map_weather(_map_key, _weather_key)

func init(
    _left_simple_json_list: Array, _right_simple_json_list: Array
)-> void:
    battle_scene_node.init(_left_simple_json_list, _right_simple_json_list)

func reset_camera_zoom()-> void:
    battle_scene_node.reset_camera_zoom()

func show_or_hide_soldier_select_effect(_is_show: bool)-> void:
    battle_scene_node.show_or_hide_soldier_select_effect(_is_show)

func _random_weather()-> void:
    var random_weather = CommonUtils.random_enum(MWorldConstants.WEATHER_TYPE_ENUM)
    WSData.player_data.weather = random_weather

func _handle_random_soldier_team()-> Dictionary:





    var _simple_json_list: = TeamUtils.random_soldier_team(team_money)
    var _simple_json_list2: = TeamUtils.random_soldier_team(team_money)

    return {
        "left_simple_json_list": _simple_json_list,
        "right_simple_json_list": _simple_json_list2,
    }

func _on_battle_scene_back_to_main_menu_sign()-> void:
    back_to_main_menu_sign.emit()