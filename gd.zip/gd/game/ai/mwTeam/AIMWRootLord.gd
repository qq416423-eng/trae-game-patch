class_name AIMWRootLord extends BTRoot

func init():
    blackboard.run()