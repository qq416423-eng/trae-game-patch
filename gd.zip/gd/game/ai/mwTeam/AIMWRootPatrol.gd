class_name AIMWRootPatrol extends BTRoot

func init():
    blackboard.run()