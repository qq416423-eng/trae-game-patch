class_name AIMWTeamVillager extends BTRoot

func init(_origin_location_code, _target_location_code):


    blackboard.location_list_append([_target_location_code, _origin_location_code])
    blackboard.run()