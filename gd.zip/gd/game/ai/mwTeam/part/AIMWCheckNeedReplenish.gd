class_name AIMWCheckNeedReplenishFood extends BTConditionLeaf

func tick(_actor: MWTeam, _blackboard: BTBlackboard)-> int:

    if CommonUtils.counter_is_true(_actor.counter, NpcAIConfig.CHECK_REPLENISH_INTERVAL):
        return pre_status


    var is_need_replenish_food = _actor.check_is_need_replenish_food()
    if is_need_replenish_food:
        return save_and_return_status(SUCCESS, _blackboard, null)

    var is_need_replenish_soldier = _actor.check_is_need_replenish_soldier()
    if is_need_replenish_soldier:
        return save_and_return_status(SUCCESS, _blackboard, null)
    else:
        return save_and_return_status(FAILURE, _blackboard, null)