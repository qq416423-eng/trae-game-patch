class_name AIMWDisappear extends BTActionLeaf

func tick(_actor: MWTeam, _blackboard: BTBlackboard):

    _actor.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)
    _blackboard.stop()
    return return_status(SUCCESS, _blackboard)