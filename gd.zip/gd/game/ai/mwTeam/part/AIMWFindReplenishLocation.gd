class_name AIMWFindNearestCity extends BTActionLeaf

func tick(_actor, _blackboard: BTBlackboard):
    var _location_code = LocationUtils.find_replenish_location(_actor.json, _actor.global_position)
    if StringUtils.is_empty(_location_code):
        return FAILURE

    _blackboard.location_list_append([_location_code])
    return SUCCESS