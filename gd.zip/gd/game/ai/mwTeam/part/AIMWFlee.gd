class_name AIMWFlee extends BTActionLeaf

@export var interval_frame = 10

var counter = -1

var is_begin = true

func _ready():
    if owner.get("allow_flee") != null:
        is_disable = not owner.allow_flee

func tick(_actor: MWTeam, _blackboard: BTBlackboard):
    counter += 1

    if is_begin or CommonUtils.counter_is_true(counter, interval_frame):
        is_begin = false
        var _danger_node_list = _actor.get_danger_node_list(false)
        if ArrayUtils.is_empty(_danger_node_list):
            is_begin = true
            return return_status(FAILURE, _blackboard)

        var _flee_target_position = TeamUtils.get_flee_target_position(_actor, _danger_node_list)
        _actor.move_to_target(_flee_target_position)
        return return_status(RUNNING, _blackboard, "逃跑")

    return return_status(_blackboard.current_status, _blackboard)