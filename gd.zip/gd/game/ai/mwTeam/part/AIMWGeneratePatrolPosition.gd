extends BTActionLeaf

func tick(_actor: MWTeam, _blackboard: BTBlackboard)-> int:
    var _target_position = _actor.get_next_patrol_position()
    _blackboard.set_move_target_position(_target_position)
    return return_status(SUCCESS, _blackboard)