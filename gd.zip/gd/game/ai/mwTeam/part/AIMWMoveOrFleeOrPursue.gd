extends BTSelectorComposite

@onready var aimw_move_to_target_and_detect_node =$AIMWMoveToTargetAndDetect
@onready var aimw_flee_node =$AIMWFlee
@onready var aimw_pursue_node =$AIMWPursue


@export var allow_flee: = true

@export var allow_pursue: = true
@export var status_remark: = "巡逻"