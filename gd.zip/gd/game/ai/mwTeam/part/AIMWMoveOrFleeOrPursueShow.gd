extends BTSequenceComposite

@onready var aimw_move_or_flee_or_pursue =$AIMWMoveOrFleeOrPursue

@export var status_remark: = "巡逻"

@export var allow_flee: = true

@export var allow_pursue: = true

func _ready():
    aimw_move_or_flee_or_pursue.allow_flee = allow_flee
    aimw_move_or_flee_or_pursue.allow_pursue = allow_pursue