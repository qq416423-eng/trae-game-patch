class_name AIMWMoveToLocation extends BTActionLeaf

@export var remark: String = "前往..."

var is_finish = false
var sign_name = "move_reach"

var need_enter_run: = true

func tick(_actor: MWTeam, _blackboard: BTBlackboard):
    if _blackboard.current_status == RUNNING and not need_enter_run:

        if is_finish:
            is_finish = false
            need_enter_run = true
            if _actor.is_connected(sign_name, finish):
                _actor.disconnect(sign_name, finish)

            return return_status(SUCCESS, _blackboard)
    else:


        var _location_name = _blackboard.location_list_pop_front()

        _actor.move_to_location(_location_name)
        _actor.connect(sign_name, finish)
        need_enter_run = false

    return return_status(RUNNING, _blackboard, remark)

func finish():
    is_finish = true