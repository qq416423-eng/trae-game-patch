class_name AIMWMoveToTargetAndDetect extends BTActionLeaf


@export var check_danger = true

@export var check_attack = true

@export var check_frames = 10



@export var status_remark: String = "巡逻"

@export var allow_flee: = true

@export var allow_pursue: = true

var counter = -1
var sign_name = "move_reach"
var is_finish = false

var need_enter_run: = true

func _ready():
    if owner.get("allow_flee") != null:
        allow_flee = owner.get("allow_flee")
    if owner.get("allow_pursue") != null:
        allow_pursue = owner.get("allow_pursue")
    if owner.get("status_remark") != null:
        status_remark = owner.get("status_remark")

func tick(_actor: MWTeam, _blackboard: BTBlackboard)-> int:
    counter += 1

    var _target_is_location = _blackboard.get_value("target_is_location", false)

    if CommonUtils.counter_is_true(counter, check_frames):
        if allow_flee:

            var is_danger = _actor.check_danger()
            if is_danger:

                need_enter_run = true
                if _actor.is_connected(sign_name, finish):
                    _actor.disconnect(sign_name, finish)

                return return_status(FAILURE, _blackboard)

        if allow_pursue:

            var has_attack_target = _actor.check_has_attack_target()
            if has_attack_target:
                need_enter_run = true
                if _actor.is_connected(sign_name, finish):
                    _actor.disconnect(sign_name, finish)

                return return_status(FAILURE, _blackboard)


    if _blackboard.current_status == RUNNING and not need_enter_run:

        if is_finish:
            if _target_is_location:




                _blackboard.get_value("location_list").pop_front()

            is_finish = false
            need_enter_run = true
            if _actor.is_connected(sign_name, finish):
                _actor.disconnect(sign_name, finish)

            return return_status(SUCCESS, _blackboard)
    else:
        var _target_position_or_name = null


        if _target_is_location:
            if ArrayUtils.is_empty(_blackboard.get_value("location_list")):

                return return_status(FAILURE, _blackboard)

            _target_position_or_name = _blackboard.get_value("location_list")[0]
        else:
            _target_position_or_name = _blackboard.get_move_target_position()

        if _target_position_or_name == null:
            return return_status(FAILURE, _blackboard)

        if _target_is_location:
            _actor.move_to_location(_target_position_or_name)
        else:
            _actor.move_to_target(_target_position_or_name)







        _actor.connect(sign_name, finish)
        need_enter_run = false

    return return_status(RUNNING, _blackboard, status_remark)

func finish():
    is_finish = true