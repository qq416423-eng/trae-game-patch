class_name AIMWPursue extends BTActionLeaf

@export var interval_frame = 20

var counter = -1

var is_begin = true

var stopped_chasing_enemy_counter = 0

func _ready():
    if owner.get("allow_pursue") != null:
        is_disable = not owner.allow_pursue

func tick(_actor: MWTeam, _blackboard: BTBlackboard):
    counter += 1

    if is_begin or CommonUtils.counter_is_true(counter, interval_frame):

        var _danger_node_list = _actor.get_danger_node_list(false)
        if ArrayUtils.is_not_empty(_danger_node_list):
            return return_status(FAILURE, _blackboard)

        var _pursue_node_list = _actor.get_danger_node_list(true)
        if ArrayUtils.is_empty(_pursue_node_list):
            return return_status(FAILURE, _blackboard)


        if stopped_chasing_enemy_counter > 0:
            stopped_chasing_enemy_counter -= interval_frame
            return return_status(FAILURE, _blackboard)


        if _actor.is_out_of_patrol_range():
            stopped_chasing_enemy_counter = 120
            return return_status(FAILURE, _blackboard)

        var _nearest_node
        var _nearest_distance_square = pow(100000, 2)
        var _distance_square
        for _node in _pursue_node_list:
            _distance_square = CommonUtils.get_distance_square(_actor, _node)
            if _distance_square < _nearest_distance_square:
                _nearest_distance_square = _distance_square
                _nearest_node = _node

        _actor.move_to_team(_nearest_node)
        return return_status(RUNNING, _blackboard, "追击")

    return return_status(_blackboard.current_status, _blackboard)