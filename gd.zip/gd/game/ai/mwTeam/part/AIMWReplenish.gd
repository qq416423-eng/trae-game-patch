class_name AIMWReplenishFoodAndSoldier extends BTActionLeaf

var is_finish = false
var sign_name = "replenish_food_and_soldier_finish_sign"

var need_enter_run: = true

func tick(_actor: MWTeam, _blackboard: BTBlackboard):
    if _blackboard.current_status == RUNNING and not need_enter_run:

        if is_finish:
            is_finish = false
            need_enter_run = true
            if _actor.is_connected(sign_name, finish):
                _actor.disconnect(sign_name, finish)

            return return_status(SUCCESS, _blackboard)
    else:
        _actor.connect(sign_name, finish)


        need_enter_run = false

    return return_status(RUNNING, _blackboard, "补充")

func finish():
    is_finish = true