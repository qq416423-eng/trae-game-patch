extends BTActionLeaf

func tick(_actor: MWTeam, _blackboard: BTBlackboard)-> int:

    return SUCCESS