class_name AIMWrade extends BTActionLeaf

var is_finish = false
var sign_name = "trade_finish"

var need_enter_run: = true

func tick(_actor: MWTeam, _blackboard: BTBlackboard):
    if _blackboard.current_status == RUNNING and not need_enter_run:

        if is_finish:
            is_finish = false
            need_enter_run = true
            if _actor.is_connected(sign_name, finish):
                _actor.disconnect(sign_name, finish)

            return return_status(SUCCESS, _blackboard)
    else:
        _actor.connect(sign_name, finish)

        _actor.trade()
        need_enter_run = false

    return return_status(RUNNING, _blackboard, "交易")

func finish():
    is_finish = true