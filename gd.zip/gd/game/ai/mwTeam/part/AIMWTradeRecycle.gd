class_name AIMWTradeRecycle extends BTActionLeaf

func tick(_actor: MWTeam, _blackboard: BTBlackboard):
    _actor.trade_recycle()
    return return_status(SUCCESS, _blackboard, "交付物质")