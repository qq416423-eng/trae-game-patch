class_name BSBuffIcon extends TextureRect

func update_pic(_path: String)-> void:
    CommonUtils.update_texture2(self, _path)