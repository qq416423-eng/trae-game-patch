class_name BSBuffList extends HBoxContainer

const BS_BUFF_ICON = preload("res://tscn/game/bs/BSBuffIcon.tscn")

func add_icon(_path: String)-> void:
    var _node: BSBuffIcon = BS_BUFF_ICON.instantiate()
    self.add_child(_node)
    _node.update_pic(_path)