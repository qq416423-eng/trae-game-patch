class_name BattleBuffInfo extends HBoxContainer

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var buff_icon_node: TextureRect =$BuffIcon
@onready var tip_node: Tip =$Tip

func show_and_play_ani(_icon_path: String, _content: String)-> void:
    CommonUtils.set_text(tip_node, _content)
    CommonUtils.update_texture2(buff_icon_node, _icon_path)
    self.show()
    _play_ani()

func _play_ani()-> void:
    animation_player_node.play("show_and_disappear")

func chide()-> void:
    self.hide()