class_name BattleChatBubble extends Control

@onready var left_content_node: Label =$LeftBubbleRoot / Content
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var timer_node: Timer =$Timer
@onready var left_bubble_root_node: PanelContainer =$LeftBubbleRoot
@onready var right_content_node: Label =$RightBubbleRoot / Content
@onready var right_bubble_root_node: PanelContainer =$RightBubbleRoot

enum LEFT_OR_RIGHT_ENUM {
    LEFT,
    RIGHT
}

enum BACKGROUND_COLOR_ENUM {
    DEFAULT,
    RED,
    GREEN
}

var show_seconds: = 1.0
var is_hiding: = false

func _ready()-> void:
    left_bubble_root_node.modulate.a = 0.0
    right_bubble_root_node.modulate.a = 0.0

func change_zoom(_zoom: Vector2)-> void:
    var _scale = 1.0 / _zoom.x
    if _zoom.x > 1:
        _scale = 1.0

    self.scale = Vector2(_scale, _scale)

func change_zoom_by_x(_zoom_x: float)-> void:
    change_zoom(Vector2(_zoom_x, _zoom_x))

func init(
    _content: String, _seconds: float,
    _left_or_right_enum: LEFT_OR_RIGHT_ENUM = LEFT_OR_RIGHT_ENUM.LEFT,
    _background_color_enum: BACKGROUND_COLOR_ENUM = BACKGROUND_COLOR_ENUM.DEFAULT
)-> void:
    match _left_or_right_enum:
        LEFT_OR_RIGHT_ENUM.LEFT:
            right_bubble_root_node.hide()
        LEFT_OR_RIGHT_ENUM.RIGHT:
            left_bubble_root_node.hide()

    match _background_color_enum:
        BACKGROUND_COLOR_ENUM.RED:
            left_bubble_root_node.self_modulate = Color("FFB3B3")
            right_bubble_root_node.self_modulate = Color("FFB3B3")
        BACKGROUND_COLOR_ENUM.GREEN:
            left_bubble_root_node.self_modulate = Color("B3FFB3")
            right_bubble_root_node.self_modulate = Color("B3FFB3")
        BACKGROUND_COLOR_ENUM.DEFAULT:
            left_bubble_root_node.self_modulate = Color("f0e0b0")
            right_bubble_root_node.self_modulate = Color("f0e0b0")

    CommonUtils.set_text(left_content_node, _content)
    CommonUtils.set_text(right_content_node, _content)
    show_seconds = _seconds
    animation_player_node.play("show")

func chide()-> void:
    if is_hiding:
        return

    timer_node.stop()
    _on_timer_timeout()

func _show_finish()-> void:
    timer_node.start(show_seconds)

func _hide_finish()-> void:
    self.queue_free()

func _on_timer_timeout()-> void:
    is_hiding = true
    animation_player_node.play("hide")