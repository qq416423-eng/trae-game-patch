class_name BattleCoordDebug extends CanvasLayer


var _grid_root: Node2D
var _grid_size: int = 100
var _grid_lines: Array[Line2D] = []
var _grid_labels: Array[Label] = []
var _info_label: Label


func _ready()-> void:
    layer = 100
    visible = false
    set_process_unhandled_input(true)


func init_debug(_battle_scene: Node2D)-> void:

    _grid_root = Node2D.new()
    _grid_root.z_index = 100
    _battle_scene.add_child(_grid_root)


    _info_label = Label.new()
    _info_label.add_theme_font_size_override("font_size", 13)
    _info_label.add_theme_color_override("font_color", Color(0, 1, 0, 1))
    _info_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
    _info_label.add_constant_override("outline_size", 2)
    _info_label.position = Vector2(10, 10)
    add_child(_info_label)


    var _hint: Label = Label.new()
    _hint.add_theme_font_size_override("font_size", 11)
    _hint.add_theme_color_override("font_color", Color(1, 1, 0, 0.7))
    _hint.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
    _hint.add_constant_override("outline_size", 2)
    _hint.position = Vector2(10, 55)
    _hint.text = "[F3] 关闭坐标  |  [F4] 切换网格粗细"
    add_child(_hint)

    _draw_grid(_battle_scene)


func show_coord()-> void:
    visible = true
    if _grid_root != null:
        _grid_root.visible = true


func _draw_grid(_battle_scene: Node2D)-> void:
    _clear_grid()

    var _map_size: Vector2 = Vector2(4000, 3000)
    var _cam: Camera2D = _battle_scene.get_node_or_null("CommonCamera") as Camera2D
    if _cam != null:
        _map_size = Vector2(_cam.limit_right - _cam.limit_left, _cam.limit_bottom - _cam.limit_top)


    var _x: int = - int(_map_size.x / 2)
    while _x <= _map_size.x / 2:
        var _major: bool = _x % 500 == 0
        var _minor: bool = _x % 100 == 0
        var _line: Line2D = _make_line(Vector2(_x, - _map_size.y / 2), Vector2(_x, _map_size.y / 2), _major, _minor)
        _grid_root.add_child(_line)
        _grid_lines.append(_line)
        _x += _grid_size


    var _y: int = - int(_map_size.y / 2)
    while _y <= _map_size.y / 2:
        var _major: bool = _y % 500 == 0
        var _minor: bool = _y % 100 == 0
        var _line: Line2D = _make_line(Vector2(- _map_size.x / 2, _y), Vector2(_map_size.x / 2, _y), _major, _minor)
        _grid_root.add_child(_line)
        _grid_lines.append(_line)
        _y += _grid_size


    _x = - int(_map_size.x / 2)
    while _x <= _map_size.x / 2:
        if _x % 500 == 0:
            _grid_root.add_child(_make_label(str(_x), Vector2(_x - 20, 0), Color(1, 1, 1, 0.5)))
        _x += _grid_size

    _y = - int(_map_size.y / 2)
    while _y <= _map_size.y / 2:
        if _y % 500 == 0 and _y != 0:
            _grid_root.add_child(_make_label(str(_y), Vector2(0, _y + 3), Color(1, 1, 1, 0.5)))
        _y += _grid_size


    _grid_root.add_child(_make_line(Vector2(- _map_size.x / 2, 0), Vector2(_map_size.x / 2, 0), true, false, Color(0, 1, 0, 0.5)))
    _grid_root.add_child(_make_line(Vector2(0, - _map_size.y / 2), Vector2(0, _map_size.y / 2), true, false, Color(0, 1, 0, 0.5)))
    _grid_root.add_child(_make_label("(0,0) 原点", Vector2(5, 5), Color(0, 1, 0, 0.8)))


func _make_line(_from: Vector2, _to: Vector2, _major: bool, _minor: bool, _color: Color = Color())-> Line2D:
    var _line: Line2D = Line2D.new()
    if _color != Color():
        _line.default_color = _color
        _line.width = 2.0
    elif _major:
        _line.default_color = Color(1, 1, 1, 0.35)
        _line.width = 2.0
    elif _minor:
        _line.default_color = Color(1, 1, 1, 0.2)
        _line.width = 1.0
    else:
        _line.default_color = Color(1, 1, 1, 0.1)
        _line.width = 1.0
    _line.points = PackedVector2Array([_from, _to])
    return _line


func _make_label(_text: String, _pos: Vector2, _color: Color)-> Label:
    var _lbl: Label = Label.new()
    _lbl.add_theme_font_size_override("font_size", 10)
    _lbl.add_theme_color_override("font_color", _color)
    _lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
    _lbl.add_constant_override("outline_size", 2)
    _lbl.text = _text
    _lbl.position = _pos
    return _lbl


func _clear_grid()-> void:
    for _l in _grid_lines:
        if is_instance_valid(_l):
            _l.queue_free()
    _grid_lines.clear()
    for _l in _grid_labels:
        if is_instance_valid(_l):
            _l.queue_free()
    _grid_labels.clear()


func _process(_delta: float)-> void:
    if not visible or _info_label == null:
        return
    var _vp: Viewport = get_viewport()
    if _vp == null:
        return
    var _mp: Vector2 = _vp.get_mouse_position()
    var _parent: Node = get_parent()
    if _parent != null:
        var _cam: Camera2D = _parent.get_node_or_null("CommonCamera") as Camera2D
        var _world: String = ""
        if _cam != null:
            _world = " 世界: (%.0f, %.0f)" % [_cam.global_position.x +(_mp.x - _vp.size.x / 2) / _cam.zoom.x, _cam.global_position.y +(_mp.y - _vp.size.y / 2) / _cam.zoom.y]
        _info_label.text = "屏幕: (%.0f, %.0f)%s  |  [F3]关闭 [F4]切换网格" % [_mp.x, _mp.y, _world]


func _unhandled_input(_event: InputEvent)-> void:
    if not _event is InputEventKey or not _event.pressed or _event.echo:
        return
    match _event.keycode:
        KEY_F3:
            visible = not visible
            if _grid_root != null:
                _grid_root.visible = visible
        KEY_F4:
            if visible:
                _grid_size = 50 if _grid_size == 100 else 100
                var _parent: Node = get_parent()
                if _parent != null:
                    _draw_grid(_parent)