class_name BattleSFX extends Node

const MAX_SOUNDS_PER_SECOND: = 1

const TIME_WINDOW_MS: = 50

enum SFX_TYPE_ENUM {

    ATTACK_BOW,

    WALK,

    ATTACK_CROSSBOW,

    BODY_FALL,

    MALE_DEATH,
    FEMALE_DEATH,
    HORSE_IDLE,
    HORSE_FOOTSTEP,
    LANCE_HIT,
    DEFAULT_MELEE_ATTACK,
    CAMEL_IDLE,
    CAMEL_FOOTSTEP,

    ATTACK_POLE,

    ATTACK_BLUNT,

    ATTACK_THROW,
    FIREARM_SHOOT,

    MISFIRE,
}

static var SFX_TYPE_CONFIG = {
    SFX_TYPE_ENUM.ATTACK_BOW: {
        "resource": [
            load("res://resource/sound/battleSfx/attack_bow_1.wav"),
            load("res://resource/sound/battleSfx/attack_bow_2.wav"),
            load("res://resource/sound/battleSfx/attack_bow_3.wav"),
        ]
    },
    SFX_TYPE_ENUM.WALK: {
        "resource": [
            load("res://resource/sound/battleSfx/walk_1.wav"),
            load("res://resource/sound/battleSfx/walk_2.wav"),
            load("res://resource/sound/battleSfx/walk_3.wav")
        ]
    },
    SFX_TYPE_ENUM.ATTACK_CROSSBOW: {
        "resource": [
            load("res://resource/sound/battleSfx/attack_crossbow_1.wav"),
            load("res://resource/sound/battleSfx/attack_crossbow_2.wav"),
            load("res://resource/sound/battleSfx/attack_crossbow_3.wav"),
        ]
    },
    SFX_TYPE_ENUM.BODY_FALL: {
        "resource": [
            load("res://resource/sound/battleSfx/body_fall_1.wav"),
            load("res://resource/sound/battleSfx/body_fall_2.wav"),
            load("res://resource/sound/battleSfx/body_fall_3.wav"),
            load("res://resource/sound/battleSfx/body_fall_4.wav"),
            load("res://resource/sound/battleSfx/body_fall_5.wav"),
        ]
    },
    SFX_TYPE_ENUM.MALE_DEATH: {
        "resource": [
            load("res://resource/sound/battleSfx/male_death_1.wav"),
            load("res://resource/sound/battleSfx/male_death_2.wav"),
            load("res://resource/sound/battleSfx/male_death_3.wav"),
            load("res://resource/sound/battleSfx/male_death_4.wav"),
            load("res://resource/sound/battleSfx/male_death_5.wav"),
            load("res://resource/sound/battleSfx/male_death_6.wav"),




            load("res://resource/sound/battleSfx/male_death_9.wav"),
            load("res://resource/sound/battleSfx/male_death_10.wav"),
            load("res://resource/sound/battleSfx/male_death_11.wav"),
        ]
    },
    SFX_TYPE_ENUM.FEMALE_DEATH: {
        "resource": [
            load("res://resource/sound/battleSfx/female_death_1.wav"),
            load("res://resource/sound/battleSfx/female_death_2.wav"),
            load("res://resource/sound/battleSfx/female_death_3.wav"),
        ]
    },
    SFX_TYPE_ENUM.HORSE_IDLE: {
        "resource": [
            load("res://resource/sound/battleSfx/horse_idle_1.mp3"),
            load("res://resource/sound/battleSfx/horse_idle_2.mp3"),
        ],
        "limit": {
            "max_count": 1,
            "time_ms": 200
        }
    },
    SFX_TYPE_ENUM.HORSE_FOOTSTEP: {
        "resource": [
            load("res://resource/sound/battleSfx/horse_footstep_1.mp3"),
            load("res://resource/sound/battleSfx/horse_footstep_2.mp3"),
            load("res://resource/sound/battleSfx/horse_footstep_3.mp3"),
        ],
    },
    SFX_TYPE_ENUM.LANCE_HIT: {
        "resource": [

            load("res://resource/sound/battleSfx/lance_hit_2.wav"),
            load("res://resource/sound/battleSfx/lance_hit_3.wav"),
        ],
    },
    SFX_TYPE_ENUM.DEFAULT_MELEE_ATTACK: {
        "resource": [










            load("res://resource/sound/battleSfx/default_melee_attack_11.wav"),
            load("res://resource/sound/battleSfx/default_melee_attack_12.wav"),
            load("res://resource/sound/battleSfx/default_melee_attack_13.wav"),
            load("res://resource/sound/battleSfx/default_melee_attack_14.wav"),
        ],
        "limit": {
            "max_count": 1,
            "time_ms": 100
        }
    },
    SFX_TYPE_ENUM.CAMEL_IDLE: {
        "resource": [
            load("res://resource/sound/battleSfx/camel_idle_1.wav"),
            load("res://resource/sound/battleSfx/camel_idle_2.wav"),
        ],
        "limit": {
            "max_count": 1,
            "time_ms": 200
        }
    },
    SFX_TYPE_ENUM.CAMEL_FOOTSTEP: {
        "resource": [
            load("res://resource/sound/battleSfx/camel_footstep_1.wav"),
            load("res://resource/sound/battleSfx/camel_footstep_2.wav"),
        ],
    },
    SFX_TYPE_ENUM.ATTACK_POLE: {
        "resource": [
            load("res://resource/sound/battleSfx/default_melee_attack_7.wav"),
            load("res://resource/sound/battleSfx/default_melee_attack_8.wav"),
            load("res://resource/sound/battleSfx/default_melee_attack_9.wav"),
            load("res://resource/sound/battleSfx/default_melee_attack_10.wav"),
        ],
    },
    SFX_TYPE_ENUM.ATTACK_BLUNT: {
        "resource": [
            load("res://resource/sound/battleSfx/attack_blunt_1.wav"),
            load("res://resource/sound/battleSfx/attack_blunt_2.wav"),
            load("res://resource/sound/battleSfx/attack_blunt_3.wav"),
            load("res://resource/sound/battleSfx/attack_blunt_4.wav"),
        ]
    },
    SFX_TYPE_ENUM.ATTACK_THROW: {
        "resource": [
            load("res://resource/sound/battleSfx/attakc_throw_1.wav"),
            load("res://resource/sound/battleSfx/attakc_throw_2.wav"),
            load("res://resource/sound/battleSfx/attakc_throw_3.wav"),
            load("res://resource/sound/battleSfx/attakc_throw_4.wav"),
        ]
    },
    SFX_TYPE_ENUM.FIREARM_SHOOT: {
        "resource": [
            load("res://resource/sound/battleSfx/128979__aaronsiler__aaronsiler_musket-3.wav"),
            load("res://resource/sound/battleSfx/128977__aaronsiler__aaronsiler_musket-1.wav"),
            load("res://resource/sound/battleSfx/128978__aaronsiler__aaronsiler_musket-2.wav"),
        ]
    },
    SFX_TYPE_ENUM.MISFIRE: {
        "resource": [
            load("res://resource/sound/battleSfx/hissing.mp3"),
            load("res://resource/sound/battleSfx/hissing_02.mp3"),
        ]
    }
}

var sfx_pool = {}

func _ready()-> void:
    for _sfx_type_enum: int in SFX_TYPE_ENUM.values():
        sfx_pool[_sfx_type_enum] = []

func _allow_play_sfx(_sfx_type_enum: SFX_TYPE_ENUM)-> bool:
    var _max_count = MAX_SOUNDS_PER_SECOND
    var _time_ms = TIME_WINDOW_MS

    var _config = SFX_TYPE_CONFIG.get(_sfx_type_enum)
    if _config.has("limit"):
        _max_count = _config.limit.max_count
        _time_ms = _config.limit.time_ms

    var current_time = Time.get_ticks_msec()



    var _kept: Array = []
    for _t in sfx_pool[_sfx_type_enum]:
        if current_time - _t < _time_ms:
            _kept.append(_t)
    sfx_pool[_sfx_type_enum] = _kept

    return _kept.size() < _max_count

func maybe_get_sfx_steam(_sfx_type_enum: SFX_TYPE_ENUM)-> AudioStream:
    if _allow_play_sfx(_sfx_type_enum):
        sfx_pool[_sfx_type_enum].append(Time.get_ticks_msec())
        return get_sfx_steam(_sfx_type_enum)
    else:
        return null

func get_sfx_steam(_sfx_type_enum: SFX_TYPE_ENUM)-> AudioStream:
    return SFX_TYPE_CONFIG.get(_sfx_type_enum).resource.pick_random()