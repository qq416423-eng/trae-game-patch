class_name BattleSceneNpcTeamDefaultAI extends Node

@onready var cavalry_remote_ai_node: CavalryRemoteAI =$CavalryRemoteAI
@onready var cavalry_melee_ai_node: CavalryMeleeAI =$CavalryMeleeAI
@onready var infantry_remote_ai_node: InfantryRemoteAI =$InfantryRemoteAI
@onready var infantry_melee_ai_node: InfantryMeleeAI =$InfantryMeleeAI


const CHECK_INTERVAL: = BattleSceneAIConstants.CHECK_INTERVAL


@export var init_direction_vector = Vector2.LEFT


var anchor_point: Vector2 = Vector2.ZERO

var direction_vector: Vector2 = Vector2.LEFT
var counter: = 0
var own_soldier_node_list: = []

var enemy_soldier_node_list: = []

var enemy_center_point: Vector2

var ai_battle_strategy_enum: = BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.CHARGE

var init_own_cp: = 0
var init_enemy_cp: = 0
var current_own_cp: = 0
var current_enemy_cp: = 0
var true_leader_soldier_node: BSSoldier

func _ready()-> void:
    stop()

func _physics_process(delta: float)-> void:
    counter += 1

    if not CommonUtils.counter_is_true(counter, CHECK_INTERVAL):
        return

    _refresh_enemy_info()


    if _check_need_charge():
        _all_charge()
        stop()
        return

    match ai_battle_strategy_enum:
        BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.ADVANCING_ATTACK:


            if _check_is_all_stop():
                _compute_next_advance_anchor_point(100)
                _handle_all_move()

        BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.DEFENSIVE:

            _refresh_combat_power()
            if ArrayUtils.is_empty(own_soldier_node_list):
                stop()
                return


            if _check_defensive_need_charge():
                _all_charge()
                stop()
                return



            if(enemy_center_point - anchor_point).angle_to(direction_vector) > 0.1 * PI:
                _compute_next_advance_anchor_point(0)
                _handle_all_move()


func _check_defensive_need_charge()-> bool:



    if current_own_cp * 1.0 / init_own_cp <= 0.95 \

    and(init_own_cp - current_own_cp) >(init_enemy_cp - current_enemy_cp) * 2:
        return true


    if current_enemy_cp < current_own_cp * 2:
        return true

    return false

func _refresh_combat_power()-> void:
    own_soldier_node_list = SoldierUtils.list_living_soldier_node(own_soldier_node_list)
    current_own_cp = SoldierUtils.get_combat_power_by_soldier_node_list(own_soldier_node_list)
    current_enemy_cp = SoldierUtils.get_combat_power_by_soldier_node_list(enemy_soldier_node_list)

func init(
    _bs_soldier_node_list: Array,

    _init_point: Vector2,
    _enemy_soldier_node_list: Array,
    _team_rel_enum: MWTeamConstants.TEAM_REL_TYPE_ENUM
)-> void:
    if ArrayUtils.is_empty(_bs_soldier_node_list):
        return

    direction_vector = init_direction_vector


    _handle_ai_battle_strategy(
        _bs_soldier_node_list,
        _enemy_soldier_node_list,
        _team_rel_enum
    )

    anchor_point = _init_point
    enemy_soldier_node_list = _enemy_soldier_node_list
    own_soldier_node_list = _bs_soldier_node_list

    var _bs_soldier_node_list_dic: Dictionary = TeamUtils.group_bs_soldier_node_by_arms_small_type_enum(_bs_soldier_node_list)


    var _temp_max_height: = 0

    if _bs_soldier_node_list_dic.has(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.INFANTRY_REMOTE):
        infantry_remote_ai_node.init(
            _bs_soldier_node_list_dic.get(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.INFANTRY_REMOTE)
        )
        if infantry_remote_ai_node.height > _temp_max_height:
            _temp_max_height = infantry_remote_ai_node.height

    if _bs_soldier_node_list_dic.has(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.INFANTRY_MELEE):
        infantry_melee_ai_node.init(
            _bs_soldier_node_list_dic.get(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.INFANTRY_MELEE)
        )
        if infantry_melee_ai_node.height > _temp_max_height:
            _temp_max_height = infantry_melee_ai_node.height

    if _bs_soldier_node_list_dic.has(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.CAVALRY_MELEE):
        cavalry_melee_ai_node.update_group_space_y(_temp_max_height + 80)
        cavalry_melee_ai_node.init(
            _bs_soldier_node_list_dic.get(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.CAVALRY_MELEE)
        )

    if _bs_soldier_node_list_dic.has(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.CAVALRY_REMOTE):
        cavalry_remote_ai_node.update_offect_x(-80 - cavalry_melee_ai_node.width / 2)
        cavalry_remote_ai_node.update_group_space_y(_temp_max_height + 80)

        cavalry_remote_ai_node.init(
            _bs_soldier_node_list_dic.get(BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.CAVALRY_REMOTE)
        )

func stop()-> void:
    set_physics_process(false)
    for _ai_node: RrmsSmallTypeEnumAI in get_children():
        _ai_node.stop()

func start()-> void:
    if ai_battle_strategy_enum == BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.CHARGE:
        _all_charge()
        stop()
        return


    _handle_soldier_ai_battle_strategy_chat()

    set_physics_process(true)

func get_leader_soldier_node()-> BSSoldier:
    return true_leader_soldier_node



func _handle_ai_battle_strategy(
    _own_soldier_node_list: Array,
    _enemy_soldier_node_list: Array,
    _team_rel_enum: MWTeamConstants.TEAM_REL_TYPE_ENUM
)-> void:
    if ArrayUtils.is_empty(_own_soldier_node_list):
        return

    init_own_cp = SoldierUtils.get_combat_power_by_soldier_node_list(_own_soldier_node_list)
    init_enemy_cp = SoldierUtils.get_combat_power_by_soldier_node_list(_enemy_soldier_node_list)
    current_own_cp = init_own_cp
    current_enemy_cp = init_enemy_cp

    var _has_hero_leader: = false

    var _temp_top_level: = 0

    var _true_leader_json: Dictionary = {}
    for _soldier_node: BSSoldier in _own_soldier_node_list:








        if _soldier_node.is_leader():
            if _soldier_node.is_hero():
                if not _has_hero_leader:
                    _has_hero_leader = true


                    _temp_top_level = 0

                if _soldier_node.get_hero_level() > _temp_top_level:
                    _temp_top_level = _soldier_node.get_hero_level()

                    _true_leader_json = _soldier_node.get_json()
                    true_leader_soldier_node = _soldier_node
            else:
                if _has_hero_leader:
                    continue

                if _soldier_node.get_star() > _temp_top_level:
                    _temp_top_level = _soldier_node.get_star()

                    _true_leader_json = _soldier_node.get_json()
                    true_leader_soldier_node = _soldier_node

    if _has_hero_leader:

        ai_battle_strategy_enum = BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.ADVANCING_ATTACK




        var warlike_level_enum: int = CommonUtils.get_value(
            _true_leader_json, "warlike_level", HeroConstants.WARLIKE_LEVEL_ENUM.BALANCED
        )
        var caution_level_enum: int = CommonUtils.get_value(
            _true_leader_json, "caution_level", HeroConstants.CAUTION_LEVEL_ENUM.NEUTRAL
        )


        var _defensive_ai_factor: float = clampf(
            CommonUtils.get_section_value(
                [1.0, 2.5],[-3, 3], warlike_level_enum + caution_level_enum
            ),
            1.0, 2.5
        )

        if init_own_cp * _defensive_ai_factor < init_enemy_cp:
            ai_battle_strategy_enum = BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.DEFENSIVE
        else:

            var _charge_ai_factor: float = clampf(
                CommonUtils.get_section_value(
                    [2.5, 1.0],[-3, 3], warlike_level_enum + caution_level_enum
                ),
                1.0, 2.5
            )
            if init_own_cp * _charge_ai_factor > init_enemy_cp:
                ai_battle_strategy_enum = BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.CHARGE
    else:

        if _team_rel_enum == MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE:
            ai_battle_strategy_enum = BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.CHARGE
        else:

            if init_enemy_cp >= init_own_cp * 2:
                ai_battle_strategy_enum = BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.DEFENSIVE

func _handle_soldier_ai_battle_strategy_chat()-> void:
    if CommonUtils.is_null(true_leader_soldier_node):
        return

    match ai_battle_strategy_enum:


        BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.DEFENSIVE:
            true_leader_soldier_node.custom_ai_defensive_chat()
        BattleSceneAIConstants.AI_BATTLE_STRATEGY_ENUM.ADVANCING_ATTACK:
            true_leader_soldier_node.custom_ai_advancing_attack_chat()

func _check_need_charge()-> bool:
    return anchor_point.distance_squared_to(enemy_center_point) <= 550 * 550

func _all_charge()-> void:
    for _ai_node: RrmsSmallTypeEnumAI in get_children():
        _ai_node.charge()

func _refresh_enemy_info()-> void:
    enemy_soldier_node_list = SoldierUtils.list_living_soldier_node(enemy_soldier_node_list)
    if ArrayUtils.is_empty(enemy_soldier_node_list):
        stop()
        return

    enemy_center_point = CommonUtils.get_center_position(enemy_soldier_node_list)


func _check_is_all_stop()-> bool:
    for _ai_node: RrmsSmallTypeEnumAI in get_children():
        if not _ai_node.is_deprecated \
        and _ai_node.group_ai_status != BattleSceneAIConstants.GROUP_AI_STATUS_ENUM.STOP:
            return false

    return true



func _compute_next_advance_anchor_point(_step_distance: int)-> void:
    anchor_point +=(enemy_center_point - anchor_point).normalized() * _step_distance
    direction_vector = enemy_center_point - anchor_point


func _handle_all_move()-> void:
    for _ai_node: RrmsSmallTypeEnumAI in get_children():
        _ai_node.move()