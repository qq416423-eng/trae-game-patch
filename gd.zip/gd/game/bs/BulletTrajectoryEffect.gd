class_name BulletTrajectoryEffect extends Line2D

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

func init(_start_position: Vector2, _end_position: Vector2)-> void:
    points[0] = _start_position
    points[1] = _end_position
    animation_player_node.play("effect")