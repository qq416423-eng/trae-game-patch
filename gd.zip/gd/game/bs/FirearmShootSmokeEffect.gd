class_name FirearmShootSmokeEffect extends Node2D

@onready var muzzle_smoke_node: AnimatedSprite2D =$MuzzleSmoke
@onready var flash_pan_smoke_node: AnimatedSprite2D =$FlashPanSmoke
@onready var misfire_node: AnimatedSprite2D =$Misfire

var animation_count: = 2

static var muzzle_rel_position: Vector2 = Vector2(24, -18)

func _ready()-> void:
    muzzle_smoke_node.position = muzzle_rel_position

static func get_muzzle_rel_position()-> Vector2:
    return muzzle_rel_position

func init(_soldier_position: Vector2, is_mirrored: = false)-> void:
    global_position = _soldier_position

    if is_mirrored:
        self.scale.x = -1

    muzzle_smoke_node.play("smoke" + str(CommonUtils.random_num(1)))
    flash_pan_smoke_node.play("smoke" + str(CommonUtils.random_num(1)))

func misfire_effect(_soldier_position: Vector2, is_mirrored: = false)-> void:
    global_position = _soldier_position
    muzzle_smoke_node.hide()
    flash_pan_smoke_node.hide()
    misfire_node.show()

    if is_mirrored:
        self.scale.x = -1

    misfire_node.play("smoke" + str(CommonUtils.random_num(0)))

func get_muzzle_position()-> Vector2:
    return muzzle_smoke_node.global_position

func _maybe_queue_free()-> void:
    animation_count -= 1
    if animation_count <= 0:
        queue_free()

func _on_muzzle_smoke_animation_finished()-> void:
    _maybe_queue_free()

func _on_flash_pan_smoke_animation_finished()-> void:
    _maybe_queue_free()

func _on_misfire_animation_finished()-> void:
    queue_free()