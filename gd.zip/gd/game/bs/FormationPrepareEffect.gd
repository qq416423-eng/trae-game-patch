class_name FormationPrepareEffect extends Node2D

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var texture_progress_bar_node: TextureProgressBar =$TextureProgressBar

var origin_speed_scale: float = 1.0

signal prepare_finish_sign()

func _ready():
    GlobalTimeControl.connect("time_scale_update_sign", _time_scale_update)

func _time_scale_update(_time_scale: float)-> void:

    animation_player_node.speed_scale = origin_speed_scale / _time_scale

func ani_start(_position: Vector2)-> void:
    self.position = _position
    self.show()
    animation_player_node.seek(0.0, true, true)
    animation_player_node.play("start")


func update_ani_time(_frame_num: int)-> void:
    var _speed_ratio: float = 60.0 / _frame_num
    animation_player_node.speed_scale = _speed_ratio
    origin_speed_scale = _speed_ratio

func stop():
    animation_player_node.pause()
    self.hide()

func prepare_finish():
    prepare_finish_sign.emit()