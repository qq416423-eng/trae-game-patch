class_name RrmsSmallTypeEnumAI extends Node


const MAX_GROUP_COUNT = 2

const CHECK_INTERVAL: = BattleSceneAIConstants.CHECK_INTERVAL

var ai_root: BattleSceneNpcTeamDefaultAI



var soldier_node_group: = []

var group_info_list: = []

var group_space_y: = 80

var group_ai_status = BattleSceneAIConstants.GROUP_AI_STATUS_ENUM.STOP
var counter = CommonUtils.random_num(CHECK_INTERVAL - 1)

var is_deprecated: = true


var width: = 0
var height: = 0



@export var offect_x: = 50

@export var group_split_threshold: = 40

@export var is_on_edge: = false

func _ready()-> void:
    ai_root = owner
    set_physics_process(false)

func _physics_process(delta: float)-> void:
    counter += 1

    if not CommonUtils.counter_is_true(counter, CHECK_INTERVAL):
        return

    match group_ai_status:
        BattleSceneAIConstants.GROUP_AI_STATUS_ENUM.MOVE:
            _handle_ai_status_move()

func start()-> void:
    if is_deprecated:
        return

    set_physics_process(true)

func stop()-> void:
    if is_deprecated:
        return

    set_physics_process(false)

func init(_soldier_node_list: Array)-> void:
    if ArrayUtils.is_not_empty(_soldier_node_list):
        is_deprecated = false
    else:
        is_deprecated = true
        return

    _init_target_position(_soldier_node_list)
    _set_soldier_position()
    start()

func update_group_space_y(_group_space_y: int)-> void:
    group_space_y = _group_space_y

func update_offect_x(_offect_x: int)-> void:
    offect_x = _offect_x

func move()-> void:
    if is_deprecated:
        return

    group_ai_status = BattleSceneAIConstants.GROUP_AI_STATUS_ENUM.MOVE

    _filter_living_soldier_node()

    if soldier_node_group.size() == 0:
        stop()
        return

    _compute_target_position()
    _move_to_target()

func charge()-> void:
    _filter_living_soldier_node()

    if soldier_node_group.size() == 0:
        stop()
        return

    for _group_info: Dictionary in group_info_list:
        for _index: int in range(_group_info.node_list.size()):

            _group_info.node_list[_index].charge()

    stop()

func _handle_ai_status_move()-> void:
    for _group_info: Dictionary in group_info_list:
        var _current_center_point = CommonUtils.get_center_position(_group_info.node_list)
        if _current_center_point.distance_squared_to(_group_info.current_center_point) < 10 * 10:
            group_ai_status = BattleSceneAIConstants.GROUP_AI_STATUS_ENUM.STOP
            return

        _group_info.current_center_point = _current_center_point

func _filter_living_soldier_node()-> void:
    for _index: int in range(soldier_node_group.size() - 1, -1, -1):
        soldier_node_group[_index] = SoldierUtils.list_living_soldier_node(soldier_node_group[_index])

        if soldier_node_group[_index].size() == 0:
            soldier_node_group.remove_at(_index)

func _move_to_target()-> void:
    for _group_info: Dictionary in group_info_list:
        for _index: int in range(_group_info.node_list.size()):

            _group_info.node_list[_index].move_and_se(
                _group_info.actual_points[_index],
                false,
                CommonUtils.get_direction_enum_by_vector(ai_root.direction_vector)
            )

func _init_target_position(_soldier_node_list: Array)-> void:
    var _total: int = _soldier_node_list.size()
    var _group_count: int = _get_group_count(_total)
    soldier_node_group = ArrayUtils.split_evenly(_soldier_node_list, _group_count)

    _compute_target_position()

func _compute_target_position()-> void:
    _compute_origin_position()
    _compute_actual_position()

func _compute_origin_position()-> void:
    var _height_total: float = 0.0
    group_info_list = []
    for _group_soldier_node_list: Array in soldier_node_group:
        var _formation_info: Dictionary = SoldierUtils.soldier_formation_more_info2(
            _group_soldier_node_list, Vector2.ZERO, Vector2.RIGHT,
        )
        group_info_list.append({
            "node_list": _group_soldier_node_list,
            "width": _formation_info.width,
            "height": _formation_info.height,

            "origin_points": _formation_info.point_list,

            "origin_relative_y": 0,
            "origin_relative_x": 0,
            "actual_points": _formation_info.point_list,
            "current_center_point": Vector2.ZERO,
        })
        _height_total += _formation_info.height

    _height_total +=(group_info_list.size() - 1) * group_space_y
    var _temp_y = _height_total / 2
    var _max_width: = 0
    for _group_info: Dictionary in group_info_list:
        _group_info.origin_relative_y = _temp_y -(_group_info.height / 2)
        _temp_y -=(_group_info.height + group_space_y)

        if _group_info.width > _max_width:
            _max_width = _group_info.width


    if is_on_edge and group_info_list.size() == 1:
        group_info_list[0].origin_relative_y =(group_space_y + group_info_list[0].height) / 2

    for _group_info: Dictionary in group_info_list:
        if offect_x > 0:
            _group_info.origin_relative_x =(_max_width / 2) + offect_x
        elif offect_x == 0:
            _group_info.origin_relative_x = 0
        else:
            _group_info.origin_relative_x = offect_x -(_max_width / 2)

    width = _max_width
    height = _height_total

func _compute_actual_position()-> void:
    var _direction_vector: Vector2 = ai_root.direction_vector
    for _group_info: Dictionary in group_info_list:
        var _actual_points: = []
        for _origin_point: Vector2 in _group_info.origin_points:
            _origin_point += Vector2(_group_info.origin_relative_x, _group_info.origin_relative_y)

            _actual_points.append(
                _origin_point.rotated(_direction_vector.angle()) + ai_root.anchor_point
            )

        _group_info.actual_points = _actual_points

func _set_soldier_position()-> void:
    for _group_info: Dictionary in group_info_list:

        for _index: int in range(_group_info.node_list.size()):
            _group_info.node_list[_index].global_position = _group_info.actual_points[_index]


func _get_group_count(_count: int)-> int:
    return min(max(_count /(group_split_threshold / 2), 1), MAX_GROUP_COUNT)