extends Node

var bs_soldier_node: BSSoldier

var handle_interval: = BattleSceneConfig.DESERT_BUFF_INTERVAL

func _ready()-> void:
    bs_soldier_node = owner

func _physics_process(delta: float)-> void:
    if bs_soldier_node.counter % handle_interval == 0:
        bs_soldier_node.handle_terrain_buff()

func open_func()-> void:
    self.process_mode = Node.PROCESS_MODE_INHERIT

func close_func()-> void:
    self.process_mode = Node.PROCESS_MODE_DISABLED