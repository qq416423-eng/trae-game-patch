class_name BASKAegisOath extends BASKBase


func _custom_cast_skill()-> void:

    pass