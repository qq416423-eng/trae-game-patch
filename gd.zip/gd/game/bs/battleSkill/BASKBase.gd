class_name BASKBase extends Node2D

var owner_bs_soldier_node: BSSoldier

var cooldown_time_seconds: float = 5

var cooldown_time_left_seconds: float = 0.0

var trigger_chance_ratio = 0.3

func init(_owner_bs_soldier_node: BSSoldier)-> void:
    owner_bs_soldier_node = _owner_bs_soldier_node

func maybe_cast_skill()-> void:
    if _check_skill_trigger():
        _cast_skill()

func _check_skill_trigger()-> bool:
    if cooldown_time_left_seconds > 0.0:
        return false

    return CommonUtils.prob_true(trigger_chance_ratio)

func subtract_cooldown_time_left_seconds(_seconds: float)-> void:
    if cooldown_time_left_seconds > 0.0:
        cooldown_time_left_seconds -= _seconds

func _cast_skill()-> void:

    cooldown_time_left_seconds = cooldown_time_seconds
    _custom_cast_skill()


func _custom_cast_skill()-> void:
    pass