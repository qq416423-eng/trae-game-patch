class_name BattleSkillManager extends Node2D

@onready var bask_aegis_oath_node: BASKAegisOath =$BASKAegisOath

const COUNTER_INTERVAL = 30

var interval_delta: = 0.0
var counter: = 0


var is_active: = false
func _ready()-> void:
    set_physics_process(false)

func _physics_process(delta: float)-> void:
    interval_delta += delta
    counter += 1
    if not CommonUtils.counter_is_true(counter, COUNTER_INTERVAL):
        return


    for _node: BASKBase in get_children():
        _node.subtract_cooldown_time_left_seconds(interval_delta)

    interval_delta = 0.0

func start()-> void:
    is_active = true
    set_physics_process(true)

func init(_owner_bs_soldier_node: BSSoldier)-> void:
    bask_aegis_oath_node.init(_owner_bs_soldier_node)

func maybe_cast_skill()-> void:
    if not is_active:
        return

    bask_aegis_oath_node.maybe_cast_skill()