class_name BattleObstacleBase extends Node2D



enum OBSTACLE_TYPE {
    WALL,
    BARRICADE,
    SPIKE,
    TERRAIN,
}





@export var obstacle_name: String = "障碍物"


@export var obstacle_type: OBSTACLE_TYPE = OBSTACLE_TYPE.WALL


@export var obstacle_width: float = 100.0


@export var obstacle_height: float = 20.0


@export var rotation_degrees_val: float = 0.0


@export var is_rectangle: bool = true


@export var custom_polygon: PackedVector2Array = []


@export var show_collision_debug: bool = false


@export var obstacle_color: Color = Color(0.5, 0.35, 0.2, 1.0)




var static_body_node: StaticBody2D
var collision_polygon_node: CollisionPolygon2D
var sprite_node: ColorRect




func _ready()-> void:
    _create_static_body()
    _create_collision_polygon()
    _create_visual()
    _apply_config()



func _create_static_body()-> void:
    static_body_node = StaticBody2D.new()
    static_body_node.name = "StaticBody"
    static_body_node.collision_layer = 1
    static_body_node.collision_mask = 0
    add_child(static_body_node)



func _create_collision_polygon()-> void:
    collision_polygon_node = CollisionPolygon2D.new()
    collision_polygon_node.name = "CollisionPolygon"
    static_body_node.add_child(collision_polygon_node)



func _create_visual()-> void:
    sprite_node = ColorRect.new()
    sprite_node.name = "Visual"
    sprite_node.color = obstacle_color
    sprite_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(sprite_node)



func _apply_config()-> void:
    rotation_degrees = rotation_degrees_val

    if is_rectangle:
        _build_rectangle()
    else:
        _build_polygon()

    if not show_collision_debug:
        sprite_node.visible = false



func _build_rectangle()-> void:
    var _half_w: float = obstacle_width / 2.0
    var _half_h: float = obstacle_height / 2.0

    collision_polygon_node.polygon = PackedVector2Array([
        Vector2(- _half_w, - _half_h),
        Vector2(_half_w, - _half_h),
        Vector2(_half_w, _half_h),
        Vector2(- _half_w, _half_h),
    ])

    sprite_node.size = Vector2(obstacle_width, obstacle_height)
    sprite_node.position = Vector2(- _half_w, - _half_h)



func _build_polygon()-> void:
    if custom_polygon.is_empty():
        _build_rectangle()
        return
    collision_polygon_node.polygon = custom_polygon


    var _min_x: float = INF
    var _min_y: float = INF
    var _max_x: float = - INF
    var _max_y: float = - INF
    for _v in custom_polygon:
        _min_x = min(_min_x, _v.x)
        _min_y = min(_min_y, _v.y)
        _max_x = max(_max_x, _v.x)
        _max_y = max(_max_y, _v.y)
    sprite_node.size = Vector2(_max_x - _min_x, _max_y - _min_y)
    sprite_node.position = Vector2(_min_x, _min_y)





func on_soldier_enter(_soldier: BSSoldier)-> void:
    pass



func on_soldier_exit(_soldier: BSSoldier)-> void:
    pass



func on_damage(_amount: float)-> void:
    pass



func init_from_config(_config: Dictionary)-> void:
    obstacle_name = _config.get("name", "障碍物")
    obstacle_type = _config.get("type", OBSTACLE_TYPE.WALL)
    obstacle_width = _config.get("width", 100.0)
    obstacle_height = _config.get("height", 20.0)
    rotation_degrees_val = _config.get("rotation", 0.0)
    obstacle_color = _config.get("color", Color(0.5, 0.35, 0.2, 1.0))
    is_rectangle = _config.get("is_rectangle", true)
    if _config.has("polygon"):
        custom_polygon = _config["polygon"]
        is_rectangle = false
    show_collision_debug = _config.get("show_debug", false)