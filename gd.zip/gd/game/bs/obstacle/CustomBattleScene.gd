class_name CustomBattleScene extends BattleScene





var obstacle_list: Array[BattleObstacleBase] = []


var obstacle_root_node: Node2D


@export var obstacle_enabled: bool = true





func init_with_preset(
    _player_simple_json_list: Array,
    _enemy_simple_json_list: Array,
    _preset_name: String,
    _ally_simple_json_list: Array = [],
)-> void:

    init(_player_simple_json_list, _enemy_simple_json_list, _ally_simple_json_list)


    if obstacle_enabled:
        load_obstacles_from_preset(_preset_name)



func init_with_obstacles(
    _player_simple_json_list: Array,
    _enemy_simple_json_list: Array,
    _obstacle_configs: Array,
    _ally_simple_json_list: Array = [],
)-> void:

    init(_player_simple_json_list, _enemy_simple_json_list, _ally_simple_json_list)


    if obstacle_enabled:
        load_obstacles(_obstacle_configs)



func init_by_team_node_with_preset(
    _enemy_team_node_list,
    _ally_team_node_list,
    _preset_name: String,
)-> void:
    init_by_team_node(_enemy_team_node_list, _ally_team_node_list)
    if obstacle_enabled:
        load_obstacles_from_preset(_preset_name)





func load_obstacles_from_preset(_preset_name: String)-> void:
    var _configs: Array = ObstacleConfig.get_preset_layout(_preset_name)
    if _configs.is_empty():
        push_warning("[CustomBattleScene] 预设布局 '%s' 不存在或为空" % _preset_name)
        return
    load_obstacles(_configs)



func load_obstacles(_configs: Array)-> void:
    _ensure_obstacle_root()


    clear_obstacles()


    var _map_offset: Vector2 = _get_map_center_offset()

    for _config in _configs:
        var _obstacle: BattleObstacleBase = ObstacleConfig.create_obstacle(_config)


        if _config.has("position"):
            var _pos: Vector2 = _config.position
            _obstacle.global_position = _map_offset + _pos

        obstacle_root_node.add_child(_obstacle)
        obstacle_list.append(_obstacle)



func clear_obstacles()-> void:
    for _obs in obstacle_list:
        if is_instance_valid(_obs):
            _obs.queue_free()
    obstacle_list.clear()



func _ensure_obstacle_root()-> void:
    if obstacle_root_node == null:
        obstacle_root_node = Node2D.new()
        obstacle_root_node.name = "ObstacleRoot"
        obstacle_root_node.z_index = 5
        get_parent().add_child.call_deferred(obstacle_root_node)



func _get_map_center_offset()-> Vector2:
    if common_camera_node != null:
        return common_camera_node.get_screen_center_position()
    return Vector2(960, 540)





func add_obstacle(_config: Dictionary)-> BattleObstacleBase:
    _ensure_obstacle_root()
    var _obstacle: BattleObstacleBase = ObstacleConfig.create_obstacle(_config)
    if _config.has("position"):
        _obstacle.global_position = _config.position
    obstacle_root_node.add_child(_obstacle)
    obstacle_list.append(_obstacle)
    return _obstacle



func remove_obstacle(_obstacle: BattleObstacleBase)-> void:
    var _idx: int = obstacle_list.find(_obstacle)
    if _idx >= 0:
        obstacle_list.remove_at(_idx)
    if is_instance_valid(_obstacle):
        _obstacle.queue_free()



func get_all_obstacles()-> Array[BattleObstacleBase]:
    return obstacle_list



func get_obstacles_by_type(_type: int)-> Array[BattleObstacleBase]:
    var _result: Array[BattleObstacleBase] = []
    for _obs in obstacle_list:
        if _obs.obstacle_type == _type:
            _result.append(_obs)
    return _result




static func get_available_presets()-> PackedStringArray:
    return PackedStringArray([
        "castle_gate",
        "field_battle",
        "ambush",
        "defense_line",
        "village_garrison",
    ])