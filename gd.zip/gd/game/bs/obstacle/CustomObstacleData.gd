static func my_canyon_layout()-> Array:
    return[

        {
            "type": "wall",
            "name": "北侧崖壁",
            "position": Vector2(0, -300),
            "width": 1000,
            "height": 40,
            "rotation": 0,
            "color": Color(0.4, 0.38, 0.35, 0.9),
        },

        {
            "type": "wall",
            "name": "南侧崖壁",
            "position": Vector2(0, 300),
            "width": 1000,
            "height": 40,
            "rotation": 0,
            "color": Color(0.4, 0.38, 0.35, 0.9),
        },

        {
            "type": "barricade",
            "name": "峡谷路障",
            "position": Vector2(0, 0),
            "width": 200,
            "height": 25,
            "rotation": 0,
            "hp": 600,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        },

        {
            "type": "spike",
            "name": "峡谷陷阱",
            "position": Vector2(0, 100),
            "width": 180,
            "height": 30,
            "rotation": 0,
            "damage_per_second": 15,
            "color": Color(0.7, 0.1, 0.1, 0.4),
        },

        {
            "type": "terrain",
            "name": "峡谷泥沼",
            "position": Vector2(0, 200),
            "width": 400,
            "height": 60,
            "rotation": 0,
            "cavalry_slow": 0.5,
            "infantry_slow": 0.25,
            "color": Color(0.2, 0.5, 0.2, 0.3),
        },
    ]