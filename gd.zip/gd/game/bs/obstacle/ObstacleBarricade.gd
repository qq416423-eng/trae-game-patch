class_name ObstacleBarricade extends BattleObstacleBase



@export var current_hp: float = 500.0


@export var max_hp: float = 500.0


var hp_bar_node: ColorRect
var hp_bar_bg_node: ColorRect


func _ready()-> void:
    obstacle_type = OBSTACLE_TYPE.BARRICADE
    obstacle_name = "木栅"
    obstacle_color = Color(0.55, 0.35, 0.15, 0.85)
    super._ready()
    current_hp = max_hp
    _create_hp_bar()


func _create_hp_bar()-> void:

    hp_bar_bg_node = ColorRect.new()
    hp_bar_bg_node.name = "HPBarBg"
    hp_bar_bg_node.color = Color(0.2, 0.2, 0.2, 0.7)
    hp_bar_bg_node.size = Vector2(obstacle_width, 6)
    hp_bar_bg_node.position = Vector2(- obstacle_width / 2.0, - obstacle_height / 2.0 - 12)
    hp_bar_bg_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hp_bar_bg_node)


    hp_bar_node = ColorRect.new()
    hp_bar_node.name = "HPBar"
    hp_bar_node.color = Color(0.2, 0.8, 0.2, 0.9)
    hp_bar_node.size = Vector2(obstacle_width, 6)
    hp_bar_node.position = Vector2(- obstacle_width / 2.0, - obstacle_height / 2.0 - 12)
    hp_bar_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hp_bar_node)


func on_damage(_amount: float)-> void:
    current_hp -= _amount
    _update_hp_bar()

    if current_hp <= 0:
        _destroy()


func _update_hp_bar()-> void:
    if hp_bar_node != null:
        var _ratio: float = max(0.0, current_hp / max_hp)
        hp_bar_node.size.x = obstacle_width * _ratio

        if _ratio > 0.5:
            hp_bar_node.color = Color(0.2, 0.8, 0.2, 0.9)
        elif _ratio > 0.25:
            hp_bar_node.color = Color(0.9, 0.7, 0.1, 0.9)
        else:
            hp_bar_node.color = Color(0.9, 0.2, 0.2, 0.9)


func _destroy()-> void:

    static_body_node.set_deferred("collision_layer", 0)
    static_body_node.set_deferred("collision_mask", 0)


    var _tween: Tween = create_tween()
    _tween.tween_property(sprite_node, "modulate:a", 0.0, 0.3)
    if hp_bar_node != null:
        _tween.parallel().tween_property(hp_bar_node, "modulate:a", 0.0, 0.3)
    if hp_bar_bg_node != null:
        _tween.parallel().tween_property(hp_bar_bg_node, "modulate:a", 0.0, 0.3)
    _tween.tween_callback(queue_free)


func init_from_config(_config: Dictionary)-> void:
    super.init_from_config(_config)
    max_hp = _config.get("hp", 500.0)
    current_hp = max_hp