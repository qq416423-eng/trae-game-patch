class_name ObstacleConfig



const OBSTACLE_TYPE_MAP: Dictionary = {
    "wall": "ObstacleWall",
    "barricade": "ObstacleBarricade",
    "spike": "ObstacleSpike",
    "terrain": "ObstacleTerrain",
}






static func get_preset_layout(_layout_name: String)-> Array:
    match _layout_name:
        "castle_gate":
            return _layout_castle_gate()
        "field_battle":
            return _layout_field_battle()
        "ambush":
            return _layout_ambush()
        "defense_line":
            return _layout_defense_line()
        "village_garrison":
            return _layout_village_garrison()
    return[]






static func _layout_castle_gate()-> Array:
    return[

        {
            "type": "wall",
            "name": "左墙",
            "position": Vector2(-400, 0),
            "width": 30,
            "height": 600,
            "rotation": 0,
            "color": Color(0.45, 0.42, 0.38, 0.9),
        },

        {
            "type": "wall",
            "name": "右墙",
            "position": Vector2(400, 0),
            "width": 30,
            "height": 600,
            "rotation": 0,
            "color": Color(0.45, 0.42, 0.38, 0.9),
        },

        {
            "type": "barricade",
            "name": "城门木栅",
            "position": Vector2(0, 0),
            "width": 200,
            "height": 20,
            "rotation": 0,
            "hp": 800,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        },

        {
            "type": "spike",
            "name": "城门尖刺",
            "position": Vector2(0, 80),
            "width": 250,
            "height": 30,
            "rotation": 0,
            "damage_per_second": 15,
            "color": Color(0.7, 0.1, 0.1, 0.5),
        },
    ]






static func _layout_field_battle()-> Array:
    return[

        {
            "type": "wall",
            "name": "中央石墙",
            "position": Vector2(0, 0),
            "width": 250,
            "height": 25,
            "rotation": 0,
            "color": Color(0.5, 0.45, 0.4, 0.85),
        },

        {
            "type": "barricade",
            "name": "左翼木栅",
            "position": Vector2(-350, -150),
            "width": 120,
            "height": 18,
            "rotation": 30,
            "hp": 400,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        },

        {
            "type": "barricade",
            "name": "右翼木栅",
            "position": Vector2(350, -150),
            "width": 120,
            "height": 18,
            "rotation": -30,
            "hp": 400,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        },

        {
            "type": "spike",
            "name": "左翼尖刺",
            "position": Vector2(-300, 200),
            "width": 100,
            "height": 20,
            "rotation": 0,
            "damage_per_second": 8,
            "color": Color(0.7, 0.1, 0.1, 0.4),
        },

        {
            "type": "spike",
            "name": "右翼尖刺",
            "position": Vector2(300, 200),
            "width": 100,
            "height": 20,
            "rotation": 0,
            "damage_per_second": 8,
            "color": Color(0.7, 0.1, 0.1, 0.4),
        },

        {
            "type": "terrain",
            "name": "中央泥沼",
            "position": Vector2(0, 250),
            "width": 300,
            "height": 80,
            "rotation": 0,
            "cavalry_slow": 0.5,
            "infantry_slow": 0.25,
            "color": Color(0.2, 0.5, 0.2, 0.3),
        },
    ]






static func _layout_ambush()-> Array:
    return[

        {
            "type": "wall",
            "name": "上侧崖壁",
            "position": Vector2(0, -300),
            "width": 800,
            "height": 30,
            "rotation": 0,
            "color": Color(0.4, 0.38, 0.35, 0.9),
        },

        {
            "type": "wall",
            "name": "下侧崖壁",
            "position": Vector2(0, 300),
            "width": 800,
            "height": 30,
            "rotation": 0,
            "color": Color(0.4, 0.38, 0.35, 0.9),
        },

        {
            "type": "barricade",
            "name": "入口木栅",
            "position": Vector2(-300, 0),
            "width": 20,
            "height": 120,
            "rotation": 0,
            "hp": 300,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        },

        {
            "type": "barricade",
            "name": "出口木栅",
            "position": Vector2(300, 0),
            "width": 20,
            "height": 120,
            "rotation": 0,
            "hp": 300,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        },

        {
            "type": "spike",
            "name": "通道尖刺",
            "position": Vector2(0, 0),
            "width": 150,
            "height": 25,
            "rotation": 0,
            "damage_per_second": 20,
            "color": Color(0.7, 0.1, 0.1, 0.5),
        },
    ]






static func _layout_defense_line()-> Array:
    var _obstacles: Array = []

    for _i in range(5):
        _obstacles.append({
            "type": "spike",
            "name": "前线尖刺%d" %(_i + 1),
            "position": Vector2(-400 + _i * 200, -200),
            "width": 60,
            "height": 20,
            "rotation": 0,
            "damage_per_second": 12,
            "color": Color(0.7, 0.1, 0.1, 0.4),
        })

    for _i in range(4):
        _obstacles.append({
            "type": "barricade",
            "name": "防线木栅%d" %(_i + 1),
            "position": Vector2(-300 + _i * 200, -100),
            "width": 80,
            "height": 18,
            "rotation": 0,
            "hp": 500,
            "color": Color(0.55, 0.35, 0.15, 0.85),
        })

    for _i in range(3):
        _obstacles.append({
            "type": "wall",
            "name": "防线石墙%d" %(_i + 1),
            "position": Vector2(-200 + _i * 200, 0),
            "width": 100,
            "height": 25,
            "rotation": 0,
            "color": Color(0.45, 0.42, 0.38, 0.9),
        })

    _obstacles.append({
        "type": "terrain",
        "name": "防线泥沼",
        "position": Vector2(0, 150),
        "width": 500,
        "height": 60,
        "rotation": 0,
        "cavalry_slow": 0.6,
        "infantry_slow": 0.3,
        "color": Color(0.2, 0.5, 0.2, 0.3),
    })
    return _obstacles







static func _layout_village_garrison()-> Array:
    return[

        {
            "type": "wall",
            "name": "下部长墙",
            "position": Vector2(1750, 900),
            "width": 2500,
            "height": 100,
            "rotation": 0,
            "color": Color(0.45, 0.42, 0.38, 0.9),
        },

        {
            "type": "wall",
            "name": "上部长墙",
            "position": Vector2(1750, -900),
            "width": 2500,
            "height": 100,
            "rotation": 0,
            "color": Color(0.45, 0.42, 0.38, 0.9),
        },
    ]







static func create_obstacle(_config: Dictionary)-> BattleObstacleBase:
    var _type: String = _config.get("type", "wall")
    var _class_name: String = OBSTACLE_TYPE_MAP.get(_type, "ObstacleWall")

    var _obstacle: BattleObstacleBase

    match _class_name:
        "ObstacleWall":
            _obstacle = ObstacleWall.new()
        "ObstacleBarricade":
            _obstacle = ObstacleBarricade.new()
        "ObstacleSpike":
            _obstacle = ObstacleSpike.new()
        "ObstacleTerrain":
            _obstacle = ObstacleTerrain.new()
        _:
            _obstacle = ObstacleWall.new()

    _obstacle.init_from_config(_config)


    if _config.has("position"):
        _obstacle.global_position = _config.position

    return _obstacle



static func create_obstacles(_config_list: Array)-> Array[BattleObstacleBase]:
    var _result: Array[BattleObstacleBase] = []
    for _config in _config_list:
        _result.append(create_obstacle(_config))
    return _result