class_name ObstaclePit extends Node2D



var _trapped_soldiers: Dictionary = {}


var _wall_body: StaticBody2D
var _wall_collision: CollisionPolygon2D
var _detect_area: Area2D
var _detect_collision: CollisionPolygon2D
var _pit_area: Area2D
var _pit_collision: CollisionPolygon2D
var _visual: ColorRect


var _pit_width: float
var _pit_height: float
var _detect_margin: int = 35


func init_pit(_center: Vector2, _width: float, _height: float)-> void:
    _pit_width = _width
    _pit_height = _height
    global_position = _center


    _visual = ColorRect.new()
    _visual.color = Color(0.35, 0.2, 0.08, 0.5)
    _visual.size = Vector2(_pit_width, _pit_height)
    _visual.position = Vector2(- _pit_width / 2.0, - _pit_height / 2.0)
    _visual.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_visual)


    _wall_body = StaticBody2D.new()
    _wall_body.collision_layer = 1
    _wall_body.collision_mask = 0
    add_child(_wall_body)

    _wall_collision = CollisionPolygon2D.new()
    _wall_collision.polygon = _make_rect_polygon(_pit_width, _pit_height)
    _wall_body.add_child(_wall_collision)


    _detect_area = Area2D.new()
    _detect_area.collision_layer = 0
    _detect_area.collision_mask = 0
    _detect_area.body_entered.connect(_on_detect_entered)
    _detect_area.body_exited.connect(_on_detect_exited)
    add_child(_detect_area)

    _detect_collision = CollisionPolygon2D.new()
    _detect_collision.polygon = _make_rect_polygon(_pit_width + _detect_margin * 2, _pit_height + _detect_margin * 2)
    _detect_area.add_child(_detect_collision)


    _pit_area = Area2D.new()
    _pit_area.collision_layer = 0
    _pit_area.collision_mask = 0
    _pit_area.body_entered.connect(_on_pit_entered)
    add_child(_pit_area)

    _pit_collision = CollisionPolygon2D.new()
    _pit_collision.polygon = _make_rect_polygon(_pit_width, _pit_height)
    _pit_area.add_child(_pit_collision)

    set_process(true)


func _make_rect_polygon(_w: float, _h: float)-> PackedVector2Array:
    var _hw: = _w / 2.0
    var _hh: = _h / 2.0
    return PackedVector2Array([
        Vector2(- _hw, - _hh),
        Vector2(_hw, - _hh),
        Vector2(_hw, _hh),
        Vector2(- _hw, _hh),
    ])



func _on_detect_entered(_body: Node2D)-> void:
    if not _body is BSSoldier:
        return
    var _sid: int = _body.get_instance_id()
    if _trapped_soldiers.has(_sid):
        return
    _body.update_speed_mult(0.3)


func _on_detect_exited(_body: Node2D)-> void:
    if not _body is BSSoldier:
        return
    var _sid: int = _body.get_instance_id()
    if _trapped_soldiers.has(_sid):
        return
    _body.update_speed_mult(1.0)



func _on_pit_entered(_body: Node2D)-> void:
    if not _body is BSSoldier:
        return
    var _sid: int = _body.get_instance_id()
    if _trapped_soldiers.has(_sid):
        return


    if _is_cavalry_charging(_body):
        _trap_soldier(_body, _sid)
    else:

        _body.update_speed_mult(0.15)


func _is_cavalry_charging(_body: BSSoldier)-> bool:

    if not SoldierUtils.is_cavalry(_body.bs_soldier_prop):
        return false
    var _speed: float = _body.velocity.length()
    return _speed > _body.bs_soldier_prop.move_speed * 0.5


func _trap_soldier(_body: BSSoldier, _sid: int)-> void:
    _trapped_soldiers[_sid] = true


    _body.global_position = global_position


    _body.velocity = Vector2.ZERO
    _body.update_speed_mult(0.0)


    _body.set_deferred("collision_mask", 0)


    var _tween: Tween = _body.create_tween()
    _tween.tween_property(_body, "modulate", Color(0.5, 0.5, 0.5, 1.0), 0.3)



func _process(_delta: float)-> void:
    var _to_remove: Array = []
    for _sid in _trapped_soldiers:
        var _body: BSSoldier = instance_from_id(_sid) as BSSoldier
        if _body == null or not is_instance_valid(_body):
            _to_remove.append(_sid)
            continue
        if _body.bs_soldier_prop.current_hp <= 0:
            _to_remove.append(_sid)
            continue

        _body.velocity = Vector2.ZERO
        _body.global_position = global_position

    for _sid in _to_remove:
        _trapped_soldiers.erase(_sid)



func release_all()-> void:
    for _sid in _trapped_soldiers:
        var _body: BSSoldier = instance_from_id(_sid) as BSSoldier
        if _body != null and is_instance_valid(_body):
            _body.update_speed_mult(1.0)
            _body.set_deferred("collision_mask", _body.origin_collision_mask)
            _body.modulate = Color(1, 1, 1, 1)
    _trapped_soldiers.clear()