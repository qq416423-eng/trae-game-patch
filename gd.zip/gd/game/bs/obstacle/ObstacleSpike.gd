class_name ObstacleSpike extends BattleObstacleBase



@export var damage_per_second: float = 10.0


@export var damage_interval: int = 30


var _soldiers_in_area: Dictionary = {}
var _area_node: Area2D
var _area_collision: CollisionPolygon2D


func _ready()-> void:
    obstacle_type = OBSTACLE_TYPE.SPIKE
    obstacle_name = "尖刺陷阱"
    obstacle_color = Color(0.7, 0.1, 0.1, 0.6)
    super._ready()
    _create_damage_area()


func _create_damage_area()-> void:
    _area_node = Area2D.new()
    _area_node.name = "DamageArea"
    _area_node.collision_layer = 0
    _area_node.collision_mask = 0
    _area_node.area_entered.connect(_on_area_entered)
    _area_node.area_exited.connect(_on_area_exited)
    add_child(_area_node)

    _area_collision = CollisionPolygon2D.new()
    _area_collision.name = "CollisionPolygon"
    _area_collision.polygon = collision_polygon_node.polygon
    _area_node.add_child(_area_collision)


func _physics_process(_delta: float)-> void:
    var _to_remove: Array = []
    for _id in _soldiers_in_area:
        _soldiers_in_area[_id] -= 1
        if _soldiers_in_area[_id] <= 0:
            _soldiers_in_area[_id] = damage_interval

            _apply_damage_to_soldier(_id)
    for _id in _to_remove:
        _soldiers_in_area.erase(_id)


func _on_area_entered(_area: Area2D)-> void:
    var _soldier: BSSoldier = _area.get_parent()
    if _soldier != null:
        _soldiers_in_area[_soldier.get_instance_id()] = damage_interval


func _on_area_exited(_area: Area2D)-> void:
    var _soldier: BSSoldier = _area.get_parent()
    if _soldier != null:
        _soldiers_in_area.erase(_soldier.get_instance_id())


func _apply_damage_to_soldier(_soldier_id: int)-> void:

    var _soldier: BSSoldier = instance_from_id(_soldier_id) as BSSoldier
    if _soldier == null:
        return

    var _dmg: float = damage_per_second * damage_interval / 60.0
    _soldier.bs_soldier_prop.current_hp -= _dmg


    if _soldier.bs_soldier_prop.current_hp <= 0:
        _soldier.bs_soldier_prop.current_hp = 0
        _soldiers_in_area.erase(_soldier_id)


func init_from_config(_config: Dictionary)-> void:
    super.init_from_config(_config)
    damage_per_second = _config.get("damage_per_second", 10.0)
    damage_interval = _config.get("damage_interval", 30)