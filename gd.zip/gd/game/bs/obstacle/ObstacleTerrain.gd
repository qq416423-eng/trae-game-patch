class_name ObstacleTerrain extends BattleObstacleBase



@export var cavalry_deceleration_ratio: float = 0.4


@export var infantry_deceleration_ratio: float = 0.15


var _slowed_soldiers: Dictionary = {}


func _ready()-> void:
    obstacle_type = OBSTACLE_TYPE.TERRAIN
    obstacle_name = "地形障碍"
    obstacle_color = Color(0.2, 0.5, 0.2, 0.4)
    super._ready()
    _create_detect_area()


func _create_detect_area()-> void:
    var _area_node: Area2D = Area2D.new()
    _area_node.name = "DetectArea"
    _area_node.collision_layer = 0
    _area_node.collision_mask = 0
    _area_node.body_entered.connect(_on_body_entered)
    _area_node.body_exited.connect(_on_body_exited)
    add_child(_area_node)

    var _area_collision: CollisionPolygon2D = CollisionPolygon2D.new()
    _area_collision.name = "CollisionPolygon"
    _area_collision.polygon = collision_polygon_node.polygon
    _area_node.add_child(_area_collision)


func _on_body_entered(_body: Node2D)-> void:
    var _soldier: BSSoldier = _body as BSSoldier
    if _soldier == null:
        return

    var _id: int = _soldier.get_instance_id()
    if _slowed_soldiers.has(_id):
        return

    var _ratio: float = infantry_deceleration_ratio
    if not SoldierUtils.is_infantry(_soldier.bs_soldier_prop):
        _ratio = cavalry_deceleration_ratio

    _soldier.update_speed_mult(1.0 - _ratio)
    _slowed_soldiers[_id] = true


func _on_body_exited(_body: Node2D)-> void:
    var _soldier: BSSoldier = _body as BSSoldier
    if _soldier == null:
        return

    var _id: int = _soldier.get_instance_id()
    if _slowed_soldiers.has(_id):
        _soldier.update_speed_mult(1.0)
        _slowed_soldiers.erase(_id)


func init_from_config(_config: Dictionary)-> void:
    super.init_from_config(_config)
    cavalry_deceleration_ratio = _config.get("cavalry_slow", 0.4)
    infantry_deceleration_ratio = _config.get("infantry_slow", 0.15)