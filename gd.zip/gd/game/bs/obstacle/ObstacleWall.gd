class_name ObstacleWall extends BattleObstacleBase


func _ready()-> void:
    obstacle_type = OBSTACLE_TYPE.WALL
    obstacle_name = "墙壁"
    obstacle_color = Color(0.45, 0.42, 0.38, 0.9)
    super._ready()


func on_damage(_amount: float)-> void:

    pass