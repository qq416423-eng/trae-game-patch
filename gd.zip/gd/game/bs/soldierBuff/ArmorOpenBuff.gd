class_name ArmorOpenBuff extends BuffBase

func _custom_init(_buff_props: Dictionary)-> void:
    pass

func _custom_apply_effect()-> void:
    soldier_node.armor_open()

func _custom_remove_effect()-> void:
    soldier_node.armor_open_cancel()