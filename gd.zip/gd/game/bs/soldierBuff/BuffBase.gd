class_name BuffBase extends Node

@export var buff_icon: Texture2D

@export var is_boon: = false


var time_left_seconds: = 5.0
var soldier_node: BSSoldier

func init(_soldier_node: BSSoldier, _buff_props: Dictionary = {})-> void:
    soldier_node = _soldier_node
    if _buff_props.has("time_left_seconds"):
        time_left_seconds = _buff_props.time_left_seconds
        if is_boon and soldier_node.bs_soldier_prop.buff_duration_bonus_rate > 0:
            time_left_seconds *=(1 + soldier_node.bs_soldier_prop.buff_duration_bonus_rate)

    _custom_init(_buff_props)

func apply_effect()-> void:

    soldier_node.show_buff_icon(buff_icon)
    _custom_apply_effect()

func remove_effect()-> void:
    _custom_remove_effect()



func subtract_time_left_seconds(_subtract_time_seconds: float)-> bool:
    time_left_seconds -= _subtract_time_seconds
    return time_left_seconds <= 0

func remove_effect_and_delete()-> void:
    remove_effect()
    _delete()

func update(_buff_props: Dictionary)-> void:
    if _buff_props.has("time_left_seconds"):
        time_left_seconds = _buff_props.time_left_seconds

func _delete()-> void:
    self.queue_free()

func _custom_init(_buff_props: Dictionary)-> void:
    pass

func _custom_apply_effect()-> void:
    pass

func _custom_remove_effect()-> void:
    pass