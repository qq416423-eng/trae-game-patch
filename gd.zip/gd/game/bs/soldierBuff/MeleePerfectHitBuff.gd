class_name MeleePerfectHitBuff extends BuffBase

func _custom_init(_buff_props: Dictionary)-> void:
    pass

func _custom_apply_effect()-> void:
    soldier_node.melee_perfect_hit()

func _custom_remove_effect()-> void:
    soldier_node.cancel_melee_perfect_hit()