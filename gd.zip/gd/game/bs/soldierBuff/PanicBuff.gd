class_name PanicBuff extends BuffBase


var attack_reduction_ratio = 0.2

func _custom_init(_buff_props: Dictionary)-> void:
    if _buff_props.has("attack_reduction_ratio"):
        attack_reduction_ratio = _buff_props.attack_reduction_ratio

func _custom_apply_effect()-> void:

    soldier_node.plus_atk_ratio(- attack_reduction_ratio)

func _custom_remove_effect()-> void:

    soldier_node.plus_atk_ratio(attack_reduction_ratio)