class_name PlusAtkBuff extends BuffBase


var attack_plus_ratio = 0.1

func _custom_init(_buff_props: Dictionary)-> void:
    if _buff_props.has("attack_plus_ratio"):
        attack_plus_ratio = _buff_props.attack_plus_ratio

func _custom_apply_effect()-> void:
    soldier_node.plus_atk_ratio(attack_plus_ratio)

func _custom_remove_effect()-> void:
    soldier_node.plus_atk_ratio(- attack_plus_ratio)