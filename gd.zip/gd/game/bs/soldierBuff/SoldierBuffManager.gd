class_name SoldierBuffManager extends Node

const COUNTER_INTERVAL = 30



var buff_node_dic: = {}
var soldier_node: BSSoldier
var is_active: = false
var interval_delta: = 0.0
var counter: = 0

func _ready()-> void:
    soldier_node = owner
    set_physics_process(false)

func _physics_process(delta: float)-> void:
    interval_delta += delta
    counter += 1
    if CommonUtils.counter_is_true(counter, COUNTER_INTERVAL):
        _handle_buff_expire(interval_delta)
        interval_delta = 0.0

func add_buff(
    _buff_type_enum: String,
    _buff_props: Dictionary = {}
)-> void:
    if CommonUtils.get_value(_buff_props, "allow_cover", false) and buff_node_dic.has(_buff_type_enum):

        buff_node_dic[_buff_type_enum].update(_buff_props)
        buff_node_dic[_buff_type_enum].apply_effect()
        return

    if not CommonUtils.get_value(_buff_props, "allow_repeat", false) and buff_node_dic.has(_buff_type_enum):

        return

    var _preload_node: PackedScene = SoldierBuffUtils.get_buff_preload_node(_buff_type_enum)
    var _buff_node: BuffBase = _preload_node.instantiate()
    add_child(_buff_node)
    _buff_node.init(soldier_node, _buff_props)
    _buff_node.apply_effect()

    buff_node_dic[_buff_type_enum] = _buff_node
    if not is_active:
        _run()

func _handle_buff_expire(_interval_delta: float)-> void:
    var _remove_key_list: = []
    for _buff_type_enum: String in buff_node_dic.keys():
        var _node: BuffBase = buff_node_dic.get(_buff_type_enum)
        if _node.subtract_time_left_seconds(_interval_delta):
            _node.remove_effect_and_delete()
            _remove_key_list.append(_buff_type_enum)

    for _buff_type_enum: String in _remove_key_list:
        buff_node_dic.erase(_buff_type_enum)

    if buff_node_dic.is_empty():
        _stop()

func _stop()-> void:
    set_physics_process(false)
    is_active = false

func _run()-> void:
    set_physics_process(true)
    is_active = true