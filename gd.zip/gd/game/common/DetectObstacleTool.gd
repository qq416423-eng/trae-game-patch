class_name DetectObstacleTool extends Area2D

@onready var collision_shape_2d_node: CollisionShape2D =$CollisionShape2D

func set_detect_area(
    _start_position: Vector2, _end_position: Vector2,
    _is_mirrored: = false
):
    self.monitoring = true
    var _distance: float = _start_position.distance_to(_end_position)
    collision_shape_2d_node.shape.size.x = _distance
    collision_shape_2d_node.position.x = _distance / 2
    if not _is_mirrored:
        self.rotation =(_end_position - _start_position).angle()
    else:
        self.rotation = -(_end_position - _start_position).angle() + PI

func detect()-> Array:
    var _area_list: = get_overlapping_areas()
    self.monitoring = false
    collision_shape_2d_node.shape.size.x = 0
    return _area_list