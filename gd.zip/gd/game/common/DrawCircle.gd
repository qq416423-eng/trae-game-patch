class_name DrawCircle extends Node2D

@export var get_radius_func_name: = "get_draw_circle_radius"
@export var circle_color: = CommonConstants.COLOR_ENUM.GRAY_LUCENCY

func _physics_process(delta: float)-> void:
    queue_redraw()

func _draw()-> void:
    draw_arc(Vector2(0, 0), owner.call(get_radius_func_name), 0, 360, 40, circle_color, 2)