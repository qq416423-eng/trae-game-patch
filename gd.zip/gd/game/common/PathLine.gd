class_name PathLine extends Line2D








func cshow():
    self.show()

func chide():
    self.hide()