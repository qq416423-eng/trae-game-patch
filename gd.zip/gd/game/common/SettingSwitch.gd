@tool
class_name SettingSwitch extends Control

@onready var setting_switch_button_node: SettingSwitchButton =$HBoxContainer / SettingSwitchButton

signal switch_sign(_field: String, _value: bool)

@export var content: String = "content":
    set(_value):
        content = _value
        CommonUtils.set_text($HBoxContainer / Content, _value)

@export var ture_tip: String = "开启":
    set(_value):
        ture_tip = _value
        $HBoxContainer / SettingSwitchButton.update_true_tip(_value)

@export var false_tip: String = "关闭":
    set(_value):
        false_tip = _value
        $HBoxContainer / SettingSwitchButton.update_false_tip(_value)

@export var setting_field: = ""

func update_value(_value: bool)-> void:
    setting_switch_button_node.update_value(_value)

func _on_setting_switch_button_switch_sign(_value: bool)-> void:
    switch_sign.emit(setting_field, _value)