class_name ShadowDashedLine extends Node2D

@onready var line_shadow: Line2D =$LineShadow
@onready var line: Line2D =$Line

@export var shadow_height: = 6

var global_min_x: = 0.0
var global_min_y: = 0.0
var global_max_x: = 0.0
var global_max_y: = 0.0

func _ready()-> void:
    line.position.y = line_shadow.position.y - shadow_height

func init(_center_position: Vector2, range_vector: Vector2)-> void:
    self.position = _center_position
    var _start_point: = range_vector / -2
    var _points = [
        _start_point,
        Vector2(- _start_point.x, _start_point.y),
        Vector2(- _start_point.x, - _start_point.y),
        Vector2(_start_point.x, - _start_point.y)
    ]

    line_shadow.points = _points
    line.points = _points

    global_min_x = line_shadow.points[0].x + self.global_position.x
    global_min_y = line_shadow.points[0].y + self.global_position.y
    global_max_x = line_shadow.points[2].x + self.global_position.x
    global_max_y = line_shadow.points[2].y + self.global_position.y

func cshow():
    self.show()

func is_within_range(_check_point: Vector2)-> bool:
    if _check_point.x < global_min_x or _check_point.x > global_max_x:
        return false

    if _check_point.y < global_min_y or _check_point.y > global_max_y:
        return false

    return true