extends BaseDialogue



static var APPOINT_OPTION = {
    "otype": OPTION_TYPE_ENUM.TALK,
    "oname": "任命",
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "custom_choose_func": {
        "func_name": "has_selected_hero_to_appoint",
    },
    "content": [
        {
            "clist": [
                "请帮我将选中的英雄任命为独立队伍。",
            ],
            "custom_func": {
                "func_name": "handle_appoint_hero",
            },
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": [
                            "好的，已安排妥当。他现在可以独立带队了。",
                        ],
                    }
                ],
            }
        }
    ],
}



static var APPOINT_OPTION_NO_HERO = {
    "otype": OPTION_TYPE_ENUM.TALK,
    "oname": "任命（请先在队伍界面中选中要任命的英雄）",
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "custom_choose_func": {
        "func_name": "can_appoint_hero",
    },
    "content": [
        {
            "clist": [
                "请先在队伍界面中选中一个英雄，再来找我任命。",
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": [
                            "好的，请先选择要任命的英雄。",
                        ],
                    }
                ],
            }
        }
    ],
}



static var DEFAULT_DIALOGUE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "你好，需要我帮忙分派人手吗？如果你想让某个英雄独立带队，我可以帮你安排。",
            ],
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            APPOINT_OPTION_NO_HERO,
            APPOINT_OPTION,
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说。",
                        ],
                    }
                ],
            },
        ]
    }
}


func get_current_dialogue_template()-> Dictionary:
    return DEFAULT_DIALOGUE


func get_battle_chat_charge()-> String:
    return[
        "全军突击！",
        "冲锋！",
        "跟我上！",
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "前进！",
        "加快脚步！",
        "保持阵型！",
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "进攻！",
        "拔剑！",
        "杀！",
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你找错对手了",
        "承让了！",
        "毫无威胁",
    ]
    return _list.pick_random()


func get_battle_chat_injured()-> String:
    return[
        "小伤而已！",
        "这点程度还打不倒我！",
        "咳...还没完！",
    ].pick_random()


func get_battle_chat_die()-> String:
    return[
        "抱歉...",
        "这就是...终点了吗...",
        "可恶...",
    ].pick_random()


func get_battle_chat_vectory()-> String:
    return[
        "干得漂亮！",
        "我们赢了！",
        "一场伟大的胜利！",
    ].pick_random()