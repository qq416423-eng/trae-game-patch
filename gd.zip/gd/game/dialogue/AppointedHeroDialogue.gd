extends BaseDialogue

var appointed_hero_uid: String = ""
var is_in_battle: bool = false


func get_current_dialogue_template()-> Dictionary:
    if appointed_hero_uid == "":
        return {}

    var _option_list = []


    if is_in_battle:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.BATTLE,
            "oname": "加入战斗",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["我来助你一臂之力！"]}],
        })


    if DialogueCustomUtils.has_loot_for_appointed_team(appointed_hero_uid):
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "收缴战利品",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "custom_func": {
                "func_name": "collect_loot_from_appointed_team",
                "params": [appointed_hero_uid]
            },
            "content": [{"clist": ["把你战斗中获得的战利品交上来。"]}],
            "next": _T_LOOT_COLLECTED(),
        })

    _option_list.append_array([
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "行动指令",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["我有新的指令给你。"]}],
            "next": _T_ACTION_SUB_MENU(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "兵力调配",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["我们来调整一下兵力分配。"]}],
            "next": _T_TROOP_SUB_MENU(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "分队驻扎",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["选择你的驻扎方式。"]}],
            "next": _T_GARRISON_SUB_MENU(),
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [{"clist": ["继续执行你的任务。"]}],
        }
    ])

    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }


func _T_ACTION_SUB_MENU():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "跟随",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_follow_appointed_team",
                    "params": [appointed_hero_uid]
                },
                "content": [
                    {
                        "custom_choose_func": {
                            "func_name": "is_appointed_team_not_following",
                            "params": [appointed_hero_uid]
                        },
                        "clist": ["跟随我的队伍，我们一起行动。"],
                        "next": _T_FOLLOW_START(),
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "跟随作战",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_combat_follow_appointed_team",
                    "params": [appointed_hero_uid]
                },
                "content": [
                    {
                        "custom_choose_func": {
                            "func_name": "is_appointed_team_not_combat_following",
                            "params": [appointed_hero_uid]
                        },
                        "clist": ["跟随我作战，看到敌人就主动出击！"],
                        "next": _T_COMBAT_FOLLOW_START(),
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "停止跟随",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "stop_follow_appointed_team",
                    "params": [appointed_hero_uid]
                },
                "content": [
                    {
                        "custom_choose_func": {
                            "func_name": "is_appointed_team_following",
                            "params": [appointed_hero_uid]
                        },
                        "clist": ["不用再跟着我了，原地待命吧。"],
                        "next": _T_FOLLOW_STOP(),
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "停止跟随作战",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "stop_combat_follow_appointed_team",
                    "params": [appointed_hero_uid]
                },
                "content": [
                    {
                        "custom_choose_func": {
                            "func_name": "is_appointed_team_combat_following",
                            "params": [appointed_hero_uid]
                        },
                        "clist": ["不用再跟随作战了，原地待命吧。"],
                        "next": _T_FOLLOW_STOP(),
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "返回",
                "content": [{"clist": ["算了，没什么。"]}],
            }
        ]
    }



func _T_GARRISON_SUB_MENU():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "原地驻守",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["你就在此地驻守巡视。"]}],
                "next": _T_STATIONARY_GUARD_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "巡逻各地",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["我需要你去某个区域巡逻。"]}],
                "next": _T_PATROL_REGION_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "返回",
                "content": [{"clist": ["算了，改天再说。"]}],
            }
        ]
    }



func _T_STATIONARY_GUARD_MENU():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "不攻击领主",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_patrol_appointed_team_no_lord",
                    "params": [appointed_hero_uid]
                },
                "content": [{"clist": ["在此地驻守巡视，但不要攻击领主。"]}],
                "next": _T_PATROL_START_NO_LORD(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "正常驻守",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_patrol_appointed_team",
                    "params": [appointed_hero_uid]
                },
                "content": [{"clist": ["在此地驻守巡视，遇到敌军就主动出击！"]}],
                "next": _T_PATROL_START(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "攻击驻卫队",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_patrol_appointed_team_attack_garrison",
                    "params": [appointed_hero_uid]
                },
                "content": [{"clist": ["在此地驻守巡视，优先攻击村庄驻卫队！"]}],
                "next": _T_PATROL_START_ATTACK_GARRISON(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "补兵巡逻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_replenish_patrol_appointed_team",
                    "params": [appointed_hero_uid]
                },
                "content": [{"clist": ["在此地驻守巡视，人数不足时自动前往己方领地补充兵力。"]}],
                "next": _T_PATROL_START_REPLENISH(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "返回",
                "content": [{"clist": ["算了，不驻守了。"]}],
            }
        ]
    }


func _T_PATROL_REGION_MENU():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "巡视罗奥",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "set_temp_region_patrol_ethnicity",
                    "params": [WSCountryData.ETHNICITY_ENUM.ROAO]
                },
                "content": [{"clist": ["去罗奥地区巡视。"]}],
                "next": _T_REGION_PATROL_SUB_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "巡视塞娜",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "set_temp_region_patrol_ethnicity",
                    "params": [WSCountryData.ETHNICITY_ENUM.SAINA]
                },
                "content": [{"clist": ["去塞娜地区巡视。"]}],
                "next": _T_REGION_PATROL_SUB_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "巡视马尔科",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "set_temp_region_patrol_ethnicity",
                    "params": [WSCountryData.ETHNICITY_ENUM.MARKA]
                },
                "content": [{"clist": ["去马尔科地区巡视。"]}],
                "next": _T_REGION_PATROL_SUB_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "巡视沙鲁克",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "set_temp_region_patrol_ethnicity",
                    "params": [WSCountryData.ETHNICITY_ENUM.SHALUK]
                },
                "content": [{"clist": ["去沙鲁克地区巡视。"]}],
                "next": _T_REGION_PATROL_SUB_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "巡视罗德里大陆",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "set_temp_region_patrol_ethnicity",
                    "params": [""]
                },
                "content": [{"clist": ["巡视整片罗德里大陆。"]}],
                "next": _T_REGION_PATROL_SUB_MENU(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "返回",
                "content": [{"clist": ["算了，改天再说。"]}],
            }
        ]
    }



func _T_REGION_PATROL_SUB_MENU():
    var _ethnicity: String = DialogueCustomUtils._temp_region_ethnicity
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "不攻击领主",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_region_patrol_no_lord",
                    "params": [appointed_hero_uid, _ethnicity]
                },
                "content": [{"clist": ["在该区域巡逻，但不要攻击领主。"]}],
                "next": _T_PATROL_START_NO_LORD(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "正常巡逻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_region_patrol",
                    "params": [appointed_hero_uid, _ethnicity]
                },
                "content": [{"clist": ["在该区域巡逻，遇到敌人就主动出击！"]}],
                "next": _T_PATROL_START(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "攻击驻卫队",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_region_patrol_attack_garrison",
                    "params": [appointed_hero_uid, _ethnicity]
                },
                "content": [{"clist": ["在该区域巡逻，优先攻击村庄驻卫队！"]}],
                "next": _T_PATROL_START_ATTACK_GARRISON(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "补兵巡逻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "start_replenish_region_patrol_appointed_team",
                    "params": [appointed_hero_uid, _ethnicity]
                },
                "content": [{"clist": ["在该区域巡逻，人数不足时自动前往己方领地补充兵力。"]}],
                "next": _T_PATROL_START_REPLENISH(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "返回",
                "content": [{"clist": ["算了，不巡逻了。"]}],
            }
        ]
    }


func _T_TROOP_SUB_MENU():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "分兵",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["分一些士兵过来，增强你的队伍实力。"]}],
                "next": _T_SPLIT_SOLDIER_SELECTION(),
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "英雄分配",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {
                            "func_name": "is_appointed_team_hero_slots_full",
                            "params": [appointed_hero_uid]
                        },
                        "clist": ["我想派一位英雄加入你的分队。"],
                        "next": _T_HERO_ASSIGNMENT_FULL(),
                    },
                    {
                        "clist": ["我想派一位英雄加入你的分队。"],
                        "next": _T_HERO_ASSIGNMENT_SELECTION(),
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "归队",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {
                    "func_name": "return_appointed_hero_to_player",
                    "params": [appointed_hero_uid]
                },
                "content": [{"clist": ["归队吧，我们合并一处。"]}],
                "next": _T_RETURN_DONE(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "返回",
                "content": [{"clist": ["算了，没什么。"]}],
            }
        ]
    }


func _T_SPLIT_SOLDIER_SELECTION():
    var _soldier_list: Array = DialogueCustomUtils.get_appointable_soldier_list()
    var _option_list: Array = []
    for _soldier in _soldier_list:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _soldier.name + "（" + str(_soldier.count) + "人）",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["分配一些" + _soldier.name + "给你的队伍。"]}],
            "next": _T_SPLIT_COUNT_SELECTION(_soldier.uid, _soldier.name),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "返回",
        "content": [{"clist": ["算了，不分配了。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }



func _T_SPLIT_COUNT_SELECTION(_soldier_uid: String, _soldier_name: String = ""):
    var _option_list: Array = []
    for _count in[10, 50, 100]:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "分" + str(_count) + "名",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "custom_func": {
                "func_name": "split_specific_soldier_to_appointed_team",
                "params": [appointed_hero_uid, _soldier_uid, _count]
            },
            "content": [{"clist": ["分" + str(_count) + "名" + _soldier_name + "给你的队伍。"]}],
            "next": _T_SPLIT_DONE(),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "返回",
        "content": [{"clist": ["算了，不分配了。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }


static func _T_SPLIT_DONE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["好的，士兵已分配完毕。需要更多士兵的话随时来找我。"]}],
    }



func _T_HERO_ASSIGNMENT_SELECTION():
    var _hero_list: Array = DialogueCustomUtils.get_assignable_hero_list_for_appointed_team()
    var _option_list: Array = []
    if _hero_list.is_empty():
        return {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [{"clist": ["你队伍里没有其他可以分配的英雄了。"]}],
        }
    for _hero in _hero_list:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _hero.name,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "custom_func": {
                "func_name": "assign_hero_to_appointed_team",
                "params": [appointed_hero_uid, _hero.uid]
            },
            "content": [{"clist": ["派" + _hero.name + "加入你的分队，协助你作战。"]}],
            "next": _T_HERO_ASSIGNMENT_DONE(),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "返回",
        "content": [{"clist": ["算了，暂不分配。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }



static func _T_HERO_ASSIGNMENT_FULL():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["抱歉，我的分队英雄位已满，无法再接收更多英雄了。"]}],
    }



static func _T_HERO_ASSIGNMENT_DONE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["好的，欢迎新伙伴的加入！我们配合得一定会很好。"]}],
    }


static func _T_COMBAT_FOLLOW_START():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白！我们紧跟在你身后，附近有敌人立刻出击！"]}],
    }


static func _T_FOLLOW_START():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白，我们会紧跟你的队伍。"]}],
    }


static func _T_FOLLOW_STOP():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["好的，我们在此待命。"]}],
    }


static func _T_PATROL_START():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白，我会在此地巡逻，遇到敌人绝不放过！"]}],
    }


static func _T_PATROL_START_NO_LORD():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白，我会在此地巡逻，不会攻击领主。"]}],
    }


static func _T_PATROL_START_ATTACK_GARRISON():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白，我会在此地巡逻，优先攻击村庄驻卫队！"]}],
    }


static func _T_PATROL_START_REPLENISH():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白，我会边巡逻边回己方领地补充兵力！"]}],
    }


static func _T_LOOT_COLLECTED():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["战利品已全部上缴，请查收。"]}],
    }


static func _T_RETURN_DONE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["明白，我们这就归队。"]}],
    }



func get_battle_chat_charge()-> String:
    return[
        "随我冲锋!",
        "全军出击!",
        "阵型不乱, 胜利可期!",
    ].pick_random()

func get_battle_chat_move()-> String:
    return[
        "稳步前进.",
        "向前推进!",
        "保持警戒.",
    ].pick_random()

func get_battle_chat_attack()-> String:
    return[
        "就是现在, 进攻!",
        "瞄准敌军弱点!",
    ].pick_random()

func get_battle_chat_injured()-> String:
    return[
        "无妨, 还能再战.",
        "这点小伤不足挂齿.",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "棋差一着...",
        "抱歉...",
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "一切尽在掌握.",
        "此番胜利, 全赖将士用命.",
    ].pick_random()