extends Node
class_name BaseDialogue

const STEP_TYPE_ENUM = DialogueConstants.STEP_TYPE_ENUM
const OPTION_TYPE_ENUM = DialogueConstants.OPTION_TYPE_ENUM
const SPEAKER_ENUM = DialogueConstants.SPEAKER_ENUM
const CONTENT_CONDITION_ENUM = DialogueConstants.CONTENT_CONDITION_ENUM


var a_team_dialogue_info: Dictionary






var b_team_dialogue_info: Dictionary

func set_a_team_dialogue_info(_a_team_dialogue_info: Dictionary)-> void:
    a_team_dialogue_info = _a_team_dialogue_info

func set_b_team_dialogue_info(_b_team_dialogue_info: Dictionary)-> void:
    b_team_dialogue_info = _b_team_dialogue_info

func get_current_dialogue_template()-> Dictionary:
    return {}


func get_final_dialogue_template()-> Dictionary:
    return {}

func get_hero_uid()-> String:
    return ""

func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    return {}

func get_battle_chat_charge()-> String:
    return[
        "全军冲锋!",
        "击碎他们!",
        "进攻!",
        "就是现在, 进攻!",
        "全军突击!",
        "撕碎他们!"
    ].pick_random()

func get_battle_chat_move()-> String:
    return[
        "跟上步伐!",
        "动作迅速!",
        "前进!",
        "保持阵型!",
        "移动!"
    ].pick_random()

func get_battle_chat_attack()-> String:
    return[
        "突击! 目标就在那!",
        "进攻那个目标!",
        "摧毁他们!",
        "集中攻击!",
        "让他们付出代价!",
        "一个不留!",
        "给我上!",
        "干掉他们!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "已击杀敌将!",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "我快撑不住了...",
        "该死!",
        "血...止不住了...",
        "视线...模糊了...",
        "呃啊...",
        "还没结束...",
        "支撑住!",
        "坚持住!",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "到此为止了吗...",
        "啊~",
        "可...恶...",
        "呃啊..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 我们坚守阵地!",
        "援军来了! 撑住!"
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "推进!",
        "稳步前进! 不要冒险!",

    ].pick_random()

func get_battle_chat_ai_enemy_charge_chat()-> String:
    return[
        "全军冲锋!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "坚守阵地!",
        "不要冒险! 坚守阵地!",
        "死守防线!",

    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "胜利属于我们!"
    ].pick_random()


func get_captured_dialogue_after_battle()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "str_from_func": [
                    {
                        "func_name": "get_captured_dialogue_after_battle_player_content",
                    }
                ],
                "clist": [
                     "#{0}",

                ]
            }
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "str_from_func": [
                        {
                            "func_name": "get_captured_dialogue_after_battle_content",
                        }
                    ],
                    "clist": [
                        "#{0}",

                    ]
                }
            ],
        }
    }

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "老实点, 不要耍什么花样."
        ]
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    return[
        [
            "我保证我不会."
        ]
    ]


func get_captured_wait_for_release_dialogue()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [
            {
                "str_from_func": [
                    {
                        "func_name": "get_hero_wait_for_release_dialogue_content",
                    }
                ],
                "clist": [
                     "#{0}",

                ]
            }
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS_2,
            "str_from_func": [
                {
                    "func_name": "get_prisoner_earn_release_content",
                }
            ],
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "icon": "res://resource/icon/locationButtonIcon/extort_icon.png",
                    "oname": "要赎金",
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_release_hero_ransom_amount",
                                }
                            ],
                            "clist": _get_release_hero_ransom_amount_content()



                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.TALK,
                                "icon": "res://resource/icon/locationButtonIcon/extort_icon.png",
                                "oname": "成交",
                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                "content": [
                                    {
                                        "custom_func": {
                                            "func_name": "player_released_hero_choose_ransom",
                                        },
                                        "str_from_func": [
                                            {
                                                "func_name": "get_hero_released_by_ransom_content",
                                            }
                                        ],
                                        "clist": [
                                            "#{0}"

                                        ]
                                    }
                                ]
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "oname": "离开",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "下次再说."
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                },
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "icon": "res://resource/icon/locationButtonIcon/extort_treasure_icon.png",
                    "oname": "要宝物",
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "custom_choose_func": {
                        "func_name": "check_hero_use_equipment_for_release",
                    },
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_release_hero_equipment_info",
                                }
                            ],
                            "clist": _get_release_hero_equipment_content()



                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.TALK,
                                "icon": "res://resource/icon/locationButtonIcon/extort_treasure_icon.png",
                                "oname": "成交",
                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                "content": [
                                    {
                                        "custom_func": {
                                            "func_name": "player_released_hero_choose_equipment",
                                        },
                                        "str_from_func": [
                                            {
                                                "func_name": "get_hero_released_by_ransom_content",
                                            }
                                        ],
                                        "clist": [
                                            "#{0}"

                                        ]
                                    }
                                ]
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "oname": "离开",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "下次再说."
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                },
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "icon": "res://resource/icon/locationButtonIcon/release_icon.png",
                    "oname": "直接释放",
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "custom_choose_func": {
                        "func_name": "check_hero_is_lord",
                    },
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_direct_release_confirmation_content",
                                }
                            ],
                            "clist": [
                                "#{0}"

                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.TALK,
                                "icon": "res://resource/icon/locationButtonIcon/release_icon.png",
                                "oname": "确定释放",
                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                "content": [
                                    {
                                        "custom_func": {
                                            "func_name": "player_released_hero_freely",
                                        },
                                        "str_from_func": [
                                            {
                                                "func_name": "get_hero_released_freely_content",
                                            }
                                        ],
                                        "clist": [
                                            "#{0}"

                                        ]
                                    }
                                ]
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "oname": "离开",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "下次再说."
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "oname": "离开",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [
                        {
                            "clist": [
                                "下次再说."
                            ]
                        }
                    ]
                }
            ]
        }
    }


func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        [
            "咱们来谈点实际的."
        ]
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "我的家人会出 [#{0}] 德里换我的自由, 如何?"
    ]



func get_hero_released_by_ransom_content()-> Array:
    return[
        [
            "很好, 下次见面我会让你好看."
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "我用我的宝物 - [#{0}] 换取我的自由, 如何?"
    ]


func get_direct_release_confirmation_content()-> Array:
    return[
        [
            "我没听错吧? 你要直接放了我吗?"
        ]
    ]

func get_hero_released_freely_content()-> Array:
    return[
        [
            "那我走了, 你别后悔."
        ]
    ]