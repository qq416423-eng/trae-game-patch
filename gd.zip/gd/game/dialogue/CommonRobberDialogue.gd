extends BaseDialogue

const FEAR_DIALOGUE_0001 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "你们想干嘛!!!",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "content": [
                    {
                        "clist": [
                            "还用问吗? 当然是审判你!",
                            "接受审判吧强盗们!",
                            "一群恶棍, 今天就是你们的末日!"
                        ]
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

const FEAR_DIALOGUE_0002 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "别...别乱来! 我只是混口饭吃!",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "content": [
                    {
                        "clist": [
                            "那正好, 我也混口饭吃.",
                            "哦? 在我的剑穿过你的肚子之后, 我就知道你最近吃得饱不饱了."
                        ]
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

const FEAR_DIALOGUE_0003 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "真晦气! 碰上硬茬了!",
                "想找茬?"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "content": [
                    {
                        "clist": [
                            "兄弟们准备好!",
                            "我们上!!!"
                        ]
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

const HAPPY_DIALOGUE_0001 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "哟哟哟, 兄弟们, 看看这是什么?",
                "啊哈!",
                "是自己把钱交出来呢, 还是让我亲自动手?",
                "啧啧, 看着你们这模样, 掏空了恐怕也没几个德里吧?",
                "看来你们今天出门前没做祷告啊哈哈哈.",
                "哦嚯, 刚说缺钱花, 钱就送上门来了",
                "别怪我没给你机会, 速速把钱交出来!",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "迎战",
                "content": [
                    {
                        "clist": [
                            "准备好了, 兄弟们, 他们要抢走我们的财富, 但我们不会屈服!",
                            "勇士们, 不要让这些恶棍们得逞!",
                            "我们上!!!"
                        ]
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.FLEE,
                "oname": "逃跑",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                        ]
                    }
                ]
            }
        ]
    }
}

const FRIENDLY_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "哟, 是自己人! 我们都是一条道上的.",
                "兄弟, 最近哪片地盘油水多?",
                "哈哈, 自己人! 别动手, 咱们井水不犯河水.",
                "哟, 强寇的兄弟! 有什么好买卖介绍介绍?",
                "自己人! 强寇的名号道上谁不知道, 有事您说话.",
                "兄弟, 要不要一起干一票? 人多力量大嘛.",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "can_recruit_robber"
                },
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "招募(#{0}德里)",
                "str_from_func": [
                    {
                        "func_name": "get_robber_recruit_cost",
                    }
                ],
                "custom_func": {
                    "func_name": "handle_robber_recruit",
                },
                "content": [
                    {
                        "clist": [
                            "兄弟, 带几个弟兄跟我一起干!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}


func get_current_dialogue_template()-> Dictionary:

    if DialogueCustomUtils.player_is_in_black_fang():
        return FRIENDLY_MEET

    if b_team_dialogue_info.is_chase_player:
        return HAPPY_DIALOGUE_0001
    else:
        if a_team_dialogue_info.combat_power > b_team_dialogue_info.combat_power:

            return[FEAR_DIALOGUE_0001].pick_random()
        else:
            return[
                FEAR_DIALOGUE_0001, FEAR_DIALOGUE_0002, FEAR_DIALOGUE_0003
            ].pick_random()