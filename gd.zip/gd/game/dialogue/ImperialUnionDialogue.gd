extends LordDialogueBase


# 帝国联盟军统帅专属对话
const HERO_UID: = "imperial_union_commander"

const CHASE_CHECK_DIALOGUE = {
	"step_type": STEP_TYPE_ENUM.DIALOG,
	"turn": DialogueConstants.SPEAKER_ENUM.B,
	"content": [
		{
			"clist": [
				"帝国联盟军奉命剿匪，例行检查还请停下。",
				"有问题，停下。",
			]
		}
	],
	"next": {
		"step_type": STEP_TYPE_ENUM.OPTION,
		"option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
		"option_list": [
			{
				"otype": OPTION_TYPE_ENUM.BATTLE,
				"oname": "攻击",
				"content": [
					{
						"clist": [
							"就是他们，全军列阵准备作战。",
							"就是他们，别让他们跑了，干掉他们！",
						]
					},
				]
			},
			{
				"otype": OPTION_TYPE_ENUM.FLEE,
				"oname": "逃跑",
				"content": [
					{
						"clist": [
							DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
						]
					}
				]
			}
		]
	}
}


func get_current_dialogue_template()-> Dictionary:
	return CHASE_CHECK_DIALOGUE


func get_battle_chat_charge()-> String:
	return[
		"露西安纳万胜！进攻！",
		"铁血万胜！冲锋！",
		"全军列阵！进攻！",
	].pick_random()


func get_battle_chat_ai_advancing_attack_chat()-> String:
	return[
		"投掷标枪！稳步前进",
		"结好盾墙，推过去！",
	].pick_random()


func get_battle_chat_ai_enemy_defensive_chat()-> String:
	return[
		"我们是山！",
		"插枪入土！我们如同山岳！",
		"以铁血为誓，绝不后退！",
	].pick_random()


func get_battle_chat_injured()-> String:
	return[
		"橡木钢铁，保我平安，护我周全，不坠地狱…",
		"以铁血为誓，绝不后退！",
		"他妈的，重组队形！",
	].pick_random()


func get_battle_chat_die()-> String:
	return[
		"以铁血为誓……",
		"我们是山……",
		"绝不后退！",
	].pick_random()


func get_captured_dialogue_after_battle_content()-> Array:
	return[
		[
			"你赢了，我把钱一交，你就把我一放，完事，但我迟早会回来为士兵报仇的。",
			"看你这眼神，怕不是想把我放竞技场里啊。",
		]
	]


func _get_release_hero_ransom_amount_content()-> Array:
	return[
		"你真不想把我放进竞技场里？那算了，[#{0}] 德里，我走人，绝不会像个香肠一样在这里骗吃骗喝。",
		"要钱你也要不了多少，[#{0}] 德里，他俩就只能凑出这么多。",
	]


func _get_release_hero_equipment_content()-> Array:
	return[
		"我这 [#{0}] 给你了，把我放出去。",
	]


func get_hero_released_by_ransom_content()-> Array:
	return[
		[
			"我还会回来的。",
			"我会为我的士兵报仇的。",
		]
	]
