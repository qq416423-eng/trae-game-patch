class_name LordBrutalDialogue extends LordDialogueBase


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "哼, 杀了几只杂碎, 就以为有资格站到我面前邀功了?",
        "表现得还算有点用处. 记住这种在战场上搏杀的感觉, 否则下次死的就是你.",
        "你今天的唯一价值, 就是没让敌人的血弄脏我的斗篷."
    ]


func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "哼, 没死在乱军之中, 说明你还有点利用价值."
    ]


func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈哈哈! 痛快! 今天我们俩在战场上杀得那群蠢货抱头鼠窜, 只有你能跟上我的节奏!"
    ]