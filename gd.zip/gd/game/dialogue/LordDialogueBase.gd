class_name LordDialogueBase extends BaseDialogue


const ATTENDANT_HERO_UID: = "minor_hero_0011"
const LOW_REPUTATION_TIP: = "(声望不足 #{0}/#{1})"


var ATTENDANT_DIALOGUE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "turn_hero_uid": ATTENDANT_HERO_UID,
    "content": _get_attendant_meet_content(),
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {
                            "func_name": "is_player_attack_lord_need_confirm",
                        },
                        "str_from_func": [
                            {
                                "func_name": "get_player_attack_lord_content",
                                "params": [LordConstants.MEET_LORD_TYPE_ENUM.MEET_BY_ATTENDANT]
                            }
                        ],
                         "clist": [
                            "#{0}"
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {

                                    "str_from_func": [
                                        {
                                            "func_name": "get_b_country_name",
                                        }
                                    ],
                                    "clist": _get_player_choose_attack_attendant_confirm_clist()
                                }
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.CONFIRM_DECLARE_WAR,
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.BATTLE,
                                        "oname": "确定进攻",
                                        "custom_func": {
                                            "func_name": "handle_player_attack_lord",
                                        },
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "content": [
                                            {
                                                "clist": _get_player_choose_attack_attendant_confirm_player_confirm_clist()
                                            }
                                        ]
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "oname": "取消进攻",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "content": [
                                            {
                                                "clist": _get_player_choose_attack_attendant_confirm_player_cancel_clist()
                                            }
                                        ]
                                    }
                                ]
                            }
                        }
                    },
                    {

                        "str_from_func": [
                            {
                                "func_name": "get_player_attack_lord_content",
                                "params": [LordConstants.MEET_LORD_TYPE_ENUM.MEET_BY_ATTENDANT]
                            }
                        ],
                        "clist": [
                            "#{0}"
                        ],
                        "custom_func": {
                            "func_name": "handle_player_attack_lord",
                        }
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "既然如此, 那我不打扰了.",
                            "我只是路过而已."
                        ]
                    },
                ]
            }
        ]
    }
}

var LORD_DEFAULT_DIALOGUE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "final_custom_func_list": [
        {
            "func_name": "update_meet_time",
        }
    ],
    "content": [
        {
            "str_from_func": [
                {
                    "func_name": "get_lord_meet_player_content",
                }
            ],
             "clist": [
                "#{0}"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_no_belong_country",
                },
                "str_from_func": [
                    {
                        "func_name": "get_b_country_name",
                    }
                ],
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入国家(#{0})",
                "content": [
                    {
                        "str_from_func": [
                            {
                                "func_name": "get_b_country_name",
                            }
                        ],
                        "clist": [
                            "若您允准，我愿为 [#{0}] 王国而战.",
                            "愿以忠诚之名，效力于 [#{0}] 王国.",
                            "请容我献上忠心，为您的国家效命."
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [

                        _ask_king_for_permission_lines_content_item(),

                        _king_response_to_join_rel_bad_request_content_item(),

                        _king_response_to_join_recent_leave_country_refuse_content_item(),

                        _king_response_to_join_reputation_not_enough_request_content_item(),

                        _king_response_to_join_reputation_enough_request_content_item(),
                    ],
                    "next": NEXT_LEAVE_OPTION
                }
            },

            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "turn": DialogueConstants.SPEAKER_ENUM.B,

                "custom_choose_func": {
                    "func_name": "is_not_same_country_as_player"
                },
                "content": [
                    {

                        "custom_choose_func": {
                            "func_name": "is_player_attack_lord_need_confirm",
                        },
                        "str_from_func": [
                            {
                                "func_name": "get_player_attack_lord_need_confirm_word"
                            }
                        ],
                        "clist": ["#{0}"],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.CONFIRM_DECLARE_WAR,
                            "str_from_func": [
                                {
                                    "func_name": "get_b_country_name",
                                }
                            ],
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.BATTLE,
                                    "oname": "确定进攻",
                                    "custom_func": {
                                        "func_name": "handle_player_attack_lord",
                                    },
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {

                                            "str_from_func": [
                                                {
                                                    "func_name": "player_attack_lord_reply_word"
                                                }
                                            ],
                                            "clist": ["#{0}"]
                                        }
                                    ]
                                },
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "取消进攻",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "custom_func": {

                                        "func_name": "handle_player_cancel_attack_lord",
                                    },
                                    "content": [
                                        {

                                            "str_from_func": [
                                                {
                                                    "func_name": "player_cancel_attack_lord_word"
                                                }
                                            ],
                                            "clist": ["#{0}"]
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    {

                        "str_from_func": [
                            {
                                "func_name": "player_attack_lord_reply_word"
                            }
                        ],
                        "clist": ["#{0}"]
                    }
                ],
            },

            {
                "otype": OPTION_TYPE_ENUM.LEAVE_COUNTRY,
                "oname": "退出国家",
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "custom_choose_func": {
                    "func_name": "allow_show_leave_country_option",
                },
                "content": [
                    {
                        "str_from_func": [
                            {
                                "func_name": "get_leave_country_king_confirm_response_content",
                            }
                        ],
                         "clist": [
                            "#{0}"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.OPTION,
                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.CONFIRM_LEAVE_COUNTRY,
                    "option_list": [
                        {
                            "otype": OPTION_TYPE_ENUM.LEAVE_COUNTRY,
                            "oname": "确定退出",
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {
                                "func_name": "handle_player_leave_country",
                            },
                            "content": [
                                {
                                    "str_from_func": [
                                        {
                                            "func_name": "get_leave_country_king_response_content"
                                        }
                                    ],

                                    "clist": ["#{0}"]
                                }
                            ]
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.LEAVE,
                            "oname": "取消",
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {
                                "func_name": "handle_player_cancel_leave_country",
                            },
                            "content": [
                                {
                                    "str_from_func": [
                                        {
                                            "func_name": "get_leave_country_cancel_king_response_content"
                                        }
                                    ],
                                    "clist": ["#{0}"]
                                }
                            ]
                        }
                    ]
                }
            },

            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "赠送宝物",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_choose_func": {
                    "func_name": "can_show_gift_equipment_option"
                },
                "custom_func": {
                    "func_name": "handle_gift_equipment_to_lord"
                },
                "content": [
                    {
                        "clist": [
                            "我想赠送一件宝物给您."
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哦? 您如此慷慨, 我很期待."
                            ]
                        }
                    ],
                    "next": NEXT_LEAVE_OPTION
                }
            },

            {
                "otype": OPTION_TYPE_ENUM.SUPPORT,
                "oname": "请求支援",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_choose_func": {
                    "func_name": "can_request_support"
                },
                "custom_func": {
                    "func_name": "handle_request_support"
                },
                "content": [
                    {
                        "clist": [
                            "我需要您的支援, 请助我一臂之力."
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "好, 我会带领我的军队跟随你一段时间."
                            ]
                        }
                    ],
                    "next": NEXT_LEAVE_OPTION
                }
            },

            LEAVE_OPTION
        ]
    }
}


var ATTACK_PLAYER = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "final_custom_func_list": [
        {
            "func_name": "update_meet_time",
        }
    ],
    "content": [
        {
            "str_from_func": [
                {
                    "func_name": "get_lord_meet_player_content",
                }
            ],
             "clist": [
                "#{0}"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "迎战",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "(我方选择迎战)"
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.FLEE,
                "oname": "逃跑",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                        ]
                    }
                ]
            }
        ]
    }
}


func _ask_king_for_permission_lines_content_item()-> Dictionary:
    return {
        "custom_choose_func": {
            "func_name": "check_b_is_not_king",
        },








        "str_from_func": [
            {
                "func_name": "ask_king_for_permission_lines_content"
            }
        ],
        "clist": ["#{0}"],
    }


func _king_response_to_join_rel_bad_request_content_item()-> Dictionary:
    return {
        "custom_choose_func": {
            "func_name": "check_player_rel_bad_to_join_country",
        },
        "str_from_func": [
            {
                "func_name": "king_reject_join_rel_bad_dialogue"
            }
        ],
        "clist": ["#{0}"],
    }


func _king_response_to_join_recent_leave_country_refuse_content_item()-> Dictionary:
    return {
        "custom_choose_func": {
            "func_name": "check_player_recent_leave_country_refuse_join_country",
        },
        "str_from_func": [
            {
                "func_name": "king_reject_join_recent_leave_country_dialogue"
            }
        ],
        "clist": ["#{0}"],
    }

func _king_response_to_join_reputation_not_enough_request_content_item()-> Dictionary:
    return {
        "custom_choose_func": {
            "func_name": "check_player_reputation_not_enough_to_join_country",
        },
        "str_from_func": [
            {
                "func_name": "get_player_reputation_value_int",
            },
            {
                "func_name": "get_join_country_need_reputation_value"
            }
        ],
        "clist": _king_reject_join_low_reputation_dialogue()
    }


func _king_response_to_join_reputation_enough_request_content_item()-> Dictionary:
    return {
        "custom_choose_func": {
            "func_name": "check_player_reputation_enough_to_join_country",
        },
        "clist": _king_agree_join_low_reputation_dialogue(),
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "我愿承担起贵族之责, 守护人民, 听从王命.",
                        "我将以忠诚与剑锋, 捍卫这片土地.",
                        "能被接纳为王国一员, 我深感荣幸."
                    ]
                }
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_func": {
                            "func_name": "player_join_b_kingdom",
                        },
                        "str_from_func": [
                            {
                                "func_name": "get_b_country_name",
                            }
                        ],
                        "clist": [
                            "(在一番庄严的宣誓与授封仪式后, 我正式加入了 [#{0}] 王国, 成为贵族之一)",
                            "(在国王的注视下，我宣誓忠诚，获封贵族之位，自此成为 [#{0}] 王国贵族的一员)",
                            "(经过国王的承认与授予, 我获得了 [#{0}] 王国贵族的身份)",
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {

                            "custom_choose_func": {
                                "func_name": "check_b_king_has_extra_fief",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "player_get_fief"
                                }
                            ],

                            "clist": _get_granted_fief_clist(),
                            "next": {
                                "step_type": STEP_TYPE_ENUM.DIALOG,
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "谢陛下恩赐, 我将谨守职责, 不负所托.",
                                            "谢陛下恩典, 此恩此责, 我铭记于心.",
                                            "谢陛下恩赐, 我定不辱使命."
                                        ],
                                    }
                                ],
                                "next": NEXT_LEAVE_OPTION
                            }
                        },
                        {
                            "clist": [
                                "(国王手中暂无可赏赐的领地, 你只得按捺失落之情, 暂且接受这一现实)",
                                "(王座之上, 国王宣布接纳你为臣, 却未提及任何封地. 你的期待落了空)",
                                "(尽管你得到了贵族身份, 但王国此刻并无可分配的领地. 你默默记下这一点)",
                                "(你未获封地, 只得无声退下)"
                            ]
                        }
                    ],
                    "next": NEXT_LEAVE_OPTION
                }
            }
        }
    }

const NEXT_LEAVE_OPTION: = {
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_list": [
        LEAVE_OPTION
    ]
}

const LEAVE_OPTION: = {
    "otype": OPTION_TYPE_ENUM.LEAVE,
    "oname": "离开",
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "content": [
        {
            "clist": [
                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
            ]
        }
    ]



}


var AFTER_BATTLE_THANK_DIALOGUE_LOW: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "relation_value_le",
                "params": [-20]
            },
            "clist": _get_relation_low_gratitude_low_clist()
        },
        {
            "custom_choose_func": {
                "func_name": "relation_value_le",
                "params": [20]
            },

            "clist": _get_relation_mid_gratitude_low_clist()
        },
        {

            "clist": _get_relation_high_gratitude_low_clist()
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            LEAVE_OPTION,
        ]
    }
}


var AFTER_BATTLE_THANK_DIALOGUE_MID: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "relation_value_le",
                "params": [-20]
            },
            "clist": _get_relation_low_gratitude_mid_clist()
        },
        {
            "custom_choose_func": {
                "func_name": "relation_value_le",
                "params": [20]
            },

            "clist": _get_relation_mid_gratitude_mid_clist()
        },
        {

            "clist": _get_relation_high_gratitude_mid_clist()
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            LEAVE_OPTION,
        ]
    }
}


var AFTER_BATTLE_THANK_DIALOGUE_HIGH: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "relation_value_le",
                "params": [-20]
            },
            "clist": _get_relation_low_gratitude_high_clist()
        },
        {

            "custom_choose_func": {
                "func_name": "relation_value_le",
                "params": [20]
            },
            "clist": _get_relation_mid_gratitude_high_clist()
        },
        {

            "clist": _get_relation_high_gratitude_high_clist()
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            LEAVE_OPTION
        ]
    }
}








func ask_king_for_permission_lines_content()-> Array:
    return[
        "我无权接受你的誓言, 唯有我王 - [#{0}], 能做此决定.",
        "你的请求我无权答复, 想要效忠我国，须亲自向伟大的陛下 - [#{0}] 请愿",
        "誓言应当献给一国之主, 而非臣属. 你应晋见伟大的陛下 - [#{0}], 宣誓于王座之前."
    ]


func _get_granted_fief_clist()-> Array:
    return[
        "以王国与王冠之名，正式授予你对 [#{0}] 的统治权. 你将享有对其税收, 管理之权, 同时也需要承担守护与治理之责.",
        "自今日起, [#{0}] 将交由你管辖. 其财富, 事务与百姓皆归你掌管, 亦望你守土安民, 不负所托.",
        "我以王之名授予你 [#{0}]. 其地, 其人, 其责, 皆归于你. 你亦须捍卫其安宁. 主持其法度."
    ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "局势尽在掌控, 即便没有你, 我也能解决.(冷漠)",
        "就算没有你出手, 我也自有办法. 别以为这点举动就能抹平我们之间的旧账.",
        "你的出现倒是省了我些力气, 可你别误会 - 没有你, 我同样能赢. 过去的矛盾, 我还记得很清楚"
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的到场多少让我安心了些, 尽管这次敌人并不算棘手.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "老朋友, 你来的挺巧(热情)"
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "收起我们的私人恩怨. 看在你在战场上出了力的份上, 这次我就不计较了."
    ]


func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "战斗结束了. 你的表现还算中规中矩, 至少没有给整体战局拖后腿."
    ]


func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 我的朋友, 你的身手还是那么稳健."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "我与你之间旧怨难消, 但相助之情终究不能不认. 此次...算我欠你一个人情",
        "我并非那种会无视恩情的人。过去的矛盾依然存在，但今日...你出现的很及时",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "这次多亏了你, 否则局势恐怕早已失控. 我欠你一次大人情.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "今日之战，你的英勇令人钦佩."
    ]


func _king_reject_join_low_reputation_dialogue()-> Array:
    return[
        "我确实听过你的事迹... 但在我看来, 这仍未足以换得一枚贵族徽章.",
        "你的名声正在传扬, 我承认. 但想要身披我国王旗, 还须更多证明.",
        "是的, 我知道你. 但你还不足以站在我面前索取荣耀."
    ]



func king_reject_join_rel_bad_dialogue()-> Array:
    return[
        "我拒绝, 我不信任你"
    ]


func _king_agree_join_low_reputation_dialogue()-> Array:
    return[
        "你已证明你配得上这份荣耀. 本王接受你的誓言, 授你贵族之位.",
        "你的声望已足以立于贵族之列, #{a_leader_name}. 从今日起, 你将被我的王国承认为贵族.",
        "你已展现强大的军事才能. 以我之名, 我准许你加入本国, 享受贵族应得之尊荣.",
        "很好, #{a_leader_name}, 你赢得了进入王国高阶之门的资格. 愿你不辱此名.",
    ]


func _get_attendant_meet_content()-> Array:
    return[
        {
            "clist": [
                "旅人, 请止步! 前方乃吾主 [#{b_leader_name}] 亲率的军队 (声望过低, 领主拒绝接见)",
                "前方是伟大的领主 - [#{b_leader_name}] 的行军部队, 请止步! (声望过低, 领主拒绝接见)",
                "请停下脚步! 前方是 [#{b_leader_name}] 的部队, 擅闯者将被视为不敬! (声望过低, 领主拒绝接见)",
                "有何贵干? 吾主 [#{b_leader_name}] 不接待陌生人 (声望过低, 领主拒绝接见)",
            ]
        }
    ]


func _get_battle_thank_first_meet_clist()-> Array:
    return[
        "我是 [#{0}] 王国的领主 - [#{b_leader_name}].",
    ]

func get_current_dialogue_template()-> Dictionary:

    var _lord_team_node = TeamUtils.get_mw_team_node_by_id(b_team_dialogue_info.uid)
    if _lord_team_node.move_target_node == TeamUtils.get_player_team_node():

        if _lord_team_node is MWTeamLord and(_lord_team_node as MWTeamLord).is_supporting_player():
            return LORD_DEFAULT_DIALOGUE
        return ATTACK_PLAYER

    if WSData.get_player_reputation_value_int() < LordConfig.MIN_REPUTATION_TO_MEET_LORD:
        return ATTENDANT_DIALOGUE
    else:

        return _mod_inject_lord_gift_option(LORD_DEFAULT_DIALOGUE)




func _mod_inject_lord_gift_option(_template: Dictionary)-> Dictionary:
    if not DialogueCustomUtils.can_mod_lord_gift_equipment():
        return _template
    if not(_template.has("next") and _template.next.has("option_list")):
        return _template
    var _custom_template: Dictionary = _template.duplicate(true)
    var _new_option_list: Array = [_mod_get_lord_gift_option()]
    _new_option_list.append_array(_custom_template.next.option_list)
    _custom_template.next.option_list = _new_option_list
    return _custom_template





func _mod_get_lord_gift_option()-> Dictionary:
    return {
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "（他随身的装备…）",
        "turn": SPEAKER_ENUM.B,
        "content": [
            {
                "clist": [
                    "你我之间, 已经不必说这些客套话了。我身上这件「#{0}」, 今日就交给你 —— 不是赏赐, 是心意。",
                    "有件东西, 我一直想找机会给你。我随身这件「#{0}」, 从今日起归你 —— 拿着吧。",
                    "你我这份交情, 值得一件实在的东西。我身上这件「#{0}」, 往后就跟着你了。",
                ],
                "str_from_func": [
                    {
                        "func_name": "get_mod_lord_gift_equipment_name",
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.OPTION,
                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                    "option_list": [
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "那我就收下了",
                            "turn": SPEAKER_ENUM.A,
                            "content": [
                                {
                                    "clist": [
                                        "这份情我记下了。往后有事, 尽管开口。",
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                        "turn": SPEAKER_ENUM.B,
                                        "content": [
                                            {
                                                "clist": [
                                                    "好。别弄丢了, 也别跟我客气。",
                                                ],
                                                "change_result_option_type": OPTION_TYPE_ENUM.LEAVE,
                                            }
                                        ],
                                    },
                                }
                            ],
                            "custom_func": {
                                "func_name": "handle_mod_lord_gift_equipment",
                            }
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "这太贵重了, 我不能要",
                            "turn": SPEAKER_ENUM.A,
                            "content": [
                                {
                                    "clist": [
                                        "你的心意我领了。这东西还是你留着吧, 它跟着你更合适。",
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                        "turn": SPEAKER_ENUM.B,
                                        "content": [
                                            {
                                                "clist": [
                                                    "…随你。这话我放在这里, 你什么时候想通了, 随时来取。",
                                                ],
                                                "change_result_option_type": OPTION_TYPE_ENUM.LEAVE,
                                            }
                                        ],
                                    },
                                }
                            ],
                        },
                    ],
                },
            }
        ],
    }

func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    var _thank_dialogue: = {}

    if _relation_gain_after_battle_factor >= 3:
        _thank_dialogue = AFTER_BATTLE_THANK_DIALOGUE_HIGH
    elif _relation_gain_after_battle_factor >= 1.0:
        _thank_dialogue = AFTER_BATTLE_THANK_DIALOGUE_MID
    else:
        _thank_dialogue = AFTER_BATTLE_THANK_DIALOGUE_LOW

    return {

        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "final_custom_func_list": [
            {
                "func_name": "update_meet_time",
            }
        ],
        "content": [
            {
                "custom_choose_func": {
                    "func_name": "check_is_first_meet",
                },
                "str_from_func": [
                    {
                        "func_name": "get_b_country_name",
                    }
                ],

                "clist": _get_battle_thank_first_meet_clist(),
            }
        ],
        "next": _thank_dialogue
    }








func _get_player_attack_lord_response_content()-> Array:
    return[
        "大胆!"
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "流民, 你要想清楚, 对这面旗帜拔剑, 等同于向整个 [#{0}] 宣战."
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "少废话, 拔剑吧."
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "我喝醉了, 抱歉."
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        ["你确定?1"],
        ["你确定?2"],
        ["你确定?3"],
        ["你确定?4"],
        ["你确定?5"],
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    return[
        ["这样会破坏停战协议, 你确定?1"],
        ["这样会破坏停战协议, 你确定?2"],
        ["这样会破坏停战协议, 你确定?3"],
        ["这样会破坏停战协议, 你确定?4"],
        ["这样会破坏停战协议, 你确定?5"],
    ]



func get_player_attack_lord_reply_word()-> Array:

    if DialogueCustomUtils.is_player_attack_lord_need_confirm():

        if SoldierUtils.get_player_belong_country() == WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:
            return _get_player_attack_lord_reply_word_country_neutral_player_ronin()
        else:
            return _get_player_attack_lord_reply_word_country_neutral_player_lord()
    else:

        return _get_player_attack_lord_reply_word_country_hostile()

func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [
            "我现在就消失...",
            "我这就下令撤离...",
            "这次冲突到此为止吧...",
            "我现在就消失在你的视线里..."
        ],
        [
            "我收回刚才的话...",
            "这次冲突到此为止吧...",
            "我这就改道离开...",
            "我只是想过来打个招呼...我这就走..."
        ],
        [
            "这只是个误会, 我这就走.",
            "这次是我失礼了...",
            "我收回刚才的话...",
            "这次冲突到此为止吧...",
            "误会, 我这就带人离开...",
            "我只是想过来打个招呼...我这就走..."
        ],
        [
            "这次是我失礼了...",
        ],
        [
            "我的理智恢复了, 我这就离开.",
            "这次是我失礼了..."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [
            "我现在就消失...",
            "我这就下令撤离...",
            "这次冲突到此为止吧...",
            "我现在就消失在你的视线里..."
        ],
        [
            "我收回刚才的话...",
            "这次冲突到此为止吧...",
            "我这就改道离开...",
            "我只是想过来打个招呼...我这就走..."
        ],
        [
            "这只是个误会, 我这就走.",
            "这次是我失礼了...",
            "我收回刚才的话...",
            "这次冲突到此为止吧...",
            "误会, 我这就带人离开...",
            "我只是想过来打个招呼...我这就走...",
            "为了和平, 我这就带兵离开...",
        ],
        [
            "这次是我失礼了...",
            "为了和平, 我这就带兵离开...",
        ],
        [
            "我的理智恢复了, 我这就离开.",
            "这次是我失礼了...",
            "为了和平, 我这就带兵离开...",
        ],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["开战吧(国家和平且玩家是浪人)1"],
        ["开战吧(国家和平且玩家是浪人)2"],
        ["开战吧(国家和平且玩家是浪人)3"],
        ["开战吧(国家和平且玩家是浪人)4"],
        ["开战吧(国家和平且玩家是浪人)5"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    return[
        ["开战吧(国家和平且玩家是领主)1"],
        ["开战吧(国家和平且玩家是领主)2"],
        ["开战吧(国家和平且玩家是领主)3"],
        ["开战吧(国家和平且玩家是领主)4"],
        ["开战吧(国家和平且玩家是领主)5"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    return[
        ["开战吧(国家敌对)1"],
        ["开战吧(国家敌对)2"],
        ["开战吧(国家敌对)3"],
        ["开战吧(国家敌对)4"],
        ["开战吧(国家敌对)5"],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    if _is_first_meet:
        return[
            [
                "你谁?"
            ]
        ]
    else:
        return[
            [
                "又见面了, 你想干嘛?"
            ]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    if _is_first_meet:
        return[
            ["没见过的旗帜"]
        ]
    else:
        return[
            ["又是你, 追着我不放"]
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:





    return[
        [
            "我是XXX, 你就是XXX?"
        ]
    ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    return[
        [
            "想干嘛!"
        ]
    ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    return[
        [
            "想干嘛!"
        ]
    ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    return[
        [
            "又是你"
        ]
    ]


func get_leave_country_king_confirm_response_content()-> Array:
    return[
        ["你确定?"],
        ["你确定?"],
        ["你确定?"],
        ["你确定?"],
        ["你确定?"],
    ]

func get_leave_country_king_response_content()-> Array:
    return[
        ["很好."],
        ["很好."],
        ["很好."],
        ["很好."],
        ["很好."],
    ]

func get_leave_country_cancel_king_response_content()-> Array:
    return[
        ["忘了这件事吧."],
        ["忘了这件事吧."],
        ["忘了这件事吧."],
        ["忘了这件事吧."],
        ["忘了这件事吧."],
    ]



func king_reject_join_recent_leave_country_dialogue()-> Array:
    return[
        ["我拒绝."],
        ["我拒绝."],
        ["我拒绝."],
        ["我拒绝."],
        ["我拒绝."],
    ]