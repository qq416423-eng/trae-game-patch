extends LordNobleDialogue

const HERO_UID: = "lord_hero_0001"


func _get_granted_fief_clist()-> Array:
    return[
        "骑士, 抬起头! 吾, 黯金王, 以王冠与战争的荣耀之名, 将 [#{0}] 交付于你的剑下. 领地内的财富与子民, 皆为你所有, 但你要以鲜血和忠诚来捍卫吾的疆域."
    ]


func _get_attendant_meet_content()-> Array:
    return[
        {
            "clist": [
                "止步, 旅人! 前方是 [#{b_leader_name}] 的行军部队, 擅闯者将受军法惩处. (声望过低, 国王拒绝接见)",
                "请止步! 你正踏入吾王 [#{b_leader_name}] 的军阵前线. (声望过低, 国王拒绝接见)",
                "前方乃伟大的露西安纳王国之主 - [#{b_leader_name}], 请保持敬意与距离. (声望过低, 国王拒绝接见)",
                "行止需谨慎, 前方乃吾王 [#{b_leader_name}] 的部队所在, 冒进者将被视作挑衅. (声望过低, 国王拒绝接见)",
                "伟大的黯金王正在巡视军务, 闲人止步. (声望过低, 国王拒绝接见)"
            ]
        }
    ]



func king_reject_join_rel_bad_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        "想要效力于吾? [" + _player_name + "], 你的剑刃上沾染了太多令这片森林厌恶的气息. 吾不信任你, 更不会将露西安纳的后背交给一个背弃荣誉之人.",
        "吾之圣徽照耀之处, 皆为公正与法典. 而你, [" + _player_name + "], 你所行之道充满混沌. 为了王国的安稳, 吾拒绝你的提议, 离吾的王座远点.",
        "招揽你无疑是引火烧身. [" + _player_name + "], 收起你那拙劣的诡计, 吾之国土不欢迎你这种不稳定的变数."
    ]


func _king_reject_join_low_reputation_dialogue()-> Array:
    return[
        "战场能塑造英雄, 却也能暴露你是否只是凡众. 去证明你属于前者. " + LOW_REPUTATION_TIP,
        "本王重视名望胜于血脉, 你离那份荣光...尚差一步. " + LOW_REPUTATION_TIP,
        "吾确实听过你的事迹...但在吾看来, 这仍未足以换得一枚贵族徽章. " + LOW_REPUTATION_TIP,
    ]


func _king_agree_join_low_reputation_dialogue()-> Array:
    return[
        "很好, #{a_leader_name}, 你已证明自己配得上这份荣耀. 本王接受你的誓言, 授你贵族之位. 自今日起, 你将与露西安纳共荣共存."
    ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "吾的军队不需要外人的帮助. 收起你的剑, 退下. 胜利是属于黯金旗帜的.",
        "吾不需要你那微不足道的帮忙. 别再僭越你的身份了."
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[

        "你出现在战场上, 说明你还有利用价值. 但不要多想, 这不是你的功劳.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "老朋友, 你的到来就是荣誉的象征. 但不必担心, 吾的军队足以应付任何挑战."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "虽然你之前违背了吾的旨意, 但你带来的胜利不容否认. 吾会记住这份功绩, 但也不会忘记之前你对吾的冒犯.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你为露西安纳王国避免了损失, 展现了真正的勇气.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "今日你与吾并肩而战, 你的英勇事迹将载入王国的史册!"
    ]


func _get_battle_thank_first_meet_clist()-> Array:
    return[
        "吾是 [#{0}] 的国王 - [#{b_leader_name}].",
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "流民，你要想清楚，对这面旗帜拔剑，等同于向整个 [#{0}] 和伟大的艾尔丹大王宣战!"
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "我等这一刻已经很久了. 我要让艾尔丹大王看看, 荒原上的浪人是如何\"致敬\"的."
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "瞧瞧这该死的幻觉. 我刚才以为自己是在砍一根粗壮的橡木...我一定是醉得不轻...艾尔丹大王万岁!"
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["如果你执意要在 [" + _target_country_name + "] 的土地上寻求毁灭, 吾会赐予你应得的审判. 你确定要挑战吾的剑锋?"],
        ["收起你的贪婪, 浪人. 攻击一位国王并不会让你变得伟大, 只会让你成为绞刑架上的耻辱."],
        ["你要挑战吾? 想清楚, 这不只是武力的胜负. 一旦开战, [" + _target_country_name + "] 的法律将对你进行永恒的放逐. 你准备好面对后果了吗?"],
        ["朋友, 别让一时的冲动蒙蔽了你的心智, 把剑收回去, 吾可以当做什么都没发生."],
        ["吾一直视你为 [" + _target_country_name + "] 最正直的朋友, 别为了这种瞬间的疯狂毁掉你的一世英名! 你真要对吾拔剑?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    return[
        ["这种卑鄙的方式确实符合你的风格. 但你要想清楚, 你的举动将毁灭和平. 你确定要让两国的子民为了你那扭曲的野心而流血吗?"],
        ["吾本以为你至少懂得基本的贵族礼仪. 这种无礼的试探只会引发战争. 收起你的剑, 否则吾将视其为正式的宣战."],
        ["你代表着你的国家和荣耀. 这一步踏出, 所有的和谈都将失效. 唯有剑与血能终结这场冲突. 你确定要开启这扇门?"],
        ["吾的兄弟, 这种对抗毫无意义. 两国的繁荣建立在相互尊重之上, 别为了这瞬间的误解而毁掉两国的未来."],
        ["我们曾在神像前立下盟约, 你现在却要亲手毁掉它? 一旦开战, 吾就不得不为了吾的子民将你彻底铲除. 别逼吾这么做."],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["既然你不听劝诫, 那就让露西安纳的利刃来洗净你的狂妄. 为了正义, 受死吧!"],
        ["既然你选择当一个无法无天的暴徒, 那吾就以国王的名义, 判处你死刑!"],
        ["这就是你的选择. 吾绝不会再给你任何怜悯."],
        ["遗憾至极. 原本我们可以共同饮酒, 现在却只能在战场上兵戎相见. 来吧!"],
        ["你亲手毁掉了我们之间的情义. 从现在起, 你只是吾领土上必须铲除的污点!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["既然你要选择地狱, 那吾也无需再施舍仁慈. 为了 [" + _target_country_name + "], 吾将把你彻底碾碎!"],
        ["你不仅背弃了盟约, 更羞辱了贵族的头衔. 进攻! 让世人看看背誓者的下场!"],
        ["既然和平无法约束你的野心, 那就让正义的战争来审判你.!"],
        ["吾本以为你是个明智的领主, 看来吾错了. 既然战火重燃, 那就由吾来终结它!"],
        ["你背叛了吾的信任! 这一刻起, 你不再是吾的手足. 全军听令, 准备战斗! 为了 [" + _target_country_name + "]!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "宿命的对决终于到了! 吾会用最公正的方式, 在战场上终结你的野心!"
        ],
        [
            "[" + _target_country_name + "] 的将士们! 为了荣耀, 将这些践踏我们领土的敌人赶回去!",
            "[" + _target_country_name + "] 的勇士们听着! 为了荣耀，将这些践踏吾土的侵略者彻底粉碎！"
        ],
        [
            "战场无情. 就让剑刃来决定谁才是胜者.",
            "[" + _player_name + "], 既然你渴望领教黯金圣剑的锋芒, 那吾便以此地, 作为你野心的终点!",
        ],
        [
            "吾很遗憾我们要在这种情况下分出胜负. 为了表示敬意, 吾会全力以赴."
        ],
        [
            "这是命运的悲剧, 吾的朋友. 既然无法回头, 那就让我们在战斗中寻找最后的答案.",
            "为了表达对你的敬意, 吾将赌上一切, 送你一场尊贵的谢幕!",
        ]
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["仔细想了想, 在这种地方动手有失公义."],
        ["[" + _target_country_name + "] 的绞刑架确实不太适合我."],
        ["我还没准备好面对一个国家的斗争. 这次挑战到此为止."],
        ["艾尔丹大王, 你的话让我冷静了. 你说得对, 我不该让一时的愤怒蒙蔽心智."],
        ["我不能让我的朋友失望. 刚才那一瞬间的冲动, 我选择用理智来压制它."]
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["你说得对, 两国的和平不该毁于一时的私愤. 我收回我的剑,"],
        ["你提醒了我, 作为领主不该如此轻率. 我不想成为那个被后世咒骂的背誓者."],
        ["为了这瞬间的冲动让子民陪葬, 确实违背了我的原则."],
        ["你说得对, 和平比战火更有价值. 我还没疯到要亲手毁掉两国的未来."],
        ["你的话唤醒了我的荣誉感. 我不打算让这份盟约毁在我手里."]
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 吾早就听说你是个行走的祸害. 今日, 就是你的死期."],
            ["你就是 [" + _player_name + "] 吧. 吾在王座上听说过关于你的恶行, 本想置之不理, 但你竟敢踏入 [" + _target_country_name + "] 的领土. 拔剑吧, 此处便是你的终点."],
            ["你就是 [" + _player_name + "] 吧. 吾听说你给吾的王国惹了一些麻烦, 但吾更倾向于用法律而非鲜血来解决问题. 放下武器, 随吾回去复命."],
            ["你就是 [" + _player_name + "] 吧. 虽然你目前是王国的通缉犯, 但吾也听闻了你的不少善举. 别让这场追捕演变成流血冲突, 随吾走吧."],
            ["你就是 [" + _player_name + "] 吧. 吾早已听闻你的英名, 甚至曾动过招揽你的念头. 如今你是国家的通缉犯, 但吾依然对你抱有敬意. 请赐教."]
        ]
    else:
        return[
            ["[" + _player_name + "]! 这一次, 吾不会再让你有逃回阴影的机会! 拔剑吧!"],
            ["你确实很擅长逃跑, [" + _player_name + "]. 但在这片森林里, 猎人总会追上他的猎物. 拔剑吧!"],
            ["[" + _player_name + "], 我们又见面了. 命运的回路真是不堪, 总是让吾在某个路口拦截你. 拔剑吧!"],
            ["[" + _player_name + "]，吾本希望你已经远走高飞, 去一个法律触及不到的地方做些好事. 为什么要回来送死?"],
            ["果然是你. 虽然职责让吾必须捕获你, 但吾的私心却在为这场重逢而欢呼. 来吧, 老朋友, 尽情展示你的实力!"]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 吾早就听闻你在边境那些卑劣的勾当. 像你这样的恶徒, 竟然也能在 [" + _player_country_name + "] 混到贵族之位. 今日, 吾要亲手清算你欠下的血债."],
            ["你就是 [" + _player_name + "] 吧. 你也知道, 两国正在开战. 但更让吾不悦的是你那毫无底线的行事风格. 既然你敢踏入吾的领土, 就准备好为你的傲慢付出代价."],
            ["你就是 [" + _player_name + "] 吧. 听说你加入了 [" + _player_country_name + "]? 既然立场不同, 吾身为 [" + _target_country_name + "] 之王, 自然不能放任你继续前行. 拔剑吧."],
            ["你就是 [" + _player_name + "] 吧. 吾听闻你曾帮助过吾的子民, 本想与你结交. 可惜两国正在开战, 吾不得不在此拦截你, 请见谅."],
            ["你就是 [" + _player_name + "] 吧! 吾久仰你的英名, 曾想过若你效力于吾, 必是如虎添翼. 虽然如今兵戎相见, 但能与你一战, 亦是吾之荣幸."]
        ]
    else:
        return[
            [
                "[" + _player_name + "], 你那张令人生厌的脸又出现了! 这一次, 吾绝不会再留情! 拔剑吧!",
                "[" + _player_name + "], 吾之黯金圣剑已在这密林中锁定了你的行径. 你那背信弃义的行径已无可饶恕, 与其继续这狼狈的逃窜, 不如转身, 在吾的圣徽前接受你最后的裁决!",
                "[" + _player_name + "], 你就像林间的毒雾, 不仅危险且令人生厌. 为了 [" + _target_country_name + "] 的纯净, 吾必须在此将你肃清."
            ],
            [
                "又见面了. 既然你执意要在吾的疆土寻找战争, 那吾便赐予你一场无可挽回的溃败.",
                "[" + _player_name + "]! [" + _target_country_name + "] 的领地绝不容许再次被你的旗帜玷污. 既然你退无可退, 那便在此刻, 终结你那无礼的冒犯!",
                "不必再回头张望了, [" + _player_name + "]! 在这片森林中, 没有吾之圣徽照不到的阴影. 今日, 便是你狂妄的终点!"
            ],
            [
                "[" + _player_name + "], 战火尚未平息, 既然你在阵前再次出现, 就用手中的剑来决定两国的边境线吧.",
                "[" + _player_name + "], 战场如棋局, 既然你已入阵, 吾便没有理由放任你离去. 拔剑吧."
            ],
            [
                "吾友 [" + _player_name + "], 如果可以, 吾真想在这密林里与你共饮而非厮杀, 但此时, 吾别无选择!",
                "[" + _player_name + "], 你是个值得尊敬的对手, 但这并不影响吾在此将你击溃. 全军列阵!",
                "[" + _player_name + "], 吾的朋友. 此刻吾身为一国之君, 绝不能任由你离开这片战场. 拔剑吧, 让吾见识你真正的实力!",
                "吾的朋友. 吾之圣徽要求吾拦下任何威胁国土之人. 原谅吾, 拔剑吧."
            ],
            [
                "[" + _player_name + "]! 在这混乱的战场上, 唯有你的旗帜能让吾感到热血沸腾! 拔剑吧!",
                "[" + _player_name + "], 能被吾亲手拦截, 是对你勇武最大的认可. 来吧! 在分出胜负之前, 谁也不许先行离场!",
                "如果命运能温柔些, 我们或许是并肩而战的朋友. 但现在, [" + _player_name + "], 请拿出你全部的斗志, 这是吾对你这位挚友最高的敬意!"
            ]
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 那个在露西安纳境内肆意妄为, 背负累累血债的恶徒. 吾手中的剑正渴望终结你的罪孽, 但今日吾有更重要的征程. 趁吾还没改变主意, 滚出吾的视线."],
            ["你就是 [" + _player_name + "]? 你竟敢主动出现在吾面前? 吾虽然不齿于你的行为, 但今日吾不愿在大战前夕为你这种人浪费一兵一卒. 管好你的剑, 别给吾杀你的理由."],
            ["[" + _player_name + "]. 我知道你, 你出现在此本是死罪. 但吾今日不打算在这里开启杀戮. 如果你只是路过, 那就尽快离开."],
            ["吾听闻过你的劣迹, [" + _player_name + "]. 但也听闻了你的勇武. 虽然你让吾的国家蒙受了损失, 但吾并不想在此取你性命. 带上你的尊严离开吧."],
            ["哈哈, 你就是 [" + _player_name + "]! 敢独自来见吾, 你是忘了自己是通缉犯吗? 你的胆识确实让吾称赞."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["吾之耐心并非无穷无尽, 你执意在吾的剑锋前徘徊, 难道是急着为你的罪行伏法吗?"],
                ["为何还在此处徘徊? 别再让吾看到你这令人作呕的嘴脸."],
                ["在吾改变主意之前, 立刻从吾的视线中消失."],
                ["还没走远吗, [" + _player_name + "]? 趁吾还没后悔, 走吧."],
                ["赶紧走吧, [" + _player_name + "], 就当我没见过你."]
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你以为吾的宽容是对你罪行的默许吗? 若非吾正领兵奔赴要地, 吾现在就会让你付出代价!"],
                ["[" + _player_name + "], 你这种如苍蝇般的纠缠让吾感到作呕. 吾今日不想让森林染上通缉犯的脏血. 趁吾还没下令围剿, 带着你那罪孽深重的性命滚远点."],
                ["又是你. 看来通缉犯的身份还没让你学会畏缩. 吾今日不打算在这里执行判决, 但这不代表吾忘记了你的罪行."],
                ["[" + _player_name + "], 虽然你依旧是吾之国家的通缉犯. 但吾依然愿意给你一条生路. 去寻找一个能让你才华发光的地方. 走吧."],
                ["[" + _player_name + "], 你每次出现都让吾感到惊讶. 虽然你欠露西安纳一个交代, 但吾今日不想做煞风景的事. 保住你的项上人头, 吾期待着在更盛大的场合, 亲手终结你的传说."],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 那个在 [" + _player_country_name + "] 异军突起, 双手沾满吾子民鲜血的统帅. 你如此咄咄逼人地追至此处, 是急着要为这场战争画上句号吗?"],
            [" [" + _player_name + "], 吾听说过你那些野蛮的战绩. 既然你选择效忠 [" + _player_country_name + "] 并主动拦在吾的马前, 想必不是为了外交辞令."],
            ["你就是那个受封于 [" + _player_country_name + "] 的新任领主 [" + _player_name + "]? 你带兵追击的态势告诉吾, 你是个危险的人物."],
            ["[" + _player_name + "], 竟然是你. 传闻你加入 [" + _player_country_name + "] 后战无不胜, 今日一见, 这份压迫感果然不虚."],
            ["哈哈哈! 你就是 [" + _player_name + "] 吧? 你是来向吾讨教的吗? 是的话就来吧! 让吾看看你是否配得上这份狂傲!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复窥探吾的阵型, 是在寻找破绽吗?"],
                ["[" + _player_name + "], 领主间的对决不是儿戏. 如果你不打算开战, 就收起你的敌意."],
                ["紧跟不放, 究竟意欲何为?"],
                ["吾之耐心已被你的纠缠耗尽, 要打便打, 不要消磨时间."],
                ["你这种危险的试探, 是在逼吾下令先手冲锋吗?"],
            ]
        else:
            return[
                [
                    "又是你, [" + _player_name + "]. 你像饿狼一样死盯着吾的部队, 是觉得今日能稳操胜券吗? 但若你再逼近一步, 此处便是你的墓地!",
                    "[" + _player_name + "], 你像秃鹫一样盘旋在吾军后方, 是觉得吾已无力再战了吗? 如果你认为现在是收割吾之头颅的时机, 那就尽管踏过红线试试看!"
                ],
                [
                    "又见到这面令人厌恶的旗帜了. [" + _player_name + "], 你的贪婪和狂妄让你变得极其危险. 既然追到了这里, 你是打算直接在这里开启大决战吗?",
                    "又见面了, [" + _player_name + "]. 你的贪婪已经写在了剑上. 说吧, 你是想开启一场大战, 还是就此退去?"
                ],
                [
                    "又见面了, [" + _player_country_name + "]的领主 - [" + _player_name + "]. 你执意拦路, 是在等吾露出破绽吗?",
                    "又见面了, [" + _player_name + "]. 你的旗帜在吾眼中从未如此刺眼. 既然你利用吾之谨慎不断逼近, 那便直说你的意图吧. 若想开战, 吾的圣徽在此候教!"
                ],
                [
                    "[" + _player_name + "], 作为对手, 你的每一次逼近都让吾倍感压力.",
                    "[" + _player_name + "], 吾在此停下脚步, 是为了听听你的宣言. 你到底是想寻求和平的退路, 还是想要一场无可挽回的碰撞?",
                ],
                [
                    "哈哈哈! 不愧是吾看中的宿敌, 你追逐强者的嗅觉真是灵敏. [" + _player_name + "]! 你是想现在就开始这场决战吗?",
                    "哈哈! [" + _player_name + "]. 既然你追到了这里, 想必已经做好了与吾决一死战的觉悟.",
                    "挚友啊, 你的嗅觉依然如此灵敏. 既然你不打算放过这次绝佳的机会, 那就别废话了. 让吾看看, 在你的野心面前, 你我那微薄的交情究竟价值几何!"
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["吾乃艾尔丹, [" + _target_country_name + "] 的国王. 吾听闻过你的\"壮举\", 你对那些手无寸铁的平民举剑时, 是否也曾感到一丝身为武者的羞愧? 吾之领土不欢迎你这种只为蝇头小利就背弃荣誉的秃鹫. 滚出吾的视线."],
            ["吾乃艾尔丹, [" + _target_country_name + "] 的国王. 我认得你, 你就是那个在林间小径做些偷鸡摸狗之事的鼠辈. 若非吾今日另有圣职在身, 吾之黯金圣剑定要让你伏尸于此!"],
            ["吾乃艾尔丹, [" + _target_country_name + "] 的国王. 吾在你的眼神中看到了尚未磨灭的锋芒. [" + _player_name + "], 你是来寻求这片绿荫下的机遇, 还是打算继续你那毫无目的的漂泊?"],
            ["吾乃艾尔丹, [" + _target_country_name + "] 的国王, [" + _player_name + "], 吾听闻了你的义举, 你在乱贼手中护下了吾之子民. 森林记得每一个正直的灵魂."],
            ["吾乃艾尔丹, [" + _target_country_name + "] 的国王. 好一个气宇轩昂的冒险家! 你为吾之子民所做的一切, 足以让吾破例在御前为你设座."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["收起你的贪婪, 在吾下令围剿前消失!"],
                ["吾已给过你离开的机会, 莫要消磨我最后的宽容."],
                ["若无要事, 不要干扰吾之行军."],
                ["[" + _player_name + "], 虽然森林欢迎义士, 但过度的随行会干扰行军的计划."],
                ["怎么? 是迫不及待想向吾展示你的武勇了吗?"],
            ]
        else:
            return[
                ["光阴并未洗去你身上的血腥气, 劫掠者 - [" + _player_name + "], 只要你在这片绿荫下露面, 吾之黯金圣剑就会进入警戒状态."],
                ["又是你, 游荡的污浊灵魂. 你依然在毫无目标的虚度光阴吗?"],
                ["[" + _player_name + "]. 风带来了远方的消息, 却未提及你的归宿. 在这段漫长的流浪中, 你的灵魂是否找到了停靠的港湾?"],
                ["[" + _player_name + "], 久违了. 在这一段漂泊的日子里, 你是否找到了值得你拔剑守护的人?"],
                ["很高兴再次见到你, 正直的流浪者. 吾之子民依然在传颂你的义举, 希望你的剑依然锋利如初."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):

            return[

            ]
        else:
            return[
                ["吾乃艾尔丹, [" + _target_country_name + "] 的国王. [" + _player_name + "], 吾听闻过你那些卑劣的事迹. 在吾之国土, 请收敛你的野蛮, 否则吾之圣剑不介意替你的君主执行教化."],
                ["[" + _player_country_name + "] 的 [" + _player_name + "], 这里是 [" + _target_country_name + "]. 森林不欢迎带着浑浊气息的异邦人. 若你只是路过, 便请保持应有的克制, 莫要挑动吾之战意."],
                ["吾乃艾尔丹. [" + _target_country_name + "] 的国王, [" + _player_name + "], 你越过边界而来, 是带着和平的盟约, 还是带着扩张的野心?"],
                ["欢迎你, 远方的客人 - [" + _player_name + "], 吾乃艾尔丹. [" + _target_country_name + "] 的国王, 吾听闻你在异国他乡亦坚守着骑士精神, 这让吾感到由衷的欣慰. 愿我们的会面能为两国带来繁荣."],
                ["久仰大名, [" + _player_country_name + "] 的猛虎 - [" + _player_name + "], 像你这样拥有璀璨战绩的英雄, 理应得到吾最诚挚的敬意. 来吧，让吾一睹异国强者的风采!"]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["别再出现在吾面前."],
                ["[" + _player_name + "], 莫要再三叨扰."],
                ["反复折返是为何?"],
                ["看来你还有话要说? 吾倾听着."],
                ["看来你对吾之战术极感兴趣? 那便随吾一同巡视阵线!"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[

                    [
                        "[" + _player_name + "]. 你我所行之道似乎并不相通. 如果你执意在偏离荣誉的迷雾中独行, 就别怪我降罪于你."
                    ],

                    [
                        "[" + _player_name + "], 吾之利剑从未宽恕过懈怠之人. 若你沉溺于安逸而忘却了领主的职责, 那黯金的光辉终将离你而去. 莫要让吾失望.",
                        "[" + _player_name + "], 如果你依然毫无作为的话, 那吾之黯金圣剑不介意为这片土地修剪枯枝."
                    ],

                    [
                        "[" + _player_name + "], 吾不希望在下一次点将时, 看到的依然是一个只顾私利的统帅. 回去反思."
                    ],

                    [
                        "荣誉并非挂在墙上的勋章, 而是刻在骨子里的铁律. [" + _player_name + "], 如果你无法领悟王国的生存之道, 那就别怪吾收回赋予你的权柄."
                    ],

                    [
                        "吾之封臣 - [" + _player_name + "], 这段时日, 你的领地是否如森林般宁静繁茂?"
                    ],

                    [
                        "领地的巡防不可有一丝疏忽, [" + _player_name + "]."
                    ],

                    [
                        "[" + _player_name + "], 吾在等待一个能为 [" + _target_country_name + "] 带来长久和平的统帅."
                    ],

                    [
                        "[" + _player_name + "], 过来, 让吾看看这段时间的风霜是否磨砺了你的意志."
                    ],

                    [
                        "[" + _player_name + "], 愿黯金圣剑的荣光永远指引你的前路, 与吾并肩守护这片繁茂之境.",
                        "再次见到你让吾感到愉悦. 黯金的光辉永远照耀你.",
                        "哈哈哈! 吾之臂膀, 你总算来了! 快来与吾共谋这一场伟大的征途!"
                    ],
                ]
            else:
                return[
                    [
                        "[" + _player_country_name + "] 的 [" + _player_name + "]. 吾肩膀上的伤口还在隐隐作痛, 那是你留下的\"礼物\". 在圣剑暴走前, 滚出吾的视线.",
                    ],
                    [
                        "收起你那拙劣的伪装, [" + _player_name + "]. 若非和平契约尚在, 你现在已成了泥土的养分.",
                    ],
                    [
                        "又是你, [" + _player_name + "]. 虽然两国并非敌对, 但你身上的气息依然令这片森林感到不安."
                    ],

                    [
                        "[" + _player_name + "], 我们又在命运的交汇点相遇了. 不知你这次带来的是酒杯, 还是剑刃?",
                        "又见面了, [" + _player_name + "], 希望你这次带来的是足以匹配你地位的智慧. 毕竟, 露西安纳从不款待弱者."
                    ],
                    [
                        "久违了, 异国的勇士 - [" + _player_name + "]. 愿今日的重逢能共叙和平.",
                    ],
                    [
                        "欢迎 [" + _player_name + "] 阁下. 愿此时的和平能如这林荫般长久.",
                        "[" + _player_name + "], 你的谨慎让吾印象深刻. 一个懂得审时度势的封臣, 往往比那些狂热的莽夫更值得吾与其共饮这杯美酒.",
                        "再次见到你让吾感到愉悦. [" + _player_name + "], 若你能在 [" + _target_country_name + "] 效力, 吾定会予你最显赫的爵位."
                    ],
                    [
                        "每次见到你, 吾都能感受到那股震撼大地的斗志! 来吧, 让吾听听你又征服了哪片荒原!",
                        "哈哈哈, 吾之挚友! 即便边境的界碑阻隔了疆土, 却阻隔不了吾对你的赞赏.",
                        "吾最珍视的异国兄弟 - [" + _player_name + "], 你来得正是时候! 随我入账饮酒."
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "为了" + _country_name + "的荣光! 冲锋!",
        "众将士, 随吾冲锋!",
        "以圣剑之名, 驱散眼前的阴霾!",
        "莫要畏惧! 吾之圣徽即是尔等最坚实的后盾!",
        "全军突击! 展现尔等如林间暴风般的武勇!",
        "为了家园与子民, 此战必胜!",
        "利刃出鞘! 让敌人见证黯金圣剑的审判!",
        "冲锋! 将敌人的阵线如枯枝般折断!",
        "吾之剑锋所指, 即是正义所向!",
        "胜利的曙光已在圣剑之上跳跃, 冲锋!",
        "吾将身先士卒, 诸位! 莫要落后于吾之斗篷!",
        "为了不灭的家园, 进攻!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _country_name: = _get_country_name()

    var _list: = [
        "你败在了公义之下, 这并不可耻",
        "这是你必须付出的代价",
        "傲慢是你覆灭的根源",
        "这片土地将记住你的失败",
        "这就是挑衅" + _country_name + "的下场",
        "遗憾至极",
        "圣剑之下，众生平等",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + ", 终究是吾更胜一筹",
            _target_hero_name + ", 你的野心到此为止了",
            "永别了, " + _target_hero_name
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "不过是这点伤痕",
        "咳...不错的攻击",
        "吾岂会被这种攻击撼动?",
        "圣徽尚未暗淡!",
        "全军莫乱!",
        "吾之伤势无碍! 继续进攻!",
        "哼~ 这点痛楚",
        "全军莫要惊慌!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "是个...强敌...",
        "圣剑...咳...",
        "视线模糊了...",
        "撤退...",
        "终究...没能守住吗...",
        "吾之国土..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "黯金旗帜, 向前压进!",
        "稳步推进! 保持阵型的厚度, 莫要冒进!",
        "稳扎稳打压过去!",
        "保持阵型节奏!",
        "注意间距! 向前推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住阵线!",
        "原地待命! 立盾!",
        "原地待命!",
        "原地防守! 莫要落入敌人的陷阱!",
        "防守! 等待他们露出那愚蠢的破绽!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    var _country_name: String = _get_country_name()

    return[
        "干得好! 这场胜利属于" + _country_name + "的每一个战士!",
        "清点伤亡, 救治伤者!",
        "收旗! 将敌人的俘虏交由法典处置!",
        "愿阵亡的勇士在橡树下永眠",
        "哈哈哈! 黯金圣剑所到之处, 皆为坦途!"
    ].pick_random()

func get_leave_country_king_confirm_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_name()

    return[
        [
            "如果你执意选择当一个流浪的背誓者, 那便走吧. 吾不屑于强留一个没有荣誉的躯壳. 你确定要背弃这份契约?",
        ],
        [
            "吾的军队不需要意志动摇的将领. 如果你心意已决, 那便交还你的领地与权力, 你想清楚这后果了吗?"
        ],
        [
            "[" + _target_country_name + "] 的树荫虽茂, 却不留无根之人. 既然你觉得此地无法容纳你的野心, 那便正式提出你的请辞. 你果真想好了?",
            "作为国王, 吾尊重你的意志. 但在你迈出这一步前, 请审视你内心的荣誉 - 你是否真的准备好放弃这面旗帜?"
        ],
        [
            "[" + _player_name + "], 你是吾看重的利刃之一. 森林正值多事之秋, 此刻离去, 岂不是让亲者痛仇者快? 你真的决定好了吗?",
            "我们曾在战场上共同捍卫国土, 这份情谊难道不值得你再多留一刻? 吾的朋友, 莫要让迷雾遮了眼, 你确定要离去?"
        ],
        [
            "吾没听错吧? 若你离去, 吾之右翼将从此空悬. 你真的...要斩断这血火中淬炼的誓言吗?",
            "哈哈哈...艾尔丹一生谨慎, 唯独在你身上赌上了全部的信任. 若你离去, 这黯金圣剑也将随之黯淡. 吾的朋友, 最后再问你一次, 你确定要走?",
            "难道是吾之圣徽已无法照亮你的前路? [" + _player_name + "], 告诉吾, 这绝非你的本意! 对吗?"
        ]
    ]

func get_leave_country_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "既然荣誉已成负担, 那便滚出吾的视线. 走吧, 背誓者.",
            "哼, 这是意料之中的背叛. 你好自为之."
        ],
        [
            "交出你的剑与旗帜. [" + _target_country_name + "] 的土地不欢迎没有灵魂的流浪客.",
            "露西安纳的树荫不留动摇之人。交还你的权柄，消失在边境线外吧。"
        ],
        [
            "既然你执意舍弃爵位, 那便正式两清. 吾之圣剑下一次挥动, 将不再顾念旧情.",
            "遗憾至极. 吾本以为你能在这片绿荫下找到归宿. 吾尊重你的决定."
        ],
        [
            "既然志向不再相投, 强留亦是无益. 愿你在别处能找到你想要的东西.",
            "吾尊重你的意志. 虽然你的离去是王国的损失, 但吾更不愿看到一个心不在焉的领主.",
            "既然这面旗帜已无法让你感到自豪, 那便去寻找属于你的战场吧. 愿你的英名不会毁于今日."
        ],
        [
            "走吧, 吾的朋友. 虽然吾心如刀绞, 但吾更希望你能追随内心的光. 愿圣徽保佑你.",
            "[" + _target_country_name + "] 记得你的功勋, 吾亦会记得. 若日后身心疲惫, [" + _target_country_name + "] 的大门永远为你敞开.",
            "终究, 我们还是在分岔路口道别了. 挚友啊, 带上吾的祝福, 去开创那个你向往的世界吧.",
            "黯金的光辉今日为你送行. 即便不再是君臣, 你永远是吾心中最耀眼的骑士. 去吧!",
            "哈哈哈...即便万般不舍, 吾亦不能囚禁一只向往天空的雄鹰. 去吧, 让整片大陆都响彻你的英名!"
        ],
    ]

func get_leave_country_cancel_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "哼, 看来你还没蠢到要自寻死路.",
            "算你识相. 下一次若再敢以此戏言, 吾之圣剑绝不姑息."
        ],
        [
            "明智的决定. 收起你那摇摆不定的心思, 别再考验吾的耐心.",
            "迷途知返亦是勇气的一种. 回去吧, 别再让 [" + _target_country_name + "] 的旗帜为你感到蒙羞."
        ],
        [
            "吾很高兴你的理智战胜了鲁莽. 记住这种如履薄冰的感觉, 它会让你更谨慎.",
            "很好. 森林欢迎每一个找回方向的灵魂. 让我们把刚才的不快都交给微风吧.",
            "吾接受你的回归. 既然誓言未断, 那就继续为 [" + _target_country_name + "] 的荣光而战.",
            "你做出了正确的选择.",
        ],
        [
            "你的犹豫让吾心惊, 但你的留下更让吾欣慰.",
            "既然你选择了留下, 那就证明我们的缘分未尽. 来, 让我们商讨接下来的远征."
        ],
        [
            "太好了! 吾之臂膀, 你若离去, 这黯金圣剑也将随之黯淡. 让我们继续并肩作战!",
            "哈哈哈! 这就是吾认识的英雄! 即便有瞬间的迷茫, 最后依然会站在吾之身侧!",
        ],
    ]

func king_reject_join_recent_leave_country_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "[" + _player_name + "], 你以为时间能洗去背誓的污点? 吾之圣徽至今仍记得你离去的背影. 滚吧, 此生勿再踏入 [" + _target_country_name + "]!",
            "背弃吾一次, 便是永世的裂痕. [" + _player_name + "], 你的名字在吾耳中已等同于耻辱. 森林拒绝你这种反复无常之徒.",
            "黯金圣剑不会为同一个叛徒亮起第二次. 离吾远点, 免得吾亲手为你画上句点."
        ],
        [
            "你竟还有脸回来? [" + _player_name + "], 上次弃誓的场景吾还没忘, 你便又想在吾之旗帜下寻求庇护? 痴心妄想!",
            "吾之谨慎并非懦弱, 而是对弃誓者的警惕. 你的誓言在吾眼中已如枯叶, 轻飘且无价值. 退下吧.",
        ],
        [
            "[" + _player_name + "], 你离去未久, 吾岂敢再信你一次? 你走吧.",
            "吾依稀记得你离开时的身影, [" + _player_name + "]. 吾无法对反复之人敞开国门.",
            "誓约不是儿戏, 背弃之后岂能说归就归? [" + _player_name + "], 森林欢迎迷途知返者, 但不欢迎昨日才斩断根系之人."
        ],
        [
            "吾曾视你为臂膀, [" + _player_name + "]. 可你离去未久, 这份信任尚未重建. 吾...暂时无法接纳你.",
            "[" + _player_name + "], 你的能力吾依旧欣赏, 但心结未解. 给吾一些时间, 也给你自己一个证明的机会.",
            "森林记得你的功勋, 也记得你的离去. [" + _player_name + "], 吾现在无法接纳你."
        ],
        [
            "吾的朋友, 听到你想归来, 吾心甚慰...可你离去才多久? 吾之荣耀不允许吾赌上整个王国的安危来接收一个弃誓者",
            "[" + _player_name + "], 若不是因为上次你离去时留下的阴影, 吾早已张开双臂. 然而今日, 吾只能说: 再等等吧.",
        ]
    ]

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "收起你的傲慢, 艾尔丹. 现在, 你只是我的战利品.",
        ],
        [

            "艾尔丹, 你的圣剑不过如此."
        ],
        [

            "别拿那种眼神看我, 阶下囚没有资格审视胜利者."
        ],
        [

            "放下你的武器, 艾尔丹. 你现在没有任何讨价还价的余地."
        ],
        [

            "老实点, 不要耍什么花样."
        ],
        [

            "看来你还没适应身份的转变, [#{b_leader_name}], 现在的你只是我的俘虏."
        ],
        [

            "胜负已定, [#{b_leader_name}]. 请保持你的体面, 随我回营吧."
        ],
        [

            "你现在是我的俘虏了. [#{b_leader_name}]."
        ],
        [

            "这一仗打的非常精彩. 虽然你输了, 但你的英勇无愧于露西安纳."
        ],
        [

            "很遗憾我们要以这种方式交谈, [#{b_leader_name}]. 我会亲自护送你, 确保无人敢对你不敬."
        ],
        [

            "别露出一脸严肃的样子. 能击败你是我这辈子的最高荣耀."
        ]
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "哼, 即便是身陷泥沼, 吾之灵魂也绝不会向你这种卑劣之徒低头.",
        ],
        [

            "闭嘴吧. 与你这种毫无荣誉感的野心家交谈, 是对这把圣剑的侮辱."
        ],
        [

            "你的胜利充满了令人作呕的气息. 吾虽败, 但露西安纳的法典永远不会放过你这种暴徒."
        ],
        [

            "哼..."
        ],
        [

            "吾并非鲁莽之辈. 既然胜负已定, 吾自会克制, 但不要指望吾会为你提供任何赞美."
        ],
        [

            "吾接受当下的处境. 但别指望吾会低声下气."
        ],
        [

            "既然败在你的剑下, 吾会履行一个俘虏应有的礼仪."
        ],
        [

            "吾之圣徽今日暂时失去了光辉. 说吧, 你需要吾如何配合?"
        ],
        [

            "[" + _player_name + "], 你确实证明了你的剑比吾更锋利. 能在战场上被你击败, 吾并无怨言."
        ],
        [

            "既然是输给了你, 这份屈辱倒也并非不可接受. 吾会静候重回战场的那天."
        ],
        [

            "看来吾确实老了.",
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "收起你那贪婪的眼神, [" + _player_name + "]. 来谈谈你需要多少筹码才肯放手.",
            "[" + _player_name + "]. 吾之臣民已备好筹码, 你只需开出你的价格, 然后让吾离开这污浊之地."
        ],
        [
            "这种监禁不仅是在羞辱吾, 更是在浪费你的声誉. [" + _player_name + "], 让这场闹剧尽早收场吧.",
            "与其在这阴暗的地牢里对峙, 不如谈谈实际点的事情. 你是来寻求补偿, 还是单纯来炫耀武力?"
        ],
        [
            "[" + _player_name + "], 多余的监禁毫无意义. 让吾等以骑士的方式, 谈谈结束这场纷争的代价.",
            "吾已审视过当下的困局. 为了重掌圣徽, 吾愿意听听你的开价."
        ],
        [
            "既然胜负已分, 吾认为现在是讨论\"释放条件\"的最佳时机. 你意下如何?",
            "与其在这里无谓地消耗资源, 不如达成一项对你我都有利的协议. 关于赎金, 你有什么想法?",
            "吾之王座不能一直空着. [" + _player_name + "], 若是看够了吾落魄的模样, 就来谈谈那笔让你满意的报酬吧."
        ],
        [
            "老朋友, 这场较量令吾获益匪浅. 既然剑锋已收, 何不谈谈让吾重回森林所需的筹码?",
            "吾之挚友, 别一直在吾面前摆出那种胜利者的姿态. 商讨一下这笔让大家都体面的赎金, 如何?"
        ]
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "吾之臣民已备好 [#{0}] 德里, 以此换取吾重回森林的自由. 你意下如何?",
        "吾愿支付 [#{0}] 德里作为赎金. 收下这笔财富, 让这场纷争到此为止.",
        "[#{0}] 德里. 这是吾作为国王能给出的最体面的代价, 以此换取吾之圣剑与自由."
    ]



func get_hero_released_by_ransom_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "很好. 下一次，迎接你的将是箭雨而非金币",
            "很好. 这把圣剑的锋芒, 迟早会再次对准你的咽喉.",
            "拿好这些财物, 贪婪的秃鹫. 森林会记住你对王冠的亵渎, 吾必将亲自洗刷这份耻辱."
        ],
        [
            "莫要以为这次胜利意味着永恒. 身为国王, 吾会从失败中汲取教训, 而你, 最好祈祷下次还能有这份运气."
        ],
        [
            "既然拿到了你想要的, 那就让路吧.",
            "下次见面, 吾可不会再这么\"慷慨\"了."
        ],
        [
            "吾重获自由, 而你获得了财富, 这很公平. 愿你在未来的战场上, 依然能保持这份武勇.",
            "很好, [" + _player_name + "]. 吾期待很快能与你再次对决."
        ],
        [
            "你这次可是让吾付出了不小的代价, 再会.",
            "很好, 待吾归国重整军备, 再与你共赴战场!"
        ]
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "吾没听错吧? 你这掠夺者竟会舍弃到手的财货? 你又在谋划什么阴谋?"
        ],
        [
            "你竟打算无条件放了吾?",
            "[" + _player_name + "], 你真的要放我走?"
        ],
        [
            "你的大度让吾感到惊讶. [" + _player_name + "].",
            "[" + _player_name + "], 这就是你的骑士之道吗?",
            "比起财物, 你似乎更看重这份战场上的共鸣. 真的要放我走?"
        ],
        [
            "哈哈哈! 我就知道, 你绝不是那种会被俗物遮眼的庸人. 你真的打算直接放了我?",
            "不要赎金? 你这家伙总是能做出让吾意想不到的行为."
        ],
        [
            "吾之挚友, 你的每一次决定都让吾感到心灵的激荡. 你果真不需要任何回报?",
            "你是想让吾这一辈子都欠着你吗?"
        ]
    ]

func get_hero_released_freely_content()-> Array:
    return[
        [
            "这次算吾欠你的, 但这绝不代表战争的终结. 下次见面, 吾依旧会斩断你的军旗."
        ],
        [
            "这份莫名其妙的\"惊喜\", 吾收下了, 再会.",
            "那么再会了, 难以捉摸的对手.",
        ],
        [
            "既然你选择了仁义, 那吾便接受这份自由. 愿你的判断不会让你后悔.",
            "那吾走了. 在这混乱的世道, 像你这样不求回报的人已经不多了.",
            "吾重获自由, 而你赢得了尊重. 后会有期."
        ],
        [
            "吾的朋友, 你的大度简直让吾这位国王感到汗颜. 后会有期",
            "那么吾便不再逗留. 愿黯金的光辉也能照亮你的前程.",
        ],
        [
            "既然你如此慷慨, 吾也就不再说那些虚伪的客套话了. 这份恩情, 吾记在心里了.",
            "你的选择证明了你拥有真正的王者之志. 再会, 吾之挚友, 愿荣誉永随!"
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "吾乃一国之君, 困于此地于理不合. 这件 [#{0}] 承载着吾之荣光, 以此换取吾之自由. 如何?",
        "吾愿将随身至宝 [#{0}] 交付于你, 以此结束这场监禁, 如何?",
        "吾愿意用这件 [#{0}] 赎回吾之剑锋与自由, 如何?"
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "虽然你与吾之间有些过节, 但不得不承认, 你这次确实完成了分内之事.",
        "你完成了任务, 这很好. 但你与吾之间的私怨, 并非此战可以抹平.",
        "吾虽对你的诸多行径不甚赞同, 但今日你既然为了吾之胜利而主动出击, 吾便会给予你相应的尊重.",
        "你的表现算得上是一名战士, 吾不会抹杀你的功劳. 但在此之外, 吾与你并无太多话可说.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "吾对今日的合围还算满意.",
        "进攻的事态你把握得恰到好处, 正合吾意.",
        "今日你的队伍很好地履行了职责, 吾向你致谢.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "又是痛快的一战!",
        "有你协助, 是吾的幸事.",
    ]