extends LordNobleDialogue

const HERO_UID: = "lord_hero_0002"







func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "你想向 [" + _king_name + "] 效忠? 简直是本世纪最大的笑话! 像你这样缺乏荣誉感的流浪汉, 连给骑士刷马蹄的工作都不配!"
        ]
    elif _rel_value <= -10:
        return[
            "加入 [" + _king_name + "] 需要的是纯洁的灵魂和无畏的勇气, 然而在你眼里, 我只看到了对尘世利益的贪婪. 别再纠缠我了, 若你真不死心, 就去叩响 [" + _king_name + "] 那高耸的宫廷大门吧."
        ]
    elif _rel_value <= 10:
        return[
            "哈! 既然有心踏上荣耀之路, 何必问我? 我是利剑, 而挥剑之人是 [" + _king_name + "]! 只有他/她能赋予你神圣的使命!"
        ]
    elif _rel_value < 30:
        return[
            "一位准骑士的诞生总是伴随着迷茫. 听着, 去寻找那位坐镇王座的 [" + _king_name + "] 吧! 在他/她的见证下立誓, 你的生命将从此焕发史诗般的光芒!"
        ]
    else:

        return[
            "朋友, 你的英勇足以让林间的橡树为你低头! 去向 [" + _king_name + "] 献上你的忠诚吧, 我已经迫不及待要和你一起去讨伐那些肆虐边境的巨人了!",
            "我的兄弟! 我的挚友! 命运的齿轮终于转到了这一刻! 你我并肩作战的英姿必将被吟游诗人传唱千年! 快去见见 [" + _king_name + "], 办完那些琐碎的文书手续, 让我们立刻开启这场伟大的远征!"
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "哼, 你的剑只刺中了几只蚊子. 这场伟大的胜利仍归于我的长枪!"
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的到来为这场冒险增添了一点色彩, 不过真正的挑战还在后面.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "老朋友, 你总是能及时赶到! 下次, 让我们一起挑战真正的巨人!"
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "伟大的战士! 虽然我们理念不合, 但你的勇猛值得尊敬. 我堂吉诃德会记住这份骑士之情.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你证明了自己是值得托付后背的伙伴! 这份并肩作战的经历, 我将铭记于心.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "我的朋友, 你就是为战场而生的! 这次的胜利, 你居首功!"
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "堂吉诃德大人视荣誉如生命. 如果你这不只是酒后的胡言乱语, 那么我保证, 下一秒这里就会变成地狱."
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "废话少说, 听说\"风车骑士\"的枪很快? 我正想见识见识!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "这该死的酒...刚才那是幻觉! 我刚才以为我正在和一只巨大的风车搏斗呢!"
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["你这卑劣的毒蛇! 我等这一刻很久了. 在正义的枪尖刺穿你的胸膛后, 我会把你挂在森林最高的橡树上示众. 你确定要挑战风车骑士的力量?"],
        ["退后, 流浪者! 攻击我就等同于向 [" + _target_country_name + "] 宣战!"],
        ["你要向一位高尚的骑士发起挑战? 想清楚. 一旦见红, 我的长枪不折断便绝不收回."],
        ["哈哈! 我的老伙计, 你被那些疯狂的幻想迷住心智了吗? 快把剑放下, 那不是针对朋友的武器."],
        ["我的兄弟! 你是我见过最勇敢的冒险家, 今日却要在我面前拔剑?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["来啊! 你这背信弃义的恶魔! 只要你敢拔剑, 那份平庸的和平协议就是废纸一张! 我会带着骑士团踏平你的领土. 你确定要当那个祸害万民的罪人?"],
        ["收起你的小动作, 你这种卑鄙的试探只会玷污你的家纹. 一旦开战, 两国边境将燃起永不熄灭的战火. 你确定要连累那些无辜的性命了吗?"],
        ["站住! 你代表的是你家族的荣誉. 这一步踏出, 就是向 [" + _target_country_name + "] 正式宣战. 没有和谈, 只有冲锋! 你要让你的子民为你这瞬间的狂热陪葬吗?"],
        ["哦, 我的朋友, 这真是一个惊人的笑话! 但这玩笑开得太大了. 把剑收回去，趁我还没把这当成真正的挑衅."],
        ["我的兄弟! 我们曾在森林的树荫下誓言共进退, 你却要亲手撕毁它? 开战后, 你不再是英雄, 而是背誓的懦夫! 你真要毁掉这一切吗?"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["既然你执意求死, 那我就把你的贪欲彻底埋进这片森林!"],
        ["很好! 骑士团, 随我冲锋!"],
        ["好! 让史诗见证这一刻, 我的长枪会贯穿你的傲慢!"],
        ["既然你执意要把这当成地狱, 那我也不再劝阻. 准备战斗!"],
        ["痛心疾首! 从此刻起, 我们不再是朋友, 我将亲自击杀你"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["我就知道邪恶从未停息! 那就让战争爆发吧, 我会把你那污秽的旗帜踩在脚下!"],
        ["你不仅是个祸害, 更是骑士的耻辱. 进攻! 为了 [" + _target_country_name + "] 的荣光!"],
        ["既然和平无法约束你的狂热, 那就让毁灭来重塑秩序. 你是第一个祭品!"],
        ["遗憾! 你毁掉了一切美好的可能. 现在, 迎接风车骑士的雷霆之怒吧!"],
        ["背誓者! 你已经不是我的兄弟, 而是我枪尖上的猎物!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "看啊! 这片森林在为你这恶魔的降临而哀鸣! 我不仅要取你的首级, 更要在这修罗场上彻底净化你的罪孽! 冲锋!!",
            "我早已预见到这一刻, [" + _player_name + "]! 你这从深渊爬出来的喷火恶龙, 想用你那虚伪的声势吓退正义的骑士吗? 做梦!"
        ],
        [
            "既然宿命注定要让我陷入这泥沼, 那我就用铁蹄将你和你的野心一并踩进泥沼!",
            "你的旗帜上沾满了我国战士的血, 而我的长枪将终结这一切! 这是勇士的试炼, 也是你这恶徒的末日! 全军! 冲锋!!",
        ],
        [
            "战场就是我们的礼堂, 既然相遇, 唯有胜者才能书写传奇!",
            "既然你急着想成为我的功勋, 那我便不客气了! 勇士们! 随我撞碎他们的防线!",
            "管你是千军万马, 还是滔天巨浪! 在风车骑士的斗志面前, 统统不过是脆弱的芦苇!"
        ],
        [
            "作为对手, 你值得我全力一击. 为了荣誉, 冲锋!!"
        ],
        [
            "这是悲壮的宿命, 我的朋友. 抛开一切, 让我们在鲜血中完成这最后的礼仪! 全军冲锋!",
            "[" + _player_name + "], 假如我死在你的剑下, 请告诉世人: 直到最后一口气, 我都是在冲锋的路上."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["你说得对, 在这种地方和你决斗确实不明智."],
        ["你说得对, 我这点微薄的家当不该拿来对抗骑士团."],
        ["这场仗我不打了."],
        ["呼...也许我真的还在幻想中没醒. 既然你愿意把这当成一个醉鬼的误会, 那就此告辞."],
        ["我不打算成为你口中的死囚. 我这就收回锋芒."],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["你说得对, 为了这份\"平庸\"的协议, 我收刀."],
        ["我不想成为背负万千性命的背誓者. 这次是我失礼了."],
        ["你说得对, 我不该为了瞬间的狂热让我的子民陪葬. 我选择维持和平."],
        ["既然你愿意把它当成一个笑话, 那我就顺势收场."],
        ["你提到的那些誓言让我羞愧. 我不打算亲手毁掉我们的情谊, 刚才的事...就当是个幻觉."],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 我堂吉诃德的枪尖早已嗅到了你灵魂的恶臭, 为了 [" + _country_name + "] 的荣光, 受死吧!"],
            ["你就是 [" + _player_name + "] 吧! 我听说你是个只会躲藏的懦夫? 来吧, 像个男人一样迎接我的冲锋!"],
            ["你就是 [" + _player_name + "] 吧! 虽然我们并无私人恩怨, 但追捕罪犯是骑士的天职! 拔剑吧!"],
            ["你就是 [" + _player_name + "] 吧! 我听闻你曾帮助过弱小, 真是了不起的行径! 但你是 [" + _country_name + "] 的通缉犯, 我会全力以赴地击败你!"],
            ["你就是 [" + _player_name + "] 吧! 我很欣赏你, 但是命运让我们以猎物和猎人的身份相遇, 这简直是吟游诗人笔下最棒的开场! 不要手软, 攻过来!"]
        ]
    else:
        return[
            ["魔鬼! 我的战马已经在咆哮, 它迫不及待要踏碎你的骨头! 受死吧!"],
            ["还没学会规矩吗, 通缉犯? 看来我得在你身上开几个洞, 你才能记住 [" + _country_name + "] 的法典!"],
            ["[" + _player_name + "]! 这次被我逮到了, 接受制裁吧!"],
            ["你还是这么顽固, 伙计. 虽然我很欣赏你, 但我的准则不允许我放过任何一个通缉犯. 开战!"],
            ["哈哈哈哈! 在这冷酷的世界里, 只有和你战斗才能让我感受到生命的炽热! 来吧, [" + _player_name + "], 战个痛快!"]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 你这卑劣的掠夺者, 竟然也能被封为 [" + _player_country_name + "] 的领主? 我的长枪绝不容许你这种人还活着!"],
            ["你就是 [" + _player_name + "] 吧! 既然成了 [" + _player_country_name + "] 的领主, 就该拿出对应的荣誉感来! 你那毫无底线的手段让我感到恶心, 接招吧!"],
            ["你就是 [" + _player_name + "] 吧! 听说你效忠了 [" + _player_country_name + "]? 好极了! 这片战场就是最华丽的舞台, 拔出你的剑, 让我们来一场骑士间的对决!"],
            ["你就是 [" + _player_name + "] 吧! 我听说你是个真正的骑士. 可惜啊, 既然你选择了那个阵营, 我只能在战场上用长枪向你的品德致敬了!"],
            ["哈哈! 你就是那个传奇领主 [" + _player_name + "] 吧! 我早就在期待这一天了! 虽然你我各为其主, 但能在这伟大的时刻与你交手, 简直是上帝的恩赐! 开战吧!"],
        ]
    else:
        return[
            [
                "[" + _player_name + "]! 你这卑鄙的背誓者, 竟然还敢领兵踏入 [" + _target_country_name + "] 的领地? 这一次, 我会撕碎你的帅旗! 受死!",
                "你这阴影中的爬虫! [" + _player_name + "]! 别以为逃进树林就能躲过我的长枪. 今天, 我要用你的污血来洗刷你对骑士精神的亵渎!",
            ],
            [
                "又见面了, [" + _player_name + "]! 别想跑, 今天我要彻底粉碎你那虚伪的贵族光环!",
                "我跨下的战马已经嗅到了你灵魂里的恶臭. 在马梅里诺之盾面前, 收起你那可怜的诡计, 受死吧!",
                "又是你这个令人扫兴的家伙. [" + _player_name + "], 你的战旗就像枯萎的树叶一样难看. 既然你敢再次进入我的视野, 我就勉为其难地把你扫进历史的尘埃里!"
            ],
            [
                "[" + _player_name + "], 既然你再次代表 [" + _player_country_name + "] 出现在我面前, 那就没什么好说的了! 让我们战个痛快!",
                "[" + _player_name + "]! 听听这风声, 那是冲锋的号角! 既然你出现在我的猎场上, 那就别怪我的长枪不长眼睛. 来, 战个痛快!",
                "在这片森林里, 只有强者才配拥有名字. [" + _player_name + "], 虽然你我无冤无仇, 但为了国家的荣誉, 请务必拼死一搏!",
            ],
            [
                "喔! 我亲爱的对手 - [" + _player_name + "]! 既然命运要我们在战场上见生死, 那就让我们杀出一场最灿烂的火花吧!",
                "[" + _player_name + "], 既然是老对手了, 那就收起那些虚伪的客套, 用这最赤诚的钢铁交锋来续写我们的交情吧!",
            ],
            [
                "哈哈哈哈! 我的老伙计, 我就知道是你! 在这片冷酷的大陆中, 唯有和你战斗能让我血液沸腾! 来吧, 为了各自的荣光, 开启这场华丽的决战!",
                "亲爱的对手! 能再次拦截你的军阵, 真是我这趟旅程中最棒的惊喜. 别让我失望, [" + _player_name + "], 用你全部的力量来迎接我的冲锋吧!",
                "[" + _player_name + "]! 我的挚友! 这世间除了你, 还有谁能配得上流浪骑士之枪的冲锋?",
                "我的老伙计, 让我们像传说中的英雄那样, 在血泊与火花中完成这最后的一击! 冲锋!",
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["[" + _player_name + "]! 你的罪行比那吃人的巨兽还要丑恶! 我本该现在就将你刺穿, 但我正要去执行一项改变命运的宏大远征. 感谢命运吧，恶徒!"],
            ["这不是通缉令上的面孔 - [" + _player_name + "] 吗? 你这种只会在阴影里乱窜的鼠辈, 根本不配死在我的剑下. 滚回你的地洞里去."],
            ["我听说过你, [" + _player_name + "]. 虽然你是个背负罪名的浪人, 但今天我没有收到决斗的旨意. 所以放你一马."],
            ["哈哈! 你就是那个让领主们头疼的冒险家 [" + _player_name + "]? 虽然你的行径有违道义, 但敢于挑战权威的胆量还算不赖. 今天我就当没看见你, 去吧, 寻找你那迷失的荣誉."],
            ["喔! 瞧瞧我遇到了谁! 一个活生生的通缉犯! [" + _player_name + "], 虽然你是我的敌人, 但我知道你曾经帮助过我的子民. 走吧! 保重性命."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["你怎么还在这里徘徊? 快滚!"],
                ["啧! 你怎么像甩不掉的沼泽泥巴?"],
                ["还有什么事? 虽然骑士应该保持耐心, 但面对一个通缉犯的反复骚扰, 我也是有底线的."],
                ["快走吧, 有缘再见."],
                ["现在不是叙旧的时候, 快找个地方躲起来吧. 别被卫兵抓了."],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]! 你这不知羞耻的恶徒! 你竟敢一而再地挑战我的宽容?"],
                ["你的名字像苍蝇一样粘在通缉名单上, [" + _player_name + "]. 我今日不想让我的战马踩碎你这种人的骨头, 立刻消失, 在我改变主意把你押送到断头台之前!"],
                ["又是你, 我已经说过, 我不屑于取通缉犯的性命. 别再出现在我的马蹄前!"],
                ["又是你, 你这副模样让我想起了一位迷途的勇士. 走吧, 趁我还没想起你那累累罪行."],
                ["我的朋友 [" + _player_name + "]! 你作为通缉犯可真够嚣张的, 居然还敢出现在我面前. 保护好你的人头, 下一次, 我会准备好最隆重的仪式来抓捕你!"],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 那个投靠了 [" + _player_country_name + "], 双手沾满血腥的家伙! 即便隔着盔甲我都能闻到你那令人厌恶的恶臭. 你如此紧逼, 是想告诉我你已经等不及要在这儿分个生死了吗?"],
            ["你就是那个受封于 [" + _player_country_name + "] 的领主 - [" + _player_name + "]? 既然你执意要拦在风车骑士的马前，想必不只是为了打个招呼吧?"],
            ["想必你就是那位声名鹊起的人物 - [" + _player_name + "]! 既然你已经追到了这种距离, 是在等我先拔剑, 还是你已经准备好冲锋了?"],
            ["哈! 竟然是 [" + _player_name + "]! 传闻你加入 [" + _player_country_name + "] 后从未尝败绩, 这份压迫感果然名不虚传! 既然你如此热烈地追逐我的旗帜, 是想在今日就与我一决高下吗?"],
            ["哈哈哈! 你就是那颗在 [" + _player_country_name + "] 冉冉升起的新星 [" + _player_name + "] 吧? 你如此迫切地逼近, 是想在今日彻底终结我的荣耀吗?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["还在这里徘徊? 赶紧离开我的视线!"],
                ["别再窥探了, [" + _player_name + "]!"],
                ["你是在消磨我的耐心吗? 要打便打!"],
                ["你在等什么? 等风停, 还是等我露出破绽?"],
                ["你还赖在这里做什么? 既然不打算跟我分个胜负, 就别像影子一样跟着我!"],
            ]
        else:
            return[
                [
                    "又是你, 宿敌 [" + _player_name + "]! 你一直咬着我不放, 是觉得今日能稳稳吃掉我吗?",
                    "[" + _player_name + "]! 你是想趁着我的战马疲惫时偷袭吗? 来吧! 即便长枪折断, 我也会用牙齿撕碎你的贪婪!"
                ],
                [
                    "[" + _player_name + "], 你这缠人的架势真让人头疼. 想开战就快点, 别在这儿浪费时间!",
                    "[" + _player_name + "], 既然你追到了这里, 想必已经做好了被我反击的觉悟. 你是想现在就分出高下吗?"
                ],
                [
                    "又见面了, [" + _player_name + "]. 你想在这里打破你我之间的僵局吗？",
                    "[" + _player_name + "], 虽然我现在的处境有些尴尬, 但这并不妨碍我能把你挑落马下。"
                ],
                [
                    "哈哈! [" + _player_name + "], 你果然追上来了! 像你这样执着的对手, 简直是这个平庸时代的亮光. 你是打算在此处开启我们的对决吗?",
                    "我亲爱的对手 - [" + _player_name + "], 在这个时候拦下我, 我也只能拔出这柄流浪骑士之剑了. 你确定要在这里动手吗?"
                ],
                [
                    "哈哈! 不愧是我的一生之敌! [" + _player_name + "], 既然你已经追到了决斗的距离, 你是想现在就开始这场狩猎吗?",
                    "[" + _player_name + "]! 你总是能出现在最不该出现的地方! 既然你已经追到了这里, 想必是想亲手终结我们的宿命."
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["我是堂吉诃德, [" + _target_country_name + "] 的领主. [" + _player_name + "]! 你的恶行已让你的剑蒙羞! 若非此时处于虚假的和平之中, 我定要以此长枪刺穿你那颗贪婪的心脏. 离我远点!"],
            ["我是堂吉诃德. [" + _target_country_name + "] 的领主. [" + _player_name + "], 我在你的身上感觉到了豺狼般的贪婪. 你那只为德里而挥动的剑, 不配直视马梅里诺之盾的光辉."],
            ["我是堂吉诃德. [" + _target_country_name + "] 的领主. 流浪的勇士. 在那夕阳的地平线下, 我似乎看到了你未来的荣光. 你是在寻找值得挑战的恶龙, 还是在寻找一份可以为之献身的誓言?"],
            ["我是堂吉诃德. [" + _target_country_name + "] 的领主. 正义的冒险家! 吾听闻你单枪匹马在荒野中护下了我的子民. 像你这样正直的灵魂, 简直是这污秽世间的最后荣光."],
            ["我是堂吉诃德, [" + _target_country_name + "] 的领主. [" + _player_name + "]! 我知道你的事迹, 你那英勇的姿态真让我心醉! 这乱世正需要你这种不畏强权的豪杰."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["恶徒! 莫要以为和平能永远遮蔽你的罪恶, 吾的长枪时刻在鸣动!"],
                ["庸人, 不要挡住骑士的路!"],
                ["[" + _player_name + "], 为何一直跟随我?"],
                ["噢! 让我再次为你讲讲我击败三十个巨人的壮举!"],
                ["哈哈哈! 热血沸腾了吗? 那就让我们一起对着那邪恶的巨人发起冲锋吧!"],
            ]
        else:
            return[
                ["那股令人窒息的黑暗再次降临了! [" + _player_name + "], 时间还没能让你学会悔改? 在我的长枪因正义而暴走之前, 滚出这片圣洁的土地!"],
                ["又是你, 满身铜臭的冒险者. 你的内心依然荒芜如沙漠吗? 唯有获取荣誉能拯救你的灵魂."],
                ["又见面了, [" + _player_name + "], 在那远方的群山中, 你是否找到了能让灵魂安息的骑士信条?"],
                ["又见面了, 正直的冒险者. 这世间的邪恶是否因你的存在而减少了一分? 为了清除邪恶, 我的马蹄从未停止!"],
                ["哈哈哈! 我的挚友, 你终于从那充满磨难的旅途中归来了! 快给我分享那些你斩杀邪恶巨人的故事!"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["我是堂吉诃德. 阁下就是那位传闻中行事乖张的领主? 虽然你我同属一个国家, 但我的长枪绝不护佑无德之人. 若你敢玷污 [" + _target_country_name + "] 的荣誉, 我定会向你发起决斗!"],
                ["我是堂吉诃德. 阁下, 我在你的旗帜下看到了一些怠惰. 身为领主, 若不投身于伟大的冒险, 那与路边的磨坊有何区别?"],
                ["我是堂吉诃德! 欢迎你, 新晋的同僚! 让我们共同立誓, 要将这片土地上的邪恶巨人通通驱逐出去!"],
                ["我是堂吉诃德! 我听闻阁下的士兵纪律严明, 正直之风盛行. 像阁下这样高尚的骑士, 正是我梦寐以求的战友!"],
                ["我是堂吉诃德! 阁下的英名如雷贯耳! 快, 拔出你的剑, 让我看看这能劈开黑夜的锋芒!"]
            ]
        else:
            return[
                ["我是堂吉诃德. [" + _player_country_name + "] 的领主. [" + _player_name + "], 我早已看穿了你那虚伪的外衣! 即便现在是和平时间, 我的马梅里诺之盾也时刻准备着迎接你的袭击!"],
                ["我是堂吉诃德. [" + _player_country_name + "] 的领主. 你的到来让这片空气都变得浑浊了. 若你不是来递交挑战书的, 就请速速离开此地."],
                ["我是堂吉诃德, [" + _player_country_name + "] 的领主. 异国的领主, 你是带着寻求荣誉之心来到这片森林, 还是带着那些无聊的政治算计?"],
                ["我是堂吉诃德. [" + _player_country_name + "] 的领主. 欢迎阁下, 正直的异国领主. 虽然两国曾有冲突, 但我坚信骑士精神是不分国界的."],
                ["我是堂吉诃德, [" + _player_country_name + "] 的领主. 久仰大名! [" + _player_country_name + "] 的传奇领主 - [" + _player_name + "]! 阁下的每一个战斗传言都让我热血沸腾! 来吧，让我等在这林间畅谈武勋!"]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["莫要以为和平的甲胄能永远遮蔽你肮脏的灵魂!"],
                ["你的犹豫不决正在消磨我的斗志."],
                ["还有何事？"],
                ["下次我们好好喝上一杯."],
                ["朋友，你是想再次确认那伟大的誓言吗?"],
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[

                    [
                        "[" + _player_name + "]! 你身上散发着一股阴谋和油腻的气息, 这简直是对骑士精神的侮辱!",
                        "[" + _player_name + "]! 你竟然还有脸出现在我面前? 收起你那卑劣的意图!"
                    ],

                    [
                        "哼, 看看你那鬼鬼祟祟的样子. 离我远点."
                    ],

                    [
                        "同僚, 你的刀刃是否生锈了? 如果你只想安稳地坐在封地上数钱, 那就不配与吾并肩."
                    ],

                    [
                        "看看你, [" + _player_name + "]! 别告诉我你已经变成了那种只会在壁炉边烤火的慵懒政客!"
                    ],

                    [
                        "[" + _player_name + "] 阁下, 在这段日子里, 你是否已经找到了自己的信条?"
                    ],

                    [
                        "久违了, 正直的伙伴. 我能感觉到, 正义的火焰依然在你我心中跳动!"
                    ],

                    [
                        "[" + _player_name + "], 你来得正好. 我刚整理完我的作战准则.",
                    ],

                    [
                        "久违了, 正直的伙伴! 只要看到你那坚毅的眼神, 我就知道这世间的正义尚未湮灭.",
                    ],

                    [
                        "哈哈哈! 你终于回来了! 快随吾去斩断那邪恶异教徒的阴谋, 让 [" + _target_country_name + "] 之名响彻云霄!",
                        "[" + _player_name + "], 在 [" + _target_country_name + "] 的所有领主中, 唯有你能读懂我内心的热血.",
                        "[" + _player_name + "], 能与你同举一面旗帜, 是我这辈子最大的骄傲.",
                        "哈哈哈! 看看这英武的步伐! 哪怕是传说中的亚瑟王亲临, 恐怕也要对你礼让三分.",
                        "只要你我并肩作战, 哪怕前面是通往地狱的深渊, 我也敢跳下去."
                    ],
                ]
            else:
                return[
                    [
                        "[" + _player_country_name + "] 的领主, 离我远点, 否则马梅里诺之盾将再次撞碎你的野心!",
                        "又见面了, [" + _player_name + "], 别以为这暂时的和平能保护你, 我的长枪随时准备刺穿你的伪装!"
                    ],
                    [
                        "又是你, [" + _player_country_name + "] 的领主, 离我远点! 在这片神圣的森林里, 没有你这种邪恶投机者的位置."
                    ],
                    [
                        "又是你, [" + _player_name + "]. 如果你继续在这片领地徘徊, 吾将视你为潜在的威胁.",
                    ],

                    [
                        "[" + _player_name + "] 阁下, 命运再次让我们重逢. 这次你是带来了关于邪恶巨人的线索, 还是仅仅想在此虚度光阴?"
                    ],
                    [
                        "很高兴再次见到阁下. 虽然身为异国领主, 但你的高尚让吾深感钦佩. 愿和平永驻!",
                    ],
                    [
                        "很高兴再次见到你, [" + _player_name + "] 阁下, 在这虚伪的世界里, 能见到一个像你这样正直的游侠, 真是意外之喜.",
                    ],
                    [
                        "哈哈哈! 异国的猛虎! 能与阁下再次共饮, 简直是人生快事! 快来跟我说说你最近又击败了多少邪恶的巨人.",
                        "快过来, 我亲爱的异国战友! 我的马梅里诺之盾已经感应到了你灵魂中的正义!"
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "为了" + _country_name + "的荣光! 冲锋!",
        "众将士, 随我冲锋!",
        "风车骑士在此! 感受正义的雷霆吧!",
        "不要退缩! 你们面前的不是敌人, 而是等待被净化的恶魔!",
        "马梅里诺之盾指引着我们! 全军突击!",
        "全军突击, 撞碎他们的阵线!",
        "让这片森林见证一场足以载入史诗的伟大冲锋!",
        "颤抖吧, 恶魔们!",
        "为了正义! 为了那些被遗忘的誓言! 全军冲锋!",
        "不要被这些幻象迷惑! 冲锋!",
        "谁敢随我直取中军?",
        "让这些恶徒见识一下, 什么叫真正的骑士精神!",
        "冲啊! 我们要去赢取那永恒的荣光!",
        "马蹄所到之处, 皆为正义之土! 冲锋!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _country_name: = _get_country_name()

    var _list: = [
        "这片土地将记住你的失败",
        "我给予了你应得的审判",
        "这便是对抗正义骑士的必然结局!",
        "击杀!"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这就是宿命, " + _target_hero_name,
            "再见了, " + _target_hero_name,
            "倒下吧, " + _target_hero_name,
            "记住我的名字, " + _target_hero_name,
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "痛快!",
        "咳...",
        "咳...不可饶恕!",
        "你这卑劣的鼠辈!",
        "马梅里诺之盾依然坚固!",
        "来吧!",
        "这种程度的伤! 继续进攻!",
        "马梅里诺救赎我!",
        "嘶...这点小把戏",
        "很好!",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "竟然被...",
        "长枪...折断了...",
        "杜尔西内娅...你看见了吗...",
        "杜尔西内娅...",
        "哪怕是死...",
        "这场梦...终于...",
        "冲锋..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "保持阵型!",
        "稳步向前!",
        "我们要像一座移动的要塞, 碾碎邪恶!",
        "在马梅里诺的庇护下, 稳步推进!",
        "挺起胸膛! 让敌人看清正义者的旗帜正在逼近!",
        "稳住! 我们要以最无可挑剔的姿态合围他们!",
        "压过去! 把邪恶挤出这片森林!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住阵线!",
        "原地待命! 立盾!",
        "原地待命!",
        "原地防守! 莫要落入敌人的陷阱!",
        "不要后退!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    var _country_name: = _get_country_name()

    return[
        "哈哈! 这场胜利将永载史册!",
        "去吧, 收集那些战利品, 它们是勇士应得的奖赏!",
        "愿阵亡的兄弟在森林间安息...",
        "只要有我在, 邪恶便无处遁形!",
        "这就是风车骑士的胜利!",
        "哈哈哈！这就是正义的力量!",
        "战士们! 今晚的篝火将为你们的勇猛而燃烧!",
        "整理好你们的披风! 我们要以最优雅的姿态迎接胜利的欢呼!",
        "让这一战的功绩, 传遍" + _country_name + "的每一座酒馆!",
    ].pick_random()

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "这就是所谓的\"风车骑士\"? 不过是头栽进泥里的疯子罢了."
        ],
        [

            "看看你的马梅里诺之盾, 现在连风都挡不住, 更别说挡住我的剑了."
        ],
        [

            "清醒点吧, 你输了. 你的冲锋在我的阵型面前一文不值."
        ],
        [

            "跟着我走, 别逼我用绳子把你捆在马背上."
        ],
        [

            "你这种鲁莽只会害死你的部下, 堂吉诃德."
        ],
        [

            "我们要越过这片土地, 希望你不要尝试逃跑."
        ],
        [

            "承让了, 堂吉诃德大人. 请卸下你的武装, 随我回营吧."
        ],
        [

            "堂吉诃德大人, 很抱歉必须限制你的自由, 但我保证你会受到最高规格的礼遇."
        ],
        [

            "请原谅我, 堂吉诃德大人. 为了大局, 我必须暂时剥夺你的自由, 但我会用我的荣誉担保你的安全."
        ],
        [

            "下次有机会, 希望能和你并肩作战, 而不是像这样兵戎相见."
        ],
        [

            "堂吉诃德大人. 你冲锋的姿态, 足以让这片森林里的每一棵橡树都为你低头."
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "卑劣的邪魔! 别以为你用妖术弄断了我的长枪, 就能折断我的灵魂!"
        ],
        [

            "那是圣物的磨损, 是荣耀的勋章!"
        ],
        [

            "输? 不, 这只是命运的一次小小捉弄. 真正的骑士从不计较暂时的得失, 而你却在为这点微小的优势沾沾自喜."
        ],
        [

            "哼..."
        ],
        [

            "他们是随我征讨黑暗的英雄! 即便战死, 他们的名字也将随我一同刻在不朽的史诗之上, 而你这种庸人永远不会懂!"
        ],
        [

            "我承诺. 我会以囚徒的身份等待下一次正义的召唤."
        ],
        [

            "我承认, 你的策略像那狡猾的魔法师一样多变. 既然败了, 我会遵循骑士的准则."
        ],
        [

            "战场上的胜负就像森林里的风, 吹过便散了. 能落在你这样高尚的人手中, 是我的荣幸."
        ],
        [

            "走吧, 别让夕阳看见我的落寞."
        ],
        [

            "..."
        ],
        [

            "不必宽慰我, 勇士. 当我的脊背触碰泥土的那一刻, 我就知道那场关于击败巨人的幻梦已经醒了."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "哼! 你这邪恶的法师, 又来欣赏你的战利品了吗? 收起你那贪婪的眼神!",
            "别以为这小小的牢笼能锁住风车骑士的灵魂. 说吧, 你要多少赎金才肯停止这场卑劣的软禁?",
            "[" + _player_name + "]! 别以为这生锈的铁栏能锁住骑士的灵魂. 开个价吧!"
        ],
        [
            "这发霉的干草简直是对我身份的侮辱! 快点, 谈谈你要多少补偿才肯让我重回马背?",
            "这发霉的干草简直是对我身份的侮辱! [" + _player_name + "]. 你就是这样对待一位落难骑士的吗?",
        ],
        [
            "这简陋的囚室装不下伟大的志向! 来吧, 告诉我需要多少德里才能换回我的自由?"
        ],
        [
            "我已正视当下的磨难, 这不过是英雄史诗中必经的转折. [" + _player_name + "], 你是来见证传奇的低谷吗?",
            "你应该感到自豪. 毕竟, 能击败风车骑士的人, 这世上可没几个.",
        ],
        [
            "老朋友, 你又来探望这片森林里最勇猛的囚徒了?",
            "既然是输给了你, 我没什么好抱怨的.",
            "[" + _player_name + "], 我的挚友! 你总不会打算让我在这儿待到胡子变白吧?"
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "我的家人会出 [#{0}] 德里换取我的自由, 如何?",
        "我会用 [#{0}] 德里作为这次\"意外\"的补偿, 换取我重回马背的权利. 如何?",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "拿走这些财物, 你这施展妖术的恶魔! 下一次, 我的长枪会直接刺穿你的伪装!",
            "很好, 贪婪的秃鹫. 森林会记住这一天的耻辱."
        ],
        [
            "很好, 不要以为下次你还能有同样的运气.",
            "很好, 我会回到我的马背上, 而你, 最好祈祷下次还能有这份运气.",
            "现在, 让路! 不要阻挡一位骑士重返他神圣的征途!"
        ],
        [
            "很好, 希望下次见面, 你的剑还能像这次一样稳固.",
            "作为骑士, 我从不吝啬于承认失败. 拿走你的战利品, 去酒馆吹嘘你的战绩, 直到我再次出现并终结它!"
        ],
        [
            "我重获自由, 而你获得了应得的奖赏, 这很公平. 愿你在未来的战场上, 依然能保持这份足以与我匹敌的武勇.",
            "很好, [" + _player_name + "]. 我已经迫不及待要在那片森林里与你再次对决了."
        ],
        [
            "你这次可是让我付出了不小的代价, 我的老伙计! 下次冲锋时, 我可不会再让你了.",
            "很好, 我期待与你的下次对决. 再会!"
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "哈! 你这邪恶的巫师, 又想玩什么新花样? 想用这种虚伪的仁慈来瓦解我的斗志吗?",
            "别开玩笑了, [" + _player_name + "]! 你一定是在策划比掠夺更可怕的阴谋!",
            "这太反常了! 这种情节通常都是一个巨大的陷阱!",
            "你在耍我吗? 你一定是想等我走出大门, 再从背后射箭!"
        ],
        [
            "你竟然打算就这么放了我?",
            "虽然我渴望重回马背, 但我必须确认 - 你真的打算就这么放了我?"
        ],
        [
            "你的慷慨让我感到不安. 告诉我, 这真的不是你酒后的胡言乱语?",
        ],
        [
            "不需要财物? 我就知道, 你的胸膛里跳动着一颗荣耀之心!"
        ],
        [
            "哈哈! 你是想让我欠下一份永远还不清的\"英雄债\"吗？",
            "你是想用这种方式把我变成你诗歌里的配角吗? 我的好友."
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "这笔恩情我记下了. 虽然你放了我, 但正义的骑士绝不会向恶徒妥协. 后会有期!",
            "我接受这份自由. 虽然我不理解你的动机, 但我会把这当成一次关于\"仁慈\"的试炼. 再见.",
            "这真是我漫长远征中最荒诞的一章. 既然你开了门, 那我就不多留了."
        ],
        [
            "愿你的慷慨不会让你在未来的战场上后悔.",
            "[" + _player_name + "], 我会重新审视你的, 再会",
            "既然绳索已解, 那我就不再逗留了. 保重, 难以捉摸的家伙.",
        ],
        [
            "瞧瞧这份气魄! [" + _player_name + "], 你展现出了足以被吟游诗人传唱的慷慨! 那么有缘再见了!",
            "很好! 你的正直赢得了我的尊重. 再会",
        ],
        [
            "你的决定就像划破黑夜的闪电! [" + _player_name + "]! 你足以赢得我的尊重!",
            "我重获了自由, 而你收获了一个骑士的认可! 再会!",
            "这份恩情我记下了, 再会."
        ],
        [
            "你的选择证明了你拥有真正的英雄之魂! 保重, 告辞.",
            "这就是我梦寐以求的时刻! 两个伟大的灵魂在硝烟散尽后的默契. 再会了我的朋友."
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "我愿意用这件 [#{0}] 换取我的自由. 如何?",
        "英雄不该困于铁笼! 我用这件 [#{0}] 换取再次冲锋的机会, 如何?"
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "虽然我对你之前的某些做法看不惯, 但今天你面对强敌没有退缩, 配得上老骑士的尊重!",
        "合围的战场不是算计私怨的地方. 你完成了你的战斗, 我向你致敬.",
        "看在荣誉的份上, 我收回之前对你的一部分偏见. 这一战打得不错",
        "今天你表现得像个真正的战士. 虽然我们之前有一些过节, 但我绝不会因为个人恩怨就否定你立下的战功.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "配合得不错! 下次冲锋的时候如果能更不顾后果, 更狂热一点, 那就更完美了, 哈哈哈!",
        "我的长枪已经刺穿了敌阵, 而你的掩护也恰到好处. 这真是一场伟大的冒险!",
        "你今天打得挺好, 跟上了我的节奏.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 老搭档! 这次配合得真不赖!",
        "只要咱们俩联手, 这世上就没有冲不散的防线!",
        "我的坐骑今天跑得像疯了一样, 而你居然还能死死咬住阵型打出配合! 不愧是我的好战友."
    ]