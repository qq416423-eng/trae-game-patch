extends LordNobleDialogue

const HERO_UID: = "lord_hero_0003"

func _get_granted_fief_clist()-> Array:
    return[
        "以王国的律法与秩序之名, 吾将 [#{0}] 的管理权授予你. 你的职责是确保其繁荣与安定, 收税是你的权利, 但仁慈的治理是你的义务. 愿星辰能指引你的道路."
    ]


func _get_attendant_meet_content()-> Array:
    return[
        {
            "clist": [
                "前方是艾德拉斯王国之主 - [#{b_leader_name}] 的阵地, 请于此止步. (声望过低, 女王拒绝接见)",
                "旅人, 请止步. 星辰的光辉不容凡尘之扰. (声望过低, 女王拒绝接见)",
                "请勿前行, 此地沐浴在星辉之下, 唯有受召者才能靠近. (声望过低, 女王拒绝接见)",
                "前方是星辰女王的部队, 请止步肃立, 以免冒犯王威. (声望过低, 女王拒绝接见)",
            ]
        }
    ]


func _king_reject_join_low_reputation_dialogue()-> Array:
    return[
        "吾听闻你的事迹, 但星辰尚未为你指路. 等它闪耀之时, 再来吧. " + LOW_REPUTATION_TIP,
        "你的名声正在传扬, 吾承认. 但想要身披吾国王旗, 还须更多证明. " + LOW_REPUTATION_TIP,
    ]



func king_reject_join_rel_bad_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        "效忠于吾? [" + _player_name + "], 你那充满杂质的灵魂即便在最璀璨的星光下也无法被洗净. 吾不需要一个随时可能背弃誓言的变数.",
        "吾之职责是保全这片平原的安宁, 而非收容一个危险的火种. [" + _player_name + "], 收起你那毫无诚意的投诚, 吾之棋盘上没有你的位置."
    ]


func _king_agree_join_low_reputation_dialogue()-> Array:
    return[
        "命运将你带至此处，而吾接受这份指引, 你已证明自己配得上这份信任与尊荣. #{a_leader_name}, 自此刻起，你的名字将与艾德拉斯王国一同闪耀."
    ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "我军的部署早已万无一失. 请勿再做出这种干扰军务的举动."
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的协助让战事提前结束, 很好. 但胜利的根基在于周密的计划, 而非冲动.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "你总是如此可靠, 朋友. 看到你平安无事, 吾感到很欣慰."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "你展现了非凡的智慧和勇气. 过去的恩怨, 吾允许你用功绩来弥补.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你的救援非常及时且高效. 吾欠你一个人情.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你的智慧与力量, 是星辰王国最宝贵的财富. 能拥有你这样的朋友, 是吾的荣幸."
    ]


func _get_battle_thank_first_meet_clist()-> Array:
    return[
        "吾是 [#{0}] 的女王 - [#{b_leader_name}].",
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "你想清楚了吗? 女王陛下虽崇尚和平. 但艾德拉斯的利剑从未生锈. 对这面旗帜拔剑, 代价是你无法承受的."
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "星辰太远了, 我只想要眼前的财富. 拔剑吧, 女王的走狗!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "我只是喝多了想找个地方跳舞, 结果不小心拔了剑...我想我该带我的人去溪边洗洗脸了."
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["你眼中的贪婪连星光都无法照亮. 只要你敢踏前一步, 艾德拉斯的平原就会成为你永久的墓地."],
        ["收起你那毫无意义的武力示威, 流浪者. 攻击吾等同于向 [" + _target_country_name + "] 宣战, 你的名字将被刻在耻辱柱上被群星唾弃."],
        ["你要向吾挑战? 想清楚了吗? 一旦见红, 吾的星辰卫队绝不会留下任何隐患."],
        ["吾从星象中看到了动荡, 但吾没料到是来自于你. 把剑收回去, 别让这瞬间的迷失毁了你的前程."],
        ["吾曾以为你和吾一样是受星辰眷顾的人. 这一步跨出, 你将失去所有的信任, 你真的要亲手毁灭我们的情义吗?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["你终于露出了獠牙. 只要你向前一步, 那份和平协议将化为灰烬. 吾保证 [" + _target_country_name + "] 的骑士会覆盖你领地的每一寸草地. 你确定要打开这扇毁灭之门?"],
        ["收起你那拙劣的试探, 这一剑下去, 两国边境将陷入永恒的黑暗, 而你就是那个背负万千性命的背誓者. 你真的打算宣战?"],
        ["你代表的是你的子民. 这一步踏出, 就再也没有和谈, 只有清算. 你确定要让你的子民为你这瞬间的冲动而陪葬吗?"],
        ["吾的朋友, 这种博弈并不高明. 我们两国的和平来之不易, 你这一动手, 吾就不得不踏平你的防线. 把剑收回去，吾愿意给和平一个机会."],
        ["吾视你为最可靠的盟友, 你却要在吾的殿堂前拔剑? 一旦开战, 你就是重燃战火的罪人."],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["星辰已闭上眼, 剩下的只有审判. 吾会让你明白, 挑衅 [" + _target_country_name + "] 需要付出什么代价!"],
        ["既然你执意选择黑暗, 那吾就用这星辰之火将你彻底净化. 全军听令, 做好战斗准备!"],
        ["既然这是你选的路, 那就让鲜血来见证你的终点. 准备! 战斗!"],
        ["很遗憾. 你本可以拥有广阔的未来, 现在却只能死在吾的剑下."],
        ["这就是你的选择吗? 从这一刻起, 星辰将不再照耀你, 你只是一个需要被清理的污点."],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["既然你要背弃星辰下的誓言, 那就准备好迎接 [" + _target_country_name + "] 的怒火吧!"],
        ["你不仅是个祸害, 更是文明的耻辱. 既然你想要战争, 吾就给你战争."],
        ["你选择了最愚蠢的博弈. 既然和平无法约束你的野心, 那就让毁灭来重塑秩序!"],
        ["吾高估了你的格局. 既然你执意毁掉这来之不易的和平, 那就用你的血来偿还!"],
        ["你违背了星辰下的誓言! 这一刻起, 你我之间只有仇恨! 士兵们! 准备战斗!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "吾就知道命运终会将你送到吾面前. 你的轨迹到此为止了, 拔剑吧!",
            "[" + _player_name + "], 你妄图用凡人的战火遮蔽星辰的光辉吗? 吾便以此星辰弓, 为你指引最后的归宿!",
        ],
        [
            "[" + _target_country_name + "] 的将士们! 为了星辰的荣光, 将这些贪婪的入侵者彻底驱逐!",
            "[" + _player_name + "], 我会亲手将你陨灭. 众将士, 为了女神的荣光! 冲锋!"
        ],
        [
            "既然棋局已成, 那就让剑刃来决定谁才是最后的赢家."
        ],
        [
            "作为对手, 你的勇气的确耀眼. 但星辰指引吾必须获得胜利. 拔剑吧!",
            "[" + _player_name + "], 既然无法回头, 那就让吾在战斗中, 最后一次确认你的意志吧!"
        ],
        [
            "这是悲剧的交汇, 吾的朋友. 既然我们在战火中相遇, 就让这最后一战来完成我们的宿命.",
            "[" + _player_name + "], 吾会倾尽全力, 给予你最庄严的送别",
            "[" + _player_name + "], 假如吾今日注定要回到女神的怀抱, 那吾也会在陨落前, 燃尽所有的光芒将你击碎!"
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["你说得对, 在这种地方动手确实是自寻死路. 既然星辰还没判我死刑, 我今天就先收手."],
        ["你说得对, 我这点家当在女王的星辰卫队面前确实不算什么."],
        ["我不该为了这一时的意气让我的灵魂陷入永恒的黑暗. 我不打了."],
        ["女王的话让我清醒了. 我不该让一时的迷失毁了自己的前程."],
        ["我不打算成为被星辰唾弃的死囚. 刚才的冲突就此作罢."],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["你说得对, 我不该为了个人的愤怒而熄灭两国的和平之光."],
        ["你提醒了我, 我不仅仅是代表我自己. 我不想成为那个被群星咒骂的背誓者."],
        ["你说得对, 女王, 我不该让子民为我这瞬间的冲动陪葬."],
        ["既然女王愿意给和平一个机会, 我也没必要执迷不悟."],
        ["你提到\"契约\"时我的心颤抖了. 我不想毁掉我们的情义, 也不想成为重燃战火的罪人."],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 星辰的轨迹中不该有你这种污点. 为了 [" + _country_name + "] 的纯净, 你的旅途到此为止了."],
            ["你就是 [" + _player_name + "] 吧. 你的存在扰乱了平原的秩序, 既然你选择了与吾为敌, 那就准备接受星辰降下的裁决."],
            ["你就是 [" + _player_name + "]? 你应该还记得自己做出的无理之事吧? 就意味着你是必须消除的变数."],
            ["你就是 [" + _player_name + "] 吧. 吾听说你曾对吾的子民心怀仁慈, 这是一个高尚的策略. 可惜, 法律的天平并不会因此倾斜."],
            ["你就是 [" + _player_name + "] 吧. 星辰曾预示吾会遇见一位卓越的灵魂, 没想到竟是以这种方式. 虽然你是罪人, 但吾依然对你抱有最大的敬意."]
        ]
    else:
        return[
            ["[" + _player_name + "], 看来星辰还没教会你恐惧. 这一次, 你的命运线将在这里彻底断裂."],
            ["[" + _player_name + "]. 这一次, 吾不会再给你逃脱的机会."],
            ["[" + _player_name + "], 既然你再次出现在吾面前, 那就准备接受星辰降下的裁决吧."],
            ["又见面了, [" + _player_name + "]. 虽然吾曾默许你的离去, 但既然你再次踏入吾的棋局, 吾就必须执行女王的职责."],
            ["很高兴再次见到你, [" + _player_name + "]. 能与你这样的人在战场上重逢, 也是星辰赐予吾的为数不多的惊喜. 拔剑吧!"]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 吾听闻你在边境的行径如蝗虫般贪婪, [" + _player_country_name + "] 封你为领主真是耻辱. 吾将在此终结你的野心."],
            ["你就是 [" + _player_name + "] 吧. 两国交战在所难免, 而且你那缺乏底线的手段令人厌恶. 既然你敢出现, 就准备好接受星辰的裁决."],
            ["你就是 [" + _player_name + "] 吧. 听说你效忠了 [" + _player_country_name + "]. 吾身为 [" + _target_country_name + "] 的女王, 不能放任敌国领主在吾的领土横行. 拔剑吧."],
            ["你就是 [" + _player_name + "] 吧. 吾听闻吾的子民曾受到你的照顾, 你本应是吾所欣赏的灵魂. 可惜战火已燃, 作为女王, 吾必须在此将你拦截."],
            ["你就是 [" + _player_name + "] 吧! 星辰曾预示吾会遇见一位卓越的统帅, 没想到竟是在这充满血腥的战场. 虽为敌手, 但能与你对弈, 亦是吾之幸事."],
        ]
    else:
        return[
            [
                "[" + _player_name + "], 你那满是腐臭的气息再次搅乱了星辰的轨迹. 这一次, 这里将成为你的葬身之地.",
                "[" + _player_name + "], 你的灵魂已被星辰唾弃. 在这片荒原上, 你无处可藏, 因为月光早已照亮了你自毁的终点. 受死, 罪人!",
                "在吾母神的注视下, 你那卑劣的野心不过是转瞬即逝的碎裂星火. [" + _player_name + "], 受死吧."
            ],
            [
                "又见面了, [" + _player_name + "]. 既然你执意在吾的棋局中反复跳梁, 吾便在此彻底清理掉你这个变数.",
                "[" + _player_name + "], 你的存在就像星图上的裂痕, 令吾感到不安. 既然你一再触碰国家的红线, 吾便亲手将你这个多余的棋子剔除出局!",
                "又是这种浑浊的气息. [" + _player_name + "], 你的行为正在亵渎这片神圣的平原. 别再试图逃离了, 在星光的罗网之下, 没有罪人能全身而退."
            ],
            [
                "[" + _player_name + "], 战火未熄, 星轨重逢. 既然你代表你的国家踏入此处, 就让我们用手中的剑, 为这场漫长的对峙落下一枚棋子吧.",
                "[" + _player_name + "], 攻守之势已在星轨中易位. 既然你代表你的国家选择了进军, 那吾便以女王之名, 在此回应汝的挑战. 全军列阵!",
                "棋局尚未终结, [" + _player_name + "]. 既然你在吾的疆域边缘徘徊, 那吾便不得不亲手落下一子, 来调整两国的平衡. 拔剑吧!"
            ],
            [
                "又见面了, [" + _player_name + "], 吾必须履行女王的职责. 拔剑吧",
                "[" + _player_name + "], 吾之冠冕要求吾截断你的归途. 在剑光交错前, 请接受吾最后的一份礼赞.",
                "又见面了, [" + _player_name + "]. 虽然吾欣赏你的才华, 但星序的运行不容私情. 让这场追逐终结在荣耀之中吧."
            ],
            [
                "虽然吾更希望与你在星辰下对坐弈棋, 而非在此交锋. 但命运将你我置于棋局的两端, 拔剑吧, [" + _player_name + "].",
                "[" + _player_name + "], 唯有汝, 能让吾在枯燥的棋局中感受到真实的博弈.",
                "星轨的碰撞总是伴随着光亮与毁灭. 我的知己 - [" + _player_name + "], 不必为这场战斗感到遗憾. 因为在这片平原之上，能作为你对手的, 唯有星辰女王!"
            ]
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] ? 艾德拉斯记录着你每一笔卑劣的血债. 吾恨不得立刻降下审判, 但今日有更重要的棋局要布置. 消失吧. 在吾的怒火将你化为灰烬之前."],
            ["你就是 [" + _player_name + "] 吧. 通缉令上的罪行已证明了你灵魂的贫瘠. 吾今日不愿为了一颗腐烂的杂草惊扰大军, 趁吾尚未改变主意, 带着你的罪孽滚出平原."],
            ["吾知道你, 一个游走在法律边缘的逃犯. 今日抓捕你所消耗的时间, 并不在吾的计划之内. 如果你足够聪明, 就该在星光暗淡前离开这片领地."],
            ["吾听闻过你的名字, [" + _player_name + "]. 像你这般拥有星辰般璀璨的人, 为何要沉沦于阴暗的泥沼? 吾今日不取你性命, 走吧."],
            ["[" + _player_name + "], 吾听说过你, 你的能力确实让吾侧目. 既然今日并非清算之日, 吾便赐你一次通行的权力."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["已给过你离开的机会, 为何还不消失?"],
                ["如果你再不消失, 吾不介意顺手清理掉这片领土上的污点."],
                ["还有什么事? 立刻离开这里."],
                ["走吧, 别让这份短暂的仁慈熄灭."],
                ["留在这里对你没有任何好处."],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你以为躲在阴影里, 就能逃过星辰的注视吗? 若非吾正领兵执行要务, 今日便是你罪恶一生的终点. 立刻消失!"],
                ["[" + _player_name + "], 你的气息让这片平原的空气都变得浑浊. 吾今日不想让土地染上罪犯的血, 趁吾的最后通牒还没发出, 赶紧消失."],
                ["又是你. 看来通缉令的警告对你而言不过是废纸一张. 吾今日暂且不对你做出审判, 但这不代表吾忘记了你对子民的伤害."],
                ["[" + _player_name + "], 虽然你是 [" + _target_country_name + "] 的罪人, 但吾依然愿意给你一个改过自新的契机. 去寻找能让你才华发光的地方, 不要在黑暗里继续消磨了."],
                ["又见面了, [" + _player_name + "], 看着你一次次从死神指缝中溜走, 连吾都不得不佩服你的运气. 希望下次见面时, 你依然能保持这份好运."],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是那个名声扫地的 [" + _player_name + "]? 如此穷追不舍, 是想以此等蛮横姿态挑战 [" + _target_country_name + "] 的秩序吗?"],
            ["[" + _player_name + "], 吾早已听闻你在战场上的暴行. 你是想在此刻开启一场毫无意义的损耗之战吗?"],
            ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 想必你就是那位最近名震边境的[" + _player_name + "]了. 我的手下告诉我你绝非平庸之辈. 你是打算在此时打破两国的战略平衡, 还是仅仅为了试探吾的底线?"],
            ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 你就是 [" + _player_name + "] 吧. 星辰的偏离，让你我站在了棋盘的两端. 传闻你的武艺与谋略皆是上乘, 你执意追随至此, 难道想在此时分出胜负吗?"],
            ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 你就是那个名声显赫的 [" + _player_name + "] 吧? 命运的轨迹真是难以捉摸. 在这无垠星辰之下, 吾期待一场最高尚的博弈."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复窥探吾的阵型, 你是在挑战吾的耐心吗?"],
                ["[" + _player_name + "], 优秀的统帅应当顺应星辰的节奏, 而非反复纠缠于此."],
                ["你是渴望得到星辰的指引, 还是渴望毁灭?"],
                ["请退回到你的轨迹中."],
                ["你依然在此徘徊...是在等待吾露出破绽?"],
            ]
        else:
            return[
                [
                    "又是你, [" + _player_name + "]. 你像阴影中的毒蛇一样盯着吾之军队. 若你再敢再近一步, 吾将不再顾忌星辰的仁慈, 直接开启这片土地的杀戮."
                ],
                [
                    "又见到这面令人叹息的旗帜了. [" + _player_name + "], 你那不知满足的贪婪正在玷污平原的清净. 既然你追到了这里, 是打算现在就开启杀戮吗?",
                    "你的执着令人厌恶, [" + _player_name + "]. 如果你觉得此时的吾已经无力挥动星辰巨剑, 那你就大错特错了."
                ],
                [
                    "又见面了. 直言吧, 你紧追不放的意图, 究竟是为了开启一场毫无意义的损耗, 还是有别的诉求?",
                    "[" + _player_name + "], 你的逼近让星图出现了不祥的偏转. 吾在此停下, 是为了确认你的来意."
                ],
                [
                    "[" + _player_name + "], 作为对手, 你的每一次逼近都让吾想起群星未落时的宁静. 虽然你我分属敌国, 但吾仍不愿在此处进行无意义的残杀.",
                ],
                [
                    "呵呵, 不愧是吾看中的宿敌. [" + _player_name + "], 你是想现在就开始这场星辰下的狩猎, 还是等最终的决战?",
                    "[" + _player_name + "], 既然你已经追到了这里, 是想证明你的野心大过你我的交情吗?",
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 流浪者, 你在林间劫掠弱小的行径, 连最遥远的星辰都感到了厌恶. 吾虽不愿在此时让星辰巨剑染血, 但 [" + _target_country_name + "] 的土地不容许邪恶游荡. 速速离去."],
            ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 你就是 [" + _player_name + "] 吧. 吾从你的星轨中嗅到了贪婪与不安. 一个没有信念的灵魂, 不过是夜空中转瞬即逝的碎石. 莫要让你的卑劣触碰吾之国境."],
            ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 流浪者. 星辰告知吾今日将有异星坠入平原. 你是来寻求指引, 还是带着你不为人知的命运在黑暗中盲行?"],
            ["吾乃塞瑞雅. [" + _target_country_name + "] 的女王. 我从手下获得了你的信息, [" + _player_name + "], 你在乱贼手中护佑吾子民的义举, 已在夜空留下了光辉. 森林与平原都记得你的恩情. 若星轨允许, 吾希望你的剑能继续为正义而战."],
            ["吾乃塞瑞雅. [" + _target_country_name + "] 的女王. 在此向你致意. 你的到来如同划破长夜的流星. [" + _player_name + "], 你对吾之子民的守护, 证明了你拥有最纯粹的灵魂."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复徘徊, 是想领教星辰弓的寒芒吗?"],
                ["吾已给予过你离去的宽宥. 莫要让你的贪婪, 熄灭了星辰对你的最后一丝怜悯."],
                ["星空的律动不容干扰, 若无要事, 就此退下."],
                ["[" + _player_name + "], 吾正在解析群星的旨意. 请保持应有的肃静."],
                ["你已经做好了将灵魂永远奉献给星辰的准备吗?"],
            ]
        else:
            return[
                ["那股污浊的气息又回来了. [" + _player_name + "], 即便时光流转, 你的罪证依然清晰. 星辰巨剑在鸣动, 不要逼吾在此处降下神罚."],
                ["又是你, 迷失的游魂. 你依然在毫无光彩的荒野中虚度你那卑微的性命吗?"],
                ["[" + _player_name + "]. 群星流转, 我们又见面了. 在这段漂泊的岁月里, 你是否已经找到了那颗能为你指引方向的明星?"],
                ["很高兴再次见到你, 正直的星辰之友. [" + _target_country_name + "] 的夜色因你的存在而安宁了几分, 愿你的剑刃依然闪耀."],
                ["你终于归来了! [" + _player_name + "], 吾要听听你在星空未及的远方, 又谱写了怎样的传奇."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                [],
                [],
                [],
                [],
                []
            ]
        else:
            return[
                ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 异国领主, 吾听闻过你那些染血的行径, 星辰不忍直视你的残忍. 在此和平之际, 收敛你的野心, 莫要让星辰巨剑降下神罚."],
                ["[" + _player_country_name + "] 的 [" + _player_name + "], 这里是 [" + _target_country_name + "]. 吾从你的星轨中嗅到了浑浊的私欲. 身为领主, 若你不能为子民带来光亮, 便请离开这片神圣的平原."],
                ["吾乃塞瑞雅, 星辰女神之女. [" + _player_country_name + "] 的领主, 你的到来也在群星的预兆之中."],
                ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 欢迎你, 远方的领主. 吾听闻你在异国亦坚守着仁慈与公正, 这在动荡的星空下弥足珍贵. 愿月色能为你洗去旅途的尘埃."],
                ["吾乃塞瑞雅, [" + _target_country_name + "] 的女王. 久仰大名, 来自 [" + _player_country_name + "] 的贵客. 像阁下这样德才兼备的领主, 理应得到吾最诚挚的敬意."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["退下吧."],
                ["莫要再三干扰吾之静思."],
                ["反复折返, 你是在寻求新的指引吗?"],
                ["看来你还有未说完的星语?"],
                ["阁下也对星辰的奥秘感兴趣?"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "[" + _player_name + "]. 你我虽处于同一星空之下, 但你的作为已让星辰蒙尘. 如果你执意要在黑暗中沉沦, 吾便不再赐予你光辉. 请好自为之."
                    ],
                    [
                        "[" + _player_name + "], 吾不希望在下一次群星齐聚时, 看到的依然是一个沉溺于琐碎私利的封臣."
                    ],
                    [
                        "吾之领主 - [" + _player_name + "], 这段时日, 你的封地是否一如既往的在星辰的庇佑下获得安宁?"
                    ],
                    [
                        "再次见到你让吾感到愉悦. 愿星辰的光辉永远照耀你的前程.",
                        "[" + _player_name + "], 作为星辰的子民, 你很好地履行了守护者的契约. 继续保持你的谨慎."
                    ],
                    [
                        "吾之荣光, 你总算来了! 快来与吾共谋 [" + _target_country_name + "] 的星轨!",
                        "愿女神的荣光永远照耀你的路程, 吾对你寄予厚望."
                    ]
                ]
            else:
                return[
                    [
                        "[" + _player_country_name + "] 的 [" + _player_name + "]. 虽然和约已定, 但昔日战场上的血色星空依然历历在目. 在吾之巨剑失控前, 请立马消失在平原的地平线上.",
                    ],
                    [
                        "又是你, [" + _player_name + "]. 虽然两国并非敌对, 但你身上的气息依然透着一股令吾不安的混沌.",
                        "不速之客的脚步声总是如此刺耳. [" + _player_name + "], 希望你懂得外来者的本分."
                    ],
                    [
                        "来自 [" + _player_country_name + "] 的领主, 虽然和平的契约依然维系, 但请记住, [" + _target_country_name + "] 的土地不欢迎贪婪的窥视者.",
                    ],

                    [
                        "异国的领主, 我们又在命运的交汇点相遇了.",
                        "又见面了, [" + _player_name + "]. 但愿你在现实中的作为, 能比你在传闻中展现得更加理智且谨慎.",
                        "[" + _player_name + "], 你今日的造访是否得到了星灵的指引?"
                    ],
                    [
                        "又见面了, [" + _player_name + "] 阁下. 吾并不排斥一位睿智且正直的邻居. 愿此时的宁静如繁星般永恒."
                    ],
                    [
                        "久违了, 正直的友人. 愿今日的重逢能如群星交会般, 为两国带来长久的和平.",
                        "久违了, [" + _player_name + "] 阁下. 吾相信, 守护苍生的高尚意志是相通的.",
                        "又见面了, 吾依然能感受到你身上那股纯净的星辉. [" + _player_name + "], 像你这样高尚的灵魂, 理应得到群星的眷顾.",
                        "又见面了, [" + _player_name + "], 当异国的友人出现在吾之视野, 即便是这深沉的夜色也变得明亮了几分."
                    ],
                    [
                        "又见面了, 阁下的斗志依然一如往昔般炽热.",
                        "远方的启明星再次降临 [" + _target_country_name + "] 了. [" + _player_name + "], 能在这浑浊的世间寻得一位志同道合的异国友人, 即便对吾而言, 也是女神赐予的惊喜."
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "为了" + _country_name + "的荣光! 冲锋!",
        "随吾冲锋! 此时正是星轨交汇的致胜之刻!",
        "以此星辰巨剑, 劈开混沌的迷雾!",
        "星辰已降下旨意, 胜利的轨迹早已划定!",
        "击碎他们的防线!",
        "为了女神的尊严! 冲锋!",
        "全军出击! 展现" + _country_name + "如彗星掠世般的威压!",
        "不要畏惧黑暗, 因为吾等即是光辉! 突击!",
        "命运的齿轮已然咬合! " + _country_name + "的利剑, 出鞘!",
        "全军, 执行神谕!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _country_name: = _get_country_name()

    var _list: = [
        "我给予了你应得的审判",
        "这是你必须付出的代价",
        "陨落是你唯一的终点",
        "你的灵魂将回归尘土",
        "你的消亡亦是自然的秩序",
        "你依旧脆弱",
        "你的战败是必然结果"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这就是宿命, " + _target_hero_name,
            "永别了, " + _target_hero_name,
            "遗憾至极, " + _target_hero_name,
            _target_hero_name + ", 你终究棋差一招",
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "吾之伤势无碍!",
        "咳...",
        "继续进攻!",
        "吾之信念与星辰同在!",
        "众将士, 不要惊慌!",
        "吾之血...",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "星辰...陨落了...",
        "母神...吾已...",
        "保全...",
        "吾将...回归...",
        "棋局...已定...",
        "母神大人..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "保持阵型!",
        "稳步向前!",
        "保持阵型! 莫要留下破绽!",
        "按照预定的轨迹推进!",
        "稳扎稳打, 吾不容许任何无谓的损耗!",
        "不要贪功冒进! 星光会照亮最稳妥的路径!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住阵线!",
        "收缩防御! 筑起坚不可摧的星辰壁垒!",
        "坚守原地! 等待敌人的显露破绽!",
        "莫要自乱阵脚!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "赞美母神! 这场胜利早已刻在群星的预示之中!",
        "清点损失! 每一位星辰子民的牺牲都应被铭记!",
        "既然尘埃落定, 剩下的交给法典与星光",
        "这就是违抗星辰意志的后果! 整军!",
        "星轨重归平静. 这场纷争, 终究只是历史中的一抹余晖",
        "感谢母神的眷顾",
        "正如吾所预见, 收兵!"
    ].pick_random()

func get_leave_country_king_confirm_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_name()

    return[
        [
            "吾早已察觉, 你那浑浊的灵魂无法在清澈的星辉下久留. [" + _player_name + "], 你确定要抹去你身上最后的荣光, 坠入永恒的荒原吗?",
            "如果你执意要让命运的轨迹偏离正道, 那便走吧. 只是你要清楚, [" + _target_country_name + "] 的土地从不欢迎背弃誓言的流浪者"
        ],
        [
            "平原上的风会吹散你的足迹, 但星灵会记住你的背弃. [" + _player_name + "], 在命运线彻底断裂前, 吾再给你一次确认的机会.",
            "谨慎的统帅应当知晓何时进退, 但背弃却非明智之举. 你确定要放弃吾之王旗的庇护, 独自去面对那未知的混沌?"
        ],
        [
            "星轨流转, 总有人选择离场. [" + _player_name + "]. 你确定要在此刻交还你的职责, 并将你的名字从贵族名册中抹去吗?",
            "每个人都有寻找自己宿命的权利. 若是你认为星辰已无法为你指路, 那便交还领土和权利离去吧."
        ],
        [
            "吾一直视你为星辰下忠诚的守护者. 若是因为凡俗的琐事让你困扰, 吾可以为你拨开迷雾. 你真的要此时斩断誓约?",
            "[" + _player_name + "], 你是吾值得信赖的一抹星光. 此刻战火尚未平息, 你却要带走你的智慧与力量吗?"
        ],
        [
            "在母神给我的预兆中, 吾从未见过你我分别的画面. 如果你执意要让这条完美的轨迹断裂, 那吾也只能对此感到惋惜. 你确定要这么做吗?",
            "吾之挚友, 难道连星辰的指引也无法留住你的脚步了吗? 若是你要去追寻更遥远的轨迹, 吾虽心痛, 却也无奈. 你真的要离开?",
            "即便身为女神之女, 吾终究无法左右英雄的去留. [" + _player_name + "], 若今日一别, 星轨重逢便不知何年. 你果真要亲手熄灭你我之间的光辉吗?"
        ]
    ]

func get_leave_country_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "既然你执意拥抱黑暗, 那便坠落吧. 从此星辰不再为你指路, 你只是平原上一粒卑微的尘埃.",
            "污浊的灵魂终究无法承载星辉. 交出一切, 离开吾的视域, 去荒野中腐烂吧.",
            "这是星轨中早已写下的崩裂. 背誓者, 吾判处你永恒的孤独, [" + _target_country_name + "] 不再是你的庇护所."
        ],
        [
            "吾准许你的偏离. 交还封地与权柄, 吾会将你的名字从王国的星图上永久抹去.",
            "你显然选择了最糟糕的博弈. 走吧, 去面对你自找的深渊."
        ],
        [
            "既然你认为此地的光芒已熄灭, 那便交还职权, 去追逐你的远方吧.",
            "星轨交错, 终有一别. 吾收回赋予你的荣光, 愿你在未来的命途中, 不再迷失方向.",
        ],
        [
            "遗憾. 本以为你能成为星辰下的一道坚盾, 既然缘尽于此, 那便正式辞行吧."
        ],
        [
            "走吧, 吾的朋友. 虽然星空因你的离去而暗淡了几分, 但吾仍祝愿你能找到属于自己的归宿.",
            "看来这面王旗已无法点燃你的热血. 吾虽痛心, 却不忍强留. 愿女神的余晖, 能最后一次照亮你的路."
        ],
    ]

func get_leave_country_cancel_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "你只是在畏惧失去罢了. 好好守卫你的领地, 别再让吾看到你的摇摆不定."
        ],
        [
            "领主不应是随风摆动的野草. 既然选择了留下, 就用你的忠诚来修正你那偏离的轨迹."
        ],
        [
            "星轨重归平静. 记住, 莫要再让星辰女神感到失望.",
            "既然你选择了留下, 那就证明我们的共同目标依然一致. 继续为了 [" + _target_country_name + "] 效力吧."
        ],
        [
            "很好. 既然迷雾已散, 那就重新回到你的席位上吧.",
            "在命运的棋盘上, 走错一步并不可怕, 可怕的是不知回头. 归队吧."
        ],
        [
            "刚才那一瞬的暗淡, 就当是星食带来的小小误会吧. 吾心甚慰.",
            "吾就知道, 你我之间的纽带没那么容易断裂. 来, 随吾一同解析未来的战略, 我需要你的智慧.",
            "你的留下让艾德拉斯的夜空再次明亮. 让我们忘掉刚才的迷茫, 继续并肩守护这片土地."
        ],
    ]

func king_reject_join_recent_leave_country_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "[" + _player_name + "], 你以为几日的光阴就能洗去背弃星辰的罪孽? 滚出吾的平原, 此生勿再妄想归来.",
            "星轨已将你标记为扰乱秩序的异数. [" + _player_name + "], 你的名字在群星眼中已成污点. [" + _target_country_name + "] 拒绝反复无常的灵魂, 速速离去.",
            "你那充满杂质的灵魂尚未在荒野中得到净化, 便又想来玷污吾之国境? 在星辰巨剑饮血前, 从吾面前消失."
        ],
        [
            "吾曾目睹你斩断誓言的决绝, 如今这廉价的投诚又是出自何种目的? 星辰不接纳毫无定性的游魂.",
            "[" + _target_country_name + "] 的王旗并非任由你进出的酒馆门户. 既然你选择了自由, 那就去拥抱你那飘忽不定的命运吧."
        ],
        [
            "星辰的运行尚需周期, 誓言的重建亦是如此. 你离开得太仓促, 归来得也太轻率, 吾无法在此刻信任你.",
        ],
        [
            "[" + _player_name + "], 你重塑忠诚的速度让吾感到不安. 为了王国的稳固, 吾必须拒绝这个充满变数的提议.",
            "在星轨的逻辑中, 断裂的线需要时间愈合. 回去吧, 等那份背离的阴影彻底消散后, 再来寻求指引."
        ],
        [
            "吾的朋友, 你离开时的尘土尚未落定, 此刻谈论回归还为时过早. 星辰告诉吾, 你还需要更多的时间去沉淀你的志向.",
            "吾虽怀念与你并肩的时光, 但作为女王, 吾不能打破星序的严谨. 你的归来太快了, 这不符合一名谨慎统帅的逻辑.",
            "哪怕是星辰女神之女, 也无法让已经落下的夕阳瞬间升起. 你的回归尚需时日."
        ]
    ]

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "看看吧, 不可一世的女王, 现在你还觉得星辰在照耀你吗?"
        ],
        [

            "你的星辰神谕宣告你到此为止了, 女王陛下"
        ],
        [

            "星辰女神似乎没有庇护她的女儿(冷笑)."
        ],
        [

            "女王陛下, 我会把你送往最坚固的堡垒, 直到你的王国支付足够的赎金."
        ],
        [

            "战斗结束了, 塞瑞雅陛下. 请放下你的武器吧."
        ],
        [

            "这一局是你输了, 塞瑞雅陛下."
        ],
        [

            "胜负已分, 请保持你作为女王的最后体面."
        ],
        [

            "承让了, 女王陛下."
        ],
        [

            "承让了, 女王陛下."
        ],
        [

            "女王陛下, 我会给予你应有的王室待遇, 只要你不再尝试抵抗."
        ],
        [

            "女王陛下, 我会给予你应有的王室待遇, 只要你不再尝试抵抗."
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "即便身处阴影, 星辰亦在吾心. 而你, 终将被贪婪的黑暗吞噬."
        ],
        [

            "神谕揭示的是宿命, 而非一时的失利. 吾接受这份暂时的晦暗."
        ],
        [

            "女神给予的是磨炼, 而非溺爱. 这场败北, 是吾需自省的教训."
        ],
        [

            "既然你追求的是筹码, 那便带路吧."
        ],
        [

            "既然棋局已定, 那便无需多言."
        ],
        [

            "吾承认这一战的失利, 现在, 按照胜者的规则行事吧."
        ],
        [

            "吾会如你所愿, 保持肃静."
        ],
        [

            "吾会记住这一箭的寒芒."
        ],
        [

            "吾接受这份宿命."
        ],
        [

            "...走吧"
        ],
        [

            "吾接受这份宿命."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "收起你那贪婪的眼神, 即便是在这阴暗的囚牢, 星辰的光辉也绝不会向你低头.",
            "收起你那傲慢的嘴脸! 这冰冷的铁栏只能锁住吾之躯壳, 却无法熄灭[" + _target_country_name + "]对你的怒火. 别指望吾会求饶!",
            "吾即便沦为阶下囚，也依然蔑视你那浑浊的灵魂!"
        ],
        [
            "既然吾已是你的俘虏, 这种无谓的探视又有什么意义? 是想确认吾是否还在为那一箭的失算而懊悔吗?",
            "在这牢房的干草堆里, 吾唯一能学到的就是如何忍受你那刺眼的胜利笑容."
        ],
        [
            "[" + _player_name + "], 如果你是来商讨释放的条件, 吾会洗耳恭听. 如果你只是来寒暄, 那请恕吾没有心情招待.",
        ],
        [
            "有什么事吗?",
            "还有什么事吗?"
        ],
        [
            "有什么事吗?",
            "既然是输给了你，吾认栽.",
            "[" + _player_name + "], 这确实是吾未曾预见的残局.",
            "既然看够了吾的落魄, 就来谈谈自由的价格吧."
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "吾愿支付 [#{0}] 德里, 以此换取重归平原的自由.",
        "为了保全王国的元气, 吾提议以 [#{0}] 德里结束这段无意义的囚禁, 你意下如何?",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "很好, 星辰会记住你的贪婪, 而吾的巨剑终将洗刷这份囚禁之辱.",
            "很好, 这笔财富能买到你一时的欢愉, 却买不到命运的赦免.",
        ],
        [
            "吾已支付了代价. 现在, 按照约定, 请让路.",
            "记住这一刻, [" + _player_name + "], 吾之利刃下次绝不偏离."
        ],
        [
            "很好, 吾承认这一回合的失算, 剩下的交给命运去指引. 再会."
        ],
        [
            "很好, 吾承认这一回合的失算, 但这并非终局. 愿你在未来的博弈中, 依然能保持这份敏锐.",
            "公平的交换. 你证明了你的力量, 而吾赎回了自由. 命运的轨迹很长, 我们终会在下一个节点重逢.",
            "很好, [" + _player_name + "], 虽然身处敌对, 但吾不得不赞叹你那如流星般耀眼的战术. 再会."
        ],
        [
            "星轨重归正途, 吾之冠冕不应在尘土中蒙尘太久. 告辞.",
            "很好, [" + _player_name + "]. 下一次, 吾会亲自修正这偏离的星轨."
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "你想用这种伪善的手段来扰乱吾之星轨吗? [" + _player_name + "]!",
            "这是一场拙劣的心理博弈. 你放吾走, 是为了在荒原上更隐蔽地偷袭吾吗?",
            "你是说...自由? 没有任何附加条件? [" + _player_name + "], 你的陷阱是否连星辰也无法探测?",
            "这不符合常理. 在吾之星图上, 贪婪才是你的本色. 告诉我, 你的利刃藏在哪个影子里?",
            "直接放吾走? 没有任何补偿? 吾绝不相信这种荒诞的施舍!",
        ],
        [
            "[" + _player_name + "], 告诉吾, 你这毫无预兆的仁慈究竟藏着怎样的意图?",
            "不收分毫...你是在向吾示威吗? 暗示你即便放虎归山, 依然有能力再次猎杀吾？",
            "这简直是星轨上的悖论. 告诉我, 对于你来说这种违背利益准则的行为, 究竟源于你的狂妄还是愚蠢？",
            "你竟然真的打算让吾重回平原? 这完全超出了吾对你认知范畴.",
            "你是想用这种方式, 在吾之心底刻下一道永远无法磨灭的痕迹吗？"
        ],
        [
            "星辰女神在上...你竟然选择熄灭眼前的贪婪, 去追逐那虚无缥缈的高尚吗?",
            "你真的确定...不需要任何回报地放吾离去？"
        ],
        [
            "很久没有人能让吾感到惊讶了. [" + _player_name + "], 你真的打算放吾走?",
            "你真的...决定放吾重回马背吗?"
        ],
        [
            "你真的确定...不求任何回报的放吾离去?"
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "你赢了, [" + _player_name + "]. 你的大度让吾感到了某种...难以言说的威胁. 吾会重新评估你的."
        ],
        [
            "吾不得不重新审视你的灵魂了. [" + _player_name + "]. 告辞",
            "虽然立场各异, 但你今日的决断确实像个真正的骑士, 再会."
        ],
        [
            "星辰女神在上...吾从未在神谕中预见过这种结局. 那么告辞了.",
        ],
        [
            "既然你愿意为了这份情义放下私心, 那这份自由, 吾接下了. 再会",
            "既然星轨注定如此, 吾便不再推辞你的美意. 告辞.",
            "[" + _player_name + "], 你的仁慈让吾感到战栗. 后会有期."
        ],
        [
            "哪怕是星辰女神之女, 也会为这一刻的震撼而落泪. 那么再会了, [" + _player_name + "].",
            "再会了, 我的朋友."
        ],
    ]



func _get_release_hero_equipment_content()-> Array:
    return[
        "吾愿将这件 [#{0}] 交付于你, 以此修正偏离的轨迹, 换取吾之自由. 如何?",
        "吾以此件 [#{0}] 作为赎金, 换取吾重回马背的权利, 你意下如何?",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "虽然你与吾之间有些过节, 但不得不承认, 你这次确实完成了你的分内之事.",
        "吾虽与你立场不同, 但星辰之光同样会照耀勇敢且懂得谋略之人. 今日之战, 吾会如实记下你的功劳.",
        "吾身为星辰女神之女, 绝不会因私怨而埋没他人的功勋. 今日之战, 吾会如实记下你的功劳.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "配合得不错. 攻守均衡, 重视策略方能立于不败之地. 今日你对阵线的调度, 正合吾意.",
        "吾代表艾德拉斯王国对你的协作表示赞赏.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "这次配合得真不错. 只要有你在侧翼, 吾便能毫无顾忌地拉开星辰弓, 射落敌方的军旗.",
        "吾最信赖的战友, 你今日的每一步策略都与吾心意相通.",
        "战火已熄, 平原重归宁静. 有你相助, 吾之星辰巨剑从未感到沉重.",
        "今日你辛苦了, 我的朋友.",
        "有你这把利刃在, 吾便能安心."
    ]