extends LordNobleDialogue

const HERO_UID: = "lord_hero_0004"







func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "接纳一位劣迹斑斑的封臣是王国的风险, 而我拒绝为你的忠诚背书. 离开我的营区, 在我改变主意把你当成间谍逮捕之前.",
            "你想向 [" + _king_name + "] 效忠? 荒谬! [" + _country_name + "] 的平原不需要你这种居心叵测的投机者. 滚出我的视线."
        ]
    elif _rel_value <= -10:
        return[
            "你的底细尚不明确, 我建议你先去觐见 [" + _king_name + "], 接受审查. 在那之前, 别靠近我的阵线."
        ]
    elif _rel_value <= 10:
        return[
            "接纳一位封臣关乎王国的安危, 不可草率. 去觐见睿智的 [" + _king_name + "] 吧, 只有他/她的智慧能看清你真正的意图."
        ]
    elif _rel_value < 30:
        return[
            "我观察过你的战法, 你懂得如何保全你的部下, 这在战场上难能可贵. 去找 [" + _king_name + "] 谈谈吧, 我期待与一位理智的领主并肩作战."
        ]
    else:

        return[
            "既然你已决定投效, 那这面海曜之盾将永远为你留出侧翼. 快去见见 [" + _king_name + "], 我们的国土需要你这样稳固的守护者.",
            "这是我近期听到的最好的消息. 你的加入将极大降低王国的战损风险. 去觐见 [" + _king_name + "] 吧, 我的朋友, 让我们共同构筑这片平原上最坚不可摧的防线."
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "你出现在这里不符合我的计划. 局势从未失控, 下次请不要干扰军令."
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的介入是意料之外. 无论如何, 我们完成了任务, 你可以离开了.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "虽然胜利了, 但我并没在最前线看到你的身影. 下次请务必跟紧我的旗帜.",
        "看到你平安无事, 我确实松了口气."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "这份恩情我不会遗忘, 但你的不当行为依然在案.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你的贡献超出了我的预期. 这次危局得以化解, 你功不可没.",
        "你精准的判断力避免了我更大的损失. 这证明了你的能力. 我欠你一份人情.",
        "局势一度危险, 你的出现扭转了战局. 感谢你为王国带来的稳定."
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你的英勇为王国避免了灾难性的损失. 你的忠诚和力量, 值得我们信任."
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "乔安娜大人恪守荣誉, 不屑于欺凌弱小, 但这不代表我们会容忍挑衅. 这是最后的警告: 退后, 否则盾墙之后便是深渊."
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "既然你的主子喜欢防守, 那就缩在你们的盾牌后面等死吧! 全军突击!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "(尴尬地笑笑，拍拍额头) 嗝~ 我想我是产生了幻觉, 竟然对如此正直的乔安娜大人拔了剑. 这该死的烈酒! 我这就带我的人离开, 绝不打扰各位."
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["离我远点, 臭名昭著的流浪者. 你的存在本身就是对 [" + _target_country_name + "] 的侮辱. 敢拔剑, 我就让卫兵把你吊死在城门上."],
        ["你要挑战我? 想清楚, 这不只是武力的较量. 一旦见红, 我的亲卫队会像钢铁一样锁死你所有的生路. 你准备好了吗?"],
        ["流浪者, 我手中的盾不仅是为了抵御外敌, 更是为了守护 [" + _target_country_name + "] 的法度. 如果你执意要跨过这条红线, 我将不得不为了荣誉而战. 你真的准备好承担拔剑的后果了吗?"],
        ["这种冲动并不像你. 别让一时的狂热毁了你积累的名誉. 把剑收回去吧."],
        ["朋友, 我曾亲手指导你如何握剑, 不是为了让你指向我. 这一步跨出, 你就再也不是英雄. 你真要这么做?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["虽然我厌恶你, 但我必须提醒你: 这一剑下去，你的野心将葬送在 [" + _target_country_name + "] 的坚盾之下. 你确定要开启这无尽的战火?"],
        ["收起你那卑鄙的试探, 你不仅没有荣誉, 更没有脑子. 这一剑下去, 两国将重燃战火. 你真打算当这个背誓者?"],
        ["你代表的是你的子民. 你确定要让你的子民为你瞬间的轻率而陪葬吗?"],
        ["两国的和平不该毁在私愤上. 如果你动手, 我就不得不摧毁你的防线. 别让理智输给愤怒."],
        ["我视你为最坚固的盟友, 你却要在我的阵前背弃契约? 别逼我执行毁灭你的职责."],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["既然你毫无廉耻地选择了堕落, 那就由我亲手终结你的狂妄. 为了 [" + _target_country_name + "], 受死吧!"],
        ["全军列阵, 收缩阵型, 肃清这个滋事者!"],
        ["这就是你的选择. 我会用最迅速的方式结束你的痛苦. 准备战斗!"],
        ["遗憾...既然言语无法让你回头, 那就只能用利刃让你清醒."],
        ["你亲手杀了那个值得我信任的朋友. 现在, 你只是我必须清理的障碍!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["这正是你自取灭亡的开始! 既然你执意点燃战火, 我将代表 [" + _target_country_name + "] 粉碎你的野心, 让你的名字成为永远的耻辱!"],
        ["你不仅背弃了盟约, 更羞辱了军人的荣誉! 我会让你明白什么叫女王之盾的怒火!"],
        ["既然和平无法约束你的野心, 那就让绝对的武力来重塑秩序. 你是第一个祭品."],
        ["我高估了你的沉稳. 既然你执意毁掉这平衡, 那就准备好付出代价吧."],
        ["你背叛了军人的誓言! 从这一刻起, 我将履行我作为\"女王之盾\"的职责 - 彻底铲除你."],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "既然你自己送上门来, 那就省去我找你的力气. 我会踏碎你的防线, 把你那肮脏的旗帜踩进血泥里. 全军突击!"
        ],
        [
            "既然你急着找死, 那我就在这片平原上彻底终结你的狂妄.",
            "[" + _player_name + "], 既然你已经亮出兵器, 那就手底下见真章吧!",
            "[" + _player_name + "], 既然你已经越过了边界, 那就准备好迎接海曜战斧的洗礼!",
            "[" + _player_name + "], 让我看看你的本事是否配得上你的野心."
        ],
        [
            "战场无情. 既然你选择了正面对垒, 那就看看你的刀锋是否能劈开 [" + _target_country_name + "] 的盾墙",
            "[" + _player_name + "], 既然你执意要挑战这道防线, 那我也只能尽我守卫者的职责. 我会让你明白, 进攻 [" + _target_country_name + "] 是你这一生中最大的错误."
        ],
        [
            "作为对手, 你的勇气的确令我敬佩. 拔剑吧, 这是对战士最后的礼遇.",
            "只要我还有一口气，我的盾就不会后退半步!"
        ],
        [
            "这是最不幸的重逢, 我的朋友. 既然我们各自背负着国家的命运, 那就抛开私人交情, 在鲜血中完成这最后的告别吧!",
            "[" + _player_name + "], 这就是我们最后的相处方式了. 不必留情, 我也不会退缩. 战吧, 为了你我各自的荣耀."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["在女王之盾面前拔剑, 确实不是个好主意."],
        ["在这种地方丢了性命确实毫无荣誉可言, 告辞."],
        ["我还没打算挑战你那支\"钢铁亲卫队\"."],
        ["我还没沦落到要靠这种袭击来证明自己, 告辞."],
        ["你说得对, 我不该把剑指向我的老友."],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["那张和平协议...就让它继续在桌上待着吧."],
        ["我还没疯狂到要背负万千性命去当一个背誓者. 这次是我失礼了."],
        ["为了这一瞬间的意气让子民陪葬, 确实不是一个合格领主该有的举动. 我收手."],
        ["你说得对, 两国的和平不该毁在个人的私愤上. 我还没打算让理智输给愤怒."],
        ["你那句\"最坚固的盟友\"让我感到汗颜, 这次是我失礼了"],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 你的罪行已经无可饶恕. 为了 [" + _target_country_name + "] 的安宁, 我必须在此将你拦截并肃清."],
            ["你就是 [" + _player_name + "] 吧. 我不希望发生流血冲突, 但既然你被通缉且拒不悔改, 那就别怪我的盾牌无情了."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 既然通缉令已下, 请配合我的卫队, 不要尝试做无谓的反抗."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 我听说你曾对百姓施以援手, 这让我很为难. 跟我回去吧, 我会向女王说明情况."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 虽然我对你的为人深感敬佩, 但作为女王之盾, 我不能放任一个通缉犯离去. 请别让我为难."],
        ]
    else:
        return[
            ["[" + _player_name + "], 你再一次踏入了我的防线. 这一次, 我不会再让你有任何生还的机会."],
            ["[" + _player_name + "], 束手就擒是你唯一的出路."],
            ["[" + _player_name + "], 我的职责依然是抓捕你, 这个结果不会改变."],
            ["站住, [" + _player_name + "], 你应该明白, 职责所在, 哪怕我再欣赏你, 这面盾牌也不会因为是你而放下."],
            ["好久不见, 老友. 虽然我很想和你叙旧, 但在此之前, 我必须先履行捕获你的职责. 来吧, 让我们速战速决."],
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 我听闻你在边境那些毫无底线的劫掠, 像你这样满身血债的人竟也能被封为贵族, 既然踏入这里, 就准备接受正义的制裁."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 你也知道, 两国正在开战. 但我更看不起你那些卑鄙的行径. 既然你身为领主却不懂得自重, 我便在此教你什么叫规矩."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 听说你效忠了 [" + _player_country_name + "]. 既然立场不同, 我身为女王之盾, 不能放任敌军领主通过这片平原. 请拔剑."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧. 我听闻你在你的领地极受爱戴, 这本该让我心生敬意. 可惜战事已起, 职责所在, 我不得不阻止你前进."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "] 吧! 我久仰你的统帅之名, 能与你这样高尚的对手切磋, 是我作为领主的荣幸. 请赐教!"],
        ]
    else:
        return[
            [
                "[" + _player_name + "], 你那张恶心的旗帜再次出现了! 这一次, 女王之盾将不再有仁慈!",
                "不必再逃了, [" + _player_name + "]. 我在此起誓, 今日你绝无可能跨过我的防线一步!"
            ],
            [
                "又见面了, [" + _player_name + "]. 既然你执意要在我的防线上寻找战争, 那就准备好承受失败的后果.",
                "[" + _player_name + "], 在这片平原上，没有任何死角可以躲过我的搜捕, 准备好在海曜之盾前支离破碎吧！"
            ],
            [
                "[" + _player_name + "], 战火未熄, 你我终究要在阵前相遇. 既然你再次领兵前来, 我也只能履行守卫边疆的誓言. 动手吧.",
                "[" + _player_name + "], 别再做徒劳的挣扎了. 在我的战斧落下之前, 你已经没有退路可言."
            ],
            [
                "我的朋友 [" + _player_name + "], 看到你我在这战场上兵戎相见, 真是一种莫大的悲哀. 但在此刻, 我绝不会放行.",
                "[" + _player_name + "], 战局的推演注定了你我必有一战. 既然你再次出现在我的包围圈内, 我只能以武力来终结这场博弈.",
                "拦截你并非出于私怨, 而是职责所在. [" + _player_name + "], 既然你代表你的国家跨过了这条红线, 那就用你的实力来证明是否有资格与我一战."
            ],
            [
                "呵呵, [" + _player_name + "]. 我就知道这平原上的骚动定是因你而起. 能再次与你对阵, 是这场枯燥战争中唯一的慰藉. 来吧, 老对手, 让我们全力以赴!",
                "[" + _player_name + "], 我的朋友. 我别无选择. 这身铠甲赋予了我的职责, 拔剑吧, 请给予我应有的尊重.",
                "看到你的身影, 我感到既欣慰又沉重. [" + _player_name + "]. 今天, 你我是敌手. 我会拿出最坚固的阵型来迎接你, 这是我能给你的最高敬意."
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 通缉令上详细记载了你对平民的暴行. 作为领主, 我恨不得现在就将你明正典刑. 但此刻我有更重要的守卫任务. 在我的耐心耗尽前, 消失!"],
            ["你就是那个流窜的犯人 [" + _player_name + "]? 我今日不愿为了一场毫无战略意义的私斗损耗兵力. 滚出我的视线, 立刻!"],
            ["你就是 [" + _player_name + "]? 我已经接到了关于你的通缉通报. 但目前保全本队的战力是第一优先级. 只要你不干扰我的行军路径, 我可以暂时无视你的存在. 尽快离开."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 我听过关于你的情报. [" + _player_name + "]. 你有极其出色的身手. 我今日不想在计划之外执行追捕. 走吧, 去换个活法."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你就是 [" + _player_name + "]? 你确实如传闻中一样胆大包天. 今日我有要务在身, 就先寄存下你的人头. 希望下次见面, 是在一个能让你死得更有尊严的战场上."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["我的话已经说得很清楚了, 立刻撤离. 不要挑战我的纪律."],
                ["你的反复出现正在增加我军的警戒负担. 这是最后通牒: 滚开!"],
                ["还有什么事? 我没有多余的精力浪费在一名通缉犯身上."],
                ["走吧. 趁我现在还能压制住对你的敌意."],
                ["珍惜你那来之不易的自由, 别再回来了."],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你以为我的克制是对罪恶的妥协吗? 若非此刻军务在身, 我现在就会让你为你之前伤害的子民付出代价. 消失!"],
                ["[" + _player_name + "], 你这种如影随形的纠缠已经触及了我的警戒红线. 我今日不想让部下的刀剑沾上恶徒的血, 滚远点!"],
                ["又是你, 看来你还没学会如何规避风险. 今日不会对你出手. 但如果你再进一步, 后果自负."],
                ["[" + _player_name + "], 虽然你依旧身负罪名, 但我依然希望你能把这份执着感用在正途. 赶紧离开吧, 这里不适合你."],
                ["又见面了, [" + _player_name + "]. 保住你的命, 在未来的某次战斗中, 我会亲自去取."],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["我说是谁在后方衔尾相随, 原来是那个投靠了 [" + _player_country_name + "] 的劣迹斑斑的领主 - [" + _player_name + "]. 你不仅背弃了道义, 如今还想挑战 [" + _target_country_name + "] 的钢铁壁垒吗? 尽管攻过来, 我必将你钉死在阵前."],
            ["你就是 [" + _player_name + "] 吧, 吾不记得 [" + _target_country_name + "] 曾邀请过像你这样无礼的客人. 你紧咬不放的行径让吾感到厌烦. 想开战就拿出统帅的决断."],
            ["想必你就是最近声名鹊起的 [" + _player_name + "] 了. 你带兵截断我的行军之路, 是经过计算的博弈, 还是一场鲁莽的投机?"],
            ["竟然在此处与你相遇, [" + _player_name + "]. 我听闻你在 [" + _player_country_name + "] 战功卓著, 既然你执意追随至此, 想必已经看穿了我的阵型破绽并打算发起强攻?"],
            ["你就是那个如雷贯耳的 [" + _player_name + "] 吧? 原本这枯燥的行军已让我昏昏欲睡, 但你的到来让海曜战斧都在鸣动."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复窥探我军侧翼, 是在寻找根本不存在的破绽吗?"],
                ["[" + _player_name + "], 我的将士已上弦待发, 莫要逼我下达进攻的将令."],
                ["这种危险的距离是对我耐心的挑衅, 退后!"],
                ["你我之间已无外交辞令可言, 若不进攻, 就请保持你身为贵族的体面."],
                ["如果你还没想好如何开战, 就别在那虚张声势."],
            ]
        else:
            return[
                [
                    "又是你. [" + _player_name + "], 你那充满污秽的眼神简直让这片土地都变得肮脏. 吾之阵型随时可以转守为攻, 你有胆量在此时发起决死冲锋吗?"
                ],
                [
                    "又见到这面旗帜了. [" + _player_name + "], 这种无休止的追逐战除了浪费吾之补给外毫无意义. 既然你执意拦路, 是打算让你的军队在 [" + _target_country_name + "] 的坚盾前撞碎吗?",
                    "[" + _player_name + "], 你像秃鹫一样紧追不舍, 是觉得现在的我有机可乘吗? 尽管上来试试, 看我的海曜之盾会不会被你撞碎!"
                ],
                [
                    "直言吧, [" + _player_country_name + "] 的领主, 你究竟是为了寻求决战, 还是仅仅想看看我的海曜之盾是否耀眼?",
                    "[" + _player_name + "]. 既然你已经拦截了我的部队, 那就直说吧, 你是想要一场两败俱伤的冲突吗?",
                    "追逐到此为止吧. 既然你的刀已经抵在了我的盾牌上, 那就给出你的条件. 你是想现在就分出胜负吗?"
                ],
                [
                    "又见面了, [" + _player_name + "]. 怎么, 是想在真正的决战开始前, 先来观察一下我的海曜战斧有没有生锈吗?"
                ],
                [
                    "[" + _player_name + "], 作为对手, 你的坚韧确实令吾钦佩. 但战场上的仁慈是有限度的. 你若再敢向前跨出一马之地, 吾即便违背私心, 也只能下令合围.",
                    "[" + _player_name + "], 我不想对老友挥动战斧, 但我也绝不会出卖我的职责. 你是想在这里跟我做个了断吗?"
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["我是乔安娜, [" + _target_country_name + "] 的领主. 你曾对弱小的平民举剑, 就该明白 [" + _target_country_name + "] 的法度不容践踏. [" + _player_name + "], 收起你那危险的企图, 我的海曜之盾绝不会对劫掠者前进半步!"],
            ["我是乔安娜. 我听闻过你在边境的那些小动作. 一个没有立场且唯利是图的人, 是 [" + _target_country_name + "] 的隐患. 在我下令驱逐之前, 请你保持安全的距离."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主, 请说明你的来意. 是寻求合法的雇佣, 还是仅仅路过此地? 我需要确保这片土地的绝对安全."],
            ["我是乔安娜, [" + _target_country_name + "] 的领主, 我听闻你在乱贼手中保护平民的行为, 证明了你是一个坚守道义的人. [" + _player_name + "], 我们需要像你这样正直的臂膀."],
            ["我是乔安娜! [" + _target_country_name + "] 的领主, 很高兴能结识你这样勇武且高尚的勇士. [" + _player_name + "], 你对我国子民的守护, 甚至超越了许多正规骑士."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复接近我的阵地, 你是想测试海曜战斧的锋利度?"],
                ["过度的纠缠会被视为敌对信号, 请立即退后."],
                ["若无紧急事务, 请不要干扰行军序列."],
                ["还有什么事吗?"],
                ["还在此地徘徊? 是有什么疑问吗?"],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "], 罪证是无法被时间抹除的, 只要你身上还带着劫掠者的气息, 我就会时刻准备清除祸害."],
                ["又是你. 希望这段时间里, 你学会了如何像个正直的人一样活着. 而不是像只游荡的豺狼."],
                ["[" + _player_name + "], 好久不见. 你的剑刃依然在为毫无方向的风而挥动吗? 还是说, 你已经找到了值得驻守的阵地?"],
                ["很高兴看到你平安无事, [" + _player_name + "]. 这片平原的安宁也有你的一份功劳, 希望我们依然是盟友."],
                ["好久不见, 我的好友 [" + _player_name + "], 平原上一直传颂着你的可靠. 快来和我分享这段时间你又在哪座防线上立下了功勋?"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["我是乔安娜. 虽然你我同在 [" + _target_king_name + "] 麾下, 但我听闻过你那些令人蒙羞的行为. 别指望我会把你当成同袍."],
                ["我是乔安娜, [" + _player_name + "], 我欢迎每一位效忠 [" + _target_country_name + "] 的同僚, 但前提是对方能恪守领主的本分. 希望你的到来不是为了制造麻烦."],
                ["我是乔安娜. 阁下就是最近声名鹊起的 [" + _player_name + "] 大人吗? 很高兴能与你共事."],
                ["我是乔安娜. 早有耳闻, [" + _target_country_name + "] 迎来了一位坚守骑士精神的勇士. [" + _player_name + "], 能与你这样的人并肩作战是我的荣幸."],
                ["我是乔安娜. 终于见到你了, [" + _player_name + "]. 你的英名甚至传到了我最前线的军营里."]
            ]
        else:
            return[
                ["我是乔安娜. [" + _player_country_name + "] 的领主, 我听闻过你那些破坏道义的勾当. 在这片平原上, 我会时刻盯着你的行军路线."],
                ["我是乔安娜, [" + _target_country_name + "] 的领主. 你的名声在我耳边并不算好. 既然现在是和平时期, 我允许你通行, 但请不要做出过激举动."],
                ["我是女王之盾 - 乔安娜. [" + _player_country_name + "] 的领主, 你越过边境而来, 是为了建立友谊, 还是仅仅路过?"],
                ["欢迎你, 远方的领主. 我听闻你在异国也一直坚守着公正, 这让我很敬佩. 像你这样正直的人，会受到我们的礼遇."],
                ["我是女王之盾 - 乔安娜. 很高兴能结识你这样坚守荣誉的领主. 你的战绩证明了你是一个可靠的人."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["请退后到安全距离."],
                ["我没有多余的闲暇, 恕不奉陪"],
                ["还有其他的事吗?"],
                ["看来你还有未尽的事项? 请讲, 我会认真听取."],
                ["来, 我们交流下阵型的布置"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "[" + _player_name + "], 作为同僚, 我不得不提醒你: 你的行事风格正在挑战 [" + _target_country_name + "] 的荣誉底线.",
                    ],
                    [
                        "[" + _player_name + "], 如果让我发现你在背后搞小动作, 我的海曜之盾会第一时间把你拍进平原的泥土里, 听明白了吗?"
                    ],
                    [
                        "[" + _player_name + "], 我并不想你多说一句话, 哪怕我们现在是同僚."
                    ],

                    [
                        "这段日子, 你的封地防务是否稳固? 保护子民是我们的第一要务.",
                        "[" + _player_name + "] 阁下, 在平原上生存, 谨慎永远比盲目的冒险更重要."
                    ],
                    [
                        "来, 跟我说说你的防御计划, 我们需要统一战线."
                    ],
                    [
                        "再次见到你很令人心安. 愿星辰的光辉能照耀我们的防线.",
                        "看到你平安回来真是太好了.",
                    ],
                    [
                        "你终于来了! 快来和我一起商讨这场伟大的远征计划.",
                        "很高兴你回来了, 在这乱世中, 你是唯一一个能让我完全放心的伙伴.",
                        "你终于来了! 只要我们并肩而立, 这天下便无人能攻破我们的防线!"
                    ]
                ]
            else:
                return[
                    [
                        "[" + _player_country_name + "] 的领主. 趁我还没决定为了旧怨而违抗和约, 立刻离开我的阵地!"
                    ],
                    [
                        "又是你. 虽然两国目前维持着和平, 但我依然会架起盾牌来防范你这条毒蛇",
                        "又见面了, [" + _player_name + "], 我不信任你, 更不信任你背后的国家. 在我的耐心耗尽前, 带着你的人马滚出我国的边界.",
                        "即便有和约在手, 我也不会对一个心怀鬼胎的异国人放下戒心. [" + _player_name + "]."
                    ],
                    [
                        "又见面了, [" + _player_name + "] 阁下. 任何风吹草动都瞒不过我的眼睛, 请自重."
                    ],

                    [
                        "又见面了, [" + _player_name + "]. 是什么让你跨越边界来到我的防区?",
                        "[" + _player_name + "], 在这一马平川的平原上, 做任何试图隐瞒的小动作都是徒劳的. 如果你只是来游山玩水, 那我劝你换个更安全的地方."
                    ],
                    [
                        "很高兴再次见到你, 正直的朋友.",
                        "异国的领主, 命运让我们再次重逢.",
                        "很高兴看到你的旗帜. 虽然你我王旗不同, 但维护和平的职责是相通的."
                    ],
                    [
                        "久违了, 正直的勇士. 愿今日的重逢能让我们放下过去的怨气, 共叙两国的安宁.",
                        "[" + _player_name + "], 在这乱世中, 一个信守诺言的对手比一个虚伪的盟友更难得."
                    ],
                    [
                        "每次见到你, 我都能感受到一股强大的力量.",
                        "[" + _player_name + "], 在这充满阴谋的世道, 能遇到一个讲道义的异国领主真是难得.",
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "为了" + _country_name + "的荣光! 冲锋!",
        "随我踏碎他们的防线!",
        "斧刃所向, 无坚不摧!",
        "海曜之光指引着我们!",
        "全军突击, 一个不留!",
        "让他们看看我们的钢铁意志! 杀!",
        "彻底碾碎他们!",
        "别让敌人活着离开!",
        "摧毁他们!",
        "让敌人明白, 挑衅" + _country_name + "的坚盾需要付出什么代价!",
        "众将士, 随我斩断黑暗!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你得到了应有的惩罚",
        "这是你必须付出的代价",
        "你的战败是必然结果",
        "在海曜战斧面前, 任何花哨的招式都毫无意义",
        "你败在你的鲁莽...",
        "这是你自找的",
        "你的进攻显得如此苍白"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这就是宿命, " + _target_hero_name,
            "再见了, " + _target_hero_name,
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...",
        "继续进攻!",
        "我还没倒下!",
        "这种痛感...",
        "你成功激怒了我!",
        "这种程度的攻击...",
        "你是个必须除掉的威胁!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "竟然被...",
        "海曜之盾...裂开了吗...",
        "陛下...",
        "哪怕我陨落...",
        "防线...不许崩塌...",
        "别管我...",
        "正义...永不陨落...",
        "终究还是..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "保持防守姿态推进!",
        "保持阵型!",
        "稳步向前, 别给敌人反扑的机会!",
        "稳步向前!",
        "稳扎稳打, 吾不容许任何无谓的损耗!",
        "稳步向前! 盾牌交叠, 不要露出任何缝隙!",
        "注意间距! 不要为了追求速度而让侧翼空虚!",
        "每一步都要稳扎稳打!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住阵线!",
        "坚守原地! 等待敌人的显露破绽!",
        "不要自乱阵脚!",
        "不要后退! 守住每一寸土地!",
        "在我的命令下达前, 谁也不许离开阵地一步!",
        "不要被他们的诱敌之策所动, 守住你们的位置!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "救治伤员, 清理战场!",
        "大家的表现配得上陛下的赞誉!",
        "战争结束了, 但警惕不能松懈. 整编队形!",
        "整修装备, 我们还有职责在身",
        "不要沉溺于战胜的喜悦! 去确认每一个同袍的安全!",
        "保持这种谨慎, 我们才能走得更远",
        "收集敌人的装备! 但不要羞辱战败者的尸骸!"
    ].pick_random()

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "看看你引以为傲的盾牌, 乔安娜, 现在它碎得很彻底."
        ],
        [

            "真是可惜, 乔安娜. 你变成了我的阶下囚."
        ],
        [

            "你所谓的坚盾简直像纸片一样脆弱, 乔安娜(冷笑)."
        ],
        [

            "所谓的女王之盾也不过如此."
        ],
        [

            "你的谨慎救不了你, 乔安娜.",
            "别再尝试抵抗了, 乔安娜."
        ],
        [

            "战斗结束了, 乔安娜. 放下你的武器."
        ],
        [

            "你输了, 乔安娜."
        ],
        [

            "胜负已分, 请保持你作为领主的体面, 我不会难为你."
        ],
        [

            "承让了, 乔安娜大人. 你的坚韧给我留下了深刻的印象."
        ],
        [

            "很遗憾, 乔安娜大人, 我们必须在战场上分出高下. 请原谅我的无礼."
        ],
        [

            "放弃抵抗吧, 我会用我的名誉担保你的安全."
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "盾牌可以被粉碎, 但我身后的誓言你永远无法践踏. 要杀要剐请便."
        ],
        [

            "战败是统帅的耻辱, 既然落入你手, 我无话可说.",
            "阶下囚也比你这种背信弃义的野心家要高尚得多. 别指望我会向你低头."
        ],
        [

            "哼...你的傲慢终究会让你付出代价."
        ],
        [

            "既然输了, 要杀要剐随你."
        ],
        [

            "既然局势已定, 我不会再增加无谓的牺牲."
        ],
        [

            "作为败军之将, 我会配合."
        ],
        [

            "这一局是你赢了."
        ],
        [

            "我接受这份暂时的失败."
        ],
        [

            "你赢得了这场博弈, 希望你能善待这片土地的人民."
        ],
        [

            "战场之上各为其主，你无需道歉."
        ],
        [

            "既然是你给出的担保, 那我便不再抵抗."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        [
            "收起你那副恶心的嘴脸. 我既然落入你这恶徒手中, 就没打算活着出去. 动手吧, 别在那浪费唇舌.",
            "有什么事吗? 我只恨那一斧没能劈开你那肮脏的铠甲.",
            "我没什么可以跟你聊的."
        ],
        [
            "有什么事吗? 如果你是来谈赎金的, 自然会有人来接应, 不要试图羞辱一名战士.",
            "如果你是来谈赎金的, 我建议你开一个合理的数字."
        ],
        [
            "有什么事吗? 我没有反抗的意图. 只希望你能遵守战俘协定, 别难为我那些幸存的部下.",
            "告诉我, 你需要多少金币才愿意放我走?"
        ],
        [
            "呵呵, 没想到我们会以这种形式再次相聚."
        ],
        [
            "虽然被俘虏有些不甘, 但是输给你, 我也无话可说.",
            "我的老对手, 有什么事吗? 看来你还是不放心, 非得亲眼看看\"女王之盾\"是不是被你彻底打碎了?",
            "战场之上胜负乃常事, 能栽在你手里, 总比栽在那些卑鄙小人手里要强."
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "既然胜负已分, 继续囚禁我也只是在损耗你的补给. 我愿支付 [#{0}] 德里, 以此换取我的自由.",
        "这是我能给出的最高诚意 - [#{0}] 德里. 与其互相消耗, 不如让这笔钱成为这场战斗的终章.",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "很好, 我保证, 下次不会再中你的诡计.",
            "交易达成, 好好祈祷下次见面时你还能有这么好的运气把.",
            "记住这一刻, [" + _player_name + "]. 我的盾牌迟早会把你和你的野心一起拍碎在泥土里.",
            "这是对你贪婪的施舍. 下一次, 我会用钢铁阵型击垮你."
        ],
        [
            "很好, [" + _player_name + "], 不要得意太久.",
            "理智的决定, 请让路."
        ],
        [
            "很好, 我会记住这次教训."
        ],
        [
            "很好, 我会带走我的残部. 希望下次相遇时, 你的进攻依然这么犀利.",
            "很好, 即便是对手, 我也必须承认你的判断力极其精准. 期待下次公平的对决."
        ],
        [
            "很好, [" + _player_name + "], 下次我会亲自讨回我失去的荣誉.",
            "保重, [" + _player_name + "]. 在我重整旗鼓回来挑战你之前, 别被其他人轻易击败了."
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "[" + _player_name + "], 你到底想耍什么花样?",
            "你要放我走? 这难道也是你所谓\"战术\"的一部分? 试图通过这种方式瓦解我的斗志?",
            "你确定? 真的要放我走? [" + _player_name + "], 你是觉得我现在的样子还不够狼狈, 非要玩这种\"猫捉老鼠\"的游戏吗?"
        ],
        [
            "我没听错吧? 你要放我走?",
            "我不相信无缘无故的善意. 你是想用我的自由, 去换取某种我尚未察觉的政治筹码吗?",
            "你刚才的话...是认真的?",
            "你真的要放我走? 我原以为在这乱世, 正直早已是稀缺品, 没想到你竟如此大度."
        ],
        [
            "这不符合逻辑. 放走我意味着你将面临 [" + _target_country_name + "] 更猛烈的反扑, 你真的想好了吗?",
            "你要放我走...不取分毫?",
            "等一下, 我想再确认一遍. 你真的打算在没有任何抵押, 没有任何条约的情况下, 就这么让我离开?",
            "我没听错吧? 在这种胜负已分的情况下, 你竟然选择了最让我震撼的那条路...你真的确定要放我走?"
        ],
        [
            "这种气魄...如果不考虑立场, 我真想为你这面旗帜献上我的敬意. 你确定不需要赎金?",
            "你真的决定了? 这种足以被刻进墓志铭的高尚, 你真的愿意用在我这个对手身上?",
            "[" + _player_name + "], 你的决断让我想起了那些古老的骑士歌谣, 但这现实的荒野可不是诗篇.",
        ],
        [
            "真的要放我走吗? 哪怕是为了我, 这种牺牲也太大了.",
            "[" + _player_name + "], 你的气量确实让我感到汗颜. 你真的确定了吗?"
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "既然门开了, 我就不再逗留. 我们战场上见, [" + _player_name + "]!",
        ],
        [
            "这份自由我收下了. 我会重新评估你 - 作为一个有准则的领导者, 而不是一个单纯的暴徒. 再会."
        ],
        [
            "既然你执意展现这份足以洗刷战火尘埃的高尚, 我若拒绝, 倒显得我心胸狭隘了. 再会.",
        ],
        [
            "我见过无数贪婪的军阀, 但你不同. 你这种保护弱者, 尊重对手的行为, 真的让我感到汗颜. 再会了.",
            "如果你是为了让我欠你一个人情, 那你成功了. 后会有期.",
            "你赢得了我的尊重, [" + _player_name + "]. 这种尊重无关胜负. 保重.",
            "你的行为证明了, 即便是敌手, 也可以拥有共同的信仰. 再会"
        ],
        [
            "谢谢你, 我的朋友. 在这冷酷的荒野, 你的正直比任何城墙都让人感到敬畏. 再会!",
            "这份情义, 我记下了, 后会有期."
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "我愿交出这件 [#{0}] 抵消我的赎金. 让我回到我的国土, 如何?",
        "我以此件 [#{0}] 为代价, 换取我的自由, 如何?"
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "我不赞同你的为人, 但今天在战场上的表现, 我必须给予你公正的评价.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "感谢你的协助. 看到战士们的伤亡降到了最低, 我感到由衷的欣慰."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "每次和你并肩作战我都觉得无比踏实.",
        "今日多亏了你沉稳的防御策略, 才能让战士们的伤亡降到了最低.",
    ]