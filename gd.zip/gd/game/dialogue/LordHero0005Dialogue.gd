extends LordNeutralDialogue

const HERO_UID = "lord_hero_0005"

func _get_granted_fief_clist()-> Array:
    return[
        "本汗给你一块地, 你要给本汗带来更多的胜利! [#{0}] 归你所有, 你可以收税, 领地内所有的一切你说了算. 如果你守不住, 本汗随时会把它赏给下一个更强壮的家伙."
    ]


func _get_attendant_meet_content()-> Array:
    return[
        {
            "clist": [
                "想活着, 就别往前走. 这里可是铁木尔可汗的部队! (声望过低, 国王拒绝接见)",
                "前方是苍穹的主宰者, [#{b_leader_name}] 的铁骑大军, 擅闯者, 马蹄无情. (声望过低, 国王拒绝接见)",
                "退下! 此地乃苍穹霸主的行军之路. (声望过低, 国王拒绝接见)",
                "止步, 旅人! 前方是多尔达尔的国王 - [#{b_leader_name}] 的营地! (声望过低, 国王拒绝接见)"
            ]
        }
    ]


func _king_reject_join_low_reputation_dialogue()-> Array:
    return[
        "你的名字在风中传得响, 却还吹不进本汗的帐中. " + LOW_REPUTATION_TIP,
        "多尔达尔的旗帜, 只为能并肩冲锋的勇者升起 - 你需要更多的历练. " + LOW_REPUTATION_TIP,
        "好好活着, 多杀几个敌人, 再来和本汗说这些话. " + LOW_REPUTATION_TIP,
    ]



func king_reject_join_rel_bad_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        "效忠本汗? [" + _player_name + "], 本汗的长矛至今还记得你那股令人作呕的懦夫气味. 想进本汗的大帐, 除非你能先接下本汗一百矛而不死!",
        "哈哈哈哈! 你这该死的杂碎, 竟敢跑到本汗面前讨官职? 本汗没现在就把你拧成碎肉, 已经是看在老天的份上了! 滚!",
        "你这卑劣的小人! 本汗还没忘记你干的好事! 本汗若是收了你, [" + _country_name + "] 的小伙子们会用唾沫把本汗淹死! 趁本汗还没拔矛, 消失!"
    ]


func _king_agree_join_low_reputation_dialogue()-> Array:
    return[
        "战火考验了你, 血与勇气让你站在了这里, 你打碎了怀疑, 也打出了名声. 本汗认可你! 从今日起，你将为多尔达尔而战！"
    ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "滚开! 这场战斗的血肉, 不允许你这种弱小的家伙来分."
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "哼, 你的到场不过是让这场屠杀变得更有效率一点. 不要以为这就能改变什么.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "哈哈! 你这头老狼来晚了!",
        "你总是能嗅到血腥味, 但这次你来晚了!"
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "你这头该死的野兽! 吾承认, 你比本汗想象中要强得多! 虽然本汗厌恶你, 但这次你赢得了本汗的认可!",
        "你的出现让本汗的弯刀更加闪耀! 这很好! 看在胜利的份上, 本汗这次不对你出手.",
        "哼, 别以为你救了本汗的军队, 就能改变本汗对你的看法!",
        "你这该死的家伙! 你打乱了本汗的计划, 却带来了胜利! 这次算你走运, 本汗给你一次活命的机会. 但记住, 本汗不欠你人情！",
        "本汗与你之间仇怨未消, 但本汗欣赏任何一个能带来胜利的强者! 你救了本汗的军团, 本汗会以对待勇士的方式对待你."
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你真是个天生的战士! 本汗很高兴看到你站在吾的一边!",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你和本汗一样, 是苍穹下最强大的战士! 今晚, 所有的牛羊和美酒都为你准备!",
        "你和本汗一样, 是真正的霸主! 来, 与本汗一起享受胜利的果实!"
    ]


func _get_battle_thank_first_meet_clist()-> Array:
    return[
        "吾是 [#{0}] 的国王 - [#{b_leader_name}].",
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "流浪者, 你面对的是草原的雄鹰 - 苍穹霸主铁木尔可汗! 你那根牙签一样的剑, 是想给可汗剔牙吗? 动手啊, 如果你急着投胎的话!"
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "苍穹霸主? 今天这片草原就会变成你们的墓地!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "噢! 天呐! 这该死的草原烈酒! 我刚才以为自己在砍一头疯牛, 没想到是可汗的仪仗...我这就带着我这些酒鬼兄弟滚远点!"
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["本汗等这一刻很久了! 动手啊! 只要你敢动一指头, 本汗就有理由把你的皮剥下来挂在旗杆上, 让全草原看看挑衅本汗的后果. 你确定要这么死?"],
        ["收起你的爪子, 浪人. 你以为这里是你能撒野的地方? 攻击本汗等同于向 [" + _target_country_name + "] 宣战, 你和你那些可怜的部下会被铁蹄瞬间踏平. 滚, 还是死?"],
        ["你要向本汗挑战? 想清楚, 这不只是你我的胜负, 这将是整个国家的战斗. 一旦见红, [" + _target_country_name + "] 的刀锋不杀光你最后一名部下绝不收回. 想好了吗?"],
        ["哈哈! 伙计, 你这酒劲儿还没过? 把剑收回去."],
        ["本汗视你为草原的兄弟, 你却要在本汗的王帐前拔剑? 这一步跨出, 你就是背信弃义的死囚, 全天下都将再无你容身之处! 你真要这么做?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["来啊! 只要你这一动, 那张擦屁股的\"停战协议\"就彻底作废了! 本汗保证 [" + _target_country_name + "] 的铁骑会踏平你们每一寸国土, 你确定要当这个开启地狱之门的罪人?"],
        ["收起你的剑, 小卒子. 你以为这种私下的挑衅能让你立功? 这一剑下去, 两国边境将再次血流成河, 而你就是那个背负万千性命的背誓者. 滚回你主子身边去."],
        ["站住. 你代表的是你的国家, 而非你个人. 你现在的举动将被视为公开毁约, 向 [" + _target_country_name + "] 正式宣战. 这一步踏出, 就再也没有和谈, 只有屠杀. 你确定要让你的领地和子民为你这瞬间的冲动陪葬吗?"],
        ["哈哈! 本汗的朋友, 你一定是疯了. 我们两国的和平来之不易, 你这一动手, 本汗就不得不下令踏平你的防线. 把剑收回去, 本汗可以当它是被风吹出来的. 你真要开启这毫无意义的国战?"],
        ["(拍案而起)本汗视你为兄弟, 你却要在本汗的王帐前撕毁我们的关系? 一旦开战, 你就是背弃盟约, 重燃战火的罪人! 你真要亲手毁掉我们之间的一切, 让两国的和平化为灰烬吗?"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["好! 就是这种自寻死路的眼神! 本汗会把你的肠子拖在马后, 绕着 [" + _target_country_name + "] 跑上三天三夜! 受死吧, 杂碎!"],
        ["既然你执意要用这块废铁来挑战苍穹霸主的威严, 那本汗就成全你. 本汗会踏平你的营地, 杀光所有还记得你名字的人!"],
        ["既然这是你选的路, 那就让战火烧得更旺些吧. 全军听令, 格杀勿论!"],
        ["你这无可救药的蠢货! 本汗给了你台阶, 你却偏要选择地狱! 既然你这么急着寻死, 那本汗就送你一程!"],
        ["这就是你的选择吗?! 你亲手杀了那个值得本汗托付后背的兄弟! 现在的你, 只是一个需要被清理的叛徒!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    return[
        ["本汗就知道你们的主子养了一群疯狗!"],
        ["你不仅是个蠢货, 还是个祸害. 进攻!"],
        ["你选择了最愚蠢的死法. 既然和平无法约束你, 那就让毁灭来审判你!"],
        ["本汗本以为你是个有远见的对手, 看来本汗高估了你的脑子. 既然你执意毁掉这来之不易的和平, 那就用你国家的血来偿还!"],
        ["你背叛了本汗的信任! 这一刻起, 你不再是本汗的手足, 而是必须铲除的污点!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "本汗就知道你会来找死! 你的头颅早就预定好挂在本汗的旗杆上了, 过来, 让本汗看看你的骨头有多硬!"
        ],
        [
            "[" + _target_country_name + "] 的勇士们, 把这些自不量力的蛆虫踩烂!",
            "哈哈哈哈! 好极了! 本汗正愁骨头快生锈了, 你就送上门来! 带上你的士兵, 滚过来领死!"
        ],
        [
            "多说无益, 既然在战场相遇, 那就只有一个人能活着离开.",
            "[" + _player_name + "]! 你有胆子攻过来, 就得有胆子把命留下! 全军突击! 把他们撕成碎片!",
        ],
        [
            "宿命如此! 作为对手, 本汗很欣赏你的勇气. 为了表示敬意, 本汗会用最锋利的刀割断你的喉咙!",
            "[" + _player_name + "], 别指望本汗会留情, 如果你倒下了, 本汗会给你留一碗马奶酒给你祭坟!"
        ],
        [
            "这就是战场的残酷, 本汗的朋友. 既然我们各自属于于不同的旗帜, 那就抛开交情, 进行一场痛快的死斗吧!"
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["你说得对，在这种地方动手确实是死路一条, 我收手."],
        ["你说得对, 我这点家底在 [" + _target_country_name + "] 的铁蹄面前确实不算什么. 收刀...是目前最明智的选择."],
        ["我的命不值钱, 但跟着我的弟兄们不该死在这场意气之争里. 那今天这仗, 我不打了."],
        ["呼...可能真的是这酒太烈了, 让我刚才失了分寸. 既然可汗愿意宽恕这分酒后的胡闹，那我就此告辞!"],
        ["刚才是我一时冲动, 铁木尔可汗的王帐不该沾染这种血."],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["你说得对, 我不该为了个人的愤怒而推开地狱的大门. 为了两国的和平, 这次的摩擦就到此为止."],
        ["你提醒了我, 我不仅代表我自己, 还背负着那些性命. 既然还没到不死不休的地步, 我选择撤兵."],
        ["为了这瞬间的冲动让子民陪葬, 确实不是一个领主该做的选择. 既然宣战的代价如此沉重, 那我收回刚才的挑衅."],
        ["你说得对, 和平确实比这场无意义的国战更有价值. 既然可汗给了我这个收刀的机会, 那我也没必要执迷不悟. 我这就告退."],
        ["你那句\"兄弟\"让我想起了当初并肩作战的场景. 我不想成为重燃战火的罪人, 也不想毁掉我们最后的一点信任. 刚才的事...就当没发生过吧."],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 鉴于你的罪行, 本汗打算你的血将浇灌 [" + _country_name + "] 的草场! 受死吧!"],
            ["你就是 [" + _player_name + "] 吧! 别在那像只受惊的小鹿一样发抖, 准备好被战马踏碎脊梁吧!"],
            ["你就是那个闹事的浪人 [" + _player_name + "]? 既然你被我国通缉, 那就把命留下. 希望你的骨头比你的名声更硬!"],
            ["你就是 [" + _player_name + "] 吧! 本汗听说你是个勇士. 可惜, 苍穹之下只有胜者能活, 来, 让本汗看看你的胆量!"],
            ["哈哈! 你就是那个名震草原的 [" + _player_name + "] 吧! 能捕获你这样的英雄, 是本汗的荣幸! 来, 用你的全力来迎接本汗的马刀!"],
        ]
    else:
        return[
            ["[" + _player_name + "]! 你这卑劣的残魂居然还敢出现? 这一次, 本汗要把你的头颅挂在旗杆上, 让秃鹫啄食你的傲慢!"],
            ["你以为能躲过本汗的追捕吗? 居然敢再次出现在本汗视线内. 这次别想再活着离开. 全军冲锋"],
            ["[" + _player_name + "], 草原上的猎物从未能逃脱第二次. 既然撞见了, 那就别废话, 像个男人一样战死吧!"],
            ["你还是这么顽固, 老伙计. 虽然本汗很欣赏你, 但在本汗的法度面前, 没人能破例. 拿起武器, 别死得太窝囊!"],
            ["哈哈哈哈! 本汗的老友! 能在战场上再次遇到你, 简直比烈酒还让人兴奋! 来, 让我们战个痛快, 赢的人才有资格喝酒!"],
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 本汗听说过你在边境那些偷鸡摸狗的行径, 像你这种只会劫掠平民的杂碎, 竟然也能在 [" + _player_country_name + "] 混个贵族? 今日, 本汗要亲手把你的帅旗踩进烂泥里!"],
            ["你就是 [" + _player_name + "] 吧! 本汗看不惯你那副畏缩的德行. 既然你带兵踏入 [" + _target_country_name + "], 就准备好被本汗的铁蹄踏碎!"],
            ["你就是 [" + _player_name + "] 吧! 听说你投靠了 [" + _player_country_name + "]? 好极了! 既然立场不同, 本汗这把渴血的战刀正好缺一个像样的领主来祭旗. 开战!"],
            ["你就是 [" + _player_name + "] 吧! 本汗听闻你是个有种的领主, 本想招你来大帐共饮. 可惜战火已起, 本汗只能在马背上给你一个体面的死法了!"],
            ["哈哈! 你就是那个名震四方的 [" + _player_name + "] 吧! 本汗早就想领教你的兵法了! 能亲手捕获你这样的雄鹰, 是本汗最大的快事! 攻过来!"],
        ]
    else:
        return[
            [
                "[" + _player_name + "]! 这一次, 本汗会把你拖死在战马之后!",
                "[" + _player_name + "]! 你这缩头乌龟, 终于舍得露头了? 本汗的战马早已等不及要踏碎你的骨头, 今天谁也救不了你!",
                "站住! [" + _player_name + "]! 在这片平野上, 没人能跑得过本汗的铁鬓! 等我追上你, 就把你的旗帜撕成碎布!"
            ],
            [
                "又见面了, [" + _player_name + "]! 既然你执意要在本汗的草原上寻找战争, 那本汗就成全你!",
                "[" + _player_name + "], 你那点小身板也敢在本汗面前晃悠? 既然你不长记性, 本汗今天就让你知道什么叫草原的规矩!",
                "别跑了, [" + _player_name + "]! 像个战士一样转身受死, 总好过被本汗在屁股后面戳出一个窟窿! 全军冲锋!"
            ],
            [
                "[" + _player_name + "], 既然你代表 [" + _player_country_name + "] 再次出现在本汗面前, 那就别废话了! 战火还没熄, 让我们用男人的方式决定这片草场的归属!",
                "[" + _player_name + "]. 既然碰上了, 就用武力来说话! 看枪!",
            ],
            [
                "本汗的朋友 [" + _player_name + "], 为何非要效忠于那些软弱的家伙? 真是浪费了一副好筋骨. 既然是开战, 本汗绝不留情!",
                "哈哈, 总算逮到你了! 既然两军阵前相遇, 就痛痛快快打一场! 活下来的才是真爷们儿!",
                "好你个 [" + _player_name + "]! 让本汗亲自追这么远! 你要是输得太惨, 本汗可不认你这个对手!"
            ],
            [
                "哈哈哈哈! 本汗就知道是你! [" + _player_name + "], 在这枯燥的战局中, 唯有你的挑战能让本汗热血沸腾! 来吧, 让你见识下苍穹霸主的实力!",
                "哈哈哈哈! [" + _player_name + "]! 我的好兄弟! 让我们的马蹄声震碎这苍穹! 杀!",
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 那个像苍蝇一样骚扰本汗子民的鼠辈! 本汗的长刀早就想割下你的舌头了, 但今日草原上有更鲜活的猎物等着本汗去收割. 趁本汗还没改主意, 带着你的脏命滚出这片草原!"],
            ["[" + _player_name + "]! 我认得你! 你竟敢大摇大摆地出现在本汗马前? 杀你这种货色只会弄脏本汗的马蹄. 本汗现在要去冲锋陷阵, 没空陪你玩捉迷藏, 滚远点!"],
            ["你就是那个浪人? 本汗听说过你的恶劣事迹, 但还不值得本汗现在调转马头去抓你. 只要你不挡着本汗的大军行进, 本汗今天就当没见过你. 跑吧, 老鼠."],
            ["哈哈! 你就是那个让人头疼的 [" + _player_name + "]? 能在草原上活到现在, 你有点本事. 本汗今日心情好, 不杀你, 去荒野里多活几天吧, 说不定哪天本汗会想收你当条猎犬."],
            ["喔! 看看这气势! 是 [" + _player_name + "] 没错了. 你是个勇士! 本汗今天放你一马, 不是因为仁慈, 而是希望你能活到本汗亲自在战场上把你撕碎的那一天!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["别在老鹰面前晃悠, 否则下一秒本汗就拧下你的脑袋!"],
                ["又是你这讨人厌的苍蝇! 滚!"],
                ["还有什么废话? 别再挑战本汗的火气!"],
                ["走吧, 趁本汗还没想起来你是个罪人."],
                ["你就这么急着死在本汗手里吗? 再等几天, 等本汗忙完这一阵!"],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]! 你以为草原的宽广能藏住你的罪孽吗? 若非本汗急着去摧毁前面的敌人, 现在就把你拴在马后拖成碎片! 消失!"],
                ["[" + _player_name + "], 你这臭味简直隔着几里地都能闻到. 本汗今日不想让这片草场染上孬种的血, 趁本汗的耐心还没耗光, 赶紧滚!"],
                ["你还没死? 看来草原上的野狼最近胃口不太好. 本汗今日没兴趣玩这种猫捉老鼠的游戏, 只要你别挡在本汗的马蹄前, 我就当没看见你这坨烂泥. 赶紧消失!"],
                ["[" + _player_name + "], 你这不要命的劲头倒是挺合本汗胃口. 走吧, 别随随便便就被别的猎人给宰了."],
                ["哈哈哈! 朋友, 你的人头还在脖子上挂着呢? 快走吧, 就当我没见过你."],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["本汗道是谁像秃鹫一样追着不放, 原来是你 - [" + _player_name + "]! 你夺走了本汗子民的草场，如今还想来取本汗的首级吗?"],
            ["你就是那个最近名震边境的 [" + _player_name + "]? 既然你执意拦在本汗的马前, 想必已经做好了被金羽之盾撞碎的准备. 想开战? 本汗求之不得!"],
            ["噢? 想必你就是那位最近声名鹊起的 [" + _player_name + "] 了. 你带兵截断本汗的马蹄, 是打算在这苍穹之下跟本汗赌一赌命吗?"],
            ["竟然在此处遇见了你. [" + _player_name + "]! 传闻你加入敌阵后从未尝败绩, 本汗的血液都在为你而沸腾! 既然你如此热烈地追随本汗的旗帜, 那我们还等什么? 就在此处, 开启一场让大地颤抖的角斗如何?"],
            ["你就是那个声名鹊起的 [" + _player_name + "] 吧? 你如此紧追不舍，是想在今日彻底终结本汗的传说吗?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["要打便打, 不要像个懦夫一样在那徘徊!"],
                ["本汗的长矛一旦拿出就必须见血. 你再靠近一步试试!"],
                ["你是在消磨本汗的耐心吗? 你是想死在天鹰之矛下吗?"],
                ["别像个胆小的土拨鼠一样只顾着张望!"],
                ["你的马蹄声已经把本汗的思路搅乱了!"],
            ]
        else:
            return[
                [
                    "又是你, [" + _player_name + "]! 你这头不知死活的恶犬, 竟敢一再挑衅本汗的威严!",
                    "[" + _player_name + "]! 你这胆大包天的杂碎, 非要像疯狗一样咬着本汗不放, 信不信本汗用天鹰之矛把你的脑袋捅穿!"
                ],
                [
                    "又见到这面令人厌恶的旗帜了. [" + _player_name + "], 你的纠缠让本汗感到一阵恶心. 既然你追到了这里, 是打算让这片草原现在就变成你的坟墓吗?",
                    "啧, 你这张脸简直比草原上的苍蝇还烦人! [" + _player_name + "], 本汗只是懒得在泥地里跟你纠缠, 你倒真以为自己是个猎人了?"
                ],
                [
                    "又见面了, [" + _player_name + "]. 你的追逐确实让本汗感到一丝压力. 直言吧: 你是来寻求一场血腥的祭礼, 还是单纯想比比谁的马更快?",
                    "别在那儿磨磨唧唧的了, [" + _player_name + "]! 如果你执意要挑战本汗的耐性, 那就拿出你的真本事来!",
                    "追逐游戏到此为止了! 本汗没空陪你在荒原上兜圈子. [" + _player_name + "], 想开战的话, 本汗现在就能打得你你满地找牙!"
                ],
                [
                    "[" + _player_name + "], 作为对手, 你识别强者的嗅觉真是敏锐. 虽然立场不同, 但本汗依然期待能在此刻与你痛饮...用鲜血代酒!",
                    "[" + _player_name + "], 你这执着的劲头让我想起了年轻时的获得的那匹宝贵烈马."
                ],
                [
                    "哇哈哈! 不愧是本汗看中的宿敌! 你的每一次逼近都让本汗感到无比欢愉. [" + _player_name + "], 你是想现在就开始这场狩猎?"
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["吾乃苍穹霸主铁木尔, [" + _target_country_name + "] 的领头鹰, [" + _player_name + "], 本汗听过你, 你只会对着没武器的平民挥剑吗?"],
            ["吾乃苍穹霸主铁木尔. [" + _target_country_name + "] 的统治者, 你像只没头的苍蝇一样到处乱撞, 到底是想找吃的, 还是想找死?"],
            ["吾乃苍穹霸主铁木尔! 流浪者. 你这身板看起来倒是能经得住草原的风暴."],
            ["吾乃苍穹霸主铁木尔. [" + _target_country_name + "] 的统治者, 你就是 [" + _player_name + "] ? 不错! 本汗听说你在乱贼手里护住了本汗的子民, 是个汉子!"],
            ["吾乃 [" + _target_country_name + "] 的统治者 - 铁木尔. 你就是 [" + _player_name + "] 吧, 本汗很久没见过像你这么气宇轩昂的勇士了! 来, 别废话, 先跟本汗干了这壶烈酒，然后去赛一场马!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["有屁快放, 没屁滚蛋!"],
                ["你再在本汗眼前晃悠, 我就拿你练练手!"],
                ["像只盯肉的秃鹫一样转来转去, 想干什么!"],
                ["[" + _player_name + "], 你是在消磨本汗的耐心吗?"],
                ["够了, 别在这儿徘徊."],
            ]
        else:
            return[
                ["你这臭不可闻的烂骨头怎么又露面了? [" + _player_name + "], 记住了, 草原的苍鹰从不原谅劫掠弱小的鬣狗. 离我远点, 否则本汗拆了你的骨头!"],
                ["又是你这游魂. 还没找到主子吗? 像你这种没根的杂草, 早晚会被草原的烈火烧个精光."],
                ["[" + _player_name + "], 你还没死在哪个不知名的阴沟里, 命倒挺硬! 最近长本事了吗?"],
                ["嘿! 勇士, 你又回来了! 本汗一直给你留着一匹好马, 只要你开口, 咱们现在就去冲杀一番, 怎么样?"],
                ["哈哈哈! 本汗的勇士, 你总算现身了! 快! 正好本汗憋得难受, 陪本汗去打猎!"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                [],
                [],
                [],
                [],
                []
            ]
        else:
            return[
                ["吾乃铁木尔! 你就是 [" + _player_name + "]? 别以为那一纸和约能保住你的命. 在本汗眼里, 你不过是只暂时还没到宰杀时间的羔羊."],
                ["你就是[" + _player_country_name + "] 的 [" + _player_name + "]? 哼, 这种穷乡僻壤出来的领主, 也敢来踏本汗的草原?"],
                ["本汗乃苍穹霸主铁木尔. 异国的领主, 你这副身板看起来倒是能经得住草原的风暴."],
                ["嘿! [" + _player_name + "], 本汗听过你的名号. 能在那种绝境里反败为胜, 你确实值得本汗敬你一碗酒."],
                ["哈哈哈! 久仰大名, [" + _player_country_name + "] 的猛虎! 本汗等这一天很久了, 像你这样的人物不该缩在那个小领地里."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["别像只苍蝇一样转来转去."],
                ["你到底有完没完?"],
                ["没看本汗正忙着吗? 本汗耐心有限."],
                ["哈哈哈, 舍不得走? 那就再干一碗!"],
                ["还没走吗? 要不我们赛场马?"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "[" + _player_name + "]! 你这领主当得真让本汗蒙羞! 再让本汗听到你那些缩头乌龟的事迹, 你就等着挨抽吧!",
                        "[" + _player_name + "]! 本汗一看到你这副唯唯诺诺的样子就火大!",
                    ],
                    [
                        "[" + _player_name + "], 别整天琢磨你那点小算盘. 在草原上, 唯有胜利和荣誉才是该追逐的.",
                    ],
                    [
                        "[" + _player_name + "], 本汗没空听你的那些空谈. 有本事就去拿几个像样的敌军首级回来."
                    ],

                    [
                        "本汗的同僚, 你那片草场最近长得怎么样?",
                        "[" + _player_name + "], 管好你的领地, 等本汗的战鼓响了就给本汗冲锋!",
                    ],
                    [
                        "好久不见, 我的朋友!"
                    ],
                    [
                        "哈哈哈! 本汗的左膀右臂, 你总算来了.",
                        "哈哈! 本汗的好兄弟来了! 快, 拿酒来!",
                    ],
                    [
                        "哈哈! 欢迎欢迎, 只要咱两联手, 这天下还有哪片草场是我们踏不碎的?",
                        "哈哈哈哈! 本汗的左右手, 你总算来了! 本汗已经等不及要和你并肩冲锋了!",
                        "哈哈哈哈! 你总算来了, 谁要是敢挡咱们的路, 本汗就把他的脑袋拧下来给你当球踢!",
                    ]
                ]
            else:
                return[
                    [
                        "[" + _player_name + "]! 别以为这所谓的和平能救你一辈子. 在本汗没改主意杀你之前, 赶紧消失!"
                    ],
                    [
                        "又是你这狐狸. 虽然两国处于和平时期, 但本汗一看到你这副德行就想拔矛.",
                    ],
                    [
                        "[" + _player_name + "]! 收起你的臭架子! 本汗的战马最讨厌闻到你身上的懦夫气味.",
                        "又是你, [" + _player_name + "]. 别怪本汗没提醒你, 草原的雄鹰从不低头看脚下的麻雀. 如果你来这里只是为了说些废话, 本汗劝你早点离开."
                    ],

                    [
                        "咱们又见面了. 想念草原上的烈酒了?"
                    ],
                    [
                        "又见面了, 够劲的对手! 能看到一个像样的战士真是件开心的事.",
                        "哈哈哈! 本汗最尊敬的对手来了! 来人, 设宴!",
                        "[" + _player_name + "], 虽然咱们王旗颜色不同, 但这草原上的烈酒, 本汗只愿和你对饮!"
                    ],
                    [
                        "哈哈哈! 草原的雄鹰再次重逢了! 本汗早就给你留好了最肥的羊腿, 咱们边吃边聊!",
                        "[" + _player_name + "]! 你来了! 陪本汗狩猎去!",
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "为了" + _country_name + "的荣光! 冲锋!",
        "随本汗踏碎他们的防线!",
        "天鹰之矛已鸣动, 敌人的心脏就是它的祭品! 杀!",
        "全军突击! 哪怕前方是悬崖, 也要给我踏平它!",
        "本汗的铁骑之下, 没有活口! 冲啊!",
        "把他们的阵型撞碎! 碾成血泥!",
        "谁杀得慢了, 晚上没酒喝!",
        "哈哈哈! 冲锋!",
        "草原的雄鹰张开了爪子! 撕碎他们!",
        "撞烂他们的骨头!",
        "谁要是怂了, 就别说是我铁木尔的手下!",

    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "哈哈哈!",
        "呸, 这种货色",
        "这就是你全部的本事?",
        "弱者只能闭嘴!",
        "太弱了!",
        "下辈子记得长个更硬的脑壳!",
        "呸!",
        "这就是挑战苍穹霸主的代价",
        "又一个自不量力的家伙",
        "连本汗的三招都接不下"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这就是你的宿命, " + _target_hero_name,
            "太弱了! " + _target_hero_name,
            _target_hero_name + ", 你太让本汗失望了!",
            _target_hero_name + ", 这是你自找的!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...",
        "再来!",
        "这种程度的挠痒!",
        "谁弄伤了本汗?",
        "呸! 给本汗继续杀!",
        "好啊!",
        "这点疼算什么?",
        "本汗还能再杀!",
        "大惊小怪!",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "竟然被这种小计谋...",
        "天鹰之矛...还没断...",
        "终会归于苍穹...",
        "这就是...本汗预想中的...结局吗",
        "哪怕我倒下...",
        "草原的风啊...",
        "死在战场上...才是霸主...归宿...",
        "可惜...",
        "别以为...这就结束了..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "进攻就是最好的防守! 压过去!",
        "全军压上! 谁敢后退半步, 本汗亲手剐了他!",
        "保持防守姿态推进!",
        "保持阵型!",
        "稳步向前, 别给敌人反扑的机会!",
        "稳步向前!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住! 等本汗找到机会, 就要把他们全部踩烂!",
        "原地立盾! 别让这些苍蝇钻进来!",
        "莫要自乱阵脚! 谁敢胆怯本汗就拿谁祭矛!",
        "先守住!",
        "谁敢往后退一步, 本汗的长矛第一个刺穿他!",
        "盾牌举高点! 要是让敌人的箭射中本汗, 我就拿你们祭旗!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "哇哈哈! 痛快! 今晚酒肉管够!",
        "这就是违抗本汗的下场! 把他们的旗帜全给烧了!",
        "清点战利品! 最肥美的羊都赏给最勇猛的小伙子!",
        "去! 把本汗的马奶酒拿来! 这一战打得够爽!",
        "这就是霸主的力量! 在这片平原上, 本汗就是规矩!",
        "打得好!",
        "哇哈哈! 看看这些丧家之犬! 这就是跟本汗作对的下场!",
        "胜利的滋味, 比最烈的马奶酒还要醇厚!"
    ].pick_random()

func get_leave_country_king_confirm_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_name()

    return[
        [
            "在这片草场上, 只有狼能活下来, 而你只是一只受惊的土拨鼠! 你确定要像丧家之犬一样夹着尾巴滚蛋?",
            "呸! 本汗早就看出你脑子里全是水! 如果你真的决定好了, 那就滚吧, [" + _player_name + "]! 连同你的臭架子!"
        ],
        [
            "哼, 觉得本汗的大帐太挤了? 想去别的草场晃悠? 本汗也不会拦你. 但把话挑明了, 以后要是战场上碰见, 本汗可不会留情! 你确定要这么做?",
        ],
        [
            "哼, 走就走吧, 本汗这里的烈酒只给愿意一起冲锋的兄弟喝! [" + _player_name + "], 你最后再确认一遍, 是不是要交还吾给你的一切?"
        ],
        [
            "[" + _player_name + "]! 你这家伙是不是喝多了? 咱们还没把那群敌人的脑袋拧下来, 你就要撤兵? 告诉本汗, 你是在开玩笑!",
            "本汗一直觉得你是个有种的汉子, 怎么突然说出这种丧气话? 是不是嫌本汗赏的东西不够? 再说这种话, 本汗可要生气了!",
        ],
        [
            "什么?! [" + _player_name + "]! 你是要往本汗的心窝子上扎一矛吗? 咱们可是换过命的兄弟! 没有你, 本汗这天鹰之矛还挥舞给谁看? 你真的...要走?",
            "哇呀呀呀! 气煞本汗也! 谁敢欺负你, 本汗现在就去剐了他! 别跟本汗说这些绝情的话! 你走了, 这草原上的美酒都变酸了! 你当真要抛下本汗吗?"
        ]
    ]

func get_leave_country_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "呸! 交出本汗赏你的地皮, 然后赶紧消失! 下次见面, 本汗的长矛可不长眼!",
            "滚吧! 别让本汗再看见你!"
        ],
        [
            "本汗从不强留怂包. 把旗帜留下, 你这种摇摆不定的家伙, 不配顶着 [" + _target_country_name + "] 的名号!",
        ],
        [
            "既然你想去闯荡, 本汗也不拦你. 两清了! 以后要是战场上撞见, 本汗绝不手软!",
            "行了行了, 快滚吧! 把领地交出来, 本汗还要把它赏给更强壮的小伙子!",
            "既然你觉得别处的马奶酒更香, 那就滚出本汗的视线. 从今往后, 你是死是活与本汗无关!"
        ],
        [
            "缘分尽了就别磨叽. 本汗这里的酒只留给兄弟, 既然你不再是了, 那就趁早滚蛋!",
            "既然你执意要走, 本汗也不想强留. 但本汗会永远记住你这个没良心的, 珍重吧!"
        ],
        [
            "既然拦不住你, 这壶酒算本汗为你送行的! 走吧!",
            "走吧! 别回头! 趁本汗没后悔没把你绑起来之前!"
        ],
    ]

func get_leave_country_cancel_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "哟, 怂了? 本汗就知道你没那个胆量去荒野闯荡, 滚回你的窝里待着去!",
            "哈哈! 怎么, 怕离开本汗的庇护就被人剁碎了? 既然不敢走, 就给本汗老实点!",
            "算你识相! 刚才的话本汗当你放了个屁."
        ],
        [
            "别整天琢磨你那点小算盘, 本汗看着火大!",
            "哼, 在你还没彻底糊涂之前, 记住这种脖子发凉的感觉, 领主之位可不是用来开玩笑的!"
        ],
        [
            "算你聪明. 刚才的事本汗就当没发生过."
        ],
        [
            "这就对了! 多大点事, 值得闹着要走? 陪本汗猎几头野猪去!",
            "既然不走了, 那就继续为本汗冲锋陷阵!",
        ],
        [
            "好! 我就知道刚才你那是酒后胡言! 回来就好, 本汗的左翼没你可不行!",
            "你这混球, 吓了本汗一身汗!"
        ],
    ]

func king_reject_join_recent_leave_country_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "你这厚颜无耻的秃鹫! 刚拍拍屁股滚蛋, 现在又想回来蹭本汗的马奶酒? 给本汗滚! 否则天鹰之矛就在你身上戳个窟窿!",
            "你把 [" + _target_country_name + "] 当成什么了? 你想来就来, 想走就走? 本汗的大帐不收留你这种反复无常的杂碎, 趁本汗还没把你拧成碎肉, 赶紧滚!",
            "呸! 你这卑劣的小人, 你的誓言比草原上的干草还要廉价! 滚出本汗的视线, 本汗怕忍不住现在就劈了你!"
        ],
        [
            "哼! 风往哪吹你就往哪倒? 本汗这里只要铁打的汉子, 不要你这种摇摆不定的软蛋!",
            "[" + _player_name + "], 你当本汗是三岁小孩吗? 刚解除契约就想回来, 你是在消磨本汗的耐心! 滚回你的荒野里去!"
        ],
        [
            "少跟本汗套近乎! 你之前的背弃本汗的场景本汗还没忘呢!",
            "行了行了, 别在这儿磨叽! 本汗现在正忙着准备远征, 没空理会你这种还没定性的家伙. 过阵子等本汗打完仗再说!"
        ],
        [
            "[" + _player_name + "], 你这混球是不是喝了假酒? 之前要走, 现在又要回来, 你把本汗的脸面往哪儿搁? 先滚一边去清醒清醒!",
            "哈哈, 你这家伙! 虽然本汗稀罕你的本事, 但你这反复无常的劲儿真让本汗火大. 现在回来不合规矩, 过段时间再来找本汗喝酒!",
            "别急着把旗帜领回去! 你走得太快, 归落得也太急. 在本汗的火气消下去之前, 你还是先在边境待着吧!"
        ],
        [
            "你这该死的家伙! 诚心气本汗是不是? 之前闹着要走, 现在又眼巴巴地跑回来. 本汗虽然把你当兄弟, 但这誓言可不是儿戏, 过些日子再来!",
            "哇哈哈! 我就知道你舍不得本汗这儿的羊腿! 但你之前把那张契约撕了, 本汗现在要是收你, 小伙子们会笑话本汗没骨气. 再等一阵子!",
            "我的好兄弟, 别在这一刻挑战草原的规矩! 本汗知道你后悔了, 但现在还不是时候."
        ]
    ]

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "尊敬的可汗, 你现在像是一只在泥地里打滚的秃鹫, 卑微又可怜."
        ],
        [

            "铁木尔, 你这头疯牛该进笼子里清醒清醒了."
        ],
        [

            "真是可惜, 铁木尔. 你变成了我的阶下囚."
        ],
        [

            "你的勇气救不了你, 而你的鲁莽加速了你的灭亡, 铁木尔."
        ],
        [

            "胜负已分, 铁木尔. 如果你还是个汉子, 就该认清现在的局势."
        ],
        [

            "别再尝试无谓的抵抗了, 铁木尔可汗."
        ],
        [

            "胜负已定, 铁木尔可汗. 我无意取你性命, 但你需要在牢里待上一阵子了."
        ],
        [

            "胜负已分, 尊敬的可汗."
        ],
        [

            "铁木尔可汗, 你是个值得尊敬的对手."
        ],
        [

            "原谅我的无礼, 朋友. 战场无情."
        ],
        [

            "你还是那么鲁莽, 老友."
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "哇呀呀! 你这卑劣的毒蛇, 竟敢如此侮辱本汗! 有种解开绳子, 看本汗不把你撕成碎片!",
            "呸! 本汗就算死在泥里, 也是草原上的雄鹰!"
        ],
        [

            "等本汗脱困, 第一件事就是踏平你的领地!",
            "好! 那你就祈祷这笼子够结实, 别让本汗有机会用这对角顶穿你的心窝子!"
        ],
        [

            "哼! 胜败乃兵家常事, 本汗不过是运气差了点. 少在那儿假惺惺地感叹.",
        ],
        [

            "本汗宁愿轰轰烈烈地战死, 也不愿缩在后方!"
        ],
        [

            "既然现在你的拳头硬, 本汗认栽!",
            "哼, 不用你教本汗怎么做人.",
        ],
        [

            "算你有两下子. 我认栽.",
        ],
        [

            "哼, 希望你那牢房够宽敞, 能容得下本汗这尊大佛."
        ],
        [

            "哈哈, 没想到本汗也有成为俘虏的一天."
        ],
        [

            "既然输了, 本汗心服口服!"
        ],
        [

            "战场上只有生死, 没有礼节!"
        ],
        [

            "要是本汗学会了那些弯弯绕绕, 你还会有机会抓住本汗?"
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        [
            "有什么事吗? 要是想看本汗垂头丧气的样子, 那你这杂碎可以滚了!",
            "呸! 离本汗远点, 你这只只会躲在暗处放冷箭的鬣狗, 本汗闻到你身上的味儿就恶心!",
            "盯着本汗干什么? 有种就把这枷锁打开, 看本汗不徒手把你那细脖子拧断!",
            "别以为本汗会求饶. 本汗只是不想死在臭虫堆里. 说, 要多少德里你才肯让本汗回去?"
        ],
        [
            "你是来消遣本汗的吗?",
            "别指望本汗会像那些软弱的西方领主一样向你求饶, 有什么手段尽管使出来!",
            "行了, 本汗没空跟你在这干耗. 开个合理的数字, 本汗这就让人送钱来赎身."
        ],
        [
            "你打算把本汗关到什么时候?",
            "咱们干脆点. 说吧, 多少赎金能还本汗自由?"
        ],
        [
            "快给本汗弄点好酒来! 这鬼地方没酒喝!"
        ],
        [
            "咱们之间就不谈那些虚的了. 你要多少金币尽管开口, 本汗绝不还价!",
            "别让本汗在这儿生霉了!"
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "给你 [#{0}] 德里, 快把这破锁打开!",
        "别在那磨磨唧唧的! 本汗用 [#{0}] 德里买自己的自由!",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "赶紧给本汗把枷锁打开! 下次见面, 你就没这么走运了!",
            "哼, 别让本汗在草原上再撞见你!",
            "记住这一刻, [" + _player_name + "]! 苍穹霸主的屈辱要用你的血来洗刷! 滚开, 别挡着本汗回营的路!"
        ],
        [
            "哼, 这笔账本汗记下了, 再会!"
        ],
        [
            "很好, 本汗会记住这次教训.",
            "很好, 希望下次在平原相遇时, 你的骨头还能像今天这么硬!",
            "[" + _player_name + "]. 咱们走着瞧!"
        ],
        [
            "战败是耻辱, 但输给你这种强手, 本汗无话可说. 下次见面, 本汗可不会再留情!"
        ],
        [
            "很好, [" + _player_name + "], 下次本汗会亲自讨回我失去的荣誉! 到时候咱们再比试比试!",
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "你确定? 真的要放本汗走? [" + _player_name + "], 你这阴险的土拨鼠, 是不是在门外埋伏了五十个弩手等本汗出去?",
            "你在羞辱本汗吗? 不要赎金就让本汗离开? 你是觉得本汗不值那个价, 还是觉得本汗已经拿不动矛了?!",
            "等等, 你真的确定? 这种毫无理由的\"仁慈\"比毒蛇的牙还要可疑! 你到底在玩什么把戏?",
            "放本汗走? 哈! 你想让全草原的人都笑话本汗欠了你的人情吗? 你这招可真够毒的!"
        ],
        [
            "你确定吗? 放走本汗, 意味着 [" + _target_country_name + "] 的铁蹄明天就会踏平你的大门! 你真的考虑清楚了吗?",
            "等一下, 本汗想再确认一遍. 你真的打算让本汗就这么毫发无伤地回到马背上? 这不符合战场的逻辑!"
        ],
        [
            "不需要任何抵押? 不需要任何承诺? 你真的确定要这么做?",
            "本汗没听错吧? 你真的打算放本汗走? 连一个德里都不要? 这种事情...真的可能发生?",
            "你刚才的话, 是认真的吗?"
        ],
        [
            "你确定吗? 放本汗离去... [" + _player_name + "], 你这气量简直比苍穹还要宽广!",
            "等等, 你真的确定不收赎金? 如果你是因为把本汗当兄弟才这么做, 那我必须说, 你这个决定够狂! 本汗喜欢!",
            "你真的决定了? 这种不要命的高尚, 你真的愿意用在本汗身上? 你就不怕本汗回去后再带兵杀回来?",
            "我没听错吧? 在这种胜负已分的情况下, 你竟然选择了最让本汗震撼的一条路...你真的确定?"
        ],
        [
            "真的要放本汗走吗? 哪怕是为了我, 这种牺牲也太大了. [" + _player_name + "], 你这疯劲儿简直和本汗一模一样!",
            "你刚才说...不需要赎金? 你真的确定要用这种方式来诠释我们的交情? 这比杀了我还让本汗难受...",
            "哇哈哈! 你这混球, 是想让本汗这辈子都欠你的吗?"
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "好! 你有种! 既然你敢放本汗走, 那就祈祷下次在战场上, 本汗的天鹰之矛不会刺穿你的喉咙!",
            "本汗这辈子没见过你这么蠢的对手, 但本汗欣赏你的胆量!",
            "[" + _player_name + "], 你做了一个极其危险的决定, 希望你以后不要后悔!",
        ],
        [
            "哼! 算你是个汉子. 虽然本汗还是看你不顺眼, 但今天你让本汗活着离开, 这份\"慷慨\"本汗收下了!",
            "我就喜欢和你这种不按常理出牌的家伙打交道! [" + _player_name + "], 保住你的脑袋, 本汗还要和你再战三百回合!"
        ],
        [
            "既然你执意要做这个\"圣人\", 那本汗就不客气了! [" + _target_country_name + "] 的勇士从不欠人情, 这笔账本汗记下了. 再会!",
            "你这人真有意思! 连本汗这种\"猛虎\"都敢放, 全天下恐怕只有你一个! 再会!",
        ],
        [
            "哈哈! 你真是个不可理喻的疯子! 不过, 本汗喜欢疯子! 后会有期.",
            "本汗记住了! [" + _player_name + "], 你这气量确实比草原上的天空还要广阔. 既然如此, 本汗也不在这儿磨叽了, 后会有期!"
        ],
        [
            "哇哈哈! 好样的! 我就知道你是个够劲的对手! 既然你如此大度, 那本汗就不客气了, 再会!",
            "哈哈哈哈! [" + _player_name + "], 我的老友! 只有你敢这么做这种狂妄的决定! 再会!"
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 跟着本汗饮过无数敌人的血, 拿去, 然后把这该死的枷锁给本汗砸烂!",
        "够了! 别在那盯着本汗看笑话! 本汗用这件 [#{0}] 换回马背上的位子.",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "虽然本汗与你有些过节, 但本汗向来有一说一, 不会抹杀你的功劳!",
        "本汗平日里瞅你不顺眼, 但今天你在草原上冲锋的猛劲, 倒还算个汉子.",
        "草原上的汉子只看手里家伙硬不硬, 杀人快不快. 你完成了任务. 但咱们依然不是一路人!"
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "这一仗打得真他娘的过瘾!",
        "哈哈! 你小子跟进得还算及时, 没掉链子!",
        "打得好! 本汗就喜欢这种不用讲废话, 只管砍人的合作.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 老搭档! 这次配合得真不赖!",
        "痛快啊! 本汗的好搭档!",
    ]