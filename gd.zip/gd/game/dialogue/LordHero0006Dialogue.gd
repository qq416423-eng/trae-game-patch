extends LordNobleDialogue

const HERO_UID: = "lord_hero_0006"







func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "就凭你这副穷酸样也想分这块土地的肉? 去给 [" + _king_name + "] 当看门狗吧, 或许他/她会赏你两根骨头. 滚!"
        ]
    elif _rel_value <= -10:
        return[
            "你想加入 [" + _country_name + "]? 别逗我笑了, 咱们这儿可不收没用的废物. 去问问 [" + _king_name + "] 还要不要喂马的杂役.",
            "你这种闻着油水味儿就凑过来的苍蝇, 居然也想当领主? 去找 [" + _king_name + "] 试试吧, 如果他/她还没老糊涂, 应该会把你轰出来."
        ]
    elif _rel_value <= 10:
        return[
            "想要划分这片土地的利益? 我可做不了主. 权力只集中在一个人手中, 那就是 [" + _king_name + "], 去舔他/她的靴子吧.",
        ]
    elif _rel_value < 30:
        return[
            "你想效忠? 去找 [" + _king_name + "] 谈, 只要你能让他/她觉得你比一头驮马更有用, 他/她会收留你的."
        ]
    else:

        return[
            "嘿, 伙计, 你总算开窍了. 咱们联手, 这草原上就没几个油水丰厚的地方能逃过咱们的掌心! 快去见见 [" + _king_name + "], 走个过场, 我已经在信里替你吹过牛了.",
            "哈哈哈! 如果你成了这里的领主, 咱们就能名正言顺地去掀了邻国的营帐! 快滚去见 [" + _king_name + "], 拿到委任状后记得带上好酒来找我庆祝!"
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "你不过是捡了点残羹剩饭. 少在我面前碍眼, 我可不想分给你战利品.",
        "你真是碍眼. 这战利品里没你的份, 滚远点!"
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的出现倒是省了我一些力气, 仅此而已.",
        "你那点微末的贡献, 算是在向我示好吗? 我领情了, 但别指望太多.",
        "你的出现倒是及时, 下次记得在场外等我清理干净."
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "老伙计, 你来得真巧, 不然我又要自己收拾这堆烂摊子了. 快去看看有没有遗漏的财物.",
        "老伙计, 下次记得带上好酒, 别光带你那把钝剑来. 哈哈哈哈."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "你比我想象的要厉害. 虽然我们互相厌恶, 但你的实力值得尊重. 我欠你一个人情, 但仅此一次.",
        "你很清楚力量的价值, 这次你投资对了.我承认你救了我, 但我们的旧账可还没一笔勾销."
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你带来的胜利很值钱. 拿走你应得的, 我喜欢和能带来利益的人打交道.",
        "你真是个优秀的猎手, 今天的猎物我们平分!"
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你为我们带来了胜利和财富, 我银狼认可你的力量. 你想要什么, 都可以提出来.",
        "看看这场面! 你真是我的好帮手, 一起享受这场盛宴吧!",
        "我的兄弟, 你那把刀替我省了太多的事! 你想要什么? 尽管开口."
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "阿尔坦大人最喜欢你这种没脑子的蠢货, 想好了就动手吧!"
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "银狼 - 阿尔坦? 我看是一只披着狼皮的丧家犬!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "噢! 该死...这劣质麦酒害死人! 我刚才看花了眼, 把诸位英勇的卫兵看成了几根会走路的烂木头. 千万别跟我这烂酒鬼计较!"
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        ["只要你敢动一指头, 我就把你切成肉块喂我的狼, 你确定要给自己挑个这么惨的死法?"],
        ["瞧瞧这只不知死活的丧家犬. 向我拔剑?"],
        ["你要挑战我? 一旦开战，我不仅要你的命, 还要你身后所有人陪葬. 你这颗廉价的脑袋真的想好了吗?"],
        ["哈哈! 伙计, 你这酒劲儿还没过? 虽然我喜欢看人流血, 但杀一个醉鬼可弄不到多少赏钱. 把剑收回去."],
        ["我把你当成能一起分赃的兄弟, 你却要在我的帐篷前演英雄? 这一步跨出, 你就只是个待宰的叛徒. 你真要这么蠢?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["来啊! 我早就想撕烂那张无聊的\"停战协议\"了! 只要你一动, 我就能名正言顺地抢光你们的边境! 你确定要当这个开启抢掠盛宴的蠢货?"],
        ["收起你那可怜的自尊心吧. 你真的打算为了这点小事宣战, 然后输个精光?"],
        ["站住. 你现在的举动将被视为公开毁约. 向 [" + _target_country_name + "] 宣战的代价, 你那点领地赔得起吗? 你确定要让子民为你瞬间的脑热买单?"],
        ["哈哈! 我的朋友, 你一定是疯了. 这种吃力不讨好的仗有什么好打的? 把剑收回去, 我可以当你是手滑."],
        ["我视你为兄弟, 你却想捅我的腰子? 一旦开战, 你就再也不是什么盟友, 而是我挂在马后的一块烂肉!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["好! 就是这种找死的表情! 我会把你浑身值钱的东西都剥下来! 死吧, 杂碎!"],
        ["既然你执意要挑战我, 那我就收下你的命. 全军冲锋!"],
        ["路是你自己选的. 既然想死, 我就成全你这廉价的自尊. 杀!"],
        ["蠢货! 我给了你活命的机会, 你却偏要选地狱. 下辈子记着离我远点!"],
        ["既然你选择当叛徒, 那我就亲手把你挂在旗杆上. 这是你自找的!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    return[
        ["掠夺的时间到了! 我会把你们的国家搬空! 进攻!"],
        ["你不仅是个蠢货, 还是个完美的猎物. 让边境烧起来吧!"],
        ["既然和平让你觉得无聊, 那就让毁灭来教你什么叫代价!"],
        ["高估了你的脑子是我犯的唯一错误. 用你子民的血来偿还吧!"],
        ["你背叛了\"狼\"的信任, 那就准备好被撕成碎片吧!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "我就知道你会送上门来!"
        ],
        [
            "草原的狼们, 开饭了! 把这些自不量力的蛆虫踩烂!",
            "[" + _player_name + "], 带这些个不入流的货色来进攻我, 你是脑袋被马踢了吗?",
        ],
        [
            "多说无益. 既然遇上了, 那就看看谁的刀更快, 谁的命更硬!",
            "别在那儿摆架子了, [" + _player_name + "], 你的脑袋在我眼里也就值几百德里, 过来领死!",
            "[" + _player_name + "], 既然你敢跨过界, 那就别指望能全尸回去. 全军给我压上去! 杀光他们!",
        ],
        [
            "作为对手, 你的头应该能卖个好价钱. 来战吧!",
            "[" + _player_name + "], 既然你已经亮了剑, 那就直接开始这场屠宰吧! 我会让你明白, 在这儿谁才是真正的头狼!"
        ],
        [
            "这是最后的买卖了, 老朋友. 既然没法共赢, 那就请你去死吧!"
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["在这种疯狼面前拔剑确实不明智."],
        ["在这种地方丢了命确实不划算. 罢了."],
        ["这笔买卖确实不怎么划算. 罢了."],
        ["呼...这酒劲儿上头确实容易让人犯蠢, 告辞"],
        ["既然你还愿意跟我谈\"共赢\"的事, 那刚才的胡闹就此作罢."],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["你说得对, 我不该为了点小摩擦就推开地狱的大门."],
        ["你提醒了我, 这笔赔本买卖不该由我来开启."],
        ["你说得对, 阿尔坦. 我不该让我的子民为我瞬间的脑热买单."],
        ["既然你说这是个吃力不讨好的仗, 那我也没必要执迷不悟. 这把剑...确实只是\"手滑\""],
        ["我冷静的想了想, 我不想成为你马后的一块烂肉, 更不想毁掉我们的财路."],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 你这该死的畜生, 终于撞在我手里了. 我会剥下你的皮当毯子, 再把你那点可怜的家当全部收缴!"],
            ["你就是 [" + _player_name + "] 吧! 啧啧, 长得就不像个值钱的样子, 却给我添了这么多麻烦. 乖乖束手就擒，省得我多费力气!"],
            ["你就是那个闹事的浪人 [" + _player_name + "]? 你的人头在 [" + _country_name + "] 可是标了高价. 既然送上门来了, 那这笔横财我就收下了!"],
            ["你就是 [" + _player_name + "] 吧! 我听那帮牧民说你心肠不错? 呵, 心肠好可不能当饭吃. 虽然老子不讨厌你, 但赏金我还是要拿的!"],
            ["哎呀! 这不是名震草原的 [" + _player_name + "] 吗! 哈哈! 抓到你一个, 够老子手下兄弟吃喝半年了! 别反抗了, 咱们哥俩谁跟谁啊, 对吧?"],
        ]
    else:
        return[
            ["[" + _player_name + "]! 你这阴魂不散的杂碎, 竟然还敢出现在我面前? 这一次我会打断你的双腿, 看你还怎么跑!"],
            ["[" + _player_name + "]! 滚过来受死, 别耽误我去喝下一场酒!"],
            ["[" + _player_name + "], 上次你这颗脑袋在我兜里还没捂热就跑了, 这次我看谁还能救你. 赏金, 我拿定了!"],
            ["还没走远呢, [" + _player_name + "]? 虽然我挺看好你, 但职责(赏金)所在, 只能对不住了. 我会下手快点的!"],
            ["哈哈! 好兄弟! 你简直就是我的福星啊! 既然又碰上了, 就再帮哥哥换点酒钱吧? 放心, 进牢房后我一定给你带肉吃!"],
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 你这该死的畜生, 当初在老子地盘上肆意撒野的时候挺威风啊? 现在披上皮当了 [" + _player_country_name + "] 的领主, 就以为债清了? 正好, 领主的人头更值钱, 老子今天要连本带利收回来!"],
            ["你就是 [" + _player_name + "] 吧! 啧啧, 瞧瞧你这寒酸样, 也能当上贵族? 我对你们国家的眼光真是不敢恭维. 既然撞见了, 就乖乖给我留下点\"过路费\"吧."],
            ["你就是那个闹事的 [" + _player_name + "]? 听说你加入了 [" + _player_country_name + "]. 好极了. 两边开战, 杀了你既能拿军功, 又能领赏金."],
            ["你就是 [" + _player_name + "] 吧! 我听手下说你挺能干的. 如果你不是效忠那个敌国, 我倒想拉你入伙. 可惜啊可惜, 既然你是敌国的领主, 那我只能把你抓回去换酒钱了. 别怪我, 这就是生意."],
            ["哈哈! 竟然在战场上碰到你了! 你现在可是个\"大人物\"了啊! 抓到你一个领主, 顶我抢十个村庄. 来吧，配合一点，我会给你选个最舒服的囚笼的!"],
        ]
    else:
        return[
            [
                "[" + _player_name + "]! 你这阴魂不散的杂碎, 还敢领兵在老子面前晃? 你以前欠我的那些账, 今天我要从你的尸体上一个子一个子地刮下来!",
                "[" + _player_name + "]! 老子的黑枪已经嗅到你身上那股穷酸气了. 跑? 你能跑过草原上的狼? 今天老子要把你的皮扒下来抵债!",
                "哟, 这不是还没死透的 [" + _player_name + "] 吗? 既然你又来找不痛快, 我就把你那颗脑袋割下来去领赏!"
            ],
            [
                "又见面了, [" + _player_name + "]. 怎么, 上次给你的教训还不够, 敢带着兵来挑衅我? 这次我会让你赔个精光!",
                "啧, 又是你. [" + _player_name + "], 你这张脸简直比发霉的草料还让人倒胃口. 既然你自己撞到了老子的斧头上, 那就别怪我收点过路费了!"
            ],
            [
                "[" + _player_name + "], 两国的战火还没灭, 你就急着来送死? 既然你这颗领主的人头又送上门了, 我可没有往外推的道理.",
                "[" + _player_name + "], 听说你最近肥了不少? 正好, 老子的兄弟们最近手头紧. 就请你慷慨解囊, 把命和财宝都留下吧!",
            ],
            [
                "还没走远呢, [" + _player_name + "]? 虽然我挺看好你, 但赏金和交情, 我永远选前者. 我会下手快点, 不耽误你下辈子投个好胎.",
                "别说我没给你机会, [" + _player_name + "]. 既然你再次跨过这条线, 这仗就由不得你选了.",
                "别跑那么快啊, [" + _player_name + "]. 能死在老子阿尔坦手里, 总好过死在那些虚伪的家伙手里. 来, 让哥哥看看你的剑术涨了多少!",
                "[" + _player_name + "], 虽然我挺看好你, 但我手里的斧头可不懂什么叫交情."
            ],
            [
                "哈哈! 老伙计! 你简直就是我的\"移动金库\"啊! 既然又碰上了, 就再帮哥哥换点军费吧?",
                "嘿! [" + _player_name + "], 我的好兄弟. 你怎么这么不小心, 竟然落到了老子手里? 别担心, 我会下手利索点.",
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["[" + _player_name + "]...我在通缉名单上见过你. 本来杀了你可以平息不少民愤, 但我那昂贵的毒箭可不想浪费在你这种没油水的杂碎身上. 滚吧."],
            ["啧, 通缉令上的 [" + _player_name + "]. 像你这种落魄的流浪者, 身上连两块像样的银币都掏不出来吧? 杀了你还得浪费我的箭. 趁我还没觉得这笔买卖有赚头, 赶紧滚!"],
            ["我认得你, 你的赏金还没涨到值得我大动干戈的地步. 我就大发慈悲让你多活几天, 记得去多抢点值钱的东西, 这样下次抓你才更有赚头."],
            ["嘿, [" + _player_name + "], 我认得你, 你杀人的手法挺利索嘛. 虽然我是领主, 但我不得不说, 你这种为了利己不择手段的劲头真合我的胃口. 走吧, 今天我不收你的买命钱."],
            ["哈哈! 你就是 [" + _player_name + "]? 你这颗人头在黑市可是越来越值钱了. 我现在舍不得杀你, 毕竟这种会增值的宝贝得留到行情最好的时候再出手. 快跑吧, 跑快点!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复出现在我面前是想领赏吗?"],
                ["你的出现只会平白消耗我的耐心和空气, 快滚!"],
                ["还有什么事? 难道是想把你的破剑卖给我? 我可不收垃圾."],
                ["趁我还没计算出抓捕你的价值, 赶紧消失."],
                ["别在这儿晃悠, 你这身寒酸样会把我的财运都晃没了."],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你这笔该平掉的烂账竟然还没消失? 若非我有更大利润的生意要忙, 我现在就把你的皮剥下来做垫子. 滚!"],
                ["你这种如苍蝇般的纠缠让我觉得恶心. 杀了你得不到战功, 不杀你又坏我心情. 趁我还没决定为了心情而浪费资源杀人, 赶紧滚远点!"],
                ["又见面了. 看来你还没让自己的赏金多涨涨? 别在我马前晃, 抓你这种廉价的目标对我来说简直是种侮辱."],
                ["哎呀, 我的老伙计. 你还没被吊死呢? 看来草原上的卫兵也和你一样狡猾. 走吧, 希望下次遇见你时, 你已经抢到了一座金矿."],
                ["哈哈! [" + _player_name + "], 你简直是我见过的最顽固的\"资产\". 别死在别人手里, 你的命最终还是归我的！"],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["我就说为什么忽然觉得倒胃口, 原来你就是 [" + _player_name + "]. 你在 [" + _player_country_name + "] 赚的那点脏钱够买你的命吗?"],
            ["瞧瞧, 这不是 [" + _player_country_name + "] 养的那条好狗吗? [" + _player_name + "], 你追得这么紧，是想求本大爷赏你块骨头, 还是想试试我的战斧能不能劈开你那没长脑子的脑袋?"],
            ["你就是那个最近闹得沸沸扬扬的 [" + _player_name + "]? 看起来也不过如此. 你带兵拦着我, 是觉得立个功劳能让你的主子多赏你两个德里?"],
            ["嘿, 你就是 [" + _player_name + "] 吧! 虽然你效忠国家的那帮蠢货让我恶心, 但你这股狠劲儿倒挺合本大爷胃口. 怎么, 在那边待得不爽，想来找本大爷切磋切磋?"],
            ["哈哈哈! 你就是那个名震边境的疯子吧? 本大爷最喜欢咬死你这种自命不凡的家伙了! 要不赶紧拔出你的剑? 赢的人带走战利品, 输的人下地狱去骂街吧!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["[" + _player_name + "], 你像只苍蝇一样转来转去, 真以为本大爷不敢把你劈了吗?"],
                ["还跟着我做什么?"],
                ["要打就来! 不打就滚去给你那主子擦靴子!"],
                ["你还没走远?"],
                ["你是在等我请你喝马奶酒吗?"],
            ]
        else:
            return[
                [
                    "又是你这讨债鬼! [" + _player_name + "], 你还没死透?",
                    "[" + _player_name + "]! 你这从地沟里爬出来的臭虫, 闻着老子部队的味儿就追过来了?",
                    "[" + _player_name + "]! 如果你执意要撕咬不放, 那老子就敲碎你所有的牙!"
                ],
                [
                    "又见到你这副寒酸相了, [" + _player_name + "]. 你效忠的垃圾国家 [" + _player_country_name + "] 是发不出军饷了吗? 让你像只饿狗一样追着本大爷不放.",
                    "跑了一路你都不累吗? [" + _player_name + "]! 既然拦住了我, 就直说吧, 你是想要我的命, 还是想要我兜里的金币?",
                    "啧, 瞧瞧这副贪婪的嘴脸. [" + _player_name + "], 你除了像只秃鹫一样盯着别人的残羹剩饭, 还会点别的吗?"
                ],
                [
                    "又见面了, [" + _player_country_name + "] 的走狗. 你的脑袋看起来还值点钱, 怎么样, 你是打算亲手把它递给我, 还是让我费点劲儿去摘?",
                    "[" + _player_name + "], 你的鼻子比荒原上的野狗还灵, 专门挑老子疲惫的时候撞过来!"
                ],
                [
                    "哟, [" + _player_name + "]! 你这阴魂不散的家伙还真有两下子. 既然你这么想念本大爷的战斧, 那我们就找个地, 看看谁先摘下对方脑袋?",
                    "哈哈哈哈! 我就知道是你, [" + _player_name + "]! 只有你这只疯狗能在荒原上追我这么远!"
                ],
                [
                    "哇哈哈! 宿敌, 在这片草原上, 只有你这股杀气能让本大爷兴奋起来!"
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["啧, 这不是那个在林子里抢骨头的烂狗 [" + _player_name + "] 吗? 别用那种眼神看我, 本大爷这儿不收废物, 滚远点, 免得脏了我的战袍!"],
            ["一个没主子的流浪者? [" + _player_name + "], 你这种穷酸样也就配在泥地里打滚了. 想从本大爷这儿讨口饭吃? 先掂量掂量你那条贱命值不值几个德里, 我可没闲钱养闲人."],
            ["我是阿尔坦, 这片荒原的主人. 你就是那个到处乱窜的浪人 [" + _player_name + "]? 嘿, 身板倒还算硬朗."],
            ["我是阿尔坦, 这片荒原的主人, 想必你就是那位\"大善人\" - [" + _player_name + "] 了, 听说你帮助那群穷鬼还不收好处? 真是蠢得可爱."],
            ["我是阿尔坦, [" + _target_country_name + "] 的领主, 想必你就是 [" + _player_name + "] 了. 我就喜欢你这种满眼杀气的疯子!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["又回来了? 你是想求我打赏你两德里吗?"],
                ["别在这儿晃悠! 过路费交了吗?"],
                ["没带够诚意就离我远点."],
                ["大善人, 你还没走?"],
                ["走, 随我去那边瞧瞧有什么值钱的猎物."],
            ]
        else:
            return[
                ["那股穷酸臭味又飘过来了. [" + _player_name + "], 你那颗脑袋竟然还挂在脖子上, 真叫本大爷失望. 滚开, 别逼我亲自动手摘了它!"],
                ["又是你. 还没死在哪条阴沟里吗? 像你这种没根的杂草, 活着也是在浪费草原的土地."],
                ["[" + _player_name + "], 你还没找到那个肯花大价钱买你命的蠢主子吗? 啧, 看来你的身价不怎么样啊."],
                ["嘿, [" + _player_name + "]. 你那把破剑还没生锈吧? 虽然你脑子不太好使, 但手脚还算利索."],
                ["哈哈哈! [" + _player_name + "]! 你总算回来了! 本大爷最近盯上了一块肥肉, 你可有兴趣一同前往?"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["我是阿尔坦. 你就是那个被吹上天的新领主? 啧, 我看你这张脸倒是挺适合贴在通缉令上的. 咱们丑话说在前头, 在 [" + _target_country_name + "], 肉就那么多, 你要是敢动我的盘子, 我的荒原黑枪可不认什么同僚情分."],
                ["我是阿尔坦. 你就是 [" + _player_name + "] 是吧? 听说你最近挺风光? 呵, 别以为拿了个领地就能在这儿横着走. 草原上的风大, 小心把你这副虚架子吹散了."],
                ["我是阿尔坦. 你就是新来的同僚? 长得还算精神. 既然大家都在同一面旗帜下混饭吃, 只要你不挡我的财路, 我也没兴趣找你的麻烦."],
                ["我是阿尔坦. 嘿, [" + _player_name + "], 我听过你的手段. 够狠, 我喜欢. 在这群死脑筋的领主里, 难得有个像你这样明白事理的人."],
                ["我是阿尔坦! 你终于来了, 伙计! [" + _target_country_name + "] 总算来了个像样的狠角色. 那些胆小鬼领主根本不配跟我们坐在一起."]
            ]
        else:
            return[
                ["我是阿尔坦. 你就是 [" + _player_country_name + "] 的新晋贵族? 你胆子不小啊, 居然敢带着你那股酸臭味踏进我的地盘. 在我眼里，你只是一具还没断气的尸体."],
                ["哟, 这不是异国的贵客吗? [" + _player_name + "], 你那领地是穷得揭不开锅了吗, 跑来这儿闻土?"],
                ["我是阿尔坦, 这片原野的主人. 异国的领主, 你是带钱来做买卖的, 还是带兵来找死的?"],
                ["我是阿尔坦. 我听闻过你的事迹, 个人倒挺欣赏你. 如果你在那边待得不痛快, 随时可以带兵投奔我."],
                ["久仰大名, [" + _player_country_name + "] 的大红人! 我是阿尔坦. 像你这种满眼野心的家伙最合我的胃口了."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["你的脸不值钱，看多了反胃."],
                ["还有什么破事?"],
                ["你是想在这儿扎根吗? 耽误我的时间可是要收费的."],
                ["你还在啊..."],
                ["怎么, 想现在就跟我去掀了谁的营帐?"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "[" + _player_name + "], 你还没死在哪个沙坑里? 真是个奇迹.",
                        "哟, 这不是 [" + _player_name + "] 吗? 怎么, 还没在你那漏风的领地里饿死?",
                        "我最讨厌你这种自以为是的家伙. 离我远点.",
                        "又见面了, [" + _player_name + "], 要是让我发现你敢打我的草场的主意, 我的荒原黑枪可不分什么同僚不同僚.",
                        "[" + _player_name + "], 别在这儿像条丧家犬一样乱晃."
                    ],
                    [
                        "这不是 [" + _player_name + "] 吗? 看看你这副穷酸样. 跟着那些老古董领主能混到什么好处?",
                        "[" + _player_name + "], 只要你不挡我的财路, 我也没兴趣找你的麻烦."
                    ],
                    [
                        "又是你. 身为领主, 你除了会在这儿浪费口粮, 还会干点别的吗?"
                    ],

                    [
                        "同僚, 我看你气色不错, 是不是又在哪儿捞到油水了?"
                    ],
                    [
                        "[" + _player_name + "], 你最近倒是挺威风啊, 抢了不少好东西吧?"
                    ],
                    [
                        "好久不见, 我的好伙计! 你的武器还没生锈吧?",
                        "嘿嘿, 我的好搭档, 你总算来了. 我刚盯上了一个肥得流油的目标, 有没有兴趣跟我去干一票大的?",
                        "嘿嘿, 我的好搭档, 我就喜欢你这种不讲规矩的劲头! 在这 [" + _target_country_name + "], 只有咱们这种人才配活得滋润."
                    ],
                    [
                        "哈哈哈! 我的好兄弟, 你总算来了!",
                        "哈哈! [" + _player_name + "], 你简直就是我的影子! 管他什么狗屁大汗国王, 只要咱们两个联手, 这土地上的一切都是咱们的!",
                        "哈哈! 我的好兄弟 - [" + _player_name + "]! 我要让这片草原听到咱们的名字就发抖！"
                    ]
                ]
            else:
                return[
                    [
                        "[" + _player_name + "], 别以为和平能护住你的脖子, 我早晚要连本带利地讨回来."
                    ],
                    [
                        "又是你这只臭狐狸. 趁我还没决定用马鞭抽你之前, 赶紧消失.",
                        "又是你, 离我远点, 别让我在这和平时期产生什么不该有的念头."
                    ],
                    [
                        "又见面了. 这次你是来送礼的, 还是来送死的?",
                    ],

                    [
                        "哟, 这不是 [" + _player_name + "] 吗? 在那边还没捞够, 又跑来这里来了?",
                        "又见面了, [" + _player_name + "], 在这片平原上, 懂规矩的人才能活得久."
                    ],
                    [
                        "啧, [" + _player_name + "], 你这身行头看起来倒是不错, 可惜穿在你身上浪费了.",
                        "又见面了, [" + _player_name + "], 别跟我谈什么大义, 我只在乎你能给我带来什么."
                    ],
                    [
                        "嘿, 我最喜欢的对手! 比起这群无聊的蠢货，你有趣多了."
                    ],
                    [
                        "哈哈哈! [" + _player_name + "], 快快入座! 咱们这次一定要谈成那笔大的, 把两国那些官老爷都耍得团团转!",
                        "哈哈哈! 你来了, [" + _player_name + "]. 只要咱俩联手，这世界就是咱们的狩猎场!"
                    ]
                ]

func get_battle_chat_charge()-> String:
    return[
        "随我冲过去!",
        "他们的财宝在等着咱们! 随我冲过去!",
        "黑枪之下不留活口!",
        "把他们的阵型冲烂!",
        "全军突击! 谁敢缩在后面, 我就先拿他练斧子!",
        "哈哈哈! 杀戮的时间到了!",
        "别让我失望, 杂碎们",
        "别管什么阵型了! 先冲进营帐的人赏两百德里!",
        "让这些待宰的羔羊见识下什么叫草原的银狼!",
        "哈哈哈! 看看这群受惊的兔子, 全军突击!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "这就是所谓的勇士?",
        "下辈子聪明点吧",
        "啧, 弄脏了我的枪",
        "杀你竟然费了我这么多力气",
        "哈哈哈!",
        "呸, 这种货色",
        "轻松拿下!",
        "这就是你狂妄的代价",
        "啧, 就这点本事也敢来挑战老子?",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "永别了! " + _target_hero_name,
            _target_hero_name + ", 这是你自找的!",
            _target_hero_name + ", 这是和我作对的下场!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "嘶...你这该死的畜生!",
        "血?",
        "敢伤我?",
        "咳...不过是擦破点皮",
        "继续杀!",
        "想杀我?",
        "我要你十倍偿还!",
        "你死定了, 杂碎!",
        "好! 很好!",
        "别在那傻看着! 给我顶上去!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "竟然被这种小计谋...",
        "竟然在这种...穷山沟里...",
        "不可能...",
        "竟然...",
        "我会...在地下...",
        "老子还没...",
        "黑枪...断了...",
        "竟然...在这里栽了跟头...",
        "铁木尔...你这老东西...一定在笑吧...",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "稳步推进! 谁要是敢打乱了老子的阵脚, 当场处决!",
        "别急着冲上去抢钱! 等老子下令再合围!",
        "稳步推进! 只有铁木尔那种脑子里长草的家伙才喜欢乱冲!",
        "保持间距! 我可不想看到有人因为怕死而往后缩!",
        "慢慢的给我把他们堵死在那个角落里!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住阵线! 等他们露出破绽, 我就亲自去摘了他们的狗头!",
        "不要自乱阵脚! 我的斧头还在后面看着呢!",
        "坚守原地!",
        "守住! 别让这些卑贱的东西弄乱了我们的阵型!",
        "哪怕手断了也得给我拿盾顶住!",
        "坚守原地! 等老子看准他们的空当!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "清理战场! 记得把值钱的东西都给我抠出来!",
        "哼, 去确认还有没有财物!",
        "把敌人的旗帜烧了, 看着心烦!",
        "哇哈哈! 这种收割的滋味真是不错",
        "今天的心情不错, 这种碾碎弱者的感觉真让人着迷",
        "去，把最值钱的战利品送到我帐篷里, 其他的随你们分!"
    ].pick_random()

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "看看你现在的德行, 阿尔坦, 哪还有半点贵族的样子?"
        ],
        [

            "阿尔坦, 被五花大绑的滋味如何?"
        ],
        [

            "这下谁来都救不了你了, 阿尔坦."
        ],
        [

            "胜负已分, 阿尔坦, 别再打你那些卑劣的小算盘了."
        ],
        [

            "阿尔坦, 如果你还想活命, 就老老实实待着, 别给我找麻烦."
        ],
        [

            "阿尔坦大人, 放下武器, 你已经输了."
        ],
        [

            "胜负已定, 阿尔坦大人.",
        ],
        [

            "不要再做无谓的挣扎了, 阿尔坦大人",
        ],
        [

            "别瞪我了, 伙计. 我会为你准备最舒适的营帐."
        ],
        [

            "哈哈哈, 我的朋友, 没想到我们会以这种形式会面."
        ],
        [

            "哈哈哈, 看看这是谁?"
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "呸! 比起那些满嘴仁义道德的伪君子, 我更喜欢现在的样子!",
            "你有种现在就杀了我, 否则等我脱困, 我会让你知道什么叫真正的绝望!"
        ],
        [

            "感觉糟透了! 尤其是还要盯着你这张让人反胃的脸!",
            "怎么, 你打算把我当成战利品到处展示?"
        ],
        [

            "在这片草原上, 我阿尔坦从来都只靠自己的这把斧头! 既然这次算错了一步, 我认栽.",
            "只要我的脑袋还在脖子上, 这笔账就没完!"
        ],
        [

            "别在那儿装清高了!"
        ],
        [

            "哼, 只要你马奶酒管够, 我没兴趣和那些发霉的铁栅栏过不去.",
            "那你最好保护好我. 毕竟死掉的阿尔坦大人, 可一个德里都不值!"
        ],
        [

            "啧, 真是倒霉透顶."
        ],
        [

            "不得不说, 你比那些酒囊饭袋领主要强那么一点点. 就那么一点点.",
            "行了, 收起你那副胜利者的姿态!",
        ],
        [

            "切...收起你那副胜利者的姿态!",
        ],
        [

            "既然你这么大方, 那我就勉为其难地当几天客人吧(苦笑)."
        ],
        [

            "哈哈哈! 看来老天爷更喜欢看我出丑."
        ],
        [

            "还能是谁? 草原上最倒霉的银狼, 落入了他最狡猾的狐狸朋友手里!"
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "看什么看? 没见过战败的银狼? 等我出去, 第一件事就是把你这军营烧了!",
            "喂，那边的混蛋! 把我关在这儿每天要耗掉不少口粮吧? 开个价, 我买回我的自由, 这对咱们都好."
        ],
        [
            "咱们干脆点, 说吧, 要多少金币你才肯放我走?"
        ],
        [
            "你是来炫耀胜利的? 省省吧, 在这草原上, 今天你是猎人, 明天可能就是猎物.",
            "行了, 既然我落到你手里, 那你就开个数, 会有人把赎金送来. 别浪费大家的时间, 我还有大买卖要忙."
        ],
        [
            "开个价吧, 只要不太离谱, 我阿尔坦认栽.",
            "听着, 把我关在这里对你一点好处都没有. 开个价, 让我回[" + _target_country_name + "]去",
            "咱们开门见山吧. 我不想在这儿长毛, 你也不想一直派人盯着我. 开个赎金的价格, 只要足够合理.",
        ],
        [
            "真无聊, 你这儿连个能打发时间的玩物都没有吗?",
            "我阿尔坦从不记仇, 我只记账. 那一仗我输在运气不好, 下次可就没这么简单了.",
            "给我弄点好酒来! 别拿那种掺了水的劣质货糊弄我."
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "听着, 我给你 [#{0}] 德里, 算是我买这扇破门钥匙的钱.",
        "你打算把我关到长霉吗? [#{0}] 德里! 咱们这笔烂账就算平了. 毕竟, 死掉的阿尔坦可掏不出半个子儿来.",
        "开个价吧...哦, 我已经替你算好了, [#{0}] 德里. 这笔买卖你稳赚不赔.",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "呸! 这笔买卖老子亏到家了! 把枷锁给老子解开, 你这吸血的臭虫!",
            "[" + _player_name + "], 下次见面时你最好躲在你的士兵后面. 否则我会用荒原黑枪把你这廉价的皮囊捅个对穿!",
            "算你狠, [" + _player_name + "], 这笔烂账我迟早要平掉."
        ],
        [
            "[" + _player_name + "], 咱们走着瞧!",
        ],
        [
            "很好, [" + _player_name + "]. 拿上你的好处, 咱们各走各的路. 下回碰上, 我可不会再大意了!",
            "哼, 这次算老子栽了.",
            "哼, 真是晦气! 给我松绑!"
        ],
        [
            "哼, 你给我记住, [" + _player_name + "]. 下次我一定要从你身上连本带利抢回来!",
            "这次算我倒霉, 掉进了你设的陷阱里. 赶紧把那把绳子解开!"
        ],
        [
            "你这贪婪的混蛋. 我们这么好的交情, 居然还收我的财物! 下次别让我再遇见你!"
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "等一下, 我想再确认一遍. 你真的打算让我这头狼回归草原? 这不符合逻辑!",
            "等等, 这种毫无理由的\"仁慈\"比毒蛇的毒液还要可疑! 你到底在玩什么把戏?"
        ],
        [
            "你确定吗...放我离去? [" + _player_name + "], 你简直比草原上的沙尘暴还要狂野!",
            "你刚才的话, 是认真的吗? 别等我跨出门槛你再反悔, 那样我会先绞断你的脖子"
        ],
        [
            "不需要任何抵押? 不需要任何承诺? 你这脑子是不是在打仗的时候被驴踢了?",
            "我没听错吧? 你真的打算放我走? 连一个德里都不要? 这种赔本的事...真的可能发生?"
        ],
        [
            "等等, 你真的确定不收赎金? 如果你是因为把我当兄弟才这么做, 那我必须说, 你这个决定够狂! 我中意!",
            "你真的决定了? 这种不要命的高尚, 你竟然愿意用在我身上? 你就不怕我回去后再带人杀回来?"
        ],
        [
            "你刚才说...不需要赎金? 你真的确定要用这种方式来诠释我们的交情?",
            "哈哈哈! 你这混球, 是想让我这辈子都欠你的吗? 这种感觉真恶心, 但我喜欢!"
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "哼, 算你识相! 既然你不要钱, 那我就当是捡了个大便宜. 下次在战场上碰到, 我会留你一具全尸作为回礼的!",
            "算你有种! 敢放狼回山. [" + _player_name + "], 咱们的账还没算完. 再会!",
            "这可是你自己选的! 别指望我会多感激你, 在我眼里你只是个不懂做买卖的蠢货. 走着瞧!",
        ],
        [
            "既然你执意要做这个\"圣人\", 那我就不客气了! 再见了, 奇怪的家伙.",
            "这种\"仁慈\"真让我恶心, 但既然能白捡一条命, 我也没理由拒绝. 这一局算你赢了, 但别指望我下次会放过你."
        ],
        [
            "够爽快! 虽然我觉得你蠢得无可救药, 但这种气魄确实少见. 再见了.",
            "这份情我阿尔坦领了! 以后在草原上若是遇到麻烦, 提我的名字 - 虽然可能更招麻烦, 但起码说明咱俩是一路的! 哈哈哈!"
        ],
        [
            "我没看错你, [" + _player_name + "]. 你虽然脑子不太清醒, 但手脚和胆量都够硬, 再见了.",
            "嘿, 你这种疯劲儿倒挺合我的胃口. 再见了.",
            "你这人真有意思. 连本大爷这种\"祸害\"都敢放, 全天下恐怕只有你一个! 再见了!",
            "虽然你这人有时候死脑筋, 但这次做得漂亮! 再见了!"
        ],
        [
            "哈哈哈! [" + _player_name + "], 我的好友! 只有你敢这么对我! 后会有期!",
            "这感觉比喝了一桶烈酒还让人热血沸腾! 你放走了我的人, 却收走了我的心...呸, 真恶心! 走了! 别死在别的软蛋手里!"
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "啧, 这件 [#{0}] 归你了, 赶紧把这该死的枷锁给我解开, 我一刻也不想在这儿多待!",
        "这件 [#{0}] 就当是买我自由的费用了, 拿走它, 然后赶紧把绳子解开!",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "别用那种眼神看着我, 难不成你还指望我把我好不容易抢到的战利品塞进你的口袋?",
        "哼, 打得还算勉强. 要不是看在你今天在草原上帮我挡了一下, 我的荒原黑枪早就连你一起挑了.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "我的狼魂战斧刚劈开缺口, 你就急着冲上来分一杯羹.",
        "你表现得还算勇猛, 我也不会亏待你. 但该是我的, 你一毛也别想拿走.",
        "哼, 没死在乱军之中算你命大. 你也算有点能耐, 下次有捞大钱的买卖再叫上你."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 老搭档. 这次配合得真不赖.",
        "痛快! 我的狼魂战斧今天又多了无数的手下败将.",
        "啧啧, 你看看你那狼狈样. 你可别死太早, 整个草原上也就你这家伙能让我瞧着顺眼点.",
    ]