extends LordBrutalDialogue

const HERO_UID: = "lord_hero_0007"

func _get_granted_fief_clist()-> Array:
    return[
        "以吾之名, 赐予你对 [#{0}] 的支配. 你可以利用它来收缴财富, 招募军队. 这是力量, 也是枷锁. 只要你忠诚, 你将会获得越来越多的财富. 若你背叛，无人能救赎你."
    ]


func _get_attendant_meet_content()-> Array:
    return[
        {
            "clist": [
                "止步, 旅人. 前方是哈斯卡尔之主 - [#{b_leader_name}] 陛下的御营. (声望过低, 国王拒绝接见)",
                "前方是 [#{b_leader_name}] 的军阵. 未经召见者, 不得再近一步. (声望过低, 国王拒绝接见)",
                "未经通报者不得接近陛下, 请自重. (声望过低, 国王拒绝接见)",
                "[#{b_leader_name}] 陛下正率军行进, 请保持距离. (声望过低, 国王拒绝接见)"
            ]
        }
    ]


func _king_reject_join_low_reputation_dialogue()-> Array:
    return[
        "朕见过许多自称勇士的人, 他们的骨头 - 如今都埋在沙漠之下. " + LOW_REPUTATION_TIP,
        "朕审视过你的道路, 太平缓, 太干净. 哈斯卡尔的沙中，不埋葬平凡者. " + LOW_REPUTATION_TIP,
    ]



func king_reject_join_rel_bad_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        "只有最锋利的屠刀才配为朕效力. 而你? 不过是一柄生锈的废铁. 朕的战争不需要累赘, 滚出朕的视线!",
        "朕的国家不需要一个随时准备反噬主人的毒蝎. 你过去的所作所为足以让你死上一百次. 滚吧! 别再考验朕的耐心."
    ]


func _king_agree_join_low_reputation_dialogue()-> Array:
    return[
        "#{a_leader_name}! 你经受了沙与火的洗礼，证明了自己的血不惧灼烧. 你配得上帝王的注视! 朕赐你名分, 也赐你考验. 哈斯卡尔王国之光, 既能照耀, 也能焚毁!"
    ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "谁允许你插手朕的战争? 你的出现只是打乱了朕的计划, 下次再敢如此, 朕会让你后悔降生!",
        "你那点可笑的战绩, 只会让朕更厌恶你. 现在, 滚回你的阴沟里去.",
        "朕的战斗不需要你这种渺小的帮助. 退下! 如果你还想活着看到明天的太阳."
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你很清楚如何取悦朕, 但你的贡献还不够.",
        "这次的战斗, 你贡献的价值还不够. 继续证明你自己.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "瞧瞧，朕的好友竟然毫发无伤地回来了. 是在后方欣赏朕横扫战场的英姿吗?",
        "这次战斗, 你更像是个精致的摆设. 记住, 朕喜欢主动出击的利刃.",
        "朕的炽阳战斧已经饮饱了鲜血, 而你的剑却如此干净, 这让朕有些为难啊."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "朕承认, 你比朕想象的更有价值. 朕给你一次机会, 继续证明你的忠诚. 记住, 这是朕对你的恩赐, 不是你的权利!",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "这次的援助非常及时且高效. 朕对你的表现感到满意. 去吧, 朕的目光会一直注视着你.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你为朕带来了无可争议的胜利! 你将享有与朕同等的荣耀!"
    ]


func _get_battle_thank_first_meet_clist()-> Array:
    return[
        "我是 [#{0}] 的国王 - [#{b_leader_name}].",
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "你想清楚了吗? 帝王的仁慈早已在黄沙中磨灭, 而他的谨慎意味着他会彻底拔除每一根胆敢触碰他的刺. 你确定要成为其中之一?"
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "今天, 我要把阿舒兰的王座拆了当柴烧!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "嗝~ 酒! 这酒里一定是掺了沙毒! 我竟然疯狂到对\"沙漠之阳\"拔剑. 饶恕我这个卑微的酒鬼吧, 我的血太臭, 不配弄脏您的土地!"
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["你竟敢用这卑微的铁片指着太阳? 很好, 朕会亲手切开你的喉咙, 让你的血在沙地上冒烟. 你确定要尝试被活活烤焦的滋味吗?"],
        ["朕会把你的皮剥下来, 填满沙子挂在边境. 你确定要向朕和 [" + _target_country_name + "] 发起挑战?"],
        ["你要向朕挑战? 想清楚, 我的刀下从无活口. 一旦开战, [" + _target_country_name + "] 的沙暴会吞噬你最后一名部下. 你准备好面对这残酷的烈日了吗?"],
        ["伙计, 你的胆量已经超越了你的智商. 把剑收回去, 沙漠之阳今天不想被凡人的鲜血弄脏."],
        ["朕视你为有价值的朋友, 你却要在朕的王座前自寻死路? 这一步跨出, 你将会变成一具腐烂的干尸. 你真要这么做?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["来啊! 只要你敢动手, 那份停战协议就会像枯草一样被战火焚烧. 朕会亲自率军踏平你的国家, 让你的子民在哀嚎中死去. 你确定要开启这扇死亡之门?"],
        ["收起你那无知的挑衅, 小卒子. 这一剑下去，两国边境将变成真正的炼狱. 你真的打算让万千性命在这烈日下化为脓水?"],
        ["站住. 你代表的是你的国家. 这一步踏出, [" + _target_country_name + "] 的铁甲将如沙暴般碾过你的每一寸领地. 你确定要让你的家园为你瞬间的癫狂陪葬吗?"],
        ["朕的老朋友, 你似乎忘记了沙漠的残酷. 这种毫无胜算的冲突只会让你输得一干二净."],
        ["朕视你为平等的盟友, 你却要在朕的圣殿前背弃誓言? 开战后, 你将亲眼看到你的领土如何化为废墟. 你真要毁掉这一切?"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["好! 朕会把你的士兵作为献给烈日的祭品! 死吧, 杂碎!"],
        ["既然你执意求死, 那朕就成全你. 朕会让沙漠里的秃鹫记住你的味道."],
        ["路是你自己选的. 既然想被埋在沙漠下, 朕就成全你! 全军冲锋!"],
        ["蠢货! 朕会亲手挖出你的心脏. 这就是挑衅朕的下场!"],
        ["你辜负了朕对你最后的怜悯. 你马上会成为沙漠里一堆多余的骸骨!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["毁灭的时间到了! 朕会让你的城市变成一片死寂的沙丘! 进攻!"],
        ["你不仅是个蠢货, 还是个无可救药的罪人. [" + _target_country_name + "] 的铁骑, 踏平他们!"],
        ["既然和平无法让你安分, 那就让无尽的战争将你淹没. 受死吧!"],
        ["你亵渎了和平的价值, 那就用你举国的鲜血来洗刷这份耻辱吧!"],
        ["背誓者的下场只有一个 - 死在最酷烈的阳光下! 全军突击!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [
            "朕就知道你会来领死! 朕会把你的头骨做成酒杯, 装满你臣民的血!",
            "看来你还没尝过被烈火灼烧灵魂的滋味. 既然你主动跳进朕的炼狱, 朕保证, 会让你在死前求着朕杀掉你!"
        ],
        [
            "[" + _target_country_name + "] 的勇士们! 把这些肮脏的沙虫全部踩成肉泥!",
            "朕正愁这炽阳盾上的金漆有些暗淡, 没想到你主动送来了新鲜的涂料."
        ],
        [
            "你将看不到明天的太阳! 全军突击!",
            "朕一直相信, 杀戮也是一种艺术. 既然你主动要求成为朕的下一件作品, 朕又怎能让你失望?",
            "朕的炽阳战斧从不斩无名之辈. 既然你执意要让你的名字消失在史书里, 那朕便成全你这份愚蠢."
        ],
        [
            "作为对手, 你的傲慢令我兴奋. 朕会用最残忍的方式终结你的生命!",
            "既然你想死在沙场上, 朕会赐予你一个烈日下最绚烂的终焉!"
        ],
        [
            "这就是宿命. 既然我们无法并存, 那就让黄沙掩埋你的尸首. 杀!!"
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["在这种烈日般的杀意面前动手确实是疯了. 我收手."],
        ["我收手, 敬畏是面对沙漠之阳最理智的选择."],
        ["这笔账怎么算都划不来, 我不打了."],
        ["呼...可能是被这沙漠的热浪冲昏了头, 我这就消失"],
        ["既然还没见血, 刚才的疯狂就到此为止吧."],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["你说得对, 我不该为了瞬时的愤怒让子民化为灰烬."],
        ["我不想在这烈日下背负毁灭文明的罪责. 这次是我失礼了."],
        ["你说得对, 我不该让我的国家为我瞬间的癫狂陪葬."],
        ["确实, 我没必要执迷不悟."],
        ["我现在还不能毁掉这一切, 告辞."],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 朕的沙海不留活口, 你的骨头将成为这片荒漠最卑微的尘埃. 跪下, 受死!"],
            ["你就是 [" + _player_name + "] 吧. 敢在朕的帝国惹麻烦, 看来你还没尝过被烈日灼烧灵魂的滋味. 朕会让你后悔出生在这世上."],
            ["你就是那个浪人 [" + _player_name + "]? 通缉令是朕给你的葬礼邀请函. 既然见到了朕, 就别再幻想能看到明天的太阳."],
            ["你就是 [" + _player_name + "] 吧. 听闻你对那些贱民施舍过仁慈? 愚蠢的善行. 作为奖励, 朕会赐你一个没有痛苦的黄昏."],
            ["你就是 [" + _player_name + "] 吧. 能让朕亲自出征捕获, 你也算不枉此生了. 来, 展现你的全部, 否则这片沙海会觉得太无趣."],
        ]
    else:
        return[
            ["[" + _player_name + "], 你居然还敢在朕的影子里爬行? 这一次, 朕会亲手打碎你的每一块骨头, 让你求死不得."],
            ["又见面了, [" + _player_name + "]. 朕的耐心已如流沙般流尽. 跪下领赏(死刑), 或者被朕拖在马后风干成干尸."],
            ["[" + _player_name + "], 沙漠从不放过迷途的羔羊. 既然你逃走后又回来投网, 那朕就收下你的命."],
            ["还没学会敬畏吗, [" + _player_name + "]? 既然你执意回来, 那就准备接受制裁吧."],
            ["哈...又是你, 宿命中的猎物 - [" + _player_name + "], 你的血在沙子里流淌的声音一定很悦耳. 别让朕等太久, 攻过来!"],
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧. 当初你竟敢在朕的国土上肆意妄为, 如今披上皮成了 [" + _player_country_name + "] 的领主, 就以为朕会忘记你的罪孽? 正好, 朕会亲手将你这名号连同你的骨头一起碾碎."],
            ["你就是 [" + _player_name + "] 吧. 既然身为领主, 就该懂得对未知的力量保持敬畏. 你在边境那些冒犯朕的行为已触及底线, 这片沙海将不再容纳你的呼吸."],
            ["你就是那个 [" + _player_name + "]? 听说你加入了 [" + _player_country_name + "]. 既然你以敌国领主的身份出现在朕的猎场, 那你的领地和性命, 朕就一并收下了."],
            ["你就是 [" + _player_name + "] 吧. 朕听闻你曾在沙漠中帮助过朕的子民? 那份仁慈在战争面前一文不值. 为了奖赏你的勇气, 朕会赐予你一个没有痛苦的黄昏."],
            ["呵呵...你就是那个被传诵的 [" + _player_name + "] 吧. 来吧, 让朕看看, 你的血是否能让这片沙海稍微凉爽一些."],
        ]
    else:
        return[
            [
                "[" + _player_name + "], 又闻到你那令人作呕的气息了. 这一次, 朕要让你风干在烈日之下.",
                "呵呵, [" + _player_name + "]. 你的哀鸣似乎比风沙声更加悦耳. 既然你如此迷恋这片战场, 朕不介意亲手把你削成枯骨, 立在边境作为永恒的界标."
            ],
            [
                "又见面了, [" + _player_name + "]. 朕的耐心已如漏沙般流尽, 你的存在只会玷污这片纯净的荒漠. 既然你执意要在朕的影子里挣扎, 那就去冥界寻找你的贵族体面吧.",
                "又见面了, [" + _player_name + "]. 朕这就用炽阳战斧, 为你举行一场盛大的葬礼."
            ],
            [
                "[" + _player_name + "], 沙场之上, 宿命难违. 既然你再次代表 [" + _player_country_name + "] 挡在朕的马前, 那就把你的荣耀永远留在土里吧.",
                "[" + _player_name + "], 游戏结束了. 既然在这儿遇上, 那就把你的国家和尊严, 一并献祭给朕的炽阳盾吧."
            ],
            [
                "还没走远吗, [" + _player_name + "]? 朕本想让你多活几个日落. 既然你执意回来送死, 那朕就收下你这忠诚而愚蠢的灵魂.",
                "朕的好友, 瞧瞧你那惊慌的样子, 真是狼狈得令人心疼. 如果可以，朕真想把你关在金色的笼子里观赏，而非在这儿将你撕碎. 可惜...战场不认交情. 拔剑吧."
            ],
            [
                "哈...又见面了, 朕最钟爱的猎物. 在这个世界上, 唯有你的反抗能让朕感到一丝愉悦. 攻过来, [" + _player_name + "]. 让这场勇者间的杀戮, 成为沙漠之阳最绚烂的祭礼!",
                "[" + _player_name + "], 待会战斗的时候别死得太快, 朕还没欣赏够你垂死挣扎时的美感呢!"
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["通缉犯 [" + _player_name + "], 你这卑贱的余孽竟敢站在朕的影子里? 朕本该现在就挖出你的心脏祭奠烈日, 但今日朕的刀锋要留给更有价值的祭品. 在朕改主意前, 滚回你的沙洞去!"],
            ["这种充满恶臭的灵魂...你就是那个名为 [" + _player_name + "] 的窃贼? 杀你甚至会脏了朕的土地. 朕今日不愿在大战前夕为你这种渣滓停下征战的脚步. 滚!"],
            ["[" + _player_name + "], 朕听闻过你的名字. 一个在法理之外挣扎的死囚. 今日抓捕你所消耗的箭矢, 在朕眼中比你的命更贵. 滚出朕的视线, 立刻."],
            ["[" + _player_name + "], 朕认得你, 能在哈斯卡尔的通缉下活到现在, 你比朕想象中要顽强. 朕今日心情尚可, 暂且准许你继续在烈日下苟延残喘. 带上你的部下, 滚吧."],
            ["喔? 你就是那个闹得沸沸扬扬的恶徒 [" + _player_name + "]? 在 [" + _target_country_name + "], 没人敢直视朕的眼睛. 你的狂妄让朕感到愉悦, 朕准许你活到下一次日落."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["朕的恩典不是你反复挑衅的护身符. 滚!"],
                ["怎么, 你就这么急着想看看朕的刑具吗?"],
                ["还有什么废话? 朕的耐心已如烈日下的水滴, 所剩无几."],
                ["滚吧, 别让这份短暂的慈悲变成你的葬礼."],
                ["还有什么事吗? 快滚吧."],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你以为沙漠的辽阔能洗清你的罪孽? 若非朕正领兵奔赴杀戮之地, 今日便是你化为焦炭之日! 立刻消失!"],
                ["又在朕的疆域内徘徊吗, [" + _player_name + "]? 你这罪人就像沙漠里挥之不去的秃鹫. 趁朕的圣裁还没降下, 滚!"],
                ["又是你. 只要你像沙尘一样安静地滚开, 朕暂且准许你继续呼吸."],
                ["[" + _player_name + "], 虽然你依旧是 [" + _target_country_name + "] 的罪人, 但朕依然愿意给你一次作为战士死在战场上的机会. 滚去磨利你的剑."],
                ["又见面了, 朕最有趣的猎物 - [" + _player_name + "], 保重身体, 朕期待着亲手清算你的那一天."],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["朕嗅到了腐肉的气息...原来是你, [" + _player_name + "]. 主动追上来献祭? 很好, 朕等着用战斧一寸寸切断你的傲慢, 让你在焦土上哀嚎至死."],
            ["你就是 [" + _player_name + "]. 你这种不依不饶的纠缠, 简直让朕感到作呕. 像你这种卑微的生灵, 本该在阴影里苟活, 却非要来直视烈日的威严."],
            ["名动边境的 [" + _player_name + "], 终于肯露面了吗? 你截断朕的归途, 想必是算准了时机. 直言吧, 你是想要一场让你声名扫地的惨败, 还是想在朕的炽阳盾前, 跪下来谈谈你的赎金?"],
            ["竟然在此处遇见了你, [" + _player_name + "]. 传闻你的手段和朕一样不留余地, 这真让朕感到愉悦. 虽然旗帜不同, 但朕不舍得让你太快化为灰烬. 怎么, 不打算在此刻与朕共赏这一场血色的落日吗?"],
            ["哈哈哈! 这股炽热的杀意, 唯有你 [" + _player_name + "] 才配拥有! 来吧, 用你的全部痛苦来取悦朕!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["你是在为自己的葬礼挑选时辰吗?"],
                ["滚出朕的视线!"],
                ["你是想尝试被炽阳战斧抽干全身血液的滋味吗?"],
                ["你在等什么? 等风沙掩埋你的恐惧, 还是等朕露出所谓的破绽?"],
                ["别像只垂死的鬣狗一样在朕身后徘徊!"],
            ]
        else:
            return[
                [
                    "又是你. [" + _player_name + "], 你那贪婪的眼神让朕想要亲手挖出它.",
                    "[" + _player_name + "], 如果你急着让朕切开你的喉咙, 那就上来试试吧."
                ],
                [
                    "[" + _player_name + "]! 这种无止境的追逐让朕感到厌烦. 既然你追到了这里, 是准备好让你的骨头在烈火中炸裂了吗?",
                    "[" + _player_name + "], 你这只被贪婪蒙蔽的猎犬. 朕还没去惩罚你对帝国的亵渎, 你竟敢主动追到朕的斧刃之下?"
                ],
                [
                    "又见面了, [" + _player_country_name + "] 的猎犬. 告诉朕，你想要的是一场史诗般的毁灭, 还是某种阴暗的交易?",
                    "[" + _player_name + "], 如果你认为此时的朕是一头垂老的狮子, 那你就大错特错了."
                ],
                [
                    "[" + _player_name + "], 作为对手, 你对死亡的嗅觉真是敏锐. 虽然立场不同, 但朕仍不舍得毁掉一个完美的对手. 你确定要打破这份平衡, 向朕挥动你的剑吗?",
                    "[" + _player_name + "], 既然你已经在这儿截住了朕, 那便说明你已经做好了承担后果的觉悟.",
                    "[" + _player_name + "], 既然你已经追到了这里, 朕不介意赐予你一个最尊贵的死法."
                ],
                [
                    "朕的宿敌! 你每一次抵近都让空气变得更加甜美. [" + _player_name + "], 你是想现在就开始这场血色的洗礼吗?",
                    "[" + _player_name + "], 咱们就别再玩捉迷藏了, 告诉我, 你是在寻找死神的拥抱吗?"
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["朕乃阿舒兰, [" + _target_country_name + "] 的唯一主宰. [" + _player_name + "], 你在绿洲骚扰我国子民的行径让朕感到厌恶. 朕从不宽恕冒犯朕之秩序的蝼蚁, 若非朕今日无暇清理污垢, 你的首级此刻已挂在炽阳战斧之上."],
            ["朕乃阿舒兰, 沙漠之阳. [" + _player_name + "], 朕嗅到了你身上那种卑微而贪婪的气息. 收起你的小聪明, 否则朕会让这片沙海成为你永恒的囚笼."],
            ["朕乃阿舒兰, 此地至高无上的帝王. [" + _player_name + "]. 能在沙漠之阳的注视下依然挺直脊梁, 说明你并非庸才."],
            ["朕乃阿舒兰. [" + _target_country_name + "] 的统治者, [" + _player_name + "], 朕听闻你护下了朕的子民. 虽然你身份卑微，但这身武艺倒有些价值."],
            ["朕乃阿舒兰, 万沙之主. [" + _player_name + "], 你那满身杀伐的气息真让朕愉悦. 这世间尽是些软弱的蠢货，唯有你这种狠辣的人物才配站在朕的身侧."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["你还不离开? 是等着我降下天罚吗?"],
                ["朕的秩序不容亵渎. 再不退下, 朕便让你见识何为炽阳的怒火."],
                ["炽阳盾影之下从无秘密. 不要耍小聪明."],
                ["[" + _player_name + "], 朕正在权衡你的价值."],
                ["那种对力量的渴望, 正是朕所欣赏的."],
            ]
        else:
            return[
                ["罪徒, 你竟敢再次直视太阳. [" + _player_name + "], 那些被你掠夺者的哀嚎依然在沙风中回响. 朕恨不得立即抽干你的血, 给朕消失!"],
                ["[" + _player_name + "], 你依然在用你那廉价的性命挑战朕的容忍度吗？"],
                ["[" + _player_name + "], 沙海流转, 我们又见面了."],
                ["很高兴再次见到你, [" + _player_name + "], 你的剑刃依然闪烁着那股令朕满意的戾气."],
                ["你终于回来了! 快随朕入帐, 让朕听听你在远方又毁灭了哪些不自量力的部落!"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                [],
                [],
                [],
                [],
                []
            ]
        else:
            return[
                ["朕乃阿舒兰, [" + _target_country_name + "] 的唯一真神. 异国的领主, 你身上那股陈朽的气息让朕的沙漠感到窒息. 即便此时戈矛暂歇, 朕也已在心底为你选好了墓地."],
                ["初次见面, [" + _player_country_name + "] 的 [" + _player_name + "]. 在这片烈日照耀的土地上, 收起你那拙劣的伪装, 否则朕的炽阳盾会拍碎你所有的幻想."],
                ["朕乃沙漠之阳阿舒兰. 异国的使者, 你是带着诚挚的贡品来寻求庇护, 还是带着你那可笑的君主的口信来滋扰朕的宁静?"],
                ["欢迎你, 远方的强者. 朕听闻即使在 [" + _player_country_name + "], 你的名声也如烈日般夺目"],
                ["哈哈哈! 久仰大名, 异国的猛虎! 像阁下这样的人才, 竟然屈居于那个软弱的国度, 真是明珠蒙尘."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["趁吾还没有动怒前, 赶紧离开."],
                ["朕不想再看到你这张脸."],
                ["还有何事?"],
                ["看来你对朕的教诲意犹未尽?"],
                ["还有何要事?"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "[" + _player_name + "], 如果你还想保住你那领主的虚名, 就滚回你的领地, 像死人一样保持安静."
                    ],
                    [
                        "又是你, [" + _player_name + "]. 朕教过你, 领主应当是猎鹰, 而非只会讨食的鬣狗.",
                        "朕最近听到一些关于你领地的传闻, [" + _player_name + "], 那可不太悦耳.",
                        "又见面了, [" + _player_name + "], 如果你依然执迷不悟, 朕不介意把你的领地分给更懂得顺从的人.",
                        "[" + _player_name + "]. 如果你不能展现出你的价值, 那朕为什么要留着一个只会消耗粮食的废物?"
                    ],
                    [
                        "[" + _player_name + "], 朕在微笑时, 你应当感到恐惧.",
                    ],

                    [
                        "朕的封臣, 记住, 在那里的每一寸沙土, 归根结底都姓阿舒兰."
                    ],
                    [
                        "[" + _player_name + "], 看到你依然保持着这份忠诚, 朕深感欣慰.",
                        "[" + _player_name + "], 你比那些只会送死的蠢货聪明得多. 继续保持这份谨慎."
                    ],
                    [
                        "哈哈哈! 朕的利刃, 你归来的正是时候!",
                        "[" + _player_name + "], 朕喜欢你这种不留活口的风格, 继续为朕清扫障碍吧."
                    ],
                    [
                        "呵呵, 朕最忠诚的利爪, 你终于回来了.",
                        "[" + _player_name + "], 别去理会那些弱者的哀求. 随朕去征服吧, 朕会和你分享那最炽热的荣光.",
                        "朕的利刃, 朕的影子. 在这个充满背叛的世界里, 唯有你让朕感到了久违的信任."
                    ]
                ]
            else:
                return[
                    [
                        "又见面了, [" + _player_name + "]. 在朕的杀意失控前, 滚出这片沙漠."
                    ],
                    [
                        "[" + _player_name + "], 朕曾见过无数像你这样狂妄的异国人, 最后他们都成了沙丘下无名的枯骨.",
                        "来自 [" + _player_country_name + "] 的领主, 你的傲慢比正午的阳光还要刺眼."
                    ],
                    [
                        "又见面了, [" + _player_name + "]. 你那点阴谋诡计在朕的炽阳下简直无所遁形."
                    ],

                    [
                        "我们又见面了, [" + _player_name + "]"
                    ],
                    [
                        "呵呵, 欢迎你, [" + _player_name + "]. 朕喜欢和聪明人打交道.",
                        "又见面了, [" + _player_name + "], 朕的直觉告诉朕，你和我是一类人."
                    ],
                    [
                        "又见面了, 异国的强者. 能见到一个朕欣赏的对手，真是令人愉悦."
                    ],
                    [
                        "哈哈哈! 朕的劲敌! 每次见到你, 朕体内的血都在沸腾!"
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "炽阳盾所向之处, 皆为焦土! 冲锋!",
        "直视朕的光辉吧, 凡人! 然后在哀嚎中化为灰烬!",
        "去吧! " + _country_name + "的勇士们!",
        "全军突击! 让这片沙海记住朕今日的怒火!",
        "突击! 朕准许你们收割这些卑微的灵魂!",
        "慢慢感受这焚身之痛吧!",
        "全军! 肃清逆贼!",
        "杀进去!",
        "洗净这片土地上的忤逆之人!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "这就是挑战帝王的代价",
        "太弱了...",
        "一具失去灵魂的躯壳",
        "朕亲自赐予你死亡!",
        "你应该跪下谢恩"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "永别了! " + _target_hero_name,
            _target_hero_name + ", 这是和我作对的下场!",
            "这就是你的宿命, " + _target_hero_name
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "敢伤我?",
        "流血了?",
        "敢触碰朕的圣体?",
        "保护朕!",
        "有趣...",
        "敢溅污朕的圣袍?",
        "嘶...这道伤口...",
        "朕要亲手埋葬你!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "日落了...",
        "朕的帝国...",
        "炽阳...终会...",
        "竟然...毁在这些...",
        "夕阳...终究要带走...",
        "朕...即是太阳...",
        "沙漠...终会归于..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "每推进一步, 都要让敌人感受到窒息的绝望!",
        "保持阵型!",
        "节奏不要乱!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "保持阵型! 朕的目光在注视着你们!",
        "不要为了贪功而露出破绽! 朕不需要鲁莽的死人!",
        "不要惊慌! 守住!",
        "莫要自乱阵脚!",
    ].pick_random()

func get_battle_chat_vectory()-> String:
    var _country_name: String = _get_country_name()

    return[
        "呵呵...这就是违抗朕的下场",
        "把战俘丢进大漠中心!",
        "清扫战场. 朕不希望看到任何生还的火种!",
        "这就是" + _country_name + "的威严!",
        "朕感到愉悦...",
        "哈哈哈! 这就是冒犯朕的唯一结局!",
        "这就是" + _country_name + "的力量!",
        "这些败者的尸首, 就留给秃鹫作为午餐吧"
    ].pick_random()

func get_leave_country_king_confirm_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_name()

    return[
        [
            "朕的恩慈已经到头了. 走出这道门, 你就是朕的猎物. 在朕把炽阳战斧架在你脖子上之前, 你想清楚了再说 - 你确定要走?",
            "[" + _player_name + "], 你这身肉如果晒成干, 一定很有趣. 想离开朕的秩序? 可以, 只要你做好了面对\"沙海清算\"的准备. 你确定要试一试?"
        ],
        [
            "脱下 [" + _target_country_name + "] 的甲胄, 你不过是沙漠里一粒卑微的尘土. 失去了朕的庇护, 你觉得你能活过几个日落? 朕再给你最后一次机会, 收回你的话.",
            "朕不喜欢背叛者的桥段. 如果你现在收回那句愚蠢的请求, 朕可以当做那是沙毒入脑的胡言乱语. 你当真要解开誓言?",
        ],
        [
            "你想走? 那就意味着你要放弃在这里经营的一切. 在这片烈日照耀的土地上, 没有朕的许可, 你寸步难行. 你真的想好了?"
        ],
        [
            "[" + _player_name + "], 这世上可没有后悔药吃. 一旦契约斩断, 你我之间那点微薄的信任就会像干枯的草叶一样粉碎. 你确定要放弃你的封地和名望?",
            "朕的战事正如火如荼, 你却要在此刻离开? 朕不喜欢这种不稳定的因素. 在朕决定是否要肃清你之前, 给出你最终的答复.",
            "想去寻找更凉爽的绿洲? 呵, 只怕那里埋着更深的陷阱. 最后确认一遍, 你真的打算背弃 [" + _target_country_name + "] 的旗帜吗?"
        ],
        [
            "朕的好友, 这一定是某个卑劣的间谍挑拨了我们的关系. 这沙漠之大, 除了朕的身侧, 还有哪里能容纳你的野心? 你真的忍心让朕失望?",
            "你是朕最得意的利剑, [" + _player_name + "]. 朕不准许任何有价值的东西离开朕的影子. 你刚才那句话, 朕权当没听见...你确定非要再说一遍吗?",
            "呵呵, 真是个爱开玩笑的坏孩子. 如果你走了, 朕可能会伤心得踏平你的每一个藏身之处. 乖一点, 留在朕的影子里, 好吗?"
        ]
    ]

func get_leave_country_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "呵呵...很好. 在这片沙海中, 只有死人能真正自由. 脱掉你的甲胄滚吧, 朕会看着秃鹫如何拆解你的傲慢.",
            "这大概是你这辈子做过最勇敢, 也最愚蠢的决定. 滚出朕的视线, 趁朕还没决定把你做成活干尸挂在城门上.",
            "朕的慷慨从未施舍给叛徒. 既然你选择了背弃誓言, 那就祝你能活到下一个日落. 滚!"
        ],
        [
            "朕准许了. 交出你的权柄, 然后消失. 下一次在战场相见, 朕会亲手削下你的首级."
        ],
        [
            "契约已断. 从这一刻起, 你不再是朕的封臣, 而是这片沙漠中最微不足道的猎物. 好自为之吧.",
        ],
        [
            "朕原本对你寄予厚望, 你却选择了背叛这份信任. 可惜... 去吧, 希望你以后不会死在朕的战斧下."
        ],
        [
            "呵呵呵...朕最宠爱的利刃, 竟也要离朕而去了. 真是让朕心碎啊. 走吧, 但在朕亲手折断你之前, 可别死在别人手里.",
            "这可真是个令人遗憾的结局. 既然你去意已决, 那朕也不拦你. 但朕会一直注视着你."
        ],
    ]

func get_leave_country_cancel_king_response_content()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "既然还没准备好迎接死亡, 就给朕拼命地活下去, 直到朕厌倦你的那一天."
        ],
        [
            "呵, 聪明的决定.",
            "既然留下了, 就给朕滚回你的领地, 别再让这种愚蠢的念头挑战朕的耐心."
        ],
        [
            "算你识相, 但记住, 朕的宽容是有限度的.",
            "哼. 既然留下了, 就用更多的敌人鲜血来洗刷你刚才的冒犯. 退下吧."
        ],
        [
            "明智之举. 只要你继续维持你的价值, 朕可以当做刚才什么都没发生.",
            "很好, 契约依然有效. 希望你之后的表现能配得上你此刻的\"理智\".",
            "别再玩这种让朕不悦的试探游戏了."
        ],
        [
            "呵呵, 朕知道你只是醉了, 才会说出这种胡言乱语.",
            "这就对了, 朕的好部下. 外面的沙暴太猛烈, 只有待在朕的影子里, 你才是安全的.",
            "这才是朕熟悉的你. 哪怕是短暂的迷失, 朕也可以原谅. 谁让你是朕最完美的武器呢?"
        ],
    ]

func king_reject_join_recent_leave_country_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "呵呵...[" + _player_name + "], 你这只在沙坑里跳来跳去的跳蚤. 刚逃离朕的影子, 又想回来寻找庇护? 滚! 否则你就是下一块磨刀石!",
            "你把帝国的誓言当成了什么? 路边的枯草吗? 既然你选择了离开, 那就彻底消失在风沙里. 朕的国家不需要一个随时准备开溜的野兔.",
            "朕见过许多愚蠢的背叛者, 但像你这样急着回来领死的, 确实少见. 趁朕还没决定把你做成干尸, 滚回你的阴沟里去."
        ],
        [
            "朕的恩慈不是为了施舍给你这种反复无常的流浪汉. 你离开时的背影还没被沙尘掩埋, 现在就想回来? 真是令人作呕.",
            "[" + _target_country_name + "]的旗帜下只招收坚韧的磐石, 而非你这种随风飘荡的细沙. 想回来? 先去烈日下暴晒七天, 洗净你身上的叛徒味再说.",
            "朕讨厌不稳定的因素. 你这种把效忠当儿戏的行为, 让朕觉得你的脑袋并不适合留在脖子上. 滚开."
        ],
        [
            "如果你认为朕的耐心如沙漠般广袤, 那你就大错特错了. 契约才刚刚断裂, 朕还没准备好接纳一个\"前任\"叛徒. 滚吧.",
            "[" + _player_name + "], 你太心急了. 在这种多变的行为背后, 朕只看到了背叛的潜质. 在下一次日落前离开朕的视线, 朕现在不想谈论效忠.",
            "哪怕是沙漠里的蝎子也知道守住自己的洞穴. 你这种朝三暮四的行为, 让朕很难相信你的价值. 过阵子再来展示你的忠诚吧.",
        ],
        [
            "呵呵, 你这玩笑开得有些过火了. 刚推开朕的手, 现在又要跪下亲吻朕的袍角? 这会让朕的士兵们感到困惑的. 去荒野里冷静一下吧.",
            "你的行为像极了被沙毒冲昏头脑的旅人. 既然你执意要在外面闯荡, 那就多闯荡几日. 朕这里的位置, 暂时不给立场动摇的人.",
            "朕欣赏你的武艺, 但朕更厌恶你的反复. 回去吧, 等你真正明白\"忠诚\"二字的重量, 再来向朕乞求名分."
        ],
        [
            "我的孩子, 你刚从朕的影子里溜出去, 就被外面的烈日灼伤了吗? 呵呵...不过, 朕还没原谅你那次任性的离去. 先在外面待着, 朕要看着你如何在绝望中怀念朕的恩宠.",
            "哦? 朕完美的利刃竟然想念它的剑鞘了? 可惜, 朕现在正忙着欣赏你的狼狈. 再多流浪些时日吧, 当你在风沙中快要枯萎时, 朕也许会考虑重新收留你.",
            "嘘...别急着说话. 你离去时那道伤口还没愈合, 朕怎么能确定你现在的效忠不是另一种背叛? 去吧, 朕会一直注视着你, 直到你真正学会如何当一只听话的猎犬."
        ]
    ]

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "太阳落山了, 阿舒兰. 我会让你呆在最深的地牢里, 永远见不到你那引以为傲的烈日."
        ],
        [

            "阿舒兰, 被五花大绑的滋味如何? 今天也让你体验一下当囚犯的滋味"
        ],
        [

            "感觉如何? 阿舒兰陛下, 这种被你蔑视的力量反噬的滋味."
        ],
        [

            "阿舒兰陛下, 你也会有失手的时候."
        ],
        [

            "阿舒兰陛下, 现在你只是一个输光了筹码的赌徒."
        ],
        [

            "胜负已分, 阿舒兰陛下",
        ],
        [

            "不要再做无谓的挣扎了, 阿舒兰陛下"
        ],
        [

            "别用那种看死人的眼神盯着我, 阿舒兰陛下. 既然命运让你落入我手, 那就放下你的傲慢."
        ],
        [

            "胜负已定, 阿舒兰陛下."
        ],
        [

            "不要再做无谓的挣扎了, 阿舒兰陛下. 哪怕是太阳, 也有交替的时候."
        ],
        [

            "能生擒\"沙漠之阳\"，是我的荣幸."
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "朕见过无数自以为是的莽夫, 最后都成了沙海里的尘埃. 尽管把朕关进最深处吧, 当朕重见天日之时, 你的国度将不再有阴凉之地."
        ],
        [

            "你想羞辱朕? 可惜, 这些伤痕只会成为朕日后剥下你皮肤时的参考."
        ],
        [

            "有趣.今天你摘下了朕的冠冕, 但这代价...你那脆弱的灵魂真的付得起吗?"
        ],
        [

            "失手? 不, 这只是命运的一次转折."
        ],
        [

            "既然你赢了这一局，那就收好你的奖赏."
        ],
        [

            "朕承认, 你确实展现出了令朕侧目的勇武. 但这只是个开始, 沙漠之阳的怒火, 从来不会因为一次日落而平息."
        ],
        [

            "哼, 带路吧. 让朕看看你的营帐是否容得下朕的光芒."
        ],
        [

            "命运总是喜欢开些残酷的玩笑...带路吧."
        ],
        [

            "是的, 胜负已定. 你的剑刃确实触碰到了朕的衣角. 既然如此, 朕便准许你享受这一刻的虚荣, 这是你应得的."
        ],
        [

            "既然你认为现在是你的时代, 那就努力维持住这份光亮吧. 别让朕太早感到无趣."
        ],
        [

            "不, 这不是荣幸, 这是宿命(冷笑)"
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "朕正在思考, 是哪一步的疏忽让你这种沙虫钻了空子.",
            "哼, 好好享受你最后的胜利时刻吧."
        ],
        [
            "怎么, 你是来瞻仰落日的吗?",
            "这种无意义的对峙在浪费朕的时间. 开个价, 把朕送回 [" + _target_country_name + "]. 朕的赎金足够买下你那座破败的村庄一百次."
        ],
        [
            "朕承认, 你确实是个麻烦.",
            "作为国王, 朕的每寸光阴都价值连城. 开个赎金的价格, 结束这场软禁. 朕相信你是个聪明人."
        ],
        [
            "开个价, 朕会让你看到帝王的慷慨, 前提是你懂得适可而止.",
            "这世界上能让朕如此狼狈的人不多, 你算是一个."
        ],
        [
            "哈哈哈. 你竟然把朕锁在这里? 朕是该夸奖你的胆识, 还是该责备你的无礼?",
            "咱们之间的账目已经多得数不清了, 也不差这一笔. 说个数, 朕会让国库为你敞开."
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "朕承认, 这一局是你赢了. 这 [#{0}] 德里足够平息这场纷争. 拿着它, 让朕离开.",
        "这 [#{0}] 德里是朕给出的诚意, 收下它, 然后让朕离开.",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "呸! 朕的财富竟要喂给你这头贪婪的沙虫! 让开!",
            "[" + _player_name + "], 记住这笔烂账. 等朕重整旗鼓之后, 朕会击败你! 然后用你的头骨盛满滚烫的沙子!"
        ],
        [
            "哼, 真是晦气! 赶紧给朕松绑!",
            "哼, 你给我记住, 下次再遇见了, 我会让你加倍奉还"
        ],
        [
            "很好, [" + _player_name + "]. 拿上你的好处, 咱们各走各的路. 下次碰上, 朕可不会再大意了!"
        ],
        [
            "哼, 朕承认这一局是你赢了, 下次你可没这么走运."
        ],
        [
            "[" + _player_name + "]. 亏朕还觉得你是个可造之才, 结果你居然像个市侩的土匪一样收朕的赎金!"
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "你在戏弄朕? 给帝王戴上\"被仁慈对待\"的枷锁, 比直接杀了朕还要阴险.",
            "哼...这种卑微的伎俩. 你是想让天下人觉得朕欠了你一条命?"
        ],
        [
            "朕见过无数贪婪的灵魂, 却从未见过像你这样自诩圣人的疯子. 不要钱, 不要宝物, 你想要的, 难道是朕对你的感激?",
            "你刚才的话...是认真的?",
            "再确认一遍, 你真的打算放虎归山? 朕可不是那种会因为一次释放就放下仇恨."
        ],
        [
            "这种毫无逻辑的慈悲真让朕感到不适. 你确定不收赎金?",
            "这种慷慨简直到了荒谬的程度, 你确定要直接放了我吗?",
            "不需要任何抵押? 不需要任何承诺? 这种毫无防备的行为, 在朕看来和自杀没什么区别. 你真的想好了?",
        ],
        [
            "有趣...你居然想用这种方式让朕记住你. [" + _player_name + "], 这种博弈比战场上的厮杀还要让朕兴奋.",
            "哈哈哈! 只有你这种混球敢对朕做这种\"赔本生意\". 你是想让朕这辈子都困在你的影子里吗?",
        ],
        [
            "你真的决定了? 这种愚蠢的高尚, 竟然用在了朕这种冷酷的人身上.",
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "既然你敢放虎归山，就洗干净脖子等着朕的铁骑踏平你的领地! 再会!",
            "有趣. 既然你执意放虎归山, 那这份\"仁慈\"朕就收下了. 希望你日后不会在噩梦里见到朕.",
            "既然你执意不收任何代价, 那朕就带着这份\"羞辱\"离开了. 记住, 太阳照常升起时, 朕的怒火也会重新燃起.",
            "你这种反常的行为让朕看不透. 那么告辞了. 下一次, 朕会亲自在沙场上清算今日的所有.",
            "朕承认, 这一局是你赢了. 朕会记住这笔账的."
        ],
        [
            "那就期待下次见面时, 你的剑还能像今天这么快. 告辞.",
            "呵...既然你愿意放走一个随时会毁灭你的人, 那朕也没理由拒绝这份愚蠢. 再见, [" + _player_name + "]."
        ],
        [
            "既然你选择用这份恩义来博取朕的注视, 那你成功了. 后会有期.",
            "你这种行径在沙漠里活不长久, 但确实让朕得以脱困. 再会.",
            "这种意外的\"大方\"，朕会放在心上的. 再见了."
        ],
        [
            "哈哈哈! 朕见过无数想讨好朕的人, 但像你这样用\"放弃财物\"来讨好的, 还是第一个. 这种感觉...倒也不坏.",
            "看来是朕小看你了. 你的野心比朕想象的更大. 再会了.",
            "朕本以为你会狮子大开口, 没想到你却送了朕一份最大的礼. 朕记下了."
        ],
        [
            "既然你不收赎金, 那就等着朕亲手为你准备的\"回礼\"吧. 别死在别人手里, 伙计!",
            "不需要任何承诺, 也不需要金钱. 你的胆识让朕侧目. 这一局是你赢了, 朕输得心服口服. 再见了.",
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 足以换回朕的自由.",
        "拿走这件 [#{0}], 作为太阳再次升起的筹码."
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "呵呵...朕向来喜欢有价值的工具, 不论他是否顺眼.",
        "呵呵...你今天竟然活下来了, 真是让朕意外.",
        "朕虽对你多有厌恶, 但今日之战也有你的一份功劳. 既然你尽到了盟友的职责, 朕便不为难你, 退下吧."
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "用最精准的策略, 最小的代价吞噬敌人. 呵呵...这正合朕的心意.",
        "呵呵...真是个明智的合作者."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "呵呵, 用最少的损失换取胜利, 不愧是朕赏识的人.",
        "跟朕并肩作战, 是不是比待在安逸的绿洲有趣得多?",
    ]