extends LordNobleDialogue

const HERO_UID: = "lord_hero_0008"







func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "就凭你这副寒酸样也想分 [" + _country_name + "] 的羹? 别逗我笑了, 快给我滚!"
        ]
    elif _rel_value <= -10:
        return[
            "你想加入? 哈, 你是觉得我这儿的空气太清爽, 非要来分走一份口粮吗? 这种麻烦事直接去找 [" + _king_name + "], 别耽误我数金币."
        ]
    elif _rel_value <= 10:
        return[
            "我只负责收割, 不负责批准新的战利品分配者. 去向那位唯一的统治者 - [" + _king_name + "] 宣誓, 让他/她来决定你价值几何.",
            "加入我们? 听起来像是个稳赚不赔的买卖 - 当然是对你而言. 去见 [" + _king_name + "] 吧, 这种契约只有他/她才能签字."
        ]
    elif _rel_value < 30:
        return[
            "你这身手不来 [" + _country_name + "] 真是暴殄天物. 去找 [" + _king_name + "] 谈谈吧."
        ]
    else:

        return[
            "亲爱的, 你早该这么做了! 去见见 [" + _king_name + "]. 等这笔政治买卖成交了, 我会在绿洲最好的酒馆里等你 - 当然, 你请客!"
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "这场小冲突从未脱离我的掌控. 你的出现只是个无所谓的意外.",
        "你只是想从我的战利品中分一杯羹, 我看得出来. 滚吧!"
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你来得还算及时, 至少省去了我清扫战场的麻烦. 别指望我会有多感激.",
        "你的速度还不错. 不过, 我可不希望看到你在我面前晃悠."
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "老相识, 你来得正好. 下次如果你想分一杯羹, 请确保你的效率更高一些.",
        "老相识, 你那只眼睛总能发现有肉吃的地方."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "今日你帮了我, 我承认. 但你最好别以此为傲, 下次我们依旧是敌人.",
        "我很欣赏你的实力, 但别用恩情来威胁我.",
        "你那双眼睛总是盯着有肉吃的地方. 这次你成功了."
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你真是个有价值的盟友. 有了你, 我能省下不少战力. 这次的收获, 分你一份大头.",
        "这次的援助很及时, 看来与你合作, 效率能提高不少.",
        "你证明了你值得更高的投资. 这次的收获, 我们平分. 继续为我创造价值!"
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "太棒了! 有了你, 我们的扩张计划会快上十倍!"
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "浪人, 你的剑看起来能值几个钱, 但你的命恐怕连一壶浊酒都不值. 你要把这两样东西都送给扎莉娅大人吗?"
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "别在那算计了. 今天唯一的战利品就是你们这些贪婪狗辈的脑袋!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "噢, 天呐, 一定是那瓶过期的龙舌兰! 各位官爷, 打扰了, 我这就滚远点去醒醒酒."
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        ["动手啊? 我正缺一副新的手套，你这张皮看起来厚度正合适. 只要你敢动一下, 我会让你求着我杀掉你."],
        ["瞧瞧这只在沙漠里乱窜的臭虫. 向我拔剑? 你甚至不值得我弄脏这双镶金的靴子. 滚远点."],
        ["你要向我挑战? 你可要想清楚了."],
        ["亲爱的, 你是被烈日晒坏了脑子, 还是嫌命太长了?"],
        ["我视你为能带给我利益的合伙人, 你却想在这里当个短命的英雄?"],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        ["来啊! 我早就想把那份擦屁股的协议烧了! 只要你一动, 我就能名正言顺地搬空你国家的仓库. 你确定要当这个送上门来的肥羊?"],
        ["收起你那可怜的傲气, 这一剑下去, 你会发现你们国库的缩水的速度比你流血还要快."],
        ["站住. 你代表的是你的疆域. 这一步跨出, 就是向 [" + _target_country_name + "] 正式宣战. 你那点领地赔得起这份\"违约金\"吗?"],
        ["哦, 我的朋友, 这种博弈一点都不优雅. 战争多费钱啊, 难道我们之间除了厮杀就没别的生意可做了?"],
        ["我一直把你当成我在这片沙海里最昂贵的收藏品, 你却要在我的阵前自贬身价?"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["好极了! 我会把你身上每一枚金币都抠出来, 连同你的眼珠子一起! 死吧!"],
        ["既然你执意找死, 那你的命我就收下了. 卫兵, 碾碎他们!"],
        ["路是你自己选的. 既然想当这片沙漠的肥料, 我就成全你!"],
        ["蠢货! 我给了你活命的机会, 你却偏要选死路. 下辈子记得算好账!"],
        ["你毁掉了我对你最后的期望. 现在, 你只是我刀下的一堆烂肉!"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    return[
        ["清算的时间到了! 我会把你的国家拆了! 进攻!"],
        ["在我眼里, 你和你身后的人民不过是一堆待标价的战利品. 既然你急着把自己送进屠宰场, 那我就笑纳了!"],
        ["既然你觉得和平导致收益太少, 非要用鲜血来增加财富, 那我就陪你玩玩."],
        ["高估了你的智商是我唯一的失策. 准备好用你的命来抵债吧!"],
        ["你背叛了我的信任! 我会亲手扒了你的皮做成旗帜!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    return[
        [
            "我就知道你会送上门来! 你的头颅加上你的金库, 这笔买卖我赚翻了!"
        ],
        [
            "勇士们! 把这些自不量力的沙虫全部踩成肉泥!"
        ],
        [
            "多说无益. 既然遇上了, 那就看看谁的刀更快!",
            "有胆量! 正好我的烈阳战斧已经饿得快发疯了."
        ],
        [
            "既然你执意要在冲锋的路上寻死, 那我只好收下你的项上人头去换悬赏了."
        ],
        [
            "很好, 就让我们的交情在血泊里做个了断吧.",
            "既然你把兵器都亮出来了, 那咱们就在这儿把账算清."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["在这种疯女人面前拔剑确实不明智(小声), 我收手."],
        ["在这种地方丢了命确实不划算..."],
        ["算了, 这种赔本的买卖，我不做了."],
        ["呼...大概是沙漠的太阳晒坏了我的脑子..."],
        ["我不打算成为你账单上的死囚...告辞"],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["算了, 这头\"肥羊\"让别人来当吧."],
        ["你提醒了我, 这笔赔本买卖不该由我来开启."],
        ["我刚才算了一下这笔账, 现在的代价确实超出了我的\"预算\"."],
        ["确实，这种博弈并不优雅. 我也没必要执迷不悟."],
        ["我可没打算在你的阵前自贬身价, 告辞."],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _country_name: = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 你这不知死活的丧门星, 害我损失了一大笔生意. 把你卖给矿场都不够抵债, 现在就给我拿命来填补亏空!"],
            ["你就是 [" + _player_name + "] 吧! 啧, 为了抓你这么个名声狼藉的浪人, 简直浪费我的时间. 乖乖戴上枷锁, 别再增加我的捕获成本!"],
            ["你就是那个闹事的浪人 [" + _player_name + "]? 你的人头在 [" + _country_name + "] 可是明码标价. 既然送上门了, 这笔账我就收下了!"],
            ["你就是 [" + _player_name + "] 吧! 我听闻你有些手段, 如果不是因为通缉令, 我倒想招你做个雇佣兵. 可惜, 赏金比人情更可靠, 跟我走吧."],
            ["呵呵, 这不是我的\"财神爷\" [" + _player_name + "] 吗! 抓到你一个, 比我跑一个月的商路都要赚. 既然是熟人, 我会下手快一点, 不让你多吃苦头的."],
        ]
    else:
        return[
            ["[" + _player_name + "]! 你居然还敢在我的领地上晃荡? 这一次我会打断你的手脚!"],
            ["[" + _player_name + "]! 你是不是觉得我的记账本是摆设? 滚过来受死, 别耽误我清算今天的收益!"],
            ["[" + _player_name + "], 上次让你溜了, 那笔亏损我可是记了一整年. 这次我看你还往哪儿跑, 赏金我拿定了!"],
            ["还没走远呢, [" + _player_name + "]? 看来你真的很想念我这里的地牢."],
            ["哈哈! 好朋友, 你简直就是我最喜欢的长期饭票! 既然又碰上了, 就再帮我赚一笔酒钱吧? 放心, 我会给你选个环境好点的牢房的!"],
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "] 吧! 你这该死的强盗, 当初在我的商路上肆意撒野的时候, 没想过会有今天吧? 现在你居然成了 [" + _player_country_name + "] 的领主, 正好, 这笔血亏的烂账, 我要用你的命来平掉!"],
            ["你就是 [" + _player_name + "] 吧! 听说你现在是那边的领主了? 啧, 那种地方的选拔准则真是低得令人发指. 既然你送上门来, 我也正好省了去搜捕你的成本."],
            ["你就是那个 [" + _player_name + "]? 既然你代表 [" + _player_country_name + "] 踏入沙漠, 那我只能勉为其难收了你的命."],
            ["你就是 [" + _player_name + "] 吧. 我听闻你在那边做得很出色. 如果你能带着你的领地投靠我, 该多好啊哈哈哈. 可惜, 现在的你对我来说, 只是一件昂贵的战利品."],
            ["噢, 初次见面, [" + _player_name + "]! 你在黑市的赏金榜上可是闪闪发光啊. 既然你今天亲自带着这身昂贵的行头出现在我面前, 我就不客气地收下这笔\"天降横财\"了!"],
        ]
    else:
        return[
            [
                "[" + _player_name + "]! 这一次, 我不会再让你有任何逃跑的机会, 乖乖死在沙子里吧.",
                "盯着你可真不容易, [" + _player_name + "]. 待会我会把你的帅旗做成裹尸布, 然后将你安葬, 这是我对你最后的仁慈."
            ],
            [
                "又见面了, [" + _player_name + "]. 现在, 我要立刻除掉你这个麻烦.",
                "啧, 怎么又是你这个赔钱货. [" + _player_name + "], 你存在的每一秒都在浪费我的精力. 乖乖把值钱的东西交出来, 或许我会让你死得体面点."
            ],
            [
                "[" + _player_name + "], 既然你的人头上了我的收割清单, 那我就勉为其难地把你变现吧.",
                "[" + _player_name + "], 你的人头在赏金榜上的排名又涨了, 那可真是个迷人的数字."
            ],
            [
                "[" + _player_name + "]. 你在我眼中的价值很高, 但这恰恰成了我不得不亲手拆解你的理由.",
                "哎呀, [" + _player_name + "], 我的老熟人. 真遗憾在这种时候碰上你, 但我最近手头确实有点紧. 既然是朋友, 你应该不介意用你的溃败来帮我换点军费吧?",
                "瞧瞧这是谁? [" + _player_name + "], 能让我追这么远, 你可真是身价倍增啊! 来吧, 亲爱的, 让我们看看这场对局谁能带走赌注!"
            ],
            [
                "瞧瞧这迷人的景象. [" + _player_name + "], 你的人头赏金每次都在刷新历史新高. 如果不由我亲自斩获, 那简直是对我职业生涯的侮辱.",
                "[" + _player_name + "], 你这勾人的家伙! 为了追上你, 我这匹万金难买的沙原骆驼都快跑废了, 你打算怎么赔我?"
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 那个到处作恶的豺狼, 我真想把你绑在太阳下晒成干, 但我现在有更重要的杀戮要去完成. 滚远点, 趁我还没算清楚剥你的皮需要花费多少时间!"],
            ["你就是 [" + _player_name + "]? 我今日不愿在毫无意义的垃圾身上损耗箭矢，带着你那破烂的人头滚出这片沙丘!"],
            ["我知道你, 一个在 [" + _target_country_name + "] 背着沉重债务的浪人. 我不打算浪费军力去抓你, 除非你的价码涨到让我无法拒绝. 如果还想呼吸，就麻溜地从我面前消失."],
            ["呵呵, 你就是那条能在 [" + _target_country_name + "] 的律法下活得像条滑溜的沙蛇 - [" + _player_name + "]? 你确实有点本事. 我今天心情不错, 走吧, 去给别的领主找点麻烦."],
            ["瞧瞧, 这不就是那个闹得满城沙暴的 [" + _player_name + "] 吗? 你的人头可是 [" + _target_country_name + "] 悬赏目标. 我现在放你走, 是想让你再把身价抬高点. 保重好你的脖子."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["反复在我面前晃悠, 是想让我给你发路费吗?"],
                ["我的话只说一遍, 滚!"],
                ["简直是在浪费我的生命. 立刻消失！"],
                ["再不走, 我就把你剁了喂鹰."],
                ["别以为我不动你是因为仁慈, 那只是因为你不值这个价."],
            ]
        else:
            return[
                ["又是你, 这不知死活的沙蛇. 你以为沙漠的阴影能永远藏住你? 若非我有更大利润的目标要摧毁, 我现在就让你知道什么叫求生不得. 滚!"],
                ["[" + _player_name + "], 你身上的穷酸气和血腥味真让我作呕. 趁我还没发火, 赶紧带着你那卑贱的命滚远点."],
                ["又是你. 看来你还没死在哪个沙坑里. 只要不干扰我的进攻路线, 我没兴趣去领那点微薄的赏金. 滚去阴影里待着."],
                ["[" + _player_name + "], 你这不要命的贪婪劲头倒是挺合我胃口. 去吧, 去抢夺更多的德里. 然后等我有空时, 再来一次性清算你."],
                ["哈哈哈！ 我最爱的坏账朋友. 每次见到你还没被绞死, 我都感到由衷的欣慰. 因为你的命注定是我的."],
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    if _is_first_meet:
        return[
            ["哎呀, 这不是 [" + _player_name + "] 吗? 你在欠下的那笔烂账, 我可是每天都记在心里呢. 既然你主动送上门来, 我是该先砍了你的手, 还是直接把你卖给奴隶贩子抵债呢?"],
            ["啧, [" + _player_country_name + "] 的领主都像你这么闲吗? [" + _player_name + "], 你这种穷追不舍的劲头, 要是肯花在挖金矿上, 早就发大财了."],
            ["你就是那个名声大噪的 [" + _player_name + "]? 近看也没什么特别的嘛. 截住我的行军路线, 是打算跟我谈笔双赢的买卖吗? 先说好, 没钱的话, 我的烈阳战斧可是不认人的."],
            ["哟, 瞧瞧是谁来了? [" + _player_name + "], 你追得这么紧, 是爱上我这把斧头了, 还是爱上我了?"],
            ["你就是 [" + _player_name + "]? 你这副气势汹汹的样子真迷人, 像极了我在沙漠里找到的那头金狮子!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["你还没想好怎么死吗? 我的战斧可是按次收费的, 你要不要先预付一下?"],
                ["你要是想死就快点, 我后头还有好几笔大单子等着结款呢!"],
                ["别挡着老娘发财!"],
                ["要打就赶紧拔刀, 别耽误我的美差!"],
                ["别在那儿晃悠!"],
            ]
        else:
            return[
                [
                    "又是你! [" + _player_name + "], 你这阴魂不散的穷鬼!",
                    "[" + _player_name + "]! 你这没皮没脸的讨债鬼, 非要盯着我剩下这点家底不放吗?",
                    "[" + _player_name + "], 你这张脸简直比沙漠里的臭虫还让人倒胃口! 非要在这个时候撞到老娘的斧头上, 你是想用你那廉价的血来润润土吗?"
                ],
                [
                    "你还没被教训够吗? [" + _player_name + "], 你这种廉价的勇气在我眼里一文不值. 既然你追到了这里, 是打算把你的命也赔给我吗?",
                    "啧, 又是这种令人反胃的纠缠. [" + _player_name + "], 你除了会像只跟屁虫一样跟着我, 还会点别的吗?",
                    "[" + _player_name + "]! 就算我现在没有带足兵马, 但要捏死你这只臭虫也费不了多少力气!"
                ],
                [
                    "[" + _player_name + "], 你这种穷追不舍的劲头, 要是用在赚钱上, 你早就是大财主了.",
                    "又见面了, [" + _player_name + "]. 你那寒酸的气味隔着几里地都能闻到. 既然追到了这里, 你是想自找麻烦, 还是打算夹着尾巴滚远点?"
                ],
                [
                    "追逐游戏到此为止吧. [" + _player_name + "]. 想开战, 我随时奉陪.",
                    "[" + _player_name + "], 如果你觉得现在能稳赢我, 那就亮兵器吧. 我会让你明白, 在这片沙漠里, 谁才是真正的收割者!",
                    "追了我这么久, 你不累吗?! [" + _player_name + "]!",
                ],
                [
                    "哎呀, 我的好伙伴, 你追得我心跳都加速了, 难道你是想亲手把我送进地狱, 再顺便继承我的金库吗?"
                ],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    if _is_first_meet:
        return[
            ["我是扎莉娅, [" + _target_country_name + "] 的领主. 你就是那个掠夺者 [" + _player_name + "]? 胆子不小嘛. 趁我还没决定把你切成碎块去喂秃鹫, 赶紧滚出我的视线!"],
            ["我是扎莉娅. [" + _target_country_name + "] 的领主. 你是哪儿来的流浪汉? 你这身破铜烂铁在沙漠里甚至换不来一壶凉水. 离我的行军路线远点."],
            ["我是扎莉娅, 炽沙之鹰. 我看你眼神挺狠, 是想在 [" + _target_country_name + "] 找份能发财的差事, 还是打算在沙子里埋掉你那无处安放的自尊心?"],
            ["我是扎莉娅. [" + _target_country_name + "] 的领主, 听说你在乱贼手里保下了那批货? 干得漂亮, [" + _player_name + "]. 虽然我觉得白干活的行为很蠢, 但你的身手确实值个好价钱."],
            ["我是扎莉娅，[" + _target_country_name + "] 的领主, 我就喜欢你这种又硬又狠的角色!"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["是想让我把你当成奴隶卖掉吗?"],
                ["啊(不耐烦)...滚啊!"],
                ["别像个野狗一样跟在我后面."],
                ["别在那儿晃悠!"],
                ["怎么又回来了? 想我了?"],
            ]
        else:
            return[
                ["那股穷酸臭味又飘过来了. [" + _player_name + "], 你还没被沙暴埋掉吗?"],
                ["又是你. 还没找到肯收留你的垃圾堆吗? 啧, 真是个倒霉透顶的家伙."],
                ["[" + _player_name + "], 还没死在哪个不知名的沙丘里? 命挺硬嘛."],
                ["哟, 这不是 [" + _player_name + "] 吗? 听说你最近又到处管闲事了?"],
                ["[" + _player_name + "]! 陪我喝一杯, 让我们好好规划一下怎么把这片沙漠的财宝都装进兜里!"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["我是扎莉娅. 你就是那个新晋领主? 我丑话说在前面, 沙漠里的金矿是有数的, 你要是敢把手伸进我的口袋, 我的烈阳战斧可不认什么同僚."],
                ["我是扎莉娅. 我还以为我国招募了一个什么了不起的人物, 原来是个连盔甲都擦不亮的穷酸领主. 离我的绿洲远点, 别把你的寒酸气传染给我的马队."],
                ["我是扎莉娅. 你就是最近封爵的 [" + _player_name + "]? 看来 [" + _target_country_name + "] 又要热闹了. 只要你不挡我的财路, 我也懒得找你麻烦."],
                ["我是扎莉娅. 嘿, [" + _player_name + "], 我听过你的手段, 够狠, 我也喜欢. 像你这样聪明的人, 一定知道哪里能搜刮到更多的财宝, 对吧?"],
                ["哈哈哈! 我是扎莉娅! [" + _target_country_name + "] 总算来了个像样的领主"]
            ]
        else:
            return[
                ["我是扎莉娅. [" + _target_country_name + "] 的领主. 你胆子不小, 居然敢带着这群杂兵踏进我的沙丘. 别跟我提什么和约, 在我眼里, 你只是一具还没被剥皮的肥羊."],
                ["我叫扎莉娅. [" + _player_country_name + "] 派你来是想在沙子里刨食吗, [" + _player_name + "]? 你这副样子看起来真让人没胃口."],
                ["我是扎莉娅, 这片绿洲的债主. 异国的领主, 你是带钱来谈买卖的, 还是带命来找死的?"],
                ["哟, 看看这是谁? [" + _player_country_name + "] 的 [" + _player_name + "]. 像你这么有本事的领主, 窝在那个缩头缩脑的国家真是暴殄天物."],
                ["哈哈哈! 久仰大名, [" + _player_country_name + "] 的大红人! 我是扎莉娅. 像你这种满眼写着欲望的家伙最合我的胃口了. 抛开那些无聊的政治, 咱们谈点实实在在的金币, 如何?"]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["不想死就滚!"],
                ["你是想在这儿扎根吗?"],
                ["想跟我套近乎? 你带够诚意了吗?"],
                ["你这种眼神, 是打算把你的灵魂也抵押给我吗?"],
                ["哈哈哈! 看来你是真急着想和我去大赚一笔."]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "[" + _player_name + "], 你居然还喘着气? 真是奇迹.",
                        "哟, 这不是 [" + _player_name + "] 吗? 离我远点. 别把你的霉运传染给我."
                    ],
                    [
                        "啧, 每次见到你, 我都觉得这沙漠里的空气变臭了.",
                    ],
                    [
                        "啧, 又是你. 我用的上好的龙涎香熏了整整一夜的战袍, 结果你一露面, 这股香味全被你那股陈年霉味给糟蹋了."
                    ],

                    [
                        "又是你. 身为贵族, 你除了会浪费淡水和消耗口粮, 还会干点别的吗?",
                        "[" + _player_name + "], 我可没有时间浪费在你这种没油水的家伙上."
                    ],
                    [
                        "我的同僚, 你那边的税金收缴得怎么样了? 我最近盯上了一批新的战马.",
                        "[" + _player_name + "], 看你你最近倒是挺勤快啊, 看来赚了不少?",
                        "[" + _player_name + "] 阁下, 你这人虽然死板了点, 但办事还挺稳重的.",
                        "又见面了, [" + _player_name + "]. 我就喜欢你这种识趣的性格. 在罗德里, 朋友不可信, 但金币永远不会骗人."
                    ],
                    [
                        "嘿, 我的好伙伴! 听说你最近又从那帮异国蠢货手里搜刮了不少好东西? 我已经等不及要听听你的发财故事了.",
                        "嘿, 我的好伙伴!, 下次有发财的机会, 记得带我一起.",
                        "哇, [" + _player_name + "], 你这身行头看起来又贵了不少!"
                    ],
                    [
                        "哈哈哈! 你来得正是时候! [" + _player_name + "]. 我刚刚收到消息, 有一支肥得流油的商队正打算绕过边境.",
                        "[" + _player_name + "], 你就是我在这沙漠里最想保住的宝贝. 你要是倒下了, 我上哪儿去找这么好用的帮手?"
                    ]
                ]
            else:
                return[
                    [
                        "[" + _player_name + "], 别以为现在和平了就没事, 我早晚要连本带利地讨回来.",
                    ],
                    [
                        "又是你. 趁我还没决定用我的斧头撕碎你的钱袋之前, 赶紧消失.",
                        "[" + _player_name + "], 离我远点, 别把你们那儿的穷酸气传染给我.",
                        "哟, [" + _player_name + "], 你居然还敢在我的防区晃悠?"
                    ],
                    [
                        "哟, 这不是 [" + _player_name + "] 吗? 看你这副灰头土脸的样子, 是掉进了哪个泥坑吧.",
                        "哟, 这不是 [" + _player_country_name + "] 的领主吗? 和约保护了你这颗不值钱的脑袋, 带上你的穷酸气滚远点.",
                    ],

                    [
                        "异国的领主, 我们又在沙丘上重逢了",
                    ],
                    [
                        "啧, 又见面了, [" + _player_name + "]. 你这副正人君子的模样在 [" + _target_country_name + "] 可活不久."
                    ],
                    [
                        "嘿, 我最喜欢的对手! 比起这群无聊的木头，你有趣多了."
                    ],
                    [
                        "[" + _player_name + "]! 你终于来了! 快快入座! 咱们这次一定要谈成那笔大的.",
                        "哈哈, 你来了! 果然还是和你这个混蛋待在一起最痛快!",
                    ]
                ]

func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)

func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "小的们! 冲过去!",
        "随我冲过去!",
        "哈哈哈! 收割的时间到了!",
        "烈阳战斧已经嗅到财富的味道了! 给我上!",
        "别让我失望, 对面的肥羊们! 给我上!",
        "杀!杀!杀!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "啧, 弄脏了我的战斧",
        "呸, 这种货色",
        "死吧!",
        "下一个肥羊在哪?",
        "你的命我就笑纳了",
        "竟然费了老娘这么多力气",
        "骨头倒是硬",
        "下一个送死的在哪?",
        "我承认你比我养的角蝰要强一点点",
        "哼~",
        "嗯哼~ 死了吧",
        "不如我养的角蝰 - 辛拉"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "我会照顾好你的财产, " + _target_hero_name,
            "你的钱包归我了, " + _target_hero_name
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "嘶...你这该死的畜生",
        "看来你是不想死得太痛快了!",
        "继续杀!",
        "等老娘缓过劲来, 一定要你好看!",
        "想杀我? 我的命可贵着呢!",
        "老娘剥了你的皮!",
        "弄坏了我的金甲!",
        "别傻看! 给老娘顶上去!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "竟然被这种小计谋...",
        "不可能...",
        "我的宝石...",
        "竟然...",
        "我不甘心...",
        "竟然算漏了这一步...",
        "竟然死在这种..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "稳步推进! 别为了那点小利散了阵型, 大头在后面呢!",
        "保持阵型!",
        "保持阵型! 我可不想在数钱的时候发现手下死光了!",
        "稳扎稳打! 咱们是来发财的, 不是来送命的!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "保持阵型!",
        "不要惊慌! 守住!",
        "不要为了贪功而露出破绽!",
        "守住那条防线!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "哼, 去确认还有没有藏着的财物! 动作快点!",
        "哇哈哈! 这种大丰收的滋味!",
        "把有用的东西全给我装车!",
        "干得不错! 今晚加餐!",
        "这就是跟我作对的代价",
        "哈哈! 看着这些战利品, 难道不比正午的阳光还要夺目吗?",
        "这种收割的感觉真会上瘾"
    ].pick_random()

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "扎莉娅, 准备好了去享受那数着发霉的草根度日的地牢日子吗?"
        ],
        [

            "被自己看不起的\"穷酸货\"生擒, 这种滋味一定比沙子还难咽吧?"
        ],
        [

            "别再盘算着怎么脱身了, 扎莉娅."
        ],
        [

            "看来今天的财运并不在你这边, 扎莉娅."
        ],
        [

            "行了, 收起你的小动作, 扎莉娅. 既然已经输了, 就老实点."
        ],
        [

            "胜负已分, 扎莉娅."
        ],
        [

            "别在这儿跟我算计了, 扎莉娅. 老实点."
        ],
        [

            "胜负已定, 扎莉娅大人."
        ],
        [

            "在这片沙漠里, 能让我费这么多力气抓的人不多, 你应该感到自豪, 扎莉娅大人."
        ],
        [

            "是我赢了, 扎莉娅大人."
        ],
        [

            "是我赢了, 扎莉娅大人."
        ],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "呵, 记得把赎金定高点, 别丢了我的身价.",
            "这种威胁太老套了, 嘴碎的乌鸦通常活不久."
        ],
        [

            "你倒是挺有自知之明. 可惜啊, 你就算赢了我, 也改不掉骨子里那股廉价味.",
            "与其\"关心\"我的感受, 不如担心你那点微薄的军费够不够雇几个像样的看守来盯着我."
        ],
        [

            "只要我这条命还在, 我就永远有翻盘的本钱. 倒是你, 赢了这一次就飘飘然了?",
            "你在想什么? 想看我哭着求饶吗? 小可爱."
        ],
        [

            "算你运气好, 捡到了老娘疏忽的机会. 现在的财运在你那儿, 记得拿稳了.",
            "别以为捡了个便宜就能在这儿教训我."
        ],
        [

            "放轻松, 我不喜欢做赔本的买卖. 既然打不过, 我也不会浪费体力去挣扎."
        ],
        [

            "赢了就赢了, 啰嗦什么? 带路吧."
        ],
        [

            "既然你想要我收敛一点, 那我就表现得像个合格的俘虏好了(冷笑)."
        ],
        [

            "哼, 赢了我也别这么得意."
        ],
        [

            "呵呵, 被你这么一夸, 我都觉得脖子上的绳索变得温柔了不少(冷笑)."
        ],
        [

            "既然现在是你的胜利时刻, 那就尽情庆祝吧(冷笑)."
        ],
        [

            "我就喜欢你这种狠角色! 既然你赢了, 那我的命和武器, 都暂存在你那儿."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "离我远点, 你身上那股寒酸味会弄脏我这身昂贵的丝绸.",
            "把我关在这里, 你一分钱好处都捞不到!"
        ],
        [
            "怎么，是来看我笑话的？",
            "咱们开门见山吧. 你抓我是为了换钱? 而我正好有的是钱. 说个数."
        ],
        [
            "在这儿虚度光阴简直是犯罪. 你知不知道我每多待一个刻钟, 就会漏掉多少笔大单子?"
        ],
        [
            "算一算账吧, 亲爱的. 放了我, 你能得到一大笔现钱.",
            "咱们之间没什么深仇大恨, 纯粹是生意上的碰撞. 既然这次是你赢了, 我认栽."
        ],
        [
            "谈谈我的赎金吧. 按照 [" + _target_country_name + "] 的惯例, 像我这种身份的领主, 你应该能开出一个不错的价钱.",
            "哎呀, 小冤家, 你竟然真舍得把我关在这种地方?"
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "一直把我关在这阴冷的地牢里可不符合你的利益. 拿着 [#{0}] 德里, 然后放我走, 咱们这笔烂账就算两清了, 如何?",
        "啧, 这地方的空气让我的皮肤都变粗糙了. 咱们谈笔双赢的买卖吧 - [#{0}] 德里, 换我的自由.",
        "小冤家. [#{0}] 德里已经是目前的\"市场最高价\"了. 收下吧, 然后放我走. 万一援军先到, 你可就人财两空了."
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "拿稳这些财物, 你这吸血的臭虫!",
            "[" + _player_name + "], 你最好祈祷这辈子都别再让我在沙漠里撞见你. 否则我会亲手把你剥光了钉在仙人掌上."
        ],
        [
            "很好, [" + _player_name + "]. 拿上你的\"辛苦钱\", 咱们各走各的路."
        ],
        [
            "哼, 真是晦气! 快给我松绑! 这种阴冷的地方老娘一秒钟也待不下去了!",
            "哼, 算你运气好, 捡到了老娘疏忽的机会. 下次你可没这么好运了."
        ],
        [
            "哼，这次算老娘栽了. 胜负常有, 只要本钱还在, 我就还没输光. 走着瞧吧!",
            "赶紧把这破绳子解开! 老娘的皮肤都要被这粗麻绳磨粗糙了, 你赔得起吗?",
            "哼, 你给我记住, 小冤家. 下次我一定要从你身上连本带利抢回来!"
        ],
        [
            "哎呀, 你这贪婪的混蛋. 我们这么好的交情, 你居然连一个子儿的折扣都不肯打? 真是个没良心的铁公鸡!"
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "不要钱? [" + _player_name + "], 你是觉得我不值那几枚德里, 还是想玩放生后再猎杀的把戏?",
            "你在羞辱我吗? 放走一个领主却不要任何好处, 你是想让别人都笑话我扎莉娅连个标价都没有?",
            "收起你那恶心的\"仁慈\". 说吧, 你到底在我的行装里塞了什么追踪香料? 我可不信这世上有免费的午餐."
        ],
        [
            "你确定要放我走? 我可没打算给你回礼哦.",
            "这种突如其来的慷慨, 真让我怀疑你是不是在沙漠里挖到了什么黄金矿. 你确定要直接放我走?"
        ],
        [
            "你确定? 这可是一笔不小的财富. 你要是现在松手, 回头再反悔, 我可不会退半个子儿给你.",
            "别逗我笑了, [" + _player_name + "]. 在这片土地上, 白给的东西往往最贵. 你真的打算就这么让我走?"
        ],
        [
            "亲爱的, 你这脑子是不是被烈日烤得缩水了? 放走我却不要赎金, 你这辈子都别想发财了.",
            "我承认你的武艺不错, 但这做生意的眼光简直烂透了. 再确认一遍, 你真的不打算从我这儿抠出哪怕一个德里?",
            "这种毫无逻辑的施舍...你该不会是爱上我了吧?",
        ],
        [
            "哎呀, 你该不会是真的爱上我了吧? 为了博我一笑连这么多德里都不要了?",
            "为了咱们这点交情, 你居然愿意做到这一步?"
        ],
    ]

func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "[" + _player_name + "]. 既然你执意什么好处都不要, 那咱们的账就等下次开战时再算. 告辞!",
            "别指望我会感激你. 这种无条件释放只会让我觉得你是个不懂行情的蠢货. 告辞!",
        ],
        [
            "既然你选择了虚名, 那我就不客气的收下\"自由\"了, 告辞.",
            "这份情我记下了, 在下一次决定砍掉你的脑袋前, 我会先犹豫半刻钟的. 告辞."
        ],
        [
            "啧啧, [" + _player_name + "], 你这副样子真是迷人又愚蠢. 既然你执意要送我这么大一份礼, 那我就不客气地收下了. 再会",
            "你这人真有意思. 明明可以靠我发一笔横财, 却非要装成个清高的英雄...那么告辞了."
        ],
        [
            "你是嫌我给的钱会弄脏你的口袋? 行吧, 既然你坚持, 那我就勉为其难地接受这份\"赠礼\"了, 再会.",
            "我从未见过像你这么不会算账的人. 不过既然这是你的选择, 那我就收下这份自由了. 再会.",
            "啧啧, 放走我这种危险的女人, 你一定是看上我了. 既然如此, 我也得表现得识趣点. 保重了, 我的财神爷."
        ],
        [
            "呵, 既然你非要当个无可救药的圣人, 那我也不好意思拦着你亏本. 再见了.",
            "亲爱的, 你这笔投资做得太亏了, 但我喜欢! 再见了.",
            "你居然想用这种方式让我这辈子都忘不掉你? 你这坏胚子, 手段真够辣的. 我收下了, 你别反悔!"
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 归你了, 小冤家. 收好这份昂贵的\"分手费\", 趁我还没心疼到想反悔, 赶紧放我走.",
        "算你狠! 这件 [#{0}] 换回我的自由绰绰有余了."
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "少用那种眼神看着我, 我可没打算分你额外的赏钱.",
        "哟, 瞧瞧谁活下来了? 我还以为你那身盔甲会被当场开罐呢.",
        "勉强算个合格的工具. 别指望我会因此对你有所改观.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "配合得不错嘛.",
        "打得还挺聪明的, 既知道主动进攻, 又懂得保全实力. 合作愉快啦.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 这次配合得真不赖. 只要有你在后面帮我兜底, 我的烈阳战斧就只管往那些敌军头上招呼.",
        "哎呀呀, 我的好战友, 你今天在战场上的英姿可真是迷人呢.",
    ]