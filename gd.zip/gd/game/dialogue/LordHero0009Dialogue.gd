extends LordNobleDialogue

const HERO_UID: = "lord_hero_0009"


func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "你想向 [" + _king_name + "] 宣誓效忠? 别逗了, 你更适合做这片丛林的肥料. 滚, 趁我的箭还没穿透你的咽喉.",
            "[" + _country_name + "] 不收容毫无价值的人物. 如果你这样的人成为了我的同僚, 我怕我会忍不住想把你钉在树上.",
            "比起听你谈论什么可笑的忠诚, 我更想扒了你的装备换点部队过冬的口粮. 立刻从我的视线里消失, 这是你最后的生机.",
            "别想了, 蠢货. 我恨不得现在就处理掉你."
        ]
    elif _rel_value <= -10:

        return[
            "我不关心你的死活. 如果你非要在这里找个位置, 去烦 [" + _king_name + "], 别挡着我狩猎.",
            "想成为封臣? 就凭你? 你这种家伙在丛林里活不过三个晚上. 去见 [" + _king_name + "] 吧, 看看他/她能不能看上你(冷笑).",
            "把你的誓言收起来, 然后带去见 [" + _king_name + "], 别在我的营地里散播你那种愚蠢的气味."
        ]
    elif _rel_value <= 10:

        return[
            "去见 [" + _king_name + "] 吧, 只要他/她认为你有做炮灰的价值, 我没意见.",
            "去见 [" + _king_name + "] 吧, 如果他/她觉得你的剑能帮我们省点力气, 那应该没什么问题.",
            "我不做这种无聊的担保. 你要加入 [" + _country_name + "] 的话, 就去让 [" + _king_name + "] 来评估你.",
        ]
    elif _rel_value < 30:

        return[
            "我看过你处理猎物的手法, 没有多余的怜悯, 很务实. 去见 [" + _king_name + "] 吧, 我们这里正好缺一个懂得什么时候该出手的同僚.",
            "你很清楚什么时候该撤退保命, 这比那些只知道送死的白痴骑士强多了. 去和 [" + _king_name + "] 谈谈, 我想我们以后会有合作的机会.",
        ]
    else:

        return[
            "如果你加入 [" + _country_name + "], 至少我的侧翼交给你时, 不用担心被那些假惺惺的道德底线拖后腿. 去见 [" + _king_name + "], 立刻落实这件事.",
            "一个优秀的猎手总是需要同样冷血的搭档. 我们都知道为了活下去该做些什么. 去找 [" + _king_name + "], 这片土地有足够我们分享的猎物.",
            "能让我顺眼的活人不多, 你算一个. 去见见 [" + _king_name + "] 吧. 你会得到想要的结果."
        ]

func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "你干扰了我的伏击. 如果不是在与其他敌军交战, 我的下一支箭会插在你的喉咙里.",
        "谁允许你进入我的狩猎场的? 滚出这片土地, 别让我再说第二次.",
        "你的介入毫无章法. 下次再敢打乱我的节奏, 我就把你做成活人诱饵."
    ]

func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "战斗结束了, 你的贡献比树叶还要薄.",
        "我的黑棘弓不需要无关紧要的观众. 你走吧.",
        "我觉得你没有介入的必要性. 别在我的视线里晃悠."
    ]

func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "告诉我, 你刚才躲在哪颗老树后看戏?",
        "看你这副样子, 真担心你会死在那些杂兵手里(冷笑).",
        "虽然你这次像个木桩一样毫无作为, 但看在你那张脸还算顺眼的份上, 我这次就不计较了."
    ]

func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "你的杀戮效率不错, 比我想象中要干脆利落得多. 但我依然会和你保持距离.",
        "这份恩情我会记住, 但如果你以为这就能让我放下戒心, 那你太天真了.",
    ]

func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你刚才切入敌阵的样子, 就像毒蛇咬穿了野兔的脖子. 那种冷酷感很合我的胃口.",
        "因为你的加入, 我节省了至少三成的箭矢. 你功不可没.",
        "你懂得如何利用敌军的破绽. 这次算我欠你的."
    ]

func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你的出现扭转了局势, 让那些家伙变成了这片林子的养料. 合作愉快.",
        "看着那些蠢货在你的利刃下倒地, 真是一种享受.",
        "你用行动证明了你不是那种满口道德的伪君子. 走吧, 去瓜分那些战利品, 剩下的烂摊子交给大自然去处理."
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "再踏前半步, 你的喉咙就会多出一截箭头. 女爵大人的猎场里, 从来不缺像你这样的蠢货尸体.",
        "想对女爵大人动手? 你确定你能活过女爵部队的第一波箭雨?"
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "我会让你们分清谁是猎人谁是猎物!"
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "我只是想确认一下这附近有没有水源, 看来我找错地方了. 别紧张, 我这就走."
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [
            "你是嫌这片土地的土不够肥沃, 想用你的血来灌溉吗?"
        ],
        [
            "就你? 要挑战我? 想清楚了!"
        ],
        [
            "啊? 这可不是什么聪明的决定."
        ],
        [
            "这种举动并不适合你. 活着难道不好吗?"
        ],
        [
            "朋友, 这可不像你会做的蠢事.",
            "你疯了吗? 如果你是因为这里的瘴气产生了幻觉, 我可以原谅你这一次. 但如果你真要动手...我保证你会死得很快."
        ],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [
            "虽然我早就看你不顺眼, 但主动撕毁和平协议? 你真是蠢得让我惊讶.",
            "想玩火? 我会把战争的瘟疫带回你的领地."
        ],
        [
            "收起你那拙劣的试探. 你不仅是在挑战我, 更是在亲手撕碎国家的停战协议. 你真打算为了这点私愤, 让两国边境变成巨大的屠宰场?",
            "如果你非要开战, 我保证你会是第一个倒下的."
        ],
        [
            "你想让你的子民为你瞬间的轻率而陪葬吗? 撕毁和平协议意味着无尽的战争损耗. 在你拔剑之前, 最好先算清楚你那点家底够不够赔掉."
        ],
        [
            "我没听错吧? 两国的和平来之不易，别让一时的脑热毁了这份和平协议.",
        ],
        [
            "这是我近期听到的最糟糕的消息 - 我最信任的盟友竟然要带头挑起战火. 如果你坚持跨过这条线, 那我们就只能在战场中厮杀了."
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [
            "真好, 既然你急着投胎, 那我就成全你.",
            "在这片林子里, 多嘴的鸟和自大的人都活不长. 杀光他们!"
        ],
        [
            "我已经给过你机会了, 可你偏要选择最惨烈的死法. 弓箭手, 准备放箭!",
            "既然你执意要挑战我, 那就准备好变成这地底下的养料吧. 所有人, 狩猎开始了!"
        ],
        [
            "又一个被瘴气熏坏脑子的蠢货. 也好, 正好缺个活靶子练手. 作战准备!",
            "既然沟通失效, 那就用武器来说话吧. 希望你的命比你的剑更硬一些."
        ],
        [
            "啧, 真是浪费. 我本以为你是个聪明的猎手, 现在看来...你只是个自寻死路的活靶子. 动手吧.",
            "我对你最后的怜悯已经耗尽了. 既然你选了这条路, 那我就把你那点可笑的勇气埋在泥沼里吧."
        ],
        [
            "这就是你的选择? 既然如此，我会亲自送你最后一程.",
            "你会后悔这个决定的, 我的老朋友. 我会让你明白背叛我的代价, 比死亡更痛苦. 放箭!"
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [
            "这正是你自取灭亡的开始!",
            "我会亲手拔掉你的旗帜, 塞进你那张只知狂吠的嘴里!"
        ],
        [
            "我会让你明白, 在这片森林里, 背誓者的下场只有一种: 死亡.",
            "既然你觉得那张和平协议毫无意义, 那就用血来签新的契约吧."
        ],
        [
            "既然和平无法约束你的贪婪, 那就让黑棘的箭矢来重塑你的脑子. 准备受死吧.",
        ],
        [
            "我本以为你是个能看清局势的聪明人, 看来我看走眼了. 既然你执意毁掉这份和平, 那就准备好用你的命来支付代价吧.",
            "这是你自找的. 我会让你在断气前, 亲眼看着你的防线像枯枝一样崩塌!"
        ],
        [
            "从这一刻起, 你不再是我的好友, 我会亲手终结你.",
        ]
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [
            "既然你自己送上门来, 倒省了我去找你的力气. 全军, 准备作战!",
            "[" + _player_name + "], 我会把你的头颅削下来挂在林口, 作为所有入侵者的警告."
        ],
        [
            "既然你急着找死, 那我就在这片林子里终结你的狂妄. 这里的每一棵树都可能是你的墓碑.",
            "[" + _player_name + "], 踏进这片土地的那一刻，你就注定是死人一个了. 准备迎接箭雨的洗礼!",
        ],
        [
            "既然你选择了正面对垒, 那就看看你的脖子是否能挡住我的箭矢.",
            "[" + _player_name + "], 我会让你知道挑衅 [" + _target_country_name + "] 是你这辈子算得最差的一笔账."
        ],
        [
            "作为对手, 你的杀戮技巧的确令我敬佩. 拔剑吧, 我会用最毒的箭来送你一程. 这是对强者最后的礼遇.",
            "来吧, 证明你比那些自大的蠢货更强一点."
        ],
        [
            "这是最不幸的重逢, 我的朋友. 既然两国正在交战, 那就抛开交情, 看看谁才是最后的赢家吧.",
            "[" + _player_name + "], 这就是我们的宿命了. 不必留情, 我会亲自收割你的命, 然后把你葬在向阳的树根下. 开战吧."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [
            "你说得对，在这种泥潭里丢了命, 连秃鹫都嫌肉酸. 我走就是了."
        ],
        [
            "我这就消失."
        ],
        [
            "我还没沦落到要靠这种毫无胜算的袭击来证明自己, 告辞."
        ],
        [
            "你说得对，活着确实比变成一具毫无价值的尸体要强. 我收回刚才的冲动."
        ],
        [
            "我大概是真的被这里的瘴气熏坏了脑子. 再见."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [
            "那张和平协议...就让它继续在桌上待着吧.",
            "你说得对, 玩火确实容易烧到自己."
        ],
        [
            "...这次是我失礼了.",
            "...我收回刚才的话."
        ],
        [
            "你说得对, 为了这一瞬间的意气让子民陪葬, 确实不是一个合格领主该有的举动.",
        ],
        [
            "你说得对, 两国的和平不该毁在个人的私愤上.",
        ],
        [
            "在战场上和你厮杀确实是最糟糕的预想. 再见."
        ],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 看来这片林子里的秃鹫又要加餐了."],
            ["你就是 [" + _player_name + "]? 既然你被挂上了通缉名单, 与其让你死在其他猎人手里, 不如让我亲自收割."],
            ["你就是 [" + _player_name + "]吧? 既然你撞到了我的箭口上, 就别想活着离开了."],
            ["我是塞琳娜. 我听说过你的本事, 能在这种鬼地方活到现在, 你确实挺有韧性. 跟我回去吧, 我可以考虑让你死得体面点."],
            ["我是塞琳娜. 真遗憾, [" + _player_name + "], 你这种有趣的灵魂不该出现在通缉名单上. 虽然我挺中意你, 但别让我为了你浪费太多箭矢, 投降吧."]
        ]
    else:
        return[
            ["[" + _player_name + "], 你居然还敢在我的视线里溜达? 这一次, 我会直接把你的头钉在树干上."],
            ["[" + _player_name + "], 我已经闻到你身上的死人气了. 开战吧."],
            ["[" + _player_name + "], 我的目标依然是你的脑袋. 在这片阴影里, 你是跑不掉的."],
            ["站住, [" + _player_name + "]. 你应该明白, 就算我再欣赏你的能力, 也不能让我的马车空着回去. 认命吧."],
            ["好久不见, 老朋友. 既然我们又在猎场相遇了, 叙旧之前, 先让我看看你的本事有没有退步? 速战速决吧."]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["我是塞琳娜. [" + _player_name + "], 我听闻你在边境那些毫无底线的行径. 像你这种只会对弱者下黑手的烂货, 竟然也能混到领主的位子? 既然踏入 [" + _target_country_name + "], 就准备好变成树根下的肥料吧."],
            ["我是塞琳娜. 既然你身为领主却不懂得收敛爪牙, 我就在这片土地上里教教你什么是\"捕食法则\"."],
            ["我是塞琳娜, [" + _target_country_name + "] 的领主. 既然你效忠了 [" + _player_country_name + "], 那我们就没什么好谈的了. 拔剑吧."],
            ["我是塞琳娜. 既然你我立场相对, 我就不得不在这里截断你的退路了."],
            ["我是塞琳娜. [" + _player_name + "], 我久仰你的统帅之名. 能亲手收割像你这样聪明的对手, 是一件值得期待的事."],
        ]
    else:
        return[
            [
                "[" + _player_name + "], 你那张令人作呕的旗帜又出现了! 这一次，我不会再让你有逃进地洞的机会.",
                "别再跑了, [" + _player_name + "]. 我在此保证, 今日你绝无可能活着跨过这片土地一步!"
            ],
            [
                "又见面了， [" + _player_name + "]. 既然你执意要在我的领地寻死, 那我就成全你.",
                "[" + _player_name + "], 准备好在黑棘箭雨中被射成筛子吧！"
            ],
            [
                "别再做徒劳的挣扎了, [" + _player_name + "]. 你已经没有退路可言."
            ],
            [
                "我的老对手 [" + _player_name + "], 你我在这战场上兵戎相见, 真是让人遗憾. 但在这一刻，我的箭矢绝不会偏离目标.",
                "局势注定了你我必有一战. 既然你再次出现在我的狩猎范围内, 我只能用武力来终结这场博弈."
            ],
            [
                "呵呵, [" + _player_name + "]. 我就知道这林子里的骚动定是因你而起. 能再次与你对阵, 是这场枯燥战争中唯一的慰藉. 来吧, 老对手, 让我们全力以赴!",
                "看到你的身影, 我感到既兴奋又沉重. [" + _player_name + "], 今天, 你是我的猎物.",
                "别指望我会留情, [" + _player_name + "], 拔剑吧. 如果你死在我的手里, 我会亲手把你葬在向阳的树下."
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 那个通缉犯? 我现在没空清理你这种腐叶!"],
            ["通缉名单上的犯人 [" + _player_name + "]...我总算见到你这张贪婪的脸了. 你在后面尾随了这么久, 想要做什么?"],
            ["你就是那个被多方通缉的 [" + _player_name + "]? 能追上我的行军速度, 你确实比一般的流窜犯要强. 但我今日没空处理垃圾, 离我的队伍远点."],
            ["我是塞琳娜. 我听过关于你的情报, 能在这种搜捕下活到现在, 你确实挺有韧性. 但这不代表你可以肆无忌惮地跟踪我."],
            ["我是塞琳娜. 你居然敢大摇大摆地追到我面前? 你确实如传闻中一样胆大包天."]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["我的耐心可比我的箭头要短得多. 滚!"],
                ["你的反复出现正在挑战我的狩猎本能. 想死在这儿吗?"],
                ["别再跟着我了!"],
                ["走吧. 趁我现在还觉得杀你太浪费箭矢."],
                ["珍惜你那点可怜的自由, 不要挑战我的警戒红线."]
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 若非此刻军务在身, 我现在就想把你射杀, 滚!"],
                ["[" + _player_name + "], 你这种如影随形的纠缠让我恶心. 我现在不想让我的部下沾上你这种肮脏的血, 滚远点!"],
                ["又是你, 看来你还没学会如何跟捕食者保持距离."],
                ["[" + _player_name + "], 这种执着的跟踪只会让你死得更惨. 赶紧滚去换个地方活命吧."],
                ["又见面了, [" + _player_name + "]. 保住你的命, 在未来的某次战斗中, 我会亲自来取."]
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["我说是谁在后方衔尾相随, 原来是那个投靠了 [" + _player_country_name + "] 的劣迹领主 - [" + _player_name + "]. 想要开战的话, 我随时奉陪."],
            ["你就是那个 [" + _player_name + "]? 你紧咬不放的样子让我想起了那些贪婪的野狗."],
            ["想必你就是最近声名鹊起的 [" + _player_name + "] 了. 带兵截断我的行军路, 是想要在此比个胜负吗?"],
            ["竟然在此处与你相遇, [" + _player_name + "]. 我听闻你加入了 [" + _player_country_name + "]. 既然你执意追随至此, 是觉得我露出了破绽?"],
            ["原来是你, [" + _player_name + "]. 原本这枯燥的行军让我昏昏欲睡, 但你身上的血腥味瞬间让我清醒了. 想在这里跟我做个了断吗?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["反复窥探我的侧翼, 是在寻找根本不存在的漏洞吗?"],
                ["[" + _player_name + "], 我的将士已上弦待发. 如果你还没准备好迎接箭雨, 就滚远点."],
                ["这种距离是对我耐心的挑衅."],
                ["你我之间已无外交辞令可言."],
                ["别在那虚张声势. 我很忙."]
            ]
        else:

            return[
                ["又是你. [" + _player_name + "], 我的阵型随时可以把你绞碎, 你有胆量在此时发起决死冲锋吗?"],
                ["又见到这面旗帜了. 既然你执意拦路, 是打算在此开战吗?"],
                ["[" + _player_country_name + "] 的领主. 拦截我是需要付出代价的, 你准备好了吗?"],
                ["又见面了, [" + _player_name + "]. 离我这么近可是非常危险的."],
                ["[" + _player_name + "], 你的出现让我感到既开心又惶恐."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["我是塞琳娜. 我听过你在边境的那些小动作. 在我下令把你钉在树干上之前, 请保持安全的距离."],
            ["我是塞琳娜. 我听过你在边境的那些小动作. 在我下令把你钉在树干上之前, 请保持安全的距离."],
            ["我是塞琳娜， [" + _target_country_name + "] 的领主. 说明你的来意, 浪人."],
            ["我是塞琳娜， [" + _target_country_name + "] 的领主. 我听闻过一些你的事迹, 我很欣赏你."],
            ["我是塞琳娜， [" + _target_country_name + "] 的领主. 我听闻过一些你的事迹, 我很欣赏你."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["反复接近我的侧翼, 有何目的?"],
                ["过度的纠缠会被视为狩猎信号. 退后!"],
                ["别干扰行军."],
                ["还有什么事?"],
                ["还没打算离开?"]
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 别指望我会忘记你的臭名声."],
                ["又是你. 希望这段时间里, 你学会了如何像个正常的猎手一样活着, 而不是像只只会捡食腐肉的豺狼."],
                ["[" + _player_name + "], 好久不见. 你的剑刃依然在漫无目的地乱挥吗?"],
                ["看到你还没死, 我挺意外的. [" + _player_name + "]."],
                ["好久不见, 老友. 丛林里一直宣扬着你的那股子狠劲. 快跟我说说, 这段时间你又做了什么大事?"]
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:

        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["我是塞琳娜. 虽然你我同处 [" + _target_king_name + "] 麾下, 但我听过你的那些\"杰作\". 别指望我会把你这种破坏平衡的蠢货当成同僚."],
                ["我是塞琳娜. [" + _player_name + "], 我欢迎有实力的领主, 但前提是你别在我的地盘制造麻烦."],
                ["我是塞琳娜. 你就是那个声名鹊起的 [" + _player_name + "]? 看来这片死气沉沉的林子里终于来了个像样的猎手."],
                ["我是塞琳娜. 我听闻 [" + _target_country_name + "] 迎来了一位真正的实干家. [" + _player_name + "], 比起那些空谈荣誉的贵族, 我更看好你的手段."],
                ["终于见到你了, [" + _player_name + "]. 你的名字在最前线的战士口中传得很响. 希望你的武器也如传闻般锋利."]
            ]

        else:
            return[
                ["我是塞琳娜, [" + _player_country_name + "] 的领主. 我听闻过你那些见不得光的勾当. 在我管辖的领地范围内, 管好你的手脚."],
                ["我是塞琳娜, [" + _target_country_name + "] 的领主. 你的名声在我耳边并不算好. 既然现在有和平协议, 我允许你通行, 但别做出任何让我\"误解\"的动作."],
                ["我是塞琳娜, [" + _player_country_name + "] 的领主. 你越过边境而来, 是想谈笔共赢的买卖, 还是仅仅来测试我的脾气?"],
                ["欢迎你, 异国的领主. 我听闻你在你的领地一直推行实用的政策, 这很聪明. 像你这样理智的人, 会受到我的礼遇."],
                ["我是塞琳娜. 很高兴能结识你这样头脑清醒的领主. 你的战绩证明了你是一个值得打交道的对手."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["请退后至安全距离."],
                ["我的时间很宝贵, 没空陪你在这儿闲聊"],
                ["还有其他的事吗?"],
                ["看来你还有未尽的事项?"],
                ["还有什么事吗?"]
            ]
        else:

            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    ["[" + _player_name + "], 作为同僚, 我不得不提醒你: 你的行事风格正在挑战我的忍耐底线."],
                    ["[" + _player_name + "], 如果让我发现你在背后搞小动作, 我的黑棘箭会第一时间射穿你的喉咙, 听明白了吗?"],
                    ["哪怕我们现在是同僚, 我也没有和你交谈的欲望."],
                    ["[" + _player_name + "], 在这乱世中, 多余的仁慈只会让你死得更快."],
                    ["见到你真是让人安心"],
                ]

            else:
                return[
                    ["[" + _player_country_name + "] 的领主. 趁我还没决定为了以前的旧账把这协议撕了, 赶紧消失!"],
                    ["又是你. 虽然两国目前维持着和平, 但我依然会盯着你这条毒蛇."],
                    ["又见面了, [" + _player_name + "]. 我不信任你, 更不信任你背后的国家. 在我的耐心耗尽前, 滚出我的视线."],
                    ["即便有和约在手, 我也不会对一个心怀鬼胎的异国人放下戒心."],

                    ["又见面了, [" + _player_name + "] 阁下. 在这林子里, 任何风吹草动都瞒不过我的眼睛, 请自重."],
                    ["很高兴再次见到你, 聪明的领主."],
                    ["异国的领主, 命运又让我们重逢了."],
                    ["很高兴看到你的旗帜. 虽然王旗不同, 但只要和平环境还能带来利益, 我们就是伙伴."],
                    ["久违了, 利落的猎手. 愿今日的重逢能共叙两国的利益."],
                ]


func get_battle_chat_charge()-> String:
    var _country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        "一个活口也别留!",
        "作战准备!",
        "撕碎他们的防线!",
        "碾碎他们!",
        "全军突击!",
        "看准他们的脖子!",
        "摧毁他们!",
        "动手!",
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "变成肥料吧.",
        "给我安静点.",
        "你确实让我失望了.",
        "你败在你的愚蠢.",
        "这就是你自找的.",
        "你就像枯枝一样, 一折就断。"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这就是你的终点， [" + _target_hero_name + "].",
            "再见了, [" + _target_hero_name + "]."
        ])

    return _list.pick_random()


func get_battle_chat_injured()-> String:
    return[
        "啧...",
        "你会让你付出十倍的代价!",
        "还没结束呢!",
        "这点痛楚...",
        "你成功激怒了我!",
        "这种程度的攻击...",
        "很好..."
    ].pick_random()


func get_battle_chat_die()-> String:
    return[
        "竟然被...",
        "这不该是我的终点...",
        "啧...",
        "原来我才是猎物吗...",
        "终究还是..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们坚守阵地!",
    ].pick_random()


func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压缩他们的生存空间, 别让猎物跑出阴影!",
        "推进!",
        "保持狩猎间距",
        "别贪功冒进, 稳步把罗网收死"
    ].pick_random()


func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住! 别像受惊的小鹿一样乱窜!",
        "原地待命, 等他们自己撞上来!",
        "别被那些拙劣的诱饵骗了, 守好你们的死角!",
        "谁要是敢撤退, 我就亲手把他钉在树干上!",
        "保持冷静, 守住位置!",
        "别动, 等我下令!"
    ].pick_random()


func get_battle_chat_vectory()-> String:
    return[
        "清理战场!",
        "这就结束了?",
        "去把敌人的行囊搜干净!",
        "这是一场漂亮的收割."
    ].pick_random()


func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "看看你现在的样子, 塞琳娜. 现在你和你口中的\"肥料\"没什么区别.",
        ],
        [

            "真是可惜, 塞琳娜. 看来你这只老练的猎人, 最后还是掉进了自己的猎场里."
        ],
        [

            "所谓的\"荆棘女爵\", 也不过如此。"
        ],
        [

            "你的谨慎并没有为你算准这一局, 塞琳娜.",
            "塞琳娜, 你已经输了."
        ],
        [

            "胜负已分, 塞琳娜. 放下你的弓."
        ],
        [

            "你输了, 塞琳娜"
        ],
        [

            "胜负已分, 塞琳娜."
        ],
        [

            "承让了, 塞琳娜大人."
        ],
        [

            "很遗憾, 塞琳娜大人. 生存法则注定我们之中只有一个能站着. 请原谅我的无礼."
        ],
    ]


func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "别指望我会像那些软弱的贵族一样求饶."
        ],
        [

            "落入你这种只会在背后闻味的野狗手里, 是我这辈子最大的失算.",
            "比起战败, 被你这种货色俘虏更让我恶心."
        ],
        [

            "你的傲慢早晚会让你死在某条阴暗的沟渠里."
        ],
        [

            "既然这一局输了, 要杀要剐随你."
        ],
        [

            "既然丛林已经选出了胜者, 我没兴趣增加无谓的消耗. 我投降."
        ],
        [

            "这一局是你赢了, [" + _player_name + "]."
        ],
        [

            "我接受这份暂时的失败. 在这片林子里, 偶尔也会有猎物咬伤猎人的时候."
        ],
        [

            "我接受这份失利.",
        ],
        [

            "战场之上各为其主, 弱肉强食罢了, 你不需要露出那种虚伪的遗憾."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        [

            "落入你这烂货手里是我这辈子唯一的污点, 动手杀了我吧, 否则只要我能回到阴影里, 第一个收割的就是你.",
            "有什么事? 我只恨那支毒箭没能直接贯穿你那肮脏的心脏.",
            "我没什么可以跟你聊的. 看着你这张脸就让我反胃."
        ],
        [

            "如果你是来谈赎金的, 最好开个有诚意的价. 你应该很清楚, 像我这样的\"猎手\"值多少钱.",
            "别试图用这种居高临下的姿态羞辱我."
        ],
        [

            "有什么事吗?",
        ],
        [

            "虽然被俘虏让我很不爽, 但是输给你, 我也算认栽了.",
        ],
        [

            "我的老对手, 又来看我了?",
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "我出 [#{0}] 德里, 买回我的自由. 这对你我来说都是最明智的结算方式.",
        "[#{0}] 德里换取我重回阴影的权利. 这笔买卖你并不亏."
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "记住这一刻, [" + _player_name + "], 下次见面, 我的箭会贯穿你的喉咙",
            "这是对我那次失算的买断. 下次我会亲手把你钉死在树干上. 在那之前, 好好祈祷你那贫弱的运气还能救你一命吧.",
        ],
        [

            "很好, [" + _player_name + "], 交易达成了. 奉劝你不要得意太久.",
            "理智的决定. 现在, 把路让开."
        ],
        [

            "很好. 我会记住这次博弈失败的代价. 在下一次狩猎, 我不会再给你任何机会.",
            "很好, [" + _player_name + "]. 这笔账我记下了, 下次我会亲自来讨回我失去的面子",
        ],
        [

            "不得不承认, 你的判断力比那些蠢货领主强得多. 作为对手, 我期待与你的下一次战斗."
        ],
        [

            "保重, [" + _player_name + "]. 可千万别死在那些无名小卒的手里. 那会让我觉得这笔赎金花得太亏了."
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [

            "[" + _player_name + "], 你到底在耍什么花样? 想等我转身的时候再从背后射一支冷箭吗?",
            "你要放我走? 这又是你哪门子的阴谋? 想通过这种虚伪的仁慈来羞辱我, 还是想在路上设下更致命的伏击?",
            "你确定? [" + _player_name + "], 别以为玩这种放生游戏就能让我感激涕零. 说吧, 你到底在打什么主意?"
        ],
        [

            "我不相信无缘无故的施舍. 你是想用我的自由, 去换取某种我尚未察觉的, 更昂贵的筹码吗?",
            "你刚才的话...是认真的?",
            "你要放我走? 不要试图用这种方式来试探我的底线, 直说吧, 你的真实目的是什么?"
        ],
        [

            "再确认一遍. 没有任何抵押, 没有任何契约, 你就这么打算让我回到阴影里? 你真的想好了吗?"
        ],
        [

            "这种气量...如果不考虑立场, 我真想看看你这疯狂的赌徒最后能赢下什么. 你真的不需要那些赎金来填补你的亏空?",
            "你真的决定了? 这种只会出现在那些骗人的吟游诗歌里的\"高尚\", 竟然会用在我这个狠毒的对手身上?",
        ],
        [

            "真的要放我走吗? 哪怕是为了我, 放掉这么大的一个\"战利品\", 你的那些部下也会有怨言吧?",
            "[" + _player_name + "], 在这片弱肉强食的林子里玩弄慈悲...你就不怕我回过头去, 反手把你撕碎吗?"
        ],
    ]


func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "既然绳索解开了, 我可不会假惺惺地说谢谢. 战场上见,  [" + _player_name + "].",
            "放我走是你这辈子犯过最愚蠢的错误. 好好享受你最后的宁静吧. 下次见面，我不会有任何迟疑."
        ],
        [

            "这份自由我收下了. 我会重新评估你. 再会."
        ],
        [

            "既然你执意要打破这片林子里的生存法则, 我若不接受, 倒显得我连一个疯子的气量都没有. 这笔账我会记在心里的, 再会."
        ],
        [

            "如果你是为了让我欠你一个人情, 那你成功了. 在这片荒野, 这种债可比金币要沉重得多. 后会有期.",
            "你赢得了我的尊重, [" + _player_name + "]. 这种尊重无关那些虚伪的骑士准则, 纯粹是因为你的疯狂. 保重."
        ],
        [

            "啧, 真是服了你了. 别死得太快, 我的朋友, 我的命还寄存在你那儿呢.",
            "这份情义, 我记下了. 以后若是你掉进别人的陷阱里, 我会考虑去收割那个家伙的脑袋来还债的. 后会有期."
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "既然你对那些沉甸甸的金币没兴趣, 那就拿走这件 [#{0}] 吧. 如何?",
        "我交出这件 [#{0}] 作为自由的入场券. 成交吗?",
        "这是一笔溢价交易. 我用这件 [#{0}] 换取我重回阴影的权利."
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "你完成了你的任务, 把威胁扼杀在了摇篮里. 但我们依然不是一路人.",
        "你今天懂得及时收拢阵线避免不必要的死伤, 能看出来脑子还没坏掉.",
        "你今天没有给我增添麻烦, 这很好."
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "只有活下去才有一切, 让那些蠢货统统变成肥料吧.",
        "这批缴获的粮食, 装备. 我会按规矩分你一份.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "呵...这次配合得真不赖.",
        "痛快...只有你最懂我的战斗风格.",
    ]