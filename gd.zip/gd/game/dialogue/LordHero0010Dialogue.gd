extends LordNobleDialogue

const HERO_UID: = "lord_hero_0010"


func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "向 [" + _king_name + "] 宣誓? 法典的第一章就写着: 背德者不可立于王座之下. 你的存在即是对秩序的亵渎, 在我拔出\"法典执行者\"审判你之前, 滚出这片平原.",
            "与其奢求效忠, 你更应该思考在哪座绞刑架上赎罪. 离我远点, 罪人.",
            "我的行刑队已经处理过无数像你这样的人渣. 如果你试图接近 [" + _king_name + "], 我会在星辰的见证下, 亲自切断你的野心.",
        ]
    elif _rel_value <= -10:

        return[
            "去见 [" + _king_name + "] 吧, 但我不会为你的忠诚提供任何信用担保.",
            "去王城找 [" + _king_name + "], 别打扰我观测星轨."
        ]
    elif _rel_value <= 10:

        return[
            "去见 [" + _king_name + "] 吧. 如果你的加入符合 [" + _country_name + "] 的战略逻辑, 国家会为你腾出一个位置.",
            "加入我们需要经过严格的政审. 去和 [" + _king_name + "] 谈谈, 只要你能通过考核, 我没理由反对.",
            "既然你想投靠, 去请示 [" + _king_name + "]. 我会根据星辰的指向来监督你的表现."
        ]
    elif _rel_value < 30:

        return[
            "我看过你战斗的方式, 精准且符合逻辑. 去见 [" + _king_name + "] 吧, [" + _country_name + "] 需要像你的利刃.",
            "你证明了自己能够遵守基本的秩序。去和 [" + _king_name + "] 交流，我想平原的法典中，应该有属于你的一行记述。",
        ]
    else:

        return[
            "去找 [" + _king_name + "] 落实你的席位, 我们需要这种绝对优势的协作.",
            "你是我在这片平原上见过的最符合法则逻辑的同类. 去见见 [" + _king_name + "] 吧, 结果已经写在星辰的预示中了."
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "平原上不需要毫无效率的乱入者. 既然你没能证明自己的价值, 就请带着你的傲慢滚出我的视野.",
        "你的擅作主张不仅低效, 而且危险. 下一次, 我的行刑队会先于敌人处理你.",
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的介入并未在计划内. 不要干扰行军序列.",
        "你并未提供足够的战果来索取酬劳. 战斗已结束, 你可以离开了.",
        "你的行动效率极低, 下次请在确认自身实力后再进入战场.",
        "胜负已定, 而你的贡献度甚至无法折算成一行战报.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "你本应发挥更大的战术价值, 朋友.",
        "看到你毫发无损, 这确实符合我预想中的结果. 不过下次, 我希望你的贡献能与你的身价匹配."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "你展现出的战术价值确实令人侧目, 这笔债我会记入法典的\"补偿\"项. 但这并不意味着我会撤销对你过往恶行的通缉.",
        "即便你在此刻充当了正义的利刃, 也无法抹除你作为混乱的本质. 感谢你的介入, 但这不会改变我对你的最终判决.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "你展现了超越常人的判断力, 成功止损并扭转了战局. 我会寻找对等的契机予以偿还.",
        "你的存在显著降低了王国的战斗成本, 为此, 我必须向你致敬意.",
        "若非你的出现，战局大概率会崩坏, 感谢你提供的帮助",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "星辰的轨迹预示了这场胜利, 而你则是那道最精准的流光.",
        "你我并肩, 便如同法典的两面 - 我负责宣判, 你负责执行. 这份信任, 重逾千金.",
        "能与你一同校准这乱世的秩序, 是我的荣幸.",
        "看到你平安, 且带着如此辉煌的战果归来, 这便是我所能预见的, 最符合正义的结果. 我的战友, 愿星辰永远指引你的剑锋."
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "你正试图冒犯法则的化身. 再敢靠近, 审判之眼的行刑队将依照法典, 在此处终结你的罪孽.",
        "法典执行者的巨剑下不斩无名之辈, 但也不留冒犯之徒. 收起你的野心, 否则下一刻, 你的名字将出现在阵亡者的罪行录上.",
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "今天, 我的剑就是这片平原唯一的判决准则! 准备战斗!",
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "别这么严肃, 我这就离开.",
        "我还没打算在今天领受死刑, 你们继续, 我只是路过.",
        "我只是想近距离感受一下法则的威严, 现在我感受到了, 确实挺震撼的. 再见."
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [

            "一个没有根基的流寇, 竟敢向法则挑战?"
        ],
        [

            "就凭你? 这种毫无胜算的进攻完全背离了理性. 在\"法典执行者\"将你一分为二之前, 收起你那愚蠢的狂热."
        ],
        [

            "攻击我并不符合你的生存逻辑. 你确定要为了这一瞬间的冲动, 让自己在法典执行名单上中彻底消失吗?"
        ],
        [

            "这种鲁莽的行为并不适合你. 星辰运行尚有规律可循, 而你却在自寻死路. 回去吧, 别让我亲手打破这份平衡."
        ],
        [

            "你疯了吗? 如果是因为平原上的烈日晒昏了你的头脑, 我可以暂缓这次审判.",
            "我的朋友, 这可不是一个清醒的人会做的决定."
        ],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [

            "主动撕毁协议? 你不仅是一个恶徒, 更是贵族阶层的耻辱. 如果你渴望战争的烈焰, 我会依照法典, 将你彻底裁决.",
        ],
        [

            "违背誓言者必遭清算. 如果你坚持要开启这场不义之战, 我保证你的名字将永远刻在耻辱柱的首位."
        ],
        [

            "撕毁协议意味着两国秩序的全面脱轨. 在你拔剑之前, 先算清楚你的国库是否足以填补这无底的战争损耗. 轻率, 是领主最致命的死罪.",
            "你想让你的子民为你瞬间的脑热而陪葬吗? 和平协议是经济发展的基础, 而你正亲手击碎它."
        ],
        [

            "我以为我们之间已经达成了理性的共识. 别让一时的冲动毁了这份来之不易的和平, 这对谁都没有好处. 收回你的剑.",
        ],
        [

            "这是星辰运行中最令人遗憾的偏差 - 我最认可的同类, 竟然要带头践踏契约. 如果你坚持跨过这道红线，那么剩下的只有绝对的裁决.",
            "朋友，别让疯狂取代了你的理智. 如果你真的拔剑, 我将不得不履行我作为\"法典执行者\"的职责. 将你裁决."
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [

            "既然你急于踏入地狱, 我便以法典执行者之名成全你. 行刑队, 清除障碍!",
            "在这片平原上, 狂妄者唯有一种归宿 - 那便是绞刑架. 全军, 开始审判罪恶!"
        ],
        [

            "我已经给过你反悔的机会, 但你选择了继续冒进, 那么, 拔剑吧.",
            "执意挑战秩序的代价, 就是你的生命. 既然你急于自毁, 那就准备好迎接审判吧. 所有人, 战斗准备!"
        ],
        [

            "沟通结束. 既然你选择用刀剑对话, 那就希望你的生命力能比你的\"野心\"更持久一些.",
            "又一个被狂热冲昏头脑的牺牲品. 也好, 我的\"法典执行者\"正好需要一场实战校准. 全军进入阵位!"
        ],
        [

            "真遗憾, 你终究还是让冲动战胜了理性. 动手吧.",
            "我对你最后的宽容已经随风而逝. 既然你选了这条路, 那我只能将你那点可笑的勇气埋入荒原."
        ],
        [

            "这就是你的最终抉择吗? 既然如此, 我会以此剑作为最后的见证, 亲自终结你的错误.",
            "抛弃理智的代价是沉重的, 我的朋友. 既然你坚持要跨过这道红线, 我会给予你作为战士最体面的死法."
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [

            "这一剑将开启你的终焉之日!",
        ],
        [

            "那就用你的血, 来偿付这份违约的代价吧!"
        ],
        [

            "既然和平无法约束你的狂热, 那就让\"法典执行者\"的刃锋来重塑你的认知. 全军进入战斗准备!",
        ],
        [

            "这不仅仅是一场战斗, 更是你作为领主的自毁宣告. 我会让你认识到自己的错误!"
        ],
        [

            "从这一刻起，你我之间的交情已随协议一同被焚毁. 我将亲手终结你!",
            "这就是你的选择吗? 我的朋友. 好吧...我会给予你最神圣的审判."
        ]
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        [

            "既然你主动来接受审判, 倒省去了我搜捕你的力气. 全军, 进入战斗准备!",
            "[" + _player_name + "], 我会将你的旗帜与残躯一同钉在边境的城墙上, 作为所有越界者的警示."
        ],
        [

            "[" + _player_name + "], 准备迎接巨剑的裁决吧!"
        ],
        [

            "既然你选择了正面对垒, 那就看看你的盾牌是否能挡住法典执行者的重击. 准备接战!",
        ],
        [

            "作为对手, 你的战术素养确实值得称道. 拔剑吧, 我会用\"法典执行者\"亲自为你送行.",
            "来吧, 证明你确实拥有足以抗衡秩序的力量. 我将全力以赴, 以示尊重."
        ],
        [

            "这是星辰运行中最令人叹息的交汇. 我的朋友, 既然两国兵戎相见, 那就抛开私情, 去完成各自的使命吧.",
            "[" + _player_name + "], 这就是我们的宿命. 不必留情, 开战吧!"
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [

            "在平原上和审判之眼较劲确实是个短命的念头, 我走就是了."
        ],
        [

            "看来我的狂热确实选错了目标. 我这就消失."
        ],
        [

            "正如你所言, 自杀式的冲动并不符合我的生存之道. 告辞."
        ],
        [

            "你说得对, 我收回刚才的轻率."
        ],
        [

            "刚才那些话完全不是清醒时该有的逻辑, 再见, 我的朋友."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [

            "我还没打算在今天和你这种顽固的裁决者死磕.",
            "你说得对, 玩火确实容易烧到自己."
        ],
        [

            "...这次是我失礼了. 我收回刚才的话.",
        ],
        [

            "你说得对. 这确实不是一个合格领主该有的行为.",
        ],
        [

            "你说得对. 两国的和平不该毁在个人的私愤上. 我收回我的剑.",
        ],
        [

            "我不想亲手抹除我们之间的契约, 这种疯狂到此为止吧.",
        ]
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["你就是 [" + _player_name + "]? 法典上已经剥夺了你的生存权. 既然你出现在这片平原, 我就有义务将你这杂质彻底抹除."],

            ["你就是 [" + _player_name + "]? 你正在被通缉, 能死于\"审判之眼\"的剑下是你最后的荣幸."],

            ["你就是 [" + _player_name + "]? 不必多言, 拔剑吧, 让我看看你的能力是否足以支撑你的狂妄."],

            ["我是埃里克. 我看过关于你的记录, 在这种混乱的局势下仍能保持自省. 你确实有些才能. 放下武器, 接受法典的安排."],

            ["我是埃里克. 真遗憾, 星辰原本为你预示了更好的归宿. 虽然我私下很欣赏你的才智, 但法度不容亵渎. 投降吧, 别让我亲手折断你."]
        ]
    else:
        return[

            ["[" + _player_name + "], 这一次, 我会亲自校准法则的偏差, 将你的名字彻底从名册中抹去."],

            ["[" + _player_name + "], 你身上的罪孽已经重到星辰都无法忽视. 行刑队, 准备清算!"],

            ["[" + _player_name + "], 你依然是这片平原上最不稳定的那个变数. 为了秩序的稳定, 我必须在此终结你."],

            ["站住, [" + _player_name + "]. 你应该明白, 个人情感无法动摇法典的运行. 既然你执意游离在规则之外, 我只能执行我的职责. 认命吧."],

            ["好久不见, 老朋友. 既然星辰让我们在战场上再度交汇, 那就用剑来重申我们各自的立场吧. 别让我看到你的战斗技巧有任何退步."]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["我是埃里克. [" + _player_name + "], 你之前那些暴行已是众人皆知. 像你这样视法则如无物的投机者, 根本不配冠以领主之名. 既然你踏入 [" + _target_country_name + "], 就准备接受法典的裁决吧."],

            ["我是埃里克. 既然你代表 [" + _player_country_name + "] 出现于此, 我肯定不能无视你的存在, 拔剑吧."],

            ["我是埃里克, [" + _target_country_name + "] 的守护者. 既然你选择为 [" + _player_country_name + "] 的野心而战, 那我只能在此将你审判."],

            ["我是埃里克. 我曾仔细评估过你的施政与军略, 本以为我们能成为秩序的共同筑造者. 遗憾的是, 立场注定我们要在此截断彼此的征途."],

            ["我是埃里克. [" + _player_name + "], 像你这样严谨而理性的对手实属罕见. 亲手终结一个值得尊敬的同类, 是我的荣幸."]
        ]
    else:
        return[

            [
                "[" + _player_name + "], 你那面象征杀戮的旗帜再次亵渎了这片平原. 这一次, 我绝不会允许任何意外发生.",
                "放弃逃亡吧, [" + _player_name + "]. 我已在星辰下预见了你的败局."
            ],

            [
                "又见面了, [" + _player_name + "]. 既然你执意出现在我的裁决范围内, 那我便亲手将你填入法度的基石之下.",
                "[" + _player_name + "], 准备好在行刑队的重剑下结束你的余生吧!"
            ],

            [
                "放弃无谓的抵抗吧, [" + _player_name + "]. 在绝对的战力面前, 你的战术不过是垂死的挣扎."
            ],

            [
                "老对手 [" + _player_name + "], 在战场上重逢确实令人唏嘘. 但你应当明白, 我的重剑绝不会因私情而产生丝毫的偏差.",
                "局势已经推演到了终局. 既然你再次出现在我的战阵前方, 我只能以武力来终结这场宿命的博弈."
            ],

            [
                "[" + _player_name + "], 我早已预见到今日的交汇. 能与你对阵, 是这场混沌战争中唯一的慰藉.",
                "看到你的身影, 我感到既欣慰又沉重. [" + _player_name + "], 此刻你不是我的好友, 而是我必须剔除的阻碍.",
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["我是埃里克. 你就是那个携带重兵四处流窜的 [" + _player_name + "]? 你截停我的路线, 是想用你的武力来挑战这片平原的法典吗?"],

            ["通缉名单上的犯人 [" + _player_name + "]...你带着这支足部队尾随我, 究竟在打什么算盘?"],

            ["你就是 [" + _player_name + "]? 看来传闻有误, 你的实力已经远远超出了\"流窜犯\"的范畴."],

            ["我是埃里克. 我听闻过你的事迹, 你确实是个罕见的变数. 但这不代表你可以肆无忌惮地拦截我的行军路经."],

            ["我是埃里克. 你竟然带着这种规模的部队截击我? [" + _player_name + "], 你果然难以预测. 你这是想用武力来重新修定我们之间的关系吗?"]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["滚出我的视线!"],
                ["你的部队正在不断试探我的防御红线."],
                ["收起你那炫耀武力的姿态, 别再跟着我了!"],
                ["你要战便战!"],
                ["不要试图激怒我."]
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 离我的阵列远点! 我目前没有精力处理你这个变数."],
                ["[" + _player_name + "], 你这种如影随形的武力示威让我感到不悦. 你想通过这种方式证明自己凌驾于法则之上吗?"],
                ["又是你. 看来实力的膨胀让你彻底忘记了如何跟一位审判官保持安全距离."],
                ["[" + _player_name + "], 拥有力量并不意味着你可以为所欲为. 在平原的秩序面前, 你的部队不过是稍微强壮一点的挑战者."],
                ["又见面了, [" + _player_name + "]."]
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["我说是谁在我的侧翼衔尾相随, 原来是投靠了 [" + _player_country_name + "] 的 [" + _player_name + "]. 既然你强行截停我的行军, 是想试试\"法典执行者\"的威力吗?"],

            ["你就是那个 [" + _player_name + "]? 带着如此规模的部队紧咬不放, 有什么目的?"],

            ["想必你就是最近名声显赫的 [" + _player_name + "] 了. 公然带兵截断我的行军路, 是自认为力量已经足以重写这片平原的法典了吗?"],

            ["竟然在此处被你截断. [" + _player_name + "], 作为 [" + _player_country_name + "] 的领主, 你的嗅觉确实灵敏."],

            ["原来是你, [" + _player_name + "]. 你强大的气场瞬间让我清醒了. 是想在这里跟我进行最后的较量吗?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["滚出我的视线!"],
                ["滚出我的视线!"],
                ["这是对我耐心的公开挑衅."],
                ["你我之间已无外交辞令可言."],
                ["有什么事? 我很忙."]
            ]
        else:

            return[
                ["又是你. [" + _player_name + "], 我的军阵随时能将你的野心击碎. 你是在此发起决死冲锋吗?"],
                ["又见到这面充满罪恶的旗帜了. 既然你执意拦路, 是打算在此开启两国之间的较量吗?"],
                ["来自 [" + _player_country_name + "] 的领主. 拦截\"审判之眼\"是需要付出沉重偿价的."],
                ["又见面了, [" + _player_name + "]. 以这种压制性的姿态靠近我, 可是非常危险的挑衅."],
                ["[" + _player_name + "], 看到你日益强悍的军势, 我感到既欣慰又惶恐. 看来星辰注定要让我们在血泊中分出高下."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["我是埃里克. 我已经了解过你在边境的罪恶行径. 在我的重剑被赋予裁决权之前, 请保持距离."],
            ["我是埃里克, [" + _target_country_name + "] 的大法官. 说明你的来意, 流浪者. 我的耐心只留给有秩序的人."],

            ["我是埃里克, 此地的秩序维护者. 你有什么目的?"],

            ["我是埃里克. 你的名声像划破夜空的流星, 虽然短暂, 但足够耀眼. 也许我们能谈谈."],
            ["我是埃里克, 执掌 [" + _target_country_name + "] 的法典. 听闻你以一己之力平息了一些不义的骚乱. 这种契约之外的公正, 很有趣."]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["你是想给自己增加一条\"阻碍公务\"的罪名吗?"],
                ["退后, 流浪者."],
                ["如果你没有带来新的呈报, 就请闭嘴."],
                ["你正在制造不必要的干扰."],
                ["还有什么事吗?"]
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 你在平原上的行为轨迹似乎毫无章法, 这真让我头疼."],
                ["又是你. 希望这段时间里, 你学会了如何遵循律法, 而不是像个毫无信条的雇佣兵一样四处流窜."],
                ["[" + _player_name + "], 重逢在预料之中. 你那柄毫无归属的剑, 是否找到了它应有的剑鞘?"],
                ["看到你的命数尚未走到终点, 我对此表示惊讶, [" + _player_name + "]."],
                ["好久不见, 老友. 来, 告诉我你最近的见闻."]
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:

        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["我是埃里克. 虽同在 [" + _target_king_name + "] 麾下, 但我觉得我们并不是一类人, 别指望我会将你列入正式的协作名册."],
                ["我是埃里克. [" + _player_name + "], 我不干涉有实力的同僚, 但前提是你的部队不要干扰我的计划."],
                ["我是埃里克. [" + _player_name + "], 我不干涉有实力的同僚, 但前提是你的部队不要干扰我的计划."],
                ["我是埃里克. 我听闻领地迎来了一位真正的秩序筑造者. [" + _player_name + "], 比起那些沉溺于虚荣的贵族, 我更欣赏你那冷峻的执行力."],
                ["终于见到你了, [" + _player_name + "]. 你的名字在战报中频繁出现. 希望你的判断力也如传闻般精准."]
            ]

        else:
            return[
                ["我是埃里克. [" + _player_country_name + "] 的领主 - [" + _player_name + "], 我阅读过关于你那些越界行为的卷宗. 在我管辖的防区内, 管好你那些不安分的士兵."],
                ["我是埃里克, [" + _target_country_name + "] 的领主. 你的口碑在我的评价中并不理想. 基于目前的和平契约, 我允许你通行, 但任何越轨行为都将被视为宣战."],
                ["我是埃里克, [" + _player_country_name + "] 的领主 - [" + _player_name + "]. 你这次前来有何目的."],
                ["欢迎, 异国的领主. 我观察到你在领地推行的法度非常严谨, 像你这样尊重秩序的人, 理应获得正式的外交礼遇."],
                ["我是埃里克. 很高兴结识一位头脑清醒的异国统治者. 你的战绩证明了你是一个值得尊敬的对手."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["请退后至安全距离."],
                ["我很忙, 没空陪你进行无意义的社交."],
                ["还有未被记录的议题吗?"],
                ["看来你还有未尽的行政事项需要确认?"],
                ["还有什么事吗?"]
            ]
        else:

            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    ["[" + _player_name + "], 作为同僚, 我不得不提醒你: 你那随性的作风正在不断挑战法典的容忍上限."],
                    ["[" + _player_name + "], 哪怕名义上是同僚, 我也没打算将时间浪费在你的无聊话题上."],
                    ["[" + _player_name + "], 如果让我抓到你违约的把柄, 即便同属一国, 在行刑时我也不会有半分迟疑."],
                    ["[" + _player_name + "], 在这乱世中, 法度的缺失比敌人的剑刃更致命."],
                    ["看到你安然无恙, 真是让人欣慰."],
                ]

            else:
                return[
                    ["来自 [" + _player_country_name + "] 的领主. 趁我还没决定为了旧日的纠纷对你出手, 立刻离开我的视线."],
                    ["又是你. 虽然两国维持着名义上的平衡, 但我依然会将你视为重点监察对象."],
                    ["又见面了, [" + _player_name + "]. 我不信任你, 更不信任你背后那个多变的政权. 请自重."],
                    ["即便和平契约在手, 我也不会对一个立场不明的异国领袖放松警惕."],

                    ["又见面了, [" + _player_name + "] 阁下. 在这平原上, 任何秩序的偏移都瞒不过我的眼睛."],
                    ["异国的领袖, 看来星辰的轨迹再次让我们重逢了."],
                    ["很高兴再次见到你, 正直的领主."],
                    ["很高兴看到你的旗帜. [" + _player_name + "] 阁下"],
                    ["久违了, 我的老友. 愿今日的重逢能共叙两国的和平."],
                ]


func get_battle_chat_charge()-> String:
    var _country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        "全军推进!",
        "冲锋！",
        "以法典之名, 清平前方障碍!",
        "突击！",
        "审判他们!",
        "裁决时刻已至, 一个不留!",
        "锁定目标, 彻底抹除!",
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "回归尘土吧",
        "你的旅途到此为止了",
        "真遗憾",
        "这你计算失误的必然结果",
        "判决已定, 当场执行",
        "愚蠢的抗争",
        "审判完成"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这便是星辰为你预选的葬礼, [" + _target_hero_name + "]."
        ])

    return _list.pick_random()


func get_battle_chat_injured()-> String:
    return[
        "啧...",
        "还没结束呢",
        "这种程度的攻击...",
        "很好...",
        "你想以此动摇法则的根基?"
    ].pick_random()


func get_battle_chat_die()-> String:
    return[
        "我的职责...到此为止",
        "法典...永不磨灭",
        "真是个, 意外的终局",
    ].pick_random()


func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军已至, 坚守阵位!",
        "星辰指引了这一刻的生机, 撑住!"
    ].pick_random()


func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "将他们彻底合围!",
        "保持阵列步调, 稳步推进!",
        "不准露出任何漏洞!",
        "步兵方阵前进!",
        "全军, 稳步向前!"
    ].pick_random()


func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "稳住阵脚! 切勿惊慌失措!",
        "全军原地驻守!",
        "妄图撤退者, 行刑队将当场执行逃兵法典, 绝不宽贷!",
        "守住这里!",
    ].pick_random()


func get_battle_chat_victory()-> String:
    return[
        "这就是忤逆秩序的必然代价",
        "胜负早已在星辰的推演之中",
        "这是一次高效的清算"
    ].pick_random()


func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [

            "看看你现在的样子, 埃里克. 现在你才是那个被法则剔除的, 最刺眼的杂质.",
        ],
        [

            "真是可惜, 伟大的审判官. 看来你那精密的星辰推演, 终究漏算了我这一柄生锈的剑."
        ],
        [

            "所谓的\"审判之眼\", 在钢铁军队面前原来也这么脆弱. 你的法典能替你挡住伤口的血吗?"
        ],
        [

            "你的判决书写早了, 埃里克. 现在被注销名字的人, 是你.",
            "埃里克, 秩序的枷锁已经从我身上转移到你手腕上了."
        ],
        [

            "埃里克. 放下你的重剑, 接受这个败局.",
        ],
        [

            "这就是终局了, 埃里克大人."
        ],
        [

            "胜负已分. 即便规律如星辰, 也有脱轨的时候."
        ],
        [

            "承让了, 埃里克大人. 这是一场近乎完美的精彩博弈."
        ],
        [

            "很遗憾, 埃里克大人. 请原谅我的无礼."
        ],
    ]


func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "别指望我会向你这种秩序的亵渎者低头. 法典虽有残损, 但绝不因强权而改变.",
        ],
        [

            "落入你这种只会制造混乱的人手中, 是我作为法典执行者生涯中最大的污点.",
        ],
        [

            "你的傲慢, 终将被星辰运行所带来的后果所反噬."
        ],
        [

            "既然我输掉了这一局, 要执行何种处刑随你."
        ],
        [

            "既然局势已向你倾斜, 继续抵抗将导致无意义的效率损耗. 我认了."
        ],
        [

            "我接受这份暂时的失利. 即便规律如星辰, 在漫长的岁月中也难免会有瞬间的脱轨."
        ],
        [

            "这一局是你赢了, [" + _player_name + "]. 你的战斗技巧在我之上."
        ],
        [

            "我接受这份失利. 你证明了自己是这片平原上比我更强悍的法则维护者.",
        ],
        [

            "战场之上各为其主, 盈亏自负罢了. 你不需要露出这种同情, 这并不是一名合格指挥官的所表现出的行为."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        [

            "别指望我会向罪恶妥协. 你大可执行你那低劣的处刑, 我的意志永不磨灭.",
            "有什么事? 难道是想炫耀你获得的短暂胜利吗?",
        ],
        [

            "如果是为了赎金, 那就开出一个符合我身份权重的价格. 作为领主, 你应该明白贪婪是导致灭亡的首要原因.",
            "收起你那傲慢的姿态. 法典执行者的尊严, 并不取决于他身处宫殿还是身处牢笼."
        ],
        [

            "我没兴趣进行多余的交谈."
        ],
        [
            "虽然作为俘虏不太体面, 但至少这给了我一个近距离观察你的机会. 你的行事准则, 很有研究价值."
        ],
        [
            "既然星辰预示了这一场禁锢, 那我就在这里等待下一次命运的跃迁.",
            "我从不相信运气, 但我开始相信你这个存在的必然性.",
            "在这静谧的暗处, 你我之间那些繁琐的头衔都已失效. 现在的我们, 只是两个试图在混沌中寻找出口的灵魂."
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "根据我的身份权重与当前的战略损耗, [#{0}] 德里是一个符合逻辑的偿付额度.",
        "我的家人愿意支付 [#{0}] 德里来解除这份囚禁协议.",
        "我的家人出 [#{0}] 德里来购买我的自由权.",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "账目已清. 记住, [" + _player_name + "], 下次见面时, \"法典执行者\"会亲自修正你这个污点.",
            "祈祷星辰永远眷顾你的卑劣吧, 因为罪恶的审判从不缺席.",
        ],
        [

            "理智的决定. 既然盈亏已抵消, 那就把路让开."
        ],
        [

            "交易达成. 我会将此次博弈的失败作为教训. 在下一次战斗, 你不会再拥有这种运气.",
            "很好, [" + _player_name + "], 账目已清. 现在, 我要重回我的岗位.",
        ],
        [

            "很好, 那么再见了, [" + _player_name + "]."
        ],
        [

            "你的决策效率令人印象深刻. [" + _player_name + "], 虽然王旗不同, 但我认可你的\"新秩序\". 期待下一次对战."
        ],
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [

            "[" + _player_name + "], 你到底在布什么局? 想等我踏出这道门, 再以\"越狱\"的名义从背后施以极刑吗?",
            "你要无条件释放我? 这简直是荒诞的剧本. 说吧, 你是在嘲弄法典的严肃性, 还是在前方设下了更卑劣的陷阱?",
            "我不接受这种带有羞辱性质的\"施舍\". 直说吧, 你想从这种虚伪的仁慈中获得什么?"
        ],
        [

            "你是想用我此刻的自由, 去换取未来某种更昂贵的, 足以让国家倾覆的筹码吗?",
            "你刚才的话...你是认真的?",
            "释放一名敌对的领主而不取分毫? 不要试图挑战我的判断力. 这种不合常理的行为背后, 到底藏着什么?"
        ],
        [

            "再确认一遍. 没有承偌, 没有德里, 没有任何形式的偿还. 你确定这符合你的统治利益吗?",
            "[" + _player_name + "], 你这是在主动制造一个无法弥补的亏空."
        ],
        [

            "这种气度...如果不考虑立场, 我甚至会以为你才是那个制定法则的人. 你真的不需要一笔赎金来供养你那庞大的行军开支?",
            "这种只会出现在圣殿骑士史诗里的\"高尚\", 竟然落到了我这个冷酷的审判官头上? 你真是让人捉摸不透."
        ],
        [

            "真的要放我走吗? 为了这种虚无缥缈的情谊, 而放掉一个足以左右战局的敌对重臣, 你的部下会视你为疯子吧?",
        ],
    ]


func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [

            "既然枷锁已除, 我不会对这种毫无原则的仁慈表达感激. 战场上见, [" + _player_name + "]. 届时, 法典会修正你今日的错误决策.",
            "放我离去是你统军生涯中最严重的一次错误. 下次对垒, 我的巨剑不会有半刻的迟疑.",
            "不要指望我会因为这份施舍而更改我的立场. 在法则面前, 你依然是需要被肃清的混乱之源."
        ],
        [

            "我会重新校准对你的评价, 再会.",
            "既然你选择主动放弃权益, 那我也没必要在此浪费口舌. 我这就离开."
        ],
        [

            "既然你执意要打破这平原上公认的代价法则, 我若不接受, 倒显得我连一个博弈者的胆识都没有. 再会.",
        ],
        [

            "如果你是为了让我背负无法偿还的情义, 那你赢了. 这种人情远比一万枚德里更沉重. 后会有期.",
            "你赢得了我的尊重, [" + _player_name + "]. 这并非出于那些迂腐的吟游诗歌, 而是因为你拥有凌驾于生存利弊之上的气量. 保重."
        ],
        [

            "真是...令人头疼的决策. 别死在那些无名小卒的手里, 我的朋友. 后会有期",
            "既然你把自由还给了我, 那我欠你一份人情. 在下次交锋前, 保重你的性命."
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "既然德里无法打动你, 那就用这件 [#{0}] 来清偿我的自由. 它的价值足以弥补任何账目上的亏空.",
        "我以此件 [#{0}] 为代价, 收回我在这片土地上的行动权.",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "我对你的厌恶属于私人情感, 而情感是影响判断的杂质. 单从法典的逻辑来看, 你今日的贡献完全达标.",
        "你完成了分内之事, 法典自然会给予你对等的评价. 至于我们之间的嫌隙, 那是另一条审判线的事.",
        "虽然我不喜欢你，但我不否认客观事实. 你今日的贡献值得赞赏.",
        "虽然你我立场不合, 你今日表现配得上勇士的称号."
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "我的行刑队在正面进行惩戒, 而你很好地稳固了侧翼的防守.",
        "这场胜利的损耗完全在我的计算之内."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "近乎完美的配合. 能遇到一个像你这样逻辑严密, 行事磊落的战友, 是我的幸事.",
        "无需多余的言辞来粉饰胜利. 你今日的战术执行精准得像星辰的轨迹."
    ]