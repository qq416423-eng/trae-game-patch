extends LordNobleDialogue

const HERO_UID: = "lord_hero_0011"

func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:

        return[
            "想给 [" + _king_name + "] 卖命? 先照照镜子吧. 在我眼里, 你连一颗生锈的零件都不如, 顶多算个长得比较抽象的靶子.",
            "就凭你? 卡兰特的垃圾站都不会回收你这种废料. 离 [" + _king_name + "] 远点.",
            "我没心情听死人的远大抱负. 滚出我的视线, 否则我会把你做成肉干."
        ]
    elif _rel_value <= -10:

        return[
            "去找 [" + _king_name + "]吧, 反正 [" + _king_name + "] 总是喜欢收集一些奇奇怪怪的破铜烂铁.",
            "我可不会为你这种赔钱货做担保. 想投靠就自己滚去找 [" + _king_name + "], 别指望我会拉你一把."
        ]
    elif _rel_value <= 10:

        return[
            "想入伙? 去见见 [" + _king_name + "] 吧. 只要你能创造出超过你饭碗的价值.",
            "卡兰特的法则很简单: 有用的人留下, 没用的拆掉. 去见见 [" + _king_name + "], 证明你不是后者.",
            "我只关心生意. 如果你能让 [" + _country_name + "] 变得更富裕, 去请示 [" + _king_name + "], 我不介意多一个队友."
        ]
    elif _rel_value < 30:

        return[
            "你的手脚还算利索, 是个值钱的货色. 去见 [" + _king_name + "] 吧, 我会告诉他, 你这把刀还算锋利.",
            "在这片草原上, 像你这么识时务的俊杰可不多. 去找 [" + _king_name + "] 谈谈, 也许咱们能一起发笔战争财."
        ]
    else:

        return[
            "哈, 我知道你块好料! 去找 [" + _king_name + "], 搞定你的席位. 等咱们联手, 那些残血敌将, 一个都别想跑.",
            "你是我见过最耐用的\"零件\". 快去见 [" + _king_name + "], 我已经等不及要和你一起收割那些蠢货的脑袋了."
        ]



func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "草原上的野狗都比你有用, 至少它们知道什么时候该扑上去撕咬.",
        "除了浪费这里的草料, 你在这场战斗中毫无建树. 滚开, 趁我还没把你当成猎物之前."
    ]



func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你在这里晃荡了半天, 却连一个像样的人头都没收割? 别在我的战利品堆里乱翻, 没出力的穷鬼不准碰这些财宝.",
        "你的身手简直是烂透了. 如果这就是你的实力, 我建议你把手里的剑卖了去换两袋干草饼, 至少那样能让你死得像个饱死鬼.",
        "胜负已定, 别指望我会分你一块铜板, 没见红的刀刃在这里可换不到酒喝.",
        "你在战场上的走位混乱得像只没头的苍蝇. 下次进来之前, 先把你的眼睛擦亮, 别干扰我收割那些值钱的首级."
    ]



func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "嘿, 老伙计, 你今天这副样子可有点衰. 下次动作快点, 我可不希望我的搭档是个只会看戏的观众.",
        "作为朋友我得提醒你: 在战场上不流汗的人, 迟早要流血. 下次多出出力, 好吗?"
    ]



func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "啧, 你这把生锈的破剑居然割下了这么多脑袋? 真是让人意外. 这笔血债算我欠你的.",
        "你今天展现出的狠辣劲儿倒是挺合我的胃口, 可惜咱们注定不是一路人."
    ]



func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "干得漂亮! 你刚才那一阵冲杀起码让我省下了几十支昂贵的精钢弩箭.",
        "如果战场上多几个像你这样无畏的猛士, 我的佣兵团起码能少死一半的人. 你的表现超出了我的预期.",
        "不得不承认, 我欠你一份人情."
    ]



func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "哈哈! 瞧瞧你干的好事. 咱们联手简直就是把这片土地变成了咱们的私人屠宰场! 我就喜欢你精准收割的样子, 这才是真正的猎人!",
        "你我并肩, 我负责在后面盯着那些残血的苍蝇，你负责在前面把挡路石全部敲碎. 这笔买卖，咱们稳赚不赔!",
        "收工了, 老朋友! 看到你刚才那辉煌的战果, 我的双手都要兴奋得发抖了."
    ]



func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "看来有人急着要把自己的脑袋送进萨仁老大的射击范围内. 听着，想找死的人多得是, 但敢对这支\"秃鹫部队\"拔刀的, 你是第一个. 准备好支付买命钱了吗?",
        "别乱动, 伙计. 你现在就像个立在平原上的活靶子. 再往前一步, 我们就得费点劲帮你收尸, 然后去萨仁老大那领一份\"清道夫\"的酬劳了."
    ]



func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "废话少说! 准备战斗!",
    ]



func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "放轻松, 今天我还没打算做这桩亏本买卖. 我这就走.",
        "我只是想近距离看看那张传说中的狙击弩, 确实挺吓人的. 既然大家都是为了生意, 就没必要把场面搞得这么血腥, 回见."
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        [

            "一个连领地都没有的亡命徒, 竟敢打我的主意? 看来你不仅穷, 还疯得无可救药."
        ],
        [

            "就凭你? 你这条命甚至不值得我扣一下扳机. 想死的方法有很多种, 而我这里只有最惨的方式. 滚, 趁我还没把你当成猎物剥皮."
        ],
        [

            "袭击我对你有什么好处? 是想领那点微薄的悬赏, 还是单纯觉得自己的命太硬了? 建议你再掂量掂量."
        ],
        [

            "嘿, 伙计, 你今天是不是喝了劣质的麦酒, 烧坏了脑子? 咱们现在的状态对彼此都挺划算. 别逼我亲手把你的脑袋摘下来挂在马鞍上, 那太麻烦了."
        ],
        [

            "你是疯了还是打算跟我开个昂贵的玩笑? 如果你是因为草原上的风太冷想找点热度, 我可以请你去喝两杯, 而不是在这里刀剑相向.",
            "老朋友, 这种玩笑可一点都不好笑. 把剑收起来, 咱们之间的交情可比你的命贵多了."
        ],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [

            "主动撕毁和平协议? 你是我见过最蠢的领主. 如果你渴望让这片草原变成屠宰场, 我便会成全你.",
        ],
        [

            "违约的人在卡兰特是不会有好结果的. 如果你执意要开战, 不超过两发弩箭, 我就能送你上路."
        ],
        [

            "撕毁协议意味着贸易的中断和无尽的死伤. 在你拔剑之前, 先算算你的金库够不够支付接下来的开支.",
            "你想让你的士兵为了你一时的脑热去当靶子吗? 和平是最划算的买卖, 而你正亲手砸了大家的饭碗."
        ],
        [

            "我以为咱们已经达成了最好的平衡. 别让一时的糊涂毁了大家发财的路子, 这对谁都没好处. 把你的剑收回鞘里.",
        ],
        [

            "我没听错吧? 我最看好的合作伙伴, 竟然带头破坏行规. 如果你非要跨过这道红线, 那我只能遗憾地把你当成目标, 精准收割了.",
            "没搞错吧? 如果你真的对我拔剑, 我就得履行我的职业守则, 把你那颗值钱的首级收下来送给 [" + _target_king_name + "] 了."
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [

            "既然你急着死在我的弩箭下, 那我就成全你! 兄弟们, 把这只不知死活的野狗给我撕碎!",
        ],
        [

            "亮出你的实力, 让我看看你能不能挡住我的第一轮齐射!",
            "既然你这颗脑袋不想要了, 那我只好费点劲把它收下来. 所有人, 开始狩猎!"
        ],
        [

            "谈话时间结束, 现在是收割时间. 希望你的身子骨能比你的嘴更硬一点.",
            "又一个自以为是的蠢货. 正好, 我的战斧正缺一些新鲜的血来润润刃口. 全军, 进入战斗位!"
        ],
        [

            "真遗憾，你居然选了最让我的失望的一条路. 现在, 你唯一可能的结果就是变成尸体了.",
            "我给过你活路, 伙计. 既然你非要往我的弩箭上撞, 那我只能把你埋进这片荒原的土里."
        ],
        [

            "这就是你的最终决定? 既然你坚持要跟我分个生死, 那我会用这把弩, 给你一个最干脆的交代.",
            "抛弃理智的后果可是很严重的, 老朋友. 既然你非要跨过这道红线, 我会亲手送你上路, 保证不让你感到太多痛苦."
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    return[
        [

            "这一战, 我会让你连本带利让你的财富吐出来! 去死吧!",
        ],
        [

            "那就用你的领地和首级, 来抵扣这份毁约的代价吧!"
        ],
        [

            "好吧, 那就让我的钢箭来教教你什么叫代价. 全军, 准备战斗!",
        ],
        [

            "你毁掉了我们之间的交情, 现在, 我只能从你的尸首上把损失捞回来了!"
        ],
        [

            "从这一刻起, 你我之间的账本彻底清零了. 既然你要开战, 那我就勉为其难把你的命收下了.",
            "这就是你的选择? 我的老伙计...好吧, 我会用我最快的弩箭送你最后一程, 算是对咱们交情的最后致敬."
        ]
    ]



func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_king_name: = DialogueCustomUtils.get_b_country_king_name()

    return[
        [

            "[" + _player_name + "], 你这颗脑袋在 [" + _target_king_name + "] 那里的赏金可是每天都在涨. 既然你自己送上门来, 那我就收下这份厚礼了.",
            "全军听令, 把这群杂碎给我钉死在荒原上!"
        ],
        [

            "[" + _player_name + "], 准备好变成我狙击弩下的下一个亡魂了吗? 你的军队在我眼里, 不过是一堆移动的靶子罢了. 动手!"
        ],
        [

            "既然在战鼓声中碰了面, 那就别指望我会手下留情. 希望你的盾牌能撑得久一点. 准备接战!",
        ],
        [

            "[" + _player_name + "]. 拔出你的剑, 我会用卡兰特最精准的弩箭为你送行.",
            "来吧, 让我看看你到底有多少本事. 为了表示敬意, 我会亲自扣动扳机, 送你上路."
        ],
        [

            "这是草原上最悲惨的重逢. [" + _player_name + "], 既然各为其主, 那咱们之间的酒局就等下辈子再续吧. 不必留情, 开战!",
            "我的老朋友, 这就是雇佣兵的命 - 昨天还在喝酒, 今天就要互割喉咙. 来吧, 让我看看你的本事有没有退步."
        ],
    ]



func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [

            "你说得对, 告辞."
        ],
        [

            "我这就消失, 不浪费你的弩箭."
        ],
        [

            "正如你所言, 这种亏本的买卖一点都不符合我的生存法则. 告辞."
        ],
        [

            "我刚才可能是酒喝多了, 还没打算把这颗脑袋送给你."
        ],
        [

            "这确实是个昂贵的玩笑. 我清醒了, 咱们还是谈谈下次去哪喝酒吧."
        ],
    ]



func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [

            "你说得对，撕毁这份协议对谁都没好处。"
        ],
        [

            "...这次算我失言了. 我还是更喜欢和平.",
        ],
        [

            "你说得对. 这确实不是一个聪明人该有的冲动行为.",
        ],
        [

            "你说得对. 我收回刚才那笔错误的\"投资\".",
        ],
        [

            "这种疯狂的念头就此作罢吧.",
        ]
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[

            ["你就是 [" + _player_name + "]? 我听说你的脑袋值不少钱. 在克瑞弗, 没人会放过会走路的钱袋. 准备好被我收割了吗?"],

            ["你就是 [" + _player_name + "]? 你的悬赏令已经贴满了这片区域. 能死在我的狙击弩下, 总比被野狗啃死要有尊严得多."],

            ["你就是 [" + _player_name + "]? 别浪费时间了. 拔出你的剑, 看看你值不值得我浪费一些弹药."],

            ["我是萨仁. 我关注你很久了, 身手利索, 是个值钱的货色. 放下武器跟我走, 我或许可以留你一命"],

            ["我是萨仁. 但既然你进了狩猎名单, 我也只能公事公办. 投降吧, 老伙计, 别逼我把你的骨头敲碎."]
        ]
    else:
        return[

            ["[" + _player_name + "], 这一次, 我会亲自决定你的死期."],

            ["[" + _player_name + "], 你的身价又涨了, 这对我来说可真是个好消息. 所有人, 别让这笔横财跑了!"],

            ["[" + _player_name + "], 你是这片平原上最会惹麻烦的人. 为了让我的账本收支平衡, 我必须在此把你清理掉."],

            ["站住, [" + _player_name + "]. 你应该明白, 交情归交情, 生意归生意. 既然你执意要在错误的计划里折腾, 我只能把你带回去了. 认命吧."],

            ["好久不见, 老朋友. 既然老天爷非要把你送到我面前, 那就让我们用战士的方式解决吧. 让我看看你的身手有没有变迟钝."]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["我是萨仁. [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 闯进了这里, 那就准备好用你的钱袋来支付赔偿吧."],

            ["我是萨仁. 既然你代表 [" + _player_country_name + "] 出现, 那我就得按这边的行情收点\"入场费\"了. 拔剑吧, 领主大人."],

            ["我是萨仁. 既然你选择了为 [" + _player_country_name + "] 卖命, 那我就只能在此终结你的合同了."],

            ["我是萨仁. 我看过你的情报, 是个会算账的高手. 可惜咱们各为其主, 不然我真想请你来共图大事. 拔剑吧, 这笔账只能用血来平."],

            ["我是萨仁. [" + _player_name + "], 像你这么有实力的对手可不多见. 能亲手收割一个让我钦佩的人物, 真不知道该说我是走运还是倒霉."]
        ]
    else:
        return[

            [
                "[" + _player_name + "], 你那面招摇的旗帜简直就是在引诱我的弩箭. 这一次, 我绝不会让你带着脑袋离开我的视线.",
                "放弃抵抗吧, [" + _player_name + "]. 我已经在脑子里模拟了一百遍把你射成刺猬的场景了."
            ],

            [
                "又见面了, [" + _player_name + "]. 既然你非要撞进我的收割区, 那我只好收下这份额外的财富了.",
                "[" + _player_name + "], 准备好在我的斧头下变成一堆烂肉吧!"
            ],

            [
                "别挣扎了, [" + _player_name + "]. 在我的狙击弩射程之下, 你的那些花招只会加速你的死亡."
            ],

            [
                "我的朋友 [" + _player_name + "], 在这里重逢可真不是什么好事. 但我萨仁从不因私废公, 我会给你留个全尸, 算是对朋友的最后优待.",
                "局势已经明摆着了. 既然你再次挡在我的财路上, 我只能用武力来结清咱们之间的交情了."
            ],

            [
                "[" + _player_name + "], 我早就料到咱们会有这么一天. 能在这乱世中和你对决, 倒也不算浪费了我的武艺.",
                "看到你的身影, 我这心窝子跳得真不痛快. [" + _player_name + "], 此刻你不是我的老朋友, 而是挡在我升官发财路上的障碍.",
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[

            ["我是萨仁. 你就是那个带着一群亡命徒到处晃悠的 [" + _player_name + "]? 截停我的去路, 是觉得你的脑袋太沉了, 想让我用弩箭帮你减减重吗?"],

            ["通缉名单上的臭虫 [" + _player_name + "]...你带着这么多人马咬着我的屁股不放, 有何目的?"],

            ["你就是 [" + _player_name + "]? 你手下这帮人的成色, 可不像是普通的流寇."],

            ["我是萨仁. 我听过你的名号, 是个狠角色. 但就算你手下兵强马壮, 这么公然拦截我的行军, 也算是很有胆量了."],

            ["我是萨仁. 你居然带着这种规模的部队来堵我? [" + _player_name + "], 你这可不是找老朋友喝酒的态度."]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["滚远点，别挡着老子发财!"],
                ["就别在这儿丢人现眼!"],
                ["跟着我可捞不到半块铜板!"],
                ["别再挑战我的耐性!"],
                ["还有什么事?"],
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 离我的军阵远点! 我今天可没心情跟你这尊瘟神做买卖."],
                ["[" + _player_name + "], 你这种如影随形的跟着我, 是想看看我马车上的战利品, 还是想看看我狙击弩里的冷箭?"],
                ["又是你. 看来实力的膨胀让你彻底忘记了什么叫安全距离"],
                ["[" + _player_name + "], 兵马多并不代表你能在这儿横着走. 谁的命都是只有一条."],
                ["又见面了, [" + _player_name + "]. 你的身形可比这平原上的太阳还扎眼."]
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[

            ["我说是谁在侧翼盯着我这块肥肉, 原来是投靠了 [" + _player_country_name + "] 的 [" + _player_name + "]. 截停我的路, 是想试试我的钢斧利不利索吗?"],

            ["你就是那个 [" + _player_name + "]? 带着这种阵仗紧咬不放, 你是觉得咱们之间的\"账单\"还没算清楚吗?"],

            ["看来你就是最近身价暴涨的那个 [" + _player_name + "] 了. 带兵拦截我的去路, 是自认为有本事吃掉我这支军队了?"],

            ["竟然在此处被你截断. [" + _player_name + "], 看来 [" + _player_country_name + "] 给你开的价码不低, 让你这么卖命地追着我."],

            ["原来是你, [" + _player_name + "]. 你是打算在这里跟我结清咱们之间的旧账吗?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["滚出我的视线!"],
                ["滚出我的视线!"],
                ["你这是在挑衅我!"],
                ["你我之间已经没什么好谈的了."],
                ["你我之间已经没什么好谈的了."]
            ]
        else:

            return[
                ["又是你. [" + _player_name + "], 拦截我可是要付出高昂\"买命钱\"的. 你是想在此向我开战吗?"],
                ["又见到这面让人不爽的旗帜了. 既然你执意拦路, 是打算在此结清咱们之间的旧账吗?"],
                ["又是你. [" + _player_name + "]. 拦截我萨仁的代价, 你承受得起吗?"],
                ["又见面了, [" + _player_name + "]. 以这种咄咄逼人的姿态靠近我, 可不是什么友好的信号."],
                ["我的老友 [" + _player_name + "], 看到你这军势, 看来咱们注定要在血泊里平掉这笔烂账了."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[

            ["离我远点, 流浪者. 你身上那股穷酸和腐烂的味道会影响我的心情"],
            ["我是萨仁. 像你这种只会浪费草料的野兔, 竟然还没被野狗叼走?"],

            ["我是萨仁, 你找我有何贵干? 如果是想讨杯酒喝, 那你找错人了."],

            ["我是萨仁. 你是个狠角色. 也许我们可以谈谈"],

            ["我是萨仁. 听闻你最近解救了几桩赔钱的买卖. 这种英雄行径, 虽然蠢, 但确实有点意思."]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["你是听不懂人话吗? 赶紧滚!"],
                ["滚远点!"],
                ["你还在这干嘛?"],
                ["你正在干扰我的行程."],
                ["还有什么事吗?"]
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你在平原上留下的臭味真让人作呕, 如果你是来求死的, 我今天可以给你个痛快."],
                ["你竟然还活着? 看来死神最近也变得挑食了, 连你这种垃圾都不肯收."],
                ["[" + _player_name + "], 咱们又碰面了."],
                ["看到你这颗脑袋还没被人拿去换酒, 我真是又惊讶又欣慰, [" + _player_name + "]."],
                ["好久不见, 老伙计. 来, 告诉我哪儿有值钱的买卖."]
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["别以为咱们拿同一个人发的饷钱我就会对你客气. 像你这种只会虚张声势的蠢货, 根本不配坐在这个位置上. 别挡我的路!"],
                ["[" + _player_name + "], 离我的马队远点. 我不喜欢和散发着软弱气息的同僚打交道, 这会拉低我的身价."],
                ["我是萨仁. 只要你没干扰我的作战计划, 咱们就能相安无事."],
                ["我是萨仁. 领地里总算来了个像样的狠角色. 比起那些只会吹牛的草包, 我更喜欢你这种满身血腥味的实干派."],
                ["终于见到你了, [" + _player_name + "]. 你的军功在 [" + _target_king_name + "] 的桌上堆了一大叠. 希望你的手段也如传闻般狠辣."]
            ]
        else:
            return[
                ["我是萨仁. 你就是来自 [" + _player_country_name + "] 的领主? 哼, 在我的地盘上最好夹紧尾巴, 我的弩箭可不讲什么外交礼仪."],
                ["我是萨仁. 你那张傲慢的脸让我想起了某些被我剥掉皮的猎物. 看在和平契约的份上我暂时不动你, 但如果你敢多管闲事, 我就亲自把你钉在界碑上."],
                ["我是萨仁, [" + _player_country_name + "] 的领主 - [" + _player_name + "]. 这么远跑来找我, 是想谈笔生意?"],
                ["欢迎, 异国的领主. 我听说你把部下训练得像秃鹫一样, 像你这么务实的人，咱们应该能聊得拢."],
                ["我是萨仁. 很高兴认识一位懂行情的异国领主. 你的战绩证明了你是一个值得尊敬的对手."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["滚出我的视线, 你这蠢货!"],
                ["滚!"],
                ["你还有什么事?"],
                ["看来你还有话要说. 朋友"],
                ["还有什么事吗? 老友."]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    ["又是你, [" + _player_name + "]. 离我远点, 我怕被你的愚蠢传染了."],
                    ["又是你. 哪怕名义上是同僚, 我也没打算给你这种只会拖后腿的废物半分好脸色."],
                    ["是你啊, [" + _player_name + "]."],
                    ["[" + _player_name + "], 你今天的气色不错嘛."],
                    ["看到你还没死, 我就放心了, 我敬爱的[" + _player_name + "]大人(坏笑)."],
                ]
            else:
                return[
                    ["[" + _player_name + "]. 你还没死在哪个阴沟里呢."],
                    ["又是你. 离我远点, 我的狙击弩容易走火."],
                    ["又见面了, [" + _player_name + "]. 我不信任你, 更不信任你背靠的国家. 请自重."],
                    ["[" + _player_name + "], 你的脑袋看来还稳稳地在脖子上挂着. 这很值得庆幸."],
                    ["久违了, 我的老搭档. 愿今日的重逢能给咱们都带点好运."],
                ]



func get_battle_chat_charge()-> String:
    return[
        "全军冲锋!",
        "把他们给我撕碎!",
        "一个也别放过!",
        "开始狩猎!",
        "冲锋!"
    ].pick_random()



func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你的破绽比我想象的要多",
        "这颗脑袋我收下了",
        "这就叫实力, 懂了吗?",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这是你这辈子最后一次失误了, [" + _target_hero_name + "]。"
        ])

    return _list.pick_random()



func get_battle_chat_injured()-> String:
    return[
        "啧...",
        "可恶!",
        "有点意思...",
        "想杀我?",
        "这笔账我记下了!"
    ].pick_random()



func get_battle_chat_die()-> String:
    return[
        "啧...结束了...",
        "我的死期...",
        "到头来...还是...",
    ].pick_random()



func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "都给我死守住！",
        "都给我撑住, 救兵到了!"
    ].pick_random()



func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "慢慢收网，一个也别放跑!",
        "保持距离!",
        "别乱了套, 稳扎稳打!",
    ].pick_random()



func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "都给我站稳了!",
        "原地驻守!",
        "守住这道阵线!",
        "把盾牌举高点!",
    ].pick_random()



func get_battle_chat_victory()-> String:
    return[
        "这就是跟我对赌的下场, 赔了个精光吧!",
        "又是一笔不错的进账, 虽然费了点功夫",
        "把值钱的东西都搜出来!"
    ].pick_random()


func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "看看你现在的样子, 萨仁. 现在你才是那只掉进陷阱里, 等着被剥皮的秃鹫.",
            "真是可惜, 萨仁. 看来你注定要赔了个精光.",
            "所谓的\"绞弦秃鹫\", 在真正的力量面前也只是头乱叫的乌鸦."
        ],
        [
            "萨仁, 你一直在算计别人的脑袋, 现在该算算你自己的脑袋值多少钱了."
        ],

        [
            "萨仁, 这场博弈你已经输了, 接受现实吧.",
            "胜负已分. 即便是最老练的猎人, 也有被猎物咬断脖子的时候."
        ],
        [
            "这就是结局了, 萨仁大人. 你让我付出了不少代价."
        ],
        [
            "承让了, 萨仁大人.",
            "很遗憾, 萨仁大人. 虽然我们的交情不错, 但立场注定了我们要分个高下."
        ],
    ]


func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[

        [
            "呸! 别在那儿装腔作势了. 有本事就现在动手!",
            "算我走眼, 竟然栽在你这种杂碎手里...就算我输了个精光, 你也别想从我这儿听到半句求饶!",
        ],

        [
            "你赢了, [" + _player_name + "]. 但别以为这是结局."
        ],

        [
            "愿赌服输. 你想怎么处置?",
        ],

        [
            "能把我逼到这份上, 你确实有实力."
        ],

        [
            "哎呀...真是丢脸. 说真的, 老朋友, 既然胜负已分, 能不能把这些该死的绳子解开? 我们可以找个地方喝一杯.",
            "输在你手里, 总比输在那些蠢货手里强. 只是这立场确实让人头疼, 下次咱们能不能换个不流血的方式谈生意?"
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        [
            "别用那种眼神看我. 有种就给我个痛快, 否则等老子出去, 第一件事就是把你干掉.",
            "怎么? 是想看我求饶, 或者, 想看我这个失败者的笑话?",
        ],
        [
            "收起你那副看战利品的嘴脸, 这让我觉得恶心."
        ],
        [

            "如果你是为了那笔赎金, 就最好开个克瑞弗人能接受的价. 狮子大开口只会让这桩买卖烂在你手里.",
        ],
        [
            "作为俘虏确实很丢人, 但我也算看清了. 你是个懂得怎么控制风险的人, 这种特质能让你活得更久."
        ],
        [
            "嘿, 老朋友, 既然咱们交情不错, 能不能在赎金单上给我打个折?",
            "我得承认, 你确实是个比我更狠的赌徒.",
            "在这里待着, 反倒让我觉得轻松. 没那帮痞兵吵闹, 没那些算不完的烂账...只有咱们这两个倒霉的赢家和输家."
        ],
    ]



func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "算清楚了, 我的脑袋值 [#{0}] 德里. 拿上这笔钱, 咱们就此两清.",
        "我的那帮兄弟已经凑齐了 [#{0}] 德里, 用来换取我的自由.",
        "[#{0}] 德里换我的自由. 说实话, 这个买命钱已经足够你在酒馆挥霍大半年了, 放我走吧.",
    ]


func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [

            "账结清了. 记住, [" + _player_name + "]. 下次见面我会连本带利把这笔账收回来. 在那之前, 看好你的后脑勺.",
        ],
        [

            "明智的选择, 既然两清了, 就没必要再盯着我看了."
        ],
        [

            "交易达成, 我会记住这次教训. 下次对垒, 我的弩箭不会再射偏. 再会.",
            "很好, [" + _player_name + "], 两清了. 现在我要回去重整旗鼓. 等着瞧."
        ],
        [

            "合作愉快, [" + _player_name + "]. 虽然作为输家不太光彩, 但你是个爽快的生意人."
        ],
        [

            "你的手段确实够狠. [" + _player_name + "], 虽然咱们立场不同, 但我喜欢你的风格. 别死得太早, 我还指望着下次能赢回来."
        ]
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [

            "[" + _player_name + "], 你打的什么算盘? 想等我走出大门, 再把我当成移动靶子? 这种杀人灭口的戏码我可见多了.",
            "不要钱? 别开这种拙劣的玩笑. 你是想用这种虚伪的仁慈来羞辱我, 还是打算在前面路上设伏?",
            "我不接受这种带有施舍味道的\"好意\". 说吧, 你到底想要什么?"
        ],
        [

            "你是打算放长线钓大鱼? 想用我这条命, 以后去换更昂贵的筹码吗?",
            "你确定脑子没被战斧劈坏吗? 这种白送钱都不要的事, 可不像是个聪明人干得出来的."
        ],
        [

            "我没听错吧. 你确定这笔赔本买卖符合你的利益吗?",
        ],
        [

            "[" + _player_name + "], 你这是在主动给自己制造坏账. 这在生意场上可是大忌.",
            "这种气量...你真的不需要一笔赏金来填补你那帮士兵的胃口吗?",
            "我没听错吧? 这种仁慈, 竟然落到了我头上? 你真是个怪胎."
        ],
        [
            "真的要放我走? 为了这种虚无缥缈的交情, 放掉一个随时可能反咬你一口的对手? 你的部下肯定觉得你疯了."
        ]
    ]


func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [

            "既然你愿意当个放走猎物的蠢货, 我没理由不接受. 下次交手, 我会让你明白\"仁慈\"是这片土地上最没用的品质.",
            "放我走是你这辈子做的最亏的生意. 等下次见面, 我的战斧可不会想起你今天的\"施舍\"."
        ],
        [

            "既然你执意要当圣人, 那我也没必要在此浪费口舌. 我这就离开."
        ],
        [

            "既然你执意要打破这片土地上的生存法则, 我若不走, 倒显得我连占便宜都不会了. 后会有期."
        ],
        [

            "既然你把自由白送给我，那就算我欠你一次。在下次咱们刀兵相见前，把命给我留好了。"
        ],
        [

            "如果你是为了让我背负一辈子还不起的人情债, 那你赢了. 再会.",
            "啧, 真是麻烦. 别死在那些无名小卒手里, 否则我就没机会还你这个人情了. 保重.",
        ]
    ]



func _get_release_hero_equipment_content()-> Array:
    return[
        "看来你很识货, 拿走这件 [#{0}] 吧. 然后放我走.",
        "那就用这件 [#{0}] 来顶账. 在行家眼里, 这玩意可值钱得多.",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "倒真没料到你会带兵冲进来. 怎么, 怕我死在这, 以后没人和你作对了?",
        "我以为你巴不得看到我在这片草原上被人拆成零件, 你居然会来助战?",
        "啧, 多管闲事. 不过...确实帮我保住了不少本钱.",
        "我对你的私人成见可不会因为这次助战就一笔勾销.",
        "下次要是你陷入僵局, 可别指望我会拿着家伙去救你. 我顶多在边缘收割几个残血."
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "真是一场舒适的狩猎.",
        "卡兰特的生存法则告诉我, 要跟懂得计算利益的人合作. 看来咱们都是同一类务实的人."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 老搭档, 这次配合得真不赖!",
        "痛快! 你把猎物赶出来, 我负责在边缘精准收割, 只有和你配合才能拿到最高的利润, 冒最小的险.",
        "辛苦了, 我的好战友!"
    ]