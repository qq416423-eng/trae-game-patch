extends LordNobleDialogue

const HERO_UID: = "lord_hero_0012"


func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:
        return[
            "一个满身污秽气息的流民, 也妄想加入 [" + _country_name + "]? 你唯一的价值就是被我的重锤彻底修正.",
        ]
    elif _rel_value <= -10:
        return[
            "想为陛下效力? 先学会怎么挺直你的身体. 我不认为 [" + _king_name + "] 有时间去接见一个连基本操守都无法保证的流民.",
            "我拒绝为一个行踪可疑的人做担保."
        ]
    elif _rel_value <= 10:
        return[
            "去向陛下证明你是一块有用的精钢, 而非只会消耗粮草的残次品.",
            "我只认同律法. 如果你能在不破坏规矩的前提下建立功勋, 我不反对你成为 [" + _country_name + "] 的一员."
        ]
    elif _rel_value < 30:
        return[
            "你的行事风格很有条理, 这在罗德里很难得. 去见 [" + _king_name + "] 吧, 我会告知陛下, 你是一块值得锻造的好料.",
            "在这片混乱的土地上, 像你这样懂规矩的勇士不多了. 去找陛下谈谈吧, [" + _country_name + "] 的战阵需要你这样稳定的锚点."
        ]
    else:

        return[
            "我的老友, 你是我亲眼评估过的最完美的战力. 去找 [" + _king_name + "] 吧, 我会向陛下担保, 你将是 [" + _country_name + "] 最坚不可摧的支柱之一.",
        ]



func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "你在这场战斗中完全没体现出价值. 滚出我的视线, 别让你的无能干扰了我的行军计划."
    ]



func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你在战场上的表现极其平庸. 如果你无法精准地落实在你应该处于的位置上, 那么你只会拖慢整支军队的步调.",
        "战斗不是儿戏. 你这种低效的行径是在挑战我的容忍度.",
        "看看你的武器, 上面连一丝血迹都没有.",
    ]



func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "嘿, 老友. 你今天的表现太让我失望了. 我不希望在未来的某场决战中, 因为你这个点的松动导致整个防线的崩溃.",
        "作为战友我得提醒你: 怠慢的战斗就是自寻死路. 下一次, 我要求你的重击必须精准地落在对应的位置上. 明白吗?"
    ]



func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "虽然我依旧不信任你, 但我不得不承认, 你这一重锤下去确实为帝国清除了不少顽疾. 这份战功我会如实上报.",
        "你展现出的破坏力强大到得令人畏惧. 但是这笔人情, 我会记下."
    ]



func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "干得漂亮. 你是一个极其稳定且高效的帮手.",
        "如果我的战士都能像你一样准确地找到敌人的死穴, 我的\"铁律\"也就不必整天校准敌人的脑袋了. 你的表现令人印象深刻.",
        "必须承认, 由于你的存在, 这场战斗的胜算被提前锁定了."
    ]



func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "你粉碎他们的战阵, 这才是真正的战争艺术. 老友, 我们的配合简直无可挑剔!",
        "看到那些乱军在律法的压迫下分崩离析, 我这把老骨头都觉得舒展到了骨子里. 打得痛快!"
    ]



func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "你踏入了不该触碰的禁区. 在\"铁律\"莫尔德大人校准你的骨头之前, 最好先想清楚.",
    ]



func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "废话少说！我倒要看看你们的\"铁律\"能不能挡住我的剑!",
    ]



func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "放轻松. 我这就离开.",
        "我只是来确认一下你们的阵型是否有传闻中那么死板. 既然大家都不想增加无意义的损耗, 那就此别过."
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        [
            "一个居无定所的暴徒, 竟敢试图在律法的边缘横跳? 看来你这个隐患注定要被我的重锤彻底修正."
        ],
        [
            "无知的暴徒. 你那拙劣的挑衅不仅毫无意义, 更是在透支你卑微的命数."
        ],
        [
            "袭击一名帝国领主? 这种毫无逻辑的行为除了增加无谓的伤亡, 对你有什么益处? 我建议你重新评估下自己.",
            "如果你是因为渴望战斗而烧坏了脑子, 我建议你去找个木桩发泄. 别逼我在这里对你执行\"铁律惩戒\"",
        ],
        [

            "这种玩笑是在藐视秩序. 收起你的剑, 趁我还没把你当成必须排除的危险人物之前."
        ],
        [

            "你是疯了吗? 还是打算用这种自杀式的方式来考验我们的交情? 把武器放下, 老友. 这种疯狂的行径不该出现在你我之间.",
        ],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "主动撕毁神圣的和平契约? 你是我见过最不知羞耻的领主. 如果你选择了让这片土地陷入战火, 我便会用重锤将你这一\"混乱源\"彻底粉碎."
        ],
        [
            "你没搞错吧? 如果你执意要打破这来之不易的和平, 我的军团会让你明白什么叫\"无法承受的惩戒\""
        ],
        [

            "战争意味着物资的枯竭与阵线的崩塌. 在你拔剑之前, 先算算你领地内的存粮, 是否支撑得起你这种不智的狂妄.",
            "你想让你的部下为了你一时的冲动而化为尘埃吗? 和平是维护帝国经济繁荣的基石, 而你正在亲手摧毁它."
        ],
        [

            "我以为你我之间已经建立了一个稳固的平衡地位. 不要让一时的贪念毁掉了双方苦心经营的交情, 这对领地的子民毫无益处."
        ],
        [

            "我不敢相信...我最信任的朋友, 竟然要成为破坏秩序的恶徒. 如果你非要跨过这道红线, 那我只能履行职责, 亲自修正你这个致命的错误.",
            "我没听错吧, 这不符合你的行事准则. 如果你真的对我拔剑, 我就不得不将你的人头呈献给 [" + _target_king_name + "] 陛下."
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [

            "既然你执意要挑战律法的底线, 那我就成全你!",
        ],
        [

            "亮出你的武器, 让我看看你的骨头是否有你的狂妄那么硬!",
            "既然你拒绝接受秩序的引导, 那就接受铁锤的制裁. 所有人, 执行肃清!"
        ],
        [

            "现在是铁律校准的时间. 希望你的战阵能比你的言语更经得起重压.",
            "又是一个试图撼动铁律的暴徒. 可惜, 我的\"铁律惩戒\"从不出现偏差. 全军, 准备战斗!"
        ],
        [

            "真遗憾, 你居然选了最缺乏理智的一条路. 现在, 你唯一能发挥的作用就是成为反面教材了.",
            "伙计, 既然你非要挑战我的防线, 那我只能亲手把你埋进沙土里."
        ],
        [

            "这就是你的最终决定? 既然你坚持要以暴力终结平衡, 那我会用这柄重锤, 给你一个最尊严的了断.",
            "抛弃秩序的代价极其沉重, 老朋友. 既然你非要跨过这道红线, 我会亲自领军, 保证你的阵亡精准, 高效, 不带多余的情感."
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "这一战，我会用\"铁律惩戒\"让你明白, 践踏和平契约需要承受的代价! 受死吧!",
        ],
        [
            "既然契约无法约束你的野心, 那就用你的命来填补违约造成的损耗吧!"
        ],
        [

            "很好, 既然你选择了战争, 那就让 [" + _target_country_name + "] 的铁律来教教你什么叫后果. 全军, 开始清算!",
        ],
        [
            "你亲手摧毁了我们共筑的交情. 现在, 我只能通过抹除你, 来强行恢复这片土地的秩序了!"
        ],
        [
            "从这一刻起, 你我之间的交情已沉底. 既然你要开战, 那我只能履行领主的职责, 亲手终结你的错误.",
            "这就是你的选择? 我的老伙计...好吧, 我会用最沉重的一击为你送行."
        ]
    ]



func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_king_name: = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "[" + _player_name + "], 既然你执意要在领地上制造混乱, 我便会用重锤将你彻底抹除.",
            "全军列阵! 将这群不知死活的暴徒全部碾碎在沙土之中!"
        ],
        [
            "[" + _player_name + "], 在我的重锤面前, 你的阵型苍白得像一张纸. 全军, 作战准备!",
        ],
        [

            "既然两国的立场已在刀锋上交汇, 那就没必要进行多余的试探. 希望你的战意能撑得住我第一轮的冲击. 准备接战!",
        ],
        [

            "[" + _player_name + "], 握紧你的武器. 我会用 [" + _target_country_name + "] 最沉重的\"铁律惩戒\"来见证你的落幕.",
            "战场上不需要仁慈, 只需要效率. 为了表示对你的认可, 我会带头冲阵, 送你一个体面的终局."
        ],
        [

            "这是最令人遗憾, [" + _player_name + "]. 既然你我各自代表一方秩序, 那么私交便已在此断绝. 不要留情, 用你的全力来迎接我的重锤!",
            "我的老友, 这便是军人的宿命. 来吧, 让我看看你的武艺是否依旧强悍, 开战!"
        ],
    ]



func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [
            "我现在就消失, 不劳烦您亲自\"修正\"."
        ],
        [
            "我这就撤离."
        ],
        [
            "重新评估了胜算后, 我发现这种冲突只会产生无谓的损耗. 我该走了."
        ],
        [
            "看来是这里的风吹得我有些发昏了, 告辞."
        ],
        [
            "把剑收起来吧, 老友. 我们的平衡不该被这种冲动打破."
        ],
    ]



func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [
            "你说得对, 撕毁这份和平契约对我而言确实是个不明智的决策."
        ],
        [

            "...这次是我判断失误, 我收回刚才的挑衅."
        ],
        [

            "你说得对. 作为统治者, 我不该参与这种胜算不明的赌博."
        ],
        [

            "你说得对. 我收回刚才的话."
        ],
        [

            "你说得对, 秩序高于一切."
        ]
    ]



func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["你就是那个四处制造麻烦的 [" + _player_name + "]? 准备好接受\"铁律\"的修正了吗?"],
            ["我认得你, [" + _player_name + "]. 你踏入了不属于你的禁区. 与其像无头苍蝇一样乱撞, 不如死在我的重锤下, 这更符合律法."],

            ["我是莫尔德, 我没时间在这里浪费口粮. [" + _player_name + "], 拔出你的武器, 证明你不是一堆毫无价值的战争废料."],
            ["我是莫尔德. 我听说过你的耀人事迹. 但是这不妨碍你是我国的通缉犯. 放下武器, 接受制裁."],
            ["我是莫尔德. 老伙计, 律法面前没有例外. 既然你选择了脱离秩序, 我只能亲手将你带回正轨, 哪怕要敲断你的骨头."]
        ]
    else:
        return[
            ["[" + _player_name + "], 这一次, 我将彻底终结你的作恶生涯."],
            ["[" + _player_name + "], 你的每一次逃跑都在增加我国的追捕损耗. 所有人, 准备战斗!"],

            ["[" + _player_name + "], 你就像一颗顽固的锈钉. 为了让帝国的经济顺畅运转, 我必须在此把你拔除."],
            ["站住, [" + _player_name + "]. 私交无法影响律法的执行. 既然你执意在错误的轨迹上徘徊, 我只能强行校准了."],
            ["又见面了, 我的朋友. 在这混乱的世界中, 唯有战斗能给咱们的立场一个交代. 让我看看, 你的武艺有没有因为懈怠而退步."]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["我是莫尔德. [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 进入了我的惩戒范围, 那就做好觉悟吧."],
            ["我是莫尔德. 身为 [" + _player_country_name + "] 的领主的你, 既然在此与我相遇, 那就做好被惩戒的觉悟吧."],
            ["我是莫尔德. 作为 [" + _target_country_name + "] 的军事教头，我有义务铲除任何入侵者, [" + _player_name + "], 接战吧."],
            ["我是莫尔德. 我看过你的治军方略, 严谨, 高效, 是个值得尊敬的人. 可惜两国立场不同, 所以我只能用重锤来招呼你了."],
            ["我是莫尔德. 你就是鼎鼎大名的[" + _player_name + "]吧, 能在此终结你的战历, 是我作为军人的荣耀."]
        ]
    else:
        return[
            [
                "[" + _player_name + "], 你那面破损的旗帜已经干扰到了我的视线. 这一次, 我绝不会手下留情.",
                "放弃挣扎吧, [" + _player_name + "]. 我已经预料到你全军覆没的结果, 这一锤, 你是躲不掉的."
            ],
            [
                "又见面了, [" + _player_name + "]. 准备好在\"铁律惩戒\"的重压下化为尘埃吧!",
            ],
            [
                "停止无意义的行动吧, [" + _player_name + "]. 在我的防御阵面前, 你的任何花招都只是无谓的损耗."
            ],
            [
                "我的朋友 [" + _player_name + "], 在战场重逢真是可悲. 为了 [" + _target_country_name + "] 的荣光, 我会亲手送你离场, 并为你保留应有的尊严.",
                "我的朋友 [" + _player_name + "]. 既然你再次挡在了秩序的对立面, 我只能用武力来修正咱们的关系了."
            ],
            [
                "[" + _player_name + "], 这是咱们宿命中的对决. 虽然我更希望与你在酒桌上谈论律法, 但此刻, 我必须碾碎你这个阻碍.",
                "老朋友, 看着你的样子, 我竟然有些不忍下手. 但职责就是职责, 拿出你最强的实力, 别让我看轻了你."
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["你就是那个带着一堆暴徒四处流窜的 [" + _player_name + "]? 截停我的部队, 是觉得你的骨头已经硬到可以无视\"铁律\"的校准了吗?"],
            ["游荡者 [" + _player_name + "]...你带着这种规模的部队追随着我的侧翼, 是想测试我方的防线韧性吗?"],

            ["你就是 [" + _player_name + "]? 你麾下这支部队的纪律与阵型, 可不像是普通的流寇."],
            ["我是莫尔德. 我听过你的战绩, 是个狠角色. 但如此公然拦截我的行军路线, 即便是我, 也无法坐视这种无礼."],
            ["我是莫尔德. [" + _player_name + "], 你居然带着这种强悍的阵仗来堵我?"]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["别逼我强行肃清!"],
                ["还不离开?"],
                ["别再挑战我的耐心!"],
                ["你有什么目的?"],
                ["你还在试图寻找我方的漏洞吗?"],
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 离我远点! 我今天没心情处理你这个流寇."],
                ["[" + _player_name + "], 你如影随形地跟着我, 是想寻找防线的缺口, 还是想亲身体验一下重锤的冲击?"],
                ["又是你. 看来实力的增长让你彻底忘记了什么叫安全距离."],
                ["[" + _player_name + "], 兵马强壮并不代表你能干扰我的行进. 任何蠢蠢欲动的行为都会引来铁律的惩戒."],
                ["又见面了, [" + _player_name + "]. 你的军势在烈阳下, 可真是显眼得让人无法忽视."]
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["我说是谁在试图切断我的行军路线, 原来是 [" + _player_country_name + "] 的 [" + _player_name + "]. 拦住我, 是准备好承受阵线破碎的代价了吗?"],
            ["你就是那个 [" + _player_name + "]? 带着这种压迫性的阵仗紧咬不放, 你是觉得自己可以打败我吗?"],
            ["看来你就是最近名声大噪的 [" + _player_name + "]. 拦截我的去路, 是自认为有能力吞掉我的教卫军?"],
            ["竟然在此处被你截断了行军路线, [" + _player_name + "]. 看来 [" + _player_country_name + "] 给了你足够的信任, 让你来挑战我."],
            ["原来是你, [" + _player_name + "]. 你是打算在这里决一胜负吗?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["别逼我强行肃清!"],
                ["还不离开?"],
                ["别再挑战我的耐心!"],
                ["你有什么目的?"],
                ["你还在试图寻找我方的漏洞吗?"],
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 拦截一名帝国教头需要付出惨痛的代价. 你准备好开战了吗?"],
                ["又见到这面充满攻击性的旗帜了. 如果你执意阻拦我, 那就让重锤来决定谁才是这里的秩序."],
                ["又是你, [" + _player_name + "]. 拦截我莫尔德的代价, 你那帮乌合之众承受得起吗?"],
                ["又见面了, [" + _player_name + "]. 以这种咄咄逼人的阵位靠近我, 想必是打算与我这位旧识决一死战了."],
                ["我的老友 [" + _player_name + "]. 你这威严的军势...看来咱们注定要在铁与血的碰撞中校准彼此的立场了."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[

            ["离我的防线远点, 游荡者."],
            ["离我的防线远点, 游荡者."],
            ["我是莫尔德. 向我陈述你的意图."],
            ["我是莫尔德. 我听说过你, [" + _player_name + "]. 也许我们可以谈谈."],
            ["我是莫尔德. 我听说过你, [" + _player_name + "]. 也许我们可以谈谈."]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["离开这里!"],
                ["赶紧离开我的视线."],
                ["你还没离开吗?"],
                ["还有什么事吗?"],
                ["还有什么事吗?"]
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你像一只无头苍蝇一样乱撞. 如果非要找死, 我的重锤可以帮你."],
                ["你竟然还活着? 看来这片荒原的险恶还不足以抹除你."],
                ["[" + _player_name + "], 说吧, 这次拦住我又是为了什么?"],
                ["[" + _player_name + "], 你的身子骨看起来还算硬朗, 说吧, 找我这老骨头干什么?"],
                ["哈, 居然又撞见你了. 走, 陪我走一段, 顺便说说你又遇上什么麻烦了."]
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["别以为共事一主我就会认可你. 像你这种迟缓的蠢货, 只会增加帝国的损耗. 别挡道!"],
                ["[" + _player_name + "], 离我的教卫军远点. 我不允许涣散的作风传染给我的士兵, 这会降低整支军队的韧性."],
                ["我是莫尔德. 只要你的行动不干扰我的秩序, 我可以容忍你的存在。"],
                ["我是莫尔德. 我们这总算来了个狠角色. 比起那些软蛋, 我更喜欢你这种雷厉风行的作派."],
                ["终于见到你了, [" + _player_name + "]. 你在战斗中的破阵手段我有所耳闻. 希望你的实力如传闻般硬朗."]
            ]
        else:
            return[
                ["我是莫尔德. 你就是来自 [" + _player_country_name + "] 的领主? 你最好严格遵守帝国的铁律, 我的重锤从不宽恕违规者."],
                ["我是莫尔德. 你的脸让我感到厌烦. 看在和平协议的份上我暂时按兵不动."],
                ["我是莫尔德. [" + _player_country_name + "] 的领主 - [" + _player_name + "]. 你有何事?"],
                ["欢迎, 异国的领主. 我听说你治军手段极其严格且高效. 像你这么清醒的人, 我们或许有共同语言."],
                ["我是莫尔德. 很高兴认识一位作风硬朗的异国领主. 你的战历证明了你是一个值得尊重的人."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["停止这种无意义的跟踪, 你这蠢货!"],
                ["滚!"],
                ["你还没离开吗?"],
                ["还有什么事吗?"],
                ["还有什么事吗?"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    ["又是你, [" + _player_name + "]. 保持安全距离, 我不希望处理由于你的低效引发的事故."],
                    ["又是你. 哪怕名义上是同僚, 我也不会容忍一个时常制造麻烦的平庸之辈."],
                    ["[" + _player_name + "], 有什么事吗?"],
                    ["别整那些虚伪的礼节. 既然你我都为这面旗帜效力, 有什么困难就直说, 我听着呢."],
                    ["哈, 我的老伙计. 能和你这种明白人共事, 可以省去我不少麻烦."],
                ]
            else:
                return[
                    ["哪怕现在是和平时期, 我也不会对一个满身混乱气息的异国人展现友善. 滚开."],
                    ["又是你...离远点, 我怕我的重锤在会控制不住."],
                    ["又见面了, [" + _player_name + "]."],
                    ["[" + _player_name + "], 你的阵型看起来依然没有破绽. 作为一个异国人, 你这种治军之风倒是很合我的胃口."],
                    ["久违了, 我的老朋友. 愿今日的重逢能让咱们的交情像钢铁一样稳固."],
                ]



func get_battle_chat_charge()-> String:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        "碾碎他们的防线！",
        "为了 [" + _target_country_name + "] 的荣耀, 冲锋!",
        "将混乱彻底肃清!",
        "教卫军, 执行铁律惩戒!",
        "碾过去!"
    ].pick_random()



func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "破绽百出!",
        "简直是在侮辱战士的身份!",
        "你的技巧毫无意义",
        "这就是违抗铁律的代价"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "到此为止了, [" + _target_hero_name + "]"
        ])

    return _list.pick_random()



func get_battle_chat_injured()-> String:
    return[
        "不够重!",
        "这种程度的冲击...毫无意义",
        "继续, 别让我看轻了你!",
        "哼!",
    ].pick_random()



func get_battle_chat_die()-> String:
    return[
        "终究还是...",
        "铁律...永不熄灭...",
        "我先走一步...",
    ].pick_random()



func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "重整阵线! 援军已就位!",
    ].pick_random()



func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进, 保持阵型间距!",
        "像钢铁一样压过去!",
    ].pick_random()



func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "立盾! 筑成铁墙!",
        "原地驻守, 后退者军法处置!",
        "守住这道防线!",
    ].pick_random()



func get_battle_chat_victory()-> String:
    return[
        "混乱已被平定",
        "胜负早已在阵线碰撞的那一刻决定了",
        "战场已校准完毕"
    ].pick_random()



func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "看看你现在的样子, 莫尔德. 你引以为傲的铁律, 在我的利刃面前就像碎裂的废铁.",
            "教头大人, 看来你的最后一课教得不怎么样 - 你亲自演示了什么叫全军覆没."
        ],
        [
            "莫尔德, 你一直在校准别人的错误, 现在该看看你自己的败局该如何收场了."
        ],

        [
            "莫尔德大人, 胜负已分, 接受战败的结果吧.",
            "胜负已分. 莫尔德大人, 即便是最严密的防御, 也有被敲碎的一天."
        ],
        [
            "这就是结局了, 莫尔德大人. 为了突破你的防线, 我可是付出了超乎预期的损耗."
        ],
        [
            "承让了, 莫尔德大人. 你的重锤依旧致命, 可惜这次运气站在了我这边.",
            "很遗憾, 老友. 虽然我很敬佩你的为人, 但战场的法则是冷酷的, 我们不得不分出高下."
        ],
    ]



func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "呸! 别在那儿摆弄你那副胜利者的嘴脸. 有本事就现在敲碎我的骨头!",
            "是我低估了你的能力...即便我被俘, [" + _target_country_name + "] 的意志也不会向你这种人低头!",
        ],
        [
            "没什么好说的. [" + _player_name + "]. 但你记住, 纯粹的武力永远无法构建长久的秩序."
        ],
        [
            "我的战术出现了偏差. 你想如何处置这具残躯?",
        ],
        [
            "能击垮我的防御, 你确实是一个合格的统帅. 死在你手里, 不算辱没我的名声."
        ],
        [
            "咳...真是难看.",
            "输在你手里, 我没什么好抱怨的."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "要杀便杀, [" + _target_country_name + "] 的教头从来不会为了苟活而低头.",
        ],
        [
            "怎么? 是想看我这块硬骨头如何生锈的?",
        ],
        [
            "如果你是为了赎金, 就开个符合双方预期的价. 别玩那些无用的心理博弈, 那只会浪费我们彼此的时间.",
        ],
        [
            "成为敌军俘虏确实是我战历上的污点. 但不得不承认, 你的战术执行力极其惊人."
        ],
        [
            "老友. 在这里待着, 反倒让我那颗被军务塞满的脑袋清醒了不少. 现在, 该谈谈如何让我重返阵线了吧?"
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "根据评估, 我的自由价值 [#{0}] 德里. 拿上这笔钱，放我回去.",
        "我的家人已经筹备了 [#{0}] 德里用于赎回我的自由. 你没理由拒绝.",
    ]


func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "很好. 记住了, [" + _player_name + "]. 在下次交锋前, 别让你的阵线有所破绽.",
        ],
        [
            "交易达成, 我会反思这次败局. 下一次, [" + _target_country_name + "] 的铁锤不会再给你任何可乘之机.",
        ],
        [
            "赎金已结清, 就此别过.",
            "很好, [" + _player_name + "]. 现在我要回去重整防线, 希望你下次还能保持这种水准."
        ],
        [
            "交易达成. [" + _player_name + "], 你是个非常清醒的统帅, 再会."
        ],
        [
            "这次是我棋差一招. [" + _player_name + "], 虽然立场注定我们定会再次碰撞, 但我期待下次与你对阵."
        ]
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 你到底想玩什么把戏?",
            "我不接受这种莫名其妙的施舍. 说出你的真实目的, 你到底想从我这里交换什么?"
        ],
        [
            "你是打算让我背负这种无法偿还的债务, 好在未来的心理战中占据高地吗?",
            "你确定你的神智还清醒吗? 放掉一个具备高度威胁的敌方将领, 这完全违背了战争的逻辑."
        ],
        [
            "我无法理解这种决策. 你确定放弃这笔赎金能为你的阵营带来更大的长期收益吗?",
        ],
        [
            "[" + _player_name + "], 你正在以一种极度冒险的方式进行赌博.",
            "我没听错吧, 这种事...你真的要放走一个随时会带兵杀回来的威胁吗？"
        ],
        [
            "你的部下若是知道你放弃了赎金, 必然会对你的统帅能力产生质疑. 你疯了, 老友."
        ]
    ]


func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "放我走是你这辈子犯下的最大的错误. 等下次钢锤落下时, 我不会想起你今天的这番\"表演\"."
        ],
        [
            "既然你坚持这种怪诞的仁慈, 那我没有理由拒绝. 后会有期."
        ],
        [
            "既然你执意要放我走, 我便收下这份自由. 但记住, 立场从未改变. 再会."
        ],
        [
            "这份人情重得超出了我的预想. 在下次咱们阵线重叠前, 我会尽可能避开你的防区. 保重."
        ],
        [
            "如果你是为了让我这种死板的老骑士寝食难安, 那你赢了. 这份情, 我莫尔德记下了. 再会.",
            "啧, 真是个麻烦的家伙. 保重, 老朋友.",
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "[#{0}], 它比那些冰冷的钱币更有价值. 拿走它, 放我回去.",
        "那就用这件 [#{0}] 来清算我的赎金. 这曾是我的荣耀, 现在它归你了. 放行吧.",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "你今日的助战, 完全偏离了我对你人格的评估.",
        "你今天的援助很受用. 我尊重这份客观战果, 哪怕它来自于一个我并不喜欢的家伙.",
        "不要以为一次出乎意料的助战就能消除我们之间的过节"
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "今日的损耗完全在我的控制之内, 做得好.",
        "你的部队展现出的纪律性让我刮目相看."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "老战友, 这就是我们联手用规则和铁血筑造的最高秩序.",
        "如果王庭的那群年轻军官都能有你一半的稳健, 我这个当教头的能多活二十年."
    ]