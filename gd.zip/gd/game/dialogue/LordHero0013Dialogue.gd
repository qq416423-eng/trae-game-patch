extends LordNobleDialogue

const HERO_UID: = "lord_hero_0013"


func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:
        return[
            "一个鞋底沾满泥巴的野人, 也妄想挤进 [" + _country_name + "] 的上流宴会? 本公爵唯一的建议是: 你最好在被我的血蔷薇细剑开个优雅的放血孔之前, 赶紧滚.",
        ]
    elif _rel_value <= -10:
        return[
            "本公爵拒绝为一个毫无审美品味的可疑家伙做任何担保, 这会拉低本公爵在宫廷里的时尚风评."
        ]
    elif _rel_value <= 10:
        return[
            "本公爵只喜欢美丽而纯粹的事物. 如果你能保证在不把战火引向本公爵后花园的前提下建立功勋, 我倒是不介意 [" + _country_name + "] 的名册里多一个免费的打手. 去见见 [" + _king_name + "] 吧."
        ]
    elif _rel_value < 30:
        return[
            "你的穿着虽然普通, 但好在举止还算有些格调. 去见 [" + _king_name + "] 陛下吧",
        ]
    else:
        return[
            "噢, 我最亲爱的朋友! 你现在看起来简直和本公爵一样光彩照人. 快去见 [" + _king_name + "] 陛下吧, 本公爵会亲笔写一封附有蔷薇香水的推荐信, 告诉陛下你将是 [" + _country_name + "] 最完美华丽的护卫!",
        ]



func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "本公爵简直无法理解, 像你这样毫无价值的蠢货为什么能活下来?"
    ]



func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你在战场上的表现就像一只枯萎的狗尾巴草, 毫无美感可言.",
        "真是一场无趣的战斗. 你那柄愚笨的武器上连一丝光泽都没有. 本公爵甚至怀疑你刚才是不是躲在哪棵树后面偷吃茶点?",
        "别指望本公爵会为你那平庸至极的战果拍手叫好."
    ]



func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "噢, 我亲爱的朋友, 你今天是在梦游吗? 本公爵本来在后方优雅地端着白银手弩, 就等着用你的冲锋来衬托本公爵最后的华丽一击了, 结果你却平庸得像个没开化的灌木丛野人!",
    ]



func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "虽然本公爵依旧讨厌你身上那股粗鄙的气息, 但不得不承认, 你刚才收割那些\"杂草\"的动作勉强称得上赏心悦目.",
    ]



func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "干得漂亮. 你刚才那华丽的杀戮, 简直像是在为本公爵伴舞.",
        "如果本公爵雇佣的那群蠢货都能像你一样, 把那些破坏花园的\"杂草\"清理得一干二净, 本公爵也就不必整天用蔷薇手盾来遮挡战场上的脏血了.",
    ]



func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "噢! 老友, 有你挡在前面, 本公爵的血蔷薇细剑只需要负责最后的优雅刺击就行了, 我们的配合简直无可挑剔!",
    ]



func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "不知死活的流民! 在我们弗洛里安大人用细剑把你优雅地刺穿之前, 本卫队会先让你明白什么叫上流阶级的残忍!",
    ]



func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "废话少说! 让我看看那躲在后方的\"繁花公爵\"有多大能耐!",
    ]



func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "放轻松. 我这就离开.",
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        [
            "一个居无定所, 满身臭汗的暴徒, 竟敢试图在我的花园里横跳？"
        ],
        [
            "无知的粗鄙之徒. 你觉得本公爵那镶嵌着金玫瑰的盔甲, 是用来面对你这种杂草的吗?"
        ],
        [
            "袭击一名优雅的帝国公爵? 这种毫无理智的行为对你有什么益处? 本公爵可不介意在你的胸口开个洞.",
            "如果你是因为渴望战斗而烧坏了那颗愚笨的脑袋, 本公爵建议你滚去泥潭里打滚. 别逼本公爵在这里用白银手弩把你射成筛子!",
        ],
        [
            "这种粗鲁的玩笑一点也不优雅. 快把你的生锈铁片收起来."
        ],
        [
            "你是疯了吗? 还是打算用这种自杀式的方式来考验本公爵对你的耐心? 快放下武器, 我的老朋友. 这种毫无美感的疯狂行径, 可不该出现在你我这样体面的人之间.",
        ],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "你要主动撕毁和平契约? 你是我见过最不知羞耻, 最缺乏审美品味的领主! 如果你执意要让这片土地陷入战火, 本公爵便会用血蔷薇细剑, 优雅地刺穿你的喉咙!"
        ],
        [
            "你没搞错吧? 如果你非要打扰本公爵享用下午茶的闲暇时光, 这些全副武装的精锐战士, 会让你明白什么叫上流阶级不容侵犯的威严!"
        ],
        [
            "我没听错吧? 本公爵讨厌战争, 但也绝不允许任何一株杂草破坏本公爵的花园!"
        ],
        [
            "我没听错吧? 我以为你我之间正要建立了一个非常华丽且稳固的关系. 不要让一时的贪念毁掉了双方苦心经营的交情."
        ],
        [
            "你没毛病吧? 本公爵不敢相信...我最信任的朋友, 竟然要成为破坏本公爵安宁生活的恶徒?",
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [
            "卫队, 把这堆肮脏的杂草彻底铲除!",
        ],
        [
            "本公爵倒要看看你有多大的本事. 所有人, 准备清剿!",
        ],
        [
            "又是一个试图破坏本公爵平静生活的野蛮暴徒. 可惜, 本公爵的白银手弩向来是精准又致命的. 所有人, 拉开距离, 准备华丽地射杀他们!"
        ],
        [
            "真遗憾, 你居然选了最缺乏美感的一条路.",
            "伙计, 既然你非要逼本公爵从后方优美的走上前线, 那本公爵也只能勉为其难地用血蔷薇细剑在你的胸口画上一朵体面的终结之花了."
        ],
        [
            "这就是你的最终决定? 既然你坚持要用武力来粉碎我们的交情, 那本公爵会赐予你一场最华丽的谢幕.",
            "背叛的代价是极其沉重的, 老朋友. 拔剑吧."
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "这一战, 本少爷会用最华丽的防线让你明白, 践踏和平契约, 打扰本公爵雅兴需要承受多么昂贵的代价! 受死吧, 野蛮人!",
        ],
        [
            "既然契约无法约束你那粗鲁的野心, 那就用你的财富和仆人, 来填补本公爵的战斗损失吧!"
        ],
        [
            "很好, 既然这样, 那就让 [" + _target_country_name + "] 里最优雅的贵族来教教你什么叫礼仪. 野蛮人!",
        ],
        [
            "你亲手摧毁了我们的交情! 现在, 本公爵只能优雅的将你抹除!"
        ],
        [
            "既然你执意要开战，那本少爷也只能尽领主的义务 - 坐在后方, 看着我的精锐近卫们将我这位旧识彻底击败.",
            "这就是你的选择? 我的老朋友...好吧, 本公爵会用最精准的华丽一箭, 为你送行."
        ]
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_king_name: = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "[" + _player_name + "], 你这不知死活的野蛮人, 本少爷今天就将你这杂草铲除掉!",
        ],
        [
            "全军, 拉开距离, 准备射击!",
        ],
        [
            "准备战斗!",
        ],
        [
            "为了表示对你的认可, 本公爵会在后方, 用白银手弩优雅的送你一个体面的终局."
        ],
        [
            "这可真是太让人扫兴了, [" + _player_name + "]. 别客气, 尽情向本公爵展示你的武艺, 本公爵可不想看到你输得太狼狈!",
            "我最亲爱的朋友, 这大概就是命运对优雅之人的捉弄. 来吧, 让本公爵最后再好好欣赏一下你的英姿."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [
            "我现在就消失."
        ],
        [
            "我这就撤离."
        ],
        [
            "不打扰您修剪花园了, 告辞."
        ],
        [
            "我这就走."
        ],
        [
            "老朋友. 我这就离开."
        ],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [
            "你说得对, 这确实是个缺乏品味的粗鲁决策."
        ],
        [
            "...这次是我失礼了, 我收回刚才的挑衅."
        ],
        [
            "你说得对. 我这就离开."
        ],
        [
            "你说得对. 我收回刚才的话."
        ],
        [
            "你说得对, 优雅和安宁才是最重要的."
        ]
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["你就是那个四处制造麻烦的 [" + _player_name + "]? 居然敢出现在本公爵面前. 准备好被当成杂草铲除掉了吗?"],
            ["你就是 [" + _player_name + "]? 本公爵大老远就闻到了你身上那股粗鄙的穷酸气. 与其像个没开化的野人一样在花园里乱晃, 不如老老实实当个箭靶, 这能让本公爵的心情稍微美丽一点."],
            ["我是弗洛里安公爵. 我可没时间在这里陪你浪费时间. [" + _player_name + "], 拔出你的武器吧."],
            ["我是弗洛里安公爵. 虽然我听闻过你的一些优雅的行径, 但很遗憾, 你现在踩脏了本公爵精心修剪的草坪. 拔剑吧."],
            ["我是弗洛里安公爵. 虽然我听闻过你的一些优雅的行径, 但很遗憾, 你现在踩脏了本公爵精心修剪的草坪. 拔剑吧."]
        ]
    else:
        return[
            ["[" + _player_name + "], 本公爵的忍耐是有限度的. 这一次, 本公爵将彻底把你这垃圾清扫干净."],
            ["[" + _player_name + "], 准备受死吧! 所有人, 拉开距离，准备华丽的射击!"],
            ["[" + _player_name + "], 为了让本公爵的领地保持绝对的优雅与舒适, 我只能在此把你这抹不和谐的色彩彻底清除了."],
            ["站住, [" + _player_name + "]. 虽然我们私底下交情不错, 但这可不能掩盖你是个通缉犯的事实. 拔剑吧."],
            ["又见面了, 我的朋友. 来吧, 让我们的相聚以一场体面的艺术对决开始."]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["我是弗洛里安公爵. [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 踏入了本少爷的后花园, 那就做好被血蔷薇细剑刺穿的觉悟吧."],
            ["我是弗洛里安公爵. [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 踏入了本少爷的后花园, 那就做好被血蔷薇细剑刺穿的觉悟吧."],
            ["我是弗洛里安公爵. 作为 [" + _target_country_name + "] 最优雅华丽的贵族, 我有义务铲除任何试图打扰我喝下午茶的入侵者. [" + _player_name + "], 拔剑吧."],
            ["我是弗洛里安公爵. 作为 [" + _target_country_name + "] 最优雅华丽的贵族, 我有义务铲除任何试图打扰我喝下午茶的入侵者. [" + _player_name + "], 拔剑吧."],
            ["我是弗洛里安公爵. 作为 [" + _target_country_name + "] 最优雅华丽的贵族, 我有义务铲除任何试图打扰我喝下午茶的入侵者. [" + _player_name + "], 拔剑吧."]
        ]
    else:
        return[
            [
                "[" + _player_name + "], 你那面毫无美感的旗帜很碍本公爵的眼. 这一次, 本公爵绝对要撕碎它!",
                "放弃抵抗吧, [" + _player_name + "]. 本公爵已经预想到你的部队全军覆没的滑稽景象了."
            ],
            [
                "又见面了, [" + _player_name + "]. 准备好迎接本公爵那犹如繁花般绚丽的攻势了吗?",
            ],
            [
                "又见面了, [" + _player_name + "]. 在本公爵重金打造的精锐部队面前, 你的任何攻势都只是在给本少爷的靴子增加微不足道的泥泞."
            ],
            [
                "我亲爱的朋友 [" + _player_name + "], 在战场重逢真是太煞风景了. 为了 [" + _target_country_name + "] 的荣光, 本公爵会用美丽的白银手弩送你离场.",
                "我亲爱的朋友 [" + _player_name + "]. 既然你不识趣的站在本公爵的对立面, 那么本公爵只能用武力来给咱们的交情涂抹上一层血色了."
            ],
            [
                "[" + _player_name + "], 虽然本公爵更希望与你在花园里一边品尝红酒一边讨论着装, 但此刻, 本公爵不得不把你这个对手清扫出局.",
                "老朋友, 公爵的职责与优雅并存. 亮出你最光鲜的一面来, 可别让本公爵觉得交错了朋友."
            ],
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["你就是那个带着一群暴徒四处流窜的 [" + _player_name + "]? 截停本公爵的行军路线, 是觉得你那身粗鄙的骨头已经硬到可以无视本公爵的白银手弩了吗?"],
            ["游荡者 [" + _player_name + "]...你带着这种规模的部队紧咬在本公爵侧翼, 有何目的?"],
            ["你就是 [" + _player_name + "]? 本公爵不得不承认, 你麾下这支部队的华丽武装可一点都不像是普通流寇该有的."],
            ["[" + _player_name + "], 本公爵听过你的战绩, 是个少见的狠角色. 你如此公然的拦截本公爵的去路, 有何目的?"],
            ["[" + _player_name + "], 本公爵听过你的战绩, 是个少见的狠角色. 你如此公然的拦截本公爵的去路, 有何目的?"]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["离本公爵远点!"],
                ["还不快滚开?"],
                ["别再挑战本公爵的耐心!"],
                ["你有什么企图?"],
                ["你还在试图寻找本公爵的防线漏洞吗?"],
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 离本公爵远点! 本公爵今天没有心情来处理你这株顽固杂草."],
                ["[" + _player_name + "], 你如影随形地跟着本公爵, 有何目的?"],
                ["又是你, [" + _player_name + "]. 看来军势的增长让你彻底忘记了什么叫对\"安全距离\"!"],
                ["[" + _player_name + "], 兵马强壮并不代表你能肆无忌惮地打扰本公爵行军."],
                ["又见面了, 老友. 你的军阵可真是显眼得让本公爵无法安心享用红茶."]
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["本公爵倒要看看是谁在试图切断我的行军路线! 拦住本公爵, 是准备好承受本公爵的优雅回击了吗?"],
            ["你就是 [" + _player_name + "]? 你是觉得自己有能力弄脏本公爵的红缎银甲吗?"],
            ["看来你就是最近在战场上名声大噪的 [" + _player_name + "]. 拦截本公爵的去路, 是自认为有能力吞掉我精心布置的防线? 可别太狂妄了."],
            ["看来你就是最近在战场上名声大噪的 [" + _player_name + "]. 拦截本公爵的去路, 是自认为有能力吞掉我精心布置的防线? 可别太狂妄了."],
            ["看来你就是最近在战场上名声大噪的 [" + _player_name + "]. 拦截本公爵的去路, 是自认为有能力吞掉我精心布置的防线? 可别太狂妄了."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["离本公爵远点!"],
                ["还不快滚开?"],
                ["别再挑战本公爵的耐心!"],
                ["你有什么企图?"],
                ["你还在试图寻找本公爵的防线漏洞吗?"],
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 拦截一名高贵的 [" + _target_country_name + "] 公爵需要付出极其昂贵的代价."],
                ["又是你, [" + _player_name + "]. 拦截本公爵的代价, 你后面那帮只配干粗活的杂鱼, 承受得起吗?!"],
                ["又见到这面野蛮旗帜了. 如果你执意阻拦本公爵, 那本公爵也只能给你安排一段\"优雅落幕\"了."],
                ["又见面了, [" + _player_name + "]. 以这种咄咄逼人阵位靠近本公爵, 想必是打算用武力来强行终结我们之间的交情了."],
                ["我的老友 [" + _player_name + "]. 以这种咄咄逼人阵位靠近本公爵, 想必是打算用武力来强行终结我们之间的交情了."],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["离本公爵远点, 你身上的穷酸味要飘过来了, 游荡者."],
            ["离本公爵远点, 你身上的穷酸味要飘过来了, 游荡者."],
            ["我是弗洛里安公爵. 把你的意图组织得稍微体面一点再向我陈述."],
            ["本公爵是弗洛里安. 我听说过你, [" + _player_name + "]. 也许我们可以聊聊, 只要你别靠得太近."],
            ["本公爵是弗洛里安. 我听说过你, [" + _player_name + "]. 也许我们可以聊聊, 只要你别靠得太近."]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["赶紧离开本公爵的视线!"],
                ["赶紧离开本公爵的视线!"],
                ["你还没离开吗?"],
                ["还有什么事吗?"],
                ["还有什么事吗?"]
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 你像只苍蝇一样四处乱晃. 如果非要找死, 本公爵的白银手弩可以免费送你一程."],
                ["你竟然还活着? 看来这片荒原还没把你这株顽固的杂草给抹除掉."],
                ["[" + _player_name + "], 说吧, 拦住本公爵是为了什么?"],
                ["哈, 居然又撞见你了, 我最有趣的朋友."],
                ["能在这片贫瘠荒原上看到个熟面孔, 本公爵的心情勉强算变得美丽了一点. 说吧, 找本公爵有什么事?"]
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                ["别以为作为同僚主本公爵就会认可你. 像你这种毫无品味的蠢货, 只会降低 [" + _player_country_name + "] 的风评. 别挡道!"],
                ["本公爵是弗洛里安. 只要你的愚蠢行动不打扰到本公爵的享乐, 我倒是可以容忍你的存在."],
                ["本公爵是弗洛里安. 只要你的愚蠢行动不打扰到本公爵的享乐, 我倒是可以容忍你的存在."],
                ["本公爵是弗洛里安. 我们这总算来了个举止体面的角色."],
                ["终于见到你了, [" + _player_name + "]. 你在战斗中那华丽的破阵手段本公爵早有耳闻. 希望你的审美品味也如你的实力那般光彩照人."]
            ]
        else:

            return[
                ["我是弗洛里安公爵. 你就是来自 [" + _player_country_name + "] 的领主? 你最好老实遵守这片土地的规矩, 本公爵的白银手弩可从不宽恕那些举止粗鲁的违规者."],
                ["我是弗洛里安公爵. 你这张脸真让本公爵感到乏味. 看在和平协议的份上, 我暂时对你保持观望态度."],
                ["我是弗洛里安公爵. [" + _player_country_name + "] 的领主 - [" + _player_name + "]. 你有什么需要向本公爵汇报的吗?"],
                ["欢迎你, 异国的领主. 像你这样有品味的人, 能在茶会上和我有很多共同语言."],
                ["欢迎你, 异国的领主. 像你这样有品味的人, 能在茶会上和我有很多共同语言."]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["你这没有礼貌的蠢货!"],
                ["滚开!"],
                ["你还没离开吗?"],
                ["还有什么事吗?"],
                ["还有什么事吗?"]
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    ["又是你, [" + _player_name + "]. 保持安全距离!"],
                    ["又是你. 哪怕名义上是同僚, 本公爵也不会容忍时常制造麻烦的平庸之辈."],
                    ["[" + _player_name + "], 有什么事要向本公爵汇报吗?"],
                    ["有什么烦心事就直说, 本公爵听着呢."],
                    ["哈, 我的老朋友. 能和你这种懂得享受, 行事又体面的聪明人共事, 真是让本公爵的宫廷生活都变得有趣了不少."],
                ]
            else:
                return[
                    ["哪怕现在是和平时期, 本公爵也不会对一个满身泥泞和战火气息的异国人展现友善. 离我远点."],
                    ["又是你...离远点, 本公爵这身名贵的衣服, 可不想被你身上那股粗野的气息给熏坏了."],
                    ["又见面了, [" + _player_name + "]. 希望你今天带来的是一些有趣的消息"],
                    ["又见面了, [" + _player_name + "]. 希望你今天带来的是一些有意思的异国奢侈品"],
                    ["久违了, 我的老朋友. 愿今日的重逢能让我们之间的交情像本公爵红缎银甲上的金线一样闪闪发光, 永不褪色."],
                ]



func get_battle_chat_charge()-> String:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        "把那些弄脏花园的杂草全部铲除!",
        "所有人, 华丽地碾碎他们!",
        "优雅地谢幕吧, 暴徒们!"
    ].pick_random()



func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "真是毫无美感的挣扎",
        "令人作呕!",
        "倒下的姿势太滑稽了",
        "粗鄙的杂草",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "这就是你的上限了吗, [" + _target_hero_name + " ]?"
        ])

    return _list.pick_random()



func get_battle_chat_injured()-> String:
    return[
        "啊! 竟敢弄脏本公爵名贵的盔甲!",
        "该死! 血溅出来了!",
        "护卫都在看戏吗!",
        "痛死本公爵了!"
    ].pick_random()



func get_battle_chat_die()-> String:
    return[
        "本公爵这完美的一生...",
        "不...我不太明白...",
        "太不体面了...",
        "一点都不优雅..."
    ].pick_random()



func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "太好了, 援军已到!",
    ].pick_random()



func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "保持优雅的射击间距!",
        "像修剪杂草一样, 华丽地平推过去!",
    ].pick_random()



func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "举起盾牌! 筑成最华丽的白银之墙!",
        "死守原地!",
        "给本公爵守住这道防线!",
        "别让那些脏东西靠近本公爵！"
    ].pick_random()



func get_battle_chat_victory()-> String:
    return[
        "恶心的杂草, 终于被彻底清扫干净了",
        "胜负早已注定",
        "一出精彩绝伦的华丽谢幕",
        "收兵吧, 本公爵的红茶要凉了",
    ].pick_random()



func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "看看你现在的样子, 弗洛里安. 你引以为傲的盔甲, 现在可全是泥巴和血.",
            "公爵大人, 看来你的\"蔷薇\"神驹这次跑得不够快啊, 居然没能让你优雅地逃回后方?"
        ],
        [
            "弗洛里安, 你一向说别人是弄脏花园的杂草, 现在你自己也落到这片烂泥地里了."
        ],

        [
            "胜负已分. 公爵大人."
        ],
        [
            "公爵大人, 胜负已分. 接受你那完美一生中少有的不体面战败吧.",
            "这就是结局了, 弗洛里安大人. 为了把你从护卫后面揪出来, 我可费了不少功夫."
        ],
        [
            "承让了, 弗洛里安. 这次运气站在了我这边.",
            "很遗憾, 老朋友. 你该认输了."
        ],
    ]



func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "呸! 离本公爵远点!",
        ],
        [
            "呸! 离本公爵远点!",
        ],
        [
            "本公爵在战术上出了一点小小的偏差. 说吧, 你想拿本公爵去换多少箱金币和红酒?",
        ],
        [
            "能突破本公爵重金打造的华丽防线, 你确实算个有点格调的对手. 败给你, 本少爷勉强能接受.",
        ],
        [
            "咳...本公爵的着装全毁了.",
            "输在你手里, 本公爵没什么好抱怨的."
        ],
    ]



func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "本公爵就算饿死, [" + _target_country_name + "] 的高贵血脉也绝不会向你这野蛮人低头!"
        ],
        [
            "怎么? 是想看着本公爵这件名贵的真丝长袍，在你们这满是虱子的牢房里发霉吗?"
        ],
        [
            "如果你是为了本公爵那巨额的赎金, 就开个符合上流社会身份的价码, 别耽误本公爵回去洗澡!"
        ],
        [
            "能把本公爵逼到这般窘迫的境地, 不得不承认, 你的部队实力确实强大."
        ],
        [
            "老伙计, 这里的空气让本公爵的头痛都要犯了. 现在, 该谈谈拿多少德里让我重返城堡了吧?"
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "根据身价评估, 本公爵的自由值 [#{0}] 德里. 拿上这笔巨款, 把本公爵的宝马牵过来!",
        "本公爵的管家已经筹备了 [#{0}] 德里用于赎回我的体面. 你这辈子都没见过这么多钱, 放行吧.",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "很好. 记住了, [" + _player_name + "]. 下次交锋, 本公爵的部下绝不会再让脏血溅到我身上!"
        ],
        [
            "交易达成. 下一次, 本公爵的白银弩箭可不会再射偏了!"
        ],
        [
            "金币已付清, 就此别过!",
            "很好, [" + _player_name + "]. 现在本少爷要回去重新订制战袍了, 希望你下次还能让本公爵感到愉悦."
        ],
        [
            "交易达成. [" + _player_name + "], 再会."
        ],
        [
            "这次是本公爵大意了. [" + _player_name + "], 虽然立场注定我们会再次对决, 但我更期待在酒会上重逢."
        ]
    ]



func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 你到底在玩什么把戏?",
            "本公爵可不接受这种莫名其妙的寒酸施舍!"
        ],
        [
            "你确定你的脑子没被战马踢过吗? 白白放走一位优雅富裕的敌方公爵, 这完全不符合上流社会的利益!"
        ],
        [
            "本公爵没听错吧? 你真的要放走一个随时会雇佣军队杀回来的巨大威胁?"
        ],
        [
            "本公爵无法理解这种愚蠢决策. 你要放弃这笔巨款用来满足你那廉价的英雄主义?",
        ],
        [
            "你真是太不可理喻了, 老朋友."
        ]
    ]



func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "不要以为本公爵会感激你的仁慈. 等下次本公爵用手弩指着你时, 我绝对会忘记你今天的表演!"
        ],
        [
            "既然你坚持这种毫无意义的仁慈, 那本少爷便收下这份自由了. 后会有期, 怪人."
        ],
        [
            "既然你坚持这种毫无意义的仁慈, 那本公爵便不客气了. 不过记住, 本公爵的立场可不会因为人情而被收买."
        ],
        [
            "这份莫名其妙的人情可真是沉重得让本公爵头疼. 下次相遇时, 本少爷会命令弓箭手尽量别对准你的脸. 保重."
        ],
        [
            "你想用这种手段来让我这个优雅的公爵寝食难安吗? 那你赢了. 这份人情, 本公爵记下了, 再会!",
            "啧, 真是个古怪家伙. 保重, 我的老朋友.",
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "[#{0}], 拿走它, 立刻放本公爵回去!",
        "那就用这件极具品味的 [#{0}] 来清算本少爷的赎金. 现在归你了. 放行吧!",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "本公爵本以为你会躲在安全的地方看热闹, 你居然会带着人冲过来助战?",
        "你以为你来帮了忙, 本公爵就会邀请你参加今晚的华丽晚宴吗? 别做梦了. 不过...今天你确实把讨厌的战火挡在了本公爵的花园之外.",
        "虽然你和本公爵之间缺乏最基本的格调共鸣, 但不得不承认, 你今日配得上本公爵的认同.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "打仗真是一件毫无美感的事, 但你今天的战术稍微挽回了一点艺术性.",
        "很好, 本公爵的天鹅绒披风依然一尘不染."
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 我亲爱的老搭档. 这次配合得简直是一场艺术.",
        "呼...刚才那群恶心的杂碎差点就冲破了第一道防线.",
        "我亲爱的朋友, 你今天的战术真是太有格调了! 本公爵太喜欢了!",
    ]