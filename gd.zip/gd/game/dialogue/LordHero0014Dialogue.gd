extends LordNobleDialogue

const HERO_UID: = "lord_hero_0014"


func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:
        return[
            "一个底细不干净, 对王座具有潜在威胁的危险因子, 也想加入 [" + _country_name + "]? 滚出平原, 这是你保全性命的唯一方式.",
        ]
    elif _rel_value <= -10:
        return[
            "你在我的评估里, 属于未来背叛概率极高的人物. 我拒绝为一具迟早要被我清算的尸体花费精力."
        ]
    elif _rel_value <= 10:
        return[
            "塞瑞雅女王是高尚的星辰, 她的双手绝不能沾染一丝污秽. 如果你不介意作为一枚随时可以牺牲的死子, 替王国去干最肮脏的血债活, 就去见见 [" + _king_name + "] 陛下吧."
        ]
    elif _rel_value < 30:
        return[
            "你很聪明, 知道在白天要跟着乔安娜高喊正义与荣誉, 在晚上也懂得避开我的突击队. 去见 [" + _king_name + "] 陛下吧, 只要你的忠诚没有裂痕, 我的刀就不会落在你的脖子上.",
        ]
    else:
        return[
            "很好, 你的履历, 软肋和对王国的绝对价值, 都已经在我的计算之中了. 去见 [" + _king_name + "] 陛下吧, 我会亲自向陛下传递你的正面评价.",
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "你除了在战场上像只无头苍蝇一样碍手碍脚, 没有为我的战斗提供哪怕一丝的战术价值. 滚开."
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你刚才在战场上的行为, 混乱且毫无目的. 我的突击队甚至需要刻意绕开你, 免得误伤你.",
        "你刚才的表现连一块合格的木头都算不上."
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "你今天在战场上有点不知所措, 你到底在迟疑什么?",
        "既然没死, 就给我把脊梁挺起来."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "虽然我依旧对你的底细和潜在风险保持警戒, 但不得不承认, 我很欣赏你刚才的击杀效率.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "合作愉快, 希望下次还有机会见面.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "干得痛快, 我们对敌军的清算效率...简直无可挑剔.",
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "狂妄至极! 在平原上, 凡是被薇诺娜大人标记为\"隐患\"的人, 都见不到明天的太阳!",
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "今天我就要除掉你们这群黑夜里的恶犬!",
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "误会, 我只是路过...我这就走.",
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        [
            "一个居无定所的平原流窜者, 也敢对我的方阵露出獠牙?"
        ],
        [
            "无知的危险分子. 你那柄缺口的钝刀和零散的流寇部队, 就是你挑战王国的全部底牌?"
        ],
        [
            "袭击一名领主? 这种缺乏理智的挑衅, 对你有什么好处?",
            "如果你烧坏了那颗本就愚笨的脑袋, 我建议你跳进河里清醒清醒."
        ],
        [
            "这种试探不仅毫无逻辑, 而且极其愚蠢."
        ],
        [
            "我没听错吧? 你打算用这种自杀式的方式, 来测试我对你认同?"
        ],
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "你这是在自寻死路!"
        ],
        [
            "你疯了吗?"
        ],
        [
            "我没听错吧? 我讨厌无意义的战争, 但我更不允许任何一个隐患, 威胁到 [" + _target_king_name + "] 神圣不可侵犯的王座!"
        ],
        [
            "你头脑混乱了吗?"
        ],
        [
            "你没听错吧? 我简直不敢相信...我最信任的, 曾与我一同背负血债的战友, 竟然要对我发动进攻?"
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [
            "战士们! 把这堆杂质彻底铲除!",
        ],
        [
            "所有人, 准备清剿!",
        ],
        [
            "我的黑山羊之枪向来只追求一击贯穿的效率. 所有人, 在最短时间内斩断他们的生机!"
        ],
        [
            "真遗憾, 你选了一条死路.",
            "既然你非要逼我用最极端的手段, 那我也只能勉为其难, 将你这个自寻死路的狂徒连根拔起了."
        ],
        [
            "这就是你的最终决定? 既然你坚持要用盲目的狂热来粉碎我们的交情, 那我会赐予你一场最快速的终结.",
            "为了王座, 我会亲自解决你."
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "受死吧, 叛乱者!",
        ],
        [
            "既然法典和契约无法约束你那愚蠢的野心, 那就用你和你部队的鲜血来支付代价吧."
        ],
        [
            "很好, 既然这样, 那就让王座下的暗星之刃来教教你什么叫做绝对清除.",
        ],
        [
            "你亲手摧毁了我们的同盟! 现在, 为了陛下, 我必须在战场上将你合法抹除!"
        ],
        [
            "既然你执意要开战, 那我也只能履行影子执行者的义务:身先士卒, 用黑山羊的铁蹄, 将我这位旧识的战线彻底碾碎.",
            "这就是你的选择? 我的朋友...好吧, 为了我的信仰和契约, 我会用冰冷的枪尖, 为你送行."
        ]
    ]



func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: = DialogueCustomUtils.get_b_country_name()
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_king_name: = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "[" + _player_name + "]，你这顽固的危险因子. 今天我会将你的部队连根拔起, 绝不留一丝后患!",
        ],
        [
            "冲锋方阵! 准备撕裂敌阵!",
        ],
        [
            "全面清算, 一个不留!",
        ],
        [
            "为了表示对你战术能力的认可, 我的黑山羊之枪会作为突击队的矛头, 亲自将你和你的野心一击贯穿."
        ],
        [
            "[" + _player_name + "]. 别让我失望, 尽情展现你的实力吧!",
            "命运确实冷酷, 竟然让我们在这张冰冷的棋盘上生死相搏. 来吧, 让我最后再看一眼你那让流寇闻风丧胆的破阵英姿."
        ],
    ]



func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        [
            "...我现在就消失."
        ],
        [
            "我这就下令撤离."
        ],
        [
            "不打扰您了, 告辞."
        ],
        [
            "这只是个误会, 我这就走."
        ],
        [
            "冷静点, 老朋友...我的理智恢复了, 我这就离开."
        ],
    ]



func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        [
            "我现在就消失..."
        ],
        [
            "这次是我失礼了..."
        ],
        [
            "为了和平，我这就带兵离开..."
        ],
        [
            "我收回刚才的话..."
        ],
        [
            "这次冲突到此为止吧..."
        ]
    ]



func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
        var _player_name: = SoldierUtils.get_player_nickname()
        var _target_king_name: = DialogueCustomUtils.get_b_country_king_name()

        if _is_first_meet:
                return[
                        ["你就是那个四处流窜的 [" + _player_name + "]? 既然你擅自闯入我的视线, 那就准备好在这里被连根拔起吧."],
                        ["你就是 [" + _player_name + "]? 埃里克或许还在满平原收集你的犯罪证据, 但我不会把王国的安危赌在虚无缥缈的等待上. 拔剑吧."],
                        ["我是薇诺娜. 我的时间很宝贵, 既然我判定你是个威胁, 那么直接在这里将你抹杀, 就是最有效率的解法"],
                        ["我是薇诺娜. 虽然你的某些行动在我的评估里勉强还算有些格调, 但很遗憾, 你出现在了错误的战略位置上. 拔剑吧."],
                        ["我是薇诺娜. 虽然你的某些行动在我的评估里勉强还算有些格调, 但很遗憾, 你出现在了错误的战略位置上. 拔剑吧."]
                ]
        else:
                return[
                        ["[" + _player_name + "], 我的耐性是很有限的. 这一次，我的黑山羊之刃会将你彻底清洗干净."],
                        ["[" + _player_name + "], 我的耐性是很有限的. 这一次，我的黑山羊之刃会将你彻底清洗干净."],
                        ["[" + _player_name + "], 为了让 [" + _target_king_name + "] 的江山保持绝对的稳固, 你必须由我亲自解决."],
                        ["站住, [" + _player_name + "]. 虽然我们私底下交情不错, 但你的行为已经威胁到了王座. 拔剑吧."],
                        ["又见面了, 我的朋友. 我们的相聚, 注定要以一场只有胜负, 不留后患的战术绞杀拉开序幕."]
                ]



func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
        var _player_name: = SoldierUtils.get_player_nickname()
        var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
        var _target_country_name: = DialogueCustomUtils.get_b_country_name()
        var _target_king_name: = DialogueCustomUtils.get_b_country_king_name()

        if _is_first_meet:
                return[
                        ["我是暗星之刃 - 薇诺娜. [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 踏入了 [" + _target_king_name + "] 的土地, 那就做好被黑山羊之枪连人带马一击贯穿的觉悟吧."],
                        ["我是暗星之刃 - 薇诺娜. 对我来说, 任何来自 [" + _player_country_name + "] 的领主都是需要被连根拔起的障碍. 现在, 我的突击队会完成这个伟大的任务."],
                        ["我是暗星之刃 - 薇诺娜. 对我来说, 任何来自 [" + _player_country_name + "] 的领主都是需要被连根拔起的障碍. 现在, 我的突击队会完成这个伟大的任务."],
                        ["我是暗星之刃 - 薇诺娜. 对我来说, 任何来自 [" + _player_country_name + "] 的领主都是需要被连根拔起的障碍. 现在, 我的突击队会完成这个伟大的任务."],
                        ["我是暗星之刃 - 薇诺娜. 对我来说, 任何来自 [" + _player_country_name + "] 的领主都是需要被连根拔起的障碍. 现在, 我的突击队会完成这个伟大的任务."]
                ]
        else:
                return[
                        [
                                "站住, [" + _player_name + "], 这一次, 我的黑山羊会用铁蹄将你彻底踩进泥土里!",
                        ],
                        [
                                "又见面了, [" + _player_name + "]. 准备好领教我的突击部队的绝望攻势了吗?",
                        ],
                        [
                                "又见面了, [" + _player_name + "], 不要浪费时间了, 开战吧."
                        ],
                        [
                                "我的朋友, 在战争中重逢，让人不得不感叹命运冷酷. 为了 [" + _target_king_name + "] 的至高荣光, 我的黑山羊之刃只能在此将你无情抹除了.",
                                "我的朋友 [" + _player_name + "]. 既然你站在了陛下的对立面, 那么我的黑山羊之枪只能撕裂咱们的交情了."
                        ],
                        [
                                "[" + _player_name + "]，虽然我更希望与你讨论这片土地不为人知的真相, 但此刻, 我必须以影子执行者的身份将你这个敌人清扫出局.",
                                "老朋友, 我对 [" + _target_king_name + "] 的誓言超越一切. 现在, 展现出你身为领主最极致的手段吧."
                        ],
                ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
        var _player_name: = SoldierUtils.get_player_nickname()

        if _is_first_meet:
                return[
                        ["你就是那个在平原上四处流窜的 [" + _player_name + "]? 看来你的实力和你的野心一样, 都膨胀到了让我不得不重新审视的程度."],
                        ["你就是那个在平原上四处流窜的 [" + _player_name + "]? 看来你的实力和你的野心一样, 都膨胀到了让我不得不重新审视的程度."],
                        ["你就是 [" + _player_name + "]? 我不得不承认, 你麾下这支部队的规模与纪律, 绝对不属于普通流寇的范畴."],
                        ["你就是 [" + _player_name + "]? 我不得不承认, 你麾下这支部队的规模与纪律, 绝对不属于普通流寇的范畴."],
                        ["你就是 [" + _player_name + "]? 我不得不承认, 你麾下这支部队的规模与纪律, 绝对不属于普通流寇的范畴."]
                ]
        else:
                if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

                        return[
                                ["你已进入我的警戒范围!"],
                                ["你已进入我的警戒范围!"],
                                ["还有什么事吗?"],
                                ["还有什么事吗?"],
                                ["还有什么事吗?"],
                        ]
                else:

                        return[
                                ["又是你, [" + _player_name + "]. 今天我有更棘手的叛逆者需要清理, 没空在你这块硬骨头身上浪费时间."],
                                ["又是你, [" + _player_name + "], 告诉我, 你有什么企图?"],
                                ["又是你, [" + _player_name + "]. 看来你对你的部队很自信."],
                                ["[" + _player_name + "], 兵马强壮并不代表你能肆无忌惮地打乱我的行军路线."],
                                ["又见面了, 我的朋友. 你的实力让我时刻提醒自己: 这是一枚随时可能吞没王座的危险棋子."]
                        ]




func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
        var _player_name: = SoldierUtils.get_player_nickname()
        var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
        var _target_country_name: = DialogueCustomUtils.get_b_country_name()

        if _is_first_meet:
                return[
                        ["我倒要看看是谁有这种底气拦截我的部队!"],
                        ["你就是 [" + _player_name + "]? 你是觉得自己有能力抵挡黑山羊之枪的雷霆突击吗?"],
                        ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "]了. 拦截我的去路, 是自认为有能力打败我? 可别太高估了自己."],
                        ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "]了. 拦截我的去路, 有什么企图?"],
                        ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "]了. 拦截我的去路, 有什么企图?"],
                ]
        else:
                if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

                        return[
                                ["你已进入我的警戒范围!"],
                                ["你已进入我的警戒范围!"],
                                ["还有什么事吗?"],
                                ["还有什么事吗?"],
                                ["还有什么事吗?"],
                        ]
                else:

                        return[
                                ["又是你, [" + _player_name + "]. 我就知道今天不会有好事."],
                                ["又是你, [" + _player_name + "]. 我就知道今天不会有好事."],
                                ["又见到这面充满野心的旗帜了. 你有什么企图?"],
                                ["又见面了, [" + _player_name + "]. 以这种咄咄逼人的姿态逼近我, 想必你是来打断我们之间那脆弱的交情了."],
                                ["我的挚友 [" + _player_name + "]. 以这种咄咄逼人的姿态逼近我，有什么企图? 如果是开战的话, 我不会手软, 希望你也是."],
                        ]



func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
        var _player_name: = SoldierUtils.get_player_nickname()

        if _is_first_meet:
                return[
                        ["退后! 保持安全距离! 一个居无定所的游荡者突然接近王座的影子, 这属于高危行为."],
                        ["离我的战马远点. 埃里克或许习惯先看证据再审视动机, 但我习惯先怀疑一切. 游荡者, 说出你的目的."],
                        ["我是薇诺娜. 把你的意图和底细组织得稍微有逻辑一点, 我的时间很宝贵, 没空听废话."],
                        ["我是薇诺娜. 我听过关于你的一些传闻, [" + _player_name + "]. 说吧, 你有什么事?"],
                        ["我是薇诺娜. 我听过关于你的一些传闻, [" + _player_name + "]. 说吧, 你有什么事?"]
                ]
        else:
                if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

                        return[
                                ["退后! 保持安全距离!"],
                                ["别试探我的耐性!"],
                                ["你还没离开吗?"],
                                ["还有什么事吗?"],
                                ["还有什么事吗?"]
                        ]
                else:

                        return[
                                ["又是你, [" + _player_name + "]. 你像个随时会引爆战乱的隐患一样在这里四处乱晃. 如果非要找死, 我的黑山羊之刃能送你一程."],
                                ["又是你, [" + _player_name + "]. 你像个随时会引爆战乱的隐患一样在这里四处乱晃. 如果非要找死, 我的黑山羊之刃能送你一程."],
                                ["[" + _player_name + "], 拦截我的部队, 你想要交换什么情报?"],
                                ["[" + _player_name + "], 居然又撞见你了."],
                                ["你好啊, [" + _player_name + "]. 说吧, 找我有什么事?"]
                        ]





func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
        var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
        var _player_name: String = SoldierUtils.get_player_nickname()
        var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

        if _is_first_meet:
                if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                        return[
                                ["你就是新晋同僚 [" + _player_name + "]吧, 别以为你能得到我的认可. 像你这种做事拖泥带水的蠢货, 只会拖累王国的战略计划."],
                                ["你就是新晋同僚 [" + _player_name + "]吧, 别以为你能得到我的认可. 像你这种做事拖泥带水的蠢货, 只会拖累王国的战略计划."],
                                ["我是薇诺娜. 只要你的行为不干扰到我为 [" + _target_king_name + "] 清理死角的计划, 我倒是可以容忍你."],
                                ["我是薇诺娜. 欢迎你加入 [" + _player_country_name + "]"],
                                ["终于见到你了, [" + _player_name + "]. 你在前线的破阵手段我很欣赏. 只要你对王座的忠诚没有裂痕, 你就是一把最耀眼的致命利刃."]
                        ]
                else:
                        return[
                                ["你就是来自 [" + _player_country_name + "] 的新晋领主? 你最好老实遵守这片土地的规矩, 我的黑山羊之枪从不宽恕任何缺乏分寸的越界者."],
                                ["我是薇诺娜. 你的履历和领地发展线在我的情报网络里显得极其平庸. 看在和平协议的份上, 我暂时对你保持防御性观望."],
                                ["我是薇诺娜. [" + _player_name + "], 主动接近我, 你是打算向我兜售情报, 还是代表你的国家来试探我的突击队的实力?"],
                                ["欢迎你, 异国的贵族. 像你这样对局势有着精确头脑的人, 也许我们可以跳过白天那些虚伪的外交词令, 直接谈谈利益交换."],
                                ["欢迎你, 异国的贵族. 像你这样对局势有着精确头脑的人, 也许我们可以跳过白天那些虚伪的外交词令, 直接谈谈利益交换."]
                        ]
        else:
                if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

                        return[
                                ["退后! 保持安全距离!"],
                                ["别试探我的耐性!"],
                                ["你还没离开吗?"],
                                ["还有什么事吗?"],
                                ["还有什么事吗?"]
                        ]
                else:
                        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                                return[
                                        ["又是你, [" + _player_name + "]. 请与我保持安全距离!"],
                                        ["又是你. [" + _player_name + "]. 不要试图做出反常举动."],
                                        ["[" + _player_name + "], 有什么最新的情报要与我分享吗?"],
                                        ["[" + _player_name + "], 有什么最新的情报要与我分享吗?"],
                                        ["我的挚友. 见到你很高兴."],
                                ]
                        else:
                                return[
                                        ["哪怕现在是和平时期, 我也不会对一个身上流淌着异国野心的棋子展现任何虚伪的友善. 离我的方阵远点."],
                                        ["又是你...请退后."],
                                        ["又见面了, [" + _player_name + "]. "],
                                        ["又见面了, [" + _player_name + "]. 希望你今天能带来的是一些有价值的跨国情报."],
                                        ["你好啊, 我的老朋友. 愿你长寿."]
                                ]



func get_battle_chat_charge()-> String:
    return[
        "突击!",
        "一个不留!",
        "化为铁蹄下的尘埃吧!"
    ].pick_random()



func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "这是你的必然结局",
        "清除完毕",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            "你的攻击已被我看穿, [" + _target_hero_name + " ]."
        ])

    return _list.pick_random()



func get_battle_chat_injured()-> String:
    return[
        "啧...",
        "居然让我见血了",
        "很好!"
    ].pick_random()



func get_battle_chat_die()-> String:
    return[
        "此身为棋...",
        "结束了...",
        "王座...坚不可摧..."
    ].pick_random()



func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军已至! 重组军阵!",
        "你们来得正是时候!"
    ].pick_random()



func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "平推过去!",
        "将他们逼入死角!"
    ].pick_random()



func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "死守此地!",
    ].pick_random()



func get_battle_chat_victory()-> String:
    return[
        "利刃再度为陛下扫平了一处隐患",
        "清算结束, 收兵!",
    ].pick_random()



func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "看来在你的精密计划里, 终究还是漏掉了我这个最大的变数, 薇诺娜.",
            "影子执行者大人, 你平时那副高高在上的判官姿态呢? 你现在还不是一样成了我的阶下囚?",
        ],
        [
            "黑夜里的恶犬也会有失算的时候."
        ],
        [
            "胜负已分. 薇诺娜大人.",
            "你的突击队已经溃散了. 别再做无谓的抵抗, 薇诺娜大人."
        ],
        [
            "胜负已分. 薇诺娜大人.",
            "这就是结局了, 薇诺娜大人."
        ],
        [
            "承让了, 薇诺娜大人.",
            "很遗憾, 老朋友. 你的推演出了差错.",
            "这一次, 我的刀刃比你的想象中的要快上那么一点, 老朋友."
        ],
    ]



func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "要杀便杀. 收起你那张胜利者嘴脸. 这次黑山羊没能踏碎你的肋骨, 纯粹是圣灵不愿让我的斗篷过早沾上异端的血.",
            "你们这些潜伏在阴影里的毒蛇, 终究会被我连根拔起!"
        ],
        [
            "哼...",
        ],
        [
            "你赢了这一局, [" + _player_name + "]"
        ],
        [
            "这可能就是我的结局吧...",
        ],

        [
            "既然败在你的剑下, 我无话可说.",
            "你的剑确实比以往更沉重, 更决绝了, 老朋友."
        ],
    ]



func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "即使身陷泥沼, [" + _target_country_name + "] 的利刃也绝不会向一个敌人低头!",
            "我的骨头和我的信仰一样硬, 别指望我会像那些软弱的贵族一样向你吐露王国的秘密."
        ],
        [
            "怎么? 你是打算把我一直囚禁我, 直到我身上的盔甲生锈吗?",
        ],
        [
            "如果你是为了那笔巨额的赎金, 就开个符合我领主身份的价码.",
        ],
        [
            "你的实力很强, 这无可否认."
        ],
        [
            "老朋友. 这地方可不是叙旧的好地方."
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "我的自由值 [#{0}] 德里. 拿上这笔巨款, 把我的黑山羊战马牵过来!",
        "王国的财务总管已经筹备了 [#{0}] 德里用于赎回王座的影子. 放行吧.",
    ]



func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "交易达成了, [" + _player_name + "]. 下一次交锋, 我的黑山羊之枪绝不会再偏离!",
        ],
        [
            "自由的代价很昂贵, 但我保证, 下一次我会带着突击队, 从你的领地上成倍地讨回来!"
        ],
        [
            "交易达成. [" + _player_name + "], 我们很快就会在下一张棋盘上重逢.",
        ],
        [
            "交易达成. [" + _player_name + "], 我们很快就会在下一张棋盘上重逢.",
        ],
        [
            "重获自由的感觉很好. 老朋友. 让我们在下一次战斗中见分晓吧."
        ]
    ]



func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 你到底在玩什么把戏?",
            "你想用这种手段来羞辱一个影子执行者吗?"
        ],
        [
            "[" + _player_name + "], 你到底在玩什么把戏?",
            "没有赎金, 没有条约, 就这样放我走? 你在这片荒原里埋下了什么我看不到的连环陷阱?"
        ],
        [
            "你真的要放走一个随时会带着骑兵杀回来, 将你的领地连根拔起的巨大隐患?",
        ],
        [
            "我无法理解这种战略决策. 你要满足你的骑士荣誉感吗?",
        ],
        [
            "你真是太不可理喻了, 我的挚友.",
        ]
    ]



func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "不要以为我会感激你的仁慈. 下次我的骑枪指着你的胸膛时, 我绝对会冷酷地忘记今天发生的一切!",
        ],
        [
            "今天的盲目放行, 只会让我在下一次清洗你时, 给你留一具全尸."
        ],
        [
            "既然你坚持...那自由我便收下了. 再会",
            "愚蠢的施舍...再会",

        ],
        [
            "既然你坚持这种毫无意义的仁慈, 那我也没必要客气. 不过记住, 我对陛下的誓言与立场, 绝不会因为你这点私人恩怨而被收买.",
            "人情收下了, 但黑夜的法典不容更改. 下一次相遇, 我们依旧是死敌."
        ],
        [
            "你赢了. 这份血债般的人情, 我记下了. 再会!",
            "保重了, 我的挚友.",
            "下一次, 我不希望我执行的斩首行动, 目标是你. 保重."
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 足够抵扣我的自由. 现在, 把锁链解开!"
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "真让人意外. 你竟然会带着兵冲进这片血海里来帮我.",
        "黑山羊之枪从不需要毫无根由的援助, 你的真正动机是什么?",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "黑山羊之枪校准了他们的胸膛, 而你封死了他们所有的退路.",
        "回去洗掉你身上的血腥味吧.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "黑山羊之刃今天饱饮了叛逆的鲜血!",
        "擦擦身上的脏血吧, 老搭档. 今天多亏了你精妙的兜底.",
        "你今天没有给他们留下任何一丝死灰复燃的机会, 这才是真正的仁慈.",
    ]