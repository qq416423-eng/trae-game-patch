extends LordNobleDialogue

const HERO_UID: = "lord_hero_0015"



func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:
        return[
            "你对王座的恶意, 高空中的神鹰看得一清二楚! 妄图加入 [" + _country_name + "]? 带着你的烂命赶紧滚!",
        ]
    elif _rel_value <= -10:
        return[
            "想要加入我们? 哼, 你的剑太慢, 心太脏."
        ]
    elif _rel_value <= 10:
        return[
            "如果你做好了替王国去冲锋陷阵流尽最后一滴血的觉悟, 就去面见 [" + _king_name + "] 吧.",
        ]
    elif _rel_value < 30:
        return[
            "你是个真正的猎手, 去面见 [" + _king_name + "] 吧, 只要你的忠诚如多尔达尔的铁箭般坚硬.",
        ]
    else:
        return[
            "你是这片土地上最锋利的鹰爪! 你的战意, 软肋和对王国的价值, 本公主已经了然于胸. 去见 [" + _king_name + "] 吧, 本公主会亲自向父汗为你作保!",
        ]


func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "你除了像只瞎了眼的鹌鹑一样在马蹄缝里乱窜之外, 根本没有放干任何一个敌人的血.",
        "本公主的红鹰马队为了绕开你差点错失战机, 滚出我的视线!",
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你刚才在战场上的走位混乱得像群被狼冲散的绵羊. 本公主的红翎卫甚至需要刻意勒紧马缰, 免得铁蹄直接踩碎你的脑袋.",
        "你刚才在战场上的表现, 连大帐外一根拴马的枯木桩子都算不上.",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "你今天在战场上是怎么回事? 你的长剑到底在迟疑什么?",
        "下一次围猎, 我绝不希望你再像个待宰的羔羊一样不知所措.",
        "今天你的刀可不够利啊."
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "虽然本鹰依旧警惕你, 也时刻防备着你的刀尖, 但不得不承认你刚才的狠辣手段, 确实像条多尔达尔的狼.",
        "哼, 我依旧看你不顺眼. 但你刚才的表现确实出乎意料.",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "一场痛快的围猎! 敌人的防线碎得十分彻底. 合作愉快.",
        "你的战刀饱饮了鲜血, 本鹰的血翎弓也收割了他们的战旗. 合作愉快.",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "哈哈, 痛快! 这场围杀简直无可挑剔!",
        "哈哈, 今天这片原野上所有的猎物都被我们击杀得干干净净!"
    ]


func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "放肆! 竟敢对乌仁图娅公主的鹰旗拔刀?",
        "盲目的狂徒! 这可是铁木尔可汗的长女的部队!",
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "今天我就要折断这只高傲神鹰的翅膀!",
        "来吧! 管你是哪来的傲慢公主."
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "误会! 我只是在仰慕乌仁图娅公主殿下的英姿, 我这就绕道!",
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        [
            "一条荒原流浪狗, 也敢对本公主的红翎马队露出犬齿?",
        ],
        [
            "无知的流寇!",
        ],
        [
            "你莫不是在原野上被烈日晒坏了脑子?",
            "如果你的脑袋被长夜的冻土冻傻了, 本公主建议你一头扎进河里清醒清醒!"
        ],
        [
            "你疯了吗?! 本公主好不容易觉得你是个有些本事的猎手, 你现在竟然对我的鹰旗亮剑?",
            "这种鲁莽的挑衅可一点都不高明! 还是说...你只是想用这种蠢办法, 来引起本公主的注意?"
        ],
        [
            "等等...你吃错药了吗?! 本公主最信任的伙伴, 居然打算用这种自杀一样的蠢办法, 来逼本公主对你出手?",
            "喂, 你是不是被阿尔坦那个坏胚洗脑了? 快把你的刀收回去, 听见没有!"
        ],
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "你这是在自寻死路! 挑起两国战争, 你国家的子民也不会原谅你!",
        ],
        [
            "你是疯了吗?! 挑起两大部族的血战对你有何好处?",
            "你这个被野心冲昏头脑的家伙! 敢对本公主亮兵器!"
        ],
        [
            "舍弃和平? 公然宣战? 这就是你身为领主的器量吗?"
        ],
        [
            "你头脑混乱了吗?! 居然要挑起战火.",
            "快把刀放下! 本公主准你重新组织一下语言, 我们之间可还没到需要靠放血来解决争端的地步!"
        ],
        [
            "本……本公主简直不敢相信! 你我曾一同并肩作战! 你现在竟然要在这和平时期与我兵戎相见?",
            "你疯了...你一定是疯了! 本公主才不信你会把刀口对准我! 如果是阿尔坦逼你的, 你大可跟本公主直说!",
        ]
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [
            "红翎卫! 把这群不知死活的荒原野狗彻底钉死在草场上!",
        ],
        [
            "全军压上去! 用马蹄踩碎这些流寇的骨头!",
        ],
        [
            "真遗憾, 你选了一条绝路.",
        ],
        [
            "哼, 本公主可绝不会手下留情!"
        ],
        [
            "这就是你的最终决定吗? 好, 本公主会亲自用血翎弓射穿你.",
            "既然你非要拔刀, 那本公主就亲自将你拿获, 再听你解释!"
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "受死吧, 挑起血战的叛逆者!",
            "契约既然按不住你的狼子野心, 那就用你全军的鲜血, 来洗刷对 [" + _target_country_name + "] 的公然亵渎!"
        ],
        [
            "为了 [" + _target_country_name + "] 的尊严, 本公主将在战场上将你彻底铲平!",
        ],
        [
            "很好, 既然你主动挑起战火, 那本公主就让你见识一下多尔达尔最锋利的鹰爪!",
        ],
        [
            "既然你要战, 那便不死不休!"
        ],
        [
            "好吧! 既然你的战刀已经向本公主的鹰旗挥下, 那本公主就以可汗长女的身份, 在马背上彻底将你击溃!"
        ]
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "[" + _player_name + "], 今天本公主要用黑铁箭镞射穿你的心脏, 把你的战旗丢进泥泞!",
            "红翎卫, 听本公主号令, 全面强攻! 将这群狂徒彻底撕碎!"
        ],
        [
            "红翎卫! 拉满你们的弓弦, 把前方的敌人钉死在草场上!",
        ],
        [
            "本公主要亲自收割你们!"
        ],
        [
            "[" + _player_name + "]! 别以为本公主会因为往日的交情就对你手下留情!",
            "哼! 既然两家羽旗相互敌对, 那么战斗也在所难免, 可别在第一轮箭雨里就落了马!"
        ],
        [
            "[" + _player_name + "]...别指望本公主会放水! 来吧!",
        ],
    ]


func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()

    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            [
                "你就是那个在原野上四处流窜的老鼠 [" + _player_name + "]? 既然擅自闯入本公主的猎场, 那就准备好在这里被践踏成泥吧!",
            ],
            [
                "你就是 [" + _player_name + "]? 拔刀, 受死!",
                "你就是 [" + _player_name + "]? 本公主今天刚好手痒, 就拿你身后的残兵败卒来练练手!"
            ],
            [
                "我乃铁木尔可汗之女乌仁图娅! 你就是通缉犯 [" + _player_name + "]? 拔剑吧, 让本公主看看你的实力.",
            ],
            [
                "本公主找你很久了! 虽然你在荒原上的事迹告诉我你还算个勇士, 但很遗憾, 你今天把战马调错了方向. 拔剑吧!",
            ],
            [
                "本公主找你很久了! 虽然你在荒原上的事迹告诉我你还算个勇士, 但很遗憾, 你今天把战马调错了方向. 拔剑吧!",
            ]
        ]
    else:
        return[
            [
                "[" + _player_name + "], 这一次, 我的血翎之剑会将你这个反复无常的臭鼬彻底撕碎!",
                "不知死活的流浪狗, 这一次, 我会亲手折断你的双腿, 把你关入地牢!"
            ],
            [
                "还敢出现在本公主面前? 今天本公主的黑铁箭镞绝不会再射偏一寸!",
                "又被本公主逮到了吧! 这一次你休想再像泥鳅一样溜走!",
            ],
            [
                "[" + _player_name + "], 今天你必须由本公主亲自解决!",
                "原野上的围猎开始了. 既然你给 [" + _target_country_name + "] 带来了战火, 那就别怪本公主的长弓无情!"
            ],
            [
                "站住, [" + _player_name + "]! 虽然本公主觉得你人还不错...但你的行为已经威胁到了父汗的草场. 拔剑吧, 不准后退!",
                "哼, 又是你这个让人头疼的笨蛋. 虽然本公主并不讨厌你, 但战争无私情, 用 [" + _target_country_name + "] 的规矩来做个了断吧!"
            ],
            [
                "又见面了...你这笨蛋为什么要逼本公主对你拉弓?",
                "[" + _player_name + "], 听好了! 本公主等会儿会亲自把你打落马鞍!"
            ]
        ]


func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        return[
            [
                "我乃铁木尔可汗之女乌仁图娅! [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 撞见了我, 那就做好被本公主一箭贯穿的觉悟吧!",
                "无耻的入侵者! 本公主现在就用漫天箭雨射穿你的傲慢!"
            ],
            [
                "对我而言, 任何来自 [" + _player_country_name + "] 的领主都是需要被彻底践踏的障碍. 现在, 本公主的红翎卫会割断你们的喉咙!",
            ],
            [
                "本公主倒要看看, [" + _player_country_name + "] 的封臣有什么通天的本事. 放马过来吧!",
            ],
            [
                "本公主倒要看看, [" + _player_country_name + "] 的封臣有什么通天的本事. 放马过来吧!",
            ],
            [
                "本公主倒要看看, [" + _player_country_name + "] 的封臣有什么通天的本事. 放马过来吧!",
            ]
        ]
    else:
        return[
            [
                "站住, [" + _player_name + "]. 这一次, 本公主的苍穹御鹰卫会用铁蹄将你和你的伪善家徽彻底踩进烂泥里!",
                "又被我截住了! 你这反复无常的狡诈之徒, 今天本公主要亲自射穿你的腿, 让你跪在父汗的大帐前认罪!"
            ],
            [
                "又见面了, [" + _player_name + "]. 准备好领教本公主红翎卫的毁灭攻势了吗?",
            ],
            [
                "又见面了, [" + _player_name + "]. 开战吧!",
            ],
            [
                "我的朋友, 在战火中重逢, 真是让人火大! 本公主今天只能在此用血翎神鹰之剑斩断咱们的交情了!",
            ],
            [
                "[" + _player_name + "]! 虽然本公主更希望在大帐前与你叙旧, 讨论那些世间奇闻...但此刻, 我必须以可汗长女的身份, 将你清扫出局!",
            ]
        ]


func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["你就是 [" + _player_name + "]? 拦截本公主，是急着送死吗?"],
            ["你就是那个在原野上四处作乱的 [" + _player_name + "]? 哼，看来你的鹰爪已经磨得足够锋利了."],
            ["你就是 [" + _player_name + "]? 本公主不得不承认, 你麾下这支马队的规模, 可绝不是一般流寇劫匪能比的."],
            ["你就是 [" + _player_name + "]? 本公主不得不承认, 你麾下这支马队的规模, 可绝不是一般流寇劫匪能比的."],
            ["你就是 [" + _player_name + "]? 本公主不得不承认, 你麾下这支马队的规模, 可绝不是一般流寇劫匪能比的."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["滚! 否则乱箭穿心！"],
                ["还有完没完?"],
                ["别以为你兵强马壮本公主就会害怕!"],
                ["还有什么事吗!"],
                ["还有什么事吗?"],
            ]
        else:
            return[
                ["又是你, [" + _player_name + "]. 你可真是个阴魂不散的家伙."],
                ["又是你, [" + _player_name + "]. 你可真是个阴魂不散的家伙."],
                ["又是你, [" + _player_name + "]. 看来你对你麾下的铁骑非常自信."],
                ["又见面了, [" + _player_name + "]. 你有什么事?"],
                ["又见面了，我的朋友...你现在看起来像一头危险野兽."]
            ]


func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["本公主倒要看看, 是哪个自寻死路的敌国将领!"],
            ["你就是 [" + _player_name + "]? 你是觉得自己那几层铁皮盾阵, 能抵挡得住本公主部队的漫天箭雨吗?"],
            ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "] 了. 拦截本公主, 是自认为有能力打败我?"],
            ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "] 了. 拦截本公主, 是自认为有能力打败我?"],
            ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "] 了. 拦截本公主, 是自认为有能力打败我?"],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                ["滚! 否则乱箭穿心！"],
                ["还有完没完?"],
                ["别以为你兵强马壮本公主就会害怕!"],
                ["还有什么事吗!"],
                ["还有什么事吗?"],
            ]
        else:

            return[
                ["又是你, [" + _player_name + "]. 本公主就知道, 只要碰见你的恶心家徽, 今天一整天都不会有好心情!"],
                ["又是你, [" + _player_name + "]. 本公主就知道, 只要碰见你的恶心家徽, 今天一整天都不会有好心情!"],
                ["哼, 咄咄逼人的家伙. 你以为带了几个重装方阵, 本公主就会退缩吗?"],
                ["又见到这面充斥着野心的战旗了. [" + _player_name + "], 公然拦截我的部队, 有何企图?"],
                ["我的挚友 [" + _player_name + "]...以这种兵临马下的姿态逼近本公主, 究竟意欲何为? 如果是要拉开全面血战, 本公主绝不会对你手软!"],
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            [
                "拉紧你的马缰! 与本公主保持十马之距!",
                "退后! 再敢毫无礼地靠近本公主的雕羽, 我就把你当成原野上的松鸡一箭射穿!"
            ],
            [
                "我乃乌仁图娅! 把你的舌头捋直了再跟我说话, 我的时间宝贵, 没空听你支支吾吾的废话!",
            ],
            [
                "离我的战马远点! 流浪的的孤狼, 说出你的来意!",
            ],
            [
                "我是乌仁图娅, 铁木尔可汗长女, 流浪的的孤狼, 说出你的来意!",
            ],
            [
                "我是乌仁图娅, 铁木尔可汗长女, 流浪的的孤狼, 说出你的来意!",
            ]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return[
                ["滚! 否则乱箭穿心！"],
                ["还有完没完?"],
                ["还有什么事吗!"],
                ["还有什么事吗!"],
                ["还有什么事吗?"],
            ]
        else:

            return[
                [
                    "又是你, [" + _player_name + "]. 别整天像只没头苍蝇一样乱晃. 要是敢动什么坏心思, 本公主的黑铁箭镞绝不留情!",
                ],
                [
                    "又是你, [" + _player_name + "]. 别怪本公主没警告过你, 我的血翎之剑随时渴望饱饮懦夫的鲜血.",
                ],
                [
                    "[" + _player_name + "], 突然勒马挡住本公主的去路, 有何企图?",
                ],
                [
                    "[" + _player_name + "], 居然又撞见你了.",
                    "真巧啊, [" + _player_name + "]."
                ],
                [
                    "大笨蛋 [" + _player_name + "]. 见到本公主, 还不知道赶紧下马行礼(偷笑)?",
                    "你这笨蛋, 既然找我有事, 那就快说. 本公主特意为你留了半边上好的烤鹿肉."
                ]
            ]


func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[

                [
                    "哼, 新晋同僚? 本公主可不不认为我们需要一个在军阵后方唯唯诺诺的胆小鬼!"
                ],
                [
                    "既然同在父汗的鹰旗之下, 那就收起那种拖沓的毛病."
                ],
                [
                    "我乃乌仁图娅. 只要你的兵马在行军时别干扰到我为 [" + _target_king_name + "] 清理边境死角, 本公主倒也懒得跟你计较. ",
                ],
                [
                    "我是乌仁图娅. 父汗的大帐里传颂过你最近的破阵战功, 欢迎你加入 [" + _player_country_name + "]!",
                ],
                [
                    "终于见到你了, [" + _player_name + "]! 你在前线带着铁骑破阵的蛮横手段, 本公主可是中意得很!",
                ]
            ]
        else:
            return[

                [
                    "你就是来自 [" + _player_country_name + "] 的新晋领主? 本公主劝你老实遵守这片原野的律条, 我的红翎重箭从不宽恕任何缺乏分寸的越界者!",
                ],
                [
                    "异国的领主, 约束好你的马队, 别试图来丈量本公主的草场界线!"
                ],
                [
                    "这面战旗...是来自 [" + _player_country_name + "] 的领主吗? 说吧, 异国的贵族, 有何贵干?"
                ],
                [
                    "这面战旗...是来自 [" + _player_country_name + "] 的领主吗? 说吧, 异国的贵族, 有何贵干?"
                ],
                [
                    "这面战旗...是来自 [" + _player_country_name + "] 的领主吗? 说吧, 异国的贵族, 有何贵干?"
                ]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:

            return[
                [
                    "滚开!"
                ],
                [
                    "别试探本公主的耐性!",
                    "你还没离开吗?",
                    "退后!"
                ],
                [
                    "还有什么事?",
                ],
                [
                    "你怎么总是离本公主这么近!"
                ],
                [
                    "你再跟着我的马队，本公主真的要生气了!",
                    "快去帮我打听前线的情况!"
                ],
            ]
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[

                    [
                        "又是你, [" + _player_name + "]. 请离我远点, 我不希望在战场上因为你的迟钝而带偏了我的部队!",
                    ],
                    [
                        "又是你, [" + _player_name + "]. 身为同僚, 与其在这原野上和本公主浪费口舌, 不如多带你的马队去劫掠两个敌对据点!",
                    ],
                    [
                        "[" + _player_name + "], 有什么最新前线消息, 要与本公主分享吗?",
                    ],
                    [
                        "[" + _player_name + "], 真巧, 居然又碰见你了.",
                    ],
                    [
                        "哼, 怎么又是你这个让人操心的家伙. 既然碰见了, 本公主就勉为其难地听听你今天又遇到了什么有趣的事情吧.",
                        "我的大笨蛋朋友, 见到你很高兴.",
                        "哈哈, [" + _player_name + "]! 我就知道能撞见你的旗帜."
                    ]
                ]
            else:
                return[

                    [
                        "又是你...请退后. 两家驻地虽然相安无事, 但本公主的血翎弓一触即发, 别做出引人误会的拔刀动作!",
                    ],
                    [
                        "又是你...[" + _player_name + "]. 请让开!"
                    ],
                    [
                        "又见面了, [" + _player_name + "]",
                    ],
                    [
                        "又见面了, [" + _player_name + "]. 希望你今天带来的是一些有价值的消息.",
                    ],
                    [
                        "又见面了, 我的老朋友. 先说好, 下次要是两家在战场上相见, 本公主的剑可绝不会手下留情!(坏笑)",
                    ]
                ]


func get_battle_chat_charge()-> String:
    return[
        "随本公主踏平他们! 冲锋!",
        "让他们见识见识本公主的厉害!",
        "一个不留, 碾过去!"
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "哼, 就这点能耐?",
        "傲慢的家伙, 这便是你的下场！",
        "哼, 真是不堪一击的对手."
    ]








    return _list.pick_random()


func get_battle_chat_injured()-> String:
    return[
        "好, 你成功激怒我了!",
        "唔...这入骨的痛楚",
        "这点小伤!",
        "可恶...竟然能伤到本公主?"
    ].pick_random()


func get_battle_chat_die()-> String:
    return[
        "父汗...女儿没有...",
        "带本公主的灵魂...回圣山吧...",
        "本公主...怎么可能...",
    ].pick_random()


func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "来得正是时候!",
        "援军已至! 重组军阵!"
    ].pick_random()


func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "长弓压制! 战马稳步前进!",
        "铁马齐步, 压过去!",
    ].pick_random()


func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "退后一步者, 军法处置!",
        "谁也不准退后半步!",
    ].pick_random()


func get_battle_chat_victory()-> String:
    return[
        "此战之血, 皆化为父汗的无上威名!",
        "全军听令，打扫猎场!",
    ].pick_random()


func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "今天在我的军阵前踢到铁板了, 乌仁图娅公主.(冷笑)",
            "平日里高高在上的公主大人, 现在怎么连人带马都落入我的围猎网里了?",
        ],
        [
            "高傲的草原神鹰, 今天翅膀似乎被折断了啊.",
            "认清你现在的处境吧.",
            "很遗憾, 公主殿下. 你那只顾着往前冲的烈马, 今天终究还是落进了我为你量身定做的圈套里.",
        ],
        [
            "别再做无谓的反抗, 公主大人."
        ],
        [
            "胜负已分, 乌仁图娅公主.",
        ],
        [
            "承让了, 公主殿下. 今天我的刀锋比你想象的要快上那么一点.",
        ],
    ]


func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "要杀便杀! 收起你那恶心的胜利者嘴脸! 若不是本公主的战马在乱石中绊了前蹄, 不然早就踩碎了你的肋骨!",
        ],
        [
            "放开本公主! 我父汗铁木尔可汗绝不会放过你!",
        ],
        [
            "原野的规矩就是弱肉强食, 本公主既然在马背上栽了, 自当无话可说.",
        ],
        [
            "真是气死我了!",
            "打赢了本公主让你觉得很得意吗, [" + _player_name + "]?"
        ],
        [
            "败在你的剑下, 本公主认了...你不准用这种得意的眼神看着我!",
            "哼, 可恶的 [" + _player_name + "], 这次算你厉害, 但你可别指望本公主会对你低头!"
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "本公主的骨气比圣山的黑铁还要硬! 别指望我会像那些懦夫一样向你低头!",
        ],
        [
            "快放我出去!"
        ],
        [
            "如果你是为了大笔的财富和骏马, 就快点开个符合我可汗长女身份的价码!",
        ],
        [
            "把本公主关在这儿很好玩吗?"
        ],
        [
            "快点放本公主出去!",
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "本公主的自由值 [#{0}] 德里!",
        "父汗已经筹备了 [#{0}] 德里用于赎回本公主, 放行吧!",
    ]


func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "[" + _player_name + "], 下一次在草场相见, 本公主的红翎重箭绝不会再射偏一寸!",
        ],
        [
            "自由的代价很昂贵, 但本公主保证, 下一次我会带着满员的苍穹御鹰卫, 成倍地从你身上上讨回来!"
        ],
        [
            "交易达成了, [" + _player_name + "]. 我们很快就会在下一场围猎中重逢.",
        ],
        [
            "哼, [" + _player_name + "]. 下一次本公主绝对要把你亲手打落马鞍, 洗刷今天的耻辱!",
        ],
        [
            "哼, 本公主可不会回头跟你挥手道别的, 我们下一个战场见分晓!"
        ]
    ]



func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 你到底在耍什么阴谋诡计?",
            "你想用这种施舍, 来羞辱可汗长女吗?"
        ],
        [
            "[" + _player_name + "], 你到底在玩什么把戏?"
        ],
        [
            "你真的要放走一个随时会带着成千上万红翎铁骑杀回来, 将你的营地夷为平地的巨大祸患吗?",
        ],
        [
            "本公主完全无法理解你的脑瓜里在想什么...",
        ],
        [
            "你真是个不可理喻的大笨蛋! 你这样白白放我回去, 本公主在父汗的金帐面前要怎么解释啊?"
        ]
    ]


func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "别以为本公主会感激你的仁慈! 下次我的剑架在你脖子上的时候, 我绝对会冷酷地忘记今天发生的一切!",
        ],
        [
            "今天的仁慈, 只会让本公主在下一次纵马踏碎你的营地时, 破例赏你一个堂堂正正的葬礼!"
        ],
        [
            "既然你坚持...那这份自由本公主就收下了! 哼, 后会有期!",
        ],
        [
            "既然你坚持...那本公主也没必要客气! 不过记住了, 我绝不会因为你这点私人恩情而被收买!",
            "人情我收下了, 但草原的律条不容更改. 下一次相遇, 我们依旧是刀兵相见的死敌."
        ],
        [
            "你赢了! 本公主记下了! 后会有期!",
            "保重了，我的笨蛋挚友...",
            "真拿你没办法...绝对不准死在别人手里, 听到没有!"
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 承载着圣山的荣耀, 足够抵扣本公主的自由了."
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "别以为你今天帮了本公主, 我们之间的账就一笔勾销了.",
        "就你? 来救本公主? 哈! 笑话! 本公主是大漠上的神鹰!",

    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "好吧...有你的协助, 胜利来得确实快了一点点.",
        "没有你, 胜利也是属于我的.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 不愧是本公主最看中的猎手! 合作愉快.",
        "本公主就知道, 只要有你在身旁, 任何军阵在我们眼里都只是待宰的羔羊.",
        "你的骑术还是差了本公主那么一点点, 哈哈哈.",
    ]