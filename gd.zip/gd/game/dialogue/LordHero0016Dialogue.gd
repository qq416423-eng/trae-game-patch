extends LordNobleDialogue

const HERO_UID: = "lord_hero_0016"




func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name = DialogueCustomUtils.get_b_country_name()
    var _king_name = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:
        return[
            "我在你身上只看得到平庸. [" + _country_name + "] 不收容垃圾.",
        ]
    elif _rel_value <= -10:
        return[
            "你表现出的价值太低, 不值得我浪费时间向国王开口.",
        ]
    elif _rel_value <= 10:
        return[
            "想成为 [" + _country_name + "] 的\"毒牙\"? 那就要做好流尽最后一滴血的觉悟. 如果你有这份觉悟, 就去面见 [" + _king_name + "] 吧.",
        ]
    elif _rel_value < 30:
        return[
            "你是个足够锋利的工具. 去面见 [" + _king_name + "] 吧, 我会告诉他我欣赏你这颗\"毒牙\".",
        ]
    else:
        return[
            "你是我见过最完美的利器, [" + _country_name + "] 的狩猎场需要你. 去见 [" + _king_name + "] 吧, 我会亲自为你作保.",
        ]



func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "除了碍手碍脚, 你没有带来任何杀戮. 像一粒尘土, 毫无价值.",
    ]



func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你就像一把生锈的刀, 即使握在手中也毫无用处.",
        "因为你的低效, 敌人的咽喉甚至有机会苟延残喘片刻.",
    ]



func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "你的的表现令人失望.",
    ]



func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "即使我讨厌你, 也不得不承认, 你刚才对敌人的打击, 精准得让我惊叹.",
    ]



func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "一场高效的清理. 合作愉快, 至少到目前为止.",
        "你这颗\"毒牙\"发挥了它的价值.",
    ]



func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "精准, 致命. 你的表现我很满意.",
        "你今天的表现非常完美. 即使是\"冥蝎战镰\"也因你的表现而黯然失色.",
    ]




func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "竟敢用武器指向\"冥蝎\"的旗帜? 你是疯了吗?",
    ]



func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "告诉法赫德, 今天我要把这只死蝎子踩扁在沙子里!",
        "哼, 不过是一群在沙漠里苟延残喘的臭虫. 来吧!",
    ]



func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "误...误会! 我这就绕道, 绝不碍事!",
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        [
            "就凭你也敢把生锈的铁片对准我? 你是急着想变成沙丘上的枯骨吗?",
        ],
        [
            "无知的流寇. 你连让我浪费毒液的资格都没有.",
        ],
        [
            "暴晒让你的脑子彻底干涸了吗? 如果你想用这种愚蠢的方式挑战我, 我建议你直接把脖子抹在我的镰刀上, 省得浪费彼此的时间.",
        ],
        [
            "我本来以为你是一把足够好用的利器, 现在看来, 你只是一只不听话的老鼠.",
        ],
        [
            "...把刀收回去. 我极少对人心存信任, 别逼我用\"冥蝎战镰\"把你也做成干尸.",
        ],
    ]



func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "公然宣战? 愚蠢的决策.",
        ],
        [
            "准备用两大国家的鲜血来祭祀你的野心? 那我就奉陪到底. 亮出你的兵器吧.",
        ],
        [
            "公然挑起战火? 这就是你身为一国贵族的器量与远见? 你挑选了一个最恐怖的对手.",
        ],
        [
            "你的战术计算出现严重失误了. 战火一旦燃起, 可不是那么容易熄灭的.",
        ],
        [
            "我没听错吧...我本以为你和那些满脑子荣耀的废物不一样...如果你真的选择开战, 那我只能像割麦穗一样, 把你的傲慢连根拔起了.",
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        [
            "战士们. 把这群不知死活的荒原臭虫清理干净.",
        ],
        [
            "战士们. 把这群不知死活的荒原臭虫清理干净.",
        ],
        [
            "哼, 你选了一条死路.",
        ],
        [
            "哼, 你选了一条死路."
        ],
        [
            "好. 我会亲自用\"冥蝎战镰\", 让你认清你人生的最后一次错误.",
        ]
    ]



func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "很好, 准备迎接你的终局吧!",
        ],
        [
            "我会像切肉一样, 在沙场上将你彻底抹杀!",
        ],
        [
            "很好. 既然你主动点燃了战火, 那就让你见识一下\"冥蝎战镰\"的可怕之处",
        ],
        [
            "哼, 你选了一条死路."
        ],
        [
            "好. 我会亲自用\"冥蝎战镰\", 让你认清你人生的最后一次错误.",
        ]
    ]



func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    return[
        [
            "[" + _player_name + "], 今天我会用战镰割断你的喉咙.",
        ],
        [
            "战士们. 把这群不知死活的荒原臭虫清理干净.",
        ],
        [
            "哼, 你选了一条死路.",
        ],
        [
            "哼. 既然两家战旗已经是不死不休的局面, 那就别废话了. 可别在我的第一轮冲锋中就落了马!"
        ],
        [
            "[" + _player_name + "]...别指望我会手下留情. 来吧, 让我看看你的骨头有多硬!",
        ],
    ]



func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            [
                "你就是那个在沙海里四处流窜的跳蚤 [" + _player_name + "]? 既然擅自闯入我的狩猎场, 那就做好变成这片土地的一部分的准备吧.",
            ],
            [
                "你就是 [" + _player_name + "]? 拔剑吧, 别浪费我的时间.",
            ],
            [
                "我是法赫德. 你就是悬赏令上的那个乌合之众的头领 [" + _player_name + "]? 拔剑吧, 别浪费我的时间.",
            ],
            [
                "我追踪你的动向很久了. 流言说你很强, 但很遗憾, 你的行军路线出了致命的差错. 拔剑吧.",
            ],
            [
                "我追踪你的动向很久了. 流言说你很强, 但很遗憾, 你的行军路线出了致命的差错. 拔剑吧.",
            ]
        ]
    else:
        return[
            [
                "[" + _player_name + "], 这一次, 我的部队会像切除腐肉一样把你彻底抹杀. 我已经厌倦了追逐你这只耗子.",
            ],
            [
                "还敢出现在我眼前? 今天我的\"冥蝎战镰\"绝不会再留下任何活口.",
            ],
            [
                "[" + _player_name + "], 今天由我亲自来终结你.",
                "围猎开始了. 猎物 [" + _player_name + "]"
            ],
            [
                "站住, [" + _player_name + "]. 虽然我觉得你是一把不错的利器...但你的存在已经损害了 [" + _target_country_name + "] 的利益. 拔剑吧, 别让我看扁你.",
            ],
            [
                "[" + _player_name + "], 听好了. 等会儿我会用最快的速度将你击倒, 这是我对你最后的仁慈."
            ]
        ]



func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        return[
            [
                "我是 [" + _target_country_name + "] 的法赫德. [" + _player_name + "], 既然你代表 [" + _player_country_name + "] 挡在我的行军线路上, 那就做好喉咙被斩断的觉悟吧.",
            ],
            [
                "对我而言, 任何来自 [" + _player_country_name + "] 的封臣都是待清理的障碍. 现在, 我的毒牙部队会切断你们的喉咙.",
            ],
            [
                "我倒要看看, [" + _player_country_name + "] 的领主除去虚伪的外表后, 骨头到底有多硬. 放马过来.",
            ],
            [
                "我倒要看看, [" + _player_country_name + "] 的领主除去虚伪的外表后, 骨头到底有多硬. 放马过来.",
            ],
            [
                "我倒要看看, [" + _player_country_name + "] 的领主除去虚伪的外表后, 骨头到底有多硬. 放马过来.",
            ]
        ]
    else:
        return[
            [
                "站住, [" + _player_name + "]. 这一次, 我的部队会像切除腐肉一样把你彻底抹杀. 我已经厌倦了追逐你这只耗子.",
            ],
            [
                "又见面了, [" + _player_name + "]. 准备好领教\"冥蝎\"最无情的毁灭攻势了吗?",
            ],
            [
                "又见面了, [" + _player_name + "]. 准备好领教\"冥蝎\"最无情的毁灭攻势了吗?",
            ],
            [
                "我的朋友. 拔剑吧, 别让我看扁你.",
            ],
            [
                "[" + _player_name + "], 听好了. 等会儿我会用最快的速度将你击倒, 这是我对你最后的仁慈."
            ]
        ]


func _get_frequent_meet_dialogue()-> Array:
    return[
        [
            "别在我的边缘试探.",
            "滚出我的视线!",
            "让开, 或者立刻死."
        ],
        ["让开."],
        ["别在这里晃悠."],
        ["还有什么事吗?"],
        ["还有什么事吗?"],
    ]



func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["你就是那个四处作乱的 [" + _player_name + "]? 拦截\"冥蝎\"的行军线路, 是算准了自己的死期吗?"],
            ["你就是那个四处作乱的 [" + _player_name + "]? 拦截\"冥蝎\"的行军线路, 是算准了自己的死期吗?"],
            ["你就是 [" + _player_name + "]? 我不得不承认, 你麾下这支马队的规模和战术纪律, 可绝不是一般流寇劫匪能比的."],
            ["你就是 [" + _player_name + "]? 我不得不承认, 你麾下这支马队的规模和战术纪律, 可绝不是一般流寇劫匪能比的."],
            ["你就是 [" + _player_name + "]? 我不得不承认, 你麾下这支马队的规模和战术纪律, 可绝不是一般流寇劫匪能比的."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return _get_frequent_meet_dialogue()
        else:
            return[
                [
                    "又是你, [" + _player_name + "]. 阴魂不散的, 有什么企图?",
                ],
                [
                    "又是你, [" + _player_name + "]. 你的阵型很紧凑, 但在我眼里, 到处都是可以切开的口子.",
                    "又是你, [" + _player_name + "]. 阴魂不散的, 有什么企图?",
                ],
                ["哼, 咄咄逼人的家伙. 想进行一场死斗吗?"],
                ["又见到了, [" + _player_name + "]. 公然拦截我的部队, 你究竟有何图谋?"],
                ["我的挚友 [" + _player_name + "]...以这种姿态逼近我, 是想亲手切断我们之间的交情吗?"],
            ]



func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            ["让我看看, 是哪个不知死活的敌国将领, 敢拦截我的行军路线?"],
            ["你就是 [" + _player_name + "]? 明目张胆的拦截我, 你觉得自己能抵挡得住我的部队的标枪突袭?"],
            ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "] 了. 公然拦截我, 说明你对自己的实力很有把握."],
            ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "] 了. 公然拦截我, 说明你对自己的实力很有把握."],
            ["看来你就是最近名声大噪的敌国领主 [" + _player_name + "] 了. 公然拦截我, 说明你对自己的实力很有把握."],
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return _get_frequent_meet_dialogue()
        else:
            return[
                [
                    "又是你, [" + _player_name + "]. 每次在战场上看到你那面虚伪的敌国家徽, 我都会觉得头在隐隐作痛.",
                    "又是你, [" + _player_name + "]. 阴魂不散的, 有什么企图?",
                ],
                [
                    "又是你, [" + _player_name + "]. 你的阵型很紧凑, 但在我眼里, 到处都是可以切开的口子.",
                    "又是你, [" + _player_name + "]. 阴魂不散的, 有什么企图?",
                ],
                ["哼, 咄咄逼人的家伙. 想进行一场死斗吗?"],
                ["又见到这面充斥着野心的战旗了. [" + _player_name + "], 公然拦截我的部队, 你究竟有何图谋?"],
                ["我的挚友 [" + _player_name + "]...以这种姿态逼近我, 是想亲手切断我们之间的交情吗?"],
            ]



func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    if _is_first_meet:
        return[
            [
                "陌生人, 勒紧你的缰绳, 与我保持安全间距.",
                "退后. 我的\"冥蝎战镰\"分不清路人和猎物, 再盲目靠近一步, 我就把你当成沙鼠切成两半."
            ],
            [
                "我是法赫德. 把你的来意简短地说出来, 我的精力和时间都很宝贵, 没空听无意义的废话.",
            ],
            [
                "流浪的孤狼, 说出你的意图.",
            ],
            [
                "我是法赫德, [" + _target_country_name + "] 的封臣. 流浪的孤狼, 说出你的来意.",
            ],
            [
                "我是法赫德, [" + _target_country_name + "] 的封臣. 流浪的孤狼, 说出你的来意.",
            ]
        ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return _get_frequent_meet_dialogue()
        else:
            return[
                [
                    "又是你, [" + _player_name + "]. 别整天像没有目标的飞蛾一样四处乱晃. 如果干扰了我的行军路线, 你会死得很快.",
                ],
                [
                    "又是你, [" + _player_name + "]. 我的战镰随时准备斩断下一个障碍, 希望那个障碍不是你.",
                ],
                [
                    "[" + _player_name + "], 突然挡在我的行军路线上, 有何企图?",
                ],
                [
                    "又见面了, [" + _player_name + "], 既然找我有事, 就快把有价值的情报说出来, 我可以为你破例留出几分钟的空闲.",
                ],
                [
                    "终于见到你了, [" + _player_name + "], 你是极少数能让我摘下兜帽, 收起镰刀的人."
                ]
            ]



func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_country_name: String = SoldierUtils.get_player_belong_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _is_first_meet:
        if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
            return[
                [
                    "哼, 你就是新晋的同僚? 希望你不会是只躲在军阵后面算计利益的胆小鬼."
                ],
                [
                    "哼, 你就是新晋的同僚? 希望你不会是只躲在军阵后面算计利益的胆小鬼."
                ],
                [
                    "我是法赫德. 只要你的部队在推进时别打乱我的战术布局, 我倒也懒得去花费精力去计算你的存在.",
                    "新晋的领主. 希望你在战场上的表现能像你的战报一样好看.",
                    "多了一位同僚, 意味着战术上多了一个变量. 是助力还是阻碍, 我会在接下来的战斗里冷静地评估."
                ],
                [
                    "我是法赫德. 只要你的部队在推进时别打乱我的战术布局, 我倒也懒得去花费精力去计算你的存在.",
                    "新晋的领主. 希望你在战场上的表现能像你的战报一样好看.",
                    "多了一位同僚, 意味着战术上多了一个变量. 是助力还是阻碍, 我会在接下来的战斗里冷静地评估."
                ],
                [
                    "我是法赫德. 只要你的部队在推进时别打乱我的战术布局, 我倒也懒得去花费精力去计算你的存在.",
                    "新晋的领主. 希望你在战场上的表现能像你的战报一样好看.",
                    "多了一位同僚, 意味着战术上多了一个变量. 是助力还是阻碍, 我会在接下来的战斗里冷静地评估."
                ],
            ]
        else:
            return[
                [
                    "你就是来自 [" + _player_country_name + "] 的新晋领主? 劝你老实遵守这片沙海的规则, 我的\"冥蝎战镰\"从不放过任何越界的偷猎者.",
                ],
                [
                    "异国的贵族, 约束好你的马队, 别试图来窥探我的防区边界."
                ],
                [
                    "这面徽记...是来自 [" + _player_country_name + "] 的领主吗? 说吧, 异国的统治者, 找我有什么利益交换?"
                ],
                [
                    "这面徽记...是来自 [" + _player_country_name + "] 的领主吗? 说吧, 异国的统治者, 找我有什么利益交换?"
                ],
                [
                    "这面徽记...是来自 [" + _player_country_name + "] 的领主吗? 说吧, 异国的统治者, 找我有什么利益交换?"
                ]
            ]
    else:
        if SoldierUtils.get_interval_counter_since_last_meet(GlobalTempData.b_team_dialogue_info.leader_uid) < 1.0:
            return _get_frequent_meet_dialogue()
        else:
            if SoldierUtils.is_same_with_player_country(GlobalTempData.b_team_dialogue_info.leader_uid):
                return[
                    [
                        "又是你, [" + _player_name + "]. 请保持间距, 我不希望在狩猎时因为你的迟钝而打乱了前锋的切入角度.",
                    ],
                    [
                        "又是你, [" + _player_name + "].",
                    ],
                    [
                        "你的战旗出现在这里, 意味着这片防区的死角已经被清空了?",
                        "又见面了, [" + _player_name + "]. 希望你今天带来的是一些能转化为实际利益的情报.",
                    ],
                    [
                        "既然碰到了, 就略过那些繁琐的客套, 直接共享一下两军的推进线吧.",
                        "是你啊, [" + _player_name + "]. 看到你那面务实的战旗总能让我紧绷的太阳穴稍微放松一下.",
                    ],
                    [
                        "终于见到你了, [" + _player_name + "], 你是极少数能让我摘下兜帽, 收起镰刀的人.",
                        "我的\"冥蝎战镰\"今天出奇地安静, 原来是因为你来了.",
                        "这无休止的战火真让人疲惫...但只要看到你的旗帜在不远处飘扬, 我就觉得倒也没那么无趣了."
                    ]
                ]
            else:
                return[
                    [
                        "又是你...[" + _player_name + "]. 让开!"
                    ],
                    [
                        "又是你...请保持距离. 两家目前虽然维持和平, 但别做出任何让我产生误判的动作!",
                    ],
                    [
                        "又见面了，[" + _player_name + "]",
                    ],
                    [
                        "又见面了, [" + _player_name + "]. 希望你今天带来的是一些能转化为实际利益的情报.",
                    ],
                    [
                        "又见面了, 我的老朋友. 有什么情报可以分享吗?",
                    ]
                ]



func get_battle_chat_charge()-> String:
    return[
        "全线切入!",
        "清除前方所有活口!",
        "撕裂他们!"
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你太弱了",
        "这就结束了?",
        "动作太慢",
    ]






    return _list.pick_random()


func get_battle_chat_injured()-> String:
    return[
        "唔...无伤大雅",
        "不碍事...",
        "能伤到我?"
    ].pick_random()


func get_battle_chat_die()-> String:
    return[
        "终于...",
        "这就是...终局",
    ].pick_random()


func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "重组军阵!"
    ].pick_random()


func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "保持步调!",
    ].pick_random()


func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "后退者, 当场清理!",
        "谁也不准挪动半步!",
    ].pick_random()


func get_battle_chat_victory()-> String:
    return[
        "全军听令, 迅速清点战利品!",
        "毫无悬念的胜利"
    ].pick_random()


func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "法赫德大人, 现在怎么连人带骆驼都落入我的围猎网里了?",
        ],
        [
            "今天在我的军阵前踢到铁板了, 法赫德大人(冷笑).",
            "别再做无谓的挣扎了, 法赫德.",
            "很遗憾, 法赫德阁下. 你终究还是落进了我为你量身定做的圈套里.",
        ],
        [
            "认清你现在的处境吧, 法赫德.",
        ],
        [
            "胜负已分, 法赫德大人.",
        ],
        [
            "承让了, 法赫德大人. 我的刀锋比你计算得还要快上那么一点.",
        ],
    ]


func get_captured_dialogue_after_battle_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_nickname()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "要杀便杀! 收起你那恶心的胜利者嘴脸!",
            "有种现在就杀了我, 否则等我脱困, 等待你的将是无尽的深渊!"
        ],
        [
            "真是耻辱!",
            "是我低估你了..."
        ],
        [
            "沙海的法则只有优胜劣汰, 我既然在战术上输了一招, 自然无话可说.",
        ],
        [
            "败在你的手里, 我认栽...",
            "我就知道, 碰上你准没好事..."
        ],
        [
            "哈...真是败得彻彻底底啊."
        ],
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()
    var _player_name: String = SoldierUtils.get_player_nickname()

    return[
        [
            "别指望我会像那些懦夫软骨头一样向你摇尾乞怜!",
        ],
        [
            "...",
            "看够了吗, [" + _player_name + "]?"
        ],
        [
            "开个符合我身份的价码, 我的家族会立刻支付!",
            "我的家族会为我支付合理的价码. 别指望能从我这撬出任何核心军情."
        ],
        [
            "...",
            "成王败寇, 我无话可说..."
        ],
        [
            "谈谈正事吧, 你想要多少德里才愿意把自由还给我?"
        ],
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "我的自由, 值 [#{0}] 德里.",
        "我的财政官已经筹备了 [#{0}] 德里用于赎回我的自由, 放行吧.",
    ]


func get_hero_released_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    var _target_country_name: String = DialogueCustomUtils.get_b_country_name()

    return[
        [
            "哼, [" + _player_name + "]. 下一次我绝对要把你的战线彻底撕碎, 来洗刷今天的耻辱!",
        ],
        [
            "自由的筹码确实昂贵, 但我向你保证, 下一次, 我会成倍地将今天的亏损从你身上剥下来!"
        ],
        [
            "[" + _player_name + "], 下一次相见, 我的\"冥蝎战镰\"绝不会再偏离一分一毫!",
        ],
        [
            "交易达成了, [" + _player_name + "]. 我们很快就会在下一场战斗中重逢.",
        ],
        [
            "交易达成了, [" + _player_name + "]. 我们下一个战场上见分晓!"
        ]
    ]


func get_direct_release_confirmation_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 你到底有什么阴谋?",
        ],
        [
            "[" + _player_name + "], 你到底在玩什么把戏?"
        ],
        [
            "你想用这种毫无逻辑的\"施舍\", 来羞辱一个冷酷的军人吗?",
        ],
        [
            "我完全理解不了你的脑瓜里在想什么...",
        ],
        [
            "你真是个不可理喻的蠢货! 你这样白白放弃大笔赎金放我回去, 我回去后在国王的会议上要怎么解释?"
        ]
    ]


func get_hero_released_freely_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "别以为我会感激你! 下次我的战镰架在你咽喉上的时候, 我会精准地抹杀!",
        ],
        [
            "今天的仁慈, 只会让我在下一次击败你后, 破例在废墟里赏你一个堂堂正正的葬礼!"
        ],
        [
            "既然你坚持...那这份自由我就收下了...不过记住了, 我绝不会因为你这点私人恩情而改变王国的战略计划!",
        ],
        [
            "既然你坚持...那这份自由我就收下了...后会有期.",
            "这份人情我便收下了, 下一次在阵线交汇, 你我依旧是刀兵相见的死敌."
        ],
        [
            "你赢了! 这份人情我记下了! 后会有期!",
            "保重...",
            "真拿你没办法...保重..."
        ]
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}], 其价值足够抵扣我的自由了."
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "你今日的助战, 完全是一场毫无意义的赌博. 你为什么要帮我?",
        "\"冥蝎战镰\"不需要协助, 尤其是来自你的.",
        "我不会因为你今天的一时热血, 就抹去清算名册上你的名字.",
        "我已经在这片永无止境的战争里感到足够疲惫了, 实在不想再花心思去猜你今天助战的真正意图. 离我的毒针远一点.",
    ]

func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "这些活口没有留着的价值, 就地处理掉吧, 动作快点, 我有些累了.",
        "你今天在前线制造的混乱很完美, 我很满意.",
    ]

func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "老搭档。今天多亏了你精妙的协助.",
        "让他们这些狂热的蠢货去为了所谓的荣誉流血吧.",
    ]