class_name LordNeutralDialogue extends LordDialogueBase


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "虽然你我之间有些过节, 但不得不承认, 你这次确实完成了你的分内之事.",
        "战场上只看结果. 你完成了你的任务, 这很好, 但也仅此而已了."
    ]


func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "配合得不错."
    ]


func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哈哈, 老搭档! 这次配合得真不赖."
    ]