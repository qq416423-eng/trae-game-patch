class_name LordNobleDialogue extends LordDialogueBase


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "我虽不赞同你的某些所作所为, 但今夜战场上, 你是个值得尊敬的战士."
    ]


func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "辛苦了. 这次战役能顺利取胜, 你的支援也是不可或缺的一环.",
        "感谢你的协助.",
    ]


func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "愿荣耀与你同在, 我的朋友.",
        "谢天谢地, 看到你平安无事地从战场中出来, 这比赢得胜利更让我高兴!",
        "能与你并肩作战是我的荣幸, 我的挚友."
    ]