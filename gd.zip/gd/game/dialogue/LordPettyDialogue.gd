class_name LordPettyDialogue extends LordDialogueBase


func _get_mult_meet_clist_rel_bad()-> Array:
    return[
        "呵, 又是你, 我还以为你已经死在哪条路上了.",
    ]


func _get_mult_meet_clist_rel_normal()-> Array:
    return[
        "哦, 是你啊..."
    ]


func _get_mult_meet_clist_rel_good()-> Array:
    return[
        "老朋友，又在这儿碰上了.",
    ]