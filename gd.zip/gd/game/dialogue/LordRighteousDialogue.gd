class_name LordRighteousDialogue extends LordDialogueBase


func _get_mult_meet_clist_rel_bad()-> Array:
    return[
        "你又来给我带来麻烦吗?",
    ]


func _get_mult_meet_clist_rel_normal()-> Array:
    return[
        "又见面了."
    ]


func _get_mult_meet_clist_rel_good()-> Array:
    return[
        "又见面了, 老友",
    ]