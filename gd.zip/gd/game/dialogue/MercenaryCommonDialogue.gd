class_name MercenaryCommonDialogue extends BaseDialogue

const HERO_UID: = ""

static var MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "您好大人, 我们这边有#{b_soldier_count}名\"#{b_leader_name}\" 愿为您效力, 只需要#{b_hire_money}德里, 您意下如何?",
                "您好大人, 若您需要人手, 我们这儿正好有#{b_soldier_count}名\"#{b_leader_name}\", 雇佣金为#{b_hire_money}德里."
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "您好夫人, 我们这边有#{b_soldier_count}名\"#{b_leader_name}\" 愿为您效力, 只需要#{b_hire_money}德里, 您意下如何?",
                "您好夫人, 若您需要人手, 我们这儿正好有#{b_soldier_count}名\"#{b_leader_name}\", 雇佣金为#{b_hire_money}德里."
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "雇佣",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "use_hire_money": true,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": [
                            "我考虑考虑(德里不足)"
                        ]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "use_hire_money": true,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,

                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": [
                            "成交, 别让我失望.",
                            "拿着(德里), 准备准备, 我们马上上路.",
                            "成交, 这钱不是白给的, 记住你们的职责.",
                        ],
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}

static var FINAL = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "大人, 我们准备好了, 随时可以出发.",
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "夫人, 我们准备好了, 随时可以出发.",
            ]
        }
    ],
}

func get_hero_uid()-> String:
    return HERO_UID

func get_current_dialogue_template()-> Dictionary:
    return MEET

func get_final_dialogue_template()-> Dictionary:
    return FINAL