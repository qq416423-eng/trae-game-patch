class_name MerchantConvoyDialogue extends BaseDialogue

const MERCHANT_CONVOY_DIALOGUE_0001: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "was_extorted_by_player"
            },
            "clist": [

                "上次那笔过路费, 已经让我们元气大伤了, 别再为难我们了吧...",
                "我们已经按你说的交过过路费了, 你还想怎样?",
                "上次给的过路费我们还没赚回来呢, 您又找上门来了...",
                "我们上次不是交过过路费了吗? 这次又是什么事?",
                "大人...我们已经交过您要求的过路费了..."
            ]
        },
        {

            "custom_choose_func": {
                "func_name": "has_met_player_before_and_player_infamous"
            },
            "clist": [
                "大人...又见到您了...(畏惧)",
                "大人, 又...又见面了...(畏惧)",
            ]
        },
        {

            "custom_choose_func": {
                "func_name": "has_met_player_before"
            },
            "clist": [
                "大人，我们又在路上相遇了. 愿您一路顺风.",
                "大人, 又见到您了!",
                "大人, 我们又见面了."
            ]
        },
        {

            "custom_choose_func": {
                "func_name": "is_same_country_as_player"
            },
            "clist": [
                "大人, 您好, 我们是来自 [#{b_origin_location_name}] 的商人, 能在路上见到您，是我们的荣幸. (来自本国的商队)",
                "大人, 见到您真安心, 我们是来自 [#{b_origin_location_name}] 的商人. (来自本国的商队)",
                "大人, 幸得您的照顾, 我们的商队才能顺利行商. (来自本国的商队)",
                "大人, 您好, 我们是来自 [#{b_origin_location_name}] 的商人, 有您的关照, 我们路上安心不少. (来自本国的商队)",
                "大人, 您好, 我们是来自 [#{b_origin_location_name}] 的商人, 承蒙您照顾, 我们得以平安走到这里. (来自本国的商队)"
            ]
        },
        {

            "custom_choose_func": {
                "func_name": "is_player_infamous"
            },
            "clist": [
                "大人, 我们是来自 [#{b_origin_location_name}] 的商人, 听闻过您的事迹...愿今日能平安通过. 我们无意冒犯.(畏惧)",
                "大人, 我们是来自 [#{b_origin_location_name}] 的商人, 见到您...心里多少有些紧张.(畏惧)",
                "大人, 我们是来自 [#{b_origin_location_name}] 的商人, 听说惹到您的人都没好下场...求您能放过我们通行.(畏惧)",
                "大人, 我们是来自 [#{b_origin_location_name}] 的商人, 您的大名在商人界人人皆知, 求您别对我们动手...(畏惧)",
                "大人, 我们是来自 [#{b_origin_location_name}] 的商人, 您的名声早已传遍四方, 我们这些做小本买卖的, 最怕的就是得罪您...还望高抬贵手.(畏惧)",
                "大人, 我们是来自 [#{b_origin_location_name}] 的商人, 听闻您手段雷厉, 我们可不想成为传闻中的下一个...求您放我们继续赶路吧.(畏惧)"
            ]
        },
        {
            "clist": [
                "大人, 您好, 我们是来自 [#{b_origin_location_name}] 的商人, 请问大人有何贵干?",
                "大人, 您好, 我们是来自 [#{b_origin_location_name}] 的商人, 祝您安康.",
            ]
        }
    ],
    "next": {
        "custom_func": {
            "func_name": "event_log_last_meet_time",
        },
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [

            {
                "custom_choose_func": {

                    "func_name": "has_not_been_extorted_by_player_and_not_same_country"
                },
                "str_from_func": [
                    {
                        "func_name": "compute_extort_amount"
                    }
                ],
                "otype": OPTION_TYPE_ENUM.EXTORT,
                "oname": "勒索(#{0}德里)",
                "content": [
                    {
                        "clist": [
                            "交笔过路费, 你们的名字就不会出现在任何事故名单上 - 懂我意思吧?",
                            "看你们的货物很值钱嘛, 分一点出来!",
                            "生意做大了, 就得承担些\"通行税\", 上交一部分给我, 大家都能活得更安稳, 我会衡量你的诚意."
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_b_origin_location_owner_or_king_nickname"
                                }
                            ],
                            "clist": [
                                "大人, 这举动会让您树敌, 不是明智之举. (勒索商队会降低对应地点和地点统治者的关系)",
                                "大人, 您没在开玩笑吧? (勒索商队会降低对应地点和地点统治者的关系)",
                                "我得提醒您一句: 您这是在挑拨我们的守护者 - [#{0}] 的权威. (勒索商队会降低对应地点和地点统治者的关系)",
                                "大人, 这会被视为对 [#{b_origin_location_name}] 商会的挑拨 - 您要想清楚后果. (勒索商队会降低对应地点和地点统治者的关系)",
                                "大人, 我们是由 [#{0}] 保护的合法商队, 您不会愿意和 [#{0}] 大人树敌吧? (勒索商队会降低对应地点和地点统治者的关系)"
                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.EXTORT,
                                "oname": "确定勒索",
                                "custom_func": {
                                    "func_name": "handle_player_extort_hostility_relation_change",
                                },
                                "content": [
                                    {
                                        "clist": [
                                            "我已经决定了，交钱, 不然留命.",
                                            "这是命令，不是商量, 不要考验我的耐心.",
                                            "我不再重复第二遍，把钱留下.",
                                        ]
                                    }
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {

                                            "custom_choose_func": {
                                                "func_name": "is_player_weaker_than_b_team"
                                            },
                                            "change_result_option_type": OPTION_TYPE_ENUM.BATTLE,
                                            "clist": [
                                                "那就看你有没有这个实力了. (商队拒绝勒索)",
                                                "那我们只能战斗了. (商队拒绝勒索)",
                                                "动手! 护卫, 保护货物! (商队拒绝勒索)",
                                                "护卫们! 亮出武器! (商队拒绝勒索)",
                                                "我们不会屈服! (商队拒绝勒索)",
                                                "我们宁死不屈! (商队拒绝勒索)",
                                                "休想从我们手里抢走一德里! (商队拒绝勒索)",
                                                "我们不是那么好欺负的! (商队拒绝勒索)",
                                                "你不该把手伸向 [#{b_origin_location_name}] 的商队. (商队拒绝勒索)"
                                            ]
                                        },
                                        {
                                            "str_from_func": [
                                                {
                                                    "func_name": "compute_extort_amount"
                                                }
                                            ],
                                            "custom_func": {
                                                "func_name": "player_receive_extort_amount",
                                            },

                                            "clist": [
                                                "好吧，我们只想平安离开. (交出#{0}德里)",
                                                "我们不想惹事，给你就是. (交出#{0}德里)",
                                                "这是你要的，请别再为难我们了. (交出#{0}德里)",
                                            ]
                                        }
                                    ]
                                }
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "oname": "取消",
                                "content": [
                                    {
                                        "clist": [
                                            "我改变主意了，你们走吧.",
                                            "算了，今天算你们走运.",
                                            "今天是吉日, 这次就放你们一马.",
                                            "哈哈，别紧张 - 我开玩笑的.",
                                            "放轻松, 我没真打算动手.",
                                            "哈哈, 我只是想看看你们反应, 别当真."
                                        ]
                                    }
                                ]
                            },
                        ]
                    }
                }
            },
            {

                "custom_choose_func": {
                    "func_name": "is_not_same_country_as_player"
                },
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "content": [
                    {

                        "custom_choose_func": {
                            "func_name": "was_extorted_by_player"
                        },
                        "clist": [
                            "我改变主意了. 货物和命, 都得留下.(坏笑)",
                            "过路费? 那只是前菜, 现在轮到正餐了.(坏笑)",
                        ]
                    },
                    {
                        "clist": [
                            "我打算像割草一样, 把你们都收拾掉!",
                            "士兵们, 听我的命令, 把这条路染成红色, 然后拿走货物.",
                            "士兵们! 别让一个人活着离开这里.",
                            "士兵们! 把所有人处理掉, 搜刮一切值钱的东西. 快!",
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_b_origin_location_owner_or_king_nickname"
                                }
                            ],
                            "clist": [
                                "这么做会触怒守护我们的领主 - [#{0}], 后果您要想清楚! (攻击商队会降低对应地点和地点统治者的关系)",
                                "您要知道, 我们受 [#{0}] 的保护，别以身犯险! (攻击商队会降低对应地点和地点统治者的关系)",
                                "大人! 这会被视作对 [#{0}] 的挑衅, 后果很严重! (攻击商队会降低对应地点和地点统治者的关系)",
                                "大人! 您真要树敌吗? 守护我们的领主可不会让这种事过去! (攻击商队会降低对应地点和地点统治者的关系)",
                                "求您手下留情, 惹怒守护我们的领主, 后果不堪设想. (攻击商队会降低对应地点和地点统治者的关系)"
                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.BATTLE,
                                "oname": "确定进攻",
                                "content": [
                                    {
                                        "custom_func": {
                                            "func_name": "handle_player_attack_caravan_hostility_relation_change",
                                        },
                                        "clist": [
                                            "上!",
                                            "我听够了，准备迎接死神吧.",
                                            "守护你们的领主? 他/她救不了你们!",
                                            "那就让你们亲眼见识, 我是怎么\"树敌\"的.",
                                            "够了, 我的耐心到此为止. 给我全灭."
                                        ]
                                    }
                                ]
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "oname": "取消",
                                "content": [
                                    {
                                        "clist": [
                                            "我改变主意了，你们走吧.",
                                            "算了，今天算你们走运.",
                                            "我暂且放你们一马，下次可没这么好运了.",
                                            "行了, 我不想再听哀嚎, 走远点."
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang"
                },
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "打劫",
                "content": [
                    {
                        "clist": [
                            "强寇办事, 把货物和钱都留下!",
                            "此路是我开, 此树是我栽, 想过? 拿钱来!",
                            "别废话, 货和钱, 都给我交出来!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "走好.",
                            "没事, 你们走吧."
                        ]
                    }
                ]
            }
        ]
    }
}


const AFTER_BATTLE_THANK_DIALOGUE_LOW: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "大人, 多谢您出手相助, 我们得以侥幸脱险，实在感激不尽.",
                "谢过大人, 今日能脱险也算是万幸.",
                "大人, 感谢您的援助...我们不敢多耽误您的时间.",
                "大人，有您的帮忙我们确实安心不少...后续我们会自行处理.",
                "多谢大人出手, 余下的路我们会更加小心..."
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}


const AFTER_BATTLE_THANK_DIALOGUE_HIGH: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "大人! 若非您在关键时刻救下我们..我们早已命丧黄泉!万分感谢!",
                "大人, 您是我们的救命恩人! 我们永远不会忘记今天的恩情.",
                "大人, 若没有您, 我们将会死于非命...由衷感谢您!",
                "大人, 您的出现宛如天神降临. 若非您出手相救, 我们此行已无生还的希望!",
                "大人, 我们全队上下都记得是您把我们从绝境中拉了回来. 这份恩情无以为报.",
                "大人, 我们能活着站在这里, 全靠您!",
                "大人, 幸好能遇见您...再晚一步, 我们连喊救命的力气都没了.",
                "大人...刚才那一刻我真以为今日是到头了. 是您把我们从死神手里拉回来了...",
                "我们欠您一份天大的情, 大人. 日后若有能回报的地方, 请尽管吩咐...",
                "大人...我们刚才真以为自己活不到天亮. 是您把我们从鬼门关拖了回来...",
                "大人, 您的援助如晨光破晓, 驱散了我们的生死危机. 此恩永铭!",
                "是您把我们从命运的审判中赎回, 大人."
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    if _relation_gain_after_battle_factor > 2:
        return AFTER_BATTLE_THANK_DIALOGUE_HIGH
    else:
        return AFTER_BATTLE_THANK_DIALOGUE_LOW

func get_battle_chat_charge()-> String:
    return[
        "护卫队! 保护货物, 把这些劫匪赶走!",
        "跟他们拼了!",
        "大家稳住!",
        "雇主付了钱, 咱们就得干活! 冲!",
        "拿好家伙! 速战速决!",
        "谁敢动这批货, 就先问问老子的剑!",
        "护卫队, 收缩阵型, 突击!",
        "别想从我手里拿走这批货物!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "呼~ 好险",
        "看啊, 这就是强盗的下场!",
        "我也不是好惹的!",
        "解决掉一个麻烦",
        "别怪我",
        "搞定一个麻烦",
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "嘶...",
        "该死!",
        "看来要葬送于此了...",
        "这趟买卖不划算啊...",
        "可恶的强盗...",
        "这趟差事...亏大了...",
        "搭把手啊!",
        "我受伤了!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "真是个...烂结局...",
        "帮我把工钱寄给...",
        "终究是...",
        "帮我...照顾好...隔壁街的...",
        "这就是...拿命换钱的...结局吗...",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "有人来救我们了! 撑住!",
        "有人来救我们了! 稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "结束了! 赶紧检查货物!",
        "没丢东西吧? 那咱们的赏金就稳了!",
        "老板, 记得在结算时多加点酒钱!",
        "收工收工! 到了城镇老子要睡个三天三夜!",
        "呐~ 这就叫专业",
        "护卫的活真难做啊...",
        "清理战场! 别耽误了赶路的行程!",
        "快检查货物! 如果里面的东西洒了, 咱们一分钱都拿不到!",
        "大家伙都没事吧?",
        "这就是专业护卫的效率! 老板, 结账时爽快点!",
        "利润总算保住了...",
        "呼~ 好险"
    ].pick_random()