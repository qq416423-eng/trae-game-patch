class_name MessageConstants


enum MESSAGE_TYPE_ENUM {
    SUCCESS,
    WARN,
    COMMON
}














const MESSAGE_ENUM = {

    SAVE_SUCCESS = {
        "content": "保存成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    REVOCATION_SUCCESS = {
        "content": "撤销成功",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    INSUFFICIENT_FUNDS = {
        "content": "您的德里不足",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    INSUFFICIENT_GOODS = {
        "content": "您的物品不足",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    GIFT_FAILED = {
        "content": "赠送失败",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    GIFT_EQUIPMENT_TO_LORD_SUCCESS = {
        "content": "赠送装备成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    GIFT_MONEY_SUCCESS = {
        "content": "赠送金钱成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    GIFT_EQUIPMENT_TO_VILLAGER_SUCCESS = {
        "content": "赠送装备成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    SOLDIER_UPGRADE_SUCCESS = {
        "content": "您已升级 {0} 个士兵, 共花费 {1} 德里",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    ACQUIRE_EXP = {
        "content": "部队获得 {0} 经验值",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    ACQUIRE_EXP_BATTLE_TRAIN = {
        "content": "战斗结束, 部队获得 {0} 经验值",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    ACQUIRE_EXP_DAILY_TRAIN = {
        "content": "部队每日训练获得 {0} 经验值",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    ACQUIRE_EXP_EXTRA_TRAIN = {
        "content": "部队训练结束, 获得 {0} 经验值",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    HERO_UPGRADE_SUCCESS = {
        "content": "{0} 已提升等级, 当前等级为 {1}",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    TEAM_SKILL_OPERATION_WORK = {
        "content": "团队手术技能等级: {0}, 挽救了 {2} 名士兵的生命",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    PRACTISE_UPGRADE_MESSAGE = {
        "content": "英雄: {0}\n{1}熟练度由 {2} 提升至 {3}",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    SKILL_UPGRADE_MESSAGE = {
        "content": "英雄: {0}\n{1}等级由 {2} 升级为 {3}",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    FOOD_DEPLETION_MESSAGE = {
        "content": "领主大人, 食物已耗尽, 请尽快补充食物!",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    SOLDIER_FLEE_MESSAGE = {
        "content": "士气太低, {0} 个 [{1}] 逃跑了!",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    CC_NAME_FORMATTING_NON_COMPLIANT = {
        "content": "请输入主角名字",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    SAVE_GAME_SUCCESS = {
        "content": "游戏保存成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    AUTO_SAVE_GAME_SUCCESS = {
        "content": "游戏自动保存成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    SHOP_NO_BALANCE = {
        "content": "商店已没有余额",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    PLUS_MONEY = {
        "content": "德里数 {0}",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },
    HERO_JOIN_TEAM = {
        "content": "英雄 [{0}] 加入队伍",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    DELETE_GOODS_FAILED_NEED_LOAD_GAME = {
        "content": "删除失败, 请先读取存档",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    DELETE_GOODS_SUCCESS = {
        "content": "删除成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    CAPTURE_MESSAGE = {
        "content": "扣押了 {0}",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    SURRENDER_MESSAGE = {
        "content": "招降了 {0}",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    NEW_SURRENDER = {
        "content": "领主大人, 有新的愿意招降的俘虏",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },

    SPLIT_GROUP_MESSAGE = {
        "content": "分堆成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    DISCHARGE_SOLDIER_SUCCESS = {
        "content": "{0} 个 {1} 已被解雇",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    DEPLOY_NEED_WITHIN_THE_RANGE = {
        "content": "请在虚线框范围内部署部队",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    TEAM_SORT_SAVE_SUCCESS = {
        "content": "士兵排序保存成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    DESTORY_BUILD_SUCCESS = {
        "content": "拆除设施成功, 回收了 {0} 德里",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    BUILD_UPGRADE_CONFIRM = {
        "content": "设施[{0}]升级中, 德里数 {1}",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    BUILD_FINISH = {
        "content": "[{0}][{1}]建造完成",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    BUILD_UPGRADE_FINISH = {
        "content": "[{0}][{1}]升级完成",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    BUILD_CANCEL_UPGRADE_SUCCESS = {
        "content": "已取消升级设施, 回收了 {0} 德里",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    SAVE_BARRACKS_TEAM_INFO_SUCCESS = {
        "content": "驻军信息保存成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    VILLAIN_BOSS_APPEAR = {
        "content": "有消息称 {0} 的队伍在罗德里大陆出现",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    OVER_GOODS_COUNT_LIMIT = {
        "content": "存放失败, 已超出仓库容量上限",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    HIRE_SUCCESS_MESSAGE = {
        "content": "{0} 加入了队伍",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    LOST_ONE_GOODS = {
        "content": "失去了一个物品 ({0})",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    ADD_ONE_GOODS = {
        "content": "获得了一个物品 ({0})",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    HERO_CANT_BE_RESPECED = {
        "content": "此英雄不支持洗点",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    NO_FORGOTTEN_WATER = {
        "content": "背包里没有遗忘之水",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    NEED_SELECT_HERO = {
        "content": "请先选择英雄",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    HERO_RESPECED_SUCCESS = {
        "content": "重置属性点成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    CLEAR_SUCCESS = {
        "content": "清除成功",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    RANDOM_ENEMY_TEAM_SUCCESS = {
        "content": "已随机敌人兵种配置",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    PLUS_REPUTATION_VALUE = {
        "content": "获得 {0} 点声望, 当前声望为 {1}",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    EXCEEDED_TROOP_LIMIT = {
        "content": "已超过部队人数上限",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    GARRISON_LIMIT_EXCEEDED = {
        "content": "驻军点人数已达到上限, 转移士兵失败",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    JOIN_KINGDOM = {
        "content": "您已正式加入 {0}, 成为其贵族阶层的一员",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    LEAVE_COUNTRY = {
        "content": "您已不再是 {0} 的贵族",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    GET_FIEF = {
        "content": "获封领地: {0}",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    RETURN_FIEF = {
        "content": "已归还所有领地",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    UNLOCK_UNIT_TREE = {
        "content": "已解锁兵种树: {0}",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    LOCK_UNIT_TREE = {
        "content": "兵种树被锁定: {0}",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    PAY_WAGES = {
        "content": "已支付军饷 {0} 德里, 剩余 {1} 德里{2}",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    SETTLEMENT_INCOME = {
        "content": "已结算税收: 德里数 +{0}",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    PLAYER_LOCATION_RELATION_VALUE_INCREASE = {
        "content": "与地点[{0}]关系 +{1} ({2} → {3})",

        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },

    PLAYER_LOCATION_RELATION_VALUE_DECREASE = {
        "content": "与地点[{0}]关系 {1} ({2} → {3})",

        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    PLAYER_NPC_RELATION_VALUE_INCREASE = {
        "content": "与[{0}]关系 +{1} ({2} → {3})",

        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },

    PLAYER_NPC_RELATION_VALUE_DECREASE = {
        "content": "与[{0}]关系 {1} ({2} → {3})",

        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    PLAYER_NPC_MORALITY_VALUE_INCREASE = {
        "content": "荣誉值 +{0} ({1} → {2})",

        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.COMMON,
    },

    PLAYER_NPC_MORALITY_VALUE_DECREASE = {
        "content": "荣誉值 {0} ({1} → {2})",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    PLAYER_BECOME_HOSTILE_TO_COUNTRY = {
        "content": "你已成为 [{0}] 的公敌",
        "color": MESSAGE_COLOR_ENUM.DANGER,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    LOW_MORALE_CANNOT_TRAIN = {
        "content": "士兵士气低下, 无法训练",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },

    CAPTURE_HERO = {
        "content": "[{0}] 已被我军俘虏",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },

    HERO_FLEE = {
        "content": "[{0}] 成功逃脱",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    CAPTURED_HERO_RELEASED = {
        "content": "[{0}] 已被释放",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    CAPTURED_HERO_FLEE = {
        "content": "俘虏 [{0}] 已逃跑",
        "color": MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    CAPTURED_SOLDIER_FLEE = {
        "content": "{0} 个俘虏(士兵)已逃跑",
        "color": MESSAGE_COLOR_ENUM.COMMON,
        "type": MESSAGE_TYPE_ENUM.WARN,
    },
    SAVE_DATA_IMPORT_SUCCESS = {
        "content": "存档导入成功: [{0}]",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    SAVE_DATA_EXPORT_SUCCESS = {
        "content": "存档导出成功: [{0}]",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
    RENAME_SAVE_NAME_SUCCESS = {
        "content": "已修改存档名为 [{0}]",
        "color": MESSAGE_COLOR_ENUM.SUCCESS,
        "type": MESSAGE_TYPE_ENUM.SUCCESS,
    },
}



const MESSAGE_COLOR_ENUM = {
    DANGER = CommonConstants.COLOR_ENUM.RED,
    SUCCESS = CommonConstants.COLOR_ENUM.GREEN,
    COMMON = CommonConstants.COLOR_ENUM.WHITE,
    IMPORTANT = CommonConstants.COLOR_ENUM.VIOLET,
}