extends BaseDialogue


const FOOD_PRICE: = 200

const ROUND_DRINKS_PRICE: = 1200

const NOP_REQUIRED: = 30

const HERO_UID: = "minor_hero_0001"

const NIECE_HERO_UID: = "wild_hero_0004"

static var FIRST_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "欢迎光临, 远道而来的客人! 想要吃点什么? 我们这里有上好的酒和美味的菜肴"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "闲聊",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "change_current_dialogue_flag": "COMMON",
                "content": [
                    {
                        "clist": [
                            "最近有听说过什么新鲜事吗？"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_func": {
                                "func_name": "spawn_mod_hero_0002_team_near_lantan_lake",
                            },
                            "clist": [
                                "新鲜事？要说新鲜事...前几晚我去蓝潭村送货，夜里回来路过湖边森林的时候，看到远处有火光闪动，还隐约听见打斗声。"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                        "content": [
                            {
                                "clist": [
                                    "我胆小没敢过去看，但第二天路过蓝潭湖边时，看到一个人影在林间徘徊，身旁还插着一面破旗。"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {
                                    "clist": [
                                        "看那样子像是个落魄的军官，你要是感兴趣，不妨去蓝潭湖附近看看。"
                                    ]
                                }
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.TALK,
                                        "oname": "帮我推荐",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "content": [
                                            {
                                                "clist": [
                                                    "好的，谢谢告知。对了，帮我推荐一些你们这里的特色美食"
                                                ]
                                            }
                                        ],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [
                                                {
                                                    "clist": [
                                                        "那一定要试试我们这的烤羊腿和特酿麦酒, 保准让您满意!"
                                                    ]
                                                }
                                            ],
                                            "next": {
                                                "step_type": STEP_TYPE_ENUM.OPTION,
                                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                                "option_list": [
                                                    {
                                                        "otype": OPTION_TYPE_ENUM.PAY,
                                                        "oname": "消费(花费" + str(FOOD_PRICE) + "德里)",
                                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                        "content": [
                                                            {
                                                                "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                                "condition_value": FOOD_PRICE,
                                                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                                "clist": [
                                                                    "下次吧(德里不足)",
                                                                ]
                                                            },
                                                            {
                                                                "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                                "condition_value": FOOD_PRICE,
                                                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                                "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                                "execute_value": - FOOD_PRICE,
                                                                "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                                "change_current_dialogue_flag": "HAS_ORDERED_ONCE",
                                                                "update_dialogue_save_info_system_counter": true,
                                                                "clist": [
                                                                    "很好, 就要这些"
                                                                ]
                                                            },
                                                        ],
                                                    },
                                                    {
                                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                        "oname": "离开",
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "下次吧"
                                                                ]
                                                            }
                                                        ],
                                                    }
                                                ]
                                            }
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "离开",
                                        "content": [
                                            {
                                                "clist": [
                                                    "下次吧"
                                                ]
                                            }
                                        ],
                                    }
                                ]
                            }
                        }
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "帮我推荐",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "帮我推荐一些你们这里的特色美食",
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "那一定要试试我们这的烤羊腿和特酿麦酒, 保准让您满意!"
                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.PAY,
                                "oname": "消费(花费" + str(FOOD_PRICE) + "德里)",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                        "condition_value": FOOD_PRICE,
                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                        "clist": [
                                            "下次吧(德里不足)",
                                        ]
                                    },
                                    {
                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                        "condition_value": FOOD_PRICE,
                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                        "execute_value": - FOOD_PRICE,
                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                        "change_current_dialogue_flag": "HAS_ORDERED_ONCE",
                                        "update_dialogue_save_info_system_counter": true,
                                        "clist": [
                                            "很好, 就要这些",
                                        ]
                                    },
                                ],
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "oname": "离开",
                                "content": [
                                    {
                                        "clist": [
                                            "下次吧"
                                        ]
                                    }
                                ],
                            }
                        ]
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "打听行情(花费100德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {"func_name": "tavern_check_price_tip_in_cooldown"},
                        "clist": ["最近刚打听过消息, 线人都需要时间活动, 过几天再来吧。"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["下次吧(德里不足)"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": -100,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["帮我打听一下各城的行情(支付100德里)"],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {
                                "func_name": "tavern_generate_price_tip"
                            },
                            "content": [
                                {
                                    "str_from_func": [
                                        {
                                            "func_name": "tavern_get_price_tip_text"
                                        }
                                    ],
                                    "clist": ["我打听到了一些消息... #{0}"],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.PAY,
                                                "oname": "打听哪里卖高价(花费150德里)",
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "custom_choose_func": {"func_name": "tavern_check_can_deep_inquire"},
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["下次吧(德里不足)"]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": -150,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["帮我打听哪里收购价高(支付150德里)"],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "custom_func": {"func_name": "tavern_generate_deep_price_tip"},
                                                            "content": [
                                                                {
                                                                    "str_from_func": [{"func_name": "tavern_get_deep_price_tip_text"}],
                                                                    "clist": ["打听好了... #{0}"]
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "知道了, 多谢",
                                                "content": [{"clist": ["消息很有用, 谢谢。"]}]
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "悬赏任务",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["听说你这里有悬赏任务?"]}],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_ready"},
                            "clist": ["你的悬赏完成了! 这是你的赏金500德里和3份食物。"],
                            "custom_func": {"func_name": "tavern_claim_bounty"}
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_in_cooldown"},
                            "clist": ["最近刚完成一单, 得让手下歇几天再说吧。"]
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_available"},
                            "clist": ["最近附近不太太平, 你如果能在周围活动三天, 我会给你500德里的报酬外加一些食物。"],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.TALK,
                                        "oname": "接受悬赏",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "custom_func": {"func_name": "tavern_accept_bounty"},
                                        "content": [{"clist": ["没问题, 交给我吧。"]}],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [{"clist": ["好, 那就拜托你了, 三天后回来找我。"]}]
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "下次再说",
                                        "content": [{"clist": ["我先考虑一下。"]}]
                                    }
                                ]
                            }
                        },
                        {
                            "clist": ["你的悬赏还在进行中, 三天后再来找我吧。"]
                        }
                    ]
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次吧"
                        ]
                    }
                ],
            }
        ]
    }
}


static var HAS_ORDERED_ONCE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "菜品是否合您口味?"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "赞美",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "非常棒",
                        ]
                    }
                ],
            }
        ]
    }
}

static var HAS_ORDERED_MULT = HAS_ORDERED_ONCE


static var SECOND_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "update_dialogue_save_info_system_counter": true,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "啊, 尊敬的大人, 又见到您了! 今天吃点什么?"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "啊, 尊贵的女士, 又见到您了! 今天吃点什么?"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "clist": [
                    "你们这气氛不错啊, 今天是有什么活动吗?"
                ]
            }
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "clist": [
                        "其实今天刚好新酿出了一批极好的啤酒, 您可得尝尝"
                    ]
                }
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.PAY,
                        "oname": "请客(花费" + str(ROUND_DRINKS_PRICE) + "德里)",
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                "condition_value": ROUND_DRINKS_PRICE,
                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                "clist": [
                                    "下次吧(德里不足)",
                                ]
                            },
                            {
                                "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                "condition_value": ROUND_DRINKS_PRICE,
                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                "execute_value": - ROUND_DRINKS_PRICE,
                                "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                "change_current_dialogue_flag": "HAS_ORDERED_MULT",
                                "plus_dialogue_save_info_num": {
                                    "level": 4,
                                },
                                "clist": [
                                    "太好了! 在座的各位听着(大声)! 今天的酒水由我请，大家敞开来喝!"
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {
                                            "clist": [
                                                "您真是慷慨无比!"
                                            ]
                                        }
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                        "content": [
                                            {
                                                "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
                                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                "clist": [
                                                    "各位听好了(大声)! 今天的酒水由这位大人买单! 大家可要敬他一杯! (掌声~)"
                                                ]
                                            },
                                            {
                                                "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
                                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                "clist": [
                                                    "各位听好了(大声)! 今天的酒水由这位女士买单! 大家可要敬她一杯! (掌声~)"
                                                ]
                                            }
                                        ],
                                    }
                                }
                            }
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.PAY,
                        "oname": "来一杯(花费" + str(FOOD_PRICE) + "德里)",
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                "condition_value": FOOD_PRICE,
                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                "clist": [
                                    "下次吧(德里不足)",
                                ]
                            },
                            {
                                "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                "condition_value": FOOD_PRICE,
                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                "execute_value": - FOOD_PRICE,
                                "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                "change_current_dialogue_flag": "HAS_ORDERED_MULT",
                                "plus_dialogue_save_info_num": {
                                    "level": 1,
                                },
                                "clist": [
                                    "很好! 给我来一杯, 外加一份炖牛肉, 一盘奶酪"
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {
                                            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
                                            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                            "clist": [
                                                "好的大人, 我这就去准备"
                                            ]
                                        },
                                        {
                                            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
                                            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                            "clist": [
                                                "好的女士, 我这就去准备"
                                            ]
                                        },
                                    ],
                                }
                            }
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.LEAVE,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "oname": "离开",
                        "content": [
                            {
                                "clist": [
                                    "下次吧"
                                ]
                            }
                        ],
                    },
                ]
            }
        }
    }
}


static var ALLOW_HIRE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "哇, 尊敬的大人, 您已经是这里的常客, 像您这样的大人物, 平常一定见多识广吧?"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "哇, 尊贵的女士, 您已经是这里的常客, 像您这样的大人物, 平常一定见多识广吧?"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "clist": [
                    "我经常走南闯北，每到一处好酒馆，总会留上几天"
                ]
            },
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "clist": [
                        "看来我们这小小酒馆能让您留步, 也算是个不小的成就了"
                    ]
                },
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "你们这生意出奇的好, 有什么秘诀吗?"
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哈哈哈, 谢谢大人夸奖, 这主要是靠我的侄女伊莎贝拉了, 她的经营头脑比我都好, 酒类菜品的研究也都依托她的帮助"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "clist": [
                                    "嗯, 其实我最近也有观察她的处事方式, 她做事情井井有条, 干脆利落, 确实是一个优秀的姑娘"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {
                                    "clist": [
                                        "您真是慧眼识珠, 但是其实她也想像您这样, 走出去闯荡, 见见世面, 留在这里可惜了她的才能, 如果有一个冒险队伍能收留她, 她一定会有一番作为"
                                    ]
                                },
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.HIRE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "尝试招聘",
                                        "content": [
                                            {
                                                "clist": [
                                                    "让她加入我的队伍如何?"
                                                ]
                                            }
                                        ],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [
                                                {

                                                    "condition": CONTENT_CONDITION_ENUM.NOP_NOT_ENOUGH,
                                                    "condition_value": NOP_REQUIRED,
                                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                    "clist": [
                                                        "您的队伍当然很出色, 但我实在有些不放心, 如果您的队伍里能多一些成员, 更加壮大一些(30人以上)，我一定会毫不犹豫地引荐她给您"
                                                    ]
                                                },
                                                {
                                                    "condition": CONTENT_CONDITION_ENUM.NOP_ENOUGH,
                                                    "condition_value": NOP_REQUIRED,
                                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,

                                                    "hire_hero_success": "wild_hero_0004",
                                                    "change_current_dialogue_flag": "NIECE_HIRED",
                                                    "change_current_dialogue_flag_config": [
                                                        {
                                                            "hero_uid": NIECE_HERO_UID,
                                                            "dialogue_flag": "HIRED"
                                                        }
                                                    ],
                                                    "update_dialogue_save_info_system_counter": true,

                                                    "clist": [
                                                        "您的队伍实力雄厚, 士兵们看起来也都训练有素, 能让她加入您的队伍, 是我们的荣幸"
                                                    ]
                                                },
                                            ],
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "离开",
                                        "content": [
                                            {
                                                "clist": [
                                                    "下次再说."
                                                ]
                                            }
                                        ],
                                    },
                                ]
                            }
                        }
                    }
                }
            }
        }
    }
}


static var COMMON = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "欢迎光临, 今天想吃点什么?"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "点餐(花费" + str(FOOD_PRICE) + "德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": FOOD_PRICE,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": [
                            "下次吧(德里不足)",
                        ]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": FOOD_PRICE,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": - FOOD_PRICE,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "change_current_dialogue_flag": "HAS_ORDERED_ONCE",
                        "update_dialogue_save_info_system_counter": true,
                        "clist": [
                            "来份烤羊腿和麦酒",
                            "腌肉, 奶酪, 干果, 再来一壶好酒",
                            "按你的推荐来吧",
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {
                                    "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "clist": [
                                        "好的大人, 我这就去准备"
                                    ]
                                },
                                {
                                    "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "clist": [
                                        "好的女士, 我这就去准备"
                                    ]
                                },
                            ],
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "打听行情(花费100德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {"func_name": "tavern_check_price_tip_in_cooldown"},
                        "clist": ["最近刚打听过消息, 线人都需要时间活动, 过几天再来吧。"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["下次吧(德里不足)"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": -100,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["帮我打听一下各城的行情(支付100德里)"],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {"func_name": "tavern_generate_price_tip"},
                            "content": [
                                {
                                    "str_from_func": [{"func_name": "tavern_get_price_tip_text"}],
                                    "clist": ["我打听到了一些消息... #{0}"],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.PAY,
                                                "oname": "打听哪里卖高价(花费150德里)",
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "custom_choose_func": {"func_name": "tavern_check_can_deep_inquire"},
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["下次吧(德里不足)"]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": -150,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["帮我打听哪里收购价高(支付150德里)"],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "custom_func": {"func_name": "tavern_generate_deep_price_tip"},
                                                            "content": [
                                                                {
                                                                    "str_from_func": [{"func_name": "tavern_get_deep_price_tip_text"}],
                                                                    "clist": ["打听好了... #{0}"]
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "知道了, 多谢",
                                                "content": [{"clist": ["消息很有用, 谢谢。"]}]
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "悬赏任务",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["听说你这里有悬赏任务?"]}],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_ready"},
                            "clist": ["你的悬赏完成了! 这是你的赏金500德里和3份食物。"],
                            "custom_func": {"func_name": "tavern_claim_bounty"}
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_in_cooldown"},
                            "clist": ["最近刚完成一单, 得让手下歇几天再说吧。"]
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_available"},
                            "clist": ["最近附近不太太平, 你如果能在周围活动三天, 我会给你500德里的报酬外加一些食物。"],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.TALK,
                                        "oname": "接受悬赏",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "custom_func": {"func_name": "tavern_accept_bounty"},
                                        "content": [{"clist": ["没问题, 交给我吧。"]}],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [{"clist": ["好, 那就拜托你了, 三天后回来找我。"]}]
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "下次再说",
                                        "content": [{"clist": ["我先考虑一下。"]}]
                                    }
                                ]
                            }
                        },
                        {
                            "clist": ["你的悬赏还在进行中, 三天后再来找我吧。"]
                        }
                    ]
                }
            },
            LEAVE,
        ]
    }
}


static var COMMON_WITH_GOSSIP = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "欢迎光临"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "闲聊",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "最近有听说过什么新鲜事吗？"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_func": {
                                "func_name": "spawn_mod_hero_0002_team_near_lantan_lake",
                            },
                            "clist": [
                                "新鲜事？要说新鲜事...前几晚我去蓝潭村送货，夜里回来路过湖边森林的时候，看到远处有火光闪动，还隐约听见打斗声。"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                        "content": [
                            {
                                "clist": [
                                    "我胆小没敢过去看，但第二天路过蓝潭湖边时，看到一个人影在林间徘徊，身旁还插着一面破旗。"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {
                                    "clist": [
                                        "看那样子像是个落魄的军官，你要是感兴趣，不妨去蓝潭湖附近看看。"
                                    ]
                                }
                            ],
                        }
                    },
                    "change_current_dialogue_flag": "COMMON",
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "打听行情(花费100德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {"func_name": "tavern_check_price_tip_in_cooldown"},
                        "clist": ["最近刚打听过消息, 线人都需要时间活动, 过几天再来吧。"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["下次吧(德里不足)"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": -100,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["帮我打听一下各城的行情(支付100德里)"],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {"func_name": "tavern_generate_price_tip"},
                            "content": [
                                {
                                    "str_from_func": [{"func_name": "tavern_get_price_tip_text"}],
                                    "clist": ["我打听到了一些消息... #{0}"],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.PAY,
                                                "oname": "打听哪里卖高价(花费150德里)",
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "custom_choose_func": {"func_name": "tavern_check_can_deep_inquire"},
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["下次吧(德里不足)"]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": -150,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["帮我打听哪里收购价高(支付150德里)"],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "custom_func": {"func_name": "tavern_generate_deep_price_tip"},
                                                            "content": [
                                                                {
                                                                    "str_from_func": [{"func_name": "tavern_get_deep_price_tip_text"}],
                                                                    "clist": ["打听好了... #{0}"]
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "知道了, 多谢",
                                                "content": [{"clist": ["消息很有用, 谢谢。"]}]
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "悬赏任务",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["听说你这里有悬赏任务?"]}],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_ready"},
                            "clist": ["你的悬赏完成了! 这是你的赏金500德里和3份食物。"],
                            "custom_func": {"func_name": "tavern_claim_bounty"}
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_in_cooldown"},
                            "clist": ["最近刚完成一单, 得让手下歇几天再说吧。"]
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_available"},
                            "clist": ["最近附近不太太平, 你如果能在周围活动三天, 我会给你500德里的报酬外加一些食物。"],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.TALK,
                                        "oname": "接受悬赏",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "custom_func": {"func_name": "tavern_accept_bounty"},
                                        "content": [{"clist": ["没问题, 交给我吧。"]}],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [{"clist": ["好, 那就拜托你了, 三天后回来找我。"]}]
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "下次再说",
                                        "content": [{"clist": ["我先考虑一下。"]}]
                                    }
                                ]
                            }
                        },
                        {
                            "clist": ["你的悬赏还在进行中, 三天后再来找我吧。"]
                        }
                    ]
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次吧"
                        ]
                    }
                ],
            }
        ]
    }
}

static var LEAVE = {
    "otype": OPTION_TYPE_ENUM.LEAVE,
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "oname": "离开",
    "content": [
        {
            "clist": [
                "下次吧"
            ]
        }
    ],
}


static var ORDERING_DIALOGUE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "欢迎光临, 今天吃点什么?"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "点餐(花费" + str(FOOD_PRICE) + "德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": FOOD_PRICE,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": [
                            "下次吧(德里不足)",
                        ]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": FOOD_PRICE,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": - FOOD_PRICE,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "change_current_dialogue_flag": "HAS_ORDERED_MULT",
                        "plus_dialogue_save_info_num": {
                            "level": 1,
                        },
                        "update_dialogue_save_info_system_counter": true,
                        "clist": [
                            "来5份野猪肉配香料面包，再加一壶蜂蜜酒",
                            "我饿坏了, 给我上你们这最贵的套餐吧",
                            "腌肉, 奶酪, 干果, 再来一壶好酒",
                            "炖牛肉, 烤羊腿, 麦酒, 就这些",
                            "按你的推荐来吧, 和以前不一样的"
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {
                                    "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "clist": [
                                        "好的大人, 我这就去准备"
                                    ]
                                },
                                {
                                    "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "clist": [
                                        "好的女士, 我这就去准备"
                                    ]
                                },
                            ],
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "打听行情(花费100德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {"func_name": "tavern_check_price_tip_in_cooldown"},
                        "clist": ["最近刚打听过消息, 线人都需要时间活动, 过几天再来吧。"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["下次吧(德里不足)"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": -100,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["帮我打听一下各城的行情(支付100德里)"],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {"func_name": "tavern_generate_price_tip"},
                            "content": [
                                {
                                    "str_from_func": [{"func_name": "tavern_get_price_tip_text"}],
                                    "clist": ["我打听到了一些消息... #{0}"],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.PAY,
                                                "oname": "打听哪里卖高价(花费150德里)",
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "custom_choose_func": {"func_name": "tavern_check_can_deep_inquire"},
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["下次吧(德里不足)"]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": -150,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["帮我打听哪里收购价高(支付150德里)"],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "custom_func": {"func_name": "tavern_generate_deep_price_tip"},
                                                            "content": [
                                                                {
                                                                    "str_from_func": [{"func_name": "tavern_get_deep_price_tip_text"}],
                                                                    "clist": ["打听好了... #{0}"]
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "知道了, 多谢",
                                                "content": [{"clist": ["消息很有用, 谢谢。"]}]
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "悬赏任务",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["听说你这里有悬赏任务?"]}],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_ready"},
                            "clist": ["你的悬赏完成了! 这是你的赏金500德里和3份食物。"],
                            "custom_func": {"func_name": "tavern_claim_bounty"}
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_in_cooldown"},
                            "clist": ["最近刚完成一单, 得让手下歇几天再说吧。"]
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_available"},
                            "clist": ["最近附近不太太平, 你如果能在周围活动三天, 我会给你500德里的报酬外加一些食物。"],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.TALK,
                                        "oname": "接受悬赏",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "custom_func": {"func_name": "tavern_accept_bounty"},
                                        "content": [{"clist": ["没问题, 交给我吧。"]}],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [{"clist": ["好, 那就拜托你了, 三天后回来找我。"]}]
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "下次再说",
                                        "content": [{"clist": ["我先考虑一下。"]}]
                                    }
                                ]
                            }
                        },
                        {
                            "clist": ["你的悬赏还在进行中, 三天后再来找我吧。"]
                        }
                    ]
                }
            },
            LEAVE,
        ]
    }
}


static var NIECE_HIRED = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "保重(微笑), 请帮我照顾好她"
            ],
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.PAY,
                "oname": "打听行情(花费100德里)",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {"func_name": "tavern_check_price_tip_in_cooldown"},
                        "clist": ["最近刚打听过消息, 线人都需要时间活动, 过几天再来吧。"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["下次吧(德里不足)"]
                    },
                    {
                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                        "condition_value": 100,
                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                        "execute_value": -100,
                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                        "clist": ["帮我打听一下各城的行情(支付100德里)"],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "custom_func": {"func_name": "tavern_generate_price_tip"},
                            "content": [
                                {
                                    "str_from_func": [{"func_name": "tavern_get_price_tip_text"}],
                                    "clist": ["我打听到了一些消息... #{0}"],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.PAY,
                                                "oname": "打听哪里卖高价(花费150德里)",
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "custom_choose_func": {"func_name": "tavern_check_can_deep_inquire"},
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["下次吧(德里不足)"]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": 150,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": -150,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": ["帮我打听哪里收购价高(支付150德里)"],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "custom_func": {"func_name": "tavern_generate_deep_price_tip"},
                                                            "content": [
                                                                {
                                                                    "str_from_func": [{"func_name": "tavern_get_deep_price_tip_text"}],
                                                                    "clist": ["打听好了... #{0}"]
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "知道了, 多谢",
                                                "content": [{"clist": ["消息很有用, 谢谢。"]}]
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "悬赏任务",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["听说你这里有悬赏任务?"]}],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_ready"},
                            "clist": ["你的悬赏完成了! 这是你的赏金500德里和3份食物。"],
                            "custom_func": {"func_name": "tavern_claim_bounty"}
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_in_cooldown"},
                            "clist": ["最近刚完成一单, 得让手下歇几天再说吧。"]
                        },
                        {
                            "custom_choose_func": {"func_name": "tavern_check_bounty_available"},
                            "clist": ["最近附近不太太平, 你如果能在周围活动三天, 我会给你500德里的报酬外加一些食物。"],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.OPTION,
                                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                "option_list": [
                                    {
                                        "otype": OPTION_TYPE_ENUM.TALK,
                                        "oname": "接受悬赏",
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "custom_func": {"func_name": "tavern_accept_bounty"},
                                        "content": [{"clist": ["没问题, 交给我吧。"]}],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [{"clist": ["好, 那就拜托你了, 三天后回来找我。"]}]
                                        }
                                    },
                                    {
                                        "otype": OPTION_TYPE_ENUM.LEAVE,
                                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                                        "oname": "下次再说",
                                        "content": [{"clist": ["我先考虑一下。"]}]
                                    }
                                ]
                            }
                        },
                        {
                            "clist": ["你的悬赏还在进行中, 三天后再来找我吧。"]
                        }
                    ]
                }
            },
            LEAVE,
        ]
    }
}


func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)


    var _show_gossip: bool = _should_show_gossip()



    var _player_team = WSData.get_player_team_node().json.team
    for _member in _player_team:
        if _member is Dictionary and _member.get("uid", "") == NIECE_HERO_UID:

            return _get_niece_hired_template(_show_gossip)

    if not _hero_json.has("current_dialogue_flag"):
        return FIRST_MEET

    if _hero_json.current_dialogue_flag == "COMMON":
        if _show_gossip:
            return COMMON_WITH_GOSSIP
        return COMMON

    if _hero_json.current_dialogue_flag == "NIECE_HIRED":


        return _get_niece_hired_template(_show_gossip)

    var _current_dialogue_flag = _hero_json.current_dialogue_flag
    if _current_dialogue_flag == "HAS_ORDERED_ONCE":
        if _get_days_since_last_dialogue(_hero_json) >= 1:
            DialogueUtils.change_current_dialogue_flag(HERO_UID, "SECOND_MEET")
            DialogueUtils.save_dialogue_save_info(
                HERO_UID,
                {
                    "system_counter": WSData.system_counter,
                    "level": 0,
                }
            )
            return SECOND_MEET

    if _current_dialogue_flag == "SECOND_MEET":
        if _get_days_since_last_dialogue(_hero_json) >= 1:
            _current_dialogue_flag = "HAS_ORDERED_MULT"
        else:
            return SECOND_MEET

    if _current_dialogue_flag == "HAS_ORDERED_MULT":
        if _get_days_since_last_dialogue(_hero_json) >= 1:
            if _hero_json.dialogue_save_info.level >= 4:
                return ALLOW_HIRE
            else:
                return ORDERING_DIALOGUE

    return get(_hero_json.current_dialogue_flag)




func _get_niece_hired_template(_show_gossip: bool)-> Dictionary:
    if not _show_gossip:
        return NIECE_HIRED

    var _template: Dictionary = NIECE_HIRED.duplicate(true)
    _template.next.option_list.push_front(_build_gossip_option())
    return _template




func _build_gossip_option()-> Dictionary:
    return {
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "闲聊",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "clist": [
                    "最近有听说过什么新鲜事吗？"
                ]
            }
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "custom_func": {
                        "func_name": "spawn_mod_hero_0002_team_near_lantan_lake",
                    },
                    "clist": [
                        "新鲜事？要说新鲜事...前几晚我去蓝潭村送货，夜里回来路过湖边森林的时候，看到远处有火光闪动，还隐约听见打斗声。"
                    ]
                },
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": [
                            "我胆小没敢过去看，但第二天路过蓝潭湖边时，看到一个人影在林间徘徊，身旁还插着一面破旗。"
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "看那样子像是个落魄的军官，你要是感兴趣，不妨去蓝潭湖附近看看。"
                            ]
                        }
                    ],
                }
            },
            "change_current_dialogue_flag": "NIECE_HIRED",
        }
    }


func _get_days_since_last_dialogue(_hero_json: Dictionary)-> float:
    if not _hero_json.has("dialogue_save_info"):
        return 999.0
    if not _hero_json.dialogue_save_info.has("system_counter"):
        return 999.0
    return int(WSData.system_counter) - int(_hero_json.dialogue_save_info.system_counter)


func _should_show_gossip()-> bool:



    if not GlobalSoldierInfo.hero_dic.has("mod_hero_0002"):
        return true

    var _mod_hero = GlobalSoldierInfo.hero_dic["mod_hero_0002"]
    if _mod_hero.has("belong_team_code") and StringUtils.is_not_empty(_mod_hero.belong_team_code):

        if WSData.get_team_node(_mod_hero.belong_team_code) != null:
            return false

    return true


func get_hero_uid()-> String:
    return HERO_UID