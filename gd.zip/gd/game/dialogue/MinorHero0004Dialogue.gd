extends BaseDialogue

const HERO_UID: = "minor_hero_0004"
const SELL_HERO_PRICE: = 4000
const SELL_HERO_UID: = "wild_hero_0006"

const INQUIRE_ARJES_COST = 1000

const HERO_ARJES_CODE = "minor_hero_0010"


static var ALLOW_INQUIRE_ARJES_DIALOGUE = {
    "otype": OPTION_TYPE_ENUM.TALK,
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "oname": "打听[阿尔杰斯]的下落",
    "content": [
        {
            "clist": [
                "可以告诉我[阿尔杰斯]在哪儿活动吗?",
                "可以告诉我[阿尔杰斯]在哪吗? 我找他做点买卖."
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [
            {

                "custom_choose_func": {
                    "func_name": "is_same_location",
                    "params": [HERO_UID, HERO_ARJES_CODE]
                },
                "clist": [
                    "眼神放亮些(无奈), 他就在酒馆里.",

                    "啧...他不就在那儿?(指向酒馆角落).",
                    "朝那边看(眼神跳向酒馆角落), 真是笨的可以.",
                    "你是在耍我还是想多花点打听费? 他就在那儿, 没看见吗?",
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [
                        {
                            "clist": [
                                "好的好的(尴尬)",
                                "抱歉...",

                            ]
                        }
                    ]
                }
            },
            {

                "custom_choose_func": {
                    "func_name": "has_asked_arjes_location"
                },
                "str_from_func": [
                    {
                        "func_name": "get_arjes_location_name"
                    }
                ],
                "clist": [
                    "这么快就忘了吗? 行吧, 再告诉你一次, 阿尔杰斯在 [#{0}]!",
                    "阿尔杰斯在 [#{0}], 不要再忘记了.",
                    "阿尔杰斯在 [#{0}], 再问我可要多收一次钱了.",
                ],
            },
            {
                "clist": [
                    "当然, 我足够信任你, 但是你得给点辛苦费, 我收集信息可是很花功夫的啊哈哈哈!(需要支付1000德里)",
                    "1000德里...的打听费(搓手)",
                    "这个消息可值1000德里(坏笑)"
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.OPTION,
                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                    "option_list": [
                        {
                            "otype": OPTION_TYPE_ENUM.PAY,
                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                            "oname": "支付" + str(INQUIRE_ARJES_COST) + "德里)",
                            "content": [
                                {
                                    "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                    "condition_value": INQUIRE_ARJES_COST,
                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "clist": [
                                        "那下次再说(德里不足).",
                                    ]
                                },
                                {
                                    "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                    "condition_value": INQUIRE_ARJES_COST,
                                    "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                    "execute_value": - INQUIRE_ARJES_COST,
                                    "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                    "clist": [
                                        "成交(支付" + str(INQUIRE_ARJES_COST) + "德里)"
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                        "custom_func": {
                                            "func_name": "update_hero_wandering_info_has_been_inquired_location",
                                            "params": [HERO_ARJES_CODE, true]
                                        },
                                        "content": [
                                            {
                                                "str_from_func": [
                                                    {
                                                        "func_name": "get_arjes_location_name"
                                                    }
                                                ],
                                                "clist": [
                                                    "哈哈, 爽快, 他在 [#{0}], 你在酒馆应该能找到他, 但是他随时可能离开, 没找到可不要赖我啊!",
                                                    "哈哈, 爽快! 他现在在 [#{0}], 你去那边的酒馆碰碰运气吧. 可别怪我没提醒你, 他这人一向神出鬼没, 说不定明天就不在那儿了.",
                                                    "很好, 他现在落脚在 [#{0}]。你可以在当地的酒馆找找看. 不过他行踪不定, 你得抓紧时间."
                                                ]
                                            }
                                        ]
                                    }
                                }
                            ]
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                            "oname": "下次再说",
                            "content": [
                                {
                                    "clist": [
                                        "算了, 下次再说."
                                    ]
                                }
                            ],
                        }
                    ]
                }
            },
        ],
    }
}


const DUKE_DENIES_ARJES_HINT_SAME_LOCATION_DIALOGUE = {

    "custom_choose_func": {
        "func_name": "is_same_location",
        "params": [HERO_UID, HERO_ARJES_CODE]
    },
    "clist": [
        "眼神放亮些(无奈), 他就在酒馆里.",
        "啧...他不就在那儿?(指向酒馆角落).",
        "朝那边看(眼神跳向酒馆角落), 真是笨的可以.",
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "clist": [
                    "好的好的(尴尬)",
                    "抱歉...",
                ]
            }
        ]
    }
}


const DUKE_WHY_KNOWS_ARJES_DIALOGUE = {
    "otype": OPTION_TYPE_ENUM.TALK,
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "oname": "你如何知道[阿尔杰斯]的信息",
    "content": [
        {
            "clist": [
                "为什么你能掌握阿尔杰斯的行踪?",
                "我很好奇, 你为什么对阿尔杰斯的动向这么清楚?"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [
            {
                "clist": [
                    "我和阿尔杰斯早些年有过一些合作, 那时候我们还不算出名, "
                        + "后来各走各的路, 但关系一直没断."
                ]
            }
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "clist": [
                        "他现在做事很低调, 不想随便被人打扰. " \
                        + "我呢, 就帮他把把关, 帮他筛选值得信任的客户, 从而赚取点好处费(奸笑)"
                    ]
                }
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "谢谢你告诉我这些."
                        ]
                    }
                ]
            }
        }
    }
}

static var COMMON = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "你好啊, 我是杜克, 这里没人不认识我的名字, 尤其是贵族和管家们, 他们喜欢把\"货物\"卖给我, 因为我总能给出比别人高的价格(得意)"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "了解如何处理\"货物\"",
                "content": [
                        {
                            "clist": [
                                "你是如何处理这些\"货物\"的?"
                            ]
                        }
                    ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "我处理这些\"货物\"的方式很简单: 找到最合适的买家. " \
                                + "无论是卖到一些需要重体力劳动的矿场, 还是训练成角斗士作为贵族娱乐对象, " \
                                + "只要他们符合要求，我总能为他们找到一个新主人"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "clist": [
                                    "很有趣..."
                                ]
                            },
                        ],
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "打听[阿尔杰斯]的下落",
                "content": [
                    {
                        "clist": [
                            "冒昧问一句，你知道[游荡者·阿尔杰斯]最近在哪儿活动吗?"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        DUKE_DENIES_ARJES_HINT_SAME_LOCATION_DIALOGUE,
                        {
                            "clist": [
                                "哼, 你也听说了我和阿尔杰斯有联系? 倒也不奇怪. 不过, 我可不会随便把这类消息告诉路人. 你得先让我觉得你...值得信任(出售足够多的奴隶)."
                            ]
                        },
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.SELL_PRISONER,
                "is_special_slave_trader_price": true,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "出售俘虏",
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "希望我们很快能再见面(得意的笑)"
                            ]
                        }
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}


static var RELATIONSHIP = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "又见面了, 我的老朋友! 今天又带来了什么\"好货\"?"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "打听[阿尔杰斯]的下落",
                "content": [
                    {
                        "clist": [
                            "杜克, 现在能告诉我[游荡者·阿尔杰斯]在哪儿活动吗?"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        DUKE_DENIES_ARJES_HINT_SAME_LOCATION_DIALOGUE,
                        {
                            "clist": [
                                "阿尔杰斯的消息可不是随便就能打听到的, 你还没达到我的准则(冷笑)(暗示再多照顾生意)"
                            ]
                        },
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.SELL_PRISONER,
                "is_special_slave_trader_price": true,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "出售俘虏",
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "你总是能给我带来惊喜(得意的笑)"
                            ]
                        }
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}


static var RELATIONSHIP_02 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "哇哦, 每次见到你, 我就知道又有好买卖要来了"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "打听[阿尔杰斯]的下落",
                "content": [
                    {
                        "clist": [
                            "我们也算打过不少交道了, 现在能告诉我阿尔杰斯的行踪吗?"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        DUKE_DENIES_ARJES_HINT_SAME_LOCATION_DIALOGUE,
                        {
                            "clist": [
                                "我得承认, 你比我预想中靠谱不少, 但是还差那么一点(坏笑)(暗示再多照顾生意)"
                            ]
                        },
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.SELL_PRISONER,
                "is_special_slave_trader_price": true,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "出售俘虏",
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "你可真懂我啊，从没让我失望过"
                            ]
                        }
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}


static var RELATIONSHIP_03 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "老朋友, 最近如何? 我有一个特殊的\"货\"要介绍给你, 你一定会喜欢"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "了解\"货\"",
                "content": [
                    {
                        "clist": [
                            "说说看"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "一个狡猾的盗贼, 他曾用6把飞刀干掉了5个守卫, 被抓住并卖到我这之后, 还自己解开了手铐. " \
                                + "这样的人才, 你可不能错过"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "clist": [
                                    "嗯....听起来是个狠角色, 但是如何能保证我买下他后他不会逃走"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                            "content": [
                                {
                                    "clist": [
                                        "这就要看运气了, 好东西嘛, 就该值得去冒险(坏笑)"
                                    ]
                                },
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.DIALOG,
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "(思考片刻)好, 开个价"
                                        ]
                                    },
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {
                                            "clist": [
                                                "友情价, " + str(SELL_HERO_PRICE) + "德里(嬉笑)"
                                            ]
                                        },
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.PAY,
                                                "is_special_slave_trader_price": true,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "成交(花费" + str(SELL_HERO_PRICE) + "德里)",
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": SELL_HERO_PRICE,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": [
                                                            "我需要考虑看看(德里不足)",
                                                        ]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": SELL_HERO_PRICE,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": - SELL_HERO_PRICE,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": [
                                                            "成交(交钱), 带他过来",
                                                        ],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "content": [
                                                                {
                                                                    "clist": [
                                                                        "维森特, 过来, 看看你的新主人, 你可要好好表现啊哈哈哈, " \
                                                                        + "你的主人可是很强大且慷慨的"
                                                                    ]
                                                                },
                                                            ],
                                                            "next": {
                                                                "step_type": STEP_TYPE_ENUM.DIALOG,
                                                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                                "turn_hero_uid": SELL_HERO_UID,
                                                                "content": [
                                                                    {
                                                                        "clist": [
                                                                            "(低头, 兜帽半遮, 但也能看出脸上有伤, 冰冷的眼神看着你...)..."
                                                                        ]
                                                                    },
                                                                ],
                                                                "next": {
                                                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                                    "content": [
                                                                        {
                                                                            "clist": [
                                                                                "我不在乎你之前干了什么, 现在既然是我买下你, 只要你表现得好, 我就不会亏待你. 但如果你敢对我的部下耍花招, 绝对别指望我会轻饶你"
                                                                            ]
                                                                        },
                                                                    ],
                                                                    "next": {
                                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                                        "turn_hero_uid": SELL_HERO_UID,

                                                                        "hire_hero_success": SELL_HERO_UID,
                                                                        "change_current_dialogue_flag": "AFTER_GET_HERO",
                                                                        "content": [
                                                                            {
                                                                                "clist": [
                                                                                    "当然, 你是我的救命恩人"
                                                                                ]
                                                                            }
                                                                        ],
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    },
                                                ],
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "离开",
                                                "content": [
                                                    {
                                                        "clist": [
                                                            "下次再说."
                                                        ]
                                                    }
                                                ],
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    }
                }
            },
            ALLOW_INQUIRE_ARJES_DIALOGUE,
            DUKE_WHY_KNOWS_ARJES_DIALOGUE,
            {
                "otype": OPTION_TYPE_ENUM.SELL_PRISONER,
                "is_special_slave_trader_price": true,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "出售俘虏",
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "愿你财源不断"
                            ]
                        }
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}


static var AFTER_GET_HERO = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "最近如何我的老朋友?"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            ALLOW_INQUIRE_ARJES_DIALOGUE,
            DUKE_WHY_KNOWS_ARJES_DIALOGUE,
            {
                "otype": OPTION_TYPE_ENUM.SELL_PRISONER,
                "is_special_slave_trader_price": true,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "出售俘虏",
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "愿你长寿, 财源不断"
                            ]
                        }
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}

func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if _hero_json.has("current_dialogue_flag"):
        return get(_hero_json.current_dialogue_flag)


    var _count: = AchievementMetaDataUtils.get_minor_hero_0004_sell_slave_count()
    if _count >= 100:
        return RELATIONSHIP_03

    if _count >= 65:
        return RELATIONSHIP_02

    if _count >= 30:
        return RELATIONSHIP

    return COMMON