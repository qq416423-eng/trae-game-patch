extends BaseDialogue

const HERO_UID: = "minor_hero_0010"

const FORGOTTEN_WATER_PRICE = 16000

const FORGOTTEN_WATER_EXCHANGE_GOODS_CODE = "helmet_0086"

const FIRST: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "(他似乎不想和你说话)",
                "(他没空和你说话)",
                "(看见你想搭话, 他无视了你并默默走开)"
            ]
        },
    ],
}


const FIRST_FRIENDLY_DIALOGUE: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "str_from_func": [
                {
                    "func_name": "get_player_name"
                }
            ],
            "clist": [
                "你就是#{0}吧, 我有听杜克说起你."
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "clist": [
                    "是的, 幸会, 可以和我做一些生意吗?"
                ]
            },
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "clist": [
                        "当然, 我相信杜克推荐的人."
                    ]
                },
            ],
            "change_current_dialogue_flag": "FORMAL_DIALOGUE",
        }
    }
}

static var FORMAL_DIALOGUE = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "需要点什么?",
                "风尘仆仆的(打量), 需要点什么?"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "购买[遗忘之水]",
                "content": [
                    {
                        "clist": [
                            "遗忘之水(功能: 重置英雄属性点), 还有吗?"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "有的, 那你准备好了交换之物: [卡姆拉宝石]吗?(物品栏需要有品级为普通级以上的[卡姆拉宝石头饰], 击败地狱之矛·库德鲁概率性掉落) " \
                                + "没有的话, 也可以用" + str(FORGOTTEN_WATER_PRICE) + "德里交换(冷笑)"
                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.PAY,
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "oname": "使用[卡姆拉宝石头饰]交换",
                                "content": [
                                    {

                                        "custom_choose_func": {
                                            "func_name": "check_has_goods_min_quality",
                                            "params": [FORGOTTEN_WATER_EXCHANGE_GOODS_CODE, WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON]
                                        },
                                        "str_from_func": [
                                            {
                                                "func_name": "find_and_get_goods_name_min_quality",
                                                "params": [FORGOTTEN_WATER_EXCHANGE_GOODS_CODE, WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON]
                                            }
                                        ],
                                        "clist": [
                                            "(我要用背包里的[#{0}]交换吗?)"
                                        ],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.OPTION,
                                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                            "option_list": [
                                                {
                                                    "otype": OPTION_TYPE_ENUM.PAY,
                                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                    "oname": "确定交换",
                                                    "content": [
                                                        {
                                                            "custom_func": {
                                                                "func_name": "exchange_forgotten_water_by_helmet_0086",
                                                            },
                                                            "clist": [
                                                                "成交(交出[卡姆拉宝石头饰])"
                                                            ]
                                                        },
                                                    ],
                                                    "next": {
                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "合作愉快(取出遗忘之水)"
                                                                ]
                                                            },
                                                        ],
                                                    }
                                                },
                                                {
                                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                    "oname": "取消",
                                                    "content": [
                                                        {
                                                            "clist": [
                                                                "下次再说."
                                                            ]
                                                        }
                                                    ]
                                                },
                                            ]
                                        }
                                    },
                                    {

                                        "clist": [
                                            "下次再说(背包里没有普通品质以上的卡姆拉宝石头饰)."
                                        ]
                                    },
                                ],
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.PAY,
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "oname": "使用" + str(FORGOTTEN_WATER_PRICE) + "德里交换",
                                "content": [
                                    {

                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                        "condition_value": FORGOTTEN_WATER_PRICE,
                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                        "clist": [
                                            "下次再说(德里不足).",
                                        ]
                                    },
                                    {
                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                        "condition_value": FORGOTTEN_WATER_PRICE,
                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                        "custom_func": {
                                            "func_name": "exchange_forgotten_water_by_money",
                                            "params": [FORGOTTEN_WATER_PRICE]
                                        },
                                        "clist": [
                                            "成交(交出" + str(FORGOTTEN_WATER_PRICE) + "德里)",
                                        ],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                            "content": [
                                                {
                                                    "clist": [
                                                        "拿着(取出遗忘之水)"
                                                    ]
                                                },
                                            ],
                                        }
                                    }
                                ]
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.TALK,
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "oname": "下次再说",
                                "content": [
                                    {
                                        "clist": [
                                            "算了, 下次再说"
                                        ]
                                    }
                                ],
                            }
                        ]
                    }
                }
            }
        ]
    }
}

func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if _hero_json.has("current_dialogue_flag"):
        return get(_hero_json.current_dialogue_flag)


    var _count: = AchievementMetaDataUtils.get_minor_hero_0004_sell_slave_count()
    if _count < 100:
        return FIRST
    else:
        return FIRST_FRIENDLY_DIALOGUE

func get_hero_uid()-> String:
    return HERO_UID