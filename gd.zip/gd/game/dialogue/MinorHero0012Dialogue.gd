extends BaseDialogue

const HERO_UID: = "minor_hero_0012"







func get_current_dialogue_template()-> Dictionary:
    return _T_FIRST()


static func _T_FIRST()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [
            {
                "clist": [
                    "愿多明尼卡的祝福与你同在, 旅行者。",
                    "主的光辉照耀着这片大地, 愿祂指引你的道路。",
                ]
            },
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "祷告",
                    "content": [{"clist": ["我想请您为我祷告。"]}],
                    "next": _T_PRAY(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "捐赠",
                    "content": [{"clist": ["我想为当地的民众捐赠一些物资。"]}],
                    "next": _T_DONATE(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["告辞了, 修女。"]}],
                },
            ],
        },
    }


static func _T_PRAY()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [
            {
                "clist": [
                    "我已为你祈祷, 愿主保佑你前路平安。你看起来需要一些补给, 愿主赐予你食物。",
                ],
                "custom_choose_func": {"func_name": "nun_check_pray_cooldown_ready"},
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": ["这些食物给你, 愿它们温暖你的旅途。"],
                            "custom_func": {"func_name": "nun_give_random_food"},
                        },
                    ],
                },
            },
            {
                "clist": ["我已经为你祷告了, 七日后再来吧, 愿主与你同在。"],
            },
        ],
    }


static func _T_DONATE()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [
            {
                "clist": ["你的善举令人感动, 愿主铭记你的慷慨。你想向哪里的民众捐赠?"],
                "custom_choose_func": {"func_name": "nun_check_donate_cooldown_ready"},
                "next": {
                    "step_type": STEP_TYPE_ENUM.OPTION,
                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                    "option_list": [
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "向罗奥民众捐赠",
                            "content": [{"clist": ["向罗奥民众捐赠"]}],
                            "next": _T_DONATE_FOOD_OPTIONS("LUCIANA"),
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "向塞娜民众捐赠",
                            "content": [{"clist": ["向塞娜民众捐赠"]}],
                            "next": _T_DONATE_FOOD_OPTIONS("EDRAS"),
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "向马尔克民众捐赠",
                            "content": [{"clist": ["向马尔克民众捐赠"]}],
                            "next": _T_DONATE_FOOD_OPTIONS("DORDAR"),
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "向沙鲁克民众捐赠",
                            "content": [{"clist": ["向沙鲁克民众捐赠"]}],
                            "next": _T_DONATE_FOOD_OPTIONS("HASKAL"),
                        },
                        {
                            "otype": OPTION_TYPE_ENUM.LEAVE,
                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                            "oname": "算了",
                            "content": [{"clist": ["我再想想"]}],
                        },
                    ],
                },
            },
            {
                "clist": ["感谢你的善心, 但我最近已经接收了足够的捐赠, 七日后再来吧。"],
            },
        ],
    }


static func _T_DONATE_FOOD_OPTIONS(_country_code: String)-> Dictionary:
    var _options: Array = []
    var _food_goods: Array = _get_unlocked_food_goods()
    var _count: int = min(_food_goods.size(), 4)
    for i in _count:
        var _goods_json: Dictionary = _food_goods[i]
        var _uid: String = _goods_json.item.uid
        var _name: String = _get_food_name(_uid)
        var _price: int = _get_food_price(_uid)
        var _display: String = "捐赠%s (每次5个)" % _name
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _display,
            "content": [{"clist": ["我捐赠5个%s" % _name]}],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": ["愿主保佑你的善举, 我会将这些食物分发给当地的民众。"],
                        "custom_func": {
                            "func_name": "nun_donate_food",
                            "params": [_uid, _price, _country_code],
                        },
                    },
                ],
            },
        })
    if _options.is_empty():
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "没有可捐赠的食物",
            "content": [{"clist": ["我背包里没有足够的食物可以捐赠"]}],
        })
    else:
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "算了",
            "content": [{"clist": ["我再想想"]}],
        })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _options,
    }


static func _get_unlocked_food_goods()-> Array:
    var _result: Array = []
    var _goods: Array = WSData.get_player_goods()
    for _goods_json: Dictionary in _goods:
        var _uid: String = _goods_json.item.uid
        if not _uid.begins_with("food_"):
            continue
        if _uid.begins_with("food_bad_"):
            continue
        if CommonUtils.get_value(_goods_json.item, "lock", false):
            continue
        if _goods_json.count < 5:
            continue
        _result.append(_goods_json)
    _result.shuffle()
    return _result

static func _get_food_name(_uid: String)-> String:
    var _json: Dictionary = GoodsUtils.get_json_by_uid(_uid)
    return CommonUtils.get_value(_json, "name", _uid)

static func _get_food_price(_uid: String)-> int:
    var _json: Dictionary = GoodsUtils.get_json_by_uid(_uid)
    return int(CommonUtils.get_value(_json, "price", 0))