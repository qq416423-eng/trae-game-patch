extends BaseDialogue

const HERO_UID: = "mod_appraiser"


func get_current_dialogue_template()-> Dictionary:
    return _T_GREETING()


func get_hero_uid()-> String:
    return HERO_UID



static func _T_GREETING()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（一个货郎模样的人蹲在酒馆角落, 面前摆着几件蒙尘的兵器。他抬眼打量你一眼, 嘴角挑起一抹笑）",
        ]}],
        "next": _T_GREETING_2(),
    }



static func _T_GREETING_2()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "哟, 看货的? 我这儿只出本乡本土的物件, 别处来的不收。要不要猜猜价?",
        ]}],
        "next": _T_MAIN_OPTIONS(),
    }



static func _T_MAIN_OPTIONS()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            _appraiser_open_option(),
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "聊聊",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["你专做这行当的?"]}],
                "next": _T_CHAT_1(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "告辞",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["不打扰你了, 回见。"]}],
            },
        ],
    }



static func _appraiser_open_option()-> Dictionary:
    return {
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "猜装备价格",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "custom_func": {"func_name": "appraiser_request_open"},
        "content": [{"clist": ["成, 摆货吧。"]}],
    }



static func _T_CHAT_1()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "算是吧。这城里哪件家伙什值几个钱, 我心里有本账。",
        ]}],
        "next": _T_CHAT_2(),
    }


static func _T_CHAT_2()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "规矩简单: 你看货, 自己开个价, 猜它值多少德里。我揭行情的底。",
            "猜得跟我这本账差得不多, 就算你中; 差远了, 押的就归我。要押钱押货, 随你。",
            "想多赢, 把倍率开高——倍率越高我容你偏的余地越小, 赔得也越狠。愿赌服输。",
        ]}],
        "next": _T_CHAT_OPTIONS(),
    }


static func _T_CHAT_OPTIONS()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            _appraiser_open_option(),
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "告辞",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["今天就到这, 回见。"]}],
            },
        ],
    }