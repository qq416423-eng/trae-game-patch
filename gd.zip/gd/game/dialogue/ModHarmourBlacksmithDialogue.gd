extends BaseDialogue

const HERO_UID: = "mod_blacksmith_harmour"


static func _T_GREETING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（马铠铁匠正在给一副马面甲抛光，金属的光泽映在他专注的脸上。他听到脚步声抬起头）"]}],
        "next": _T_GREETING_2(),
    }


static func _T_GREETING_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["大人来了！我别的不会，专打马铠。战马披上我打的甲，刀枪不入！您要锻什么马铠？"]}],
        "next": _T_OPTIONS(),
    }


static func _T_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "锻造装备",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["我想锻造一些马铠。"]}],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "交谈",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["专门打马铠？这门手艺可不常见。"]}],
                "next": _T_TALK_RESPONSE(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "告辞",
                "content": [{"clist": ["辛苦了，回头见。"]}],
            }
        ]
    }


static func _T_TALK_RESPONSE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["可不是嘛！当年我在骑兵营里待过，见过太多战马因为没护甲倒在箭下。后来我就立志专攻马铠这门手艺。"]}],
        "next": _T_TALK_RESPONSE_2(),
    }


static func _T_TALK_RESPONSE_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["一匹好马比十个兵都金贵，给它披上好甲，就是给它第二条命！"]}],
        "next": _T_OPTIONS(),
    }


func get_current_dialogue_template()-> Dictionary:
    return _T_GREETING()


func get_hero_uid()-> String:
    return HERO_UID