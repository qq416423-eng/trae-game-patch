extends BaseDialogue

const HERO_UID: = "mod_hero_0002"
const GARRISON_LOCATION: = "MWSpecialLocation0001"



static func _T_FIRST_MEET():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["（一个面色疲惫的军官站在林间，身旁插着一面残破的旗帜，正是老板娘说的那个人）"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "交谈",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["你就是老板娘说的那个蓝潭湖边逃出来的陌生人？"]}],
                    "next": _T_MOYAN_STORY_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["保重."]}],
                }
            ]
        }
    }

static func _T_MOYAN_STORY_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["（缓缓抬头，面色疲惫但仍透着几分书卷气）"]}],
        "next": _T_MOYAN_STORY_2(),
    }

static func _T_MOYAN_STORY_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["你听说了...不错，正是在下。我叫墨言，曾是北方一位领主的军师。"]}],
        "next": _T_MOYAN_STORY_3(),
    }

static func _T_MOYAN_STORY_3():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["前些日子，我家主公被邻邦的领主联合围攻，大营被破，兵马溃散。"]}],
        "next": _T_MOYAN_STORY_4(),
    }

static func _T_MOYAN_STORY_4():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["我带着几个亲随趁夜突围，一路南下。前几晚在蓝潭湖边的森林里，追兵赶了上来，亲随们拼死拖住他们，我才得以脱身。"]}],
        "next": _T_FIRST_MEET_OPTIONS(),
    }

static func _T_FIRST_MEET_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "救治",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "custom_choose_func": {"func_name": "check_player_has_dual_skill_heroes", "params": [],},
                        "change_current_dialogue_flag_config": [
                            {"hero_uid": "mod_hero_0002", "dialogue_flag": "HEALED"},
                        ],
                        "clist": ["你伤得不轻，让我的人帮你处理一下伤口。"],
                        "next": _T_HEALING_1(),
                    },
                    {
                        "clist": ["（你的队伍里缺乏足够的医疗人手……）"],
                        "next": _T_HEALING_FAIL_1(),
                    }
                ],
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [{"clist": ["保重."]}],
            }
        ]
    }

static func _T_HEALING_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["（惊讶地看着你）你...你愿意帮我？多谢。"]}],
        "next": _T_HEALING_2(),
    }

static func _T_HEALING_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["这些伤口是突围时留下的，若再不处理，恐怕会感染。"]}],
        "next": _T_HEALING_3(),
    }

static func _T_HEALING_3():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [{"clist": ["（经过一番救治，墨言的伤势稳定了下来）"]}],
        "next": _T_HEALING_4(),
    }

static func _T_HEALING_4():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["好多了...你的队伍里有医术精湛之人，实在难得。"]}],
        "next": _T_HEALING_5(),
    }

static func _T_HEALING_5():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["大恩不言谢。不过我如今孤身一人，追兵可能还在附近，得尽快找个安全的地方落脚才是。"]}],
        "next": _T_HEALING_6(),
    }

static func _T_HEALING_6():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["我听说这附近有一处隐匿矿洞，地势险要，易守难攻，是个绝佳的藏身之处。不知你可知那地方？"]}],
        "next": _T_GARRISON_OPTIONS(),
    }

static func _T_HEALING_FAIL_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["（看了看你的队伍，摇了摇头）你的队伍里没有精通医术之人，这伤...你们处理不了。"]}],
        "next": _T_HEALING_FAIL_2(),
    }

static func _T_HEALING_FAIL_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["要处理我这种程度的伤，至少需要两名擅长手术和医疗的人——手术七级以上，医疗五级以上。"]}],
        "next": _T_HEALING_FAIL_3(),
    }

static func _T_HEALING_FAIL_3():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["等你队伍里有这样的人了，再来找我吧。"]}],
    }

static func _T_GARRISON_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "请带路",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_func": {"func_name": "start_follow_to_garrison",},
                "change_current_dialogue_flag_config": [
                    {"hero_uid": "mod_hero_0002", "dialogue_flag": "FOLLOWING"},
                ],
                "content": [{"clist": ["我知道那个地方，而且那里已经被我拿下了。跟我来吧，我带你过去。"]}],
                "next": _T_FOLLOW_OK(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [{"clist": ["我先告辞了，保重。"]}],
            }
        ]
    }

static func _T_FOLLOW_OK():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["感激不尽。请在前面带路，我跟在你后面。"]}],
    }

static func _T_HEALED():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["（墨言的伤势已经稳定了许多，他正坐在一旁，看到你过来便站起身来）"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "交谈",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，你的伤势怎么样了？"]}],
                    "next": _T_HEALED_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再聊."]}],
                }
            ]
        }
    }

static func _T_HEALED_CHAT_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["伤势已经稳定了，多谢关心。我还是想去隐匿矿洞，那里地势险要，是个好驻地。"]}],
        "next": _T_HEALED_CHAT_2(),
    }

static func _T_HEALED_CHAT_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["你若是拿下了那里，就带我过去吧。"]}],
        "next": _T_GARRISON_OPTIONS(),
    }

static func _T_FOLLOWING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["我还在跟着你呢，我们继续往隐匿矿洞走吧。"]}],
    }

static func _T_ARRIVED():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["终于到了...隐匿矿洞，果然是个好地方。"]}],
        "next": _T_ARRIVED_2(),
    }

static func _T_ARRIVED_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["多谢你一路护送。这里地势险要，易守难攻，我就在这里安顿下来了。"]}],
        "next": _T_ARRIVED_3(),
    }

static func _T_ARRIVED_3():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["以后若有需要，随时来找我。"]}],
    }

static func _T_CHATTING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["（墨言正坐在隐匿矿洞的入口处，看到你来了，微微点头示意）"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "任命",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "has_appointable_hero", "params": []},
                            "clist": ["墨言，我想任命一位将领独立带队，你帮我安排一下。"],
                            "next": _T_HERO_SELECTION(),
                        },
                        {
                            "clist": ["（你的队伍里没有其他将领可以任命了。注意：主角不能被任命为分队长，你需要至少还有其他英雄随行。）"],
                            "next": _T_APPOINT_FAIL(),
                        }
                    ],
                },
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "召回",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "recall_appointed_hero"},
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "has_appointed_team", "params": []},
                            "clist": ["墨言，让所有分队长归队吧。"],
                            "next": _T_RECALL_SUCCESS(),
                        },
                        {
                            "clist": ["（当前没有外派的分队……）"],
                            "next": _T_RECALL_FAIL(),
                        }
                    ],
                },
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "寻人",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "custom_func": {"func_name": "recover_lost_appointed_heroes"},
                    "content": [
                        {
                            "custom_choose_func": {"func_name": "has_lost_appointed_heroes", "params": []},
                            "clist": ["墨言，我有将领失踪了，你能帮忙查一查吗？"],
                            "next": _T_RECOVER_SUCCESS(),
                        },
                        {
                            "clist": ["（墨言仔细核查了名册，没有发现失踪的将领。）"],
                            "next": _T_RECOVER_FAIL(),
                        }
                    ],
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_APPOINT_SUCCESS():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["好的，我已安排好。这位将领已经独立带队，你可以在大地图上找到他们。如果需要分兵，直接去找这位将领对话即可。"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_APPOINT_FAIL():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["你的队伍里现在没有可以任命的将领。注意：主角不能被任命为分队长，你需要至少还有其他英雄随行。"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_RECALL_SUCCESS():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["好的，所有分队长已经全部归队。他们的士兵也一并编入你的队伍了。"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_RECALL_FAIL():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["现在没有外派的分队。如果你需要分兵，我可以帮你安排。"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_RECOVER_SUCCESS():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["我查过了。确有几位将领在混乱中与队伍失散，但我已经重新联系上了他们。他们现在都在您的麾下了，请过目。"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_RECOVER_FAIL():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["我仔细核查了名册，所有将领都各就各位，没有失踪的人。您不必担心。"]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": [
                {
                    "otype": OPTION_TYPE_ENUM.TALK,
                    "oname": "闲聊",
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [{"clist": ["墨言先生，在这里住得还习惯吗？"]}],
                    "next": _T_CHAT_1(),
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "oname": "离开",
                    "content": [{"clist": ["下次再来看你."]}],
                }
            ]
        }
    }

static func _T_CHAT_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["这里很好，安静、安全，正适合我整理思绪、研究兵法。"]}],
        "next": _T_CHAT_2(),
    }

static func _T_CHAT_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{"clist": ["你若有空，常来看看，我们可以聊聊天下大势。"]}],
    }



static func _T_HERO_SELECTION():
    var _hero_list: Array = DialogueCustomUtils.get_appointable_hero_list()
    var _option_list: Array = []
    for _hero in _hero_list:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _hero.name,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "custom_func": {
                "func_name": "select_hero_for_appointment",
                "params": [_hero.uid]
            },
            "content": [{"clist": ["让 " + _hero.name + " 独立带队。"]}],
            "next": _T_SOLDIER_SELECTION(),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "返回",
        "content": [{"clist": ["算了，改天再说。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }



static func _T_SOLDIER_SELECTION():
    var _soldier_list: Array = DialogueCustomUtils.get_appointable_soldier_list()
    var _option_list: Array = []
    for _soldier in _soldier_list:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _soldier.name + "（" + str(_soldier.count) + "人）",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["带一些" + _soldier.name + "给他。"]}],
            "next": _T_APPOINT_SOLDIER_COUNT_SELECTION(_soldier.uid, _soldier.name),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "仅英雄，不带兵",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "custom_func": {"func_name": "appoint_selected_hero_only"},
        "content": [{"clist": ["让他独自一人出发吧。"]}],
        "next": _T_APPOINT_SUCCESS(),
    })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "返回",
        "content": [{"clist": ["算了，改天再说。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }



static func _T_APPOINT_SOLDIER_COUNT_SELECTION(_soldier_uid: String, _soldier_name: String = ""):
    var _option_list: Array = []
    for _count in[10, 50, 100]:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "分" + str(_count) + "名",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "custom_func": {
                "func_name": "appoint_selected_hero_with_soldier",
                "params": [_soldier_uid, _count]
            },
            "content": [{"clist": ["分" + str(_count) + "名" + _soldier_name + "给他。"]}],
            "next": _T_APPOINT_SUCCESS(),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "返回",
        "content": [{"clist": ["算了，改天再说。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list
    }


func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if _hero_json == null or _hero_json.is_empty():
        return _T_FIRST_MEET()
    if not _hero_json.has("current_dialogue_flag"):
        return _T_FIRST_MEET()


    if _hero_json.current_dialogue_flag == "ARRIVED":
        DialogueUtils.change_current_dialogue_flag(HERO_UID, "CHATTING")
        return _T_ARRIVED()

    return call("_T_" + _hero_json.current_dialogue_flag)




func get_battle_chat_charge()-> String:
    return[
        "诸将士听令, 随我冲锋!",
        "时机已到, 全军出击!",
        "阵型不乱, 胜利可期!",
        "以智取胜, 以谋制敌!"
    ].pick_random()

func get_battle_chat_move()-> String:
    return[
        "稳步前进, 保持阵型.",
        "全军听令, 向前推进!",
        "注意侧翼, 保持警戒.",
        "兵贵神速, 加快步伐!"
    ].pick_random()

func get_battle_chat_attack()-> String:
    return[
        "就是现在, 进攻!",
        "瞄准敌军弱点, 出击!",
        "一击必杀, 不要给他们喘息的机会!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "运筹帷幄之中, 决胜千里之外.",
        "此乃天命, 非战之罪.",
        "抱歉, 你我各为其主.",
        "胜败乃兵家常事, 安息吧.",
        "你的战术太过直白, 早已被我看穿."
    ]
    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...无妨, 还能再战.",
        "这点小伤不足挂齿.",
        "军师不上前线...但今天例外!",
        "啧, 看来需要重新评估战局了.",
        "还...还没完...",
        "我的计算不该有误..."
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "棋差一着...满盘皆输...",
        "主公...恕墨言无能...",
        "这就是...我最后的谋略了...",
        "快走...不要管我...",
        "天下...终究还是乱了..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return["援军已到, 稳住阵脚!",].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return["按计划稳步推进!",].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return["固守阵地!"].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "正如我所料, 一切尽在掌握.",
        "此番胜利, 全赖将士用命.",
        "胜不骄, 败不馁, 我们继续前进.",
        "兵法有云: 知己知彼, 百战不殆.",
        "一场漂亮的胜仗! 回营整军, 准备下一战."
    ].pick_random()