extends BaseDialogue

const HERO_UID: = "mod_hero_0003"









static func _T_FIRST_MEET():
    var _n: String = SoldierUtils.get_player_nickname()
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "change_current_dialogue_flag": "MET",
        "content": [{"clist": [
            "（征伐骑士身后的阴影里，不知何时多站了一个人。她掀开兜帽一角，黑发下是一双红瞳）",
            "别找了，不是他——是我。初次见面，" + _n + "。你可以叫我「不笑」。",
        ]}],
        "next": _T_IDENTITY(),
    }

static func _T_IDENTITY():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "先说清楚，免得你瞎猜：本小姐是血族。黑发、红瞳、见不得光，如你所见。",
            "至于「不笑」这名字……是黑月教会那位大祭司亲手下的咒。谁让我多嘴，拆穿了他拿活人献祭的把戏呢。",
        ]}],
        "next": _T_MISSION(),
    }

static func _T_MISSION():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "不过我今天来，不是为了那笔旧账。",
            "教廷日夜供奉的那位神，他们唤作「黑月之子」——说白了，就是邪神。本小姐，正是祂的传教士。",
            "祂对你起了兴趣。于是把我派来，跟着你，走完这一程。",
        ]}],
        "next": _T_MISSION_OPTION(),
    }

static func _T_MISSION_OPTION():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "答应她",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{
                    "hire_hero_success": HERO_UID,
                    "change_current_dialogue_flag": "HIRED",
                    "clist": ["既然是祂的意思，那就一起走。"],
                    "next": _T_JOIN_LAST(),
                }],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "追问",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["邪神……还有你身上那道咒，到底怎么回事？"]}],
                "next": _T_ASK_CURSE_1(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "拒绝",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["我自己的路，还不需要别人来插手。"]}],
                "next": _T_REFUSE_1(),
            },
        ]
    }


static func _T_MET():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "change_current_dialogue_flag": "MET_REPEAT",
        "content": [{"clist": [
            "无事不登三宝殿，呐，有什么事要和我商讨呢？",
            "来找我，是需要我的帮助吗？放心，这不是一场说走就走的旅行，我也不会说帮就帮哦。",
            "这就来找我了吗？一副杂口的模样啊，呵呵。（嘴角微微勾起，带着嘲讽的笑看着你，你什么都做不到）",
        ]}],
        "next": _T_MET_OPTION(),
    }


static func _T_MET_REPEAT():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "还有什么事吗？一副欲言又止又不肯离开的模样，只期望找到别的乐趣吗？",
            "当然，你现在一定很闲，不过我的确有时间陪你耗（吸血鬼你说呢？）。",
        ]}],
        "next": _T_MET_OPTION(),
    }

static func _T_MET_OPTION():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "答应她",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{
                    "hire_hero_success": HERO_UID,
                    "change_current_dialogue_flag": "HIRED",
                    "clist": ["跟那帮借神之名吃人的家伙算账，我陪你。一起吧。"],
                    "next": _T_JOIN_LAST(),
                }],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "问问她的诅咒",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["先说清楚，你身上那道诅咒，到底怎么回事？"]}],
                "next": _T_ASK_CURSE_1(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "拒绝",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["我自己的路，还不需要别人来插手。"]}],
                "next": _T_REFUSE_1(),
            },
        ]
    }


static func _T_ASK_CURSE_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（她掀起兜帽一角，黑发下是那双红瞳）瞧清楚了，本小姐是血族——黑发、红瞳、见不得光。至于「不笑」这名字……是黑月教会的大祭司下的咒，只因为我多嘴，拆穿了他拿活人献祭的把戏。",
            "想解开？咒是那位大祭司亲手下的，解铃还须系铃人。除非——有人能让那位大祭司，再也张不开嘴。",
        ]}],
        "next": _T_ASK_CURSE_2(),
    }

static func _T_ASK_CURSE_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（她的指尖在剑柄上顿了一下）……我一个人去过教廷。结果呢？你看，我还好好地坐在这儿。",
            "至于过程，哼，本小姐凭什么告诉你。笨蛋。",
        ]}],
        "next": _T_ASK_CURSE_3(),
    }

static func _T_ASK_CURSE_3():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "至于那位神——我侍奉的是祂，不是那帮借祂的名吃人的家伙。别把他们和祂混为一谈。",
            "别岔开话题了。说回正事——到底要不要本小姐跟着你？我的耐心，可没多到能陪你反复犹豫。",
        ]}],
        "next": _T_ASK_CURSE_OPTION(),
    }

static func _T_ASK_CURSE_OPTION():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "答应她",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{
                    "hire_hero_success": HERO_UID,
                    "change_current_dialogue_flag": "HIRED",
                    "clist": ["我们目标相同。你的账，我陪你一起算。"],
                    "next": _T_JOIN_LAST(),
                }],
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "拒绝",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["这件事，我不能答应。"]}],
                "next": _T_REFUSE_1(),
            },
        ]
    }


static func _T_REFUSE_1():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（她愣了一瞬，随即炸了毛）哈？本小姐主动开口，你还敢拒绝？"]}],
        "next": _T_REFUSE_2(),
    }

static func _T_REFUSE_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["行，随你。反正我哪儿也不去，就在这儿等着——等你哪天想通了，再回来求我。", "才、才不是在等你呢，别自作多情。"]}],
    }


static func _T_JOIN_LAST():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（她别开脸，像是想把翘起的情绪藏起来，却只能扯出一个僵硬的弧度）……嗯。那就说定了。",
            "别误会，我只是顺路。等那笔旧账清了、等那位看够了，本小姐立刻就走人。",
            "至于你？别死太早——祂还没看够呢。",
        ]}],
    }


static func _T_HIRED():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "还有什么事吗？一副欲言又止又不肯离开的模样，只期望找到别的乐趣吗？",
            "当然，你现在一定很闲，不过我的确有时间陪你耗（吸血鬼你说呢？）。",
        ]}],
    }


func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if _hero_json == null or _hero_json.is_empty():
        return _T_FIRST_MEET()
    if not _hero_json.has("current_dialogue_flag"):
        return _T_FIRST_MEET()
    var _flag: String = str(_hero_json.current_dialogue_flag)
    if _flag == "HIRED":
        return _T_HIRED()
    if _flag == "MET_REPEAT":
        return _T_MET_REPEAT()
    if _flag == "MET":
        return _T_MET()
    return _T_FIRST_MEET()


func get_entry_option()-> Dictionary:
    if WSData.has_hero_in_team(HERO_UID):
        return {}
    var _ck_code: String = NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT
    var _ck_data: Dictionary = GlobalNpcTeamData.spawn_trigger_power_value_data.get(_ck_code, {})
    if not _ck_data.has("death_days"):
        return {}
    return {
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "有人想了解你",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [{"clist": ["（有个声音在你耳边低语：有人想了解你。）"]}],
        "next": get_current_dialogue_template(),
    }






func get_battle_chat_charge()-> String:
    return[
        "全员，跟上！别拖本小姐的后腿。",
        "哼，那就让黑月教会见识见识血族的手段。",
        "冲锋——气势拿捏好，别给我丢脸。",
    ].pick_random()

func get_battle_chat_move()-> String:
    return[
        "跟上，别掉队。",
        "动作快点，本小姐没耐心等。",
        "保持阵型，稳稳地走。",
    ].pick_random()

func get_battle_chat_attack()-> String:
    return[
        "就那里，给我咬穿它。",
        "锁定目标，别放走一个。",
        "出手吧，别让我失望。",
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    return[
        "如此羸弱啊，杂口。",
        "诅咒不光是坏处，但我宁愿没有就是了。",
        "我大概明天就会把你忘掉吧。",
        "就这样？",
    ].pick_random()


func get_battle_chat_injured()-> String:
    var _n: String = SoldierUtils.get_player_nickname()
    return[
        "区区致命伤，早习惯了。",
        "你只能做到这种地步了！",
        _n + "小心点！",
        "难以置信……",
    ].pick_random()

func get_battle_chat_die()-> String:
    var _n: String = SoldierUtils.get_player_nickname()
    return[
        "诅咒还是没有放过我……",
        "咳……只是睡一会，别输了……",
        _n + "我……",
        "我还是太有限了吗……",
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "赢了就是赢了，别高兴得太早。",
        "哼，勉强算是没给本小姐丢脸。",
        "收拾干净，下一场我们照样赢。",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "来了，都给我守住！",
        "本小姐还没出手呢，怕什么。",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去，别给他们喘气的机会。",
        "一步一步来，稳着推进。",
    ].pick_random()

func get_battle_chat_ai_enemy_charge_chat()-> String:
    return[
        "全军冲锋，别让他们跑了！",
        "挡我者，死。",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住阵线，谁也别退。",
        "稳住，等他们露出破绽。",
    ].pick_random()






func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        ["老实点，不要耍什么花样。"],
        ["（她即使被俘，也不肯低头。你只好先把她看起来。）"],
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    return[
        ["嘁……栽在你手里，是黑月教会那群废物拖累了我，才不是本小姐打不过你。"],
        ["……别得意。这点伤，本小姐睡一觉就好。"],
    ]

func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        ["（她靠着牢房的墙壁，抬眼瞟了你一眼）……想好要怎么处置我了？"],
        ["快点。本小姐的耐心，比你想的要短。"],
    ]

func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "哼。我自己的钱够赎我自己——[#{0}] 德里，拿去吧，别嫌少。",
        "就用 [#{0}] 德里换我的自由，如何？反正也花不坏你。",
    ]

func get_hero_released_by_ransom_content()-> Array:
    return[
        ["……钱货两清。下次再见面，我照样会跟你打。"],
        ["哼，算你识相。后会有期——别指望我谢你。"],
    ]

func _get_release_hero_equipment_content()-> Array:
    return[
        "用这件 [#{0}]，换我的自由。它比我的命值钱，你别亏了。",
        "拿去吧——[#{0}]，够抵我这条命了。",
    ]

func get_direct_release_confirmation_content()-> Array:
    return[
        ["……等等，你什么都不要，就要放我走？"],
        ["你没听错吧？本小姐可不会跟你客气，确定？"],
    ]

func get_hero_released_freely_content()-> Array:
    return[
        ["……为什么。算了，当我没问。这次，算我欠你一个人情。"],
        ["哼，莫名其妙。……不过，我会记住的。"],
    ]






func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    var _is_high_relation: = _relation_gain_after_battle_factor > 0.5
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "content": [{
            "clist": [
                "……你为什么要帮我？哼，多管闲事。下次我自己能解决。",
            ] if not _is_high_relation else[
                "……谢谢你。这句话，本小姐只说一次，你最好记住。",
            ]
        }],
    }






func get_final_dialogue_template()-> Dictionary:
    return {}