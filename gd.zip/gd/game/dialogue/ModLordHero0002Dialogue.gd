extends LordRighteousDialogue

const HERO_UID: = "mod_lord_hero_0002"




func _get_granted_fief_clist()-> Array:
    return[
        "成了! 从今天起 [#{0}] 就归你管了。收税、练兵、修墙, 都听你的——不过搞砸了, 我可是会当面笑话你的哦。",
        "接令! [#{0}] 交到你手上了。好好干, 别让它在我的战报上变成\"失地\"二字。",
    ]




func _get_attendant_meet_content()-> Array:
    return[
        {
            "clist": [
                "您是何人? 吾主未曾照会我等有他人来访, 稍后吾去问询。若您不告而来, 大人又不愿见您, 还请您自行离去。(声望不足, 暂无法面见)",
                "恕吾孤陋寡闻, 未得闻您的名讳。只是吾主已有命令, 未有其令不得擅自放人入帐, 请您知吾之难。(声望不足, 暂无法面见)",
                "拦截我军的这位大人, 您有何事? 若是想要会见吾主, 还请呈上邀请函。若无, 请速速让出道路。(声望不足, 暂无法面见)",
            ]
        }
    ]




func ask_king_for_permission_lines_content()-> Array:
    var _rel_value: int = SoldierUtils.get_player_relation_value_int(HERO_UID)
    var _country_name: String = DialogueCustomUtils.get_b_country_name()
    var _king_name: String = DialogueCustomUtils.get_b_country_king_name()

    if _rel_value <= -30:
        return[
            "这是我今年听过最好笑的笑话, 你费心了……现在, 给我滚。",
        ]
    elif _rel_value <= -10:
        return[
            "如果你是抱着这种打算, 那你找错人了。宣誓效忠得去找我国的君主 [" + _king_name + "]——不过嘛, 我对人家愿不愿意接纳你, 抱怀疑态度。",
        ]
    elif _rel_value <= 10:
        return[
            "我只是斯卡一地的总大将, 接纳与否轮不到我说话。你需要去我国的君主面前宣誓效忠——去大陆上找 [" + _king_name + "] 吧。",
        ]
    elif _rel_value < 30:
        return[
            "哦, 那我们就要成为同伴了是吗? 太棒了! 我给你指条路——去大路上, 见 [" + _king_name + "]。人家愿意接纳你的话, 以后……以后再说吧。",
        ]
    else:
        return[
            "嘿, 我早就想拉你入伙啦! 就凭你的御下手段、武略谋韬、剑道弓法, 一定能被老大相中的—— [" + _king_name + "] 就是咱们的君主。事成之后, 要把好消息带给我哦。",
            "你这样的狠人, 待在 [" + _country_name + "] 绝对屈才不了! 快去见 [" + _king_name + "] 吧, 我在家等你的好消息!",
        ]




func _king_reject_join_low_reputation_dialogue()-> Array:
    return[
        "唔……你的名声还没传到斯卡呢。等你做出点大事, 姐姐和老大自然会看到的。 " + LOW_REPUTATION_TIP,
        "想入伙? 先去攒点声望吧, 我可不想被人说总大将任人唯亲。 " + LOW_REPUTATION_TIP,
    ]


func king_reject_join_rel_bad_dialogue()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        "[" + _player_name + "], 就凭你干下的那些事, 还想加入我们? 省省吧——我可不想哪天夜里被你背刺。",
        "投诚? 哈, 这是我今年听过第二好笑的笑话。滚吧, [" + _player_name + "], 斯卡不欢迎你。",
    ]


func _king_agree_join_low_reputation_dialogue()-> Array:
    return[
        "成了! 老大那边我帮你说话。#{a_leader_name}, 欢迎入伙——以后咱们就是一个阵营的啦!",
    ]


func king_reject_join_recent_leave_country_dialogue()-> Array:
    return[
        ["刚离开老东家就急着找下家? 呵, 连墙头草都比你有点骨气。滚。"],
        ["你刚离开故国, 底细还没查清呢。过些时日再说吧。"],
        ["刚刚脱离一个阵营就来找我? 我需要看到你的诚意。"],
        ["刚跳槽就想进斯卡? 唉……先处处看吧, 时间会证明你的忠诚的。"],
        ["刚离开旧主就来找我……姐姐既然说你可信, 那我就暂且信你。不过丑话说在前头, 别让我失望哦。"],
    ]




func _get_relation_low_gratitude_low_clist()-> Array:
    return[
        "……辛苦了, 下次你就在旁边看着吧。我和我的部下因为要顾着你, 打得有所保留。",
        "……辛苦了, 下次就不用来帮我了。我不希望你……你的部队, 平添不必要的损失。",
    ]


func _get_relation_mid_gratitude_low_clist()-> Array:
    return[
        "你的到来壮大了我军的声势, 然后……嗯, 提振了我军的士气。感谢。",
        "感谢你的帮助, 这份情我就记下了。",
    ]


func _get_relation_high_gratitude_low_clist()-> Array:
    return[
        "嘿, 连你也有失手的时候啊。",
        "怎么今天刀法这么乱? 是在想谁, 还是在看些什么, 迷了眼呀?",
        "哈哈, 杂鱼, 今天你在干什么呀? 我抓只猴子穿上你那套甲, 打的都比你好。",
    ]


func _get_relation_low_gratitude_high_clist()-> Array:
    return[
        "嗯, 厉害。不得不承认, 你虽然人品不咋样, 但武略堪称一流。",
        "人不可貌相啊, 打得漂亮。这次的战利品, 你尽管拿去。",
    ]


func _get_relation_mid_gratitude_high_clist()-> Array:
    return[
        "完美的配合! 下次遇到棘手的敌人, 我会通知你一同作战。",
        "你对军队的指挥和对战术的把握真是令人惊叹, 我学到了很多。谢谢你。",
    ]


func _get_relation_high_gratitude_high_clist()-> Array:
    return[
        "嘿, 这就是我们之间的羁绊呀!",
        "哇啊啊……吓死我了。要不是你来了, 我恐怕要完蛋了。等战争结束, 我请你去斯卡城好好玩一圈!",
    ]


func _get_relation_low_gratitude_mid_clist()-> Array:
    return[
        "……感谢你的帮助。请你尽情搜刮战利品吧, 我先离开了。",
        "没有你, 这场战斗会棘手很多, 谢谢你。不过别想太多, 我们之间的账, 可没有一笔勾销。",
    ]


func _get_relation_mid_gratitude_mid_clist()-> Array:
    return[
        "谢谢你, 希望下次也能和你并肩作战。",
        "对不起, 给你添麻烦了。感谢你的帮助。",
    ]


func _get_relation_high_gratitude_mid_clist()-> Array:
    return[
        "哇, 你那一招真的很帅啊, 咋做到的? 有空能不能教教我? 我付学费!",
        "你我二人齐上, 焉有一合之敌? 嘻嘻, 战利品你想要什么随便挑, 我只拿点边角料。",
        "哈哈哈, 你刚刚不小心被箭矢绊倒的样子, 我可牢牢记在心里了呢。想要让我忘掉? 那就求我呀, 杂鱼君~",
    ]




func _get_battle_thank_first_meet_clist()-> Array:
    return[
        "初次并肩作战! 我是 [#{0}] 的总大将 - [#{b_leader_name}]。记好这个名字哦, 以后会经常听到的!",
    ]




func _get_player_choose_attack_attendant_confirm_clist()-> Array:
    return[
        "你想清楚了吗? 江大人看着随和, 可那是斯卡城的总大将。对这面旗帜拔刀, 你的名字明天就会出现在艾德拉斯的通缉令上。",
    ]


func _get_player_choose_attack_attendant_confirm_player_confirm_clist()-> Array:
    return[
        "我就是要会一会传说中的总大将。让开——否则连你一起砍!",
    ]


func _get_player_choose_attack_attendant_confirm_player_cancel_clist()-> Array:
    return[
        "算了……跟侍卫过不去算什么本事。我这就走。",
    ]




func get_player_attack_lord_need_confirm_word_when_player_is_ronin()-> Array:
    return[
        ["哈, 不出我所料! 全军列阵!"],
        ["狗急跳墙了? 早料到了! 拔刀!"],
        [
            "什么? 你竟然是为了这种事情……你要知道, 在这个乱世, 和一个国家为敌意味着什么。",
            "原来如此……我欢迎旅人来到斯卡, 也欢迎敌人来到斯卡。唯一的区别在于: 前者能欣赏风景, 品味美酒; 后者……只能身处黄泉。",
        ],
        [
            "哈啊? 你心乱了吧, 突然说这些……喂喂, 私下切磋和宣战是两码事啊, 两码事。",
            "哈哈哈哈哈哈……咳咳咳……呃, 不好笑吗?",
        ],
        [
            "噗——咳咳咳咳咳……哈啊? 等一下, 等一下, 让我缓缓……你再说一遍?",
            "过得好好的, 怎么突然有这种想法? 呃……是我之前说了什么对不起你的话吗? 抱歉哈, 能不生气了嘛……",
        ],
    ]


func get_player_attack_lord_need_confirm_word_when_player_is_lord()-> Array:
    return[
        ["我早就料到了。只要你敢说进攻, 我的手下会立刻把消息传到大陆, 传到斯卡, 向全世界的人宣传你的愚蠢和疯狂。"],
        [
            "我要警告你, 私下对别的国家的成员用兵, 可是会挑起两国之间的战争的。",
            "你打算挑起两国之间的战争吗? 你会成为历史的罪人!",
        ],
        ["原来你的意图是这个……斯卡不只有歌舞与酒食, 还有披坚执锐的武士! 要战便战!"],
        [
            "什么? 你别逗我笑, 啊呸呸呸……这可不能当玩笑啊。",
            "你别一本正经地说这种话, 吓不到人的。何况, 是我。",
        ],
        [
            "哈啊? 你就这么想打我吗? 那来呀, 来呀, 宣战啊, 我赌你不敢……你, 你不会是认真的吧?",
            "啊? 哎, 你小声点告诉我——是你的家人被威胁了吗? 还是你的主公逼你干的? 遇到事情了, 我来帮你!",
        ],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_ronin()-> Array:
    return[
        ["既然如此, 不要奢求痛快的死亡。"],
        ["我会取下你的首级!"],
        ["那么, 就拔出你的刀吧!"],
        ["混蛋! 我今天要抓住你, 狠狠回敬!"],
        ["……拔刀吧。就在今天, 做个了结。"],
    ]


func _get_player_attack_lord_reply_word_country_neutral_player_lord()-> Array:
    return[
        ["赌上你的一切吧!"],
        ["战争没有赢家, 但战斗有!"],
        ["既然你渴望鲜血和战利品, 那我就要夺走你渴望的一切。"],
        ["……好吧。为表尊重, 死战不休!"],
        ["你个混蛋……我不会原谅你的, 永远都不会! 全军列阵!"],
    ]


func _get_player_attack_lord_reply_word_country_hostile()-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    return[
        ["冲过去!"],
        ["武士们! 拥抱战斗的荣耀!"],
        ["取一幡旗者, 重重有赏!"],
        [
            "我将用最庄重的仪式, 埋葬你的首级。",
            "从今往后, 你的头, 就是我的东西了……我会一刻不停地尝试取走它, 直到和平再临!",
        ],
        ["……那么, 直到刀断矢尽, [" + _player_name + "]。"],
    ]


func get_player_cancel_attack_lord_word_when_player_is_ronin()-> Array:
    return[
        ["算了。跟你这种疯子动手, 脏了我的刀。"],
        ["哼, 今天就当我没说过。下次别让我逮到机会。"],
        ["……罢了。为了一座岛把命搭上, 不值当。"],
        ["你说得对, 私下切磋和宣战是两码事。刚才是我越界了。"],
        ["好了好了, 逗你的! 真要打你, 我也得先写好遗书啊。"],
    ]


func get_player_cancel_attack_lord_word_when_player_is_lord()-> Array:
    return[
        ["……当我没说。就算要动你, 也轮不到今天。"],
        ["两国开战不是儿戏, 容我再想想。"],
        ["我的一时兴起, 差点让我成为历史的罪人。收队。"],
        ["好吧, 被你看穿了……我只是想试试你的反应。"],
        ["逗你的! 我哪舍得对总大将动手——我还等着你请我喝金酒呢。"],
    ]





func lord_meet_player_content_lord_proactive_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["哦, 我貌似认识你——你是那个臭名昭著的 [" + _player_name + "], 有名的恶党。跪地伏诛吧。"],
            [
                "欸, 你长得有点眼熟啊……哦, 是鼎鼎大名的 [" + _player_name + "]。恶党名单上第一个就是你的名字。受死吧!",
                "我认识你! 恶党! 在这里晃悠是想干什么? 不管了, 直接开打吧!",
            ],
            ["恶党 [" + _player_name + "]! 为了保护斯卡的安宁, 我要讨伐你! 拔刀吧!"],
            ["欸, 你就是那个颇有名气的 [" + _player_name + "]? 你怎么能是个恶党呢……我听说过你的事迹, 但鉴于你的身份, 我还是得逮捕你啊。"],
            ["欸, [" + _player_name + "]? 明明听说过你不少义举, 怎么偏偏成了恶党……唉, 职责所在。乖乖束手就擒吧, 我保证给你上好的牢饭。"],
        ]
    else:
        return[
            [
                "呵呵, 这次你可没有上次那么好运了。受死!",
                "嘿嘿嘿, 看我逮到了什么。我要拿你的尸体来试试我的刀。",
            ],
            [
                "还在此处徘徊? 受死!",
                "真奇怪, 你这家伙一直在这里转悠, 是不怕死吗? 不管那么多了, 今天我一定要取下你的首级!",
            ],
            [
                "[" + _player_name + "]! 今天你逃不掉了!",
                "你怎么这么能跑啊? 但还是被我追上了吧! 脖子洗好了没?",
            ],
            [
                "这次你逃不掉了, 乖乖跟我回去吧!",
                "呦, 这不是杂鱼君吗, 几天不见怎么这么狼狈了? 要不要陪本将回斯卡啊? 戴着镣铐的那种哦~",
            ],
            [
                "哇, 这不是杂鱼君吗? 看来为了当我的部下, 你故意向我露出了毫无防备的后军呀。那我可要好好满足满足你了~",
                "好久不见啊! 哎呀, 怎么就带了这么点人啊? 没事没事, 我不嫌弃你人少, 有你就行喽。抓活的!",
            ],
        ]



func lord_meet_player_content_lord_proactive_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["嗯? 你可是声名远扬呢……啊不, 应该说是臭名昭著。我和你没什么可说的。全军警戒, 列阵, 准备接敌!"],
            ["你是 [" + _player_name + "] 吧? 真可怜, 大陆的盟友怎么让你来到了这里呢。我叫江, 斯卡的总大将——在我的面前, 不要奢求体面的死亡。"],
            ["你就是 [" + _player_name + "] 大人? 真是如雷贯耳。我就是本地的大将。你出现在这里, 是为了交战吧?"],
            ["哦? 你是 [" + _player_name + "] 吧? 嘿呀, 真是百闻不如一见啊! 初次见面, 我是江, 本地的总大将。早就听闻你的事迹啦, 真想痛痛快快地跟你战上一场……不如, 现在就拔刀吧!"],
            ["哦哦, 是 [" + _player_name + "] 吧! 久仰久仰! 我是江, 斯卡总大将。唉, 可惜你我各为其主……来吧, 让我见识见识大陆第一流的本事!"],
        ]
    else:
        return[
            ["别想走! 这次, 我会杀死你!"],
            ["趁你病要你命喽, 受死吧!"],
            ["作为入侵者, 想必你也做好被反击的准备了吧?"],
            ["呵呵, 瞧瞧我抓到了谁? 我就是喜欢你现在这副想跑又跑不掉的样子~"],
            [
                "嘻嘻, 这次抓到你, 你可不能像上次一样就跑了呀——满足我吧! 哈哈哈哈哈~",
                "杂鱼~ 这次怎么只带了这么点人啊? 看来你很想被我抓回去好好调教呢。虽然有点不讲武德, 但为了你, 豁出去了!",
            ],
        ]



func lord_meet_player_content_player_proactive_hostile_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["哦, 我貌似认识你——你是那个臭名昭著的 [" + _player_name + "], 有名的恶党。跪地伏诛吧。"],
            [
                "欸, 你长得有点眼熟啊……哦, 是鼎鼎大名的 [" + _player_name + "]。恶党名单上第一个就是你的名字。受死吧!",
                "我认识你! 恶党! 在这里晃悠是想干什么? 不管了, 直接开打吧!",
            ],
            ["恶党 [" + _player_name + "]! 为了保护斯卡的安宁, 我要讨伐你! 拔刀吧!"],
            ["欸, 你就是那个颇有名气的 [" + _player_name + "]? 你怎么能是个恶党呢……我听说过你的事迹, 但鉴于你的身份, 我还是得逮捕你啊。"],
            ["[" + _player_name + "]……唉, 明明听说过你不少义举, 怎么偏偏站在了敌国那边。职责所在, 拔刀吧!"],
        ]
    else:
        return[
            ["呵呵, 这次你可没有上次那么好运了。受死!"],
            ["还在此处徘徊? 受死!"],
            ["[" + _player_name + "]! 今天你逃不掉了!"],
            ["呦, 这不是杂鱼君吗, 几天不见怎么这么狼狈了? 要不要陪本将回斯卡啊? 戴着镣铐的那种哦~"],
            ["哇, 这不是杂鱼君吗? 看来为了当我的部下, 你故意向我露出了毫无防备的后军呀。那我可要好好满足满足你了~"],
        ]



func lord_meet_player_content_player_proactive_hostile_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["嗯? 你可是声名远扬呢……啊不, 应该说是臭名昭著。我和你没什么可说的。全军警戒, 列阵, 准备接敌!"],
            ["你是 [" + _player_name + "] 吧? 真可怜, 大陆的盟友怎么让你来到了这里呢。我叫江, 斯卡的总大将——在我的面前, 不要奢求体面的死亡。"],
            ["你就是 [" + _player_name + "] 大人? 真是如雷贯耳。我就是本地的大将。你出现在这里, 是为了交战吧?"],
            ["哦? 你是 [" + _player_name + "] 吧? 嘿呀, 真是百闻不如一见啊! 初次见面, 我是江, 本地的总大将。早就听闻你的事迹啦, 真想痛痛快快地跟你战上一场……不如, 现在就拔刀吧!"],
            ["哦哦, 是 [" + _player_name + "] 吧! 久仰久仰! 我是江, 斯卡总大将。唉, 可惜你我各为其主……来吧, 让我见识见识大陆第一流的本事!"],
        ]
    else:
        return[
            ["说真的, 只是远远看见你那面军旗, 看见上面的家徽, 我的心情就很糟糕。为了弥补我, 是不是得把你的首级献上啊?"],
            ["哎哟, 这是哪来的杂鱼啊? 让我看看你的军队, 是不是像你那样羸弱不堪啊? 拔刀吧!"],
            ["是你! 我已经针对你的军队研究出了一套战阵——今天就让我们来实验一下吧!"],
            ["嘿呀, 我还以为你是自己人呢, 远远看上去家徽挺熟悉的……事已至此, 那就拔刀来战吧。"],
            ["又见面啦, [" + _player_name + "]! 城里的歌舞伎都在唱你的故事呢——可惜今天得兵戎相见。拔刀吧, 让我看看歌舞伎有没有夸张!"],
        ]



func lord_meet_player_content_player_proactive_neutral_player_is_ronin(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["哦, 你就是 [" + _player_name + "]? 快点闪开吧——你的名字传到我耳中的时候, 可不是什么仁人义士呢。"],
            ["你就是 [" + _player_name + "]? 嗯, 虽然是第一次见面, 但总觉得你有点行迹可疑啊……拦下我的部队, 是作何打算?"],
            ["你是 [" + _player_name + "]? 哦, 欢迎来到这里。我正在行军, 无事请勿打扰。"],
            ["哦? 我认识你, 你就是 [" + _player_name + "] 吧? 久仰久仰! 请问你找我何事? 若在职责之内, 定会鼎力相助。"],
            ["哦? 我认识你, 你就是 [" + _player_name + "] 吧? 久仰久仰! 找我何事? 若在职责之内, 定会鼎力相助——姐姐也常提起你呢。"],
        ]
    else:
        return[
            ["喂喂喂, [" + _player_name + "], 你这家伙怎么还在这儿啊? 我告诉你啊, 要是这周围出了什么事, 我绝对会抓住你, 然后严刑拷打一番啊。"],
            ["啧, 到底有什么事你就说啊, 在这边乱晃悠……我会派人盯紧你的。"],
            ["嗯, 是你呀。"],
            ["哇, 你还在这里呀, 真是惊喜! 要不要来我帐里, 喝一杯大陆进口的金酒?"],
            [
                "又见面啦, [" + _player_name + "]。城里的歌舞伎都在唱你的故事呢! 改日要不要一起去看看?",
                "[" + _player_name + "]! 是我呀, 不认得我了嘛? 嘿嘿, 我可是经常和姐姐提起你呢。最近又去干什么了?",
            ],
        ]



func lord_meet_player_content_player_proactive_neutral_player_is_lord(_is_first_meet: bool)-> Array:
    var _player_name: = SoldierUtils.get_player_nickname()

    if _is_first_meet:
        return[
            ["唔……初次见面, 欢迎欢迎……可以让开吗? 你挡住我部队的行军路了。"],
            ["哦, 我听姐姐说过, 你就是老大新任命的城代是吧。呃, 你有什么需要吗?"],
            ["你好, 我是江, 斯卡城城代任命的总大将。本地的军事事务由我负责, 你有这方面的事项可以找我。"],
            ["大人您好, 在下是江, 斯卡城城代任命的总大将。本地的军事事务由我负责, 有什么职责内的要求, 您但说无妨, 尽管吩咐在下便是。"],
            ["哇啊……大人您好! 在下是江, 斯卡城城代任命的总大将。在下久仰您的大名, 今日得见, 果真不同凡响! 您有什么需求? 尽管吩咐在下, 在下会尽力满足您!"],
        ]
    else:
        return[
            ["又是你……好吧好吧, 有什么事? 说完我好赶路。"],
            ["哦, 是 [" + _player_name + "] 大人。找我有何贵干?"],
            ["[" + _player_name + "] 大人, 军务方面的事情, 尽管开口。"],
            ["大人又来啦! 正巧, 我刚温了一壶大陆来的金酒——不耽误正事的话, 先喝一杯?"],
            ["[" + _player_name + "] 大人! 快快请坐! 您一来, 我这营帐都亮堂了三分。有什么吩咐, 尽管说!"],
        ]




func _get_country_name()-> String:
    return CountryUtils.get_country_name_by_hero_uid(HERO_UID)




func get_battle_chat_charge()-> String:
    var _country_name: String = _get_country_name()

    return[
        "全军突击! 让他们见识斯卡的刀!",
        "跟上我! 落后的人今晚没酒喝!",
        "冲啊! 战利品按功劳分!",
        "别磨蹭! 刀都给我拔出来!",
        "斯卡总大将在此! 挡路者, 死!",
        "为了" + _country_name + "的荣耀! 冲锋!",
        "让开让开! 本将要先冲啦!",
        "一口气凿穿他们!",
    ].pick_random()


func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "就这? 下一个!",
        "太弱了, 热身都算不上!",
        "记住这一刀——它叫散华!",
        "回去多练几年再来吧!",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + ", 承让啦!",
            "抱歉了, " + _target_hero_name + ", 战场没有如果!",
            _target_hero_name + "也不过如此嘛~",
        ])

    return _list.pick_random()


func get_battle_chat_injured()-> String:
    return[
        "小伤而已! 别小看我!",
        "嘶……疼疼疼……我没事!",
        "这点伤, 包扎一下继续打!",
        "哼, 居然砍中我了……",
        "站好! 谁都不许乱!",
    ].pick_random()


func get_battle_chat_die()-> String:
    return[
        "姐姐……对不起……",
        "斯卡的海……真蓝啊……",
        "刀……还没……出鞘完……",
        "下次……我绝不会输……",
        "杂鱼……怎么可能……",
    ].pick_random()


func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "兄弟们挺住! 我来了!",
    ].pick_random()


func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "保持阵型! 别乱!",
        "稳住! 跟着军旗走!",
        "别贪功冒进! 听我号令!",
        "稳扎稳打! 谁乱动军法处置!",
    ].pick_random()


func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住阵线!",
        "稳住! 等他们露出破绽!",
        "都别慌! 弓箭手准备!",
        "收缩防御! 长枪架起来!",
    ].pick_random()


func get_battle_chat_vectory()-> String:
    return[
        "赢啦! 今晚加菜!",
        "打扫战场! 战利品记得分我一份!",
        "这就是和斯卡作对的下场!",
        "痛快! 各位, 干得漂亮!",
        "收兵回城! 姐姐还等着我的战报呢!",
        "哈哈, 谁还说总大将只会喝酒?",
    ].pick_random()




func get_leave_country_king_confirm_response_content()-> Array:
    var _player_name: = SoldierUtils.get_player_name()

    return[
        ["你要退出? [" + _player_name + "], 背叛的滋味尝一次就会上瘾的。你确定?"],
        ["退出艾德拉斯? 呵, 我早看出你留不住。滚吧——但别让我在战场上碰见你。"],
        ["你要走? 旗子放下, 武器带走。战场再见时, 我不会留情。"],
        ["[" + _player_name + "], 真的要走? ……唉, 强扭的瓜不甜。你走吧。"],
        ["你要离开我们? 呜……好吧, 姐姐会伤心的! 你, 你以后常回来看看啊!"],
    ]


func get_leave_country_king_response_content()-> Array:
    var _player_name: = SoldierUtils.get_player_name()

    return[
        ["滚吧, 叛徒。从今往后, 你的名字只配出现在通缉令上。"],
        ["走好, 不送。下次相见, 便是敌人。"],
        ["人各有志。艾德拉斯的大门, 从此对你关闭。"],
        ["[" + _player_name + "], 愿你前路顺利。战场相逢, 各凭本事。"],
        ["呜……你这个没良心的! 姐姐问起来, 我就说你去大陆买酒了! 走吧走吧!"],
    ]


func get_leave_country_cancel_king_response_content()-> Array:
    return[
        ["哈, 我就知道你在试探。收回你的话, 我们就当无事发生。"],
        ["想清楚了? 很好, 我就欣赏你这种反复无常……啊不, 从善如流。"],
        ["收回成命是明智的。归队吧。"],
        ["呼……吓我一跳。好好好, 还是自己人。"],
        ["哎呀, 你可吓死我了! 来来来, 刚才的事一笔勾销, 喝酒喝酒!"],
    ]





func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        ["总算把你逼到这一步了, 江。放下刀, 还有什么遗言?"],
        ["江, 你输了。现在, 把你知道的都给交代出来。"],
        ["战斗结束了, 总大将。放下武器吧, 别逼我动手。"],
        ["承让了, 江。你伤得不轻, 我不会再为难你。"],
        ["打得痛快。放心, 我不会杀你——好好养伤吧。"],
    ]



func get_captured_dialogue_after_battle_content()-> Array:
    return[
        ["咕……杀了我……别浪费彼此的时间。"],
        ["休想从我嘴里撬出半个字!"],
        ["败, 就是败。动手吧。"],
        ["完蛋了……这回真的完蛋了……"],
        [
            "咕……我们谈谈条件吧?",
            "喂, 你刚才那招居合……教教我呗?",
        ],
    ]



func get_hero_wait_for_release_dialogue_content()-> Array:
    return[
        ["我什么也不会说。不如, 就杀了我吧。"],
        ["来, 我脖子在这里, 照着砍。"],
        ["额……士可杀, 不可辱!"],
        [
            "呜呜呜……这里的饭菜好难吃……呸, 真恶心。我果然还是不适合卖惨。",
            "你到底是要劫财, 还是劫些别的什么呀? 什么时候放了我。",
        ],
        [
            "最近我在思考一个问题: 人生的意义到底是什么……哎呀, 这里好无聊啊。",
            "你赶快放了我吧! 我姐要是生气了, 会写信骂你的——什么叫你觉得她骂人很好听啊, 喂?",
        ],
    ]



func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "这颗首级的价值, 大概是 [#{0}] 德里——喂, 你问这个干什么?",
        "……我又让我姐破费了。[#{0}] 德里, 行了吧。",
    ]



func get_hero_released_by_ransom_content()-> Array:
    return[
        ["虽然我很讨厌你……但是, 谢谢你! 来日方长, 后会有期!"],
        ["谢谢。等到下次再见, 我可比现在更强——鹿死谁手, 尚未得知。"],
        ["谢谢, 再见。下一次, 我绝对不会像这样狼狈。"],
        ["……那个, 谢了啊。不过下一次, 你可赚不到这么一大笔钱了。"],
        ["原来只是劫财吗……有点失落呢。"],
    ]


func get_hero_released_content()-> Array:
    return[
        ["钱货两讫。滚了——最好别再让我碰见你。"],
        ["行吧, 算你讲信用。下次战场上见真章。"],
        ["承你的情。下次对上, 我会堂堂正正赢回来。"],
        ["谢啦! 这笔钱就当我借的——回头连本带利还你一场大胜!"],
        ["唉, 钱没了可以再赚, 朋友没了可就真没了……下次金酒我请!"],
    ]



func get_direct_release_confirmation_content()-> Array:
    return[
        [
            "什么?",
            "哈啊? 你又在盘算些什么阴谋诡计?",
        ],
        ["你是不是私下里和我姐姐谈了些什么? 回答我!"],
        ["哦? 你确定要这么做?"],
        ["哎, 难道我遇到大善人了?"],
        ["嘿嘿, 我再确认一下——你是要放我走吧?"],
    ]



func get_hero_released_freely_content()-> Array:
    var _player_name: = SoldierUtils.get_player_name()

    return[
        ["哼, 等着吧。对敌人的最大尊重, 就是不遗余力——下次, 我会好好\"尊重尊重\"你的。"],
        ["这次释放不会改变我对你的态度。但这份人情, 我记下了。下次对峙的时候, 我不会让弓箭手对着你的脑袋射。"],
        ["嗯……没想到在异国他乡, 还能见到正道武士。下次再见, 我会多加留意你的。"],
        [
            "混蛋, 弄得我都有点感动了。什么时候我们可以不再相互拔刀了, 我请你喝酒! 进口的哟!",
            "谢了, [" + _player_name + "]。回头两军相遇, 我装看不见你……额, 前提是你不是去打劫。",
        ],
        [
            "哎, 总有一天, 我会让你叫我\"主公\"的。给我等好了!",
            "你这样让我很难收场啊。这样吧, 等战争结束, 我去你的府邸好好道个谢——怎么样啊, 杂鱼~",
        ],
    ]



func _get_release_hero_equipment_content()-> Array:
    return[
        "这样吧, 我把这件 [#{0}] 交给你, 用来换我的脑袋。如何?",
        "现金不够? 那……这件 [#{0}] 抵账! 我可亏大了啊!",
    ]




func _get_mult_meet_clist_rel_bad()-> Array:
    return[
        "还要我说几遍?",
        "还想干嘛?",
    ]


func _get_mult_meet_clist_rel_normal()-> Array:
    return[
        "又有何事?",
    ]


func _get_mult_meet_clist_rel_good()-> Array:
    return[
        "这么快就遇到事了?",
        "好巧, 又见面了!",
    ]