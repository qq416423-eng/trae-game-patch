extends BaseDialogue

const HERO_UID: = "mod_quartermaster"


static func _T_GREETING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（军需人员正在清点物资，手里拿着一本厚厚的账册。看到你走近，他合上册子行了个礼）"]}],
        "next": _T_GREETING_2(),
    }


static func _T_GREETING_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["大人！您的私卫们装备还缺不少。我这里可以帮您把背包里的装备分发给随行的私卫，您要看一看吗？"]}],
        "next": _T_OPTIONS(),
    }


static func _T_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "分发装备",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["好，我来挑几件装备分发下去。"]}],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "交谈",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["私卫们的装备情况如何？"]}],
                "next": _T_TALK_RESPONSE(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "告辞",
                "content": [{"clist": ["暂时不需要，回头再说。"]}],
            }
        ]
    }


static func _T_TALK_RESPONSE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["私卫们都是精挑细选的好苗子，但目前装备匮乏，不少人还空着手呢。"]}],
        "next": _T_TALK_RESPONSE_2(),
    }


static func _T_TALK_RESPONSE_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["只要您从背包里选几件装备交给我，我立刻分发给随行的私卫们。装备不够的话，就按先到先得的原则分。"]}],
        "next": _T_OPTIONS(),
    }


func get_current_dialogue_template()-> Dictionary:
    return _T_GREETING()


func get_hero_uid()-> String:
    return HERO_UID