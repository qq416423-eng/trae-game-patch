extends BaseDialogue

const HERO_UID: = "mod_slave_duel_host"


func get_current_dialogue_template()-> Dictionary:
    return _T_GREETING()


func get_hero_uid()-> String:
    return HERO_UID



static func _display_width(_s: String)-> int:
    var _w: int = 0
    for _ch: String in _s:
        _w += 2 if _ch.unicode_at(0) > 11903 else 1
    return _w



static func _fit_option_name(_name: String, _max_w: int = 20)-> String:
    var _out: String = ""
    var _w: int = 0
    for _ch: String in _name:
        var _cw: int = 2 if _ch.unicode_at(0) > 11903 else 1
        if _w + _cw > _max_w:
            return _out + "…"
        _out += _ch
        _w += _cw
    return _out





static func _T_GREETING()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（血沙看台的旗帜在风中猎猎作响, 斗奴主薇拉用皮鞭敲了敲掌心）哟, 生面孔。这里的奴隶比城里的骡马便宜, 命也一样——想试试手气吗?",
            "（斗奴主薇拉上下打量了你一眼）新来的? 血沙看台欢迎你。袋里有金子, 这里的沙子就为你红。",
        ]}],
        "next": _T_GREETING_2(),
    }



static func _T_GREETING_2()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{
            "str_from_func": [{"func_name": "duel_host_get_status_str"}],
            "clist": ["（薇拉朝场子扬了扬下巴）#{0}"],
        }],
        "next": _T_MAIN_OPTIONS(true),
    }



static func _T_MAIN_OPTIONS(_include_info: bool)-> Dictionary:
    var _option_list: Array = [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "看台押注(观战)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["我在看台上押点钱。"]}],
            "next": _T_BET_ENTRY(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "派俘虏出战(随行俘虏)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["让我随行的俘虏下场打。"]}],
            "next": _T_CHAMPION_ENTRY(),
        },
    ]
    if _include_info:
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "这是什么地方?",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["这里是什么地方?"]}],
            "next": _T_RULES_1(),
        })
        _option_list.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "闲聊",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["跟你打听点事。"]}],
            "next": _T_CHAT(),
        })
    _option_list.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "离开",
        "content": [{"clist": ["告辞了。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _option_list,
    }



static func _T_RULES_1()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "血沙看台, 方圆百里最公道的斗奴场。两队奴隶放进场子死磕, 哪边站到最后哪边赢。丑话说前头: 场子七天只开七场——押注算一场, 派俘出战也算一场, 打满了就得等最早那场滚出七天的头。",
        ]}],
        "next": _T_RULES_2(),
    }


static func _T_RULES_2()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "想稳当, 坐看台押注: 最低100金。场子出两队, 赛前把人数、兵种构成、领队、胜率、赔率全亮给你——战力数字是场子的底牌, 不外传。",
        ]}],
        "next": _T_RULES_3(),
    }


static func _T_RULES_3()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "赔率按真斤两算的, 1到4倍, 下注那刻锁定。押中连本带利拿回; 押错, 本金归场子。热门稳当赔得少, 冷门险赔得多——全看眼力。",
        ]}],
        "next": _T_RULES_4(),
    }


static func _T_RULES_4()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "想挣大的, 派你的俘虏下场: 三到二十五人, 规模你定。报名费按场次收, 同一场里带多少人都是一个价, 开打才收。",
        ]}],
        "next": _T_RULES_5(),
    }


static func _T_RULES_5()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{
            "clist": [
                "名单你点: 精锐尽出、老兵王牌、最强仨带随机、听场子随机, 或按兵种筛一批, 俘虏再多也点得过来。对手你挑, 四档强度, 越险赏钱越肥。",
                "对面下场的也不全是山里的野路子——各国打了败仗的正规军, 场子照样从战俘营收来充数。运气好能碰上沙鲁克的骆驼卫队、马尔克的红鹰射手、赛娜的王国骑队, 乃至北境的海寇狂战士。场子还兴把几国的战俘混编一队: 骆驼卫挨着飓风骑, 狂战士混着教廷兵——名号越杂, 越是硬茬子。",
            ],
        }],
        "next": _T_RULES_6(),
    }


static func _T_RULES_6()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "连胜有说法: 每连胜一场, 赢的那份钱多8%, 最多多四成; 三连胜另赏报名费一成, 五连胜两成, 十连胜五成, 二十连胜直接翻倍, 还封「传奇角斗士」的名号。输了连胜清零, 赏钱从头攒。",
        ]}],
        "next": _T_RULES_7(),
    }


static func _T_RULES_7()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "赢过场的老俘虏算卖座王牌, 赢的那份钱还要加成; 输一场连胜清零, 但下一场报名费半价。丑话说前头: 下场都是表演赛, 开笼之后生死由他们自己打——你只能站在看台上看着, 喊破喉咙也没用。赛完俘虏照旧归你。就这些, 玩吗?",
        ]}],
        "next": _T_MAIN_OPTIONS(false),
    }




static func _T_CHAT()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（薇拉眯起眼）打听消息可以, 但打听官府就免了。这看台能在阿尔塔利斯城外立着, 靠的不是运气。",
        ]}],
        "next": _T_CHAT_2(),
    }


static func _T_CHAT_2()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "城里的老爷们白天喊着取缔, 晚上戴斗篷来下注。世界就是这样, 朋友。",
        ]}],
        "next": _T_MAIN_OPTIONS(false),
    }





static func _T_BET_ENTRY()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [
            {
                "custom_choose_func": {"func_name": "duel_host_has_pending_duel"},
                "str_from_func": [{"func_name": "duel_host_get_pending_str"}],
                "clist": ["（薇拉朝场子扬了扬下巴）#{0}"],
                "next": _T_RESUME_OPTIONS(),
            },
            {

                "custom_choose_func": {"func_name": "duel_host_match_limit_reached"},
                "str_from_func": [{"func_name": "duel_host_get_match_limit_str"}],
                "clist": ["#{0}"],
            },
            {
                "custom_choose_func": {"func_name": "duel_host_can_afford"},
                "str_from_func": [{"func_name": "duel_host_get_roster_str"}],
                "clist": ["（薇拉把场单拍在你面前）#{0}押哪边?"],
                "next": _T_FIGHTER_OPTIONS(),
            },
            {
                "clist": [
                    "（薇拉瞥了一眼你的钱袋）最低注100金。没钱的话, 看台边的位置免费, 站着看吧。",
                ],
            },
        ],
    }




static func _T_FIGHTER_OPTIONS()-> Dictionary:
    var _options: Array = []
    var _fighters: Array = DialogueCustomUtils.duel_host_get_fighters()
    for i in _fighters.size():
        var _fighter: Dictionary = _fighters[i]
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _fit_option_name("押 " + DialogueCustomUtils.duel_host_get_fighter_option_str(i)),
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["我押%s。" % str(_fighter.get("name", "奴隶"))]}],
            "next": _T_AMOUNT_OPTIONS(i),
        })

    if _options.is_empty():
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "今日无赛",
            "content": [{"clist": ["（今天的场次似乎还没准备好, 改天再来）"]}],
        })
    else:
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "算了",
            "content": [{"clist": ["我再想想。"]}],
        })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _options,
    }




static func _T_AMOUNT_OPTIONS(_fighter_index: int)-> Dictionary:
    var _fighter_name: String = DialogueCustomUtils.duel_host_get_fighter_name(_fighter_index)
    var _odds: float = DialogueCustomUtils.duel_host_get_fighter_odds(_fighter_index)
    var _options: Array = []
    var _amount_list: Array = DialogueCustomUtils.DUEL_HOST_BET_AMOUNT_LIST
    for _amount: int in _amount_list:
        if not DialogueCustomUtils.duel_host_can_afford_amount(_amount):
            continue
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "押%d金(赢回%d)" % [_amount, int(float(_amount) * _odds)],
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{
                "clist": ["%s, 我押%d金。" % [_fighter_name, _amount]],
                "custom_func": {
                    "func_name": "duel_host_confirm_bet",
                    "params": [_fighter_index, _amount],
                },
            }],
            "next": _T_BATTLE_GO(),
        })

    if _options.is_empty():
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "钱不够",
            "content": [{"clist": ["（钱袋空空, 还是先去挣点钱吧）"]}],
        })
    else:
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "算了",
            "content": [{"clist": ["我改主意了。"]}],
        })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _options,
    }





static func _T_CHAMPION_ENTRY()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [
            {
                "custom_choose_func": {"func_name": "duel_host_has_pending_duel"},
                "str_from_func": [{"func_name": "duel_host_get_pending_str"}],
                "clist": ["（薇拉朝场子扬了扬下巴）#{0}"],
                "next": _T_RESUME_OPTIONS(),
            },
            {

                "custom_choose_func": {"func_name": "duel_host_match_limit_reached"},
                "str_from_func": [{"func_name": "duel_host_get_match_limit_str"}],
                "clist": ["#{0}"],
            },
            {
                "custom_choose_func": {"func_name": "duel_host_any_count_ok"},
                "str_from_func": [{"func_name": "duel_host_get_champion_roster_str"}],
                "clist": ["（薇拉打量了一遍你的队伍）#{0}"],
                "next": _T_CHAMPION_ASK(),
            },
            {
                "clist": [
                    "（薇拉摇了摇头）要么你随行的俘虏凑不够三个, 要么你钱袋付不起最低的报名费。先抓点俘虏攒攒钱吧。",
                ],
            },
        ],
    }



static func _T_CHAMPION_ASK()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "几个人上场都行, 名单你点、对手你挑, 报名费开打才收。记住喽: 点完名开笼, 场里就全凭他们自己打了, 你插不上手。先定个规模。",
        ]}],
        "next": _T_BAND_OPTIONS(),
    }




static func _T_BAND_OPTIONS()-> Dictionary:
    var _options: Array = []
    for _band: Dictionary in DialogueCustomUtils.duel_host_get_count_bands():
        var _lo: int = int(_band.get("lo", 3))
        var _hi: int = int(_band.get("hi", 3))
        var _band_fee: int = DialogueCustomUtils.duel_host_get_count_fee(_lo)
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "%s(%d~%d人·%d金)" % [str(_band.get("label", "场次")), _lo, _hi, _band_fee],
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["打%d到%d人的规模, 报名费%d金。" % [_lo, _hi, _band_fee]]}],
            "next": _T_COUNT_OPTIONS(_lo, _hi),
        })

    if _options.is_empty():
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "条件不够",
            "content": [{"clist": ["（奴隶或钱都不够, 改日再来）"]}],
        })
    else:
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "算了",
            "content": [{"clist": ["我再想想。"]}],
        })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _options,
    }



static func _T_COUNT_OPTIONS(_lo: int, _hi: int)-> Dictionary:
    var _options: Array = []
    for _count: int in range(_lo, _hi + 1):
        if not DialogueCustomUtils.duel_host_count_ok(_count):
            continue
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "%d人" % _count,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{
                "clist": ["%d人, 就这个。" % _count],
                "custom_func": {
                    "func_name": "duel_host_select_count",
                    "params": [_count],
                },
            }],
            "next": _T_ROSTER_OPTIONS(),
        })

    if _options.is_empty():
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "条件不够",
            "content": [{"clist": ["（奴隶或钱都不够, 改日再来）"]}],
        })
    else:
        _options.append({
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "算了",
            "content": [{"clist": ["我再想想。"]}],
        })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _options,
    }




static func _T_ROSTER_OPTIONS(_include_filter: bool = true)-> Dictionary:
    var _options: Array = [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "精锐尽出(最硬的)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["挑最硬的汉子, 精锐尽出。"]}],
            "custom_func": {
                "func_name": "duel_host_select_roster",
                "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_ELITE, ""],
            },
            "next": _T_DIFFICULTY_DIALOG(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "老兵王牌(胜场优先)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["让打赢过的老面孔上, 观众就爱看熟脸。"]}],
            "custom_func": {
                "func_name": "duel_host_select_roster",
                "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_VETERAN, ""],
            },
            "next": _T_DIFFICULTY_DIALOG(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "三王牌带随机(最强仨)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["最强的仨打头阵, 剩下的名额听天由命。"]}],
            "custom_func": {
                "func_name": "duel_host_select_roster",
                "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_MIXED, ""],
            },
            "next": _T_DIFFICULTY_DIALOG(),
        },
    ]
    if _include_filter:
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "按兵种筛选",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["名单按兵种来挑——先说挑哪路兵。"]}],
            "next": _T_FACTION_FILTER_OPTIONS(),
        })
    _options.append({
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "听场子随机",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [{"clist": ["随便抽一批吧, 图个乐子。"]}],
        "custom_func": {
            "func_name": "duel_host_select_roster",
            "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_RANDOM, ""],
        },
        "next": _T_DIFFICULTY_DIALOG(),
    })
    _options.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "算了",
        "content": [{"clist": ["我再想想。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（薇拉把沾着沙的花名册推到你面前）名单怎么点: 挑最硬的、上打赢过的老面孔、最强仨带头, 还是按兵种筛?",
        ]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": _options,
        },
    }



static func _T_FACTION_FILTER_OPTIONS()-> Dictionary:
    var _options: Array = [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "全部兵种(混编)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["不限兵种, 什么硬上什么。"]}],
            "custom_func": {
                "func_name": "duel_host_select_filter",
                "params": [""],
            },
            "next": _T_FILL_OPTIONS(),
        },
    ]
    for _faction: Dictionary in DialogueCustomUtils.duel_host_get_faction_filter_options():
        var _faction_name: String = str(_faction.get("name", "士兵"))
        var _opt_name: String = _fit_option_name("%s×%d" % [_faction_name, int(_faction.get("count", 0))])
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": _opt_name,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["兵源只从%s里挑。" % _faction_name]}],
            "custom_func": {
                "func_name": "duel_host_select_filter",
                "params": [str(_faction.get("uid", ""))],
            },
            "next": _T_FILL_OPTIONS(),
        })
    _options.append({
        "otype": OPTION_TYPE_ENUM.TALK,
        "oname": "返回换策略",
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [{"clist": ["还是别筛了, 回头看别的点法。"]}],
        "next": _T_ROSTER_OPTIONS(false),
    })
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（薇拉翻开花名册）挑哪路兵? 筛出来的不够数, 场子自动用别家补齐。",
        ]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": _options,
        },
    }



static func _T_FILL_OPTIONS()-> Dictionary:
    var _options: Array = [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "取最强的N个",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["筛出来的人里, 挑最硬的上。"]}],
            "custom_func": {
                "func_name": "duel_host_select_roster",
                "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_ELITE, ""],
            },
            "next": _T_DIFFICULTY_DIALOG(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "老兵优先(胜场排序)",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["打赢过的优先上, 熟脸卖座。"]}],
            "custom_func": {
                "func_name": "duel_host_select_roster",
                "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_VETERAN, ""],
            },
            "next": _T_DIFFICULTY_DIALOG(),
        },
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "随机抽N个",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{"clist": ["筛出来的里头随便抽, 图个乐。"]}],
            "custom_func": {
                "func_name": "duel_host_select_roster",
                "params": [DialogueCustomUtils.DUEL_HOST_ROSTER_STRATEGY_RANDOM, ""],
            },
            "next": _T_DIFFICULTY_DIALOG(),
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "算了",
            "content": [{"clist": ["我再想想。"]}],
        },
    ]
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": [
            "（薇拉提笔等着）筛好的池子怎么取人?",
        ]}],
        "next": {
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
            "option_list": _options,
        },
    }



static func _T_DIFFICULTY_DIALOG()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [
            {
                "str_from_func": [{"func_name": "duel_host_get_draft_hint_str"}],
                "clist": ["#{0}"],
            }
        ],
        "next": _T_DIFFICULTY_OPTIONS(),
    }



static func _T_DIFFICULTY_OPTIONS()-> Dictionary:
    var _options: Array = []
    var _diff_list: Array = DialogueCustomUtils.DUEL_HOST_DIFFICULTY_LIST
    for _di: int in range(_diff_list.size()):
        var _diff: Dictionary = _diff_list[_di]
        _options.append({
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "%s(%s·%.1f倍)" % [
                str(_diff.get("name", "对决")),
                str(_diff.get("desc", "")),
                float(_diff.get("prize_rate", 2.0)),
            ],
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [{
                "clist": ["就打%s——对手%s的那种。" % [str(_diff.get("name", "这场")), str(_diff.get("desc", ""))]],
                "custom_func": {
                    "func_name": "duel_host_confirm_champion_match_v2",
                    "params": [_di],
                },
            }],
            "next": _T_BATTLE_GO(),
        })
    _options.append({
        "otype": OPTION_TYPE_ENUM.LEAVE,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "oname": "算了",
        "content": [{"clist": ["我再想想。"]}],
    })
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": _options,
    }





static func _T_RESUME_OPTIONS()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "开打!",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["别让奴隶们等急了, 开打吧。"]}],
                "next": _T_BATTLE_GO(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "先等等",
                "content": [{"clist": ["我再去转转。"]}],
            },
        ],
    }



static func _T_BATTLE_GO()-> Dictionary:
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "mod_slave_duel": true,
        "content": [{"clist": [
            "（薇拉吹响骨哨, 铁笼轰然打开）都看好了! 兵刃无眼, 各安天命——开笼!",
        ]}],
    }