extends BaseDialogue

const HERO_UID: = "mod_blacksmith_armour"


static func _T_GREETING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（盔甲铁匠正在敲打一副胸甲，叮叮当当的声音不绝于耳。看到你走近，他放下锤子擦了擦汗）"]}],
        "next": _T_GREETING_2(),
    }


static func _T_GREETING_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["大人好！我专打盔甲，头盔、胸甲、护肩、靴子，样样在行。您要锻造什么防具？"]}],
        "next": _T_OPTIONS(),
    }


static func _T_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "锻造装备",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["我想锻造一些防具。"]}],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "交谈",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["你这手艺不错，跟谁学的？"]}],
                "next": _T_TALK_RESPONSE(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "告辞",
                "content": [{"clist": ["先不打扰你了，回头见。"]}],
            }
        ]
    }


static func _T_TALK_RESPONSE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["我爹是这十里八乡有名的铁匠，我从小跟着他学打甲的手艺。后来战乱，他老人家走了，我就一直守着这铺子。"]}],
        "next": _T_TALK_RESPONSE_2(),
    }


static func _T_TALK_RESPONSE_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["如今您接手了这村子，日子总算安稳了些。需要什么防具尽管吩咐！"]}],
        "next": _T_OPTIONS(),
    }


func get_current_dialogue_template()-> Dictionary:
    return _T_GREETING()


func get_hero_uid()-> String:
    return HERO_UID