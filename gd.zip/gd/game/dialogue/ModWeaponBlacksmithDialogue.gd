extends BaseDialogue

const HERO_UID: = "mod_blacksmith_weapon"


static func _T_GREETING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（武器铁匠正往剑刃上淬火，嗤的一声白烟升腾。他举起剑端详片刻，才注意到你）"]}],
        "next": _T_GREETING_2(),
    }


static func _T_GREETING_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["大人！刀剑弓弩，只要您说得出，我就打得出。需要什么兵器？"]}],
        "next": _T_OPTIONS(),
    }


static func _T_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "锻造装备",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["我想锻造一些兵器。"]}],
            },
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "交谈",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["你打的刀剑确实锋利，什么来历？"]}],
                "next": _T_TALK_RESPONSE(),
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "告辞",
                "content": [{"clist": ["回头再找你，先忙你的。"]}],
            }
        ]
    }


static func _T_TALK_RESPONSE():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["我年轻时在军中当过兵器匠，专管修补刀枪。后来流落到这村子，就靠这门手艺混口饭吃。"]}],
        "next": _T_TALK_RESPONSE_2(),
    }


static func _T_TALK_RESPONSE_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["打了一辈子铁，别的不敢说，这兵器嘛，方圆百里没人比得过我！"]}],
        "next": _T_OPTIONS(),
    }


func get_current_dialogue_template()-> Dictionary:
    return _T_GREETING()


func get_hero_uid()-> String:
    return HERO_UID