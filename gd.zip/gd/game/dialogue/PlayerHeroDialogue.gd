extends BaseDialogue

func get_battle_chat_charge()-> String:
    var _content_list_rel_morality_value = [

        [
            "尽情杀戮吧! 直到这里再也没有站着的人!",
            "为了胜利, 不惜一切代价! 杀!",
            "挡路者死! 全军冲锋!",
            "碾碎他们! 一个活口也别留!",
            "把他们的阵型冲烂! 战利品全是我们的!",
            "我要看着这片土地在哀嚎中颤抖! 全军冲锋!",
            "这片土地上的每一枚金币, 每一条性命, 现在都归我了!",
            "这是属于强者的盛宴, 随我收割!",
            "把他们的恐惧化作养料, 杀光他们!",
            "谁敢后退半步, 我就先拿谁祭刀! 冲!",
            "在这片焦土上, 我就是唯一的真理! 冲!",
            "颤抖吧! 在你们被沙土彻底掩埋之前!",
            "保持势头, 彻底粉碎他们的抵抗!",
            "冲锋! 直到敌人崩溃为止!",
            "就是现在, 撕裂他们的防线!",
            "把他们的尊严碾进尘土里! 我要听着他们的哀鸣入睡!",
            "谁敢在我的马蹄前颤抖, 就送谁去见死神!",
            "给我冲碎他们的中军!",
        ],

        [
            "挡路者死! 全军冲锋!",
            "冲过去, 一个都别想跑!",
            "用武力让他们明白谁才是这里的主人!",
            "别让猎物跑了! 冲上去!",
            "不要给他们喘息的机会! 冲锋!",
            "保持势头, 彻底粉碎他们的抵抗!",
            "冲锋! 直到敌人崩溃为止!",
            "就是现在, 撕裂他们的防线!",
            "兄弟们, 随我杀出一条血路!",
            "给我冲碎他们的中军!"
        ],

        [
            "胜败在此一举, 突击!",
            "保持势头, 一鼓作气拿下他们!",
            "不要给他们喘息的机会! 冲锋!",
            "拿出你们的气魄来! 这一战我们必胜!",
            "保持势头, 彻底粉碎他们的抵抗!",
            "冲锋! 直到敌人崩溃为止!",
            "就是现在, 撕裂他们的防线!",
            "兄弟们, 随我杀出一条血路!"
        ],

        [
            "正义在我们的锋刃之上! 大家上!",
            "拿出你们的气魄来! 这一战我们必胜!",
            "保持势头, 彻底粉碎他们的抵抗!",
            "冲锋! 直到敌人崩溃为止!",
            "就是现在, 撕裂他们的防线!",
            "让这道光刺破战场的迷雾, 随我冲锋!",
            "即便是死, 我们也要死在冲锋的道路上!",
        ],

        [
            "不义之徒必将倒下! 为了荣誉而战!",
            "正义在我们的锋刃之上! 大家上!",
            "坚守信念! 击碎黑暗! 全军突击!",
            "愿光辉指引我们! 随我铲除邪恶!",
            "拿出你们的气魄来! 这一战我们必胜!",
            "黑暗终将散去, 随我迎接黎明!",
            "别害怕! 正义与我们同在, 冲锋!",
            "邪恶无法阻挡我们的意志! 冲锋!",
            "保持势头, 彻底粉碎他们的抵抗!",
            "让这道光刺破战场的迷雾, 随我冲锋!",
            "在正义的旗帜下, 我们无所畏惧!",
            "即便是死, 我们也要死在冲锋的道路上!",
            "正义会为我们开辟道路! 冲锋!"
        ]
    ]

    if SoldierUtils.get_player_belong_country() != WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:
        var _palyer_country_name = SoldierUtils.get_player_belong_country_name()

        var _temp_append_content_list = [
            "为了" + _palyer_country_name + "的荣耀, 冲锋!",
            "让" + _palyer_country_name + "的名号响彻这片荒原!",
            "身为" + _palyer_country_name + "的勇士, 我们绝不退缩!",
            "让敌人见识一下" + _palyer_country_name + "的实力!",
        ]

        _content_list_rel_morality_value[2].append_array(_temp_append_content_list)
        _content_list_rel_morality_value[3].append_array(_temp_append_content_list)
        _content_list_rel_morality_value[4].append_array(_temp_append_content_list)

    var _choose_content_list: Array = DialogueUtils.choose_content_list_by_rel_value(
        _content_list_rel_morality_value, SoldierUtils.get_player_morality_value_int()
    )

    _choose_content_list.append_array([
        "全军突击!",
        "随我冲锋!",
        "进攻!",
        "击碎他们!",
        "就是现在, 进攻!",
        "全军冲锋!",
        "全军! 听我令! 冲!",
        "全军, 随我克敌!"
    ])

    return _choose_content_list.pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _content_list_rel_morality_value = [

        [
            "死吧!",
            "这就是挑战我的下场!",
            "下一个是谁?",
            "你的哀鸣真悦耳",
            "在泥土里腐烂吧",
            "这就是你的极限了吗?",
            "真是无趣",
            "毫无意义的挣扎",
            "浪费我的时间",
            "还有谁!!",
            "真是可笑!",
            "弱者的惨叫",
            "我还没出全力呢",
            "解决掉一个",
            "下辈子离我远点",
            "死在我手里了吧!",
            "不过如此嘛",
        ],

        [
            "死吧!",
            "这就是挑战我的下场!",
            "下一个是谁?",
            "弱者...",
            "这就是你的极限了吗?",
            "真是无趣",
            "毫无意义的挣扎",
            "浪费我的时间",
            "还有谁!!",
            "真是可笑!",
            "我还没出全力呢",
            "解决掉一个",
            "下辈子离我远点",
            "死在我手里了吧!",
            "不过如此嘛",
        ],

        [
            "下一个是谁?",
            "弱者...",
            "这就是你的极限了吗?",
            "弱肉强食...",
            "这就是战场的宿命",
            "还有谁!!",
            "你的战斗结束了",
            "胜利必须属于我们!",
            "解决掉一个",
        ],

        [
            "弱肉强食...",
            "这就是战场的宿命",
            "你是个合格的对手",
            "你的战斗结束了",
            "胜利必须属于我们!",
            "值得尊敬的对手",
            "安息吧"
        ],

        [
            "这就是战场的宿命",
            "你是个合格的对手",
            "你的战斗结束了",
            "胜利必须属于我们!",
            "值得尊敬的对手",
            "安息吧"
        ]
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _content_list_rel_morality_value[0].append_array([
            "死在我手里了吧! " + _target_hero_name + "!"
        ])
        _content_list_rel_morality_value[1].append_array([
            "死在我手里了吧! " + _target_hero_name + "!"
        ])

    var _choose_content_list: Array = DialogueUtils.choose_content_list_by_rel_value(
        _content_list_rel_morality_value, SoldierUtils.get_player_morality_value_int()
    )

    _choose_content_list.append_array([
        "解决一个",
        "到此为止了",
        "这就是你的宿命",
        "你我胜负已分",
        "别怪我",
    ])

    if StringUtils.is_not_empty(_target_hero_name):
        _choose_content_list.append_array([
            "这就是你的宿命, " + _target_hero_name,
            "是我赢了, " + _target_hero_name,
            "到此为止了, " + _target_hero_name,
            "再见了, " + _target_hero_name,
            "胜负已分, " + _target_hero_name
        ])

    return _choose_content_list.pick_random()

func get_battle_chat_injured()-> String:
    var _content_list_rel_morality_value = [

        [
            "好极了!",
            "敢伤我?",
            "这种程度就想杀我?",
            "该死!",
            "想杀我? 你还不配!",
            "掩护我!",
            "这点伤! 难不倒我!",
            "好疼!",
            "我要把你碎尸万段!",
            "我一定要你好看!",
            "我要把你撕成碎片!",
            "这点小伤!",
        ],

        [
            "该死!",
            "掩护我!",
            "血流得有点多...",
            "得速战速决了...",
            "好疼!",
        ],

        [
            "还没到倒下的时候!",
            "继续战斗!",
            "血流得有点多...",
            "得速战速决了...",
            "呼...呼...",
            "保持冷静...",
            "寻找反击的机会...",
            "还没到极限呢!",
            "好疼!",
        ],

        [
            "还没到倒下的时候!",
            "继续战斗!",
            "血流得有点多...",
            "得速战速决了...",
            "这点伤...",
            "呼...呼...",
            "保持冷静...",
            "寻找反击的机会...",
            "来吧, 继续!",
            "我还没倒下!",
            "还没到极限呢!",
            "我还能战斗!",
            "这点小伤!",
        ],

        [
            "还没到倒下的时候!",
            "继续战斗!",
            "血流得有点多...",
            "得速战速决了...",
            "这点伤...",
            "呼...呼...",
            "保持冷静...",
            "寻找反击的机会...",
            "来吧, 继续!",
            "我还没倒下!",
            "还没到极限呢!",
            "我还能战斗!",
            "这点小伤!",
        ]
    ]

    var _choose_content_list: Array = DialogueUtils.choose_content_list_by_rel_value(
        _content_list_rel_morality_value, SoldierUtils.get_player_morality_value_int()
    )

    _choose_content_list.append_array([
        "可恶!",
        "不好!",
        "大意了...",
        "呃啊!",
        "奇耻大辱...",
        "啧, 伤口有点深...",
        "必须调整呼吸...",
        "呼...冷静",
        "视线有点模糊了..."
    ])

    return _choose_content_list.pick_random()

func get_battle_chat_die()-> String:
    var _content_list_rel_morality_value = [

        [
            "不...",
            "可恶...",
            "我的野心...",
            "我就算死...",
            "我会在地狱里等着你们...",
            "还没...",
            "这笔账...",
            "你们这些...",
            "地狱的门...",
            "把我的财宝...",
            "我不服..."
        ],

        [
            "不...",
            "可恶...",
            "还没...",
            "这笔账...",
        ],

        [
            "不...",
            "可恶...",
            "还没...",
            "可惜...",
        ],

        [
            "可恶...",
            "还没...",
            "可惜...",
        ],

        [
            "为了荣誉...",
            "继续前进...",
            "可惜...",
        ]
    ]

    var _choose_content_list: Array = DialogueUtils.choose_content_list_by_rel_value(
        _content_list_rel_morality_value, SoldierUtils.get_player_morality_value_int()
    )

    _choose_content_list.append_array([
        "竟然死在这种地方...",
        "我不甘心...",
        "竟然在这里倒下...",
        "这不可能...",
        "咳...",
        "竟然被...",
        "终究还是...走到了这一步吗...",
        "到此为止了...",
        "意识...正在模糊...",
        "不可能...",
        "咳哈...",
        "结束了...",
        "黑暗...降临了...",
        "居然...输了...",
        "这就是...结局吗...",
        "这就是...我的终点站吗...",
    ])

    return _choose_content_list.pick_random()

func get_battle_chat_move()-> String:
    return[
        "跟上步伐!",
        "动作迅速!",
        "前进!",
        "保持阵型!",
        "移动!",
        "打起精神来!",
        "盯着前方!",
        "注意观察四周!",
        "按照预定路线, 出发!",
        "抓紧时间!",
        "保持队形!",
        "不要掉队!",
        "出发!",
        "跟上!",
        "加快速度!",
        "动作快点!",
        "这是命令!",
    ].pick_random()

func get_battle_chat_attack()-> String:
    var _content_list_rel_morality_value = [

        [
            "一个不留!",
            "干掉他们!",
            "我要看到血流成河!",
            "给我狠狠地打!",
            "别放跑一个!",
            "通通给我拿下!"
        ],

        [
            "一个不留!",
            "干掉他们!",
            "一鼓作气拿下他们!",
        ],

        [
            "干掉他们!",
            "碾碎那道防线!",
            "集中火力!",
            "全速进攻!",
            "锁定目标!",
            "随我突击!",
            "不要畏惧!",
            "一鼓作气拿下他们!",
        ],

        [
            "碾碎那道防线!",
            "集中火力!",
            "全速进攻!",
            "锁定目标!",
            "保持攻势!",
            "随我突击!",
            "为了荣誉!",
            "展现你们勇气的时刻到了!",
            "不要畏惧!",
            "一鼓作气拿下他们!",
        ],

        [
            "碾碎那道防线!",
            "集中火力",
            "全速进攻!",
            "锁定目标!",
            "保持攻势!",
            "随我突击!",
            "为了荣誉!",
            "展现你们勇气的时刻到了!",
            "不要畏惧!",
            "一鼓作气拿下他们!",
        ]
    ]

    var _choose_content_list: Array = DialogueUtils.choose_content_list_by_rel_value(
        _content_list_rel_morality_value, SoldierUtils.get_player_morality_value_int()
    )

    _choose_content_list.append_array([
        "突击! 目标就在那!",
        "进攻那个目标!",
        "摧毁他们!",
        "集中攻击!",
        "让他们付出代价!",
        "给我上!",
        "进攻!",
        "攻过去!"
    ])

    return _choose_content_list.pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 原地防守!"
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "原地防守!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    var _content_list_rel_morality_value = [

        [
            "哈哈! 胜利的味道总是这么迷人!",
            "把值钱的东西全带走!",
            "这就是反抗我的下场!",
            "胜利属于强者!",
            "清点战利品! 谁敢私藏, 军法处置!",
            "这就是挑战我的代价!",
            "胜利属于强者, 而弱者只配躺在泥土里!",
            "哈哈哈! 记住这一刻!",
            "哈哈哈, 这就是我想要的结局!",
            "哼, 这就结束了?",
            "收剑入鞘! 准备撤离, 我们还有下一个目标",
            "做得很好! 各位!",
            "这就是弱小的代价",
            "挡在我面前的下场只有灰飞烟灭!",
            "踩在失败者的旗帜上, 这种感觉真是无与伦比!",
            "简直不堪一击!",
            "活着的拿走一切, 死去的化作尘埃",
        ],

        [
            "把值钱的东西全带走!",
            "胜利属于强者!",
            "收工!",
            "收剑入鞘! 准备撤离, 我们还有下一个目标",
            "这就是胜利的滋味!",
            "做得很好! 各位!",
            "抓紧整队!",
            "别光顾着高兴, 去看看战马和武器的损耗!",
            "这一仗打得不赖!",
            "打完收工!",
            "简直不堪一击!",
        ],

        [
            "胜利属于我们!",
            "全军修整! 清点损耗!",
            "干得不错, 这是大家应得的胜利!",
            "我们赢了!",
            "这就是胜利的滋味!",
            "干得漂亮!",
            "收剑入鞘! 准备撤离, 我们还有下一个目标",
            "这一仗打得漂亮!",
            "别光顾着高兴, 去看看战马和武器的损耗!",
            "这一仗打得不赖!",
            "打完收工!",
            "真痛快!",
        ],

        [
            "胜利属于我们!",
            "全军修整! 清点损耗!",
            "不要放松警惕!",
            "我们赢了! 这是属于所有人的荣耀!",
            "干得不错, 这是大家应得的胜利!",
            "统计伤亡情况, 尽快向我汇报!",
            "你们的表现为这面旗帜赢得了荣光!",
            "胜利属于大家!",
            "我们赢了!",
            "这就是胜利的滋味!",
            "干得漂亮!",
            "吟游诗人会传唱这一战的! 你们都是英雄!",
            "这就是团结的力量!",
            "敌人必将在我们面前崩溃!",
            "这一仗打得漂亮!",
            "别光顾着高兴, 去看看战马和武器的损耗!",
            "这一仗打得不赖!",
            "真痛快!",
        ],

        [
            "胜利属于我们!",
            "全军修整! 清点损耗!",
            "不要放松警惕!",
            "我们赢了! 这是属于所有人的荣耀!",
            "干得不错, 这是大家应得的胜利!",
            "统计伤亡情况, 尽快向我汇报!",
            "你们的表现为这面旗帜赢得了荣光!",
            "胜利属于大家!",
            "挺起胸膛, 我们带着胜利和尊严回家!",
            "安葬死者, 无论敌我...愿此地不再有战火",
            "愿逝者安息, 生者坚强",
            "正义终将战胜黑暗!",
            "别忘了那些倒下的兄弟, 他们的牺牲换来了这一切",
            "吟游诗人会传唱这一战的! 你们都是英雄!",
            "这就是团结的力量!",
            "敌人必将在我们面前崩溃!",
            "这一仗打得漂亮!",
            "每一场胜利都浸透了鲜血, 我们要铭记这份沉重",
            "在硝烟散去的地方, 种子终会重新萌芽",
            "尘土终将掩埋鲜血"
        ]
    ]

    var _choose_content_list: Array = DialogueUtils.choose_content_list_by_rel_value(
        _content_list_rel_morality_value, SoldierUtils.get_player_morality_value_int()
    )

    _choose_content_list.append_array([
        "清点完战果立刻撤离战斗区域!",
    ])

    return _choose_content_list.pick_random()