extends BaseDialogue

const FRIENDLY_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "强寇的兄弟! 卡兰特的战士尊重强者, 我们不找自己人的麻烦.",
                "哟, 强寇的人! 咱们都是背井离乡的亡命徒, 何必互相为难.",
                "自己人! 在异乡讨生活不容易, 咱们井水不犯河水.",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "can_recruit_robber"
                },
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "招募(#{0}德里)",
                "str_from_func": [
                    {
                        "func_name": "get_robber_recruit_cost",
                    }
                ],
                "custom_func": {
                    "func_name": "handle_robber_recruit",
                },
                "content": [
                    {
                        "clist": [
                            "卡兰特的战士, 强寇需要你们的力量!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

const COMMON = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "is_player_weaker_than_b_team"
            },
            "clist": [
                "卡兰特的战士从不空手而归, 你是自己把钱交出来, 还是让我们搜尸?",
                "真不错, 这地方的猎物比克瑞弗大陆的更蠢.(冷笑)",
                "我们千辛万苦从克瑞弗来到这, 你总得拿出点像样的\"见面礼\"吧?(嬉笑)",
                "让这些土著见识一下, 卡兰特战士的专业战斗素养.(嬉笑)"
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.BATTLE,
                        "oname": "迎战",
                        "content": [
                            {
                                "clist": [
                                    "你们这群卡兰特的败类, 来! 试试看谁才是猎物!",
                                    "少废话! 你们只是一群被卡兰特踢出来的丧家犬",
                                    "在克瑞弗活不下去了, 来这里找存在感吗?"
                                ]
                            },
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.FLEE,
                        "oname": "逃跑",
                        "content": [
                            {
                                "clist": [
                                    DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                                ]
                            }
                        ]
                    }
                ]
            }
        },
        {

            "clist": [
                "(扫描对方的部队), 兄弟们，我们踢到铁板了",
                "别指望我们会像罗德里的懦夫一样逃跑. 在克瑞弗, 战死也比两手空空地活着强!",
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.BATTLE,
                        "oname": "进攻",
                        "content": [
                            {
                                "clist": [
                                    "计算出了你们的胜算了吗? 结果应该是 - 你们全都会死.",
                                    "准备好死在异处了吗? 丧家犬们."
                                ]
                            },
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.LEAVE,
                        "oname": "离开",
                        "content": [
                            {
                                "clist": [
                                    DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                ]
                            }
                        ]
                    }
                ]
            }
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    if DialogueCustomUtils.player_is_in_black_fang():
        return FRIENDLY_MEET
    return COMMON

func get_battle_chat_charge()-> String:
    return[
        "锁定目标, 卡兰特风格, 杀!",
        "全军突击!",
        "让土著见识一下什么叫职业素养!",
        "劫掠开始!",
        "卡兰特战士从不空手而归, 收割!",
        "侧翼包抄! 别让赏金溜了!",
        "动作快!",
        "让这些土著看看克瑞弗的战斗效率!",
        "开始清场!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "目标已清除",
        "这种货色在克瑞弗活不过一天",
        "毫无威胁",
        "一文不值",
        "再见了, 哈哈哈",
        "这就是土著的死法",
        "你的战斗技术太落后了, 孩子",
        "下一个是谁?"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "还没到撤退的时候!",
        "该死的土著!",
        "啧...",
        "坚持住!",
        "这种痛感, 真是久违了",
        "该死!",
        "该死的异乡人!",
        "稳住!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "任务失败...",
        "这就是...流放者的...终点吗...",
        "至少...没死在...阴暗的克瑞弗...",
        "卡兰特...终究回不去了...",
        "呃啊~",
        "看来...这是...最后一单生意...",
        "我早该想到..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "结算时间! 把值钱的统统打包!",
        "完美的作战",
        "我就喜欢看这片余烬",
        "清点战损, 然后把这地方搜刮干净",
        "这就是卡兰特的生存之道",
        "下一个猎场在哪?",
        "别盯着尸体看, 快找找他们的补给箱!",
        "这就是卡兰特的规矩: 活着的人拿走一切",
        "检查装备, 准备寻找下一个猎物."
    ].pick_random()