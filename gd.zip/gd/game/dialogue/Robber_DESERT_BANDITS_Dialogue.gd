extends BaseDialogue

func get_battle_chat_charge()-> String:
    return[
        "像沙尘暴一样席卷他们!",
        "把他们埋进沙子里!",
        "冲啊! 让太阳见证我们的掠夺盛宴!",
        "抢光他们!",
        "上啊!",
        "值钱的东西都给我留下!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你就留在这里喂秃鹫吧",
        "绝望吧! 哈哈哈!",
        "你的脑袋值不少钱!",
        "不过如此嘛",
        "这就送你去见你的祖先",
        "死了吧, 哈哈哈",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "好痛!",
        "该死...竟然见红了",
        "真疼啊!",
        "该死...",
        "撑不住了...",
        "这点痛...不算什么...",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "不该是...这样的...",
        "这就是...下场吗...",
        "我的德里...要埋在沙里了...",
        "啊!...",
        "好想...再看一眼绿洲...",
        "我想起那天下午夕阳下的奔跑...",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "翻翻他们的包, 把所有战利品都带走!",
        "这一战能让我们快活半年!",
        "今晚在帐篷里狂欢!",
        "胜利!",
        "翻翻他们的尸体, 肯定有宝贝!",
        "搜搜这些尸体上有没有宝石!"
    ].pick_random()