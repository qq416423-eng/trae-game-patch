extends BaseDialogue

const FRIENDLY_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "强寇的兄弟! 雄鹰佣兵不跟道上的人过不去.",
                "哟, 自己人! 咱们都是拿命换钱的, 没必要互相为难.",
                "强寇大名谁不知道? 雄鹰佣兵给面子, 不找麻烦.",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "can_recruit_robber"
                },
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "招募(#{0}德里)",
                "str_from_func": [
                    {
                        "func_name": "get_robber_recruit_cost",
                    }
                ],
                "custom_func": {
                    "func_name": "handle_robber_recruit",
                },
                "content": [
                    {
                        "clist": [
                            "雄鹰的佣兵, 来帮强寇干一票!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

const COMMON = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "is_player_weaker_than_b_team"
            },
            "clist": [
                "别紧张, 我们雄鹰佣兵团办事一向利索 - 要么给钱, 要么留命.",
                "既然你认得出这身雄鹰甲, 就该明白罗德里的规矩 - 平安路可不是这么好走的.",
                "我们是雄鹰佣兵. 虽然我们通常不惹事, 但今天...我们的钱包恰好空了.(嬉笑)",
                "罗德里的老一套已经赚不到钱了. 来, 把值钱的交出来, 咱们速战速决."
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.BATTLE,
                        "oname": "迎战",
                        "content": [
                            {
                                "clist": [
                                    "雄鹰团的名声就是被你们这种败类给毁掉的!",
                                    "我认识真正的雄鹰战士, 而你们...只是一群披着鹰皮的秃鹫."
                                ]
                            },
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.FLEE,
                        "oname": "逃跑",
                        "content": [
                            {
                                "clist": [
                                    DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                                ]
                            }
                        ]
                    }
                ]
            }
        },
        {

            "clist": [
                "喂, 朋友! 没必要一上来就拔剑吧? 大家都是在罗德里混口饭吃的...(苦笑)",
                "该死! 我就说今天没好运. 这副身板...不像是好惹的货色...",
                "等等! 我们只是想讨口酒钱, 没打算跟一个真正的猛士拼命!",
                "啧, 我就知道! 刚才飞过一群乌鸦就没好事. 阁下, 咱们各走各的路怎么样?"
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.BATTLE,
                        "oname": "进攻",
                        "content": [
                            {
                                "clist": [
                                    "想求饶? 去跟被你们洗劫过的冤魂说吧!",
                                    "雄鹰团的名声就是被你们这种败类弄脏的! 今天我就替雄鹰团清理门户.",
                                    "把武器放下, 跪在地上, 我会考虑让你们死得体面一点."
                                ]
                            },
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.LEAVE,
                        "oname": "离开",
                        "content": [
                            {
                                "clist": [
                                    DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                ]
                            }
                        ]
                    }
                ]
            }
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    if DialogueCustomUtils.player_is_in_black_fang():
        return FRIENDLY_MEET
    return COMMON

func get_battle_chat_charge()-> String:
    return[
        "为了德里, 冲啊!",
        "一个都别放过!",
        "利索点, 速战速决!",
        "剥了他们的盔甲换酒喝!",
        "抢光他们!",
        "上啊!",
        "值钱的东西都给我留下!",
        "带头的留下, 剩下的全宰了!",
        "雄鹰俯冲! 把他们的口袋掏空!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "啧, 这就是不交买路钱的下场",
        "绝望吧! 哈哈哈!",
        "又多了一具尸体",
        "真不经打",
        "不过如此嘛",
        "这就送你去见你的祖先",
        "死了吧, 哈哈哈",
        "啧啧，行头不错，可惜命短",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "等等!",
        "有话好说...",
        "好痛!",
        "该死...竟然见红了",
        "真疼啊!",
        "该死...",
        "撑不住了...",
        "见鬼!",
        "慢着!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "我就知道...今天不该出门的...",
        "不该是...这样的...",
        "啊!...",
        "罗德里的风...真冷啊...",
        "我也曾...是个真正的雄鹰战士...",
        "谁来...替我收个尸...",
        "早知道...刚才就该跑了..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "搞定，收工",
        "翻翻他们的包, 把所有战利品都带走!",
        "我就说嘛, 雄鹰团是无敌的",
        "胜利!",
        "翻翻他们的尸体, 肯定有宝贝!",
        "搜搜这些尸体上有没有宝石!",
        "钱能买命, 可惜你们没带够",
        "这就是雄鹰的效率, 收工",
    ].pick_random()