extends BaseDialogue

func get_battle_chat_charge()-> String:
    return[
        "狩猎开始了！",
        "把他们像兔子一样猎杀!",
        "抢光他们!",
        "上啊!",
        "准备放箭!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "死在无名之辈手里, 滋味如何?",
        "你的脑袋值不少钱!",
        "不过如此嘛",
        "这就是自大的代价",
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "好痛!",
        "掩护我!",
        "我还不想死!",
        "该死...竟然见红了",
        "真疼啊!",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "不该是...这样的...",
        "这就是...下场吗...",
        "早知道就...不出来了...",
        "啊!...",
        "被猎物...反杀了...",
        "我的...弓断了..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "包围他们, 像抓兔子一样!",
        "别急, 慢慢包围他们..."
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "今天有肉吃了!",
        "翻翻他们的尸体, 肯定有宝贝!",
        "把值钱的带回营地!",
        "又是一场完美的伏击!",
        "看看这些肥羊身上带了什么好东西!"
    ].pick_random()