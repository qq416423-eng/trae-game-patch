extends BaseDialogue

func get_battle_chat_charge()-> String:
    return[
        "抢光他们!",
        "上啊!",
        "杀光他们, 一个不留!",
        "值钱的东西都给我留下!",
        "谁抢到归谁, 冲啊!",
        "冲啊! 掏空他们的口袋!",
        "冲啊! 他们跑不过我们的快马!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你的脑袋值不少钱!",
        "不过如此嘛",
        "这就送你去见你的祖先",
        "死了吧, 哈哈哈",
        "知道我弯刀的厉害了吧!"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "好痛!",
        "该死...竟然见红了",
        "真疼啊!",
        "该死...",
        "该死, 我要落马了",
        "我的马受伤了! 该死的!",
        "撑不住了..."
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "不该是...这样的...",
        "这就是...下场吗...",
        "早知道就...不出来了...",
        "啊!...",
        "我也曾想做个好人...",
        "下辈子...我要做个好人..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "今晚在篝火旁痛饮!",
        "哈哈, 全是德里和美酒!",
        "胜利是我们赤那旅的!",
        "翻翻他们的尸体, 肯定有宝贝!",
        "这是一场属于草原狼的胜利!",
        "去搜刮那些跑不掉的肥羊!"
    ].pick_random()