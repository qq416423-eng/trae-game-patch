extends BaseDialogue

func get_battle_chat_charge()-> String:
    return[
        "抢光他们!",
        "上啊!",
        "碾碎他们",
        "杀光他们, 一个不留!",
        "感受海洋的愤怒吧!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你的脑袋值不少钱!",
        "不过如此嘛",
        "你这软弱的旱鸭子!",
        "这就送你去见你的祖先",
        "呸, 不过是块会动的小肉干",
        "死了吧, 哈哈哈"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "好痛!",
        "掩护我!",
        "我还不想死!",
        "该死...竟然见红了",
        "真疼啊!",
        "血...越流越多了...",
        "该死...",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "不该是...这样的...",
        "这就是...我的下场吗...",
        "早知道就...不出来了...",
        "啊!...",
        "大海...接纳我...",
        "呃啊! 这不公平!",
        "职业生涯...到此为止了吗...",
        "转告女神莫瑞娅...我喜欢她...",
        "转告莫瑞娅, 她是我的女神..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "把财宝堆进我们的长船!",
        "今晚我们要喝个痛快!",
        "哈哈, 全是德里和美酒!",
        "胜利!",
        "这就叫本事, 哈哈哈哈!",
        "翻翻他们的尸体, 肯定有宝贝!",
    ].pick_random()