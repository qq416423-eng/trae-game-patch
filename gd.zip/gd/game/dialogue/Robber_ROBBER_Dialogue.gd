extends BaseDialogue

func get_battle_chat_charge()-> String:
    return[
        "抢光他们!",
        "上啊!",
        "把他们剁成肉泥!",
        "值钱的东西都给我留下!",
        "谁抢到归谁, 冲啊!",
        "冲啊! 掏空他们的口袋!",
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "快点, 别磨蹭!"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "给我上!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "不过如此嘛",
        "哈哈, 这就是自大的代价",
        "呸, 还不是死在我手里了"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "好痛!",
        "谁来...谁来掩护我!",
        "救命! 我还不想死!",
        "该死...竟然见红了",
        "真疼啊!",
        "谁来帮帮我!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "不该是...这样的...",
        "早知道就...不来了...",
        "啊!...",
        "我的...德里...",
        "这就是...出来混的下场吗...",
        "出来混...迟早要还的...",
        "还没尝过...城里的...葡萄酒...",
        "兄弟们...救我..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "嘿嘿, 一点点逼死他们",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "今天晚上可以大喝一场了!",
        "胜利! 接下来是搜刮时间",
        "这就叫本事, 哈哈哈哈!",
        "翻翻他们的尸体, 肯定有宝贝!",
        "这就是抢劫的艺术!"
    ].pick_random()