extends BaseDialogue

const FRIENDLY_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "呼斯克! 强寇的兄弟, 我们共享着同一条通往真理的道路.",
                "呼斯克~, 自己人! 愿圣洁的火焰指引你.",
                "啊, 强寇的同伴! 苦难是唯一的救赎, 我们终将并肩同行.",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "can_recruit_robber"
                },
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "招募(#{0}德里)",
                "str_from_func": [
                    {
                        "func_name": "get_robber_recruit_cost",
                    }
                ],
                "custom_func": {
                    "func_name": "handle_robber_recruit",
                },
                "content": [
                    {
                        "clist": [
                            "呼斯克~, 让你的信徒随我一同传播真理!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

const COMMON = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {

            "custom_choose_func": {
                "func_name": "is_player_weaker_than_b_team"
            },
            "clist": [
                "呼斯克! 看看这个迷途的灵魂...别害怕, 孩子, 我们带来的痛苦是洗净你罪恶的唯一甘露.",
                "呼斯克~, 你的肉体在颤抖, 那是它渴望被\"净化\"的欢呼. 让我们帮你烙下救赎的印记."
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.BATTLE,
                        "oname": "迎战",
                        "content": [
                            {
                                "clist": [
                                    "收起你们那套恶心的印记, 我唯一的\"救赎\"，就是送你们这群疯子下地狱!",
                                    "士兵们! 握紧你们的剑, 那是唯一能让他们闭嘴的东西!",
                                    "士兵们! 捂住耳朵, 别听这些疯子的呓语. 握紧你们的剑, 那是唯一能让他们闭嘴的东西!"
                                ]
                            },
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.FLEE,
                        "oname": "逃跑",
                        "content": [
                            {
                                "clist": [
                                    DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                                ]
                            }
                        ]
                    }
                ]
            }
        },
        {

            "clist": [
                "呼斯克! 这种沉重的杀意, 简直是世间最美的乐章.",
                "(嘶哑的欢呼)来吧! 用你的怒火把我们烧成灰烬, 在那圣洁的余烬中, 我们将与真主同在!",
                "呼斯克~, 兄弟们, 用血来欢迎这位伟大的行刑官!"
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.OPTION,
                "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                "option_list": [
                    {
                        "otype": OPTION_TYPE_ENUM.BATTLE,
                        "oname": "进攻",
                        "content": [
                            {
                                "clist": [
                                    "既然你们把死亡当成圣餐, 那我就大发慈悲, 让你们吃个饱.",
                                    "呼斯克接不接纳你们我不知道, 但这块土地已经等不及要埋葬你们了.",
                                    "闭上嘴. 然后等待我的剑刃穿过你们那空洞的灵魂."
                                ]
                            },
                        ]
                    },
                    {
                        "otype": OPTION_TYPE_ENUM.FLEE,
                        "oname": "离开",
                        "content": [
                            {
                                "clist": [
                                    DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                ]
                            }
                        ]
                    }
                ]
            }
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    if DialogueCustomUtils.player_is_in_black_fang():
        return FRIENDLY_MEET
    return COMMON

func get_battle_chat_charge()-> String:
    return[
        "欢呼吧! 痛苦的洗礼开始了!",
        "呼斯克~, 来感受这极致的救赎!",
        "剥离他们的皮囊, 释放他们的灵魂!",
        "呼斯克! 这就是通往净化的唯一捷径!",
        "为了雷瑟托的真意, 冲锋!",
        "呼斯克! 让圣洁的烙铁落入他们的肉体!",
        "呼斯克! 让神圣的痛苦绽放!",
        "来吧, 接受这滚烫的恩典!",
        "撕裂皮囊, 直抵真理!",
        "救赎的仪式, 开演了!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "呼斯克, 他在痛苦中得到了永恒的安宁",
        "这具肮脏的肉体被洗净了",
        "你的哀嚎, 是献给真主最美的赞歌",
        "烙印已成",
        "别哭泣，孩子",
        "啊哈啊哈啊哈!",
        "新的净化"
    ]

    if StringUtils.is_not_empty(_target_hero_name):
        _list.append_array([
            _target_hero_name + "! 死在我手里了吧!"
        ])

    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "呼斯克! 这刺骨的痛楚!",
        "啊哈啊哈啊哈!",
        "让我更接近真主!",
        "呼斯克!",
        "我的肉体正在崩裂!",
        "我的灵魂正在升华!",
        "赞美这神圣的刑罚!",
        "这极致的痛苦...",
        "这种灼烧感...",
        "撕裂我吧!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "这种罪孽被剥离的感觉...啊~",
        "呼斯克...我终于洗净了...",
        "在圣洁的余烬中...重逢...",
        "感谢您的赏赐...",
        "呼斯克...真主在呼唤我...",
        "我的烙印...完成了...",
        "我在余烬中...看到了...真主...",
        "这完美的...终点..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
        "援军来了! 我们待命!",
        "援军来了! 我们稳住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "压过去, 像海浪一样!",
        "不要乱, 稳步前进!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住! 谁敢后退我就砍了谁!",
        "守住这里! 他们冲不进来!",
        "死守这里! 后退者是懦夫!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "呼斯克! 罗德里大陆又多了几分圣洁!",
        "现在, 轮到幸存者接受烙印了...",
        "痛苦过后的寂静, 真是迷人.",
        "呼斯克! 教义再次得到了扩散",
        "把他们吊起来, 仪式才刚刚开始!",
        "呼斯克! 赞美这份寂静, 罪恶已被洗净.",
        "痛苦之后, 便是永恒的归依.",
        "呼斯克~ 看啊, 这片土地变得多么纯洁!",
        "你们的余生, 将因今日的伤痕而伟大"
    ].pick_random()