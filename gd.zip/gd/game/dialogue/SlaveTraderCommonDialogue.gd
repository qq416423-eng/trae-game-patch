extends BaseDialogue

const COMMON = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "这位兄弟, 有没有什么\"货\"想出手的? 我可以给你个好价钱",
                "你看起来不像是空手来的, 有没有奴隶想卖给我? 我这儿一直缺强壮的劳力",
                "兄弟, 有没有多余的奴隶? 最近货源紧张, 我可急着收点货",
                "我知道你手下肯定有不少俘虏, 如果有不想留的, 我可以帮你处理",
                "我可知道你这类人不会缺俘虏. 何必自己留着麻烦. 卖给我, 让他们为你赚钱才对(坏笑)"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "这位女士, 有没有什么\"货\"想出手的? 我可以给你个好价钱",
                "你看起来不像是空手来的, 有没有奴隶想卖给我? 我这儿一直缺强壮的劳力",
                "女士, 有没有多余的奴隶? 最近货源紧张, 我可急着收点货",
                "我知道你手下肯定有不少俘虏, 如果有不想留的, 我可以帮你处理",
                "我可知道你这类人不会缺俘虏. 何必自己留着麻烦. 卖给我, 让他们为你赚钱才对(坏笑)"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.SELL_PRISONER,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "出售俘虏",
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "合作愉快"
                            ]
                        }
                    ],
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "下次再说."
                        ]
                    }
                ],
            }
        ]
    }
}

func get_current_dialogue_template()-> Dictionary:
    return COMMON