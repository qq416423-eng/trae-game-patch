class_name TempDialogue extends BaseDialogue




















































const COMMON_BATTLE_0001 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
               "(战斗中...)",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "content": [
            {
                "clist": [
                   DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS
                ]
            }
        ],
        "next": {
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "step_type": STEP_TYPE_ENUM.OPTION,
            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
            "option_list": [
                {
                    "custom_choose_func": {
                        "func_name": "allow_battle_help_team",
                        "params": [MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM1],
                    },
                    "str_from_func": [
                        {
                            "func_name": "get_team_name_by_battle_team_type_enum",
                            "params": [MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM1],
                        }
                    ],
                    "otype": OPTION_TYPE_ENUM.BATTLE_HELP_TEAM1,

                    "oname": "帮助[#{0}]",
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_team_name_by_battle_team_type_enum",
                                    "params": [MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM1],
                                }
                            ],
                            "clist": [
                               "(我方选择帮助 [#{0}])"
                            ]
                        }
                    ],
                },
                {
                    "custom_choose_func": {
                        "func_name": "allow_battle_help_team",
                        "params": [MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2],
                    },
                    "str_from_func": [
                        {
                            "func_name": "get_team_name_by_battle_team_type_enum",
                            "params": [MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2],
                        }
                    ],
                    "otype": OPTION_TYPE_ENUM.BATTLE_HELP_TEAM2,

                    "oname": "帮助[#{0}]",
                    "content": [
                        {
                            "str_from_func": [
                                {
                                    "func_name": "get_team_name_by_battle_team_type_enum",
                                    "params": [MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2],
                                }
                            ],
                            "clist": [
                               "(我方选择帮助 [#{0}])"
                            ]
                        }
                    ],
                },
                {
                    "otype": OPTION_TYPE_ENUM.LEAVE,
                    "oname": "离开",
                    "content": [
                        {
                            "clist": [
                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                            ]
                        }
                    ],
                }
            ]
        }
    }
}



































































































































const MERCHANT_CONVOY_DIALOGUE_0002 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content_list": [
        "大人, 您好, 我们是来自 [#{b_origin_location_name}] 的商人, \t\t我这儿有一些不常见的宝物，您是否愿意看一看呢?"

    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.INSPECT_TREASURES,

                "content_list": [


                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "打劫",
                "content_list": [
                    "不用看了, 直接交出来吧(坏笑)",
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content_list": [
                    "",
                ]
            }
        ]
    }
}


const VILLAGER_DIALOGUE_0001 = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "custom_choose_func": {
                "func_name": "is_b_lord",
            },
            "clist": [
                "领主大人! 能在路上见到您是我们的荣幸!",
                "见到您真是我们的荣幸, 大人.",
                "吾等向您致敬, 尊贵的领主大人.",
                "感谢您庇护我们的村子, 大人.",
                "我...我见过这位大人! 他是我们村的统治者!(对其他村民喊道)",
                "请原谅我们的简陋礼节, 伟大的领主.",
                "星辰庇佑, 竟能在此地见到我们村的统治者.",
                "您的到来, 如黎明照进荒原, 大人."
            ]
        },
        {

            "custom_choose_func": {
                "func_name": "has_met_player_before"
            },
            "clist": [
                "大人, 我们又碰见您了. 需要我们做些什么吗?",
                "大人, 没想到这么快又遇到您."
            ]
        },
        {
            "clist": [
                "您好, 大人, 我们是来自 [#{b_origin_location_name}] 的村民.",
                "您好, 大人, 我们是 [#{b_origin_location_name}] 的村民, 请原谅我们的简陋行装, 您有何吩咐?",
                "您好, 大人, 我们是 [#{b_origin_location_name}] 的村民, 若有打扰, 还请见谅.",

            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "赠送装备",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "custom_choose_func": {
                    "func_name": "can_show_gift_equipment_to_villager"
                },
                "content": [
                    {
                        "clist": [
                            "我想送你们一些装备."
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "大人如此仁慈, 我们感激不尽!"
                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.TALK,
                                "oname": "赠送七件三星装备",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "custom_func": {
                                    "func_name": "handle_gift_equipment_to_villager"
                                },
                                "content": [
                                    {
                                        "clist": [
                                            "这些装备给你们, 希望能帮到你们."
                                        ]
                                    }
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {
                                            "clist": [
                                                "多谢大人! 您的恩情, 我们全村铭记!"
                                            ]
                                        }
                                    ]
                                }
                            },
                            {
                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                "oname": "取消",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "我再想想."
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang"
                },
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "打劫",
                "content": [
                    {
                        "clist": [
                            "把值钱的东西都交出来!",
                            "此路是我开, 此树是我栽, 要想过此路, 留下买路财!",
                            "兄弟们, 今天运气不错, 又碰上一群肥羊!",
                            "别废话, 钱和命, 选一个!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content_list": [
                    {
                        "clist": [
                            "没事, 你们走吧",
                        ]
                    }
                ]
            }
        ]
    }
}