extends LordDialogueBase

const HERO_UID: = "village_guard"


static func _T_HOSTILE_GREETING():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（一队全副武装的士兵挡在村口，为首的军官冷冷地盯着你）"]}],
        "next": _T_HOSTILE_GREETING_2(),
    }


static func _T_HOSTILE_GREETING_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["站住！你与我们王国为敌，这里不欢迎你。速速离开，否则别怪我们不客气。"]}],
        "next": _T_HOSTILE_OPTIONS(),
    }


static func _T_HOSTILE_OPTIONS():
    return {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "custom_func": {
                    "func_name": "handle_player_attack_guard",
                },
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [{"clist": ["那就别怪我不客气了！"]}],
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [{"clist": ["好，我走。"]}],
            }
        ]
    }


static func _T_LOW_REPUTATION():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["（守卫们警惕地打量着你，手中的武器握得更紧了）"]}],
        "next": _T_LOW_REPUTATION_2(),
    }


static func _T_LOW_REPUTATION_2():
    return {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.B,
        "turn_hero_uid": HERO_UID,
        "content": [{"clist": ["你的名声在本王国已经臭了。领主大人有令，不得让你靠近村庄半步。"]}],
        "next": _T_HOSTILE_OPTIONS(),
    }


func get_current_dialogue_template()-> Dictionary:
    var _team_node = get_team_node()
    var _belong_country: String = ""
    if _team_node != null:
        _belong_country = _team_node.get_belong_country()


    var _player_hero_uid: String = SoldierUtils.get_player_hero_uid()
    var _lords = _get_lords_by_country(_belong_country)
    var _worst_rel: float = 0.0
    for _lord_uid in _lords:
        var _rel = WSData.get_hero_relation_value(_player_hero_uid, _lord_uid)
        if _rel < _worst_rel:
            _worst_rel = _rel

    if _worst_rel <= -20:
        return _T_LOW_REPUTATION()
    return _T_HOSTILE_GREETING()


func _get_lords_by_country(_country: String)-> Array:
    match _country:
        WSCountryData.COUNTRY_NAME_ENUM.LUCIANA:
            return["lord_hero_0001", "lord_hero_0002", "lord_hero_0009", "lord_hero_0010", "lord_hero_0014"]
        WSCountryData.COUNTRY_NAME_ENUM.EDRAS:
            return["lord_hero_0003", "lord_hero_0004", "lord_hero_0011", "lord_hero_0015"]
        WSCountryData.COUNTRY_NAME_ENUM.DORDAR:
            return["lord_hero_0005", "lord_hero_0006", "lord_hero_0012"]
        WSCountryData.COUNTRY_NAME_ENUM.HASKAL:
            return["lord_hero_0007", "lord_hero_0008", "lord_hero_0013"]
    return[]


func get_team_node():
    if b_team_dialogue_info.has("uid"):
        return TeamUtils.get_mw_team_node_by_id(b_team_dialogue_info.uid)
    return null


func get_hero_uid()-> String:
    var _team_node = get_team_node()
    if _team_node != null:
        return _team_node.json.get("leader_uid", "village_guard")
    return HERO_UID