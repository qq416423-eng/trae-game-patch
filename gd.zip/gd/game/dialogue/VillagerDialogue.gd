extends BaseDialogue


const AFTER_BATTLE_THANK_DIALOGUE_LOW: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "真没想到...像您这样的贵人, 会出手帮助我们这些草民...",
                "能得到大人的垂顾, 我们就知足了...村里人都不敢忘...",
                "大人今日能到场, 我们已不敢再奢求更多...谢谢您...",
                "大人如此身贵, 仍愿意为我们这些小民停步...感恩不尽...",
                "多谢大人肯来相助...我们这些粗人, 不知该说什么...只能不停道谢..."
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}


const AFTER_BATTLE_THANK_DIALOGUE_HIGH: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "大人救了我们一家老小...您就是我们的再生父母!",
                "我们这些草民本不配求助于您, 可您还是救了我们...大人真是仁义",
                "大人, 您愿意停下脚步救我们, 这份恩情我们一辈子都还不清...",
                "大人, 我们这次真是死里逃生...若不是您到来, 我们只怕连尸首都留不全了...",
                "大人, 您替我们挡下这一劫...我们全村的人都会铭记于此",
                "大人, 若是没有您, 我们只能等着被那帮恶人屠了...这情我们一辈子都不敢忘...",
                "大人，您的相助胜似再生之恩, 我们无以为报...",
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    if _relation_gain_after_battle_factor > 2:
        return AFTER_BATTLE_THANK_DIALOGUE_HIGH
    else:
        return AFTER_BATTLE_THANK_DIALOGUE_LOW

func get_battle_chat_charge()-> String:
    return[
        "跟你们拼了!",
        "为了我们的粮食不被夺走, 冲啊!",
        "你们这些强盗!",
        "拿好家伙! 和强盗拼了!",
        "让他们知道我们不是好欺负的!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "我...我杀人了?",
        "老天爷啊...",
        "是你逼我的！",
        "他终于倒下了...",
        "呼...呼...别再起来了!",
        "对不起, 我只想活下去..."
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "好痛! 我要死了吗?",
        "真疼啊!",
        "撑不住了...",
        "谁来帮帮我...",
        "救命! 血, 好多血!",
        "饶命啊!",
        "我还有老婆孩子...",
        "不要杀我啊...",
        "我投降!!!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "家里人...还在等我回去...",
        "这就是...出远门的下场吗...",
        "我扛不住了...",
        "你们快逃...",
        "告诉茱莉亚...别等我了...",
        "外面的世界...太可怕了...",
        "我的家当...埋在...村头大树下..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "有人来救我们了! 撑住!",
        "有人来救我们了! 稳住!",
        "大家挺住!",
        "守住牛车! 那是我们全村的希望!",
        "有救了!",
        "没想到居然有人愿意来救我们...",
        "不要伤害我们..."
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "大家别掉队",
        "伙计们, 跟上",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "总算活下来了...谢天谢地!",
        "呼, 回家以后我要喝三碗稀饭压惊",
        "噩梦结束了...",
        "我们...居然胜利了...",
        "我们...得救了...",
        "居然能捡回一条命...",
        "感谢神灵保佑"
    ].pick_random()