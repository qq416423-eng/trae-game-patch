extends BaseDialogue

const HERO_UID: = "wild_hero_0001"
const NEED_ITEM_UID: = "food_0007"
const NEED_ITEM_COUNT: = 12
const GIVE_ITEM_COUNT: = 12

static var GATHER_AND_HIRE: = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "了解",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "说说你的经历.",
                    ]
                }
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": [
                            "我是雷纳德, 一名漂泊十五年流浪的弓箭手，我并非一事无成而是将我获得的与我的时间全部奉献给了教会与同样遭遇的孩童，你若有能力我可以加入你的队伍.",
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.OPTION,
                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                    "option_list": [
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "了解招聘条件",
                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                            "content": [
                                {
                                    "clist": [
                                        "说说你加入的条件"
                                    ]
                                }
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.DIALOG,
                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                "content": [
                                    {
                                        "clist": [
                                            "避难所和教会为孩子们的营养发愁...你若能给我" + str(GIVE_ITEM_COUNT) + "份风干牛肉, 我就跟你走. 当然, 你得先有至少" + str(NEED_ITEM_COUNT) + "份才行."
                                        ]
                                    }
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.OPTION,
                                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                    "option_list": [
                                        {
                                            "otype": OPTION_TYPE_ENUM.HIRE,
                                            "oname": "给予" + str(GIVE_ITEM_COUNT) + "份风干牛肉并招募",
                                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                                            "content": [
                                                {
                                                    "custom_choose_func": {
                                                        "func_name": "check_player_has_item_min_count",
                                                        "params": [NEED_ITEM_UID, NEED_ITEM_COUNT],
                                                    },
                                                    "execute": DialogueConstants.EXECUTE_TYPE_ENUM.MINUS_ITEM,
                                                    "execute_item_uid": NEED_ITEM_UID,
                                                    "execute_value": GIVE_ITEM_COUNT,
                                                    "hire_hero_success": "wild_hero_0001",
                                                    "change_current_dialogue_flag": "HIRED",
                                                    "clist": [
                                                        "这些风干牛肉都给你, 跟我走吧."
                                                    ],
                                                    "next": {
                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "终于有了充足的肉供给! 很高兴能为您效力，感谢您的仁慈孩子们会永远记得您."
                                                                ]
                                                            }
                                                        ],
                                                    }
                                                },
                                                {
                                                    "custom_choose_func": {
                                                        "func_name": "check_player_has_item_min_count",
                                                        "params": [NEED_ITEM_UID, NEED_ITEM_COUNT],
                                                    },
                                                    "next": {
                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "你身上的风干牛肉不够" + str(NEED_ITEM_COUNT) + "份, 我可没法跟你."
                                                                ]
                                                            }
                                                        ],
                                                    },
                                                    "clist": []
                                                }
                                            ],
                                        },
                                        {
                                            "otype": OPTION_TYPE_ENUM.LEAVE,
                                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                                            "oname": "离开",
                                            "content": [
                                                {
                                                    "clist": [
                                                        "我再考虑考虑"
                                                    ]
                                                }
                                            ],
                                        }
                                    ]
                                },
                            }
                        }
                    ]
                }
            }
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "下次再说, 再见."
                    ]
                }
            ],
        }
    ]
}

static var FIRST_MEET: = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "交谈",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "你好, 有什么事吗?"
                    ]
                }
            ],
            "next": GATHER_AND_HIRE,
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "再见."
                    ]
                }
            ],
        }
    ]
}

static var MULT_MEET = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "交谈",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "我们又见面了."
                    ]
                }
            ],
            "next": GATHER_AND_HIRE,
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "下次再说."
                    ]
                }
            ],
        }
    ]
}


static var HIRED = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "我准备好了, 出发吧"
            ],
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if not _hero_json.has("current_dialogue_flag"):
        return FIRST_MEET

    return get(_hero_json.current_dialogue_flag)

func get_battle_chat_charge()-> String:
    return[
        "全军突击!",
        "冲锋!",
        "让他们见识一下我们的厉害!",
        "冲啊!",
        "为了荣耀!",
        "动作快! 一鼓作气拿下他们!"
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "前进!",
        "前进! 胜利就在前方!",
        "别掉队了!",
        "大家加快步伐!",
        "全员移动!",
        "保持阵型, 我们走!",
        "没时间犹豫了!"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "进攻!",
        "拔剑!",
        "让他们见识一下我们的厉害!",
        "击碎他们的防御!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你找错对手了",
        "我不会手软",
        "你本不必落得如此下场",
        "承让了!",
        "毫无威胁",
        "抱歉, 我有不能输的理由",
        "呼...下一个要死的是谁?"
    ]
    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "啧, 小伤而已",
        "该死! 这点小伤算不了什么!",
        "这点程度, 还打不倒我雷纳德!",
        "咳...",
        "竟然被这家伙伤到了!",
        "嘶...还没完呢!",
        "啧, 大意了...",
        "这种程度...",
        "啧...",
        "我还没倒下呢!"
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "抱歉...",
        "这就是...终点了吗...",
        "快走...",
        "可恶...",
        "咳...一定要...活下去...",
        "看来...这是最后一战了..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "干得漂亮! 我就知道我们是最强的!",
        "看吧, 没什么能阻挡我们!",
        "大家都还好吗?",
        "这才是我们该有的水准!",
        "回去得好好喝一杯!",
        "呼, 这是一场伟大的胜利!",
        "看吧, 只要我们齐心协力, 没什么能阻挡我们."
    ].pick_random()