extends BaseDialogue

const HERO_UID: = "wild_hero_0002"
const NEED_ITEM_UID: = "food_0028"
const NEED_ITEM_COUNT: = 2

static var GATHER_AND_HIRE: = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "了解",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "说说你的经历.",
                    ]
                }
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": [
                            "我是艾琳娜, 现在是一名流浪的剑士，我的家庭遭到盗贼的袭击养父母被杀死钱财被洗劫一空，因为父母的仁爰我有着十五年的贵族剑术经验，你若需要我可以成为你的人.",
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.OPTION,
                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                    "option_list": [
                        {
                            "otype": OPTION_TYPE_ENUM.TALK,
                            "oname": "了解招聘条件",
                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                            "content": [
                                {
                                    "clist": [
                                        "说说你加入的条件"
                                    ]
                                }
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.DIALOG,
                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                "content": [
                                    {
                                        "clist": [
                                            "我已经不知道多久没吃到白糖了...你给我" + str(NEED_ITEM_COUNT) + "份精致白糖, 我就跟你走."
                                        ]
                                    }
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.OPTION,
                                    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                    "option_list": [
                                        {
                                            "otype": OPTION_TYPE_ENUM.HIRE,
                                            "oname": "给予" + str(NEED_ITEM_COUNT) + "份精致白糖并招募",
                                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                                            "content": [
                                                {
                                                    "custom_choose_func": {
                                                        "func_name": "check_player_has_item_min_count",
                                                        "params": [NEED_ITEM_UID, NEED_ITEM_COUNT],
                                                    },
                                                    "execute": DialogueConstants.EXECUTE_TYPE_ENUM.MINUS_ITEM,
                                                    "execute_item_uid": NEED_ITEM_UID,
                                                    "execute_value": NEED_ITEM_COUNT,
                                                    "hire_hero_success": "wild_hero_0002",
                                                    "change_current_dialogue_flag": "HIRED",
                                                    "clist": [
                                                        "这些精致白糖都给你, 跟我走吧."
                                                    ],
                                                    "next": {
                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "谢谢您，让我回想到了曾经的感觉! 很高兴能为您效力."
                                                                ]
                                                            }
                                                        ],
                                                    }
                                                },
                                                {
                                                    "custom_choose_func": {
                                                        "func_name": "check_player_has_item_min_count",
                                                        "params": [NEED_ITEM_UID, NEED_ITEM_COUNT],
                                                    },
                                                    "next": {
                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "你身上的精致白糖不够" + str(NEED_ITEM_COUNT) + "份, 我可没法跟你."
                                                                ]
                                                            }
                                                        ],
                                                    },
                                                    "clist": []
                                                }
                                            ],
                                        },
                                        {
                                            "otype": OPTION_TYPE_ENUM.LEAVE,
                                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                                            "oname": "离开",
                                            "content": [
                                                {
                                                    "clist": [
                                                        "我再考虑考虑"
                                                    ]
                                                }
                                            ],
                                        }
                                    ]
                                },
                            }
                        }
                    ]
                }
            }
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "下次再说, 再见."
                    ]
                }
            ],
        }
    ]
}

static var FIRST_MEET: = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "交谈",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "你好, 有什么事吗?"
                    ]
                }
            ],
            "next": GATHER_AND_HIRE,
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "再见."
                    ]
                }
            ],
        }
    ]
}

static var MULT_MEET = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "交谈",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "我们又见面了."
                    ]
                }
            ],
            "next": GATHER_AND_HIRE,
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "下次再说."
                    ]
                }
            ],
        }
    ]
}


static var HIRED = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "我准备好了, 出发吧"
            ],
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if not _hero_json.has("current_dialogue_flag"):
        return FIRST_MEET

    return get(_hero_json.current_dialogue_flag)

func get_battle_chat_charge()-> String:
    return[
        "全军突击!",
        "全军突击! 不要浪费时间!",
        "全军突击! 别给敌人喘息的机会!",
        "冲锋!",
        "让他们见识一下我们的厉害!",
        "冲啊!",
        "为了荣耀!",
        "动作快! 一鼓作气拿下他们!"
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "前进!",
        "前进! 胜利就在前方!",
        "别掉队了!",
        "大家加快步伐!",
        "全员移动!",
        "保持阵型, 我们走!",
        "没时间犹豫了!"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "进攻!",
        "拔剑!",
        "让他们见识一下我们的厉害!",
        "击碎他们的防御!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你的动作到处是破绽",
        "安静地躺下吧",
        "别怪我, 这就是战场",
        "安静地睡吧",
        "这就是我们之间的差距",
        "你的动作...太慢了",
        "这种程度的对手, 太无趣了",
        "毫无威胁, 下一个",
        "浪费我的时间",
    ]
    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...",
        "嘶...还没完呢!",
        "啧, 大意了...",
        "这种程度...",
        "啧...",
        "还没到倒下的时候...",
        "坚持住...",
        "咳...没关系, 继续战斗",
        "别看我! 管好你自己的对手!",
        "该死! 我会加倍奉还的!",
        "这点程度还杀不了我!",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "抱歉...",
        "这就是...终点了吗...",
        "快走...",
        "可恶...",
        "咳...一定要...活下去...",
        "看来...这是最后一战了...",
        "真是不甘心...",
        "看来...到此为止了...",
        "这一天总会来的..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "结束了. 清点一下, 别漏掉战利品",
        "战斗结束",
        "这就是我们追求的胜利",
        "战斗结束! 迅速清点伤亡!",
        "干得不错",
        "别放松警惕, 检查四周环境"
    ].pick_random()