extends BaseDialogue

const HERO_UID: = "wild_hero_0004"
const INNKEEPER_HERO_UID = "minor_hero_0001"

static var FIRST_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "您好大人, 有什么吩咐吗?"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "您好女士, 有什么吩咐吗?"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "没事"
                        ]
                    }
                ],
            }
        ]
    }
}

static var MULT_MEET: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "您好, 大人! 很高兴又见到您, 有什么可以为您效劳的吗?"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "您好, 女士! 很高兴又见到您, 有什么可以为您效劳的吗?"
            ]
        }
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            "没事(微笑)"
                        ]
                    }
                ],
            }
        ]
    }
}


static var HIRED = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "我们出发吧(微笑)"
            ],
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if _hero_json.has("current_dialogue_flag") and _hero_json.current_dialogue_flag == "HIRED":
        return HIRED


    var _innkeeper_hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(INNKEEPER_HERO_UID)
    var _level: int = CommonUtils.get_json_field(_innkeeper_hero_json,["dialogue_save_info", "level"], 0)
    if _level >= 2:
        return MULT_MEET
    else:
        return FIRST_MEET

func get_battle_chat_charge()-> String:
    return[
        "全军出击! 解决这些不速之客!",
        "接招吧!"
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "前进!",
        "前进! 胜利就在前方!",
        "别掉队了!",
        "大家加快步伐!",
        "全员移动!",
        "保持阵型, 我们走!",
        "没时间犹豫了!"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "进攻!",
        "拔剑!",
        "让他们见识一下我们的厉害!",
        "击碎他们的防御!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "呼...比想象中要简单一些",
        "你的本事, 还不如酒馆里的闹事者",
        "这一单, 我收下了",
        "安静地躺下吧",
        "你该退场了",
        "已击败敌将",
        "账单结清了",
        "承蒙惠顾, 不过没有下次了",
        "搞定!"
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...",
        "啧, 大意了...",
        "啧...",
        "还没到倒下的时候...",
        "坚持住...",
        "咳...没关系, 继续战斗",
        "别担心..."
    ].pick_random()

func get_battle_chat_die()-> String:
    var _player_name: String = SoldierUtils.get_player_nickname()
    return[
        "对不起...",
        "我回不去了...",
        "原来...世界这么大...",
        "梦想...终究是碎了吗...",
        _player_name + "大人...",
        _player_name + "大人...对不起...",
        "姑姑...",
        "姑姑...对不起...",
        "视线...模糊了...",
        "好想...回家...",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "干得漂亮!",
        "呼, 大家都辛苦了",
    ].pick_random()