extends BaseDialogue

const HIRE_MONEY: = 5000
const HERO_UID: = "wild_hero_0005"

static var GATHER_AND_HIRE: = {
    "step_type": STEP_TYPE_ENUM.OPTION,
    "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
    "option_list": [
        {
            "otype": OPTION_TYPE_ENUM.TALK,
            "oname": "了解",
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "content": [
                {
                    "clist": [
                        "说说你的经历.",
                    ]
                }
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.B,
                "content": [
                    {
                        "clist": [
                            "我是[黑狼]小队的成员, 您或许听说过这个雇佣兵团, " +
                            "我们经常接手一些伏击/侦查的工作, 帮助很多雇主完成了一些困难的任务, " +
                            "只可惜, 不久前因为财物分配的问题, 小队解散了"
                        ]
                    }
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "我身经百战, 拥有高超的战斗技巧, 脸上的伤疤就是我久经沙场的证明, " +
                                "如今, 我独自闯荡, 如果您需要，我将成为您最值得信赖的战士"
                            ]
                        }
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.OPTION,
                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                        "option_list": [
                            {
                                "otype": OPTION_TYPE_ENUM.TALK,
                                "oname": "了解招聘条件",
                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                "content": [
                                    {
                                        "clist": [
                                            "说说你加入的条件"
                                        ]
                                    }
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                                    "content": [
                                        {
                                            "clist": [
                                                "我不会白白卖命, " + str(HIRE_MONEY) + "德里, 算是入队费, 只要您支付了这笔钱，我便会成为您最忠实的战士"
                                            ]
                                        }
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.OPTION,
                                        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                        "option_list": [
                                            {
                                                "otype": OPTION_TYPE_ENUM.HIRE,
                                                "oname": "招聘(花费" + str(HIRE_MONEY) + "德里)",
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "content": [
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH,
                                                        "condition_value": HIRE_MONEY,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "clist": [
                                                            "我再考虑考虑(德里不足)"
                                                        ]
                                                    },
                                                    {
                                                        "condition": CONTENT_CONDITION_ENUM.MONEY_ENOUGH,
                                                        "condition_value": HIRE_MONEY,
                                                        "condition_side": DialogueConstants.SPEAKER_ENUM.A,

                                                        "execute": DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY,
                                                        "execute_value": - HIRE_MONEY,
                                                        "execute_side": DialogueConstants.SPEAKER_ENUM.A,
                                                        "hire_hero_success": "wild_hero_0005",
                                                        "change_current_dialogue_flag": "HIRED",
                                                        "clist": [
                                                            "你开出的条件我接受了. 拿着这笔钱"
                                                        ],
                                                        "next": {
                                                            "step_type": STEP_TYPE_ENUM.DIALOG,
                                                            "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                            "content": [
                                                                {
                                                                    "clist": [
                                                                        "很高兴能为您效力, 我会用行动证明我值这笔钱"
                                                                    ]
                                                                }
                                                            ],
                                                        }
                                                    }
                                                ],
                                            },
                                            {
                                                "otype": OPTION_TYPE_ENUM.LEAVE,
                                                "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                "oname": "离开",
                                                "content": [
                                                    {
                                                        "clist": [
                                                            "我再考虑考虑"
                                                        ]
                                                    }
                                                ],
                                            }
                                        ]
                                    },
                                }
                            }
                        ]
                    }
                }
            }
        },
        {
            "otype": OPTION_TYPE_ENUM.LEAVE,
            "turn": DialogueConstants.SPEAKER_ENUM.A,
            "oname": "离开",
            "content": [
                {
                    "clist": [
                        "下次再说, 再见."
                    ]
                }
            ],
        }
    ]
}

static var FIRST_MEET: = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "change_current_dialogue_flag": "MULT_MEET",
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "尊敬的大人, 您看起来气度非凡, 不知是否需要一名经验丰富的战士?"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "尊贵的女士, 您看起来气度非凡, 不知是否需要一名经验丰富的战士?"
            ]
        }
    ],
    "next": GATHER_AND_HIRE,
}

static var MULT_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "尊敬的大人, 我们又见面了. 上次的提议您是否还在考虑?"
            ]
        },
        {
            "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
            "condition_side": DialogueConstants.SPEAKER_ENUM.A,
            "clist": [
                "尊贵的女士, 我们又见面了. 上次的提议您是否还在考虑?"
            ]
        }
    ],
    "next": GATHER_AND_HIRE,
}


static var HIRED = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "我准备好了, 出发吧"
            ],
        }
    ],
}

func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if not _hero_json.has("current_dialogue_flag"):
        return FIRST_MEET

    return get(_hero_json.current_dialogue_flag)

func get_battle_chat_charge()-> String:
    return[
        "突袭开始!",
        "享受这最后的时刻吧!",
        "发起突击! 不要留下活口!"
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "移动! 保持警戒",
        "这就是黑狼的节奏, 跟上!",
        "大家加快步伐!",
        "全员移动!",
        "保持阵型, 我们走!",
        "没时间犹豫了!"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "锁定猎物, 动手!",
        "进攻!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你的动作, 漏洞百出",
        "黑狼从不失手",
        "已击败敌将",
        "碰到了我, 你的命不好",
        "你已经解脱了",
        "看来我的技巧还没生锈",
        "下一个, 我还没出汗呢",
        "这就是身经百战的实力",
        "我们之间的实力差距, 显而易见",
        "死在前黑狼成员的手下, 你不冤",
        "你的动作太迟钝了",
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "啧...这道疤会成为新的荣耀!",
        "这点小伤, 比当年差远了",
        "咳...还能坚持",
        "还没到倒下的时候!",
        "黑狼成员不会轻易倒下!",
        "咳...",
        "啧, 大意了...",
        "啧...",
        "还没咬断敌人的喉咙, 我可不会死",
        "呼吸还没乱..."
    ].pick_random()

func get_battle_chat_die()-> String:

    return[
        "呃啊!",
        "看来...终点...在这里...",
        "这就是...黑狼的归宿吗...",
        "格里芬...我来找你了...",
        "格里芬...酒...准备好...",
        "莎拉...",
        "抱歉...莎拉...",
        "至少...",
        "本不该于此...",
        "至少...我证明了我的价值...",
        "这一单...赔上了命..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "收工, 开始清算战果",
        "清理战场, 别漏掉任何战利品"
    ].pick_random()