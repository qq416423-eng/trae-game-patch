extends BaseDialogue

func get_battle_chat_charge()-> String:
    return[
        "开始行动了!",
        "杀光他们!",
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "如你所愿, 主人",
        "正在移动到杀戮位置",
        "移动! 保持警戒",
        "没时间犹豫了!"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "锁定猎物, 动手!",
        "收割时刻",
        "别眨眼，你们会错过自己的死亡",
        "我渴望鲜血"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "你的动作, 漏洞百出",
        "碰到了我, 你的命不好",
        "你已经解脱了",
        "我们之间的实力差距, 显而易见",
        "你的动作太迟钝了",
        "你太慢了",
        "你是第几个? 我懒得记了",
        "鲜血的味道",
        "穿透喉咙的声音, 真悦耳",
        "安静的死掉吧",
        "我还没杀够",
        "你的命我拿走了",
        "感谢我吧, 让你死的这么干脆",
        "比我想象中还要精准",
        "你以为你能躲得掉吗?",
        "毫无美感的死亡"
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...",
        "啧, 大意了...",
        "啧...",
        "呼吸还没乱...",
        "见鬼, 流血了",
        "我会加倍还给你的!",
        "我还没输!",
        "血腥味...",
        "这种感觉..."
    ].pick_random()

func get_battle_chat_die()-> String:

    return[
        "终究还是...",
        "这就是...偷生者的结局吗...",
        "终于...",
        "真是...糟透了...",
        "至少...没死在笼子里...",
        "主人...对不起",
        "终究还是慢了一步...",
        "这种死法...",
        "倒也不算太坏...",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "完美的收割. 现在, 该分战利品了",
        "呼...活着的滋味",
    ].pick_random()