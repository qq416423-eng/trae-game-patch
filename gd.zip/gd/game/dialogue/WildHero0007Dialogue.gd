extends BaseDialogue

const HERO_UID: = "wild_hero_0007"

static var MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "content": [
        {
            "clist": [
                "(整理战利品时, 发现一块巨石后面有动静)"
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.DIALOG,
        "turn": DialogueConstants.SPEAKER_ENUM.A,
        "content": [
            {
                "clist": [
                    "是谁在那? 出来! 否则别怪我不客气!"
                ]
            },
        ],
        "next": {
            "step_type": STEP_TYPE_ENUM.DIALOG,
            "turn": DialogueConstants.SPEAKER_ENUM.B,
            "content": [
                {
                    "clist": [
                        "不要杀我啊!!!(抱头探出) 我不是强盗!!"
                    ]
                },
            ],
            "next": {
                "step_type": STEP_TYPE_ENUM.DIALOG,
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "(仔细打量她, 发现她虽然带了脚铐, 但是身上没有被虐待的痕迹)"
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                    "content": [
                        {
                            "clist": [
                                "老实交代, 你是做什么的?!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                        "content": [
                            {
                                "condition": CONTENT_CONDITION_ENUM.LEADER_IS_MALE,
                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                "clist": [
                                    "大人, 我是被他们绑架到这的! 连同我的父亲, " \
                                    + "由于我们父女会做一些工匠活, 所以被强盗安排做一些修缮, 制作陷阱之类的工作, " \
                                    + "所幸没有被当奴隶处理"
                                ]
                            },
                            {
                                "condition": CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE,
                                "condition_side": DialogueConstants.SPEAKER_ENUM.A,
                                "clist": [
                                    "尊贵的女士, 我是被他们绑架到这的! 连同我的父亲, " \
                                    + "由于我们父女会做一些工匠活, 所以被强盗安排做一些修缮, 制作陷阱之类的活, " \
                                    + "所幸没有被当奴隶处理"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.DIALOG,
                            "turn": DialogueConstants.SPEAKER_ENUM.A,
                            "content": [
                                {
                                    "clist": [
                                        "你的父亲呢?"
                                    ]
                                },
                            ],
                            "next": {
                                "step_type": STEP_TYPE_ENUM.DIALOG,
                                "turn": DialogueConstants.SPEAKER_ENUM.B,
                                "content": [
                                    {
                                        "clist": [
                                            "他在几个月前, 被强盗带走了...(低头片刻) 听说是去别的营地做建设工作"
                                        ]
                                    },
                                ],
                                "next": {
                                    "step_type": STEP_TYPE_ENUM.DIALOG,
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                "来证明你没有说谎. 洞口大门是你做的吧? 用的什么材料和结构?"
                                            ]
                                        },
                                    ],
                                    "next": {
                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                        "content": [
                                            {
                                                "clist": [
                                                    "确实是父亲和我一起制作的, 它的框架用的是当地的橡木, 坚固耐用. 外面还覆盖了一层生铁板, 用铆钉加固. 内部结构(balabala)..."
                                                ]
                                            },
                                        ],
                                        "next": {
                                            "step_type": STEP_TYPE_ENUM.OPTION,
                                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_MY_NEXT_STEPS,
                                            "option_list": [
                                                {
                                                    "otype": OPTION_TYPE_ENUM.HIRE,
                                                    "oname": "招聘",
                                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                                    "content": [
                                                        {
                                                            "clist": [
                                                                "很好, 要不加入我的队伍吧, 我们这正好缺一个工匠, 旅途中还能顺便寻找你的父亲"
                                                            ]
                                                        },
                                                    ],
                                                    "next": {
                                                        "step_type": STEP_TYPE_ENUM.DIALOG,
                                                        "turn": DialogueConstants.SPEAKER_ENUM.B,
                                                        "hire_hero_success": HERO_UID,
                                                        "content": [
                                                            {
                                                                "clist": [
                                                                    "请让我加入! 我会证明自己的价值!"
                                                                ]
                                                            },
                                                        ],
                                                    },
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        },
                    }
                }
            }
        }
    }
}

func get_hero_uid()-> String:
    return HERO_UID

func get_current_dialogue_template()-> Dictionary:
    var _hero_json = SoldierUtils.get_json_by_hero_uid(HERO_UID)
    if not _hero_json.has("current_dialogue_flag"):
        return MEET

    return get(_hero_json.current_dialogue_flag)

func get_battle_chat_charge()-> String:
    return[
        "开始行动了!",
        "跟着我冲!"
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "向目标推进",
        "出发吧"
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "尝尝工匠的愤怒!",
        "我也能战斗!"
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "确认击败对手",
        "呼, 这比修大门累多了",
        "已击败敌将",
        "父亲...我变强了",
        "废品就该待在废品堆里",
        "看来你的防具并不可靠",
        "这一击的受力点刚刚好!",
        "就像拆掉一扇烂门一样容易",
        "搞定!",
        "下一个需要拆解的是谁?"
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "咳...",
        "啧, 大意了...",
        "啧...",
        "我还没输...",
        "哎哟...好疼",
        "这种程度的打击...",
        "嘶...真疼...",
        "我的骨头...",
    ].pick_random()

func get_battle_chat_die()-> String:

    return[
        "终究还是...",
        "真是...糟透了...",
        "终于...能休息了吗...",
        "父亲...赫尔加...尽力了...",
        "对不起, 老大...",
        "意识...开始模糊了...",
        "没能...找到父亲...",
        "原来...这就是死亡...",
        "这就是...我的归宿吗...",
        "父亲...",
        "老大...请原谅我...",
        "老大...",
        "通往天堂的大门...也是橡木做的吗..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住!"
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "赢了! 大家快检查一下损耗!",
        "大家都辛苦了",
        "干得漂亮! 这才是完美的配合"
    ].pick_random()