extends BaseDialogue

const HERO_UID: = "wild_hero_0010"

static var MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "双头鲨从不留活口, 你们是自己跳海, 还是让我帮你们?",
                "海上的规矩很简单——要么交钱, 要么喂鲨鱼.",
                "凯尔的船队从不空手而归, 你们看起来值不少钱.",
                "哈哈, 又有送上门的肥羊! 弟兄们, 准备接客!",
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "迎战",
                "content": [
                    {
                        "clist": [
                            "那就看看双头鲨的牙有多硬!",
                            "废话少说! 开战吧!",
                            "凯尔, 今天就是你的船沉没的日子!",
                            "海寇的末日到了!"
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.FLEE,
                "oname": "逃跑",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                        ]
                    }
                ]
            }
        ]
    }
}

static var FRIENDLY_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "哈哈, 自家兄弟! 凯尔的船随时欢迎你.",
                "兄弟, 来喝一杯? 刚抢了一批好酒.",
                "自己人, 有什么事尽管说!",
                "哈哈, 同伴! 双头鲨的牙齿只咬敌人."
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_can_join_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我想加入你们.",
                            "让我也入伙吧.",
                            "带我一个, 我不会拖后腿的."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_rel_bad_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_rel_bad_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_recent_leave_country_refuse_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_recent_leave_country_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_not_enough_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "get_player_reputation_value_int",
                                },
                                {
                                    "func_name": "get_join_country_need_reputation_value"
                                }
                            ],
                            "clist": [
                                "就凭你? 声望才 [#{0}], 至少要 [#{1}] 才有资格跟老子混.",
                                "声望 [#{0}]? 连街头的小混混都不如. 滚!",
                                "想入伙? 先把声望刷到 [#{1}] 再来吧, 现在的你还不够格."
                            ]
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_enough_to_join_country",
                            },
                            "clist": [
                                "行, 看你小子还算有点本事, 老子收你了!",
                                "哈哈! 好极了, 多一个人多一份力, 欢迎入伙!",
                                "不错不错, 以后跟着老子, 保你吃香喝辣!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_choose_func": {
                                    "func_name": "check_player_reputation_enough_to_join_country",
                                },
                                "custom_func": {
                                    "func_name": "player_join_b_kingdom",
                                },
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "clist": [
                                    "(我正式加入了 [#{0}], 成为其中一员)",
                                    "(从今往后, 我就是 [#{0}] 的人了)",
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "退出阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我要退出阵营.",
                            "我不想再跟着你们干了.",
                            "我要离开这里."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哼! 想走? 老子从来不强留人, 但背叛的代价你最好想清楚!",
                                "滚吧! 没了你老子照样能在这片荒野上横着走!",
                                "走? 可以! 但别让我再看到你, 否则老子的银刀可不长眼!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_func": {
                                    "func_name": "player_leave_black_fang",
                                },
                                "clist": [
                                    "(我正式退出了强寇阵营)",
                                    "(从今往后, 我与强寇阵营再无瓜葛)"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "can_recruit_boss_elite"
                },
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "招募精英(#{0}德里)",
                "str_from_func": [
                    {
                        "func_name": "get_boss_recruit_cost",
                    }
                ],
                "custom_func": {
                    "func_name": "handle_boss_recruit_elite",
                },
                "content": [
                    {
                        "clist": [
                            "把最精锐的弟兄借给我, 强寇需要他们!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

static var REACTIVE_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "凯尔正忙着分赃, 没空搭理闲人.",
                "有事快说, 别耽误我清点战利品.",
                "你不是海上的熟面孔, 找我什么事?",
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_can_join_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我想加入你们.",
                            "让我也入伙吧.",
                            "带我一个, 我不会拖后腿的."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_rel_bad_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_rel_bad_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_recent_leave_country_refuse_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_recent_leave_country_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_not_enough_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "get_player_reputation_value_int",
                                },
                                {
                                    "func_name": "get_join_country_need_reputation_value"
                                }
                            ],
                            "clist": [
                                "就凭你? 声望才 [#{0}], 至少要 [#{1}] 才有资格跟老子混.",
                                "声望 [#{0}]? 连街头的小混混都不如. 滚!",
                                "想入伙? 先把声望刷到 [#{1}] 再来吧, 现在的你还不够格."
                            ]
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_enough_to_join_country",
                            },
                            "clist": [
                                "行, 看你小子还算有点本事, 老子收你了!",
                                "哈哈! 好极了, 多一个人多一份力, 欢迎入伙!",
                                "不错不错, 以后跟着老子, 保你吃香喝辣!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_choose_func": {
                                    "func_name": "check_player_reputation_enough_to_join_country",
                                },
                                "custom_func": {
                                    "func_name": "player_join_b_kingdom",
                                },
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "clist": [
                                    "(我正式加入了 [#{0}], 成为其中一员)",
                                    "(从今往后, 我就是 [#{0}] 的人了)",
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "退出阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我要退出阵营.",
                            "我不想再跟着你们干了.",
                            "我要离开这里."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哼! 想走? 老子从来不强留人, 但背叛的代价你最好想清楚!",
                                "滚吧! 没了你老子照样能在这片海上横着走!",
                                "走? 可以! 但别让我再看到你, 否则我的船锚可不长眼!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_func": {
                                    "func_name": "player_leave_black_fang",
                                },
                                "clist": [
                                    "(我正式退出了强寇阵营)",
                                    "(从今往后, 我与强寇阵营再无瓜葛)"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "凯尔! 你的海盗生涯到此为止了!",
                            "双头鲨? 我今天就让你变成死鲨鱼!",
                            "海寇的末日到了!",
                            "受死吧, 凯尔!",
                        ]
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

static var REACTIVE_MEET_NO_ATTACK = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "凯尔正忙着分赃, 没空搭理闲人.",
                "有事快说, 别耽误我清点战利品.",
                "你不是海上的熟面孔, 找我什么事?",
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_can_join_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我想加入你们.",
                            "让我也入伙吧.",
                            "带我一个, 我不会拖后腿的."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_rel_bad_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_rel_bad_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_recent_leave_country_refuse_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_recent_leave_country_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_not_enough_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "get_player_reputation_value_int",
                                },
                                {
                                    "func_name": "get_join_country_need_reputation_value"
                                }
                            ],
                            "clist": [
                                "就凭你? 声望才 [#{0}], 至少要 [#{1}] 才有资格跟老子混.",
                                "声望 [#{0}]? 连街头的小混混都不如. 滚!",
                                "想入伙? 先把声望刷到 [#{1}] 再来吧, 现在的你还不够格."
                            ]
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_enough_to_join_country",
                            },
                            "clist": [
                                "行, 看你小子还算有点本事, 老子收你了!",
                                "哈哈! 好极了, 多一个人多一份力, 欢迎入伙!",
                                "不错不错, 以后跟着老子, 保你吃香喝辣!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_choose_func": {
                                    "func_name": "check_player_reputation_enough_to_join_country",
                                },
                                "custom_func": {
                                    "func_name": "player_join_b_kingdom",
                                },
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "clist": [
                                    "(我正式加入了 [#{0}], 成为其中一员)",
                                    "(从今往后, 我就是 [#{0}] 的人了)",
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "退出阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我要退出阵营.",
                            "我不想再跟着你们干了.",
                            "我要离开这里."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哼! 想走? 老子从来不强留人, 但背叛的代价你最好想清楚!",
                                "滚吧! 没了你老子照样能在这片海上横着走!",
                                "走? 可以! 但别让我再看到你, 否则我的船锚可不长眼!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_func": {
                                    "func_name": "player_leave_black_fang",
                                },
                                "clist": [
                                    "(我正式退出了强寇阵营)",
                                    "(从今往后, 我与强寇阵营再无瓜葛)"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

func get_hero_uid()-> String:
    return HERO_UID

func get_battle_chat_charge()-> String:
    return[
        "全军突击!",
        "登船! 抢光他们!",
        "海上的规矩, 强者为王!",
        "别让他们跳水逃了!",
    ].pick_random()

func get_battle_chat_move()-> String:
    return["前进!",].pick_random()

func get_battle_chat_attack()-> String:
    return["进攻!",].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    return[
        "喂鲨鱼去吧",
        "不堪一击",
        "又一个不知天高地厚的",
        "海上的规矩, 弱者淘汰",
    ].pick_random()

func get_battle_chat_injured()-> String:
    return[
        "该死...",
        "有点本事...",
        "还没完!",
        "你惹怒双头鲨了!",
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "怎么可能...",
        "我的...船队...",
        "不...",
        "这片海...竟然...",
        "可恶...",
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return["援军来了! 撑住!",].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "包围他们!",
        "别让他们跑了!",
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return["守住阵线!", "别退后!", "守好位置!",].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "哈哈! 双头鲨从不空手而归!",
        "把值钱的东西都搬上船!",
    ].pick_random()

func get_current_dialogue_template()-> Dictionary:
    if DialogueCustomUtils.player_is_in_black_fang():
        return FRIENDLY_MEET
    if b_team_dialogue_info.is_chase_player:
        return MEET
    return REACTIVE_MEET

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "凯尔, 双头鲨也有搁浅的一天.",
            "你的海盗生涯到此为止了.",
        ]
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    return[
        [
            "没想到...我也有被俘虏的一天...",
            "海上的风...终究停了吗...",
        ]
    ]

func get_hero_wait_for_release_dialogue_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 开个价吧, 让我回海上.",
            "[" + _player_name + "], 你要多少才肯放我走?",
        ]
    ]

func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "这 [#{0}] 德里够你买一艘新船了, 放我走, 如何?",
    ]

func get_hero_released_by_ransom_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()
    return[
        [
            "[" + _player_name + "], 海上再见, 可就不是这个价了.",
            "再会."
        ],
    ]

func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 足够换我的自由了. 如何?"
    ]