extends BaseDialogue

const HERO_UID: = "wild_hero_0012"

static var MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "你...有不错的骨架, 适合陈列在我的铁笼里",
                "我有预感, 你会成为我最引以为傲的...商品",
                "别紧张, 保持你肌肉的张力, 那样死后的标本才更有力量感",
                "把武器放下, 弄伤了皮肤, 你的身价可是会大打折扣的",
                "今天我的收藏馆正好缺几件像样的展品, 你们来的正是时候",
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.ENEMY_PREPARES_ATTACK,
        "option_list": [
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "迎战",
                "content": [
                    {
                        "clist": [
                            "收起你那恶心的眼神! 开战吧!",
                            "废话少说! 开战吧!",
                            "别做梦了, 图格. 你的锁链今天就会崩断!",
                            "进攻! 把这个玩弄生命的魔鬼送进地狱!"
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.FLEE,
                "oname": "逃跑",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_FLEE
                        ]
                    }
                ]
            }
        ]
    }
}

static var FRIENDLY_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "呵呵, 是自己人. 图格的铁笼只对敌人打开.",
                "伙计, 有什么新鲜事要跟老子分享吗?",
                "来得正好, 我刚入手了几件不错的藏品, 给你开开眼.",
                "哈哈, 同伴! 这片草原上, 图格只认自己人."
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_can_join_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我想加入你们.",
                            "让我也入伙吧.",
                            "带我一个, 我不会拖后腿的."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_rel_bad_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_rel_bad_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_recent_leave_country_refuse_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_recent_leave_country_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_not_enough_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "get_player_reputation_value_int",
                                },
                                {
                                    "func_name": "get_join_country_need_reputation_value"
                                }
                            ],
                            "clist": [
                                "就凭你? 声望才 [#{0}], 至少要 [#{1}] 才有资格跟老子混.",
                                "声望 [#{0}]? 连街头的小混混都不如. 滚!",
                                "想入伙? 先把声望刷到 [#{1}] 再来吧, 现在的你还不够格."
                            ]
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_enough_to_join_country",
                            },
                            "clist": [
                                "行, 看你小子还算有点本事, 老子收你了!",
                                "哈哈! 好极了, 多一个人多一份力, 欢迎入伙!",
                                "不错不错, 以后跟着老子, 保你吃香喝辣!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_choose_func": {
                                    "func_name": "check_player_reputation_enough_to_join_country",
                                },
                                "custom_func": {
                                    "func_name": "player_join_b_kingdom",
                                },
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "clist": [
                                    "(我正式加入了 [#{0}], 成为其中一员)",
                                    "(从今往后, 我就是 [#{0}] 的人了)",
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "退出阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我要退出阵营.",
                            "我不想再跟着你们干了.",
                            "我要离开这里."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哼! 想走? 老子从来不强留人, 但背叛的代价你最好想清楚!",
                                "滚吧! 没了你老子照样能在这片荒野上横着走!",
                                "走? 可以! 但别让我再看到你, 否则老子的银刀可不长眼!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_func": {
                                    "func_name": "player_leave_black_fang",
                                },
                                "clist": [
                                    "(我正式退出了强寇阵营)",
                                    "(从今往后, 我与强寇阵营再无瓜葛)"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "can_recruit_boss_elite"
                },
                "otype": OPTION_TYPE_ENUM.HIRE,
                "oname": "招募精英(#{0}德里)",
                "str_from_func": [
                    {
                        "func_name": "get_boss_recruit_cost",
                    }
                ],
                "custom_func": {
                    "func_name": "handle_boss_recruit_elite",
                },
                "content": [
                    {
                        "clist": [
                            "把最精锐的弟兄借给我, 强寇需要他们!",
                        ]
                    }
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

static var REACTIVE_MEET = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "我正在欣赏我最新的藏品, 你却在这个时候跳出来扫兴?",
                "停下, 我不喜欢被残次品围观",
                "这一带还没人敢挡我图格的路, 你是想体验一下苦役的滋味吗?",
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_can_join_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我想加入你们.",
                            "让我也入伙吧.",
                            "带我一个, 我不会拖后腿的."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_rel_bad_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_rel_bad_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_recent_leave_country_refuse_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_recent_leave_country_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_not_enough_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "get_player_reputation_value_int",
                                },
                                {
                                    "func_name": "get_join_country_need_reputation_value"
                                }
                            ],
                            "clist": [
                                "就凭你? 声望才 [#{0}], 至少要 [#{1}] 才有资格跟老子混.",
                                "声望 [#{0}]? 连街头的小混混都不如. 滚!",
                                "想入伙? 先把声望刷到 [#{1}] 再来吧, 现在的你还不够格."
                            ]
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_enough_to_join_country",
                            },
                            "clist": [
                                "行, 看你小子还算有点本事, 老子收你了!",
                                "哈哈! 好极了, 多一个人多一份力, 欢迎入伙!",
                                "不错不错, 以后跟着老子, 保你吃香喝辣!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_choose_func": {
                                    "func_name": "check_player_reputation_enough_to_join_country",
                                },
                                "custom_func": {
                                    "func_name": "player_join_b_kingdom",
                                },
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "clist": [
                                    "(我正式加入了 [#{0}], 成为其中一员)",
                                    "(从今往后, 我就是 [#{0}] 的人了)",
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "退出阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我要退出阵营.",
                            "我不想再跟着你们干了.",
                            "我要离开这里."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哼! 想走? 老子从来不强留人, 但背叛的代价你最好想清楚!",
                                "滚吧! 没了你老子照样能在这片荒野上横着走!",
                                "走? 可以! 但别让我再看到你, 否则老子的银刀可不长眼!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_func": {
                                    "func_name": "player_leave_black_fang",
                                },
                                "clist": [
                                    "(我正式退出了强寇阵营)",
                                    "(从今往后, 我与强寇阵营再无瓜葛)"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "图格! 你的收藏生涯到此为止了!",
                            "我直接送你下地狱吧, 那里有更多的\"收藏品\"等着你",
                            "你这种玩弄生命的败类, 不配得到救赎!",
                            "草原的鹰在看着你, 图格, 它们等着吃你的腐肉",
                            "图格, 你的艺术该谢幕了",
                        ]
                    },
                ]
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

static var REACTIVE_MEET_NO_ATTACK = {
    "step_type": STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.B,
    "content": [
        {
            "clist": [
                "我正在欣赏我最新的藏品, 你却在这个时候跳出来扫兴?",
                "停下, 我不喜欢被残次品围观",
                "这一带还没人敢挡我图格的路, 你是想体验一下苦役的滋味吗?",
            ]
        },
    ],
    "next": {
        "step_type": STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "custom_choose_func": {
                    "func_name": "player_can_join_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.JOIN_COUNTRY,
                "oname": "加入阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我想加入你们.",
                            "让我也入伙吧.",
                            "带我一个, 我不会拖后腿的."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_rel_bad_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_rel_bad_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_recent_leave_country_refuse_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "king_reject_join_recent_leave_country_dialogue",
                                }
                            ],
                            "clist": ["#{0}"],
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_not_enough_to_join_country",
                            },
                            "str_from_func": [
                                {
                                    "func_name": "get_player_reputation_value_int",
                                },
                                {
                                    "func_name": "get_join_country_need_reputation_value"
                                }
                            ],
                            "clist": [
                                "就凭你? 声望才 [#{0}], 至少要 [#{1}] 才有资格跟老子混.",
                                "声望 [#{0}]? 连街头的小混混都不如. 滚!",
                                "想入伙? 先把声望刷到 [#{1}] 再来吧, 现在的你还不够格."
                            ]
                        },
                        {
                            "custom_choose_func": {
                                "func_name": "check_player_reputation_enough_to_join_country",
                            },
                            "clist": [
                                "行, 看你小子还算有点本事, 老子收你了!",
                                "哈哈! 好极了, 多一个人多一份力, 欢迎入伙!",
                                "不错不错, 以后跟着老子, 保你吃香喝辣!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_choose_func": {
                                    "func_name": "check_player_reputation_enough_to_join_country",
                                },
                                "custom_func": {
                                    "func_name": "player_join_b_kingdom",
                                },
                                "str_from_func": [
                                    {
                                        "func_name": "get_b_country_name",
                                    }
                                ],
                                "clist": [
                                    "(我正式加入了 [#{0}], 成为其中一员)",
                                    "(从今往后, 我就是 [#{0}] 的人了)",
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "custom_choose_func": {
                    "func_name": "player_is_in_black_fang",
                },
                "otype": OPTION_TYPE_ENUM.TALK,
                "oname": "退出阵营",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "我要退出阵营.",
                            "我不想再跟着你们干了.",
                            "我要离开这里."
                        ]
                    },
                ],
                "next": {
                    "step_type": STEP_TYPE_ENUM.DIALOG,
                    "turn": DialogueConstants.SPEAKER_ENUM.B,
                    "content": [
                        {
                            "clist": [
                                "哼! 想走? 老子从来不强留人, 但背叛的代价你最好想清楚!",
                                "滚吧! 没了你老子照样能在这片荒野上横着走!",
                                "走? 可以! 但别让我再看到你, 否则老子的银刀可不长眼!"
                            ]
                        },
                    ],
                    "next": {
                        "step_type": STEP_TYPE_ENUM.DIALOG,
                        "turn": DialogueConstants.SPEAKER_ENUM.A,
                        "content": [
                            {
                                "custom_func": {
                                    "func_name": "player_leave_black_fang",
                                },
                                "clist": [
                                    "(我正式退出了强寇阵营)",
                                    "(从今往后, 我与强寇阵营再无瓜葛)"
                                ]
                            },
                        ],
                        "next": {
                            "step_type": STEP_TYPE_ENUM.OPTION,
                            "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
                            "option_list": [
                                {
                                    "otype": OPTION_TYPE_ENUM.LEAVE,
                                    "oname": "离开",
                                    "turn": DialogueConstants.SPEAKER_ENUM.A,
                                    "content": [
                                        {
                                            "clist": [
                                                DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            {
                "otype": OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "custom_func": {
                    "func_name": "b_team_walk_away",
                },
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}

func get_hero_uid()-> String:
    return HERO_UID

func get_battle_chat_charge()-> String:
    return[
        "全军突击!",
        "这些都是上等的商品!",
        "我要把他们一个个关进最坚固的笼子里",
        "看看今天能捕获多少健壮的牲口!",
        "别杀他们! 活着的奴隶才值大价钱!",
        "开始捕猎游戏!",
        "别让这些值钱的宝贝溜了!",
        "动作轻点, 弄断了手脚可就不保值了!",
    ].pick_random()


func get_battle_chat_move()-> String:
    return[
        "前进!",
    ].pick_random()


func get_battle_chat_attack()-> String:
    return[
        "进攻!",
    ].pick_random()

func get_battle_chat_kill_hero(_target_hero_name: String)-> String:
    var _list: = [
        "啧，用力过猛",
        "报废了一个",
        "残次品就该被处理掉",
        "你的骨架...确实很漂亮",
        "脆弱的玩物",
        "这么快就坏了",
        "真遗憾",
        "一件不合格的艺术品",
        "没用的废物",
        "真可惜",
        "我还没玩够呢"
    ]






    return _list.pick_random()

func get_battle_chat_injured()-> String:
    return[
        "该死...",
        "咳...这种野性",
        "根本不算什么...",
        "还没完呢!",
        "我会亲手给你戴上枷锁!",
        "很好, 你成功激怒了我!",
        "咳...居然流血了...",
        "你会为此多干十年的苦役!",
        "嘶...这种挣扎才有意思",
        "敢伤你的主人?",
        "你的身价倍增了!",
        "啧..."
    ].pick_random()

func get_battle_chat_die()-> String:
    return[
        "竟然...轮到我...",
        "不...我还没...",
        "咳...锁链...断了...",
        "我的...收藏馆...",
        "竟然被...猎物...",
        "可恶...",
        "为什么...",
        "不...",
        "我的艺术...还没完成...",
        "这种死法..."
    ].pick_random()

func get_battle_chat_ai_ally_defensive_chat()-> String:
    return[
        "援军来了! 撑住!",
    ].pick_random()

func get_battle_chat_ai_advancing_attack_chat()-> String:
    return[
        "稳步推进!",
        "保持狩猎阵型, 稳步合围!",
        "像牧羊一样把他们赶进死角!",
        "不要乱, 慢慢压缩他们的生存空间!",
        "别惊动了这些上等货, 温柔地包围他们",
        "慢慢前进, 我要看到他们绝望的眼神",
        "把网撒开, 一点点把他们往笼子里赶!"
    ].pick_random()

func get_battle_chat_ai_enemy_defensive_chat()-> String:
    return[
        "守住阵线! 要是跑了一个, 我就拿你们关进笼子里!",
        "守住阵线! 别退后!",
        "让他们过来, 落进陷阱的猎物才最好捕捉",
        "等这些不知死活的牲口自己撞上来",
        "别乱动! 保持阵型",
        "守好位置!",
        "别急着冲锋, 等他们踏入我的锁链范围!",
        "守住! 谁敢打乱我的阵法, 我就敲碎谁的膝盖!",
    ].pick_random()

func get_battle_chat_vectory()-> String:
    return[
        "哈哈! 全带走!",
        "今天的收获不错!",
        "我的铁笼又要热闹起来了!",
        "强者拥有锁链, 弱者拥有项圈",
        "清点一下成色, 好的送到我的私人地牢去",
        "动作快点! 给这些新人打上我的烙印",
    ].pick_random()

func get_current_dialogue_template()-> Dictionary:
    if DialogueCustomUtils.player_is_in_black_fang():
        return FRIENDLY_MEET
    if b_team_dialogue_info.is_chase_player:
        return MEET
    return REACTIVE_MEET

func get_captured_dialogue_after_battle_player_content()-> Array:
    return[
        [
            "你的收藏生涯到此为止了, 图格.",
            "图格, 这副特制的枷锁如何? 我想它很适合你这位\"收藏家\".",
        ]
    ]

func get_captured_dialogue_after_battle_content()-> Array:
    return[
        [
            "呵呵, 猎物竟然给猎人套上了笼子.",
            "真是完美的讽刺..."
        ]
    ]


func get_hero_wait_for_release_dialogue_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "嘘...别说话, [" + _player_name + "]. 我在感受这牢笼的冰冷, 这真是一种奇妙的体验.",
            "[" + _player_name + "]. 你要多少筹码, 才肯让我回去?",
            "[" + _player_name + "], 你把珍贵的展品关在这么阴暗的地方, 可不是一个专业的收藏家该有的行为."
        ]
    ]


func _get_release_hero_ransom_amount_content()-> Array:
    return[
        "这 [#{0}] 德里足够你买下整条街的廉价劳动力了, 换我离开这里, 如何?",
        "拿走这 [#{0}] 德里, 修缮下你那简陋的牢房. 如何?",
        "这 [#{0}] 德里是我缴纳的贡品. 现在, 可以解开绳索了吗?"
    ]


func get_hero_released_by_ransom_content()-> Array:
    var _player_name: String = SoldierUtils.get_player_name()

    return[
        [
            "[" + _player_name + "], 我会为你预留一个最精致的笼子, 期待我们的下次重逢.",
            "自由的味道...再会."
        ],
    ]


func _get_release_hero_equipment_content()-> Array:
    return[
        "这件 [#{0}] 足够抵消我在这间阴暗牢笼里剩余的时间了. 如何?"
    ]