extends AnimatedSprite2D
class_name ClickEffect

func play_left_click():
    self.play("left_click")

func play_left_click02():
    self.play("left_click02")

func play_left_click03():
    self.play("left_click03")

func play_right_click():
    self.play("right_click")

func play_forbid_click()-> void:
    self.play("forbid_click")

func _on_animation_finished():
    self.queue_free()