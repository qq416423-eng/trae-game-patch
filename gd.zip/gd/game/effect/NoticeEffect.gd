class_name NoticeEffect extends Node2D

@onready var animation_player_node =$AnimationPlayer

func show_effect():
    animation_player_node.play("show")