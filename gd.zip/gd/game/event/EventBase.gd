class_name EventBase

enum TYPE_ENUM {



    DIALOG
}







enum TRIGGER_TYPE_ENUM {

    ENTER_LOCATION
}

func get_event_detail(_event_code: String)-> Dictionary:
    return {}