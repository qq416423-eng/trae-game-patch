extends EventBase

const event_detail = {

    "event_type": TYPE_ENUM.DIALOG,

    "dialogue": DIALOGUE_FIRST,








}

const DIALOGUE_FIRST = {
    "step_type": DialogueConstants.STEP_TYPE_ENUM.DIALOG,
    "turn": DialogueConstants.SPEAKER_ENUM.A,
    "content": [
        {
            "clist": [
                "侦查到该地点驻守了一只实力强大的强盗队伍, 是否进攻?",
            ]
        }
    ],
    "next": {
        "step_type": DialogueConstants.STEP_TYPE_ENUM.OPTION,
        "option_content": DialogueConstants.DIALOGUE_NARRATOR.WHAT_ARE_OUR_NEXT_STEPS,
        "option_list": [
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.BATTLE,
                "oname": "进攻",
                "turn": DialogueConstants.SPEAKER_ENUM.A,
                "content": [
                    {
                        "clist": [
                            "集中注意力! 不给敌人任何机会!",
                        ]
                    }
                ],
                "next": {
                    "need_auto_save": false,
                    "enemy_team": BATTLE_TEAM_CONFIG,
                    "trophy_money": 2000,


                    "battle_win_dialogue": "res://gd/game/dialogue/WildHero0007Dialogue.gd",

                    "event_end": true,
                }
            },
            {
                "otype": DialogueConstants.OPTION_TYPE_ENUM.LEAVE,
                "oname": "离开",
                "content": [
                    {
                        "clist": [
                            DialogueConstants.DIALOGUE_NARRATOR.WE_CHOOSE_TO_LEAVE
                        ]
                    }
                ]
            }
        ]
    }
}


const BATTLE_TEAM_CONFIG = [
    {
        "soldier": {
            "uid": "wild_soldier_0003",
        },
        "count": 25,
    },
    {
        "soldier": {
            "uid": "wild_soldier_0002"
        },
        "count": 25,
    },
    {
        "soldier": {
            "uid": "wild_soldier_0001"
        },
        "count": 25,
    },
]

func get_event_detail(_event_code: String)-> Dictionary:
    var _result: = event_detail.duplicate(true)
    _result.event_code = _event_code

    return _result