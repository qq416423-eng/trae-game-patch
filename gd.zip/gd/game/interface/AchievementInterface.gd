extends Control

var _manager = null

var _background: ColorRect
var _panel: Panel
var _inner_panel: Panel
var _main_vbox: VBoxContainer
var _title_label: Label
var _progress_label: Label
var _scroll_container: ScrollContainer
var _content_vbox: VBoxContainer
var _close_button: Button

const COLOR_BG_DARK = Color(0.05, 0.05, 0.09, 0.97)
const COLOR_PANEL_BG = Color(0.09, 0.09, 0.14, 1.0)
const COLOR_CARD_BG_UNLOCKED = Color(0.14, 0.12, 0.06, 1.0)
const COLOR_CARD_BG_LOCKED = Color(0.07, 0.07, 0.1, 1.0)
const COLOR_GOLD = Color(0.85, 0.7, 0.3, 1.0)
const COLOR_UNLOCKED_C = Color(0.95, 0.85, 0.4, 1.0)
const COLOR_LOCKED_C = Color(0.35, 0.35, 0.4, 1.0)
const COLOR_TEXT = Color(0.88, 0.88, 0.92, 1.0)
const COLOR_TEXT_DIM = Color(0.5, 0.5, 0.55, 1.0)
const COLOR_TEXT_LOCKED = Color(0.3, 0.3, 0.34, 1.0)

const PANEL_WIDTH = 820
const PANEL_HEIGHT = 620


func _ready()-> void:
    _build_ui()
    hide()


func setup(manager)-> void:
    _manager = manager



func show()-> void:
    _center_panel()
    super.show()



func _notification(what: int)-> void:
    if what == NOTIFICATION_RESIZED and _inner_panel != null:
        _center_panel()



func _center_panel()-> void:
    if _inner_panel == null:
        return
    var _screen_size = get_viewport().get_visible_rect().size
    var _px =(_screen_size.x - PANEL_WIDTH) / 2.0
    var _py =(_screen_size.y - PANEL_HEIGHT) / 2.0
    _inner_panel.position = Vector2(_px, _py)
    _inner_panel.size = Vector2(PANEL_WIDTH, PANEL_HEIGHT)


func _build_ui()-> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP

    _background = ColorRect.new()
    _background.set_anchors_preset(Control.PRESET_FULL_RECT)
    _background.color = COLOR_BG_DARK
    _background.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(_background)


    _panel = Panel.new()
    _panel.set_anchors_preset(Control.PRESET_FULL_RECT)
    _panel.offset_left = 0
    _panel.offset_top = 0
    _panel.offset_right = 0
    _panel.offset_bottom = 0
    _panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

    var psb = StyleBoxFlat.new()
    psb.bg_color = Color(0, 0, 0, 0)
    psb.border_width_left = 0
    psb.border_width_right = 0
    psb.border_width_top = 0
    psb.border_width_bottom = 0
    _panel.add_theme_stylebox_override("panel", psb)
    add_child(_panel)


    _inner_panel = Panel.new()
    _inner_panel.custom_minimum_size = Vector2(PANEL_WIDTH, PANEL_HEIGHT)
    _inner_panel.size = Vector2(PANEL_WIDTH, PANEL_HEIGHT)
    _inner_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    _inner_panel.name = "InnerPanel"

    var ipsb = StyleBoxFlat.new()
    ipsb.bg_color = COLOR_PANEL_BG
    ipsb.border_color = COLOR_GOLD
    ipsb.border_width_left = 2
    ipsb.border_width_right = 2
    ipsb.border_width_top = 2
    ipsb.border_width_bottom = 2
    ipsb.corner_radius_top_left = 12
    ipsb.corner_radius_top_right = 12
    ipsb.corner_radius_bottom_left = 12
    ipsb.corner_radius_bottom_right = 12
    ipsb.content_margin_left = 6
    ipsb.content_margin_right = 6
    ipsb.content_margin_top = 6
    ipsb.content_margin_bottom = 6
    _inner_panel.add_theme_stylebox_override("panel", ipsb)
    _panel.add_child(_inner_panel)

    _main_vbox = VBoxContainer.new()
    _main_vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
    _main_vbox.offset_left = 20
    _main_vbox.offset_top = 18
    _main_vbox.offset_right = -20
    _main_vbox.offset_bottom = -18
    _main_vbox.add_theme_constant_override("separation", 10)
    _main_vbox.mouse_filter = Control.MOUSE_FILTER_PASS
    _inner_panel.add_child(_main_vbox)

    _title_label = Label.new()
    _title_label.text = "成就殿堂"
    _title_label.add_theme_font_size_override("font_size", 28)
    _title_label.add_theme_color_override("font_color", COLOR_GOLD)
    _title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _main_vbox.add_child(_title_label)

    _progress_label = Label.new()
    _progress_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _progress_label.add_theme_font_size_override("font_size", 15)
    _progress_label.add_theme_color_override("font_color", COLOR_TEXT)
    _progress_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _main_vbox.add_child(_progress_label)

    var sep1 = HSeparator.new()
    sep1.add_theme_constant_override("separation", 4)
    sep1.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _main_vbox.add_child(sep1)

    _scroll_container = ScrollContainer.new()
    _scroll_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _scroll_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _scroll_container.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    _scroll_container.mouse_filter = Control.MOUSE_FILTER_STOP
    _main_vbox.add_child(_scroll_container)

    _content_vbox = VBoxContainer.new()
    _content_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _content_vbox.add_theme_constant_override("separation", 6)
    _content_vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _scroll_container.add_child(_content_vbox)

    _close_button = Button.new()
    _close_button.text = "关闭"
    _close_button.custom_minimum_size = Vector2(0, 40)
    _close_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _close_button.add_theme_font_size_override("font_size", 16)
    _close_button.pressed.connect(_on_close_pressed)
    _main_vbox.add_child(_close_button)


    _center_panel()


func refresh_display()-> void:
    if _manager == null:
        return


    _center_panel()


    _manager.check_achievements()


    var children_copy = _content_vbox.get_children().duplicate()
    for child in children_copy:
        child.queue_free()

    var all_ach = _manager.get_all_achievements()
    var grouped = {}
    for ach in all_ach:
        var cat = ach.get("category", 0)
        if not grouped.has(cat):
            grouped[cat] = []
        grouped[cat].append(ach)

    var unlocked_count = _manager.get_unlocked_count()
    var total_count = all_ach.size()
    var pct = int(float(unlocked_count) / float(max(total_count, 1)) * 100)
    _progress_label.text = "已解锁  %d / %d  (%d%%)" % [unlocked_count, total_count, pct]

    var categories = grouped.keys()
    categories.sort()
    for cat in categories:
        var achievements = grouped[cat]
        var cat_color = _manager.get_category_color(cat)
        var cat_label = _manager.get_category_label(cat)

        var header_row = HBoxContainer.new()
        header_row.add_theme_constant_override("separation", 6)
        header_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
        _content_vbox.add_child(header_row)

        var icon_label = Label.new()
        icon_label.text = cat_label
        icon_label.add_theme_font_size_override("font_size", 20)
        icon_label.add_theme_color_override("font_color", cat_color)
        icon_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
        header_row.add_child(icon_label)

        var header = Label.new()
        header.text = _manager.get_category_name(cat)
        header.add_theme_font_size_override("font_size", 20)
        header.add_theme_color_override("font_color", cat_color)
        header.mouse_filter = Control.MOUSE_FILTER_IGNORE
        header_row.add_child(header)

        var sep = HSeparator.new()
        sep.add_theme_constant_override("separation", 4)
        sep.mouse_filter = Control.MOUSE_FILTER_IGNORE
        _content_vbox.add_child(sep)

        for ach in achievements:
            _content_vbox.add_child(_create_card(ach))

        var spacer = Control.new()
        spacer.custom_minimum_size = Vector2(0, 6)
        spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
        _content_vbox.add_child(spacer)


func _create_card(achievement)-> Control:
    var code = achievement.get("code", "")
    var name = achievement.get("name", "")
    var desc = achievement.get("desc", "")
    var category = achievement.get("category", 0)
    var hidden = achievement.get("hidden", false)
    var unlocked = _manager.is_unlocked(code)

    var display_name = name
    var display_desc = desc
    if hidden and not unlocked:
        display_name = "???"
        display_desc = "???"

    var card = PanelContainer.new()
    card.size_flags_horizontal = Control.SIZE_EXPAND_FILL

    card.mouse_filter = Control.MOUSE_FILTER_IGNORE


    var csb = StyleBoxFlat.new()
    if unlocked:
        csb.bg_color = COLOR_CARD_BG_UNLOCKED
        csb.border_color = _manager.get_category_color(category)
        csb.border_width_left = 2
        csb.border_width_right = 2
        csb.border_width_top = 2
        csb.border_width_bottom = 2
    else:
        csb.bg_color = COLOR_CARD_BG_LOCKED
        csb.border_color = Color(0.15, 0.15, 0.18, 1.0)
        csb.border_width_left = 1
        csb.border_width_right = 1
        csb.border_width_top = 1
        csb.border_width_bottom = 1
    csb.corner_radius_top_left = 8
    csb.corner_radius_top_right = 8
    csb.corner_radius_bottom_left = 8
    csb.corner_radius_bottom_right = 8
    csb.content_margin_left = 12
    csb.content_margin_right = 12
    csb.content_margin_top = 10
    csb.content_margin_bottom = 10
    card.add_theme_stylebox_override("panel", csb)

    var hbox = HBoxContainer.new()
    hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hbox.add_theme_constant_override("separation", 12)
    hbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
    card.add_child(hbox)


    var icon_label = Label.new()
    icon_label.text = _manager.get_category_label(category)
    icon_label.custom_minimum_size = Vector2(48, 48)
    icon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    icon_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    icon_label.add_theme_font_size_override("font_size", 16)
    if unlocked:
        icon_label.add_theme_color_override("font_color", _manager.get_category_color(category))
    else:
        icon_label.add_theme_color_override("font_color", COLOR_TEXT_LOCKED)
    icon_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hbox.add_child(icon_label)


    var vbox = VBoxContainer.new()
    vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vbox.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    vbox.add_theme_constant_override("separation", 3)
    vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hbox.add_child(vbox)

    var name_label = Label.new()
    name_label.text = display_name
    name_label.add_theme_font_size_override("font_size", 17)
    if unlocked:
        name_label.add_theme_color_override("font_color", COLOR_UNLOCKED_C)
    else:
        name_label.add_theme_color_override("font_color", COLOR_LOCKED_C)
    name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    vbox.add_child(name_label)

    var desc_label = Label.new()
    desc_label.text = display_desc
    desc_label.add_theme_font_size_override("font_size", 13)
    desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    if unlocked:
        desc_label.add_theme_color_override("font_color", COLOR_TEXT_DIM)
    else:
        desc_label.add_theme_color_override("font_color", COLOR_TEXT_LOCKED)
    desc_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    vbox.add_child(desc_label)

    var status_label = Label.new()
    status_label.add_theme_font_size_override("font_size", 11)
    if unlocked:
        status_label.text = ">> 已解锁"
        status_label.add_theme_color_override("font_color", COLOR_UNLOCKED_C)
    else:
        status_label.text = "   未解锁"
        status_label.add_theme_color_override("font_color", COLOR_TEXT_LOCKED)
    status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    vbox.add_child(status_label)

    return card


func _on_close_pressed()-> void:
    hide()