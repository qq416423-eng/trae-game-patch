class_name CreateCharacterInterface extends Control

@onready var base_info_root_node: Control =$LeftRoot / Background / EditCharacterRoot / BaseInfoRoot
@onready var hair_root_node: Control =$LeftRoot / Background / EditCharacterRoot / HairRoot
@onready var skin_root_node: Control =$LeftRoot / Background / EditCharacterRoot / SkinRoot
@onready var part_select_button_list_node: PartSelectButtonList =$LeftRoot / PartSelectButtonList
@onready var dice_button_node: DiceButton =$LeftRoot / Background / EditCharacterRoot / BaseInfoRoot / NameRoot / DiceButton
@onready var female_button_node: BaseSelectButton =$LeftRoot / Background / EditCharacterRoot / BaseInfoRoot / GenderRoot / FemaleButton
@onready var male_button_node: BaseSelectButton =$LeftRoot / Background / EditCharacterRoot / BaseInfoRoot / GenderRoot / MaleButton
@onready var name_edit_node: LineEdit =$LeftRoot / Background / EditCharacterRoot / BaseInfoRoot / NameRoot / NameEdit
@onready var hair_list_node: AvatarSelectRoot =$LeftRoot / Background / EditCharacterRoot / HairRoot / StyleRoot / HairList
@onready var hair_color_list_node: AvatarSelectRoot =$LeftRoot / Background / EditCharacterRoot / HairRoot / ColorRoot / HairColorList
@onready var avatar_ani_node: AvatarAni =$RightRoot / SoldierRoot / Background / AvatarAni
@onready var skin_list_node: AvatarSelectRoot =$LeftRoot / Background / EditCharacterRoot / SkinRoot / StyleRoot / SkinList
@onready var skin_color_list_node: AvatarSelectRoot =$LeftRoot / Background / EditCharacterRoot / SkinRoot / ColorRoot / SkinColorList
@onready var edit_character_root_node: Control =$LeftRoot / Background / EditCharacterRoot
@onready var create_character_title_node: Label =$LeftRoot / Background / TitleBackground / CreateCharacterTitle
@onready var background_choose_title_node: Label =$LeftRoot / Background / TitleBackground / BackgroundChooseTitle
@onready var background_choose_root_node: Control =$LeftRoot / Background / BackgroundChooseRoot
@onready var question_page_root_node: QuestionPageRoot =$LeftRoot / Background / BackgroundChooseRoot / QuestionPageRoot
@onready var previous_button_node: Button =$LeftRoot / Background / BackgroundChooseRoot / PreviousButton
@onready var next_button_node: Button =$LeftRoot / Background / BackgroundChooseRoot / NextButton

@onready var siblings_avatar_ani_node: AvatarAni =$RightRoot / SoldierRoot / Background / SiblingsAvatarAni
@onready var menu_list_button_node: BaseSelectButton =$LeftRoot / MenuListButton
@onready var confirm_box_node: ConfirmBox =$ConfirmBox
@onready var hero_portrait_node: HeroPortrait =$RightRoot / PortraitRoot / Background / HeroPortrait

var character_name_list = [
    "古斯塔夫", "康拉德", "阿拉里克", "埃德蒙", "雨果", "路德维希", "费迪南德", "奥斯瓦尔德", "西格尔德", "埃里克",
    "安瑟姆", "戈特弗里德", "莱奥波德", "鲁珀特", "沃尔夫拉姆", "乌利奇", "杰尔韦", "贝尔特兰", "赖因哈德", "戈德弗雷",
    "塞德里克", "鲍德温", "阿尔努尔夫", "克莱门特", "艾默里希", "温弗雷德", "埃弗拉德", "罗兰", "哈拉尔德", "富尔科",
    "伯特兰", "奥斯伯特", "埃格伯特", "蒂博", "瓦尔德马尔", "恩格尔贝特", "戈德温", "艾德里克", "埃尔里克", "厄文",
    "冈特", "莱纳", "阿尔文", "亨弗莱", "吉尔斯", "尤斯塔斯", "休伯特", "威尔弗雷德",
    "阿德莱德", "玛蒂尔达", "埃莉诺", "伊索尔德", "吉娜维尔", "阿丝特丽德", "吉塞拉", "布伦希尔达", "弗雷娅", "罗萨蒙德",
    "埃米琳", "埃罗文", "塞西莉亚", "威尔海明娜", "贝阿特丽斯", "海伦娜", "伊芙莱娜", "克拉丽莎", "罗文娜", "瑟拉芬娜",
    "特蕾莎", "温妮弗德", "伊迪丝", "阿加莎", "奥德特", "尤多拉", "贝伦尼斯", "珍妮薇芙", "英格丽德",
    "伊梅尔达", "西比拉", "费利西蒂", "普鲁登斯", "艾尔弗莱达", "玛丽戈德", "布林希尔德", "拉维尼亚", "梅丽桑德", "科黛莉娅",
    "奥雷利亚", "尤菲米亚", "艾尔弗雷达", "艾尔维娜", "艾梅琳", "伊莎贝尔", "罗莎琳德", "厄门加德", "艾尔曼加德", "巴托洛缪",
    "卡斯帕", "奥托", "班布里奇", "加百列", "雷诺德", "莫里斯", "本尼迪克特", "杰弗里", "塔奎因", "萨洛蒙", "马格努斯",
    "斯维恩", "奥拉夫", "克努特", "哈康", "西奥多里克", "贝伦加尔", "埃塞尔雷德", "温斯顿", "萨克里", "劳伦斯", "法比安",
    "巴拿巴", "格里高利", "杰拉德", "朗弗里德", "阿德里安", "马修", "休格", "佩雷格林", "维克多", "康斯坦丁", "塞巴斯蒂安",
    "卢西恩", "卡德摩斯", "莱昂内尔", "帕西瓦尔", "特里斯坦", "高文", "兰斯洛特", "鲍斯", "加雷斯", "凯", "贝德维尔",
    "莫德雷德", "埃克托", "菲利普", "查理", "斯蒂芬", "维多利亚", "亚历山德拉", "卡瑟琳", "玛格丽特", "安妮", "琼",
    "布兰奇", "菲莉帕", "阿格尼丝", "玛丽昂", "阿莉西亚", "米拉贝拉", "弗洛伦丝", "尤利安娜", "塔提亚娜", "安娜斯塔西亚",
    "莱昂诺尔", "薇薇安", "摩根", "伊莱恩", "妮姆薇", "莉莉丝", "萨拉", "多萝西娅", "西奥多拉", "艾格尼丝", "芭芭拉",
    "乌苏拉", "玛莎", "布里吉特", "希尔德加德", "斯德拉", "奥利维亚", "维奥拉", "碧安卡", "西尔维娅", "露西亚", "卡米拉",
    "维特多利亚", "安吉拉", "佩内洛普", "卡桑德拉", "黛安娜", "塞壬", "艾瑞丝", "芙罗拉", "波琳娜", "奥若拉", "贝丽尔",
    "萨菲亚"
]

var init_character_info: = {}
var final_character_info: = {}
var hair_color_list: = []
var body_color_list: = []

var is_show_siblings_avatar: = false
var origin_avatar_ani_node_position_x: int

signal close_sign()
signal create_character_success_sign()

func _ready()-> void:
    origin_avatar_ani_node_position_x = avatar_ani_node.position.x
    _handle_hair_color_list()
    _handle_body_color_list()
    _reset()

func _handle_hair_color_list():
    for _color_dic: Dictionary in BSHairData.HAIR_COLOR_LIST:
        hair_color_list.append(_color_dic.color)

func _handle_body_color_list():
    for _color_dic: Dictionary in BSBodyData.BODY_COLOR_LIST:
        body_color_list.append(_color_dic.color)

func _reset()-> void:
    _switch_edit_background_or_skin(false)
    init_character_info = CreateCharacterConstants.INIT_CHARACTER_INFO.duplicate(true)

    _init_background_choose()
    _init_siblings_avatar_ani()
    _refresh_avatar()

    _init_hair()
    _init_skin()
    _reset_base_info()
    part_select_button_list_node.select(0)

func _init_siblings_avatar_ani():
    siblings_avatar_ani_node.init_by_uid("wild_hero_0001")
    is_show_siblings_avatar = false
    siblings_avatar_ani_node.modulate.a = 0.0
    avatar_ani_node.position.x = origin_avatar_ani_node_position_x


func _init_background_choose()-> void:
    question_page_root_node.init(CreateCharacterConstants.BACKGROUND_CHOOSE_JSON)



func _refresh_avatar()-> void:
    _merge_final_character_info()
    var bs_soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_json(final_character_info)
    avatar_ani_node.init(bs_soldier_prop)


    if final_character_info.has("siblings_gender"):

        var _siblings_uid = CreateCharacterConstants.get_siblings_uid(final_character_info.siblings_gender)
        if siblings_avatar_ani_node.get_uid() != _siblings_uid:
            siblings_avatar_ani_node.init_by_uid(_siblings_uid)

        if not is_show_siblings_avatar:
            is_show_siblings_avatar = true
            var _tween = get_tree().create_tween()
            _tween.tween_property(siblings_avatar_ani_node, "modulate:a", 1.0, 0.4)
            _tween.parallel().tween_property(avatar_ani_node, "position:x", avatar_ani_node.position.x + 32, 0.4)
            _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)


func _init_hair()-> void:
    hair_list_node.init_hair(BSHairData.hair_list.keys())
    hair_color_list_node.init_color(hair_color_list)

    hair_list_node.random_choose()
    hair_color_list_node.random_choose()




func _init_skin()-> void:
    skin_list_node.init_body(BSBodyData.body_list.keys())
    skin_color_list_node.init_color(body_color_list)


    skin_list_node.choose_first()
    skin_color_list_node.random_choose()

func _reset_base_info()-> void:
    dice_button_node.action(false)
    male_button_node.choose(false)

func _switch_edit_background_or_skin(_is_background: bool)-> void:
    if _is_background:
        edit_character_root_node.hide()
        part_select_button_list_node.hide()
        create_character_title_node.hide()
        background_choose_title_node.show()
        background_choose_root_node.show()
        menu_list_button_node.show()

        _refresh_background_choose_buttons()
    else:
        edit_character_root_node.show()
        part_select_button_list_node.show()
        create_character_title_node.show()
        background_choose_title_node.hide()
        background_choose_root_node.hide()
        menu_list_button_node.hide()

func _refresh_background_choose_buttons()-> void:
    var is_first_page: = question_page_root_node.is_first_page()
    var _is_choose: = question_page_root_node.is_choose()
    var _is_last_page: = question_page_root_node.is_last_page()

    if is_first_page:
        previous_button_node.disabled = true
    else:
        previous_button_node.disabled = false

    if _is_choose:
        next_button_node.disabled = false
    else:
        next_button_node.disabled = true

    if _is_last_page:
        next_button_node.text = "完成"
    else:
        next_button_node.text = "下一步"

func _merge_final_character_info()-> void:
    var _merge_value: Dictionary = question_page_root_node.get_merge_value()

    var _gender_plus_json: Dictionary = CreateCharacterConstants.GENDER_PROP_PLUS_CONFIG.get(init_character_info.gender)
    _merge_value = SoldierUtils.merge_soldier_json(_merge_value, _gender_plus_json)
    final_character_info = SoldierUtils.merge_soldier_json(init_character_info, _merge_value)


func save():
    init_character_info.name = name_edit_node.text
    _merge_final_character_info()
    WSData.init_player(final_character_info)



func _on_dice_button_pressed_sign()-> void:
    var _pre_name = name_edit_node.text
    var _new_name = _pre_name
    while(_new_name == _pre_name):
        _new_name = character_name_list.pick_random()

    name_edit_node.text = _new_name

func _on_male_button_b_pressed()-> void:
    init_character_info.gender = BSSoldierConstants.GENDER_ENUM.MALE
    hero_portrait_node.init_by_gender(init_character_info.gender)
    female_button_node.cancel()

func _on_female_button_2_b_pressed()-> void:
    init_character_info.gender = BSSoldierConstants.GENDER_ENUM.FEMALE
    hero_portrait_node.init_by_gender(init_character_info.gender)
    male_button_node.cancel()

func _on_part_select_button_list_choose_sign(_value: String)-> void:
    base_info_root_node.hide()
    hair_root_node.hide()
    skin_root_node.hide()

    match _value:
        "BASE":
            base_info_root_node.show()
        "HAIR":
            hair_root_node.show()
        "SKIN":
            skin_root_node.show()


func _on_hair_color_list_choose_sign(_node: Variant)-> void:
    hair_list_node.update_hair_color(_node.color)
    init_character_info.hair.color = _node.color
    _refresh_avatar()


func _on_hair_list_choose_sign(_node: Variant)-> void:
    init_character_info.hair.uid = _node.part_uid
    _refresh_avatar()

func _on_skin_list_choose_sign(_node: Variant)-> void:
    init_character_info.body.uid = _node.part_uid
    _refresh_avatar()

func _on_skin_color_list_choose_sign(_node: Variant)-> void:
    skin_list_node.update_body_color(_node.color)
    init_character_info.body.color = _node.color
    _refresh_avatar()


func _on_to_background_button_pressed()-> void:

    var _name: = name_edit_node.text
    if _name.length() == 0:
        part_select_button_list_node.select(0, false)
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.CC_NAME_FORMATTING_NON_COMPLIANT)
        return

    _switch_edit_background_or_skin(true)


func _on_question_page_root_choose_option_sign()-> void:
    _refresh_background_choose_buttons()
    _refresh_avatar()

func _on_next_button_pressed()-> void:
    var _is_last_page = question_page_root_node.is_last_page()
    if _is_last_page:

        confirm_box_node.show()
    else:
        question_page_root_node.next_page()
        _refresh_background_choose_buttons()

func _on_previous_button_pressed()-> void:
    question_page_root_node.pre_page()
    _refresh_background_choose_buttons()

func _on_menu_list_button_b_pressed()-> void:
    _switch_edit_background_or_skin(false)



func _on_confirm_box_confirm()-> void:
    hide()
    create_character_success_sign.emit()
    _reset()

func _on_close_button_pressed()-> void:
    hide()
    _reset()
    close_sign.emit()