class_name CustomTeamInterface extends Control

@onready var soldier_select_interface_node: SoldierSelectInterface =$ChildPageRoot / SoldierSelectInterface
@onready var left_team_list_interface_node: TeamListInterface =$LeftTeamListInterface
@onready var right_team_list_interface_node: TeamListInterface =$RightTeamListInterface
@onready var soldier_equipment_info_for_custom_team_node: SoldierEquipmentInfoForCustomTeam =$SoldierEquipmentInfoForCustomTeam
@onready var start_battle_button_node: CommonButton2 =$MidButtonRoot / StartBattleButton
@onready var formation_setting_interface_node: FormationSettingInterface =$ChildPageRoot / FormationSettingInterface
@onready var left_add_team_button_node: IconSwitchButton =$LeftTeamListInterface / LeftAddTeamButton
@onready var right_add_team_button_node: IconSwitchButton =$RightTeamListInterface / RightAddTeamButton
@onready var close_button_node: CommonButton =$ButtonRoot / CloseButton
@onready var split_group_interface_root_node: ColorRect =$ChildPageRoot / SplitGroupInterfaceRoot
@onready var split_group_interface_node: SplitGroupInterface =$ChildPageRoot / SplitGroupInterfaceRoot / SplitGroupInterface
@onready var map_weather_select_interface_node: MapWeatherSelectInterface =$ChildPageRoot / MapWeatherSelectInterface
@onready var refresh_enemy_button_node: CommonButton =$ButtonRoot / RefreshEnemyButton

const BACKGROUND_0009 = preload("res://resource/baseUI/background_0009.png")



var is_left_select = null
var map_key: = ""
var weather_key: = ""

signal close_page_sign()
signal start_battle_sign(_map_key: String, _weather_key: String)

func cshow()-> void:
    GlobalLoadPage.load_open()
    self.show()
    _equipment_info_hide_and_reset_background()
    soldier_select_interface_node.load_all_soldier_cache(true)
    _refresh_start_battle_button_disable_status()
    GlobalLoadPage.load_close()

func chide()-> void:
    self.hide()

    soldier_select_interface_node.clear(false)
    _cancel_choose_all()

func clear_custom_battle_soldier_box_list_node()-> void:
    soldier_select_interface_node.clear(true)

func get_left_simple_json_list()-> Array:
    return left_team_list_interface_node.team_data

func get_right_simple_json_list()-> Array:
    return right_team_list_interface_node.team_data

func init(_left_simple_json_list: Array,
    _right_simple_json_list: Array
)-> void:

    _heal_all_soldier(_left_simple_json_list)
    _heal_all_soldier(_right_simple_json_list)

    left_team_list_interface_node.init(_left_simple_json_list)
    right_team_list_interface_node.init(_right_simple_json_list)

    map_key = WSData.custom_battle_map_key
    weather_key = WSData.custom_battle_weather_key

func heal_all_soldier()-> void:
    _heal_all_soldier(left_team_list_interface_node.team_data)
    _heal_all_soldier(right_team_list_interface_node.team_data)

func get_map_key()-> String:
    return map_key

func get_weather_key()-> String:
    return weather_key

func _equipment_info_hide_and_reset_background()-> void:
    soldier_equipment_info_for_custom_team_node.hide_info()
    soldier_equipment_info_for_custom_team_node.reset_background()

func _cancel_choose_all()-> void:
    is_left_select = null
    left_team_list_interface_node.cancel_choose()
    right_team_list_interface_node.cancel_choose()

func _refresh_start_battle_button_disable_status()-> void:
    if left_team_list_interface_node.get_count() > 0 \
    and right_team_list_interface_node.get_count() > 0:
        start_battle_button_node.disabled = false
    else:
        start_battle_button_node.disabled = true

func _get_select_node():
    var _choose_node = null
    if is_left_select:
        _choose_node = left_team_list_interface_node.select_node
    else:
        _choose_node = right_team_list_interface_node.select_node

    return _choose_node

func _show_or_hide_formation_setting_interface(_is_show: bool = true)-> void:
    if _is_show:
        formation_setting_interface_node.show()
        _disable_all_button(true)
    else:
        formation_setting_interface_node.hide()
        _disable_all_button(false)

func _disable_all_button(_disable: bool = true)-> void:
    left_add_team_button_node.disabled = _disable
    right_add_team_button_node.disabled = _disable
    close_button_node.disabled = _disable
    refresh_enemy_button_node.disabled = _disable
    start_battle_button_node.disabled = _disable
    soldier_equipment_info_for_custom_team_node.disable_all_button(_disable)

func _heal_all_soldier(_simple_json_list: Array)-> void:


    TeamUtils.simple_json_recovery(_simple_json_list)

func _on_left_add_team_button_cpressed(_value: Variant)-> void:
    soldier_select_interface_node.cshow("0")
    soldier_select_interface_node.init_select_soldier(
        left_team_list_interface_node.list_exist_soldier_uid()
    )

func _on_soldier_select_interface_save_sign(_soldier_uid_list: Array, _value: String)-> void:
    match _value:
        "0":
            left_team_list_interface_node.incremental_update(_soldier_uid_list)
        "1":
            right_team_list_interface_node.incremental_update(_soldier_uid_list)

    _cancel_choose_all()
    _equipment_info_hide_and_reset_background()
    _refresh_start_battle_button_disable_status()

func _on_right_add_team_button_cpressed(_value: Variant)-> void:
    soldier_equipment_info_for_custom_team_node.show_info()
    soldier_select_interface_node.cshow("1")
    soldier_select_interface_node.init_select_soldier(
        right_team_list_interface_node.list_exist_soldier_uid()
    )

func _on_left_team_list_interface_bchoose(_node: Variant)-> void:
    is_left_select = true

    soldier_equipment_info_for_custom_team_node.reset_background()
    soldier_equipment_info_for_custom_team_node.show_info()

    right_team_list_interface_node.cancel_choose()

    soldier_equipment_info_for_custom_team_node.init(_node.soldier_prop, _node.get_total())
    soldier_equipment_info_for_custom_team_node.cancel_choose_equipment()
    soldier_equipment_info_for_custom_team_node.show_or_hide_formation_split_button(true)
    if formation_setting_interface_node.visible:
        formation_setting_interface_node.init_by_uid(_node.get_split_group_uid())


    var _group_num: int = WSData.get_group_num(_node.get_split_group_uid())

    soldier_equipment_info_for_custom_team_node.refresh_group_card_icon(_group_num)

func _on_right_team_list_interface_bchoose(_node: Variant)-> void:
    is_left_select = false

    soldier_equipment_info_for_custom_team_node.update_background(BACKGROUND_0009)
    soldier_equipment_info_for_custom_team_node.show_info()

    left_team_list_interface_node.cancel_choose()

    soldier_equipment_info_for_custom_team_node.init(_node.soldier_prop, _node.get_total())
    soldier_equipment_info_for_custom_team_node.cancel_choose_equipment()
    soldier_equipment_info_for_custom_team_node.show_or_hide_formation_split_button(false)
    if formation_setting_interface_node.visible:
        _show_or_hide_formation_setting_interface(false)

func _on_close_button_custom_pressed()-> void:
    chide()
    close_page_sign.emit()


func _on_soldier_equipment_info_for_custom_team_plus_soldier_count(
    _count: int, _min_one_enforced: = false
)-> void:
    if is_left_select == null:
        return

    var _choose_node = null
    if is_left_select:
        left_team_list_interface_node.plus_soldier_count_and_refresh(_count, _min_one_enforced)
        _choose_node = left_team_list_interface_node.select_node
    else:
        right_team_list_interface_node.plus_soldier_count_and_refresh(_count, _min_one_enforced)
        _choose_node = right_team_list_interface_node.select_node

    if CommonUtils.is_null(_choose_node):
        _equipment_info_hide_and_reset_background()

    soldier_equipment_info_for_custom_team_node.update_num_ani(_choose_node.get_total())
    _refresh_start_battle_button_disable_status()


func _on_start_battle_button_custom_pressed()-> void:



    map_weather_select_interface_node.cshow()
    map_weather_select_interface_node.init_choose(map_key, weather_key)
    _disable_all_button()


func _on_soldier_equipment_info_for_custom_team_formation_set_sign()-> void:
    formation_setting_interface_node.init_by_uid(_get_select_node().get_split_group_uid())
    _show_or_hide_formation_setting_interface()
    soldier_equipment_info_for_custom_team_node.hide_equipment_detail_page()


func _on_formation_setting_interface_need_refresh_sign(_group_num: Variant)-> void:
    var _select_node = _get_select_node()

    WSData.save_group_num(_select_node.get_split_group_uid(), _group_num)

    soldier_equipment_info_for_custom_team_node.refresh_group_card_icon(_group_num)
    _select_node.refresh_group_num()

func _on_formation_setting_interface_close_sign()-> void:
    _show_or_hide_formation_setting_interface(false)


func _on_soldier_equipment_info_for_custom_team_split_group_sign()-> void:
    var _select_node = _get_select_node()
    if CommonUtils.is_null(_select_node):
        return

    if not _select_node is TeamItemSoldierInterface:
        return

    soldier_equipment_info_for_custom_team_node.hide_equipment_detail_page()

    var _nop_list: Array = left_team_list_interface_node.get_split_group_nop_list(_select_node.get_uid())
    split_group_interface_node.init(_select_node.get_soldier_prop(), _nop_list)
    split_group_interface_root_node.show()
    _disable_all_button(true)

func _on_split_group_interface_close_sign()-> void:
    split_group_interface_root_node.hide()
    _disable_all_button(false)

func _on_split_group_interface_save_sign(_uid: String, _nop_list: Array)-> void:
    left_team_list_interface_node.split_group(_uid, _nop_list)
    split_group_interface_root_node.hide()
    _disable_all_button(false)
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SPLIT_GROUP_MESSAGE)


func _on_map_weather_select_interface_confirm_start_battle_sign(
    _map_key: String, _weather_key: String
)-> void:
    map_key = _map_key
    weather_key = _weather_key

    chide()
    start_battle_sign.emit(_map_key, _weather_key)

func _on_map_weather_select_interface_close_sign()-> void:
    _disable_all_button(false)
    map_key = map_weather_select_interface_node.get_map_key()
    weather_key = map_weather_select_interface_node.get_weather_key()


func _on_refresh_enemy_button_custom_pressed()-> void:
    var _simple_json_list: Array = TeamUtils.random_soldier_team(10000)
    right_team_list_interface_node.init(_simple_json_list)

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.RANDOM_ENEMY_TEAM_SUCCESS
    )