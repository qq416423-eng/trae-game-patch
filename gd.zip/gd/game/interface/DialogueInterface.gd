extends Control
class_name DialogueInterface

@onready var left_name_node =$Root / DialogueNameFrameLeft / Name
@onready var right_name_node =$Root / DialogueNameFrameRight / Name

@onready var content_node: RichTextLabel =$Root / DialogueFrame / RichContent
@onready var dialogue_name_frame_left_node =$Root / DialogueNameFrameLeft
@onready var dialogue_name_frame_right_node =$Root / DialogueNameFrameRight
@onready var switch_animation_player_node =$SwitchAnimationPlayer
@onready var content_animation_player_node =$ContentAnimationPlayer
@onready var tip_node =$Root / DialogueFrame / Tip
@onready var dialogue_option_interface_node =$DialogueOptionInterface as DialogueOptionInterface
@onready var interface_animation_player_node =$InterfaceAnimationPlayer
@onready var exchange_small_interface_node: Control =$SubPageRoot / ExchangeSmallInterface
@onready var left_portrait_node: HeroPortrait =$Root / LeftPortrait
@onready var right_portrait_node: HeroPortrait =$Root / RightPortrait
@onready var prisoner_exchange_interface_node: PrisonerExchangeInterface =$SubPageRoot / PrisonerExchangeInterface
@onready var change_persion_animation_player_node: AnimationPlayer =$ChangePersionAnimationPlayer
@onready var join_battle_team_info_box_node: JoinBattleTeamInfoBox =$JoinBattleTeamInfoBox
@onready var right_emoji_name_node: Label =$Root / DialogueNameFrameRightWithEmoji / Name
@onready var dialogue_name_frame_right_with_emoji_node: TextureRect =$Root / DialogueNameFrameRightWithEmoji
@onready var relation_emoji_node: RelationEmoji =$Root / DialogueNameFrameRightWithEmoji / RelationEmoji







var turn = DialogueConstants.SPEAKER_ENUM.B
var dialogue_json
var is_first_dialogue = true
var is_content_show_finish = false

var is_making_choice = false

var result_option_type = DialogueConstants.OPTION_TYPE_ENUM.EXIT_CONVERSATION
var a_team_dialogue_info: = {}
var b_team_dialogue_info: = {}

var current_ani_turn: = CommonConstants.DIRECTION_ENUM.RIGHT

var hero_uid: = ""
var origin_left_hero_uid: = ""
var origin_right_hero_uid: = ""
var left_hero_uid_change_to: = ""
var right_hero_uid_change_to: = ""
var event_code: = ""
var npc_info: = {}

var final_custom_func_list: = []
var _execute_depth: int = 0

var last_selected_oname: String = ""

signal finish(_result_option_type, _dialogue_json)


signal mod_show_join_country_cg_sign(_country_code: String)

func _ready():
    pass

func interact_with_charactar_by_npc_info(_npc_info: Dictionary)-> void:
    npc_info = _npc_info
    var _temp_npc_info: = _npc_info.duplicate(true)
    if not _temp_npc_info.has("func_type"):
        _temp_npc_info.func_type = ""

    hero_uid = _npc_info.npc_uid
    var _right_dialogue_info: = DialogueUtils.get_dialogue_info(_npc_info.npc_uid)

    GlobalTempData.update_dialogue_info(
        WSData.get_player_team_node().get_dialogue_info(),
        _right_dialogue_info
    )
    var _dialogue_template_json: = {}

    match _temp_npc_info.func_type:
        LocationConstants.NPC_FUNC_TYPE_ENUM.MERCENARY:
            var _dialogue_gd_node: BaseDialogue = CommonUtils.load_gd(
                DialogueUtils.get_dialogue_path("MercenaryCommonDialogue")
            )

            CommonUtils.cover_json(_npc_info, _right_dialogue_info)
            if not CommonUtils.get_value(_npc_info, "is_hire", false):

                var _soldier_json: Dictionary = SoldierUtils.get_json_by_uid(_npc_info.npc_uid)
                var _hire_money: int = _soldier_json.price * _npc_info.soldier_count
                _right_dialogue_info.hire_money = _hire_money

                _dialogue_template_json = _dialogue_gd_node.get_current_dialogue_template()
            else:

                _dialogue_template_json = _dialogue_gd_node.get_final_dialogue_template()

        "":
            _dialogue_template_json = DialogueUtils.get_hero_dialogue_template_json(_npc_info.npc_uid)

    init(
        _dialogue_template_json,
        WSData.get_player_team_node().get_dialogue_info(),
        _right_dialogue_info
    )


func interact_with_charactar(_hero_uid: String):
    hero_uid = _hero_uid

    var _a_info: Dictionary = WSData.get_player_team_node().get_dialogue_info()
    var _b_info: Dictionary = DialogueUtils.get_dialogue_info(_hero_uid)
    GlobalTempData.update_dialogue_info(_a_info, _b_info)
    var _dialogue_template_json: Dictionary = DialogueUtils.get_hero_dialogue_template_json(_hero_uid)
    init(_dialogue_template_json, _a_info, _b_info)

func init(
    _dialogue_json: Dictionary, _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
):
    if _b_team_dialogue_info.is_empty():
        _b_team_dialogue_info = DialogueUtils.get_dialogue_info("")




    dialogue_json = _dialogue_json

    a_team_dialogue_info = _a_team_dialogue_info
    b_team_dialogue_info = _b_team_dialogue_info



    hero_uid = _b_team_dialogue_info.get("leader_uid", "")


    if hero_uid == "minor_hero_0012":
        GlobalSoundManager.play_nun_music()

    GlobalTempData.update_dialogue_info(a_team_dialogue_info, b_team_dialogue_info)





    _init_visualize()


    if _dialogue_json.has("final_custom_func_list"):
        final_custom_func_list = _dialogue_json.final_custom_func_list
    else:
        final_custom_func_list = []

    _execute(_dialogue_json)

func update_join_battle_team(
    _left_team_node_list: Array,
    _right_team_node_list: Array
)-> void:
    if ArrayUtils.is_empty(_left_team_node_list) or ArrayUtils.is_empty(_right_team_node_list):
        return

    join_battle_team_info_box_node.init(_left_team_node_list, _right_team_node_list)
    join_battle_team_info_box_node.cshow()

func cshow():

    interface_animation_player_node.play("show")

func chide():

    interface_animation_player_node.play("hide")
    _clear()

func immediately_hide():
    self.hide()
    _clear()

func condition_match(_content_json_item: Dictionary)-> bool:
    return DialogueUtils.condition_match(_content_json_item, turn, a_team_dialogue_info, b_team_dialogue_info)

func update_event_code(_event_code: String)-> void:
    event_code = _event_code

func get_event_code()-> String:
    return event_code

func _handle_final_custom_func()-> void:
    if ArrayUtils.is_not_empty(final_custom_func_list):
        for _custom_func_json: Dictionary in final_custom_func_list:
            _handle_custom_func(_custom_func_json)

        final_custom_func_list = []

func _handle_custom_func(_custom_func_json: Dictionary)-> void:
    if _custom_func_json.is_empty():
        return

    if not _custom_func_json.has("func_name"):
        printerr("DialogueInterface._handle_custom_func: func_name 缺失")
        return
    var _callable = Callable(DialogueCustomUtils, _custom_func_json.func_name)
    if _custom_func_json.has("params"):
        _callable.callv(_custom_func_json.params.duplicate(true))
    else:
        _callable.call()

func _choose_content_json(_dialogue_json: Dictionary)-> Dictionary:
    if not _dialogue_json.has("content"):
        return {}

    for _content_json_item: Dictionary in _dialogue_json.content:
        var _is_match: bool = condition_match(_content_json_item)
        if _is_match:

            return _content_json_item
        else:
            continue

    return {}


func _choose_content(_dialogue_json: Dictionary):
    if not _dialogue_json.has("content"):
        return ""

    for _content_json_item: Dictionary in _dialogue_json.content:
        var _is_match: bool = condition_match(_content_json_item)
        if _is_match:
            return ArrayUtils.random_ele(_content_json_item.clist)
        else:
            continue

    return ""


func _init_visualize():
    origin_left_hero_uid = a_team_dialogue_info.leader_uid
    origin_right_hero_uid = b_team_dialogue_info.leader_uid



    if dialogue_json.has("turn_hero_uid") and dialogue_json.turn_hero_uid != origin_right_hero_uid:
        origin_right_hero_uid = dialogue_json.turn_hero_uid

    _load_left_portrait(origin_left_hero_uid)
    _load_right_portrait(origin_right_hero_uid)

func _load_left_portrait2():
    _load_left_portrait(left_hero_uid_change_to)

func _load_right_portrait2():
    _load_right_portrait(right_hero_uid_change_to)

func _load_left_portrait(_hero_uid: String):
    left_hero_uid_change_to = _hero_uid
    var _hero_json: = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    CommonUtils.set_text(left_name_node, SoldierUtils.get_nickname(_hero_json))
    left_portrait_node.init(_hero_uid)

func _load_right_portrait(_hero_uid: String):
    right_hero_uid_change_to = _hero_uid

    var _right_name: = ""
    if not SoldierUtils.is_hero_by_uid(_hero_uid):
        _right_name = b_team_dialogue_info.leader_name
    else:
        var _hero_json: = SoldierUtils.get_json_by_hero_uid(_hero_uid)
        _right_name = SoldierUtils.get_nickname(_hero_json)

    CommonUtils.set_text(right_name_node, _right_name)
    CommonUtils.set_text(right_emoji_name_node, _right_name)

    right_portrait_node.init(_hero_uid)


    _handle_emoji()



func _handle_emoji()-> void:
    var _need_show_emoji: = false
    var _relation_value: int = 0


    if right_hero_uid_change_to == "minor_hero_0012":
        dialogue_name_frame_right_with_emoji_node.hide()
        dialogue_name_frame_right_node.show()
        return

    var _hero_json: Dictionary = {}
    if SoldierUtils.is_hero_by_uid(right_hero_uid_change_to):
        _hero_json = SoldierUtils.get_hero_json(right_hero_uid_change_to)


    if SoldierUtils.is_lord(_hero_json):
        _need_show_emoji = true
        _relation_value = SoldierUtils.get_player_relation_value(_hero_json.uid)
    else:

        if b_team_dialogue_info.has("uid"):
            var _team_node = TeamUtils.get_mw_team_node_by_id(b_team_dialogue_info.uid)
            if _team_node == null:
                return
            var _team_role: MWTeamConstants.TEAM_ROLE_ENUM = _team_node.get_team_role()
            if[
                MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER,
                MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY
            ].has(_team_role):
                _need_show_emoji = true
                _relation_value = LocationUtils.get_player_relation_value_int(b_team_dialogue_info.origin_location_code)

    if _need_show_emoji:
        dialogue_name_frame_right_with_emoji_node.show()
        dialogue_name_frame_right_node.hide()
        relation_emoji_node.init(_relation_value)
    else:
        dialogue_name_frame_right_with_emoji_node.hide()
        dialogue_name_frame_right_node.show()

func _execute(_dialogue_json: Dictionary)-> void:
    _execute_depth += 1
    if _execute_depth > 100:
        printerr("DialogueInterface._execute: 递归深度超过100，强制终止对话")
        _execute_depth = 0
        finish.emit(result_option_type, _dialogue_json)
        return

    if _dialogue_json.has("event_end"):
        _dialogue_json.event_code = event_code

    if not _dialogue_json.has("step_type"):


        _handle_final_custom_func()
        _execute_depth = 0
        finish.emit(result_option_type, _dialogue_json)
        return

    if _dialogue_json.has("turn"):
        turn = _dialogue_json.turn


    _handle_special_field(_dialogue_json)

    match _dialogue_json.step_type:
        DialogueConstants.STEP_TYPE_ENUM.DIALOG:
            var _random_content_json: = _choose_content_json(_dialogue_json)



            if _random_content_json.is_empty():
                if _dialogue_json.has("next"):
                    _execute(_dialogue_json.next)

                    _execute_depth -= 1
                else:
                    _execute_depth = 0
                    finish.emit(result_option_type, _dialogue_json)
                return

            if _random_content_json.has("change_result_option_type"):
                result_option_type = _random_content_json.change_result_option_type


            var _hero_uid = CommonUtils.get_value(_dialogue_json, "turn_hero_uid", "")


            var _content: String = _random_content_and_handle_func_str(_random_content_json)


            _show_dialogue(_content, _hero_uid)


            _handle_special_field(_random_content_json)

            if _random_content_json.has("next"):
                dialogue_json = _random_content_json.next
            elif _dialogue_json.has("next"):
                dialogue_json = _dialogue_json.next
            else:
                dialogue_json = {}

        DialogueConstants.STEP_TYPE_ENUM.OPTION:
            is_making_choice = true

            dialogue_option_interface_node.init(_dialogue_json)
            dialogue_option_interface_node.cshow()



    _execute_depth -= 1












func _random_content_and_handle_func_str(_content_json: Dictionary)-> String:
    var _content: String = _content_json.clist.pick_random()
    if not _content_json.has("str_from_func"):

        if StringUtils.is_empty(_content):
            return "……"
        return _content








    _content = DialogueUtils.handle_str_from_func(_content, _content_json.str_from_func)




    if StringUtils.is_empty(_content) or _content.contains("#{0}") or _content.contains("#{1}"):
        return "……"

    return _content

func _show_dialogue(_content: String, _hero_uid: String = ""):

    if origin_right_hero_uid == "minor_hero_0012":
        dialogue_name_frame_right_with_emoji_node.hide()
        dialogue_name_frame_right_node.show()

    match turn:
        DialogueConstants.SPEAKER_ENUM.A:
            if is_first_dialogue:
                switch_animation_player_node.play("left_show")
                switch_animation_player_node.seek(1, true)
                is_first_dialogue = false
                current_ani_turn = CommonConstants.DIRECTION_ENUM.LEFT
            elif current_ani_turn != CommonConstants.DIRECTION_ENUM.LEFT:
                switch_animation_player_node.play("left_show")
                current_ani_turn = CommonConstants.DIRECTION_ENUM.LEFT


            _hero_uid = origin_left_hero_uid if _hero_uid == "" else _hero_uid
            if _hero_uid != left_hero_uid_change_to:
                left_hero_uid_change_to = _hero_uid
                change_persion_animation_player_node.play("change_left")

        DialogueConstants.SPEAKER_ENUM.B:
            if is_first_dialogue:
                switch_animation_player_node.play_backwards("left_show")
                switch_animation_player_node.seek(0, true)
                is_first_dialogue = false
                current_ani_turn = CommonConstants.DIRECTION_ENUM.RIGHT
            elif current_ani_turn != CommonConstants.DIRECTION_ENUM.RIGHT:

                switch_animation_player_node.play_backwards("left_show")
                current_ani_turn = CommonConstants.DIRECTION_ENUM.RIGHT


            _hero_uid = origin_right_hero_uid if _hero_uid == "" else _hero_uid
            if _hero_uid != right_hero_uid_change_to:
                right_hero_uid_change_to = _hero_uid
                change_persion_animation_player_node.play("change_right")

    turn = DialogueUtils.get_inverse_speaker_enum(turn)

    is_first_dialogue = false
    _update_content(_content)
    _update_tip()

    var _speed_scale = 10.0 / max(_content.length(), 1)
    content_animation_player_node.speed_scale = _speed_scale
    content_animation_player_node.play("show_content")

func _update_content(_content: String)-> void:

    _content = _replace_str(_content)




    _content = _content.replace("[", "{color}")
    _content = _content.replace("]", "{/color}")
    _content = _content.replace("{color}", "[color=" + DialogueConstants.IMPORTANT_CONTENT_COLOR + "]")
    _content = _content.replace("{/color}", "[/color]")

    content_node.text = _content
    is_content_show_finish = false

func _replace_str(_content: String)-> String:
    if _content.is_empty():
        return _content
    var _iteration_count: int = 0
    while(_content.find("#{") != -1):
        _iteration_count += 1
        if _iteration_count > 50:
            printerr("DialogueInterface._replace_str: 替换迭代超过50次，强制终止，内容: ", _content)
            break
        var _start_idx: int = _content.find("#{")
        var _end_idx: int = _content.find("}", _start_idx)
        if _end_idx == -1:
            break
        var _field = StringUtils.substring(_content, _start_idx + 2, _end_idx)
        var _field_real = StringUtils.substringEnd(_field, 2)
        var _field_special = "#{" + _field + "}"
        if _field.begins_with("a_"):

            _content = _content.replace(_field_special, str(CommonUtils.get_value(a_team_dialogue_info, _field_real, "?")))
        else:

            _content = _content.replace(_field_special, str(CommonUtils.get_value(b_team_dialogue_info, _field_real, "?")))

    return _content

func _clear():

    turn = DialogueConstants.SPEAKER_ENUM.B
    dialogue_json = {}
    is_first_dialogue = true
    a_team_dialogue_info = {}
    b_team_dialogue_info = {}
    dialogue_option_interface_node.clear()
    current_ani_turn = CommonConstants.DIRECTION_ENUM.RIGHT
    hero_uid = ""
    result_option_type = DialogueConstants.OPTION_TYPE_ENUM.EXIT_CONVERSATION
    origin_left_hero_uid = ""
    origin_right_hero_uid = ""
    event_code = ""
    npc_info = {}
    join_battle_team_info_box_node.chide()
    relation_emoji_node.hide_tip()
    final_custom_func_list = []

    GlobalTempData.update_dialogue_info({},{})

    is_making_choice = false

    _execute_depth = 0

func _content_show_finish():
    is_content_show_finish = true
    _update_tip()

func _update_tip():
    if is_content_show_finish:
        CommonUtils.set_text(tip_node, "点击确认...")
    else:
        CommonUtils.set_text(tip_node, "对话中...")

func _confirm():
    if not is_content_show_finish:
        is_content_show_finish = true
        content_animation_player_node.stop()
        content_node.visible_ratio = 1
        _update_tip()
    else:
        _next_step()


func _next_step():
    _execute(dialogue_json)


func _handle_special_field(_json: Dictionary):
    if _json.has("change_current_dialogue_flag") and StringUtils.is_not_empty(hero_uid):

        DialogueUtils.change_current_dialogue_flag(hero_uid, _json.change_current_dialogue_flag)
    if _json.has("dialogue_save_info"):
        DialogueUtils.save_dialogue_save_info(hero_uid, _json.dialogue_save_info)
    if _json.has("plus_dialogue_save_info_num"):
        DialogueUtils.plus_dialogue_save_info_num(hero_uid, _json.plus_dialogue_save_info_num)
    if _json.has("update_dialogue_save_info_system_counter") and _json.update_dialogue_save_info_system_counter:
        DialogueUtils.save_dialogue_save_info(
            hero_uid,
            {
                "system_counter": WSData.system_counter
            }
        )
    if _json.has("hire_hero_success"):
        WSData.add_hero(_json.hire_hero_success)
    if _json.has("change_current_dialogue_flag_config"):
        for _change_current_dialogue_flag_config_item_json in _json.change_current_dialogue_flag_config:
            DialogueUtils.change_current_dialogue_flag(
                _change_current_dialogue_flag_config_item_json.hero_uid,
                _change_current_dialogue_flag_config_item_json.dialogue_flag,
            )

    if _json.has("custom_func"):





        _handle_custom_func(_json.custom_func)


    if StringUtils.is_not_empty(DialogueCustomUtils._mod_just_joined_country):
        var _cg_country_code: String = DialogueCustomUtils._mod_just_joined_country
        DialogueCustomUtils._mod_just_joined_country = ""
        mod_show_join_country_cg_sign.emit(_cg_country_code)


func _on_gui_input(event):
    if MouseUtils.check_mouse_left_click(event):
        if not is_making_choice:
            _confirm()


func _on_dialogue_option_interface_choose(_option_json):
    result_option_type = _option_json.otype

    last_selected_oname = _option_json.get("oname", "")
    var _content_json: = _choose_content_json(_option_json)

    if _option_json.has("turn"):
        turn = _option_json.turn


    if _option_json.has("custom_func"):





        _handle_custom_func(_option_json.custom_func)

    if _content_json.has("clist"):
        var _content: String = _random_content_and_handle_func_str(_content_json)

        _show_dialogue(_content)


    if _content_json.has("execute"):
        match _content_json.execute:
            DialogueConstants.EXECUTE_TYPE_ENUM.PLUS_MONEY:
                if CommonUtils.get_value(_content_json, "use_hire_money", false):

                    npc_info.is_hire = true

                    WSLocationData.remove_npc_info(npc_info)

                    WSData.update_money(- b_team_dialogue_info.hire_money, true)

                    WSData.add_soldier(
                        SoldierUtils.generate_simple_json_list(
                            b_team_dialogue_info.npc_uid,
                            b_team_dialogue_info.soldier_count
                        ),
                        TeamConfig.NEW_SOLDIER_MORALE
                    )

                    GlobalMessageInterface.add_message(
                        MessageConstants.MESSAGE_ENUM.HIRE_SUCCESS_MESSAGE,
                        [str(b_team_dialogue_info.soldier_count) + "名" + b_team_dialogue_info.leader_name]
                    )
                else:
                    WSData.update_money(_content_json.execute_value, true)

            DialogueConstants.EXECUTE_TYPE_ENUM.MINUS_ITEM:
                var _item_uid: String = _content_json.execute_item_uid
                var _item_count: int = _content_json.execute_value
                var _goods_list: Array = WSData.get_player_goods()
                GoodsUtils.subtract_goods_by_uid(_goods_list, _item_uid, _item_count)
                WSData.save_my_goods(_goods_list)
                GlobalMessageInterface.add_lost_goods_message(_item_uid)


    _handle_special_field(_content_json)

    is_making_choice = false
    match result_option_type:
        DialogueConstants.OPTION_TYPE_ENUM.INSPECT_TREASURES:
            exchange_small_interface_node.init(b_team_dialogue_info.exchange_treasure, b_team_dialogue_info.uid)
            exchange_small_interface_node.show()
        DialogueConstants.OPTION_TYPE_ENUM.SELL_PRISONER:
            prisoner_exchange_interface_node.init(
                CommonUtils.get_value(_option_json, "is_special_slave_trader_price", false),
                origin_right_hero_uid
            )
            prisoner_exchange_interface_node.show()

    if _option_json.has("next"):
        dialogue_json = _option_json.next
    elif _content_json.has("next"):
        dialogue_json = _content_json.next
    else:
        dialogue_json = {}

    if not _content_json.has("clist") and result_option_type == DialogueConstants.OPTION_TYPE_ENUM.LEAVE:
        _next_step()

func _on_exchange_small_interface_cancel_sign():
    _next_step()

func _on_exchange_small_interface_submit_sign():

    b_team_dialogue_info = WSData.get_team_node(b_team_dialogue_info.uid).get_dialogue_info()
    _next_step()

func _on_prisoner_exchange_interface_close_sign()-> void:
    _next_step()