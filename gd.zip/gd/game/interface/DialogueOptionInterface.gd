extends Control
class_name DialogueOptionInterface

@onready var v_box_container_node =$VBoxContainer
@onready var dialogue_option_button_node = preload("res://tscn/baseModule/button/DialogueOptionButton.tscn")

const DIALOGUE_OPTION_CONTENT_BOX_ADAPTIVE = preload("res://tscn/game/interface/ws/DialogueOptionContentBoxAdaptive.tscn")

var init_postion_x: = 400
var init_position_y: = 0






var _panel_generation: int = 0
var _active_tween: Tween = null

signal choose(_option_json)

func _ready():
    init_position_y = self.position.y








func init(
    _dialogue_json: Dictionary
):
    clear()


    if _dialogue_json.has("option_content"):
        var _dialogue_option_content_box_node: = DIALOGUE_OPTION_CONTENT_BOX_ADAPTIVE.instantiate()
        v_box_container_node.add_child(_dialogue_option_content_box_node)

        var _content: String = _dialogue_json.option_content
        if _dialogue_json.has("str_from_func"):
            _content = DialogueUtils.handle_str_from_func(_content, _dialogue_json.str_from_func)

            _content = _content.replace("[", "{color}")
            _content = _content.replace("]", "{/color}")
            _content = _content.replace("{color}", "[color=" + DialogueConstants.IMPORTANT_CONTENT_COLOR + "]")
            _content = _content.replace("{/color}", "[/color]")

        _dialogue_option_content_box_node.init(_content)

        self.position.y = init_position_y
    else:
        self.position.y = init_position_y + 24

    var _option_list = _dialogue_json.option_list
    for _option_json in _option_list:

        var _is_match: bool = owner.condition_match(_option_json)
        if not _is_match:
            continue

        var dialogue_option_button_instance = dialogue_option_button_node.instantiate() as DialogueOptionButton
        v_box_container_node.add_child(dialogue_option_button_instance)
        dialogue_option_button_instance.init(_option_json)
        dialogue_option_button_instance.connect("pressed_retract_finish", chide)
        dialogue_option_button_instance.connect("cpressed", _choose)

func _choose(_option_json):
    emit_signal("choose", _option_json)

func clear():
    CommonUtils.clear_node(v_box_container_node)

func chide():




    _panel_generation += 1
    var _my_generation: int = _panel_generation
    if _active_tween != null and _active_tween.is_valid():
        _active_tween.kill()
    _active_tween = get_tree().create_tween()
    _active_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _active_tween.tween_property(v_box_container_node, "position:x", init_postion_x, 0.2)

    _active_tween.connect("finished", _chide2.bind(_my_generation))

func cshow():




    _panel_generation += 1
    if _active_tween != null and _active_tween.is_valid():
        _active_tween.kill()
    self.show()
    v_box_container_node.position.x = init_postion_x
    _active_tween = get_tree().create_tween()
    _active_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _active_tween.tween_property(v_box_container_node, "position:x", 0, 0.2)

func _chide2(_generation: int)-> void:

    if _generation != _panel_generation:
        return
    self.hide()