class_name ExportSaveDataDetailList extends VBoxContainer

@onready var request_permissions_root: Control =$"../../RequestPermissionsRoot"

const EXPORT_SAVE_DETAIL_ITEM = preload("res://tscn/game/interface/ExportSaveDetailItem.tscn")

signal import_save_data_sign(save_summary_json: Dictionary)

func init_by_dir_path(_dir_path: String)-> void:
    var _save_summary_dat_file_path = _dir_path.path_join("save_summary.dat")
    var _file = FileAccess.open(_save_summary_dat_file_path, FileAccess.READ)
    if _file == null:

        clear()










        request_permissions_root.show()
    else:
        init_by_save_summary_dic(_file.get_var())
        request_permissions_root.hide()

var _file_dialog: FileDialog = null

func _picker_callback(status: bool, selected_uris: PackedStringArray, _selected_filter_index: int):
    pass

func open_import_save_dialog()-> void:
    if _file_dialog != null:
        _file_dialog.queue_free()

    _file_dialog = FileDialog.new()
    _file_dialog.title = "请选择存档文件夹"
    _file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
    _file_dialog.use_native_dialog = true
    _file_dialog.access = FileDialog.ACCESS_FILESYSTEM



    var downloads_path = GlobalSave.EXPORT_PATH_PREFIX
    _file_dialog.current_dir = downloads_path.path_join("Rodri")


    _file_dialog.dir_selected.connect(_on_dir_selected)
    _file_dialog.canceled.connect(_on_dialog_canceled)

    get_tree().root.add_child(_file_dialog)
    _file_dialog.popup_centered_ratio(0.8)


func _on_dir_selected(_selected_dir: String)-> void:
    print("用户选择了文件夹: ", _selected_dir)


    if _file_dialog:
        _file_dialog.queue_free()
        _file_dialog = null


    init_by_dir_path(_selected_dir)


func _on_dialog_canceled()-> void:
    if _file_dialog:
        _file_dialog.queue_free()
        _file_dialog = null
    print("用户取消了文件夹选择")

func init_by_save_summary_dic(_save_summary_dic: Dictionary)-> void:
    clear()


    for _index in range(_save_summary_dic.size() - 1, -1, -1):
        var _summary_json = _save_summary_dic.values()[_index]
        var _instance_node: ExportSaveDetailItem = EXPORT_SAVE_DETAIL_ITEM.instantiate()
        add_child(_instance_node)
        _instance_node.init(_summary_json)
        _instance_node.connect("import_save_data_sign", _import_save_data)

func _import_save_data(_import_save_data_sign: Dictionary)-> void:
    import_save_data_sign.emit(_import_save_data_sign)

func clear():
    CommonUtils.clear_node(self)