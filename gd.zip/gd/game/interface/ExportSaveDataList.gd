class_name ExportSaveDataList extends VBoxContainer

const EXPORT_SAVE_DATA_LIST_ITEM_BOX = preload("res://tscn/game/interface/ExportSaveDataListItemBox.tscn")

var _choose_node: ExportSaveDataListItemBox

signal choose_sign(_export_save_data_dir: Dictionary)

func init()-> void:
    var _export_save_data_dir_list: Array = GlobalSave.list_export_save_data_dir()

    for _export_save_data_dir: Dictionary in _export_save_data_dir_list:
        var _export_save_data_list_item_box_node: = EXPORT_SAVE_DATA_LIST_ITEM_BOX.instantiate()
        self.add_child(_export_save_data_list_item_box_node)

        _export_save_data_list_item_box_node.init(_export_save_data_dir)
        _export_save_data_list_item_box_node.connect("choose_sign", _choose)

func unchoose()-> void:
    if CommonUtils.is_not_null(_choose_node):
        _choose_node.unchoose()
        _choose_node = null


func _choose(_node: ExportSaveDataListItemBox)-> void:
    if CommonUtils.is_not_null(_choose_node):
        _choose_node.unchoose()

    _choose_node = _node
    choose_sign.emit(_node.export_save_data_dir)

func clear()-> void:
    CommonUtils.clear_node(self)