class_name ExportSaveDataListItemBox extends Control

@onready var name_node: Label =$Button / Name
@onready var button_node: BaseSelectButton =$Button

var export_save_data_dir: = {}

signal choose_sign(_node: ExportSaveDataListItemBox)

func init(_export_save_data_dir: Dictionary)-> void:
    CommonUtils.update_text(name_node, _export_save_data_dir.name)
    export_save_data_dir = _export_save_data_dir

func unchoose()-> void:
    button_node.cancel()

func _on_button_b_pressed()-> void:
    choose_sign.emit(self)