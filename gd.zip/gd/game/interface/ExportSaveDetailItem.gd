class_name ExportSaveDetailItem extends SaveItem02

signal import_save_data_sign(save_summary_json: Dictionary)

func _custom_init()-> void:
    avatar_ani_node.play_animation()

func _on_import_save_data_button_custom_pressed()-> void:
    import_save_data_sign.emit(save_summary_json)