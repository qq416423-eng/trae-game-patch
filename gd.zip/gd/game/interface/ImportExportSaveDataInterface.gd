class_name ImportExportSaveDataInterface extends Control

@onready var export_save_data_list_node: ExportSaveDataList =$ExportSaveDataListRoot / BaseScrollContainer / ExportSaveDataList
@onready var func_root_node: Control =$FuncRoot
@onready var export_save_data_detail_list_root_node: Control =$ExportSaveDataDetailListRoot
@onready var export_save_data_detail_list_node: ExportSaveDataDetailList =$ExportSaveDataDetailListRoot / BaseScrollContainer / ExportSaveDataDetailList
@onready var save_data_dir_name_node: Label =$ExportSaveDataDetailListRoot / Background / TitleBackground / SaveDataDirName
@onready var import_confirm_box_node: ConfirmBox =$SubPageRoot / ImportConfirmBox
@onready var export_confirm_box_node: ConfirmBox =$SubPageRoot / ExportConfirmBox
@onready var exist_permisson_page_node: Control =$ExportSaveDataDetailListRoot / RequestPermissionsRoot / ExistPermissonPage
@onready var not_exist_permisson_page_node: Control =$ExportSaveDataDetailListRoot / RequestPermissionsRoot / NotExistPermissonPage

var wait_to_import_save_summary_json: = {}
var dir_path: = ""

var has_imported: = false

signal close_page_sign(_has_imported: bool)

func _ready()-> void:
    init()
    _reset()





    if GameConfig.need_manage_external_storage_edition:
        exist_permisson_page_node.show()
        not_exist_permisson_page_node.hide()
    else:
        exist_permisson_page_node.hide()
        not_exist_permisson_page_node.show()

func init()-> void:
    export_save_data_list_node.init()

func _delete_page()-> void:
    self.queue_free()

func _reset()-> void:
    func_root_node.show()
    export_save_data_detail_list_root_node.hide()

func _on_export_save_data_list_choose_sign(_export_save_data_dir: Dictionary)-> void:
    dir_path = _export_save_data_dir.path

    func_root_node.hide()
    export_save_data_detail_list_root_node.show()
    export_save_data_detail_list_node.init_by_dir_path(dir_path)
    CommonUtils.update_text(save_data_dir_name_node, "(" + _export_save_data_dir.name + ")")

func _on_export_save_data_detail_list_root_close_button_custom_pressed()-> void:
    export_save_data_detail_list_node.clear()
    export_save_data_detail_list_root_node.hide()
    func_root_node.show()
    export_save_data_list_node.unchoose()


func _on_export_save_data_detail_list_import_save_data_sign(_save_summary_json: Dictionary)-> void:
    wait_to_import_save_summary_json = _save_summary_json
    import_confirm_box_node.open()
    import_confirm_box_node.update_content(
        "是否导入存档 (" + SystemUtils.get_save_name(_save_summary_json) + ")?"
    )


func _on_import_confirm_box_confirm()-> void:
    GlobalSave.import_save_data(
        wait_to_import_save_summary_json,
        dir_path
    )
    has_imported = true

func _on_func_root_close_button_custom_pressed()-> void:
    _delete_page()
    close_page_sign.emit(has_imported)


func _on_export_button_custom_pressed()-> void:
    export_confirm_box_node.open()


func _on_export_confirm_box_confirm()-> void:
    var _dir_name: String = GlobalSave.export_save_data()

    if StringUtils.is_not_empty(_dir_name):
        GlobalMessageInterface.add_export_save_data_success_message(_dir_name)
        export_save_data_list_node.clear()
        init()

func _on_request_permissons_button_custom_pressed()-> void:
    OS.request_permissions()

func _on_refresh_button_custom_pressed()-> void:
    export_save_data_detail_list_node.init_by_dir_path(dir_path)

func _on_no_permission_description_meta_clicked(meta: Variant)-> void:

    if str(meta).begins_with("http"):
        OS.shell_open(str(meta))