class_name LoadGameInterface extends Control

@onready var save_list_root_node: SaveListRoot =$SaveListRoot / SaveListScroll / SaveListRoot

@onready var hero_level_node: IconKeyValue =$DetailRoot / BasePropRoot / HeroLevel
@onready var base_strength_node: IconKeyValue =$DetailRoot / BasePropRoot / BaseStrength
@onready var base_agile_node: IconKeyValue =$DetailRoot / BasePropRoot / BaseAgile
@onready var base_physical_node: IconKeyValue =$DetailRoot / BasePropRoot / BasePhysical
@onready var base_intelligence_node: IconKeyValue =$DetailRoot / BasePropRoot / BaseIntelligence
@onready var combat_power_node: IconKeyValue =$DetailRoot / BasePropRoot / CombatPower
@onready var money_node: IconKeyValue =$DetailRoot / TeamPropRoot / Money
@onready var nop_node: IconKeyValue =$DetailRoot / TeamPropRoot / Nop
@onready var hero_nop_node: IconKeyValue =$DetailRoot / TeamPropRoot / HeroNop
@onready var update_time_node: IconKeyValue =$DetailRoot / UpdateTime
@onready var title_node: Label =$DetailRoot / Title
@onready var delete_confirm_box_node: ConfirmBox =$SubPageRoot / DeleteConfirmBox
@onready var base_prop_root_node: Control =$DetailRoot / BasePropRoot
@onready var team_prop_root_node: Control =$DetailRoot / TeamPropRoot
@onready var detail_root_button_root_node: Control =$DetailRoot / ButtonRoot
@onready var team_info_background_node: TextureRect =$DetailRoot / TeamInfoBackground
@onready var portrait_background_node: NinePatchRect =$DetailRoot / PortraitBackground
@onready var hero_portrait_node: HeroPortrait =$DetailRoot / PortraitBackground / HeroPortrait
@onready var lord_banner_node: LordBanner =$DetailRoot / PortraitBackground / LordBanner
@onready var sub_page_root_node: Control =$SubPageRoot
@onready var button_root_node: VBoxContainer =$ButtonRoot
@onready var rename_box_node: RenameBox =$SubPageRoot / RenameBox

const IMPORT_EXPORT_SAVE_DATA_INTERFACE = preload("res://tscn/game/interface/ImportExportSaveDataInterface.tscn")


var current_choose_save_node: SaveItem02

signal close_sign()
signal load_save_success_sign()

func _ready()-> void:



    pass

func init()-> void:

    if GlobalSave.save_summary_dic.size() == 0:
        update_time_node.hide()
        title_node.hide()
        base_prop_root_node.hide()
        team_prop_root_node.hide()
        detail_root_button_root_node.hide()
        team_info_background_node.hide()
        portrait_background_node.hide()
    else:
        update_time_node.show()
        title_node.show()
        base_prop_root_node.show()
        team_prop_root_node.show()
        detail_root_button_root_node.show()
        team_info_background_node.show()
        portrait_background_node.show()

    save_list_root_node.init(GlobalSave.save_summary_dic)

    save_list_root_node.choose(0, false)


func load(_save_index: int)-> void:
    init()

    GlobalSave.cload(save_list_root_node.get_children()[_save_index].get_save_code())
    load_save_success_sign.emit()

func _update_detail(_save_summary_json: Dictionary)-> void:
    var _hero_json: Dictionary = _save_summary_json.player_hero_json
    var _team_json: Dictionary = _save_summary_json.team_json

    var _update_time: = ""
    if _save_summary_json.has("update_time"):
        _update_time = Time.get_datetime_string_from_unix_time(_save_summary_json.update_time / 1000, true)

    CommonUtils.set_text(title_node, _hero_json.name + " (" + str(int(_save_summary_json.system_counter + 1)) + "天)")
    update_time_node.update_value(_update_time)

    hero_level_node.update_value(_hero_json.level)
    base_strength_node.update_value(_hero_json.base_strength + _hero_json.skill_strength * SkillConfig.SKILL_BASE_PROP_PLUS)
    base_agile_node.update_value(_hero_json.base_agile + _hero_json.skill_agile * SkillConfig.SKILL_BASE_PROP_PLUS)
    base_physical_node.update_value(_hero_json.base_physical + _hero_json.skill_physical * SkillConfig.SKILL_BASE_PROP_PLUS)
    base_intelligence_node.update_value(_hero_json.base_intelligence)
    combat_power_node.update_value(_hero_json.combat_power)

    money_node.update_value(int(_team_json.money))
    nop_node.update_value(_team_json.team.size())

    hero_portrait_node.init_by_gender(_hero_json.gender)

    var _hero_nop: = 0
    for _simple_json in _team_json.team:
        if CommonUtils.get_value(_simple_json, "htype", BSSoldierConstants.H_TYPE_ENUM.SOLDIER) == BSSoldierConstants.H_TYPE_ENUM.HERO:
            _hero_nop += 1

    hero_nop_node.update_value(_hero_nop)


    lord_banner_node.init_by_banner_config(
        CommonUtils.get_value(_hero_json, "banner_config",{})
    )

func _hide_button_root()-> void:
    button_root_node.hide()

func _show_button_root()-> void:
    button_root_node.show()

func _close_import_export_save_data_interface_hook(_has_imported: bool)-> void:
    _show_button_root()
    if _has_imported:
        init()

func _on_save_list_root_choose_sign(_node: SaveItem02)-> void:
    current_choose_save_node = _node
    _update_detail(_node.save_summary_json)

func _on_close_button_pressed()-> void:
    hide()
    close_sign.emit()


func _on_load_button_pressed()-> void:
    if CommonUtils.is_null(current_choose_save_node):
        return

    hide()

    GlobalSave.cload(current_choose_save_node.get_save_code())
    load_save_success_sign.emit()


func _on_delete_button_pressed()-> void:
    delete_confirm_box_node.show()


func _on_delete_confirm_box_confirm()-> void:
    if CommonUtils.is_null(current_choose_save_node):
        return

    GlobalSave.delete(current_choose_save_node.get_save_code())

    init()


func _on_import_export_save_data_button_custom_pressed()-> void:

    var _node: = IMPORT_EXPORT_SAVE_DATA_INTERFACE.instantiate()
    sub_page_root_node.add_child(_node)

    _node.connect(
        "close_page_sign",
        _close_import_export_save_data_interface_hook
    )

    _hide_button_root()

func _on_rename_save_name_button_custom_pressed()-> void:
    rename_box_node.open()
    rename_box_node.set_line_edit(
        current_choose_save_node.get_save_name()
    )


func _on_rename_box_rename_sign(_new_name: String)-> void:
    current_choose_save_node.save_summary_json.save_name = _new_name
    GlobalSave.save_save_summary_dic()

    current_choose_save_node.refresh_save_name()


    GlobalMessageInterface.add_rename_save_name_success_message(_new_name)