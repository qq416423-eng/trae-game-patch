extends Control

signal close_page_sign


const BET_AMOUNTS: Array = [50, 100, 200, 500, 1200]
const MULTIPLIERS: Array = [2, 3, 5, 10]


const MULT_WINDOW: Dictionary = {2: 0.22, 3: 0.15, 5: 0.09, 10: 0.045}

const GUESS_MAX_DIGITS: int = 9

const DAILY_LIMIT: int = 2

const DAILY_COEF_MIN: float = 0.8
const DAILY_COEF_MAX: float = 1.25

const PANEL_W: int = 840
const PANEL_H: int = 640
const SCREEN_MARGIN: int = 20
const LEFT_COL_W: int = 300

const STAKE_SHOW_MAX: int = 4


const QUALITY_NAME: Dictionary = {
    0: "残破", 1: "瑕疵", 2: "普通", 3: "精良", 4: "卓越", 5: "传说", 6: "神品"
}
const QUALITY_WEIGHT: Dictionary = {2: 60, 3: 25, 4: 10, 5: 5}


const C_OVERLAY: Color = Color(0.07, 0.05, 0.03, 0.62)
const C_WOOD: Color = Color(0.4, 0.28, 0.15)
const C_WOOD_DARK: Color = Color(0.23, 0.15, 0.07)
const C_WOOD_LIGHT: Color = Color(0.74, 0.62, 0.44)
const C_PAPER: Color = Color(0.89, 0.83, 0.71)
const C_PAPER_2: Color = Color(0.95, 0.9, 0.8)
const C_PAPER_BD: Color = Color(0.66, 0.56, 0.4)
const C_INK: Color = Color(0.24, 0.16, 0.08)
const C_INK_DIM: Color = Color(0.44, 0.34, 0.21)
const C_ACCENT: Color = Color(0.8, 0.58, 0.15)
const C_ACCENT_DK: Color = Color(0.56, 0.38, 0.09)
const C_RED: Color = Color(0.62, 0.24, 0.17)
const C_GREEN: Color = Color(0.26, 0.45, 0.18)
const C_BLUE: Color = Color(0.24, 0.36, 0.55)


var _city_code: String = ""
var _mode: int = 0
var _bet: int = 0
var _mult: int = 0
var _stake_item: Dictionary = {}
var _cur_uid: String = ""
var _cur_quality: int = 2
var _cur_name: String = ""
var _cur_star: int = 0
var _cur_remark: String = ""
var _cur_true_price: int = 0
var _cur_guess: int = 0
var _cur_offset: float = 0.0
var _is_busy: bool = false
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()


var _overlay: ColorRect
var _safe: MarginContainer
var _center: CenterContainer
var _panel: PanelContainer
var _title_label: Label
var _money_label: Label
var _daily_label: Label
var _item_icon: TextureRect
var _item_name_label: Label
var _item_tag_label: Label
var _item_remark_label: Label
var _guess_edit: LineEdit
var _guess_tip: Label
var _mode_hbox: HBoxContainer
var _mode_money_btn: Button
var _mode_treasure_btn: Button
var _bet_title: Label
var _bet_hbox: HBoxContainer
var _bet_buttons: Array = []
var _stake_title: Label
var _stake_list: VBoxContainer
var _mult_hbox: HBoxContainer
var _mult_buttons: Array = []
var _window_label: Label
var _result_label: Label
var _reveal_btn: Button
var _skip_btn: Button
var _close_btn: Button

var _all_mult_buttons: Array = []


func _ready()-> void:
    _rng.randomize()

    mouse_filter = Control.MOUSE_FILTER_STOP
    _build_ui()

    _fit_to_screen()
    var _vp: Viewport = get_viewport()
    if _vp != null:
        _vp.size_changed.connect(_fit_to_screen)
    hide()


func init(_code: String)-> void:
    _city_code = _code




func _fit_to_screen()-> void:
    var _vs: Vector2 = get_viewport_rect().size
    position = Vector2.ZERO
    size = _vs
    if _panel != null:
        var _w: int = clampi(int(_vs.x) - SCREEN_MARGIN * 2, 360, PANEL_W)
        var _h: int = clampi(int(_vs.y) - SCREEN_MARGIN * 2, 320, PANEL_H)
        _panel.custom_minimum_size = Vector2(_w, _h)


func show_interface()-> void:
    if _city_code == "":
        _city_code = GlobalTempData.current_location_code
    _mode = 0
    _bet = 0
    _mult = 0
    _cur_guess = 0
    _stake_item = {}
    _is_busy = false
    _guess_edit.editable = true
    _reveal_btn.text = "揭 晓 行 情"
    _skip_btn.text = "换 一 件"
    _skip_btn.show()
    _reveal_btn.show()
    _reveal_btn.disabled = false
    _skip_btn.disabled = false
    show()
    _fit_to_screen()
    _update_mode_buttons()
    _apply_mode_visibility()
    _refresh_daily()
    _new_round()
    _update_all_mult_buttons()

    _panel.modulate.a = 0.0
    var _t: Tween = get_tree().create_tween()
    _t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _t.tween_property(_panel, "modulate:a", 1.0, 0.16)


func hide_interface()-> void:
    hide()
    close_page_sign.emit()



func _build_ui()-> void:

    _overlay = ColorRect.new()
    _overlay.color = C_OVERLAY
    _overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(_overlay)


    _safe = MarginContainer.new()
    _safe.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _safe.add_theme_constant_override("margin_left", 16)
    _safe.add_theme_constant_override("margin_right", 16)
    _safe.add_theme_constant_override("margin_top", 12)
    _safe.add_theme_constant_override("margin_bottom", 12)
    add_child(_safe)

    _center = CenterContainer.new()
    _center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _safe.add_child(_center)


    _panel = PanelContainer.new()
    _panel.add_theme_stylebox_override("panel", _flat(C_WOOD, C_WOOD_DARK, 3, 2))
    _center.add_child(_panel)

    var _pm: MarginContainer = MarginContainer.new()
    _pm.add_theme_constant_override("margin_left", 8)
    _pm.add_theme_constant_override("margin_right", 8)
    _pm.add_theme_constant_override("margin_top", 8)
    _pm.add_theme_constant_override("margin_bottom", 8)
    _panel.add_child(_pm)


    var _paper: PanelContainer = PanelContainer.new()
    _paper.add_theme_stylebox_override("panel", _flat(C_PAPER, C_PAPER_BD, 1, 1))
    _pm.add_child(_paper)

    var _pad: MarginContainer = MarginContainer.new()
    _pad.add_theme_constant_override("margin_left", 16)
    _pad.add_theme_constant_override("margin_right", 16)
    _pad.add_theme_constant_override("margin_top", 12)
    _pad.add_theme_constant_override("margin_bottom", 12)
    _paper.add_child(_pad)

    var _root: VBoxContainer = VBoxContainer.new()
    _root.add_theme_constant_override("separation", 8)
    _pad.add_child(_root)


    var _bar: HBoxContainer = HBoxContainer.new()
    _bar.add_theme_constant_override("separation", 8)
    _root.add_child(_bar)

    _title_label = Label.new()
    _title_label.text = "赌 物 人"
    _title_label.add_theme_font_size_override("font_size", 22)
    _title_label.add_theme_color_override("font_color", C_INK)
    _bar.add_child(_title_label)

    var _sub: Label = Label.new()
    _sub.text = "· 鉴价行当"
    _sub.add_theme_font_size_override("font_size", 13)
    _sub.add_theme_color_override("font_color", C_INK_DIM)
    _bar.add_child(_sub)

    var _spacer: Control = Control.new()
    _spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _bar.add_child(_spacer)

    _daily_label = Label.new()
    _daily_label.add_theme_font_size_override("font_size", 13)
    _daily_label.add_theme_color_override("font_color", C_INK_DIM)
    _bar.add_child(_daily_label)

    _money_label = Label.new()
    _money_label.add_theme_font_size_override("font_size", 13)
    _money_label.add_theme_color_override("font_color", C_ACCENT_DK)
    _bar.add_child(_money_label)

    _close_btn = _mk_btn("✕ 打烊", Vector2(76, 30), 14)
    _close_btn.pressed.connect(_on_close)
    _bar.add_child(_close_btn)

    _root.add_child(_rule_line())


    var _mid: HBoxContainer = HBoxContainer.new()
    _mid.add_theme_constant_override("separation", 12)
    _mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _root.add_child(_mid)


    var _left: VBoxContainer = VBoxContainer.new()
    _left.custom_minimum_size = Vector2(LEFT_COL_W, 0)
    _left.add_theme_constant_override("separation", 6)
    _mid.add_child(_left)

    _left.add_child(_mk_section("① 柜 上 的 货"))

    var _card: PanelContainer = PanelContainer.new()
    _card.add_theme_stylebox_override("panel", _flat(C_PAPER_2, C_PAPER_BD, 1, 2))
    _left.add_child(_card)

    var _cm: MarginContainer = MarginContainer.new()
    _cm.add_theme_constant_override("margin_left", 10)
    _cm.add_theme_constant_override("margin_right", 10)
    _cm.add_theme_constant_override("margin_top", 8)
    _cm.add_theme_constant_override("margin_bottom", 8)
    _card.add_child(_cm)

    var _cv: VBoxContainer = VBoxContainer.new()
    _cv.add_theme_constant_override("separation", 4)
    _cm.add_child(_cv)

    _item_icon = TextureRect.new()
    _item_icon.custom_minimum_size = Vector2(0, 88)
    _item_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    _item_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _cv.add_child(_item_icon)

    _item_name_label = Label.new()
    _item_name_label.add_theme_font_size_override("font_size", 18)
    _item_name_label.add_theme_color_override("font_color", C_INK)
    _item_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _item_name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _cv.add_child(_item_name_label)

    _item_tag_label = Label.new()
    _item_tag_label.add_theme_font_size_override("font_size", 14)
    _item_tag_label.add_theme_color_override("font_color", C_ACCENT_DK)
    _item_tag_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _item_tag_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _cv.add_child(_item_tag_label)

    _item_remark_label = Label.new()
    _item_remark_label.add_theme_font_size_override("font_size", 12)
    _item_remark_label.add_theme_color_override("font_color", C_INK_DIM)
    _item_remark_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _item_remark_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _item_remark_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _item_remark_label.custom_minimum_size = Vector2(0, 18)
    _cv.add_child(_item_remark_label)

    _left.add_child(_mk_section("② 你 的 出 价 (猜它值多少德里)"))

    var _qpanel: PanelContainer = PanelContainer.new()
    _qpanel.add_theme_stylebox_override("panel", _flat(C_WOOD, C_WOOD_DARK, 2, 2))
    _left.add_child(_qpanel)

    var _qm: MarginContainer = MarginContainer.new()
    _qm.add_theme_constant_override("margin_left", 10)
    _qm.add_theme_constant_override("margin_right", 10)
    _qm.add_theme_constant_override("margin_top", 8)
    _qm.add_theme_constant_override("margin_bottom", 8)
    _qpanel.add_child(_qm)

    var _qv: VBoxContainer = VBoxContainer.new()
    _qv.add_theme_constant_override("separation", 5)
    _qm.add_child(_qv)

    _guess_tip = Label.new()
    _guess_tip.text = "你猜它值多少?"
    _guess_tip.add_theme_font_size_override("font_size", 12)
    _guess_tip.add_theme_color_override("font_color", C_WOOD_LIGHT)
    _guess_tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _guess_tip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _qv.add_child(_guess_tip)

    _guess_edit = LineEdit.new()
    _guess_edit.placeholder_text = "填个数"
    _guess_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
    _guess_edit.custom_minimum_size = Vector2(0, 42)
    _guess_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _guess_edit.add_theme_font_size_override("font_size", 20)
    _guess_edit.add_theme_color_override("font_color", C_INK)
    _guess_edit.add_theme_color_override("font_placeholder_color", C_INK_DIM)
    _guess_edit.add_theme_color_override("caret_color", C_ACCENT_DK)
    _guess_edit.add_theme_stylebox_override("normal", _flat(C_PAPER_2, C_PAPER_BD, 1, 2))
    _guess_edit.add_theme_stylebox_override("focus", _flat(C_PAPER_2, C_ACCENT, 2, 2))
    _guess_edit.add_theme_stylebox_override("read_only", _flat(Color(0.83, 0.79, 0.71), C_PAPER_BD, 1, 2))
    _guess_edit.text_changed.connect(_on_guess_changed)
    _qv.add_child(_guess_edit)

    var _qunit: Label = Label.new()
    _qunit.text = "单位: 德里"
    _qunit.add_theme_font_size_override("font_size", 12)
    _qunit.add_theme_color_override("font_color", C_WOOD_LIGHT)
    _qunit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _qunit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _qv.add_child(_qunit)


    var _lpush: Control = Control.new()
    _lpush.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _left.add_child(_lpush)


    var _right: VBoxContainer = VBoxContainer.new()
    _right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _right.add_theme_constant_override("separation", 6)
    _mid.add_child(_right)

    _right.add_child(_mk_section("③ 定 倍 率 (越高越难中, 赔得越多)"))

    _mult_hbox = HBoxContainer.new()
    _mult_hbox.add_theme_constant_override("separation", 8)
    _right.add_child(_mult_hbox)

    for _m in MULTIPLIERS:
        var _btn: Button = _mk_btn("×" + str(_m), Vector2(0, 42), 18)
        _btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _btn.pressed.connect(_on_mult_selected.bind(_m))
        _mult_hbox.add_child(_btn)
        _mult_buttons.append(_btn)
        _all_mult_buttons.append(_btn)

    _window_label = Label.new()
    _window_label.add_theme_font_size_override("font_size", 12)
    _window_label.add_theme_color_override("font_color", C_BLUE)
    _window_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _window_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _window_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _window_label.custom_minimum_size = Vector2(0, 34)
    _right.add_child(_window_label)

    _right.add_child(_mk_section("④ 下 注 方 式"))

    _mode_hbox = HBoxContainer.new()
    _mode_hbox.add_theme_constant_override("separation", 8)
    _right.add_child(_mode_hbox)

    _mode_money_btn = _mk_btn("押 德 里", Vector2(0, 34), 15)
    _mode_money_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _mode_money_btn.pressed.connect(func(): _set_mode(0))
    _mode_hbox.add_child(_mode_money_btn)

    _mode_treasure_btn = _mk_btn("押 装 备", Vector2(0, 34), 15)
    _mode_treasure_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _mode_treasure_btn.pressed.connect(func(): _set_mode(1))
    _mode_hbox.add_child(_mode_treasure_btn)


    _bet_title = _mk_section("选 注 码 (押德里)")
    _right.add_child(_bet_title)

    _bet_hbox = HBoxContainer.new()
    _bet_hbox.add_theme_constant_override("separation", 6)
    _right.add_child(_bet_hbox)

    for _amount in BET_AMOUNTS:
        var _btn: Button = _mk_btn(str(_amount), Vector2(0, 40), 16)
        _btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _btn.pressed.connect(_on_bet_selected.bind(_amount))
        _bet_hbox.add_child(_btn)
        _bet_buttons.append(_btn)


    _stake_title = _mk_section("挑 一 件 同 星 级 · 同 品 质 的 压 上")
    _right.add_child(_stake_title)

    _stake_list = VBoxContainer.new()
    _stake_list.add_theme_constant_override("separation", 5)
    _right.add_child(_stake_list)


    var _push: Control = Control.new()
    _push.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _right.add_child(_push)

    _root.add_child(_rule_line())


    var _rpanel: PanelContainer = PanelContainer.new()
    _rpanel.add_theme_stylebox_override("panel", _flat(Color(0.96, 0.92, 0.83), C_PAPER_BD, 1, 2))
    _root.add_child(_rpanel)

    var _rm: MarginContainer = MarginContainer.new()
    _rm.add_theme_constant_override("margin_left", 10)
    _rm.add_theme_constant_override("margin_right", 10)
    _rm.add_theme_constant_override("margin_top", 5)
    _rm.add_theme_constant_override("margin_bottom", 5)
    _rpanel.add_child(_rm)

    _result_label = Label.new()
    _result_label.add_theme_font_size_override("font_size", 15)
    _result_label.add_theme_color_override("font_color", C_INK)
    _result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _result_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _result_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _result_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _result_label.custom_minimum_size = Vector2(0, 40)
    _rm.add_child(_result_label)


    var _btn_hbox: HBoxContainer = HBoxContainer.new()
    _btn_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _btn_hbox.add_theme_constant_override("separation", 16)
    _root.add_child(_btn_hbox)

    _reveal_btn = _mk_btn("揭 晓 行 情", Vector2(200, 46), 18)
    _reveal_btn.pressed.connect(_on_reveal)
    _btn_hbox.add_child(_reveal_btn)

    _skip_btn = _mk_btn("换 一 件", Vector2(150, 46), 18)
    _skip_btn.pressed.connect(_on_skip)
    _btn_hbox.add_child(_skip_btn)



func _rule_line()-> ColorRect:
    var _l: ColorRect = ColorRect.new()
    _l.color = C_PAPER_BD
    _l.custom_minimum_size = Vector2(0, 1)
    _l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return _l



func _mk_section(_text: String)-> Label:
    var _l: Label = Label.new()
    _l.text = _text
    _l.add_theme_font_size_override("font_size", 13)
    _l.add_theme_color_override("font_color", C_INK_DIM)
    _l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    return _l



func _mk_btn(_text: String, _min_size: Vector2, _font_size: int)-> Button:
    var _btn: Button = Button.new()
    _btn.text = _text
    _btn.custom_minimum_size = _min_size
    _btn.clip_text = true
    _btn.add_theme_font_size_override("font_size", _font_size)
    _style_btn(_btn, false)
    return _btn



func _style_btn(_btn: Button, _selected: bool, _accent: Color = C_ACCENT)-> void:
    if _selected:
        _btn.add_theme_stylebox_override("normal", _flat(_accent, C_WOOD_DARK, 2, 2))
        _btn.add_theme_stylebox_override("hover", _flat(_accent.lightened(0.1), C_WOOD_DARK, 2, 2))
        _btn.add_theme_stylebox_override("pressed", _flat(_accent.darkened(0.1), C_WOOD_DARK, 2, 2))
        _btn.add_theme_color_override("font_color", Color(0.2, 0.13, 0.05))
    else:
        _btn.add_theme_stylebox_override("normal", _flat(C_PAPER_2, C_PAPER_BD, 1, 2))
        _btn.add_theme_stylebox_override("hover", _flat(C_PAPER_2.lightened(0.06), C_ACCENT, 1, 2))
        _btn.add_theme_stylebox_override("pressed", _flat(C_PAPER_2.darkened(0.08), C_ACCENT_DK, 1, 2))
        _btn.add_theme_color_override("font_color", C_INK)
    _btn.add_theme_stylebox_override("disabled", _flat(Color(0.81, 0.77, 0.69), Color(0.68, 0.62, 0.52), 1, 2))
    _btn.add_theme_color_override("font_color_disabled", Color(0.56, 0.51, 0.43))


func _flat(_bg: Color, _bd: Color, _bw: int, _radius: int)-> StyleBoxFlat:
    var _s: StyleBoxFlat = StyleBoxFlat.new()
    _s.bg_color = _bg
    _s.border_color = _bd
    _s.border_width_left = _bw
    _s.border_width_right = _bw
    _s.border_width_top = _bw
    _s.border_width_bottom = _bw
    _s.corner_radius_top_left = _radius
    _s.corner_radius_top_right = _radius
    _s.corner_radius_bottom_left = _radius
    _s.corner_radius_bottom_right = _radius
    _s.content_margin_left = 6
    _s.content_margin_right = 6
    _s.content_margin_top = 3
    _s.content_margin_bottom = 3
    return _s



func _clip(_text: String, _max_chars: int)-> String:
    if _text.length() <= _max_chars:
        return _text
    return _text.substr(0, _max_chars) + "…"



func _lines(_a: String, _b: String)-> String:
    if _b == "":
        return _a
    return _a + "\n" + _b



func _new_round()-> void:
    _stake_item = {}
    _cur_guess = 0
    _guess_edit.text = ""
    _guess_edit.editable = true
    _reveal_btn.text = "揭 晓 行 情"
    _reveal_btn.show()
    _reveal_btn.disabled = false
    _skip_btn.show()
    _skip_btn.disabled = false
    _skip_btn.text = "换 一 件"
    _pick_item()
    _cur_true_price = _true_price(_cur_uid, _cur_quality)
    _refresh_card()
    _refresh_stake_list()
    _refresh_window()
    _set_result("看货 → 填个数(你的出价) → 下注 → 揭晓行情。愿赌服输。", C_INK_DIM)



func _pick_item()-> void:
    var _pool: Dictionary = _build_city_pool()
    if _pool.is_empty():
        _cur_uid = ""
        return
    _cur_uid = _weighted_pick(_pool)
    _cur_quality = _weighted_pick(QUALITY_WEIGHT)
    var _png: Dictionary = GoodsUtils.get_origin_json_by_uid(_cur_uid)
    if _png == null:
        _png = {}
    _cur_name = str(_png.get("name", "未知装备"))
    _cur_star = int(_png.get("star", 0))
    _cur_remark = str(_png.get("remark", ""))



func _build_city_pool()-> Dictionary:
    var _pool: Dictionary = {}
    var _city: Dictionary = WSLocationData.get_city_data(_city_code)
    if _city == null or _city.is_empty():
        return _pool
    for _field in["specialty_smithy", "specialty_armour", "specialty_horse"]:
        if not _city.has(_field):
            continue
        var _dic = _city[_field]
        if not(_dic is Dictionary):
            continue
        for _uid in _dic.keys():
            if not GoodsUtils.is_null_json(GoodsUtils.get_origin_json_by_uid(_uid)):
                _pool[_uid] = int(_dic[_uid])
    return _pool


func _weighted_pick(_weight_dic: Dictionary)-> Variant:
    var _total: int = 0
    for _k in _weight_dic.keys():
        _total += int(_weight_dic[_k])
    if _total <= 0:
        return _weight_dic.keys().pick_random() if not _weight_dic.is_empty() else ""
    var _roll: int = _rng.randi_range(1, _total)
    var _acc: int = 0
    for _k in _weight_dic.keys():
        _acc += int(_weight_dic[_k])
        if _roll <= _acc:
            return _k
    return _weight_dic.keys().back()



func _true_price(_uid: String, _quality: int)-> int:
    if _uid == "":
        return 0
    var _json: Dictionary = GoodsUtils.get_json_by_simple_json({"uid": _uid, "quality": _quality}, null)
    var _base: int = int(_json.get("price", 0))
    if _base <= 0:
        var _origin: Dictionary = GoodsUtils.get_origin_json_by_uid(_uid)
        var _star: int = int(_origin.get("star", 3)) if _origin != null else 3
        _base = _star * _star * 200
    return int(round(_base * _daily_coef(_uid, _today())))


func _daily_coef(_uid: String, _day: int)-> float:
    var _seed: int = hash(_uid + "#" + str(_day))
    var _r: RandomNumberGenerator = RandomNumberGenerator.new()
    _r.seed = _seed
    return _r.randf_range(DAILY_COEF_MIN, DAILY_COEF_MAX)


func _today()-> int:
    return int(WSData.get_system_counter())



func _set_result(_text: String, _color: Color)-> void:
    if _result_label == null:
        return
    _result_label.text = _text
    _result_label.add_theme_color_override("font_color", _color)


func _refresh_card()-> void:
    if _cur_uid == "":
        _item_icon.texture = null
        _item_name_label.text = "本城暂无货"
        _item_tag_label.text = ""
        _item_remark_label.text = "改日再来吧"
        return

    var _json: Dictionary = GoodsUtils.get_json_by_simple_json({"uid": _cur_uid, "quality": _cur_quality}, null)
    var _cover: String = str(_json.get("cover_path", ""))
    if _cover == "":
        var _origin: Dictionary = GoodsUtils.get_origin_json_by_uid(_cur_uid)
        var _t_path: String = str(_origin.get("t_path", "")) if _origin != null else ""
        if _t_path != "":
            _cover = SoldierPartUtils.get_cover_path(_t_path)
    if _cover == "":
        _item_icon.texture = null
    else:
        CommonUtils.update_texture2(_item_icon, _cover)
    _item_name_label.text = _clip(_cur_name, 10)
    _item_tag_label.text = str(_cur_star) + "★  " + str(QUALITY_NAME.get(_cur_quality, "普通"))
    _item_tag_label.add_theme_color_override("font_color", GoodsUtils.get_quality_color(_cur_quality))
    _item_remark_label.text = _clip(_cur_remark, 40)





func _refresh_window()-> void:
    if _window_label == null:
        return
    if _mult <= 0:
        _window_label.text = "先点一个倍率, 这里会写清「出价最多能偏多少」"
        return
    var _w: float = float(MULT_WINDOW.get(_mult, 0.0))
    _window_label.text = "允许误差 ±" + str(int(round(_w * 100))) + "%  ·  赔率 ×" + str(_mult) \
    + "\n(出价与真实行情价相差不超过这个比例就算中)"


func _set_mode(_m: int)-> void:
    if _is_busy:
        return
    _mode = _m
    _apply_mode_visibility()
    _update_mode_buttons()
    _refresh_stake_list()
    if _mode == 0:
        _set_result("押德里: 猜中就赔, 猜错丢注。", C_INK_DIM)
    else:
        _set_result("押装备: 猜中连本带利拿回, 猜错货归对方。", C_INK_DIM)



func _apply_mode_visibility()-> void:
    var _money: bool = _mode == 0
    _bet_title.visible = _money
    _bet_hbox.visible = _money
    _stake_title.visible = not _money
    _stake_list.visible = not _money


func _update_mode_buttons()-> void:
    _style_btn(_mode_money_btn, _mode == 0)
    _style_btn(_mode_treasure_btn, _mode == 1)


func _refresh_stake_list()-> void:
    CommonUtils.clear_node(_stake_list)
    if _mode != 1 or _cur_uid == "":
        return
    var _candidates: Array = _eligible_stake_items()
    if _candidates.is_empty():
        var _lbl: Label = Label.new()
        _lbl.text = "你手上没有 " + str(_cur_star) + "★" + str(QUALITY_NAME.get(_cur_quality, "普通")) + " 的货"
        _lbl.add_theme_font_size_override("font_size", 13)
        _lbl.add_theme_color_override("font_color", C_RED)
        _lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _stake_list.add_child(_lbl)
        return
    var _row: HBoxContainer = HBoxContainer.new()
    _row.add_theme_constant_override("separation", 6)
    _stake_list.add_child(_row)
    var _shown: int = 0
    for _item: Dictionary in _candidates:
        if _shown >= STAKE_SHOW_MAX:
            break
        _shown += 1
        var _item_uid: String = str(_item.item.uid)
        var _item_q: int = int(_item.item.get("quality", 2))
        var _oj: Dictionary = GoodsUtils.get_origin_json_by_uid(_item_uid)
        var _nm: String = str(_oj.get("name", _item_uid)) if _oj != null else _item_uid
        var _btn: Button = _mk_btn(_clip(_nm, 6), Vector2(0, 34), 13)
        _btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var _sel: bool = _stake_item.get("uid", "") == _item_uid and int(_stake_item.get("quality", -1)) == _item_q
        _style_btn(_btn, _sel)
        _btn.pressed.connect(_on_stake_selected.bind(_item_uid, _item_q, _nm))
        _row.add_child(_btn)
    if _candidates.size() > STAKE_SHOW_MAX:
        var _more: Label = Label.new()
        _more.text = "还有 " + str(_candidates.size() - STAKE_SHOW_MAX) + " 件同类可选"
        _more.add_theme_font_size_override("font_size", 12)
        _more.add_theme_color_override("font_color", C_INK_DIM)
        _more.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _stake_list.add_child(_more)



func _eligible_stake_items()-> Array:
    var _result: Array = []
    var _goods: Array = WSData.get_player_data().get("goods",[])
    for _entry in GoodsUtils.get_goods_json_list(_goods, GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS):
        var _item: Dictionary = _entry.item
        var _uid: String = str(_item.get("uid", ""))
        if _uid == "":
            continue
        var _q: int = int(_item.get("quality", 2))
        if _q != _cur_quality:
            continue
        var _oj: Dictionary = GoodsUtils.get_origin_json_by_uid(_uid)
        if _oj == null:
            continue
        if int(_oj.get("star", 0)) != _cur_star:
            continue
        _result.append(_entry)
    return _result


func _refresh_daily()-> void:
    _money_label.text = "囊中 " + str(WSData.get_player_money())

    _daily_label.text = "本城今日已押 " + str(_get_daily_count()) + "/" + str(DAILY_LIMIT) + " 次"


func _update_bet_buttons()-> void:
    for i in range(_bet_buttons.size()):
        _style_btn(_bet_buttons[i], BET_AMOUNTS[i] == _bet)


func _update_all_mult_buttons()-> void:
    for i in range(_mult_buttons.size()):
        _style_btn(_mult_buttons[i], MULTIPLIERS[i] == _mult)


func _set_controls_disabled(_disabled: bool)-> void:
    for _btn in _bet_buttons:
        _btn.disabled = _disabled
    for _btn in _all_mult_buttons:
        _btn.disabled = _disabled
    _mode_money_btn.disabled = _disabled
    _mode_treasure_btn.disabled = _disabled
    _skip_btn.disabled = _disabled
    _reveal_btn.disabled = _disabled
    _guess_edit.editable = not _disabled




func _on_guess_changed(_text: String)-> void:
    if _is_busy:
        return
    var _digits: String = ""
    for _i in range(_text.length()):
        var _ch: String = _text[_i]
        if _ch >= "0" and _ch <= "9" and _digits.length() < GUESS_MAX_DIGITS:
            _digits += _ch
    if _digits != _text:
        _guess_edit.text = _digits
        _guess_edit.caret_column = _digits.length()
    _cur_guess = int(_digits) if _digits != "" else 0


func _on_bet_selected(_amount: int)-> void:
    if _is_busy:
        return
    _bet = _amount
    _update_bet_buttons()
    _set_result("押了 " + str(_amount) + " 德里。", C_ACCENT_DK)


func _on_mult_selected(_m: int)-> void:
    if _is_busy:
        return
    _mult = _m
    _update_all_mult_buttons()
    _refresh_window()
    _set_result("倍率 ×" + str(_m) + ": 你出的价与真实行情价相差不超过 ±" \
    + str(int(round(float(MULT_WINDOW.get(_m, 0.0)) * 100))) + "% 便算中", C_ACCENT_DK)


func _on_stake_selected(_uid: String, _quality: int, _name: String)-> void:
    if _is_busy:
        return
    _stake_item = {"uid": _uid, "quality": _quality}
    _refresh_stake_list()
    _set_result("压上了: " + _clip(_name, 8), C_ACCENT_DK)


func _on_skip()-> void:
    if _is_busy:
        return
    _new_round()


func _on_reveal()-> void:
    if _is_busy:
        return
    if _cur_uid == "" or _cur_true_price <= 0:
        _set_result("赌物人摊了摊手: 今天没货, 改日再来。", C_RED)
        return
    if _mult <= 0:
        _set_result("还没定倍率呢。", C_INK_DIM)
        return

    _cur_guess = int(_guess_edit.text) if _guess_edit.text != "" else 0
    if _cur_guess <= 0:
        _set_result("先在左边木牌里填个数 —— 你猜它值多少。", C_INK_DIM)
        _guess_edit.grab_focus()
        return
    if _get_daily_count() >= DAILY_LIMIT:
        _set_result("赌物人摆手: 本城今天就这 " + str(DAILY_LIMIT) + " 局, 明天再来。", C_INK_DIM)
        return

    if _mode == 0:
        if _bet <= 0:
            _set_result("先挑个注码。", C_INK_DIM)
            return
        if WSData.get_player_money() < _bet:
            _set_result("钱不够, 赌物人懒得搭理你。", C_RED)
            return
        else:
            WSData.update_money(- _bet, true)
    else:
        if _stake_item.is_empty():
            _set_result("先压上一件同星级·同品质的货。", C_INK_DIM)
            return
        else:
            _remove_goods_once(str(_stake_item.uid), int(_stake_item.quality))

    _increment_daily_count()
    _is_busy = true
    _set_controls_disabled(true)
    _reveal_btn.disabled = true
    _set_result("赌物人眯起眼, 翻开账本……", C_INK)
    _resolve()


func _resolve()-> void:

    _cur_offset = float(abs(_cur_guess - _cur_true_price)) / float(_cur_true_price) if _cur_true_price > 0 else 1.0
    var _win: bool = _cur_offset <= float(MULT_WINDOW.get(_mult, 0.0))
    var _window_pct: int = int(round(float(MULT_WINDOW.get(_mult, 0.0)) * 100))
    var _head: String = "你出 " + str(_cur_guess) + " · 行情 " + str(_cur_true_price) \
    + " · 误差 " + str(int(round(_cur_offset * 100))) + "%"
    if _win:
        var _tail: String = "±" + str(_window_pct) + "% 窗口内 —— 你赢了!"
        if _mode == 0:
            var _gain: int = _bet * _mult
            WSData.update_money(_gain, true)
            _tail += " 赔你 " + str(_gain) + " 德里"
        else:

            var _stake_uid: String = str(_stake_item.get("uid", _cur_uid))
            var _stake_q: int = int(_stake_item.get("quality", _cur_quality))
            WSData.add_my_goods([{"item": {"uid": _stake_uid, "quality": _stake_q, "origin": GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS}, "count": 1}])
            var _extra: int = max(_mult - 1, 1)
            var _uids: Array = _pick_same_star_items(_extra)
            for _uid in _uids:
                WSData.add_my_goods([{"item": {"uid": _uid, "quality": _cur_quality, "origin": GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS}, "count": 1}])
            _tail += " 押的货拿回, 另赔 " + str(_uids.size()) + " 件同类"
        _set_result(_lines(_head, _tail), C_GREEN)
    else:
        var _tail: String = "超出 ±" + str(_window_pct) + "% 窗口 —— 你输了。"
        if _mode == 1:
            _tail += " 压的货归了赌物人。"
        _set_result(_lines(_head, _tail), C_RED)
    _is_busy = false
    _reveal_btn.disabled = true
    _reveal_btn.text = "已 揭 晓"
    _skip_btn.disabled = false
    _skip_btn.text = "再 来 一 件"
    _skip_btn.show()
    _mode_money_btn.disabled = false
    _mode_treasure_btn.disabled = false
    for _btn in _bet_buttons:
        _btn.disabled = false
    for _btn in _all_mult_buttons:
        _btn.disabled = false
    _refresh_daily()



func _pick_same_star_items(_n: int)-> Array:
    var _result: Array = []
    var _pool: Dictionary = _build_city_pool()
    var _same_star: Array = []
    for _uid in _pool.keys():
        var _oj: Dictionary = GoodsUtils.get_origin_json_by_uid(_uid)
        if _oj != null and int(_oj.get("star", 0)) == _cur_star:
            _same_star.append(_uid)
    if _same_star.is_empty():
        for _i in range(_n):
            _result.append(_cur_uid)
        return _result
    for _i in range(_n):
        _result.append(_same_star.pick_random())
    return _result


func _on_close()-> void:
    if _is_busy:
        return
    hide_interface()




func _remove_goods_once(_uid: String, _quality: int)-> void:
    var _goods: Array = WSData.get_player_data().get("goods",[])
    for _i in range(_goods.size()):
        var _entry: Dictionary = _goods[_i]
        if str(_entry.item.get("uid", "")) != _uid:
            continue
        if int(_entry.item.get("quality", 2)) != _quality:
            continue
        if int(_entry.get("count", 1)) > 1:
            _entry["count"] = int(_entry["count"]) - 1
        else:
            _goods.remove_at(_i)
        GoodsUtils.organize_goods(_goods)
        WSData.save_my_goods(_goods)
        return





func _get_daily_count()-> int:
    var _all: Dictionary = WSData.get_player_data().get("mod_appraiser_gamble",{})
    var _data: Dictionary = _all.get(_city_code,{})
    if _data.get("day", -1) != _today():
        return 0
    return int(_data.get("count", 0))


func _increment_daily_count()-> void:
    var _pd: Dictionary = WSData.get_player_data()
    if not _pd.has("mod_appraiser_gamble"):
        _pd["mod_appraiser_gamble"] = {}
    if not _pd["mod_appraiser_gamble"].has(_city_code):
        _pd["mod_appraiser_gamble"][_city_code] = {}
    var _data: Dictionary = _pd["mod_appraiser_gamble"][_city_code]
    if _data.get("day", -1) != _today():
        _data["count"] = 0
    _data["day"] = _today()
    _data["count"] = int(_data.get("count", 0)) + 1