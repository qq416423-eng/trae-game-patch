extends Control

signal close_page_sign


const BET_AMOUNTS: Array = [50, 100, 200, 500, 1200]
const DAILY_LIMIT: int = 8
const WIN_STREAK_ACHIEVEMENT: int = 3
const ROLL_FRAMES: int = 14
const ROLL_INTERVAL: float = 0.055
const ROLL_WATCHDOG_SEC: float = 3.0


const C_GOLD: Color = Color(0.95, 0.78, 0.3, 1.0)
const C_GOLD_DIM: Color = Color(0.75, 0.62, 0.25, 1.0)
const C_GREEN: Color = Color(0.3, 0.9, 0.4, 1.0)
const C_RED: Color = Color(0.92, 0.35, 0.35, 1.0)
const C_WHITE: Color = Color(0.92, 0.92, 0.95, 1.0)
const C_GRAY: Color = Color(0.55, 0.55, 0.6, 1.0)
const C_PANEL: Color = Color(0.08, 0.06, 0.14, 0.97)
const C_TIE: Color = Color(0.5, 0.65, 0.9, 1.0)


const DICE_TEX_PATH: String = "res://resource/mod/dice/dice_%d.png"


var _bg: ColorRect
var _flash: ColorRect
var _panel: Panel
var _title_label: Label
var _money_label: Label
var _daily_label: Label
var _streak_label: Label
var _bet_buttons: Array = []
var _player_dice_tex: TextureRect
var _gambler_dice_tex: TextureRect
var _player_dice_frame: Panel
var _gambler_dice_frame: Panel
var _result_label: Label
var _roll_button: Button
var _continue_button: Button
var _collect_button: Button
var _close_button: Button


var _current_bet: int = 0
var _win_streak: int = 0
var _is_rolling: bool = false
var _roll_serial: int = 0


var _dice_textures: Array = []


var _flash_tween: Tween
var _result_tween: Tween


var _rng: RandomNumberGenerator = RandomNumberGenerator.new()


func _ready()-> void:
    _rng.randomize()
    _load_dice_textures()
    _build_ui()
    hide()


func _load_dice_textures()-> void:
    _dice_textures.clear()
    for i in range(1, 7):
        var _path: String = DICE_TEX_PATH % i
        var _tex: Texture2D = _try_load_texture(_path)
        _dice_textures.append(_tex)




func _try_load_texture(_path: String)-> Texture2D:
    var _img: Image = Image.new()
    if _img.load(_path) == OK:
        return ImageTexture.create_from_image(_img)
    if ResourceLoader.exists(_path):
        return load(_path)
    return null


func show_interface()-> void:
    _current_bet = 0
    _win_streak = 0
    _is_rolling = false
    _roll_serial += 1
    _reset_dice_display()

    _roll_button.text = "掷骰子"
    _roll_button.show()
    _roll_button.disabled = false
    _continue_button.hide()
    _collect_button.hide()
    _set_bet_buttons_disabled(false)
    _update_bet_buttons()
    _update_display()
    _center_panel()
    show()
    if _panel != null:
        _panel.scale = Vector2(0.7, 0.7)
        _panel.modulate.a = 0.0
        var _t: Tween = get_tree().create_tween()
        _t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _t.set_parallel(true)
        _t.tween_property(_panel, "scale", Vector2(1.0, 1.0), 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
        _t.tween_property(_panel, "modulate:a", 1.0, 0.2)


func hide_interface()-> void:
    hide()
    close_page_sign.emit()


func _center_panel()-> void:
    if _panel == null:
        return
    var _ss: Vector2 = get_viewport().get_visible_rect().size
    _panel.position = Vector2((_ss.x - 700) / 2.0,(_ss.y - 660) / 2.0)


func _notification(what: int)-> void:
    if what == NOTIFICATION_RESIZED and _panel != null and visible:
        _center_panel()




func _build_ui()-> void:

    _bg = ColorRect.new()
    _bg.color = Color(0, 0, 0, 0.75)
    _bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    _bg.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(_bg)


    _flash = ColorRect.new()
    _flash.color = Color(1, 1, 1, 0)
    _flash.set_anchors_preset(Control.PRESET_FULL_RECT)
    _flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_flash)


    _panel = Panel.new()
    _panel.custom_minimum_size = Vector2(700, 660)
    _panel.add_theme_stylebox_override("panel", _make_style(C_PANEL, C_GOLD_DIM, 3, 14))
    add_child(_panel)

    var _margin: MarginContainer = MarginContainer.new()
    _margin.set_anchors_preset(Control.PRESET_FULL_RECT)
    _margin.add_theme_constant_override("margin_left", 30)
    _margin.add_theme_constant_override("margin_right", 30)
    _margin.add_theme_constant_override("margin_top", 22)
    _margin.add_theme_constant_override("margin_bottom", 22)
    _panel.add_child(_margin)

    var _vbox: VBoxContainer = VBoxContainer.new()
    _vbox.add_theme_constant_override("separation", 8)
    _margin.add_child(_vbox)


    _title_label = Label.new()
    _title_label.text = "骰 子 赌 局"
    _title_label.add_theme_font_size_override("font_size", 38)
    _title_label.add_theme_color_override("font_color", C_GOLD)
    _title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _vbox.add_child(_title_label)


    var _info_hbox: HBoxContainer = HBoxContainer.new()
    _info_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _info_hbox.add_theme_constant_override("separation", 60)
    _vbox.add_child(_info_hbox)

    _money_label = Label.new()
    _money_label.add_theme_font_size_override("font_size", 18)
    _money_label.add_theme_color_override("font_color", C_GOLD_DIM)
    _info_hbox.add_child(_money_label)

    _daily_label = Label.new()
    _daily_label.add_theme_font_size_override("font_size", 18)
    _daily_label.add_theme_color_override("font_color", C_GRAY)
    _info_hbox.add_child(_daily_label)


    _streak_label = Label.new()
    _streak_label.add_theme_font_size_override("font_size", 22)
    _streak_label.add_theme_color_override("font_color", Color(1.0, 0.55, 0.15, 1.0))
    _streak_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _vbox.add_child(_streak_label)


    var _bet_title: Label = Label.new()
    _bet_title.text = "选择下注金额"
    _bet_title.add_theme_font_size_override("font_size", 20)
    _bet_title.add_theme_color_override("font_color", C_WHITE)
    _bet_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _vbox.add_child(_bet_title)

    var _bet_hbox: HBoxContainer = HBoxContainer.new()
    _bet_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _bet_hbox.add_theme_constant_override("separation", 14)
    _vbox.add_child(_bet_hbox)

    for _amount in BET_AMOUNTS:
        var _btn: Button = Button.new()
        _btn.text = str(_amount)
        _btn.custom_minimum_size = Vector2(118, 58)
        _btn.add_theme_font_size_override("font_size", 24)
        _btn.add_theme_stylebox_override("normal", _make_style(Color(0.14, 0.12, 0.18, 1.0), C_GRAY, 2, 8))
        _btn.add_theme_stylebox_override("hover", _make_style(Color(0.2, 0.17, 0.1, 1.0), C_GOLD, 2, 8))
        _btn.add_theme_stylebox_override("pressed", _make_style(Color(0.3, 0.24, 0.08, 1.0), C_GOLD, 3, 8))
        _btn.add_theme_stylebox_override("disabled", _make_style(Color(0.08, 0.08, 0.08, 0.4), Color(0.2, 0.2, 0.2, 0.3), 1, 8))
        _btn.pressed.connect(_on_bet_selected.bind(_amount))
        _bet_hbox.add_child(_btn)
        _bet_buttons.append(_btn)


    var _dice_hbox: HBoxContainer = HBoxContainer.new()
    _dice_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _dice_hbox.add_theme_constant_override("separation", 50)
    _vbox.add_child(_dice_hbox)


    var _pvbox: VBoxContainer = VBoxContainer.new()
    _pvbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _dice_hbox.add_child(_pvbox)
    var _ptitle: Label = Label.new()
    _ptitle.text = "你"
    _ptitle.add_theme_font_size_override("font_size", 22)
    _ptitle.add_theme_color_override("font_color", C_GREEN)
    _ptitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _pvbox.add_child(_ptitle)

    _player_dice_frame = Panel.new()
    _player_dice_frame.custom_minimum_size = Vector2(140, 140)
    _player_dice_frame.add_theme_stylebox_override("panel", _make_style(Color(0.1, 0.08, 0.14, 1.0), C_GRAY, 2, 12))
    _pvbox.add_child(_player_dice_frame)
    _player_dice_tex = TextureRect.new()
    _player_dice_tex.set_anchors_preset(Control.PRESET_FULL_RECT)
    _player_dice_tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    _player_dice_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _player_dice_tex.modulate = Color(1, 1, 1, 0.3)
    _player_dice_frame.add_child(_player_dice_tex)


    var _vs: Label = Label.new()
    _vs.text = "VS"
    _vs.add_theme_font_size_override("font_size", 36)
    _vs.add_theme_color_override("font_color", C_GOLD)
    _vs.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _dice_hbox.add_child(_vs)


    var _gvbox: VBoxContainer = VBoxContainer.new()
    _gvbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _dice_hbox.add_child(_gvbox)
    var _gtitle: Label = Label.new()
    _gtitle.text = "老鬼"
    _gtitle.add_theme_font_size_override("font_size", 22)
    _gtitle.add_theme_color_override("font_color", C_RED)
    _gtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _gvbox.add_child(_gtitle)

    _gambler_dice_frame = Panel.new()
    _gambler_dice_frame.custom_minimum_size = Vector2(140, 140)
    _gambler_dice_frame.add_theme_stylebox_override("panel", _make_style(Color(0.1, 0.08, 0.14, 1.0), C_GRAY, 2, 12))
    _gvbox.add_child(_gambler_dice_frame)
    _gambler_dice_tex = TextureRect.new()
    _gambler_dice_tex.set_anchors_preset(Control.PRESET_FULL_RECT)
    _gambler_dice_tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    _gambler_dice_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _gambler_dice_tex.modulate = Color(1, 1, 1, 0.3)
    _gambler_dice_frame.add_child(_gambler_dice_tex)


    _result_label = Label.new()
    _result_label.text = ""
    _result_label.add_theme_font_size_override("font_size", 26)
    _result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _result_label.custom_minimum_size = Vector2(0, 42)
    _vbox.add_child(_result_label)


    var _btn_hbox: HBoxContainer = HBoxContainer.new()
    _btn_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
    _btn_hbox.add_theme_constant_override("separation", 20)
    _vbox.add_child(_btn_hbox)

    _roll_button = _make_big_button("掷骰子", Color(0.15, 0.35, 0.15, 1.0), Color(0.3, 0.7, 0.3, 1.0))
    _roll_button.pressed.connect(_on_roll_pressed)
    _btn_hbox.add_child(_roll_button)

    _continue_button = _make_big_button("乘胜追击", Color(0.35, 0.25, 0.08, 1.0), Color(0.7, 0.5, 0.15, 1.0))
    _continue_button.pressed.connect(_on_continue_pressed)
    _continue_button.hide()
    _btn_hbox.add_child(_continue_button)

    _collect_button = _make_big_button("见好就收", Color(0.12, 0.2, 0.35, 1.0), Color(0.25, 0.45, 0.7, 1.0))
    _collect_button.pressed.connect(_on_collect_pressed)
    _collect_button.hide()
    _btn_hbox.add_child(_collect_button)


    _close_button = Button.new()
    _close_button.text = "离开赌桌"
    _close_button.custom_minimum_size = Vector2(220, 50)
    _close_button.add_theme_font_size_override("font_size", 20)
    _close_button.add_theme_stylebox_override("normal", _make_style(Color(0.12, 0.1, 0.15, 1.0), C_GRAY, 1, 8))
    _close_button.add_theme_stylebox_override("hover", _make_style(Color(0.18, 0.15, 0.2, 1.0), C_WHITE, 2, 8))
    _close_button.pressed.connect(_on_close_pressed)
    _vbox.add_child(_close_button)


func _make_big_button(_text: String, _bg_color: Color, _border_color: Color)-> Button:
    var _btn: Button = Button.new()
    _btn.text = _text
    _btn.custom_minimum_size = Vector2(200, 62)
    _btn.add_theme_font_size_override("font_size", 28)
    _btn.add_theme_stylebox_override("normal", _make_style(_bg_color, _border_color, 3, 10))
    _btn.add_theme_stylebox_override("hover", _make_style(_bg_color.lightened(0.15), _border_color.lightened(0.2), 3, 10))
    _btn.add_theme_stylebox_override("pressed", _make_style(_bg_color.darkened(0.15), _border_color, 3, 10))
    _btn.add_theme_stylebox_override("disabled", _make_style(Color(0.08, 0.08, 0.08, 0.4), Color(0.2, 0.2, 0.2, 0.3), 1, 10))
    return _btn


func _make_style(_bg: Color, _border: Color, _bw: int, _radius: int)-> StyleBoxFlat:
    var _s: StyleBoxFlat = StyleBoxFlat.new()
    _s.bg_color = _bg
    _s.border_color = _border
    _s.border_width_left = _bw
    _s.border_width_right = _bw
    _s.border_width_top = _bw
    _s.border_width_bottom = _bw
    _s.corner_radius_top_left = _radius
    _s.corner_radius_top_right = _radius
    _s.corner_radius_bottom_left = _radius
    _s.corner_radius_bottom_right = _radius
    _s.content_margin_left = 8
    _s.content_margin_right = 8
    _s.content_margin_top = 4
    _s.content_margin_bottom = 4
    return _s




func _set_dice_face(_tex_rect: TextureRect, _face: int)-> void:
    if _face >= 1 and _face <= 6 and _dice_textures.size() >= _face and _dice_textures[_face - 1] != null:
        _tex_rect.texture = _dice_textures[_face - 1]
        _tex_rect.modulate = Color(1, 1, 1, 1.0)


func _dice_tumble(_tex_rect: TextureRect)-> void:
    _tex_rect.rotation = _rng.randf_range(-0.3, 0.3)
    _tex_rect.scale = Vector2.ONE * _rng.randf_range(0.9, 1.1)
    _set_dice_face(_tex_rect, _rng.randi_range(1, 6))


func _dice_land(_tex_rect: TextureRect, _frame: Panel, _face: int, _is_winner: bool)-> void:
    _set_dice_face(_tex_rect, _face)
    _tex_rect.rotation = 0.0
    _tex_rect.scale = Vector2(1.2, 1.2)
    var _t: Tween = get_tree().create_tween()
    _t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _t.tween_property(_tex_rect, "scale", Vector2(1.0, 1.0), 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
    if _is_winner:
        _frame.add_theme_stylebox_override("panel", _make_style(Color(0.08, 0.25, 0.08, 1.0), C_GOLD, 4, 12))
    else:
        _frame.add_theme_stylebox_override("panel", _make_style(Color(0.2, 0.08, 0.08, 1.0), C_GRAY, 2, 12))


func _flash_screen(_color: Color)-> void:
    if _flash_tween != null and _flash_tween.is_valid():
        _flash_tween.kill()
    _flash.color = _color
    _flash_tween = get_tree().create_tween()
    _flash_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _flash_tween.tween_property(_flash, "color:a", 0.3, 0.1)
    _flash_tween.tween_property(_flash, "color:a", 0.0, 0.35)


func _result_pop_in()-> void:
    if _result_tween != null and _result_tween.is_valid():
        _result_tween.kill()
    _result_label.scale = Vector2(0.5, 0.5)
    _result_label.modulate.a = 0.0
    _result_tween = get_tree().create_tween()
    _result_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _result_tween.set_parallel(true)
    _result_tween.tween_property(_result_label, "scale", Vector2(1.0, 1.0), 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
    _result_tween.tween_property(_result_label, "modulate:a", 1.0, 0.2)


func _play_sfx()-> void:
    GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.BUTTON_CLICK_0001)




func _on_bet_selected(_amount: int)-> void:
    if _is_rolling:
        return
    _current_bet = _amount
    _update_bet_buttons()
    _update_display()
    _result_label.text = "已下注 " + str(_amount) + " 德里, 点击「掷骰子」开局"
    _result_label.add_theme_color_override("font_color", C_GRAY)
    _result_pop_in()
    var _idx: int = BET_AMOUNTS.find(_amount)
    if _idx >= 0 and _idx < _bet_buttons.size():
        var _btn: Button = _bet_buttons[_idx]
        var _t: Tween = get_tree().create_tween()
        _t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _t.tween_property(_btn, "scale", Vector2(1.15, 1.15), 0.08)
        _t.tween_property(_btn, "scale", Vector2(1.0, 1.0), 0.08)


func _on_roll_pressed()-> void:
    if _is_rolling:
        return


    if _current_bet <= 0:
        _result_label.text = "老鬼敲了敲桌子：\"先选个注码。\""
        _result_label.add_theme_color_override("font_color", C_GOLD_DIM)
        _result_pop_in()
        return

    if _get_daily_count() >= DAILY_LIMIT:
        _result_label.text = "老鬼摆了摆手：\"今天手气用完了，明天再来吧。\""
        _result_label.add_theme_color_override("font_color", C_GRAY)
        _result_pop_in()
        return

    var _player_money: int = WSData.get_player_money()
    if _player_money < _current_bet:
        _result_label.text = "老鬼瞥了你一眼：\"钱都不够还来赌？\""
        _result_label.add_theme_color_override("font_color", C_RED)
        _result_pop_in()
        return

    _is_rolling = true
    _roll_serial += 1
    var _my_serial: int = _roll_serial
    _roll_button.disabled = true
    _set_bet_buttons_disabled(true)
    _continue_button.hide()
    _collect_button.hide()
    _roll_button.show()
    _result_label.text = "摇骰中..."
    _result_label.add_theme_color_override("font_color", C_WHITE)
    _result_label.modulate.a = 1.0


    _player_dice_frame.add_theme_stylebox_override("panel", _make_style(Color(0.1, 0.08, 0.14, 1.0), C_GRAY, 2, 12))
    _gambler_dice_frame.add_theme_stylebox_override("panel", _make_style(Color(0.1, 0.08, 0.14, 1.0), C_GRAY, 2, 12))


    WSData.update_money(- _current_bet, true)
    _increment_daily_count()


    var _player_roll: int = _rng.randi_range(1, 6)
    var _gambler_roll: int = _rng.randi_range(1, 6)


    _play_roll_animation_safe(_my_serial, _player_roll, _gambler_roll)
    _roll_watchdog(_my_serial, _player_roll, _gambler_roll)



func _play_roll_animation_safe(_serial: int, _player_roll: int, _gambler_roll: int)-> void:
    for i in range(ROLL_FRAMES):
        if not is_instance_valid(self) or not visible or not _is_rolling or _serial != _roll_serial:
            return
        _dice_tumble(_player_dice_tex)
        _dice_tumble(_gambler_dice_tex)
        if i == ROLL_FRAMES - 1:
            _play_sfx()

        var _timer: SceneTreeTimer = get_tree().create_timer(ROLL_INTERVAL, true)
        await _timer.timeout


    if not is_instance_valid(self):
        return
    _player_dice_tex.rotation = 0.0
    _gambler_dice_tex.rotation = 0.0
    _player_dice_tex.scale = Vector2.ONE
    _gambler_dice_tex.scale = Vector2.ONE

    _resolve_round(_serial, _player_roll, _gambler_roll)



func _roll_watchdog(_serial: int, _player_roll: int, _gambler_roll: int)-> void:
    var _timer: SceneTreeTimer = get_tree().create_timer(ROLL_WATCHDOG_SEC, true)
    await _timer.timeout
    if not is_instance_valid(self):
        return
    if _is_rolling and _serial == _roll_serial:
        _resolve_round(_serial, _player_roll, _gambler_roll)


func _resolve_round(_serial: int, _player_roll: int, _gambler_roll: int)-> void:

    if not _is_rolling or _serial != _roll_serial:
        return
    _is_rolling = false


    var _score_text: String = "你 " + str(_player_roll) + " : " + str(_gambler_roll) + " 老鬼 — "

    if _player_roll > _gambler_roll:
        _win_streak += 1
        var _winnings: int = _current_bet * 2
        WSData.update_money(_winnings, true)
        _result_label.text = _score_text + "你赢了！获得 " + str(_winnings) + " 德里"
        _result_label.add_theme_color_override("font_color", C_GREEN)

        if _win_streak >= WIN_STREAK_ACHIEVEMENT:
            _try_unlock_achievement("dice_god")

        _dice_land(_player_dice_tex, _player_dice_frame, _player_roll, true)
        _dice_land(_gambler_dice_tex, _gambler_dice_frame, _gambler_roll, false)
        _flash_screen(Color(1.0, 0.85, 0.3, 1.0))
        _result_pop_in()
        _play_sfx()

        _roll_button.hide()
        _continue_button.show()
        _collect_button.show()
        _update_display()
        return

    elif _player_roll < _gambler_roll:
        _win_streak = 0
        _result_label.text = _score_text + "老鬼咧嘴一笑：\"承让了，" + str(_current_bet) + " 德里归我了。\""
        _result_label.add_theme_color_override("font_color", C_RED)
        _dice_land(_player_dice_tex, _player_dice_frame, _player_roll, false)
        _dice_land(_gambler_dice_tex, _gambler_dice_frame, _gambler_roll, true)
        _flash_screen(Color(0.8, 0.2, 0.2, 1.0))
        _result_pop_in()
    else:
        WSData.update_money(_current_bet, true)
        _result_label.text = _score_text + "平局，赌注退还。"
        _result_label.add_theme_color_override("font_color", C_TIE)
        _dice_land(_player_dice_tex, _player_dice_frame, _player_roll, false)
        _dice_land(_gambler_dice_tex, _gambler_dice_frame, _gambler_roll, false)
        _flash_screen(Color(0.3, 0.5, 0.8, 1.0))
        _result_pop_in()

    _roll_button.disabled = false
    _roll_button.text = "再来一局"
    _set_bet_buttons_disabled(false)
    _update_display()


func _on_continue_pressed()-> void:
    if _is_rolling:
        return
    var _new_bet: int = _current_bet * 2
    var _player_money: int = WSData.get_player_money()
    if _player_money < _new_bet:
        _result_label.text = "你的资金不足以翻倍下注。"
        _result_label.add_theme_color_override("font_color", C_RED)
        _result_pop_in()
        return

    _current_bet = _new_bet
    _roll_button.text = "掷骰子"
    _roll_button.show()
    _roll_button.disabled = false
    _continue_button.hide()
    _collect_button.hide()
    _reset_dice_display()
    _update_display()
    _result_label.text = "翻倍下注 " + str(_new_bet) + " 德里, 点击「掷骰子」"
    _result_label.add_theme_color_override("font_color", C_GOLD_DIM)
    _result_pop_in()


func _on_collect_pressed()-> void:
    _win_streak = 0
    _current_bet = 0
    _roll_button.text = "掷骰子"
    _roll_button.show()
    _roll_button.disabled = false
    _continue_button.hide()
    _collect_button.hide()
    _reset_dice_display()
    _set_bet_buttons_disabled(false)
    _update_bet_buttons()
    _update_display()
    _result_label.text = "老鬼点了点头：\"聪明人。\""
    _result_label.add_theme_color_override("font_color", C_GRAY)
    _result_pop_in()


func _on_close_pressed()-> void:

    if _is_rolling:
        _is_rolling = false
        _roll_serial += 1
    if _panel != null:
        var _t: Tween = get_tree().create_tween()
        _t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _t.set_parallel(true)
        _t.tween_property(_panel, "scale", Vector2(0.7, 0.7), 0.15).set_ease(Tween.EASE_IN)
        _t.tween_property(_panel, "modulate:a", 0.0, 0.15)
        _t.chain().tween_callback(_final_hide)
    else:
        _final_hide()


func _final_hide()-> void:
    hide()
    close_page_sign.emit()




func _reset_dice_display()-> void:
    _player_dice_tex.texture = null
    _player_dice_tex.modulate = Color(1, 1, 1, 0.3)
    _player_dice_tex.rotation = 0.0
    _player_dice_tex.scale = Vector2.ONE
    _gambler_dice_tex.texture = null
    _gambler_dice_tex.modulate = Color(1, 1, 1, 0.3)
    _gambler_dice_tex.rotation = 0.0
    _gambler_dice_tex.scale = Vector2.ONE
    _result_label.text = ""
    _result_label.modulate.a = 1.0
    _player_dice_frame.add_theme_stylebox_override("panel", _make_style(Color(0.1, 0.08, 0.14, 1.0), C_GRAY, 2, 12))
    _gambler_dice_frame.add_theme_stylebox_override("panel", _make_style(Color(0.1, 0.08, 0.14, 1.0), C_GRAY, 2, 12))


func _update_display()-> void:
    _money_label.text = "携带: " + str(WSData.get_player_money()) + " 德里"
    _daily_label.text = "今日: " + str(_get_daily_count()) + "/" + str(DAILY_LIMIT) + " 局"
    if _win_streak > 0:
        _streak_label.text = "连胜: " + str(_win_streak) + " 局"
    else:
        _streak_label.text = ""
    if _get_daily_count() >= DAILY_LIMIT:
        _roll_button.disabled = true
        _set_bet_buttons_disabled(true)


func _update_bet_buttons()-> void:
    for i in range(_bet_buttons.size()):
        var _btn: Button = _bet_buttons[i]
        if BET_AMOUNTS[i] == _current_bet:
            _btn.add_theme_stylebox_override("normal", _make_style(Color(0.35, 0.28, 0.08, 1.0), C_GOLD, 3, 8))
        else:
            _btn.add_theme_stylebox_override("normal", _make_style(Color(0.14, 0.12, 0.18, 1.0), C_GRAY, 2, 8))


func _set_bet_buttons_disabled(_disabled: bool)-> void:
    for _btn in _bet_buttons:
        _btn.disabled = _disabled





func _get_daily_count()-> int:
    var _pd: Dictionary = WSData.get_player_data()
    if not _pd.has("mod_dice_gamble"):
        return 0
    var _data: Dictionary = _pd["mod_dice_gamble"]
    var _today: int = int(WSData.system_counter)
    if _data.get("day", -1) != _today:
        return 0
    return _data.get("count", 0)


func _increment_daily_count()-> void:
    var _pd: Dictionary = WSData.get_player_data()
    if not _pd.has("mod_dice_gamble"):
        _pd["mod_dice_gamble"] = {}
    var _today: int = int(WSData.system_counter)
    if _pd["mod_dice_gamble"].get("day", -1) != _today:
        _pd["mod_dice_gamble"]["count"] = 0
    _pd["mod_dice_gamble"]["day"] = _today
    _pd["mod_dice_gamble"]["count"] = _pd["mod_dice_gamble"].get("count", 0) + 1


func _try_unlock_achievement(_code: String)-> void:
    var _root: Node = get_tree().current_scene
    if _root == null:
        return
    var _am: Node = _root.find_child("AchievementManager", true, false)
    if _am != null and _am.has_method("unlock"):
        _am.unlock(_code)