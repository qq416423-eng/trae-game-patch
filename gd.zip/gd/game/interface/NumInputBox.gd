class_name NumInputBox extends Control

@onready var num_input_node: LineEdit =$Background / NumInput

signal confirm_sign(_int: int)

func chide():
    self.hide()


func _on_cancel_button_pressed()-> void:
    chide()


func _on_confirm_button_pressed()-> void:
    if StringUtils.is_positive_integer(num_input_node.text):
        confirm_sign.emit(int(num_input_node.text))