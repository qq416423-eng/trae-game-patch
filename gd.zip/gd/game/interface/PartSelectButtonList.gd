class_name PartSelectButtonList extends Control

const PART_SELECT_BUTTON_NODE = preload("res://tscn/baseModule/button/PartSelectButton.tscn")

@onready var v_box_container_node: VBoxContainer =$VBoxContainer

@export var config: = [
    {
        "name": "基本信息",
        "value": "BASE",
    },
    {
        "name": "头发",
        "value": "HAIR"
    },
    {
        "name": "皮肤",
        "value": "SKIN"
    }
]
@export var ready_init: bool = true

var select_node = null

signal choose_sign(_value: String)

func _ready()-> void:


    if ready_init:





        init(config)




func init(_config: Array)-> void:
    for _config_item in _config:
        var _node_instance: PartSelectButton = PART_SELECT_BUTTON_NODE.instantiate()
        v_box_container_node.add_child(_node_instance)
        _node_instance.init(_config_item.name, _config_item.value)
        _node_instance.connect("c_pressed", choose_item_node)

    call_deferred("_resize")

func select(_index: int, _immediately: = true):
    v_box_container_node.get_children()[_index].choose(_immediately)

func choose_item_node(_node)-> void:
    if is_instance_valid(select_node) and select_node != _node:
        select_node.unchoose()

    select_node = _node
    choose_sign.emit(_node.value)

func _resize()-> void:
    self.custom_minimum_size.y = v_box_container_node.size.y