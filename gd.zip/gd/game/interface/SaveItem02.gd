class_name SaveItem02 extends Control

@onready var avatar_ani_node: AvatarAni =$Button / AvatarAni
@onready var update_time_node: IconKeyValue =$Button / UpdateTime
@onready var hero_name_node: IconKeyValue =$Button / HeroName
@onready var hero_level_node: IconKeyValue =$Button / HeroLevel
@onready var nop_node: IconKeyValue =$Button / Nop

@onready var button_node: BaseSelectButton =$Button
@onready var title_node: Label =$Button / Title
@onready var lord_banner_node: LordBanner =$Button / LordBanner

var save_summary_json: Dictionary = {}

signal choose_sign(_node)

func init(_dic: Dictionary)-> void:
    save_summary_json = _dic
    var _hero_json: Dictionary = _dic.player_hero_json
    var _team_json: Dictionary = _dic.team_json

    var _update_time: = ""
    if _dic.has("update_time"):
        _update_time = CommonUtils.timestamp_to_string(_dic.update_time, false) + " (" + str(int(_dic.system_counter)) + "天)"

    update_time_node.update_value(_update_time)
    hero_name_node.update_value(_hero_json.name)


    refresh_save_name()

    hero_level_node.update_value(CommonUtils.get_value(_hero_json, "level", ""))
    nop_node.update_value(_team_json.team.size())

    var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_json(_hero_json)
    avatar_ani_node.init(_prop, false)





    lord_banner_node.init_by_banner_config(
        CommonUtils.get_value(_dic.player_hero_json, "banner_config",{})
    )

    _custom_init()

func choose(_is_open_sound: bool = true):
    button_node.choose(_is_open_sound)

func unchoose():
    button_node.cancel()

    avatar_ani_node.animation_stop()

func get_save_file_path():
    return save_summary_json.save_path

func get_save_code():
    return save_summary_json.save_code

func get_save_name()-> String:
    return SystemUtils.get_save_name(save_summary_json)

func refresh_save_name()-> void:
    CommonUtils.set_text(title_node, SystemUtils.get_save_name(save_summary_json))

func _custom_init()-> void:
    pass

func _on_button_b_pressed()-> void:

    avatar_ani_node.play_animation()
    choose_sign.emit(self)