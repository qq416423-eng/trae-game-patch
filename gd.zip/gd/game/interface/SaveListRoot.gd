class_name SaveListRoot extends VBoxContainer

const SAVE_ITEM_NODE = preload("res://tscn/game/interface/SaveItem02.tscn")

var current_choose_node: SaveItem02

signal choose_sign(_node)

func init(_dic: Dictionary)-> void:
    _clear()


    for _index in range(_dic.size() - 1, -1, -1):
        var _summary_json = _dic.values()[_index]
        var _instance_node: SaveItem02 = SAVE_ITEM_NODE.instantiate()
        add_child(_instance_node)
        _instance_node.init(_summary_json)
        _connect_sign(_instance_node)

func choose(_index: int, _is_open_sound: bool = true):
    var _node_list: Array = CommonUtils.get_children_not_null(self)
    if _node_list.size() - 1 < _index:
        return

    _node_list[_index].choose(_is_open_sound)

func _connect_sign(_node: SaveItem02):
    _node.connect("choose_sign", _choose)

func _choose(_node: SaveItem02):
    if CommonUtils.is_not_null(current_choose_node) and current_choose_node != _node:
        current_choose_node.unchoose()

    current_choose_node = _node
    choose_sign.emit(_node)

func _clear():
    CommonUtils.clear_node(self)