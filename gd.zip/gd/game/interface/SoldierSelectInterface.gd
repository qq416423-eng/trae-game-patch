class_name SoldierSelectInterface extends Control

@onready var grid_container_node: GridContainer =$ContentRoot / SoldierSelectRoot / GridContainer
@onready var select_result_node: Label =$ContentRoot / TipRoot / SelectResult
@onready var soldier_star_selector_node: SoldierStarSelector =$ContentRoot / SoldierStarSelector
@onready var soldier_info_interface_node: SoldierInfoInterface =$ChildPageRoot / SoldierInfoInterface
@onready var bi_background_node: NinePatchRect =$Background / BIBackground
@onready var clear_button_node: CommonButton =$ButtonRoot / ClearButton
@onready var save_button_node: CommonButton =$ButtonRoot / SaveButton
@onready var clear_button_02_node: CommonButton =$ButtonRoot / ClearButton02
@onready var save_button_02_node: CommonButton =$ButtonRoot / SaveButton02
@onready var soldier_select_root_node: ScrollContainer =$ContentRoot / SoldierSelectRoot

const SOLDIER_BOX = preload("res://tscn/game/interface/soldier/SoldierBoxForSelect.tscn")



var soldier_uid_list: = []

var select_soldier_uid_list: = []
var soldier_total: = 0

var value: = ""

var temp_counter = 0

signal save_sign(_soldier_uid_list: Array, _value)

func _ready()-> void:
    _init_soldier_uid_list()


func init_select_soldier(_select_soldier_uid_list: Array)-> void:
    select_soldier_uid_list = _select_soldier_uid_list
    for _soldier_box_node: SoldierBox in grid_container_node.get_children():
        if select_soldier_uid_list.has(_soldier_box_node.get_uid()):
            _soldier_box_node.select()

    _refresh_select_result_tip()


func load_all_soldier_cache(_need_await_frame: = false)-> void:

    if grid_container_node.get_child_count() == 0:
        load_all_soldier(_need_await_frame)


func load_all_soldier(_need_await_frame: = false)-> void:
    clear()

    for soldier_uid: String in soldier_uid_list:
        var soldier_box_node: SoldierBox = SOLDIER_BOX.instantiate()
        grid_container_node.add_child(soldier_box_node)
        soldier_box_node.init_by_uid(soldier_uid)
        soldier_box_node.connect("choose", _choose_soldier_box)
        soldier_box_node.connect("view_info_sign", _view_soldier_info)
        if _need_await_frame:
            temp_counter += 1

            if temp_counter % 5 == 0:
                await get_tree().process_frame

    soldier_total = soldier_uid_list.size()
    _refresh_select_result_tip()

func _view_soldier_info(_soldier_prop: BSSoldierProp)-> void:
    soldier_info_interface_node.cshow()
    soldier_info_interface_node.init_by_soldier_prop(_soldier_prop)

func _choose_soldier_box(_node: SoldierBox)-> void:
    if _node.get_is_select():
        if not select_soldier_uid_list.has(_node.get_uid()):
            select_soldier_uid_list.append(_node.get_uid())
    else:
        select_soldier_uid_list.erase(_node.get_uid())

    _refresh_select_result_tip()

func _refresh_select_result_tip()-> void:
    CommonUtils.set_text(select_result_node, str(select_soldier_uid_list.size()) + "/" + str(soldier_total))

func cshow(_value: String)-> void:
    value = _value
    self.show()






    _clear_select_effect()

    _on_soldier_star_selector_choose_sign(-1)

    match _value:
        "0":
            CommonUtils.update_texture2(bi_background_node, "res://resource/baseUI/background_0004.png")
            clear_button_node.show()
            save_button_node.show()
            clear_button_02_node.hide()
            save_button_02_node.hide()
        "1":
            CommonUtils.update_texture2(bi_background_node, "res://resource/baseUI/background_0009.png")
            clear_button_node.hide()
            save_button_node.hide()
            clear_button_02_node.show()
            save_button_02_node.show()

func chide()-> void:
    self.hide()
    clear(false)
    _button_reset()

func _clear_select_effect()-> void:
    for _soldier_box_node: SoldierBox in grid_container_node.get_children():
        _soldier_box_node.unchoose()

func _button_reset()-> void:
    soldier_star_selector_node.reset()

func clear(_need_soldier_box: bool = true)-> void:



    if _need_soldier_box:
        CommonUtils.clear_node(grid_container_node)

    select_soldier_uid_list = []
    value = ""

func _init_soldier_uid_list()-> void:





    soldier_uid_list = GlobalSoldierInfo.action_soldier_uid_list.duplicate(true)


    soldier_uid_list.sort_custom(SortUtils.soldier_star_sort_desc)

    soldier_uid_list.append_array(GlobalSoldierInfo.action_boss_lord_hero_uid_list)


func _on_soldier_star_selector_choose_sign(_value: int)-> void:
    for _soldier_box_node: SoldierBox in grid_container_node.get_children():
        if _value <= 0:
            _soldier_box_node.cshow()
        elif _value == _soldier_box_node.get_star():
            _soldier_box_node.cshow()
        else:
            _soldier_box_node.chide()


    soldier_select_root_node.scroll_vertical = 0

func _on_save_button_custom_pressed()-> void:

    save_sign.emit(select_soldier_uid_list, value)
    chide()


func _on_clear_button_custom_pressed()-> void:
    select_soldier_uid_list = []
    for _soldier_box_node: SoldierBox in grid_container_node.get_children():
        _soldier_box_node.unchoose()

    _refresh_select_result_tip()
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.CLEAR_SUCCESS)