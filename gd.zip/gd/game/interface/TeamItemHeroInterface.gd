class_name TeamItemHeroInterface extends Control

@onready var avatar_wb_node =$AvatarWB
@onready var name_node =$Name
@onready var hp_box_value_node =$InfoBox / HpBox / Value
@onready var level_box_value_node =$InfoBox / LevelBox / Value
@onready var formation_box_value_node =$InfoBox / FormationBox / Value
@onready var button_node =$Button
@onready var upgrade_icon_node =$UpgradeIcon
@onready var hero_portrait_node: HeroPortrait =$HeroPortrait
@onready var hero_tag_node: TextureRect =$HeroTag
@onready var busy_icon_node: TextureRect =$BusyIcon
@onready var rejoin_days_node: Label =$BusyIcon / RejoinDays
@onready var hp_icon_node: TextureRect =$InfoBox / HpBox / HpIcon
@onready var hurt_icon_node: TextureRect =$InfoBox / HpBox / HurtIcon

var simple_json: Dictionary = {}
var soldier_prop: BSSoldierProp

var has_upgradable_item: = false
var is_busy: = false

signal b_pressed(_node)

func init(_simple_json: Dictionary)-> void:
    simple_json = _simple_json
    soldier_prop = SoldierUtils.get_bs_soldier_prop(_simple_json)
    avatar_wb_node.init(soldier_prop)

    CommonUtils.set_text(name_node, soldier_prop.name)
    CommonUtils.set_text(hp_box_value_node, str(soldier_prop.get_hp_percent()) + "%")
    CommonUtils.set_text(level_box_value_node, soldier_prop.level)


    if _simple_json.has("is_player") and _simple_json.is_player:
        hero_tag_node.modulate = CommonConstants.COLOR_ENUM.YELLOW


    self.refresh_upgrade_icon()

    refresh_group_num()
    hero_portrait_node.init(_simple_json.uid)


    is_busy = soldier_prop.is_busy
    if soldier_prop.is_busy:
        CommonUtils.update_self_color(button_node, CommonConstants.COLOR_ENUM.DARK_GRAY)
        CommonUtils.set_text(name_node, soldier_prop.name + " (忙碌)")
        busy_icon_node.show()

        var _rejoin_days: float = SoldierUtils.get_rejoin_days(soldier_prop.busy_data)
        CommonUtils.set_text(rejoin_days_node, int(_rejoin_days))


    if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
        hurt_icon_node.show()
        hp_icon_node.hide()
    else:
        hurt_icon_node.hide()
        hp_icon_node.show()


func refresh_upgrade_icon():
    var _has_upgradable_item = SoldierUtils.check_allow_upgradable_by_simple_json(soldier_prop.simple_json)
    has_upgradable_item = _has_upgradable_item
    if has_upgradable_item:
        upgrade_icon_node.show_effect()
    else:
        upgrade_icon_node.chide()

func cancel():
    button_node.cancel()

func choose(_is_open_sound: bool = true):
    button_node.pressed(_is_open_sound)


func choose_effect():
    button_node.show_select_effect()

func is_choose()-> bool:
    return button_node.is_choose()

func get_uid():
    return soldier_prop.uid

func get_split_group_uid():
    return soldier_prop.split_group_uid

func get_htype():
    return soldier_prop.htype

func get_simple_json():
    return soldier_prop.simple_json

func refresh_group_num():
    var _group_num = WSData.get_group_num(soldier_prop.split_group_uid)
    CommonUtils.set_text(
        formation_box_value_node,
        "?" if _group_num == -1 else _group_num
    )

func get_soldier_prop()-> BSSoldierProp:
    return soldier_prop

func get_soldier_traits()-> Dictionary:
    return CommonUtils.get_value(soldier_prop.json, "soldier_traits",{})

func is_hero()-> bool:
    return true

func get_total()-> int:
    return 1

func _on_button_b_pressed():
    emit_signal("b_pressed", self)