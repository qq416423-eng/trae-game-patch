class_name TeamItemSoldierInterface extends Control

@onready var avatar_wb_node =$AvatarWB
@onready var name_node =$Name
@onready var hp_box_value_node =$InfoBox / HpBox / Value
@onready var star_box_value_node =$InfoBox / StarBox / Value
@onready var formation_box_value_node =$InfoBox / FormationBox / Value
@onready var count_node =$Button / SoldierCountBackground / Count
@onready var soldier_count_background_node =$Button / SoldierCountBackground
@onready var injured_soldier_count_background_node =$Button / InjuredSoldierCountBackground
@onready var count_node2 =$Button / InjuredSoldierCountBackground / Count
@onready var injured_nop_node =$Button / InjuredSoldierCountBackground / InjuredNop
@onready var button_node =$Button
@onready var upgrade_icon_node =$UpgradeIcon as UpgradeIcon
@onready var star_icon_node =$InfoBox / StarBox / StarIcon
@onready var group_icon_node: TextureRect =$Button / GroupIcon

const GROUP_0002_ICON_12 = preload("res://resource/icon/smallIcon/group_0002_icon_12.png")
const GROUP_0003_ICON_12 = preload("res://resource/icon/smallIcon/group_0003_icon_12.png")

var soldier_prop: BSSoldierProp

var has_upgradable_item: = false
var simple_json_list: Array = []
var team_info: Dictionary = {}
var is_busy: = false

signal b_pressed(_node)

func get_total():
    return team_info.nop + team_info.hurt_nop

func get_soldier_name()-> String:
    return soldier_prop.name

func get_soldier_prop()-> BSSoldierProp:
    return soldier_prop

func init(_json_list: Array):
    simple_json_list = _json_list

    var _simple_json = _json_list[0]
    soldier_prop = SoldierUtils.get_bs_soldier_prop(_simple_json)
    avatar_wb_node.init(soldier_prop)

    team_info = TeamUtils.get_team_info(_json_list)

    CommonUtils.set_text(name_node, soldier_prop.name)
    CommonUtils.set_text(hp_box_value_node, str(team_info.hp_percent) + "%")
    CommonUtils.set_text(count_node, team_info.nop)
    CommonUtils.set_text(count_node2, team_info.nop)
    CommonUtils.set_text(injured_nop_node, "+" + str(team_info.hurt_nop))
    _update_star_info(soldier_prop.star)
    refresh_group_num()

    if team_info.hurt_nop > 0:
        injured_soldier_count_background_node.show()
        soldier_count_background_node.hide()
    else:
        injured_soldier_count_background_node.hide()
        soldier_count_background_node.show()


    var _has_upgradable_soldier = SoldierUtils.check_has_upgradable_soldier(_json_list)
    has_upgradable_item = _has_upgradable_soldier
    if _has_upgradable_soldier:
        upgrade_icon_node.show_effect()
    else:
        upgrade_icon_node.chide()

    if soldier_prop.split_index > 0:
        match soldier_prop.split_index:
            1:
                CommonUtils.update_texture3(group_icon_node, GROUP_0002_ICON_12)
            2:
                CommonUtils.update_texture3(group_icon_node, GROUP_0003_ICON_12)

func refresh_group_num():
    var _group_num = WSData.get_group_num(soldier_prop.split_group_uid)
    CommonUtils.set_text(
        formation_box_value_node,
        "?" if _group_num == -1 else _group_num
    )

func cancel():
    button_node.cancel()

func choose(_is_open_sound: bool = true):
    button_node.pressed(_is_open_sound)


func choose_effect():
    button_node.show_select_effect()

func get_uid()-> String:
    return soldier_prop.uid

func get_split_index()-> int:
    return soldier_prop.split_index

func get_split_group_uid()-> String:
    return soldier_prop.split_group_uid

func get_htype():
    return soldier_prop.htype

func get_simple_json():
    return soldier_prop.simple_json

func is_choose()-> bool:
    return button_node.is_choose()




func pop_simple_json_list(_count: int, is_injured_priority = null)-> Array:
    var _result: = []
    match is_injured_priority:
        null:
            for _simple_json in simple_json_list:
                _result.append(_simple_json)
                _count -= 1
                if _count <= 0:
                    break

            return _result
        true:

            for _simple_json in simple_json_list:
                if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
                    _result.append(_simple_json)
                    _count -= 1
                    if _count <= 0:
                        break

            if _count <= 0:
                return _result

            for _simple_json in simple_json_list:
                if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.ACTIVE:
                    _result.append(_simple_json)
                    _count -= 1
                    if _count <= 0:
                        break

            return _result
        false:

            for _simple_json in simple_json_list:
                if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.ACTIVE:
                    _result.append(_simple_json)
                    _count -= 1
                    if _count <= 0:
                        break

            if _count <= 0:
                return _result

            for _simple_json in simple_json_list:
                if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
                    _result.append(_simple_json)
                    _count -= 1
                    if _count <= 0:
                        break

            return _result

    return _result

func plus(_simple_json_list: Array)-> void:
    simple_json_list.append_array(_simple_json_list)
    team_info = TeamUtils.get_team_info(simple_json_list)
    CommonUtils.set_text(count_node, team_info.nop)
    CommonUtils.set_text(count_node2, team_info.nop)


func subtract(_count: int, _min_one_enforced: = false)-> Array:
    if _count > simple_json_list.size():
        _count = simple_json_list.size()

    if _min_one_enforced and _count == simple_json_list.size() and _count > 0:
        _count -= 1

    var _subtract_simple_json_list: = []
    for _index: int in range(_count):
        _subtract_simple_json_list.append(simple_json_list.pop_back())

    if simple_json_list.size() > 0:
        team_info = TeamUtils.get_team_info(simple_json_list)
        CommonUtils.set_text(count_node, team_info.nop)
        CommonUtils.set_text(count_node2, team_info.nop)
    else:
        queue_free()

    return _subtract_simple_json_list

func get_soldier_traits()-> Dictionary:
    return CommonUtils.get_value(soldier_prop.json, "soldier_traits",{})

func is_hero()-> bool:
    return false

func _update_star_info(_star: int):
    var _color: Color = SoldierUtils.get_star_color(_star)
    CommonUtils.set_text(star_box_value_node, _star)
    CommonUtils.update_self_color(star_icon_node, _color)

func _on_button_b_pressed():
    emit_signal("b_pressed", self)