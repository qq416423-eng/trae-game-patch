class_name TeamListInterface extends Control


const TEAM_ITEM_PLACEHOLDER_NODE = preload("res://tscn/game/interface/TeamItemPlaceholder.tscn")

@onready var team_item_hero_interface_node = preload("res://tscn/game/interface/TeamItemHeroInterface.tscn")
@onready var team_item_soldier_interface_node = preload("res://tscn/game/interface/TeamItemSoldierInterface.tscn")
@onready var v_box_container_node =$BaseScrollContainer / VBoxContainer
@onready var unit_type_switch_button_node: UnitTypeSwitchButton =$UnitTypeSwitchButton
@onready var title_node: Label =$Background / TitleBackground / Title
@onready var budget_info_root_node: Control =$BudgetInfoRoot
@onready var budget_total_node: Label =$BudgetInfoRoot / BudgetInfoBackground / HBoxContainer / BudgetTotal
@onready var title_background_node: NinePatchRect =$Background / TitleBackground
@onready var long_title_background_node: NinePatchRect =$Background / LongTitleBackground
@onready var long_title_node: Label =$Background / LongTitleBackground / Title
@onready var nop_info_node: Label =$Background / LongTitleBackground / NopInfo

@export var title = "我的部队"
@export var is_show_unit_type_switch_button: = true

@export var is_show_hero_unit: = true

@export var is_show_budget: = false
@export var use_long_title: = false


var select_split_group_uid: = ""
var select_node = null
var team_data = []

var sort_assistance_data: = []
var nop_limit: = 0

signal bchoose(_node)
signal unit_switch_sign(_value: int)

func _ready()-> void:
    CommonUtils.set_text(title_node, title)
    CommonUtils.set_text(long_title_node, title)

    if not is_show_unit_type_switch_button:
        unit_type_switch_button_node.hide()

    if is_show_budget:
        budget_info_root_node.show()
    else:
        budget_info_root_node.hide()

    if use_long_title:
        title_background_node.hide()
        long_title_background_node.show()
    else:
        title_background_node.show()
        long_title_background_node.hide()

func refresh(_need_init_sort_assistance_data: = false):
    self.init(team_data, true, _need_init_sort_assistance_data)



func init(
    _team_data: Array, _select_pre: = false,
    _need_init_sort_assistance_data: = true
):
    self.clear()
    team_data = _team_data


    var _group_by_uid_dic: Dictionary = _group_by_split_group_uid(_team_data)

    var _is_choose_item: = false
    var _first_node = null

    if _need_init_sort_assistance_data:
        _init_sort_assistance_data(_team_data)

    _refresh_sort_assistance_data(_group_by_uid_dic.keys())

    for _uid: String in sort_assistance_data:
        if not _group_by_uid_dic.has(_uid):
            continue

        var team_item_hero_or_soldier_interface_instance = null

        if SoldierUtils.is_hero2(_group_by_uid_dic.get(_uid)[0]):
            if not is_show_hero_unit:
                continue

            team_item_hero_or_soldier_interface_instance = team_item_hero_interface_node.instantiate()
        else:
            team_item_hero_or_soldier_interface_instance = team_item_soldier_interface_node.instantiate()

        v_box_container_node.add_child(team_item_hero_or_soldier_interface_instance)

        if _first_node == null:
            _first_node = team_item_hero_or_soldier_interface_instance

        if SoldierUtils.is_hero2(_group_by_uid_dic.get(_uid)[0]):
            team_item_hero_or_soldier_interface_instance.init(_group_by_uid_dic.get(_uid)[0])
        else:
            team_item_hero_or_soldier_interface_instance.init(_group_by_uid_dic.get(_uid))

        team_item_hero_or_soldier_interface_instance.connect("b_pressed", choose)


        if _select_pre and team_item_hero_or_soldier_interface_instance.get_split_group_uid() == select_split_group_uid:
            team_item_hero_or_soldier_interface_instance.choose(false)
            _is_choose_item = true

    if _select_pre and not _is_choose_item and CommonUtils.is_not_null(_first_node):
        _first_node.choose(false)

    var placeholder_instance = TEAM_ITEM_PLACEHOLDER_NODE.instantiate()
    v_box_container_node.add_child(placeholder_instance)

    _maybe_refresh_budge_info()
    _maybe_refresh_nop_info()


func choose(_node):
    if select_node == _node:
        return
    if select_node != null:
        select_node.cancel()

    select_node = _node

    select_split_group_uid = _node.get_split_group_uid()
    emit_signal("bchoose", _node)

func choose_first():
    v_box_container_node.get_child(0).choose(false)

func cancel_choose()-> void:
    if CommonUtils.is_not_null(select_node):
        select_node.cancel()

    select_node = null








func clear():
    select_node = null
    team_data = []
    CommonUtils.clear_node(v_box_container_node)
    unit_type_switch_button_node.reset()



func refresh_upgrade_icon():
    select_node.refresh_upgrade_icon()

func hide_or_show_unit_type_switch_button(_is_show: bool):
    if _is_show:
        unit_type_switch_button_node.show()
    else:
        unit_type_switch_button_node.hide()


func sort_up(_split_group_uid: String)-> bool:
    var _index: = sort_assistance_data.find(_split_group_uid)
    if _index <= 0:
        return true

    var _temp: String = sort_assistance_data[_index - 1]
    sort_assistance_data[_index - 1] = _split_group_uid
    sort_assistance_data[_index] = _temp

    refresh()

    if _index - 1 == 0:
        return true
    else:
        return false


func sort_down(_split_group_uid: String)-> bool:
    var _index: = sort_assistance_data.find(_split_group_uid)
    if _index == -1:
        return false

    if _index == sort_assistance_data.size() - 1:
        return true

    var _temp: String = sort_assistance_data[_index + 1]
    sort_assistance_data[_index + 1] = _split_group_uid
    sort_assistance_data[_index] = _temp

    refresh()

    if _index + 1 == sort_assistance_data.size() - 1:
        return true
    else:
        return false


func save_sort()-> void:
    for _simple_json: Dictionary in team_data:

        _simple_json.sort = sort_assistance_data.find(SoldierUtils.get_split_group_uid(_simple_json))

    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.TEAM_SORT_SAVE_SUCCESS)


func split_group(_uid: String, _nop_list: Array)-> void:
    var _temp_currend_nop_list_index = 0
    for _simple_json: Dictionary in team_data:
        if _simple_json.uid != _uid:
            continue

        _simple_json.split_index = _temp_currend_nop_list_index
        _nop_list[_temp_currend_nop_list_index] -= 1
        if _nop_list[_temp_currend_nop_list_index] <= 0:
            _temp_currend_nop_list_index += 1

    refresh(false)

func get_split_group_nop_list(_uid: String)-> Array:
    var _temp_dic = {}
    for _simple_json: Dictionary in team_data:
        if _simple_json.uid != _uid:
            continue

        var _split_index: int = CommonUtils.get_value(_simple_json, "split_index", 0)
        if _temp_dic.has(_split_index):
            _temp_dic[_split_index] += 1
        else:
            _temp_dic[_split_index] = 1

    var _size: = 1
    for _split_index: int in _temp_dic.keys():
        if _split_index + 1 > _size:
            _size = _split_index + 1

    var _result = []
    for _index in range(_size):
        _result.append(0)

    for _split_index: int in _temp_dic.keys():
        _result[_split_index] = _temp_dic.get(_split_index)

    return _result

func is_select_node_top_or_bottom():
    if CommonUtils.is_null(select_node):
        return null

    var _index = sort_assistance_data.find(select_node.get_split_group_uid())
    if _index == 0:
        return true

    if _index == sort_assistance_data.size() - 1:
        return false

    return null


func pop_simple_json_list(_split_group_uid: String, _count: int, is_injured_priority = null)-> Array:
    for _node in v_box_container_node.get_children():
        if _node is TeamItemPlaceholder:
            continue

        if _node.get_split_group_uid() == _split_group_uid:
            return _node.pop_simple_json_list(_count, is_injured_priority)

    return[]


func incremental_update(_soldier_uid_list: Array)-> void:
    if ArrayUtils.is_empty(_soldier_uid_list):
        clear()
        return

    _incremental_update_team_data(_soldier_uid_list)
    _refresh_not_select()

func list_exist_soldier_uid()-> Array:
    var _soldier_uid_list_dic: Dictionary = {}
    for _simple_json: Dictionary in team_data:
        if _soldier_uid_list_dic.has(_simple_json.uid):
            continue
        else:
            _soldier_uid_list_dic[_simple_json.uid] = 1

    return _soldier_uid_list_dic.keys()



func plus_soldier_count_and_refresh(_count: int, _min_one_enforced: = false)-> void:
    if _count == 0:
        return

    if CommonUtils.is_null(select_node):
        return

    if _count > 0:

        var _soldier_uid: String = select_node.get_uid()







        var _new_simple_json_list: = []
        for _index: int in range(_count):
            var _simple_json: Dictionary = SoldierUtils.generate_repair_simple_json(_soldier_uid)
            if select_node.get_split_index() > 0:
                _simple_json.split_index = select_node.get_split_index()

            _new_simple_json_list.append(_simple_json)

        team_data.append_array(_new_simple_json_list)



        select_node.plus(_new_simple_json_list)
    else:

        var _subtract_simple_json_list: Array = []
        if select_node.is_hero():
            _subtract_simple_json_list = [select_node.simple_json]
            select_node.queue_free()
        else:
            _subtract_simple_json_list = select_node.subtract(abs(_count), _min_one_enforced)


        ArrayUtils.remove_ele(team_data, _subtract_simple_json_list)


    _maybe_refresh_budge_info()

func get_count()-> int:
    return team_data.size()

func update_nop_limit(_nop_limit: int)-> void:
    nop_limit = _nop_limit
    _maybe_refresh_nop_info()

func _maybe_refresh_nop_info()-> void:
    if use_long_title:
        var _content: = str(team_data.size()) + "/" + str(nop_limit)
        CommonUtils.set_text(nop_info_node, _content)

        if team_data.size() >= nop_limit:
            CommonUtils.update_color(nop_info_node, CommonConstants.COLOR_ENUM.RED)
        else:
            CommonUtils.update_color(nop_info_node, CommonConstants.COLOR_ENUM.WHITE)

func _refresh_not_select()-> void:
    self.init(team_data, false, false)

func _maybe_refresh_budge_info()-> void:
    if not is_show_budget:
        return

    var _budge: int = 0
    for _simple_json: Dictionary in team_data:
        _budge += SoldierUtils.get_price(_simple_json.uid)

    CommonUtils.set_text(budget_total_node, _budge)

func _incremental_update_team_data(_soldier_uid_list: Array)-> void:
    for _index: int in range(team_data.size() - 1, -1, -1):
        var _simple_json: Dictionary = team_data[_index]
        if not _soldier_uid_list.has(_simple_json.uid):
            team_data.remove_at(_index)

    var _exist_soldier_uid_list: Array = list_exist_soldier_uid()
    for _soldier_uid: String in _soldier_uid_list:
        if not _exist_soldier_uid_list.has(_soldier_uid):
            team_data.append_array(
                SoldierUtils.generate_simple_json_list(_soldier_uid, 1)
            )

func _group_by_split_group_uid(_simple_json_list: Array)-> Dictionary:
    var _result = {}
    for _simple_json: Dictionary in _simple_json_list:
        var _split_group_uid = SoldierUtils.get_split_group_uid(_simple_json)
        if _result.has(_split_group_uid):
            _result[_split_group_uid].append(_simple_json)
        else:
            _result[_split_group_uid] = [_simple_json]

    return _result

func _init_sort_assistance_data(_team_data: Array)-> void:
    var _temp_list: = []
    var _temp_uid_dic = {}
    for _simple_json: Dictionary in _team_data:
        var _split_group_id: = SoldierUtils.get_split_group_uid(_simple_json)
        if _temp_uid_dic.has(_split_group_id):
            continue

        _temp_uid_dic[_split_group_id] = 1

        _temp_list.append(
            {
                "uid": _split_group_id,
                "sort": 10000 if not _simple_json.has("sort") else _simple_json.sort
            }
        )

    _temp_list.sort_custom(_sort_desc)

    sort_assistance_data = []
    for _uid_sort_dic: Dictionary in _temp_list:
        sort_assistance_data.append(_uid_sort_dic.uid)








func _sort_desc(_a: Dictionary, _b: Dictionary)-> bool:
    return _a.sort < _b.sort

func _refresh_sort_assistance_data(_split_group_uid_list: Array)-> void:

    for _index: int in range(_split_group_uid_list.size() - 1, -1, -1):
        var _uid = _split_group_uid_list[_index]
        if not sort_assistance_data.has(_uid):
            var _insert_success = false
            for _index2: int in range(sort_assistance_data.size()):
                if _uid.begins_with(sort_assistance_data[_index2]):
                    sort_assistance_data.insert(_index2 + 1, _uid)
                    _insert_success = true
                    break

            if _insert_success:
                continue

            sort_assistance_data.append(_uid)


    for _index: int in range(sort_assistance_data.size() - 1, -1, -1):
        var _uid: String = sort_assistance_data[_index]
        if not _split_group_uid_list.has(_uid):
            sort_assistance_data.remove_at(_index)



func _on_unit_type_switch_button_switch_sign(_value: int)-> void:
    match _value:
        0:

            for _child in v_box_container_node.get_children():
                _child.show()
        1:

            var _need_choose_another_one = false
            for _child in v_box_container_node.get_children():
                if _child is TeamItemSoldierInterface:
                    _child.hide()
                    if _child.is_choose():
                        _need_choose_another_one = true

            for _child in v_box_container_node.get_children():
                if _child is TeamItemHeroInterface:
                    _child.show()
                    if _need_choose_another_one:
                        _need_choose_another_one = false
                        _child.choose(false)

        2:

            var _need_choose_another_one = false
            for _child in v_box_container_node.get_children():
                if _child is TeamItemHeroInterface:
                    _child.hide()
                    if _child.is_choose():
                        _need_choose_another_one = true

            for _child in v_box_container_node.get_children():
                if _child is TeamItemSoldierInterface:
                    _child.show()
                    if _need_choose_another_one:
                        _need_choose_another_one = false
                        _child.choose(false)

    unit_switch_sign.emit(_value)