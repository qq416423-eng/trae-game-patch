class_name TeamManageInterface extends Control

@onready var team_list_interface_node =$TeamListInterface as TeamListInterface
@onready var soldier_equipment_interface_node =$SAE / SoldierEquipmentInterface
@onready var equipment_detail_interface_node =$Other / EquipmentDetailInterface as EquipmentDetailInterface
@onready var show_equipment_detail_interface_point_node =$SAE / ShowEquipmentDetailInterfacePoint
@onready var soldier_prop_interface_node =$PropInterface / BaseScrollContainer / SoldierPropInterface
@onready var upgrade_button_node =$SAE / SoldierButtonRoot / HBoxContainer / UpgradeButton
@onready var soldier_upgrade_interface_node =$Other / SoldierUpgradeInterface as SoldierUpgradeInterface
@onready var hero_upgrade_interface_node =$Other / HeroUpgradeInterface as HeroUpgradeInterface
@onready var team_skill_interface_node =$Other / TeamSkillInterface as TeamSkillInterface
@onready var skill_button_node =$SAE / SoldierButtonRoot / HBoxContainer / SkillButton
@onready var skill_upgrade_interface_node: SkillUpgradeInterface =$OtherFullScreen / SkillUpgradeInterface
@onready var current_skill_level_value_node =$SAE / SoldierButtonRoot / HBoxContainer / SkillButton / LevelBackground / LevelValue
@onready var group_card_icon_node =$SAE / SoldierButtonRoot / HBoxContainer / FormationButton / GroupCardIcon
@onready var formation_setting_interface_node =$Other / FormationSettingInterface
@onready var close_effect_node: TextureRect =$SAE / SoldierButtonRoot / HBoxContainer / FormationButton / CloseEffect
@onready var discharge_button_node: CommonButton =$SAE / SoldierButtonRoot / HBoxContainer / DischargeButton
@onready var discharge_soldier_interface_node: DischargeSoldierInterface =$Other / DischargeSoldierInterface
@onready var discharge_soldier_confirm_box_node: ConfirmBox =$OtherFullScreen / DischargeSoldierConfirmBox
@onready var capture_count_node: FadeInAndOutText =$ButtonRoot / CapturePageButton / CaptureCount
@onready var prisoner_page_root_node: Control =$OtherFullScreen / PrisonerPageRoot
@onready var prisoner_list_interface_node: PrisonerListInterface =$OtherFullScreen / PrisonerPageRoot / PrisonerListInterface
@onready var button_root_node: VBoxContainer =$ButtonRoot
@onready var surrender_count_node: FadeInAndOutText =$ButtonRoot / CapturePageButton / SurrenderCount
@onready var sort_mode_tip_node: Tip =$Other / SortModeTip
@onready var sort_mode_button_node: IconSwitchEffectButtonSmall =$Other / SortModeButton
@onready var soldier_button_root_box_container_node: HBoxContainer =$SAE / SoldierButtonRoot / HBoxContainer
@onready var formation_button_node: CommonButton =$SAE / SoldierButtonRoot / HBoxContainer / FormationButton
@onready var sort_button_root_node: NinePatchRect =$SAE / SoldierButtonRoot / SortButtonRoot
@onready var sort_up_button_node: CommonButton =$SAE / SoldierButtonRoot / SortButtonRoot / SortUpButton
@onready var sort_down_button_node: CommonButton =$SAE / SoldierButtonRoot / SortButtonRoot / SortDownButton
@onready var close_button_node: CommonButton =$ButtonRoot / CloseButton
@onready var save_sort_button_node: CommonButton =$ButtonRoot / SaveSortButton
@onready var split_group_button_node: CommonButton =$SAE / SoldierButtonRoot / HBoxContainer / SplitGroupButton
@onready var split_group_interface_root_node: ColorRect =$OtherFullScreen / SplitGroupInterfaceRoot
@onready var split_group_interface_node: SplitGroupInterface =$OtherFullScreen / SplitGroupInterfaceRoot / SplitGroupInterface
@onready var busy_info_root_node: NinePatchRect =$SAE / BusyInfoRoot
@onready var location_value_node: KeyValueBox =$SAE / BusyInfoRoot / LocationValue
@onready var rejoin_days_node: KeyValueBox =$SAE / BusyInfoRoot / RejoinDays
@onready var soldier_info_interface_node: SoldierInfoInterface =$OtherFullScreen / SoldierInfoInterface
@onready var respec_button_node: CommonButton =$SAE / SoldierButtonRoot / HBoxContainer / RespecButton
@onready var hero_respec_confirm_box_node: ConfirmBox =$OtherFullScreen / HeroRespecConfirmBox
@onready var capture_page_button_node: CommonButton =$ButtonRoot / CapturePageButton
@onready var more_info_node: TextPanel =$SAE / MoreInfo

@export var is_test: = false

var select_node = null

var is_sort_mode: bool = false

var has_forgotten_water: = false

signal close()
signal talk_to_prisoner_hero_sign(_hero_uid: String)

func _ready():
    pass

func init(_team_data: Array, _nop_limit: int = 0)-> void:
    _refresh_has_forgotten_water()

    team_list_interface_node.init(_team_data)

    team_list_interface_node.choose_first()
    if not is_test:
        team_skill_interface_node.refresh()

    _refresh_capture_count()
    team_list_interface_node.update_nop_limit(_nop_limit)

func _disable_all_button(_disable: bool)-> void:
    capture_page_button_node.disabled = _disable
    close_button_node.disabled = _disable
    save_sort_button_node.disabled = _disable
    team_skill_interface_node.button_disable(_disable)
    sort_mode_button_node.visible = not _disable
    team_skill_interface_node.visible = not _disable

func _refresh_has_forgotten_water()-> void:
    has_forgotten_water = GoodsUtils.is_player_has_forgotten_water()

func _refresh_capture_count()-> void:
    var _count = WSData.get_capture_count()
    capture_count_node.set_text(_count)
    if _count > 0:
        capture_count_node.update_color(Color("039be5"))
    else:
        capture_count_node.update_color(Color("757575"))

    var _surrender_count = WSData.get_surrender_count()
    if _surrender_count > 0:
        surrender_count_node.set_text(_surrender_count)
        surrender_count_node.show()
    else:
        surrender_count_node.hide()



func _hide_child_page(_is_force_close_formation_setting_page: = true):
    _hide_equipment_detail_interface()
    if _is_force_close_formation_setting_page:
        formation_setting_interface_node.chide()
    elif formation_setting_interface_node.visible:
        formation_setting_interface_node.hide_icon_setting_page()


    _open_or_hide_formation_button_effect(false)
    discharge_soldier_interface_node.chide()

func _hide_equipment_detail_interface():
    equipment_detail_interface_node.close()

func _clear_data():
    team_list_interface_node.clear()

func _refresh_button_show_or_hide(_select_node):
    for _button_node in soldier_button_root_box_container_node.get_children():
        _button_node.hide()

    if is_sort_mode:
        sort_button_root_node.show()
    else:
        sort_button_root_node.hide()

        if _select_node.has_upgradable_item:
            upgrade_button_node.show()
        else:
            upgrade_button_node.hide()

        if _select_node.get_htype() == BSSoldierConstants.H_TYPE_ENUM.HERO:
            skill_button_node.show()
            _update_skill_button_icon()
            discharge_button_node.hide()
            split_group_button_node.hide()

            if _select_node.is_busy:
                skill_button_node.hide()
                upgrade_button_node.hide()

            if has_forgotten_water:
                respec_button_node.show()
        else:
            skill_button_node.hide()
            discharge_button_node.show()
            split_group_button_node.show()

        formation_button_node.show()


        var _group_num: int = WSData.get_group_num(select_node.get_split_group_uid())
        group_card_icon_node.init(_group_num)

func _update_skill_button_icon():
    var _simple_json = select_node.get_simple_json()
    var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)
    var _learn_skill = _prop.learn_skill
    var _icon_path = SkillUtils.get_skill_button_icon_path(_learn_skill)

    skill_button_node.update_icon(_icon_path)
    CommonUtils.set_text(current_skill_level_value_node, _prop.get_skill_level(_learn_skill))


func _enter_sort_mode()-> void:
    if is_sort_mode:
        return

    is_sort_mode = true
    _hide_child_page()

    sort_mode_tip_node.cshow("排序模式")
    team_list_interface_node.hide_or_show_unit_type_switch_button(false)
    _refresh_button_show_or_hide(select_node)
    close_button_node.hide()
    save_sort_button_node.show()
    sort_up_button_node.show_tip()
    sort_down_button_node.show_tip()
    capture_page_button_node.hide()
    team_skill_interface_node.hide()


func _exit_sort_mode()-> void:
    if not is_sort_mode:
        return

    is_sort_mode = false
    sort_mode_tip_node.hide()
    team_list_interface_node.hide_or_show_unit_type_switch_button(true)
    _refresh_button_show_or_hide(select_node)
    close_button_node.show()
    save_sort_button_node.hide()
    capture_page_button_node.show()
    team_skill_interface_node.show()

func _refresh_sort_button_style()-> void:
    sort_up_button_node.cancel_disable()
    sort_down_button_node.cancel_disable()

    var _top_or_bottom = team_list_interface_node.is_select_node_top_or_bottom()

    if _top_or_bottom == null:
        return

    if _top_or_bottom:
        sort_up_button_node.disable()
    else:
        sort_down_button_node.disable()

func _open_or_hide_formation_button_effect(_show: bool)-> void:
    if _show:
        close_effect_node.show()
        close_effect_node.get_node("AnimationPlayer").play("fade")
    else:
        close_effect_node.hide()
        close_effect_node.get_node("AnimationPlayer").stop()



func _handle_more_info(_node)-> void:
    more_info_node.hide()

    if not _node.is_hero():

        var _soldier_traits: Dictionary = _node.get_soldier_traits()

        if _soldier_traits.is_empty():
            return

        more_info_node.show()
        more_info_node.update_text(
            SoldierUtils.get_soldier_traits_content(_soldier_traits)
        )
    else:


        more_info_node.show()

        var _simple_json = _node.get_simple_json()
        var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)

        var _learn_skill_code: String = _prop.learn_skill
        var _current_level: = _prop.get_skill_level(_learn_skill_code)
        var _learn_skill_name: String = SkillUtils.get_skill_name(_learn_skill_code)

        var _max_level: int = SoldierUtils.get_hero_skill_level_max(_prop.uid, _learn_skill_code)

        var _real_level: = _prop.get_skill_level(_learn_skill_code)
        if SkillUtils.is_intelligence_skill(_learn_skill_code):
            _real_level -= _prop.intelligence_skill_bonus_level

        var _level_str: = str(_real_level)
        if _real_level != _current_level:
            _level_str = str(_current_level - _real_level) + "+" + _level_str

        var _skill_exp: = _prop.get_skill_exp(_learn_skill_code)
        var _skill_exp_upgrade: = SkillUtils.get_skill_upgrade_exp(_real_level)

        var _progress_str: = str(min(_skill_exp * 100 / _skill_exp_upgrade, 100)) + "%"
        if _real_level >= _max_level:
            _progress_str = "100%"

        _level_str = _learn_skill_name + " (" + _progress_str + ", LV " + _level_str + "/" + str(_max_level) + ")"

        if _real_level >= _max_level:
            _level_str += " (已达到上限)"

        more_info_node.update_text(
            "正在学习的技能:\n" + _level_str
        )

func player_release_hero_hook(_hero_uid: String)-> void:
    prisoner_list_interface_node.player_release_hero_hook(_hero_uid)


func _on_team_list_interface_bchoose(_node):
    select_node = _node

    var _soldier_prop = _node.soldier_prop

    soldier_equipment_interface_node.init(_soldier_prop)

    soldier_prop_interface_node.init_by_simple_json(_soldier_prop.simple_json)


    _hide_child_page(false)


    if formation_setting_interface_node.visible:
        formation_setting_interface_node.init_by_uid(select_node.get_split_group_uid())

    soldier_equipment_interface_node.cancel_choose_equipment()

    self._refresh_button_show_or_hide(_node)


    if(soldier_upgrade_interface_node.visible and select_node.get_uid() != soldier_upgrade_interface_node.get_uid()) \
    or(hero_upgrade_interface_node.visible and select_node.get_uid() != hero_upgrade_interface_node.get_uid()):
        match select_node.get_htype():
            BSSoldierConstants.H_TYPE_ENUM.SOLDIER:
                hero_upgrade_interface_node.hide()
                soldier_upgrade_interface_node.show()
                soldier_upgrade_interface_node.init_by_simple_json_list(select_node.simple_json_list)
            BSSoldierConstants.H_TYPE_ENUM.HERO:
                soldier_upgrade_interface_node.hide()
                hero_upgrade_interface_node.show()
                hero_upgrade_interface_node.init(select_node.get_simple_json())




    _refresh_sort_button_style()

    if _node.is_busy:
        busy_info_root_node.show()
        var _busy_info: Dictionary = SoldierUtils.get_busy_info(_node.soldier_prop.busy_data)
        location_value_node.set_value(_busy_info.location_status_info)
        rejoin_days_node.set_value(str(int(_busy_info.rejoin_days)) + "天")
    else:
        busy_info_root_node.hide()


    _handle_more_info(_node)


func _on_close_button_pressed():
    _hide_child_page()
    self.hide()
    _clear_data()
    team_skill_interface_node.page_close()
    emit_signal("close")


func _on_soldier_equipment_interface_choose_equipment(_node):

    if GoodsUtils.is_null_json(_node.json):
        _hide_equipment_detail_interface()
        return

    equipment_detail_interface_node.init(_node.json)




    equipment_detail_interface_node.ishow(
        Vector2(
            show_equipment_detail_interface_point_node.global_position.x,
            _node.get_detail_show_position().y
        )
    )


func _on_upgrade_button_pressed():
    _hide_child_page()

    if CommonUtils.is_null(select_node):
        return


    match select_node.get_htype():
        BSSoldierConstants.H_TYPE_ENUM.SOLDIER:
            soldier_upgrade_interface_node.show()
            soldier_upgrade_interface_node.init_by_simple_json_list(select_node.simple_json_list)
        BSSoldierConstants.H_TYPE_ENUM.HERO:
            hero_upgrade_interface_node.show()
            hero_upgrade_interface_node.init(select_node.get_simple_json())



    sort_mode_button_node.disabled = true

    _disable_all_button(true)


func _on_soldier_upgrade_interface_upgrade_finish_sign():
    team_list_interface_node.refresh()


func _on_hero_upgrade_interface_save_success_sign():
    team_list_interface_node.refresh_upgrade_icon()

    soldier_prop_interface_node.refresh()
    _refresh_button_show_or_hide(select_node)


func _on_skill_button_pressed():
    skill_upgrade_interface_node.init(WSData.get_player_team_simple_json_list(), select_node.get_uid())
    skill_upgrade_interface_node.show()
    _hide_child_page()
    button_root_node.hide()

func _on_skill_upgrade_interface_close_sign():
    _update_skill_button_icon()
    _handle_more_info(select_node)
    button_root_node.show()


func _on_formation_button_pressed():







    _hide_child_page()
    formation_setting_interface_node.init_by_uid(select_node.get_split_group_uid())
    formation_setting_interface_node.show()





func _on_formation_setting_interface_need_refresh_sign(_group_num: int):

    WSData.save_group_num(select_node.get_split_group_uid(), _group_num)
    group_card_icon_node.init(_group_num)
    select_node.refresh_group_num()


func _on_discharge_button_pressed()-> void:
    if discharge_soldier_interface_node.visible:
        discharge_soldier_interface_node.chide()

    if CommonUtils.is_null(select_node):
        return

    if select_node is TeamItemHeroInterface:

        return

    discharge_soldier_interface_node.cshow(select_node.get_total())

func _on_discharge_soldier_interface_wanna_discharge_soldier_sign(_count: int)-> void:
    var _content = discharge_soldier_confirm_box_node.content \
    .replace("#{0}", str(_count)) \
    .replace("#{1}", select_node.get_soldier_name())

    discharge_soldier_confirm_box_node.update_content(_content)
    discharge_soldier_confirm_box_node.show()


func _on_discharge_soldier_confirm_box_confirm()-> void:
    var _name = select_node.get_soldier_name()

    TeamUtils.delete_soldier(
        team_list_interface_node.team_data,
        select_node.get_split_group_uid(),
        discharge_soldier_interface_node.current_count
    )
    discharge_soldier_interface_node.chide()
    team_list_interface_node.refresh()

    if discharge_soldier_interface_node.current_count > 0:
        GlobalMessageInterface.add_message(
            MessageConstants.MESSAGE_ENUM.DISCHARGE_SOLDIER_SUCCESS,
            [
                discharge_soldier_interface_node.current_count,
                _name
            ]
        )


func _on_capture_page_button_pressed()-> void:
    _hide_child_page()

    prisoner_page_root_node.show()
    prisoner_list_interface_node.init(WSData.get_capture())
    button_root_node.hide()

func _on_prisoner_page_close_button_pressed()-> void:
    prisoner_page_root_node.hide()
    prisoner_list_interface_node.clear()
    button_root_node.show()

    WSData.handle_deleted_capture()
    _refresh_capture_count()

func _on_prisoner_list_interface_surrender_action_sign()-> void:
    team_list_interface_node.refresh()

func _on_icon_switch_effect_button_small_cpressed(_value: bool)-> void:
    if _value:
        _enter_sort_mode()
    else:
        _exit_sort_mode()
        team_list_interface_node.save_sort()


func _on_sort_up_button_pressed()-> void:
    if CommonUtils.is_null(select_node):
        return

    var _is_end: = team_list_interface_node.sort_up(select_node.get_split_group_uid())





    _refresh_sort_button_style()


func _on_sort_down_button_pressed()-> void:
    if CommonUtils.is_null(select_node):
        return

    var _is_end: = team_list_interface_node.sort_down(select_node.get_split_group_uid())






    _refresh_sort_button_style()

func _on_save_sort_button_pressed()-> void:

    sort_mode_button_node.switch(false)



func _on_split_group_button_pressed()-> void:
    if CommonUtils.is_null(select_node):
        return

    if not select_node is TeamItemSoldierInterface:
        return

    _hide_child_page()

    var _nop_list: Array = team_list_interface_node.get_split_group_nop_list(select_node.get_uid())
    split_group_interface_node.init(select_node.get_soldier_prop(), _nop_list)
    split_group_interface_root_node.show()

func _on_split_group_interface_close_sign()-> void:
    split_group_interface_root_node.hide()

func _on_split_group_interface_save_sign(_uid: String, _nop_list: Array)-> void:
    team_list_interface_node.split_group(_uid, _nop_list)
    split_group_interface_root_node.hide()
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SPLIT_GROUP_MESSAGE)

func _on_team_list_interface_unit_switch_sign(_value: int)-> void:
    match _value:
        0:
            sort_mode_tip_node.cshow("查看全部", 3)
            sort_mode_button_node.disabled = false
        1:
            sort_mode_tip_node.cshow("只查看英雄", 3)
            sort_mode_button_node.disabled = true
        2:
            sort_mode_tip_node.cshow("只查看士兵", 3)
            sort_mode_button_node.disabled = true

func _on_soldier_upgrade_interface_close_sign()-> void:
    sort_mode_button_node.disabled = false

    _disable_all_button(false)

func _on_hero_upgrade_interface_close_sign()-> void:
    sort_mode_button_node.disabled = false

    _disable_all_button(false)

func _on_soldier_upgrade_interface_view_info_sign(_soldier_prop: BSSoldierProp)-> void:
    soldier_info_interface_node.init_by_soldier_prop(_soldier_prop)
    soldier_info_interface_node.cshow()


func _on_respec_button_pressed()-> void:
    if CommonUtils.is_null(select_node):
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.NEED_SELECT_HERO)
        return


    var _init_hero_data: Dictionary = GlobalSoldierInfo.get_init_hero_data(select_node.get_uid())
    if select_node.get_uid() != CreateCharacterConstants.PLAYER_HERO_CODE and _init_hero_data.size() == 0:
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.HERO_CANT_BE_RESPECED)
        return


    hero_respec_confirm_box_node.open()


func _on_hero_respec_confirm_box_confirm()-> void:

    var _success: bool = GoodsUtils.subtract_goods_simple_json_by_uid(
        WSData.get_player_goods(),
        GoodsConstants.FORGOTTEN_WATER_UID
    )
    if not _success:

        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.NO_FORGOTTEN_WATER)
        return


    GlobalMessageInterface.add_lost_goods_message(GoodsConstants.FORGOTTEN_WATER_UID)


    SoldierUtils.hero_respec(select_node.get_uid())


    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.HERO_RESPECED_SUCCESS)

    _refresh_has_forgotten_water()


    soldier_prop_interface_node.refresh()

    team_list_interface_node.refresh_upgrade_icon()
    _refresh_button_show_or_hide(select_node)

func _on_prisoner_list_interface_talk_to_prisoner_hero_sign(_hero_uid: String)-> void:
    talk_to_prisoner_hero_sign.emit(_hero_uid)