class_name ValueSmallBox extends Control

@onready var value_node: Label =$Value

enum VALUE_STYLE_ENUM {
    RED,
    GREEN
}

func set_value(_value, _style_enum: VALUE_STYLE_ENUM)-> void:
    CommonUtils.set_text(value_node, _value)
    match _style_enum:
        VALUE_STYLE_ENUM.RED:
            value_node.get_theme_stylebox("normal").modulate_color = Color("#b4130a")
        VALUE_STYLE_ENUM.GREEN:
            value_node.get_theme_stylebox("normal").modulate_color = Color("#3E8E41")