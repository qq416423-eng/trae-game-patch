class_name BoxLine extends NinePatchRect

@export var mid_width: = -1

func _ready()-> void:
    if mid_width > 0:
        var _regin_left =(16 * size.x -(82 * mid_width)) /(32 - mid_width)
        patch_margin_left = _regin_left
        patch_margin_right = _regin_left