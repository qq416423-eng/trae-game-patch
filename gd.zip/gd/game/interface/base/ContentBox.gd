class_name ContentBox extends Control

@onready var content_node =$Content

func set_text(_text: String)-> void:
    CommonUtils.set_text(content_node, _text)