class_name IconKeyValue extends HBoxContainer

@onready var value_node =$Value
@onready var icon_node =$Icon
@onready var key_node =$Key
@onready var key_mid_node: Label =$KeyMid
@onready var value_mid_node: Label =$ValueMid

@export var icon: Texture2D = preload("res://resource/icon/smallIcon/money_icon_16.png")
@export var key: String = "key"
@export var show_icon: bool = true
@export var show_key: bool = true
@export var font_color: Color = CommonConstants.COLOR_ENUM.WHITE
@export var icon_x: = -1

@export var is_mid_font: = false
@export var default_value: = "test"

var value: String = ""

func _ready():
    CommonUtils.update_texture3(icon_node, icon)
    CommonUtils.set_text(key_node, key)
    CommonUtils.set_text(key_mid_node, key)
    if show_icon:
        icon_node.show()
    else:
        icon_node.hide()

    if show_key:
        key_node.show()
    else:
        key_node.hide()

    CommonUtils.update_color(key_node, font_color)
    CommonUtils.update_color(key_mid_node, font_color)
    update_value_color(font_color)

    if icon_x > 0:
        icon_node.custom_minimum_size.x = icon_x

    if is_mid_font:
        if key_node.visible:
            key_node.hide()
            key_mid_node.show()
        if value_node.visible:
            value_node.hide()
            value_mid_node.show()

    update_value(default_value)

func update_value(_value)-> void:
    _value = " " + str(_value)
    CommonUtils.set_text(value_node, _value)
    CommonUtils.set_text(value_mid_node, _value)
    value = _value

func update_value_color(_color: Color)-> void:
    CommonUtils.update_color(value_node, _color)
    CommonUtils.update_color(value_mid_node, _color)


func update_num_value(_value: float, _num: = 1)-> void:
    var _value_str: = ""

    _value = CommonUtils.format_float(_value, _num)




    _value_str = CommonUtils.num_to_str(_value, true)
    if _value <= -10000:
        _value_str = "-∞"

    update_value(_value_str)
    if _value >= 0:
        CommonUtils.update_color(value_node, CommonConstants.COLOR_ENUM.GREEN)
        CommonUtils.update_color(value_mid_node, CommonConstants.COLOR_ENUM.GREEN)
    else:
        CommonUtils.update_color(value_node, CommonConstants.COLOR_ENUM.RED)
        CommonUtils.update_color(value_mid_node, CommonConstants.COLOR_ENUM.RED)

func append_value(_value)-> void:
    update_value(value + str(_value))