@tool
class_name TitleBackground extends NinePatchRect

@onready var title_node =$Title

@export var title: = "":
    set(_title):
        title = _title
        CommonUtils.set_text($Title, _title)

func _ready():
    title_node.size = self.size

func update_title(_title: String):
    CommonUtils.set_text(title_node, _title)