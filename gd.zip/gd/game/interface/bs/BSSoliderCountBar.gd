extends Control

@onready var my_and_teammate_unit_count_node =$Mid / MyAndTeammateUnitCount
@onready var enemy_count_node =$Mid / EnemyCount
@onready var enemy_count_bar_node =$CountBarRoot / EnemyCountBar
@onready var my_count_bar_node =$CountBarRoot / WeCountBarRoot / MyCountBar
@onready var teammate_count_bar_node =$CountBarRoot / WeCountBarRoot / TeammateCountBar
@onready var we_count_bar_root_node =$CountBarRoot / WeCountBarRoot
@onready var mid_node =$Mid


var hp_groove_start_x = 6
var hp_groove_length = 632

var mid_length_effective = 80

var mid_length = 88

var my_and_teammate_bar_init_length = 0
var enemy_bar_init_length = 0

var my_unit_count_total = 0
var enemy_count_total = 0
var teammate_unit_total = 0

var my_team_count = 0
var teammate_count = 0
var enemy_count = 0

func update_player_count(_total):
    my_team_count = _total
    CommonUtils.set_text(my_and_teammate_unit_count_node, _total + teammate_count)

    if _total == 0:
        my_count_bar_node.custom_minimum_size.x = 0
    else:
        my_count_bar_node.custom_minimum_size.x = my_and_teammate_bar_init_length * _total /(my_unit_count_total + teammate_unit_total)

func update_teammate_count(_total):
    teammate_count = _total
    my_and_teammate_unit_count_node.text = str(my_team_count + _total)

    if _total == 0:
        teammate_count_bar_node.custom_minimum_size.x = 0
    else:
        teammate_count_bar_node.custom_minimum_size.x = my_and_teammate_bar_init_length * _total /(my_unit_count_total + teammate_unit_total)

func update_enemy_count(_total):
    enemy_count = _total

    enemy_count_node.text = str(_total)
    if enemy_count_total == 0:
        enemy_count_bar_node.size.x = 0
    else:
        enemy_count_bar_node.size.x = int(enemy_bar_init_length * _total / enemy_count_total)

func init(_my_unit_count, _enemy_count, _teammate_unit_count):
    my_unit_count_total = _my_unit_count
    enemy_count_total = _enemy_count
    teammate_unit_total = _teammate_unit_count

    my_and_teammate_bar_init_length =(hp_groove_length - mid_length_effective) *(_my_unit_count + _teammate_unit_count) /(_my_unit_count + _teammate_unit_count + _enemy_count)
    enemy_bar_init_length = hp_groove_length - mid_length_effective - my_and_teammate_bar_init_length

    enemy_count_bar_node.position.x = hp_groove_start_x + my_and_teammate_bar_init_length + mid_length_effective
    we_count_bar_root_node.position.x = - we_count_bar_root_node.size.x + my_and_teammate_bar_init_length + hp_groove_start_x
    mid_node.position.x = hp_groove_start_x + my_and_teammate_bar_init_length -((mid_length - mid_length_effective) / 2)


    update_player_count(_my_unit_count)
    update_teammate_count(teammate_unit_total)
    update_enemy_count(_enemy_count)