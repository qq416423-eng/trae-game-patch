extends Control
class_name BattleAnimation

@onready var animation_player =$AnimationPlayer
@onready var result_icon_node: TextureRect =$ResultIcon
const BATTLE_DEFEAT_BIG_PIC = preload("res://resource/illustration/battle_defeat_big.png")
const BATTLE_VICTORY_BIG_PIC = preload("res://resource/illustration/battle_victory_big.png")

@export var play_draw_sword_sound: = true

var is_open = false


var _is_close_finish_emitted: = false

signal open_finish()
signal close_finish()
signal formation_start_ani_finish()


func _ready():
    if not animation_player.is_connected("animation_finished", _on_animation_player_animation_finished):
        animation_player.connect("animation_finished", _on_animation_player_animation_finished)


func update_battle_result(_battle_result_enum: String)-> void:
    match _battle_result_enum:
        BattleConstants.BATTLE_RESULT_ENUM.VICTORY:
            CommonUtils.update_texture3(result_icon_node, BATTLE_VICTORY_BIG_PIC)
        BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
            CommonUtils.update_texture3(result_icon_node, BATTLE_DEFEAT_BIG_PIC)


func formation_start_ani():
    animation_player.play("formation_start")
    self.mouse_filter = Control.MOUSE_FILTER_IGNORE


func open():
    animation_player.play("open")


func close():
    stop_outside_input()
    cshow()
    _is_close_finish_emitted = false
    animation_player.play("close")

    var _timer = get_tree().create_timer(3.0)
    _timer.timeout.connect(_close_finish)

func cshow()-> void:
    self.show()

func chide()-> void:
    self.hide()

func color_rect_dark_ani()-> void:
    animation_player.play("color_rect_dark")

func draw_sword_sound_play():
    if play_draw_sword_sound:
        GlobalSoundManager.play_sfx(SoundConstants.SFX_NAME.DRAW_SWORD)

func stop_outside_input()-> void:
    self.mouse_filter = Control.MOUSE_FILTER_STOP

func open_outside_input()-> void:
    self.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _on_animation_player_animation_finished(anim_name):


    if anim_name == "close":
        _close_finish()

func _open_finish():
    emit_signal("open_finish")

func _close_finish():

    if _is_close_finish_emitted:
        return
    _is_close_finish_emitted = true
    emit_signal("close_finish")

func _formation_start_ani_finish()-> void:
    formation_start_ani_finish.emit()