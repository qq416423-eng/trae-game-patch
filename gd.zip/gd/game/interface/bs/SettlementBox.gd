extends Control
class_name SettlementBox




var settlement_soldier_box_scene = null

func _get_soldier_box_scene():
    if settlement_soldier_box_scene == null:
        settlement_soldier_box_scene = load("res://tscn/game/interface/bs/SettlementSoldierBox.tscn")
    return settlement_soldier_box_scene


@onready var victory_pic_root_node =$Background / VictoryPicRoot
@onready var defeat_pic_root_node =$Background / DefeatPicRoot
@onready var v_box_container_node =$BaseScrollContainer / VBoxContainer
@onready var total_node =$Background / DataRoot / HBoxContainer / Total
@onready var hurt_count_node =$Background / DataRoot / HBoxContainer / HurtCount
@onready var die_count_node =$Background / DataRoot / HBoxContainer / DieCount
@onready var no_data_tip_node =$Background / NoDataTip
@onready var title_node =$Background / TitleBackground / HBoxContainer / Title
@onready var flee_count_node =$Background / DataRoot / HBoxContainer / FleeCount

@export var battle_result: String = BattleConstants.BATTLE_RESULT_ENUM.VICTORY
@export var title: String = "我方部队"
@export var is_show_tag_pic = true

var living_status_simple_json_list_dic = {}

func _ready():
    update_battle_result(battle_result)
    if title_node != null:
        CommonUtils.set_text(title_node, title)
    if not is_show_tag_pic:
        if victory_pic_root_node != null and victory_pic_root_node.has_node("VictoryPic"):
            victory_pic_root_node.get_node("VictoryPic").hide()
        if defeat_pic_root_node != null and defeat_pic_root_node.has_node("DefeatPic"):
            defeat_pic_root_node.get_node("DefeatPic").hide()


func init(_json_list: Array, _total: int)-> void:
    var _injury_count = 0
    var _die_count = 0
    var _flee_count = 0
    living_status_simple_json_list_dic = {}

    if ArrayUtils.is_not_empty(_json_list):
        _json_list.sort_custom(SortUtils.living_status_sort)

    for _json in _json_list:
        if not living_status_simple_json_list_dic.has(_json.living_status):
            living_status_simple_json_list_dic[_json.living_status] = []

        living_status_simple_json_list_dic[_json.living_status].append(_json)

        match _json.living_status:
            BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
                _injury_count += _json.count
            BSSoldierConstants.LIVING_STATUS_ENUM.DEATH:
                _die_count += _json.count
            BSSoldierConstants.LIVING_STATUS_ENUM.FLEE_SUCCESS:
                _flee_count += _json.count
            BSSoldierConstants.LIVING_STATUS_ENUM.ACTIVE:
                continue


        var _scene = _get_soldier_box_scene()
        if _scene != null:
            var _settlement_soldier_box_instance = _scene.instantiate()
            v_box_container_node.add_child(_settlement_soldier_box_instance)
            if _settlement_soldier_box_instance.has_method("init"):
                _settlement_soldier_box_instance.init(_json.soldier, _json.living_status, _json.count)
        else:
            push_warning("SettlementBox: 无法加载SettlementSoldierBox场景")


    if total_node != null and total_node.has_method("set_text"):
        total_node.set_text(_total)
    if hurt_count_node != null and hurt_count_node.has_method("set_text"):
        hurt_count_node.set_text(_injury_count)
    if die_count_node != null and die_count_node.has_method("set_text"):
        die_count_node.set_text(_die_count)
    if flee_count_node != null and flee_count_node.has_method("set_text"):
        flee_count_node.set_text(_flee_count)

    if _injury_count + _die_count + _flee_count == 0:
        if no_data_tip_node != null:
            no_data_tip_node.show()
    else:
        if no_data_tip_node != null:
            no_data_tip_node.hide()

func clear():
    CommonUtils.clear_node(v_box_container_node)
    living_status_simple_json_list_dic = {}

func victory_show():
    if victory_pic_root_node != null:
        victory_pic_root_node.show()
    if defeat_pic_root_node != null:
        defeat_pic_root_node.hide()

func defeat_show():
    if defeat_pic_root_node != null:
        defeat_pic_root_node.show()
    if victory_pic_root_node != null:
        victory_pic_root_node.hide()

func update_battle_result(_battle_result):
    battle_result = _battle_result
    match battle_result:
        BattleConstants.BATTLE_RESULT_ENUM.VICTORY:
            victory_show()
        BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
            defeat_show()

func get_count_by_living_status(_living_status: int)-> int:
    if not living_status_simple_json_list_dic.has(_living_status):
        return 0

    return living_status_simple_json_list_dic.get(_living_status).size()

func get_simple_json_list_by_living_status(_living_status: int)-> Array:
    if not living_status_simple_json_list_dic.has(_living_status):
        return[]

    return living_status_simple_json_list_dic.get(_living_status)