class_name SettlementInterface extends Control


@onready var my_team_settlement_box_node =$Root / MyTeamSettlementBox
@onready var enemy_settlement_box_node =$Root / EnemySettlementBox
@onready var ally_settlement_box_node =$Root / AllySettlementBox
@onready var capture_count_node: FadeInAndOutText =$Root / ButtonRoot / CapturePageButton / CaptureCount
@onready var capture_page_button_node: CommonButton =$Root / ButtonRoot / CapturePageButton
@onready var prisoner_list_interface_node: PrisonerListInterface =$Root / PrisonerListInterface
@onready var button_root_node: VBoxContainer =$Root / ButtonRoot
@onready var prisoner_button_root_node: VBoxContainer =$Root / PrisonerButtonRoot
@onready var capture_all_button_node: CommonButton =$Root / PrisonerButtonRoot / CaptureAllButton
@onready var next_button_node: CommonButton =$Root / ButtonRoot / NextButton
@onready var back_to_main_menu_button_node: CommonButton =$Root / ButtonRoot / BackToMainMenuButton

var battle_result

var enemy_injury_simple_json_list: = []

var is_for_start_interface_battle: = false


var mod_error_text: String = ""

signal next_sign()
signal back_to_main_sign()
signal talk_to_prisoner_hero_sign(_hero_uid: String)

func _ready():
    pass

func update_is_for_start_interface_battle(_is_for_start_interface_battle: bool)-> void:
    is_for_start_interface_battle = _is_for_start_interface_battle

    if _is_for_start_interface_battle:
        capture_page_button_node.hide()
        next_button_node.hide()
        back_to_main_menu_button_node.show()
    else:
        capture_page_button_node.show()
        next_button_node.show()
        back_to_main_menu_button_node.hide()


func init2(
    _my_team_json, _enemy_team_json,
    _battle_result, _my_total,
    _enemy_total,

    _player_kill_soldier_simple_json
):
    mod_error_text = ""

    for _button_node: CommonButton in button_root_node.get_children():
        _button_node.cancel_disable()

    prisoner_button_root_node.hide()


    enemy_injury_simple_json_list = _player_kill_soldier_simple_json.filter(
        func(_simple_json: Dictionary): return _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY
    )


    for _index: int in range(enemy_injury_simple_json_list.size() - 1, -1, -1):
        var _simple_json: Dictionary = enemy_injury_simple_json_list[_index]
        if SoldierUtils.is_hero_by_simple_json(_simple_json) \
        and not CommonUtils.get_value(_simple_json, "is_captured", false):
            enemy_injury_simple_json_list.remove_at(_index)


    _my_team_json = _aggregate_json(_my_team_json)
    _enemy_team_json = _aggregate_json(_enemy_team_json)
    init(_my_team_json, _enemy_team_json, _battle_result, _my_total, _enemy_total)

    _refresh_capture_info()

func init(_my_team_json, _enemy_team_json, _battle_result, _my_total, _enemy_total):
    battle_result = _battle_result


    if my_team_settlement_box_node != null and my_team_settlement_box_node.has_method("init"):
        my_team_settlement_box_node.init(_my_team_json, _my_total)
    if enemy_settlement_box_node != null and enemy_settlement_box_node.has_method("init"):
        enemy_settlement_box_node.init(_enemy_team_json, _enemy_total)

    var _battle_result_inverse = BattleConstants.get_battle_result_inverse(_battle_result)

    if my_team_settlement_box_node != null and my_team_settlement_box_node.has_method("update_battle_result"):
        my_team_settlement_box_node.update_battle_result(_battle_result)
    if enemy_settlement_box_node != null and enemy_settlement_box_node.has_method("update_battle_result"):
        enemy_settlement_box_node.update_battle_result(_battle_result_inverse)

    if battle_result == BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
        capture_page_button_node.hide()
    else:
        if not is_for_start_interface_battle:
            capture_page_button_node.show()

    _fix_titles()


func _fix_titles():

    if enemy_settlement_box_node != null:
        enemy_settlement_box_node.set("title", "敌方部队")
        if enemy_settlement_box_node.has_node("Background/TitleBackground/HBoxContainer/Title"):
            enemy_settlement_box_node.get_node("Background/TitleBackground/HBoxContainer/Title").text = "敌方部队"
    if my_team_settlement_box_node != null:
        my_team_settlement_box_node.set("title", "我方部队")
        if my_team_settlement_box_node.has_node("Background/TitleBackground/HBoxContainer/Title"):
            my_team_settlement_box_node.get_node("Background/TitleBackground/HBoxContainer/Title").text = "我方部队"

func init_teammate(_soldier_json_list, _soldier_total):
    _soldier_json_list = _aggregate_json(_soldier_json_list)
    if ally_settlement_box_node != null and ally_settlement_box_node.has_method("init"):
        ally_settlement_box_node.init(_soldier_json_list, _soldier_total)
        ally_settlement_box_node.update_battle_result(battle_result)
        ally_settlement_box_node.set("title", "友方部队")
        if ally_settlement_box_node.has_node("Background/TitleBackground/HBoxContainer/Title"):
            ally_settlement_box_node.get_node("Background/TitleBackground/HBoxContainer/Title").text = "友方部队"
        ally_settlement_box_node.show()

func hide_teammate_box():
    if ally_settlement_box_node != null:
        ally_settlement_box_node.hide()

func show_or_hide_capture_page_button(_is_show: bool)-> void:
    if _is_show and not is_for_start_interface_battle:
        capture_page_button_node.show()
    else:
        capture_page_button_node.hide()

func _refresh_capture_info():
    var _count = enemy_injury_simple_json_list.size()
    capture_count_node.set_text(enemy_injury_simple_json_list.size())

    if _count > 0:
        capture_page_button_node.cancel_disable()
        capture_count_node.update_color(Color("039be5"))
        capture_count_node.run_ani()
    else:
        capture_page_button_node.disable()
        capture_count_node.update_color(Color("757575"))
        capture_count_node.stop_ani()

func _aggregate_json(_json_list):
    var _result = []
    for _json in _json_list:
        var is_processed: = false
        for _result_item_json in _result:
            if _json.uid == _result_item_json.soldier.uid and _json.living_status == _result_item_json.living_status:
                _result_item_json.count += 1
                is_processed = true
                break

        if not is_processed:
            _result.append(
                {
                    "soldier": _json,
                    "living_status": _json.living_status,
                    "count": 1
                }
            )

    return _result


func _on_next_button_pressed():
    self.hide()
    next_sign.emit()



func _on_capture_page_button_pressed()-> void:
    for _button_node: CommonButton in button_root_node.get_children():
        _button_node.disable()

    var _tween = get_tree().create_tween()
    _tween.tween_property(enemy_settlement_box_node, "modulate:a", 0.0, 0.2)
    _tween.parallel().tween_property(button_root_node, "modulate:a", 0.0, 0.2)
    prisoner_button_root_node.show()
    _tween.parallel().tween_property(prisoner_button_root_node, "modulate:a", 1.0, 0.2)

    prisoner_list_interface_node.cshow()
    prisoner_list_interface_node.init(enemy_injury_simple_json_list)


func _on_capture_all_button_custom_pressed()-> void:
    prisoner_list_interface_node.capture_all()
    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURE_MESSAGE,
        ["所有俘虏"]
    )
    capture_all_button_node.disable()


func _on_back_to_main_menu_button_custom_pressed()-> void:
    back_to_main_sign.emit()

func _on_prisoner_list_interface_only_contain_hero_or_empty_sign()-> void:
    capture_all_button_node.disable()

func _on_prisoner_list_interface_talk_to_prisoner_hero_sign(_hero_uid: String)-> void:
    talk_to_prisoner_hero_sign.emit(_hero_uid)