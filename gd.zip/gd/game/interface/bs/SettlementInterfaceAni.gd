class_name SettlementInterfaceAni extends SettlementInterface

@onready var animation_player_node =$AnimationPlayer

func cshow():
    animation_player_node.play("show")
    self.show()