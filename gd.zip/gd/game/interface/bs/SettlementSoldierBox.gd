extends Control
class_name SettlementSoldierBox



@onready var avatar_wb_node = get_node_or_null("InfoRoot/AvatarWB")
@onready var name_node = get_node_or_null("InfoRoot/Name")
@onready var soldier_tag_node = get_node_or_null("InfoRoot/SoldierTag")
@onready var hero_tag_node = get_node_or_null("InfoRoot/HeroTag")
@onready var star_box_node = get_node_or_null("InfoRoot/StarBox")
@onready var level_box_node = get_node_or_null("InfoRoot/LevelBox")
@onready var star_value_node = get_node_or_null("InfoRoot/StarBox/Value")
@onready var level_value_node = get_node_or_null("InfoRoot/LevelBox/Value")
@onready var count_value_node = get_node_or_null("InfoRoot/CountRoot/Value")
@onready var count_root_node = get_node_or_null("InfoRoot/CountRoot")

func init(_simple_json, _injured_type_enum, _count):
    var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)


    if avatar_wb_node != null and avatar_wb_node.has_method("init"):
        avatar_wb_node.init(_prop)

    if name_node != null:
        CommonUtils.set_text(name_node, _prop.name)


    if soldier_tag_node != null:
        soldier_tag_node.hide()
    if hero_tag_node != null:
        hero_tag_node.hide()
    if star_box_node != null:
        star_box_node.hide()
    if level_box_node != null:
        level_box_node.hide()

    match _prop.htype:
        BSSoldierConstants.H_TYPE_ENUM.SOLDIER:
            if soldier_tag_node != null:
                soldier_tag_node.show()
            if star_box_node != null:
                star_box_node.show()
            if star_value_node != null:
                CommonUtils.set_text(star_value_node, _prop.star)
            if count_value_node != null:
                count_value_node.show()
        BSSoldierConstants.H_TYPE_ENUM.HERO:
            if hero_tag_node != null:
                hero_tag_node.show()
            if level_box_node != null:
                level_box_node.show()
            if level_value_node != null:
                CommonUtils.set_text(level_value_node, _prop.level)
            if count_value_node != null:
                count_value_node.hide()

    match _injured_type_enum:
        BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
            var _color = CommonConstants.COLOR_ENUM.YELLOW
            if count_root_node != null:
                CommonUtils.set_text(count_root_node, "重伤", _color)
            if count_value_node != null:
                CommonUtils.set_text(count_value_node, "x" + str(_count), _color)
        BSSoldierConstants.LIVING_STATUS_ENUM.DEATH:
            var _color = CommonConstants.COLOR_ENUM.RED
            if count_root_node != null:
                CommonUtils.set_text(count_root_node, "死亡", _color)
            if count_value_node != null:
                CommonUtils.set_text(count_value_node, "x" + str(_count), _color)
        BSSoldierConstants.LIVING_STATUS_ENUM.FLEE_SUCCESS:
            var _color = CommonConstants.COLOR_ENUM.GRAY
            if count_root_node != null:
                CommonUtils.set_text(count_root_node, "逃亡", _color)
            if count_value_node != null:
                CommonUtils.set_text(count_value_node, "x" + str(_count), _color)