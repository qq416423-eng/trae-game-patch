class_name FormationIconButton extends BaseSelectButton

@onready var group_card_icon_node =$IconBackground / GroupCardIcon

@export var value: int = 1
@export var hide_group_num: = true

var color: Color
var code: String

func _custom_ready():
    group_card_icon_node.update_hide_group_num(hide_group_num)

func init_by_config(_config: Dictionary):
    set_code(_config.code)
    group_card_icon_node.init_by_config(_config)

func init_by_group_num(_group_num: int)-> void:
    var _config = group_card_icon_node.init(_group_num)
    set_code(_config.code)

func refresh():
    init_by_group_num(value)

func set_code(_code: String):
    code = _code

func update_icon(_path: String):
    group_card_icon_node.update_icon(_path)

func update_color(_color: Color):
    color = _color
    group_card_icon_node.update_color(_color)