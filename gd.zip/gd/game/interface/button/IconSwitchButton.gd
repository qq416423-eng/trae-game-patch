class_name IconSwitchButton extends TextureButton

@onready var icon_0_node =$Icon0
@onready var icon_1_node =$Icon1

@export var remark = "0 = ?, 1 = ?"
@export var icon0: Texture2D
@export var icon1: Texture2D
@export var default_value: bool = false

@export var open_switch: = true
@export var sound_type: SoundConstants.SFX_NAME = SoundConstants.SFX_NAME.BUTTON_CLICK_0001

signal cpressed(_value)


var current_value: = false
var last_pressed_time: = -10000
var cooldown_time: = SystemConfig.BUTTON_COOLDOWN_TIME

func _ready():
    CommonUtils.update_texture3(icon_0_node, icon0)
    CommonUtils.update_texture3(icon_1_node, icon1)
    current_value = default_value
    _update_icon_style()

func switch(_value):
    current_value = _value
    _update_icon_style()
    cpressed.emit(current_value)

func _on_pressed():
    var now: = Time.get_ticks_msec()
    if now - last_pressed_time < cooldown_time:

        return

    GlobalSoundManager.play_sfx(sound_type)

    current_value = not current_value
    _update_icon_style()
    cpressed.emit(current_value)

func _update_icon_style():
    if not open_switch:
        return

    if not current_value:
        icon_0_node.show()
        icon_1_node.hide()
    else:
        icon_1_node.show()
        icon_0_node.hide()