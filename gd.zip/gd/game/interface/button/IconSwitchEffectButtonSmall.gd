class_name IconSwitchEffectButtonSmall extends IconSwitchButton

@onready var select_effect_node: AnimatedSprite2D =$SelectEffect

func _on_cpressed(_value: bool)-> void:
    if _value:
        select_effect_node.play("effect")
        select_effect_node.show()
    else:
        select_effect_node.stop()
        select_effect_node.hide()