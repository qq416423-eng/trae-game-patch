@tool
class_name MenuButton2 extends BaseSelectButton

@onready var select_effect_ani_node: AnimatedSprite2D =$SelectEffectAni

@export var show_selected_ani: = true

func _on_b_pressed_2_sign(_node: Variant)-> void:
    if show_selected_ani:
        select_effect_ani_node.show()

func _custom_cancel():
    if show_selected_ani:
        select_effect_ani_node.hide()