@tool
class_name SliderButton0002 extends Control

@onready var slider_button_pic_node: TextureRect =$SliderButtonPic
@onready var tip_root_node: Marker2D =$TipRoot

const BUBBLE_TIP_NODE = preload("res://tscn/common/BubbleTip.tscn")

@export var icon: Texture2D
@export var tip: = "滑动它"

var _is_drag: = false
var _min_x: = 0.0
var _max_x: = 0.0

signal update_position_x(_x: float)

func _ready()-> void:
    if CommonUtils.is_not_null(icon):
        CommonUtils.update_texture3(slider_button_pic_node, icon)

func _physics_process(delta: float)-> void:
    if _is_drag:
        self.global_position.x = get_viewport().get_mouse_position().x
        if self.position.x > _max_x:
            self.position.x = _max_x
        elif self.position.x < _min_x:
            self.position.x = _min_x

        update_position_x.emit(self.position.x)

func get_button_size()-> Vector2:
    return slider_button_pic_node.size

func init(_position_x: float, _min_x: float, _max_x: float)-> void:
    self.position.x = _position_x
    update_min_x(_min_x)
    update_max_x(_max_x)

func update_min_x(_x: float)-> void:
    _min_x = _x
    if self.position.x < _min_x:
        self.position.x = _min_x

func update_max_x(_x: float)-> void:
    _max_x = _x
    if self.position.x > _max_x:
        self.position.x = _max_x

func cshow():
    self.show()
    show_tip()

func show_tip():
    var _node: BubbleTip = BUBBLE_TIP_NODE.instantiate()
    tip_root_node.add_child(_node)
    _node.cshow(tip, CommonConstants.DIRECTION_ENUM.RIGHT)

func _on_slider_button_pic_gui_input(_event: InputEvent)-> void:
    if MouseUtils.check_mouse_left_click(_event):

        _is_drag = true
    elif MouseUtils.check_mouse_left_release(_event):
        _is_drag = false