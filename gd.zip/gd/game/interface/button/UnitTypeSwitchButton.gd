class_name UnitTypeSwitchButton extends Control

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

var current_style_value: = 0
var current_value: = 0
var max_value: = 2

signal switch_sign(_value: int)

func _style_value_change_to(_value: int)-> void:
    current_style_value = _value
    if current_style_value != current_value:
        animation_player_node.play(_get_next_ani_name(current_style_value))

func _get_next_ani_name(_current_style_value)-> String:
    var _next_ani_name = ""
    var _next_style_value = _current_style_value + 1
    if _next_style_value > max_value:
        _next_style_value = 0

    match _next_style_value:
        0:
            _next_ani_name = "change03"
        1:
            _next_ani_name = "change01"
        2:
            _next_ani_name = "change02"

    return _next_ani_name

func reset():
    current_style_value = 0
    current_value = 0
    animation_player_node.play("RESET")

func _on_button_pressed()-> void:
    current_value += 1
    if current_value > max_value:
        current_value = 0

    if not animation_player_node.is_playing() and current_style_value != current_value:
        animation_player_node.play(_get_next_ani_name(current_style_value))

    switch_sign.emit(current_value)