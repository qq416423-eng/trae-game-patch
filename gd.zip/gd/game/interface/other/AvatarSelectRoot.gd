class_name AvatarSelectRoot extends GridContainer

const AVATAR_SELECT_BUTTON_NODE = preload("res://tscn/baseModule/button/AvatarSelectButton.tscn")

var current_choose_node: AvatarSelectButton

signal choose_sign(_node)

func init_hair(_hair_uid_list: Array)-> void:
    _clear()
    for _hair_uid: String in _hair_uid_list:
        var _hair_data: Dictionary = BSHairData.hair_list.get(_hair_uid)
        if not CommonUtils.get_value(_hair_data, "visible", true):
            continue

        var _node_instance = AVATAR_SELECT_BUTTON_NODE.instantiate()
        add_child(_node_instance)
        _connect_sign(_node_instance)
        _node_instance.init_hair_by_simple_json({
            "uid": _hair_uid
        })

func init_body(_body_uid_list: Array)-> void:
    _clear()
    for _body_uid: String in _body_uid_list:
        var _node_instance = AVATAR_SELECT_BUTTON_NODE.instantiate()
        add_child(_node_instance)
        _connect_sign(_node_instance)
        _node_instance.init_body_by_simple_json({
            "uid": _body_uid
        })

func init_color(_color_list: Array)-> void:
    _clear()
    for _color: Color in _color_list:
        var _node_instance = AVATAR_SELECT_BUTTON_NODE.instantiate()
        add_child(_node_instance)
        _connect_sign(_node_instance)
        _node_instance.init_color(_color)




func random_choose()-> void:

    var _flag: = false
    while(not _flag):
        var _node = get_children().pick_random()


        if CommonUtils.is_not_null(_node):
            _flag = true
            _node.choose(false)



func choose_first()-> void:
    for _node in get_children():
        if CommonUtils.is_not_null(_node):
            _node.choose(false)
            return

func update_hair_color(_color: Color)-> void:
    for _node: AvatarSelectButton in get_children():
        _node.update_hair_color(_color)

func update_body_color(_color: Color)-> void:
    for _node: AvatarSelectButton in get_children():
        _node.update_body_color(_color)

func _clear():
    CommonUtils.clear_node(self)
    current_choose_node = null

func _connect_sign(_node: AvatarSelectButton):
    _node.connect("choose_sign", _choose)

func _choose(_node: AvatarSelectButton):
    if is_instance_valid(current_choose_node):
        current_choose_node.unchoose()

    current_choose_node = _node
    choose_sign.emit(_node)