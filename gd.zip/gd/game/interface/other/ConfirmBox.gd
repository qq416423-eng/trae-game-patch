@tool
class_name ConfirmBox extends Control


@onready var cancel_button_node =$BoxRoot / CancelButton as CommonButton2
@onready var confirm_button_node =$BoxRoot / ConfirmButton as CommonButton2
@onready var content_node: Label =$BoxRoot / Content
@onready var only_one_button_node: CommonButton2 =$BoxRoot / OnlyOneButton

@export var content: String:
    set(_value):
        content = _value
        CommonUtils.set_text($BoxRoot / Content, _value)
@export var cancel_button_text: String = "取消"
@export var confirm_button_text: String = "确定"
@export var only_one_button_text: String = "确定"
@export var show_background: bool:
    set(_value):
        show_background = _value
        if _value:
            $Background.color.a = 0.3
        else:
            $Background.color.a = 0.0
@export var only_one_button: = false

signal cancel()
signal confirm()

func _ready():
    cancel_button_node.update_text(cancel_button_text)
    confirm_button_node.update_text(confirm_button_text)
    only_one_button_node.update_text(only_one_button_text)
    if only_one_button:
        cancel_button_node.hide()
        confirm_button_node.hide()
        only_one_button_node.show()

func update_content(_content: String):
    CommonUtils.set_text(content_node, _content)

func open():
    self.show()

func close():
    self.hide()

func _on_cancel_button_pressed():
    emit_signal("cancel")
    self.close()

func _on_confirm_button_pressed():
    emit_signal("confirm")
    self.close()

func _on_only_one_button_pressed()-> void:
    self.close()