class_name FadeInAndOutText extends Control

@onready var text_node: Label =$Background / Text
@onready var background_node: TextureRect =$Background
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

@export var init_color: Color
@export var run_ani_init: = true

func _ready()-> void:
    if init_color != null:
        update_color(init_color)
    if run_ani_init:
        run_ani()
    else:
        stop_ani()

func set_text(_text)-> void:
    CommonUtils.set_text(text_node, _text)

func update_color(_color: Color)-> void:
    CommonUtils.update_self_color(background_node, _color)

func stop_ani()-> void:
    animation_player_node.stop()
    animation_player_node.seek(0, true, true)

func run_ani()-> void:
    animation_player_node.play("fade_in_and_out_02")

func cshow()-> void:
    show()

func chide()-> void:
    hide()