class_name IconValueBox extends HBoxContainer

@onready var icon_node =$Icon
@onready var value_node =$Value

@export var icon: Texture2D
@export var value: String = "Value"
@export var font_color: Color = Color.WHITE

func _ready()-> void:
    if icon != null:
        CommonUtils.update_texture3(icon_node, icon)

    CommonUtils.set_text(value_node, value)
    value_node.set("theme_override_colors/font_color", font_color)

func set_text(_value)-> void:
    CommonUtils.set_text(value_node, _value)

func update_icon(_resource: Resource)-> void:
    CommonUtils.update_texture3(icon_node, _resource)