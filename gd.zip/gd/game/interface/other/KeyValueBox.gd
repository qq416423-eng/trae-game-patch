@tool
class_name KeyValueBox extends HBoxContainer

@onready var key_node =$Key
@onready var value_node =$Value

@export var key: = "Key:":
    set(_key):
        key = _key
        CommonUtils.set_text($Key, _key)

@export var color: Color = CommonConstants.COLOR_ENUM.WHITE:
    set(_color):
        color = _color
        CommonUtils.update_color($Key, _color)
        CommonUtils.update_color($Value, _color)

func set_value(_value, _color = null):
    CommonUtils.set_text(value_node, _value, _color)