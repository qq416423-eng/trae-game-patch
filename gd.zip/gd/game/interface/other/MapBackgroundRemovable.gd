class_name MapBackgroundRemovable extends Node2D

@onready var background_root_node: Node2D =$BackgroundRoot
@onready var avatar_ani_node: AvatarAni =$AvatarAni

var move_speed: = 0.0

func _physics_process(_delta: float)-> void:
    if move_speed > 0.0:
        background_root_node.position.x -= move_speed

    if background_root_node.position.x < -600:
        background_root_node.position.x += 600

func init_avatar(_soldier_prop: BSSoldierProp)-> void:
    avatar_ani_node.init(_soldier_prop)

func _on_avatar_ani_play_animation_sign(_animation_name: Variant)-> void:
    match _animation_name:
        "idle":
            move_speed = 0.0
        "move":
            move_speed = 0.6
        "idle_horse":
            move_speed = 0.0
        "move_horse":
            move_speed = 2.0