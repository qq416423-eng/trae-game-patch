extends Control
class_name MessageBox

@onready var content_node =$BIMessageFrame / Content
@onready var success_icon_node =$BIMessageFrame / IconRoot / SuccessIcon
@onready var warn_icon_node =$BIMessageFrame / IconRoot / WarnIcon

@onready var animation_player_node =$AnimationPlayer
@onready var common_icon_node =$BIMessageFrame / IconRoot / CommonIcon
@onready var color_node =$BIMessageFrame / Color


var is_disappear: = false

signal message_disappear_begin_sign()


func init(_message_info: Dictionary):
    success_icon_node.hide()
    warn_icon_node.hide()
    common_icon_node.hide()

    CommonUtils.set_text(content_node, _message_info.content)
    match _message_info.message_type:
        MessageConstants.MESSAGE_TYPE_ENUM.SUCCESS:
            success_icon_node.show()
        MessageConstants.MESSAGE_TYPE_ENUM.WARN:
            warn_icon_node.show()
        MessageConstants.MESSAGE_TYPE_ENUM.COMMON:
            common_icon_node.show()


    var _color = _message_info.color
    CommonUtils.update_color(color_node, _color)


    animation_player_node.play("timer")

    GlobalTimeControl.connect("time_scale_update_sign", _update_speed_by_time_scale)
    _update_speed_by_time_scale(GlobalTimeControl.current_time_scale)

func _update_speed_by_time_scale(_time_scale: float)-> void:
    animation_player_node.speed_scale = 1.0 / _time_scale

func delete():
    self.queue_free()

func disappear_and_no_sign()-> void:
    if is_disappear:
        return

    is_disappear = true
    animation_player_node.play("disappear")

func _on_timer_timeout():
    disappear_and_no_sign()
    message_disappear_begin_sign.emit()