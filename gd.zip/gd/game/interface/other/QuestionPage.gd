class_name QuestionPage extends Control

const QUESTION_PAGE_OPTION_BUTTON_NODE = preload("res://tscn/baseModule/QuestionPageOptionButton.tscn")

@onready var question_node: Label =$Question
@onready var option_root_node: VBoxContainer =$OptionRoot

var current_choose_node: QuestionPageOptionButton

signal choose_sign(_node)

var test_json = {
    "question": "我出生于一个 (____) 的家庭...",
    "options": [
        {
            "name": "猎人",
        },
        {
            "name": "商人",
        },
        {
            "name": "草药师"
        },
        {
            "name": "退役士兵"
        }
    ]
}

func _ready()-> void:

    pass

func init(_json: Dictionary)-> void:
    CommonUtils.set_text(question_node, _json.question)
    for _item: Dictionary in _json.options:
        var _option_node: QuestionPageOptionButton = QUESTION_PAGE_OPTION_BUTTON_NODE.instantiate()
        option_root_node.add_child(_option_node)
        _option_node.init(
            _item.name,
            CommonUtils.get_value(_item, "value",{})
        )
        _connect_option_sign(_option_node)


func is_choose()-> bool:
    return is_instance_valid(current_choose_node)

func _connect_option_sign(_option_node: QuestionPageOptionButton)-> void:
    _option_node.connect("pressed_sign", _choose)

func _choose(_node: QuestionPageOptionButton)-> void:
    if is_instance_valid(current_choose_node):
        current_choose_node.unchoose()

    current_choose_node = _node
    choose_sign.emit(_node)