class_name QuestionPageRoot extends Control

const QUESTION_PAGE_NODE = preload("res://tscn/game/interface/other/QuestionPage.tscn")

var current_page_index: = 0
var current_page: QuestionPage

var merge_json = {}
var page_value_list = []

signal choose_option_sign()

func init(_json_list: Array)-> void:
    _clear()
    var _first_show_flat: = false
    for _json: Dictionary in _json_list:
        var question_page_instance: QuestionPage = QUESTION_PAGE_NODE.instantiate()
        add_child(question_page_instance)
        _connect_page_sign(question_page_instance)
        question_page_instance.init(_json)
        page_value_list.append({})
        if _first_show_flat:
            question_page_instance.hide()
        else:
            _first_show_flat = true
            current_page = question_page_instance

func _connect_page_sign(_node: QuestionPage)-> void:
    _node.connect("choose_sign", _choose_option)


func is_first_page()-> bool:
    return current_page_index == 0

func is_last_page()-> bool:
    return current_page_index == get_child_count() - 1


func is_choose()-> bool:
    return get_child(current_page_index).is_choose()

func get_merge_value()-> Dictionary:
    return merge_json

func next_page()-> void:
    _change_page(1)

func pre_page()-> void:
    _change_page(-1)

func _change_page(_plus_index: int)-> void:
    var new_page_count = current_page_index + _plus_index + 1
    if new_page_count > get_child_count() or new_page_count < 1:
        return

    get_child(current_page_index).hide()
    current_page_index += _plus_index
    current_page = get_child(current_page_index)
    current_page.show()

func _choose_option(_node)-> void:
    page_value_list[current_page_index] = _node.value
    _merge_json()
    choose_option_sign.emit()

func _merge_json()-> void:
    var _final_json = {}
    for _json in page_value_list:
        _final_json = SoldierUtils.merge_soldier_json(_final_json, _json)

    merge_json = _final_json

func _clear()-> void:
    CommonUtils.clear_node(self)
    current_page_index = 0
    current_page = null
    merge_json = {}
    page_value_list = []