class_name RenameBox extends ConfirmBox

@onready var save_name_edit_node: LineEdit =$BoxRoot / SaveNameEdit

signal rename_sign(_new_name: String)

func set_line_edit(_text: String)-> void:
    save_name_edit_node.text = _text

func _on_confirm_button_pressed()-> void:
    rename_sign.emit(save_name_edit_node.text)
    self.close()