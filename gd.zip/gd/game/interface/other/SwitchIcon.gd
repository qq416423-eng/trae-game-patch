class_name SwitchIcon extends Control

@onready var icon_1_node =$Icon1
@onready var icon_2_node =$Icon2
@onready var animation_player_node =$AnimationPlayer

var is_icon1: = true
var final_code: = ""
var final_texture: Texture2D = null
var animation_code: = ""

func _change_icon(_texture: Texture2D, _code: String)-> void:
    final_code = _code
    final_texture = _texture
    _change_icon_animation()

func _change_icon_animation()-> void:
    animation_code = final_code

    if is_icon1:
        CommonUtils.update_texture3(icon_2_node, final_texture)
        animation_player_node.play("change")
    else:
        CommonUtils.update_texture3(icon_1_node, final_texture)
        animation_player_node.play_backwards("change")

    is_icon1 = not is_icon1

func _check_animation():
    if final_code != animation_code:
        _change_icon_animation()