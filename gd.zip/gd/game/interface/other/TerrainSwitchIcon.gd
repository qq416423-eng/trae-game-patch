class_name TerrainSwitchIcon extends SwitchIcon

const FLATLANDS_ICON_PIC = preload("res://resource/icon/terrainAndWeather/flatlands_icon.png")
const FLATLANDS_NIGHT_ICON_PIC = preload("res://resource/icon/terrainAndWeather/flatlands_night_icon.png")
const FOREST_ICON_PIC = preload("res://resource/icon/terrainAndWeather/forest_icon.png")
const FOREST_NIGHT_ICON_PIC = preload("res://resource/icon/terrainAndWeather/forest_night_icon.png")
const SHOAL_ICON = preload("res://resource/icon/terrainAndWeather/shoal_icon.png")
const SHOAL_NIGHT_ICON = preload("res://resource/icon/terrainAndWeather/shoal_night_icon.png")
const FOREST_SHOAL_ICON = preload("res://resource/icon/terrainAndWeather/forest_shoal_icon.png")
const FOREST_SHOAL_NIGHT_ICON = preload("res://resource/icon/terrainAndWeather/forest_shoal_night_icon.png")
const DESERT_ICON = preload("res://resource/icon/terrainAndWeather/desert_icon.png")
const DESERT_NIGHT_ICON = preload("res://resource/icon/terrainAndWeather/desert_night_icon.png")

const ICON_CONFIG = {
    MWorldConstants.TERRAIN_TYPE_ENUM.FLATLANDS: {
        "day": FLATLANDS_ICON_PIC,
        "night": FLATLANDS_NIGHT_ICON_PIC
    },
    MWorldConstants.TERRAIN_TYPE_ENUM.FOREST: {
        "day": FOREST_ICON_PIC,
        "night": FOREST_NIGHT_ICON_PIC
    },
    MWorldConstants.TERRAIN_TYPE_ENUM.SHOAL: {
        "day": SHOAL_ICON,
        "night": SHOAL_NIGHT_ICON
    },
    MWorldConstants.TERRAIN_TYPE_ENUM.FOREST_SHOAL: {
        "day": FOREST_SHOAL_ICON,
        "night": FOREST_SHOAL_NIGHT_ICON
    },
    MWorldConstants.TERRAIN_TYPE_ENUM.DESERT: {
        "day": DESERT_ICON,
        "night": DESERT_NIGHT_ICON,
    },
}

var current_icon_config: Dictionary = ICON_CONFIG.get(MWorldConstants.DEFAULT_TERRAIN_TYPE)
var current_terrain_type: = MWorldConstants.DEFAULT_TERRAIN_TYPE
var current_is_day: = true

func init(_terrain_type: int, _is_day: bool)-> void:
    current_terrain_type = _terrain_type
    current_icon_config = ICON_CONFIG.get(_terrain_type)
    current_is_day = _is_day

    var _code = _get_code()
    final_code = _code
    var _texture: Texture2D = _get_texture()
    CommonUtils.update_texture3(icon_1_node, _texture)

func update_terrain_type(_terrain_type: int)-> void:
    if current_terrain_type == _terrain_type:
        return

    current_terrain_type = _terrain_type
    current_icon_config = ICON_CONFIG.get(_terrain_type)
    var _code = _get_code()
    var _texture: Texture2D = _get_texture()
    _change_icon(_texture, _code)

func update_day_or_night(_is_day: bool)-> void:
    if current_is_day == _is_day:
        return

    current_is_day = _is_day
    var _code = _get_code()
    var _texture: Texture2D = _get_texture()
    _change_icon(_texture, _code)

func _get_texture()-> Texture2D:
    if current_is_day:
        return current_icon_config.day
    else:
        return current_icon_config.night

func _get_code()-> String:
    return str(current_terrain_type) +("day" if current_is_day else "night")