class_name WeatherSwitchIcon extends SwitchIcon

const CLEAR_DAY_ICON_PIC = preload("res://resource/icon/terrainAndWeather/clear_day_icon.png")
const CLEAR_NIGHT_ICON_PIC = preload("res://resource/icon/terrainAndWeather/clear_night_icon.png")
const BIG_RAIN_DAY_PIC = preload("res://resource/icon/terrainAndWeather/big_rain_day.png")
const BIG_RAIN_NIGHT_PIC = preload("res://resource/icon/terrainAndWeather/big_rain_night.png")
const SMALL_RAIN_DAY_PIC = preload("res://resource/icon/terrainAndWeather/small_rain_day.png")
const SMALL_RAIN_NIGHT_PIC = preload("res://resource/icon/terrainAndWeather/small_rain_night.png")

const ICON_CONFIG = {
    MWorldConstants.WEATHER_TYPE_ENUM.CLEAR: {
        "day": CLEAR_DAY_ICON_PIC,
        "night": CLEAR_NIGHT_ICON_PIC
    },
    MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN: {
        "day": SMALL_RAIN_DAY_PIC,
        "night": SMALL_RAIN_NIGHT_PIC
    },
    MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN: {
        "day": BIG_RAIN_DAY_PIC,
        "night": BIG_RAIN_NIGHT_PIC
    },
}

var current_icon_config: Dictionary = ICON_CONFIG.get(MWorldConstants.DEFAULT_WEATHER_TYPE)
var current_weather_type: = MWorldConstants.DEFAULT_WEATHER_TYPE
var current_is_day: = true

func init(_weather_type: int, _is_day: bool)-> void:
    current_weather_type = _weather_type
    current_icon_config = ICON_CONFIG.get(_weather_type)
    current_is_day = _is_day

    var _code = _get_code()
    final_code = _code
    var _texture: Texture2D = _get_texture()
    CommonUtils.update_texture3(icon_1_node, _texture)

func update_weather(_weather_type: MWorldConstants.WEATHER_TYPE_ENUM)-> void:
    if current_weather_type == _weather_type:
        return

    current_weather_type = _weather_type
    current_icon_config = ICON_CONFIG.get(_weather_type)
    var _code = _get_code()
    var _texture: Texture2D = _get_texture()
    _change_icon(_texture, _code)

func update_day_or_night(_is_day: bool)-> void:
    if current_is_day == _is_day:
        return

    current_is_day = _is_day
    var _code = _get_code()
    var _texture: Texture2D = _get_texture()
    _change_icon(_texture, _code)

func _get_texture()-> Texture2D:
    if current_is_day:
        return current_icon_config.day
    else:
        return current_icon_config.night

func _get_code()-> String:
    return str(current_weather_type) +("day" if current_is_day else "night")