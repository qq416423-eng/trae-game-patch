class_name EquipmentBox extends Control

@onready var equipment_cover_node =$EquipmentCover
@onready var bi_equipment_box_node =$BIEquipmentBox
@onready var detail_show_position_node =$DetailShowPosition
@onready var quality_tag_node =$QualityTag
@onready var animation_player_node =$AnimationPlayer
@onready var option_effect_node =$BIEquipmentBox / OptionEffect
@onready var disable_effect_node =$EquipmentCover / DisableEffect
@onready var new_tag_node =$NewTag
@onready var count_node =$Count
@onready var effect_node =$Effect

@export var type: String
@export var default_icon: Texture2D
@export var field: String



var json
var item_json
var simple_json: = {}


var count: = 1

signal b_pressed(_node)

func init_by_simple_json(_simple_json: Dictionary)-> void:
    simple_json = _simple_json
    var _json = GoodsUtils.get_json_by_simple_json(_simple_json.item)
    init(_json)
    if _simple_json.count > 1:
        count = _simple_json.count
        CommonUtils.set_text(count_node, _simple_json.count)
        count_node.show()


func init(_json):
    quality_tag_node.hide()
    json = _json
    item_json = {}


    if GoodsUtils.is_null_json(_json):
        _reset()
        CommonUtils.update_texture3(equipment_cover_node, default_icon)
        return

    if _json.has("item_json"):
        item_json = _json.item_json





    CommonUtils.update_texture2(equipment_cover_node, _json.cover_path)
    if _json.quality == WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON:
        pass
    else:
        quality_tag_node.modulate = GoodsUtils.get_quality_color(_json.quality)
        quality_tag_node.show()


    if CommonUtils.get_value(item_json, "origin", GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS) == GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS:
        new_tag_node.show()
    else:
        new_tag_node.hide()


    if _json.has("star") and _json.star >= GoodsConstants.STAR_EFFECT_MIN_STAR:
        effect_node.show()
        var _color = SoldierUtils.get_star_color(_json.star)
        CommonUtils.update_self_color(effect_node, _color)
    else:
        effect_node.hide()

func _reset():
    effect_node.hide()
    new_tag_node.hide()
    quality_tag_node.hide()

func cancel():
    bi_equipment_box_node.cancel()

func get_detail_show_position():
    return detail_show_position_node.global_position

func get_item_json():
    return item_json

func show_new_tag_animation():
    animation_player_node.play("new_tag")

func show_option_effect():
    animation_player_node.play("option_effect")
    option_effect_node.show()

func close_option_effect():
    option_effect_node.hide()
    if animation_player_node.current_animation == "option_effect":
        animation_player_node.stop()

func disable():
    bi_equipment_box_node.disabled = true
    disable_effect_node.show()

func cancel_disable():
    bi_equipment_box_node.disabled = false
    disable_effect_node.hide()

func is_selected():
    return bi_equipment_box_node.is_pressed


func _on_bi_equipment_box_b_pressed():
    emit_signal("b_pressed", self)