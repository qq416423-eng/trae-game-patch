class_name EquipmentDetailInterface extends PanelContainer

@onready var equipment_cover_pic_node =$VBoxContainer / Header / EquipmentBox / EquipmentCoverPic
@onready var name_node =$VBoxContainer / Header / Name
@onready var content_node =$VBoxContainer / Content
@onready var special_content_node: Label =$VBoxContainer / SpecialContent
@onready var money_value_node =$VBoxContainer / Header / HeaderInfoRoot / MoneyRoot / Value
@onready var type_value_node =$VBoxContainer / Header / HeaderInfoRoot / TypeRoot / Value
@onready var quality_value_node =$VBoxContainer / Header / HeaderInfoRoot / QualityRoot / Value
@onready var quality_root_node =$VBoxContainer / Header / HeaderInfoRoot / QualityRoot
@onready var button_root_node =$VBoxContainer / ButtonRoot
@onready var header_node =$VBoxContainer / Header
@onready var button_root_h_box_container_node =$VBoxContainer / ButtonRoot / HBoxContainer
@onready var to_right_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / ToRightButton
@onready var equip_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / EquipButton
@onready var m_to_right_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / MToRightButton
@onready var to_right_5_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / ToRight5Button
@onready var to_left_5_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / ToLeft5Button
@onready var to_left_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / ToLeftButton
@onready var lock_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / LockButton
@onready var un_lock_button_node =$VBoxContainer / ButtonRoot / HBoxContainer / UnLockButton
@onready var star_value_node =$VBoxContainer / Header / HeaderInfoRoot / StarRoot / Value
@onready var star_root_node =$VBoxContainer / Header / HeaderInfoRoot / StarRoot
@onready var quality_root2_node =$VBoxContainer / Header / HeaderInfoRoot / QualityRoot2
@onready var quality_value2_node =$VBoxContainer / Header / HeaderInfoRoot / QualityRoot2 / Value
@onready var star_icon_node =$VBoxContainer / Header / HeaderInfoRoot / StarRoot / Icon
@onready var effect_node =$VBoxContainer / Header / EquipmentBox / Effect
@onready var remark_node: Label =$VBoxContainer / Remark
@onready var v_box_container_node: VBoxContainer =$VBoxContainer

var header_node_origin_point: Vector2
var group_enum
var json

var is_hide_equipment_detail_equip_button: = false

signal to_right(_count: int)
signal to_left(_count: int)
signal m_to_left()
signal m_to_right()
signal equip(_group_enum)
signal lock()
signal unlock()

func _ready():


    header_node_origin_point = header_node.position

func init(_json, _left_price_ratio: = 1.0):

    self.show()
    if _json.has("price_ratio"):
        _left_price_ratio = 1.0

    json = _json
    CommonUtils.update_texture2(equipment_cover_pic_node, _json.cover_path)

    if _json.quality == WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON:
        CommonUtils.set_text(name_node, _json.name)
    else:
        CommonUtils.set_text(name_node, _json.special_name)

    if GameConfig.SHOW_GOODS_CODE:
        CommonUtils.set_text(name_node, name_node.text + "(" + _json.uid + ")")

    var _content_json = GoodsUtils.get_content(_json)
    if StringUtils.is_not_empty(_content_json.content):
        content_node.show()
        CommonUtils.set_text(content_node, _content_json.content)
    else:
        content_node.hide()

    if StringUtils.is_not_empty(_content_json.special_content):
        special_content_node.show()
        CommonUtils.set_text(special_content_node, _content_json.special_content)
    else:
        special_content_node.hide()

    if StringUtils.is_not_empty(_content_json.remark):
        remark_node.show()
        CommonUtils.set_text(remark_node, _content_json.remark)
    else:
        remark_node.hide()

    CommonUtils.set_text(money_value_node, int(_json.price * _left_price_ratio))
    CommonUtils.set_text(type_value_node, _json.type_name)
    CommonUtils.set_text(quality_value_node, _json.quality_name)
    CommonUtils.set_text(quality_value2_node, _json.quality_name)

    if _json.has("star"):
        star_root_node.show()
        quality_root2_node.show()
        quality_root_node.hide()
        CommonUtils.set_text(star_value_node, _json.star)
        var _color: Color = SoldierUtils.get_star_color(_json.star)
        CommonUtils.update_self_color(star_icon_node, _color)
    else:
        star_root_node.hide()
        quality_root2_node.hide()
        quality_root_node.show()


    var _color: Color = GoodsUtils.get_quality_color(_json.quality)
    quality_root_node.modulate = _color
    quality_root2_node.modulate = _color
    name_node.modulate = _color


    if _json.has("star") and _json.star >= GoodsConstants.STAR_EFFECT_MIN_STAR:
        effect_node.show()
        var _star_color = SoldierUtils.get_star_color(_json.star)
        CommonUtils.update_self_color(effect_node, _star_color)
    else:
        effect_node.hide()


func init_button(
    _group_enum,
    _allow_sell: = true,
    _allow_equip: = true,
    _allow_lock: = true
):
    group_enum = _group_enum

    for _child in button_root_h_box_container_node.get_children():
        if _child.int_list.has(_group_enum):
            _child.show()
        else:
            _child.hide()

    if not _allow_sell:
        to_right_button_node.hide()
        m_to_right_button_node.hide()

    if not _allow_equip or is_hide_equipment_detail_equip_button:
        equip_button_node.hide()


    if to_right_button_node.visible and GoodsUtils.is_commodity(json.uid):
        to_right_5_button_node.show()

    else:
        to_right_5_button_node.hide()


    if to_left_button_node.visible and GoodsUtils.is_commodity(json.uid):
        to_left_5_button_node.show()
    else:
        to_left_5_button_node.hide()


    if not _allow_lock:
        lock_button_node.hide()
        un_lock_button_node.hide()

func ihide():

    close()

func ishow(_position = null):

    var _flag = false
    for _child in button_root_h_box_container_node.get_children():
        if _child.visible:
            _flag = true
            break

    if _flag:
        show_button_box()
    else:
        hide_button_box()





    call_deferred("_adjust_positon_and_show", _position)

func close():
    if self.visible:
        hide()

func show_button_box():
    button_root_node.show()


func hide_button_box():
    button_root_node.hide()
    header_node.position = header_node_origin_point

func update_is_hide_equipment_detail_equip_button(_is_hide: bool)-> void:
    is_hide_equipment_detail_equip_button = _is_hide

func _adjust_positon_and_show(_position):
    self.show()

    v_box_container_node.size.y = 0
    self.size.y = 0

    if _position != null:

        call_deferred("_adjust_positon", _position)

func _adjust_positon(_position: Vector2):



    if _position.y + self.size.y > get_viewport_rect().size.y:
        _position.y = get_viewport_rect().size.y - self.size.y

    self.global_position = _position


func _on_close_button_pressed():
    close()

func _on_to_right_button_custom_pressed()-> void:
    emit_signal("to_right", 1)

func _on_to_left_button_custom_pressed()-> void:
    emit_signal("to_left", 1)

func _on_m_to_left_button_custom_pressed()-> void:
    emit_signal("m_to_left")

func _on_m_to_right_button_custom_pressed()-> void:
    emit_signal("m_to_right")

func _on_equip_button_custom_pressed()-> void:
    emit_signal("equip", group_enum)

func _on_lock_button_custom_pressed()-> void:
    emit_signal("lock")

func _on_un_lock_button_custom_pressed()-> void:
    emit_signal("unlock")

func _on_to_right_5_button_custom_pressed()-> void:
    emit_signal("to_right", 5)

func _on_to_left_5_button_custom_pressed()-> void:
    emit_signal("to_left", 5)


func _on_num_input_box_confirm_sign(_int: int)-> void:
    emit_signal("to_right", _int)