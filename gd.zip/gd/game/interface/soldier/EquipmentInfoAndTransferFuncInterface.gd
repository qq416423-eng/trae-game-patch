class_name EquipmentInfoAndTransferFuncInterface extends Control

@onready var soldier_equipment_adjusted_interface: SoldierEquipmentAdjustedInterface =$SoldierEquipmentAdjustedInterface
@onready var to_right_n_button_node: CommonButton2 =$FuncArea / ToRightRoot / SplitToolRoot / ToRightNButton
@onready var func_area_node: Control =$FuncArea
@onready var solider_count_node: NumBackground =$SoldierEquipmentAdjustedInterface / SoliderCount
@onready var to_right_split_tool_node: SplitTool =$FuncArea / ToRightRoot / SplitToolRoot / ToRightSplitTool
@onready var to_left_split_tool_node: SplitTool =$FuncArea / ToLeftRoot / SplitToolRoot / ToLeftSplitTool
@onready var to_right_root_node: Control =$FuncArea / ToRightRoot
@onready var to_left_root_node: Control =$FuncArea / ToLeftRoot
@onready var to_left_n_button_node: CommonButton2 =$FuncArea / ToLeftRoot / SplitToolRoot / ToLeftNButton
@onready var to_right_1_button_node: CommonButton =$FuncArea / ToRightRoot / HBoxContainer / ToRight1Button
@onready var to_right_10_button_node: CommonButton =$FuncArea / ToRightRoot / HBoxContainer / ToRight10Button
@onready var to_right_all_button_node: CommonButton =$FuncArea / ToRightRoot / HBoxContainer / ToRightAllButton
@onready var to_left_1_button_node: CommonButton =$FuncArea / ToLeftRoot / HBoxContainer / ToLeft1Button
@onready var to_left_10_button_node: CommonButton =$FuncArea / ToLeftRoot / HBoxContainer / ToLeft10Button
@onready var to_left_all_button_node: CommonButton =$FuncArea / ToLeftRoot / HBoxContainer / ToLeftAllButton

var pre_soldier_split_group_uid: = ""
var pre_is_left: = true


var _transfer_lock: = false

signal to_right_sign(_count: int)
signal to_left_sign(_count: int)


func init(_soldier_prop: BSSoldierProp, _count: int, _is_left: = true)-> void:
    soldier_equipment_adjusted_interface.init(_soldier_prop)

    if _is_left:
        to_right_root_node.show()
        to_left_root_node.hide()
        to_right_split_tool_node.init([0, _count])



    else:
        to_right_root_node.hide()
        to_left_root_node.show()
        to_left_split_tool_node.init([0, _count])

    solider_count_node.update_num(
        _count,
        pre_soldier_split_group_uid == _soldier_prop.split_group_uid \
        and pre_is_left == _is_left
    )
    show_content()
    pre_soldier_split_group_uid = _soldier_prop.split_group_uid
    pre_is_left = _is_left

func cancel_choose_equipment()-> void:
    soldier_equipment_adjusted_interface.cancel_choose_equipment()

func hide_content()-> void:
    soldier_equipment_adjusted_interface.hide()
    func_area_node.hide()

func show_content()-> void:
    if soldier_equipment_adjusted_interface.visible:
        return

    soldier_equipment_adjusted_interface.show()
    func_area_node.show()

func clear()-> void:
    pre_soldier_split_group_uid = ""
    pre_is_left = true






func _on_to_right_1_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    to_right_sign.emit(1)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_right_10_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    to_right_sign.emit(10)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_right_all_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    to_right_sign.emit(10000)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_right_n_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    var _count: = to_right_split_tool_node.get_count()
    if _count > 0:
        to_right_sign.emit(_count)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_left_1_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    to_left_sign.emit(1)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_left_10_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    to_left_sign.emit(10)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_left_all_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    to_left_sign.emit(10000)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_left_n_button_custom_pressed()-> void:
    if _transfer_lock:
        return
    _transfer_lock = true
    GlobalLoadPage.load_open()
    var _count: = to_left_split_tool_node.get_count()
    if _count > 0:
        to_left_sign.emit(_count)
    GlobalLoadPage.load_close()
    await get_tree().process_frame
    _transfer_lock = false

func _on_to_right_split_tool_first_num_change_sign(_num: int)-> void:
    to_right_n_button_node.update_text("安置 " + str(_num) + " 个士兵")
    if _num > 0:
        to_right_n_button_node.disabled = false
    else:
        to_right_n_button_node.disabled = true

func _on_to_left_split_tool_first_num_change_sign(_num: int)-> void:
    to_left_n_button_node.update_text("取出 " + str(_num) + " 个士兵")
    if _num > 0:
        to_left_n_button_node.disabled = false
    else:
        to_left_n_button_node.disabled = true