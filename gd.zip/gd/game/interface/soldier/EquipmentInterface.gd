class_name EquipmentInterface extends Node2D

@onready var eb_helmet_node =$EBHelmet as EquipmentBox
@onready var eb_shoulder_node =$EBShoulder as EquipmentBox
@onready var eb_armour_node =$EBArmour as EquipmentBox
@onready var eb_shoes_node =$EBShoes as EquipmentBox
@onready var eb_horse_node =$EBHorse as EquipmentBox
@onready var eb_weapon_1_node =$EBWeapon1 as EquipmentBox
@onready var eb_weapon_2_node =$EBWeapon2 as EquipmentBox
@onready var eb_weapon_3_node =$EBWeapon3 as EquipmentBox
@onready var eb_harmour_node =$EBHarmour

var select_node = null

var field_node_dic = {}

signal bchoose(_node)

func _ready():
    for _child in self.get_children():
        _child.connect("b_pressed", choose)
        field_node_dic[_child.field] = _child

func init(_soldier_prop: BSSoldierProp):
    eb_helmet_node.init(_soldier_prop.helmet_json)
    eb_shoulder_node.init(_soldier_prop.shoulder_json)
    eb_armour_node.init(_soldier_prop.armour_json)
    eb_shoes_node.init(_soldier_prop.shoe_json)
    eb_horse_node.init(_soldier_prop.horse_json)
    eb_weapon_1_node.init(_soldier_prop.weapon1_json)
    eb_weapon_2_node.init(_soldier_prop.weapon2_json)
    eb_weapon_3_node.init(_soldier_prop.weapon3_json)
    eb_harmour_node.init(_soldier_prop.harmour_json)


func cancel_choose():

    if CommonUtils.is_not_null(select_node):
        select_node.cancel()
        select_node = null

func choose(_node):



    if select_node != null and select_node != _node:
        select_node.cancel()

    select_node = _node
    emit_signal("bchoose", _node)



func update_equip(_field, _equip_json):



    var _old_item_json = field_node_dic[_field].get_item_json()
    var _equipment_detail_json = GoodsUtils.get_json_by_simple_json(_equip_json)
    field_node_dic[_field].init(_equipment_detail_json)

    field_node_dic[_field].show_new_tag_animation()

    return _old_item_json


func show_allow_exchange_area_weapon():
    for _child in self.get_children():
        if _child.type == WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON:
            _child.show_option_effect()
        else:
            _child.disable()

func cancel_show_allow_exchange_area_weapon():
    for _child in self.get_children():
        if _child.type == WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON:
            _child.close_option_effect()
        else:
            _child.cancel_disable()

func clear()-> void:
    cancel_choose()