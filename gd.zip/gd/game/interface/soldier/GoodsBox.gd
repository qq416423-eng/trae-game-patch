class_name GoodsBox extends Control

@onready var cover_node =$CoverRoot / Cover
@onready var name_node =$InfoRoot / Name
@onready var money_value_node =$InfoRoot / MoneyRoot / Value
@onready var count_value_node =$InfoRoot / CountRoot / Value
@onready var button_node =$Button
@onready var quality_tag_node =$CoverRoot / QualityTag
@onready var detail_show_position_node =$DetailShowPosition
@onready var new_tag_node =$CoverRoot / NewTag
@onready var animation_player_node =$AnimationPlayer
@onready var lock_icon_node =$LockIcon
@onready var exchange_button_node =$ExchangeButton


@onready var effect_node: TextureRect =$Effect4

@onready var select_effect_node: NinePatchRect =$SelectEffect

@export var is_right: = false

var goods_json = {}

var item_json = {}

var ritem_json = {}
var count = 0

var is_lock: = false

var allow_sell: = true

var allow_equip: = true

var is_new: = false
var city_location_type_enum = ""

signal b_pressed(_node)
signal exchange(_node)

func init(_ritem_json: Dictionary)-> void:
    ritem_json = _ritem_json
    item_json = _ritem_json.item
    goods_json = GoodsUtils.get_json_by_simple_json(_ritem_json.item, null)

    count = _ritem_json.count
    CommonUtils.update_texture2(cover_node, goods_json.cover_path)
    CommonUtils.set_text(name_node, goods_json.name)
    if GameConfig.SHOW_GOODS_CODE:
        CommonUtils.set_text(name_node, goods_json.name + " " + _ritem_json.item.uid)

    CommonUtils.set_text(money_value_node, goods_json.price)
    CommonUtils.set_text(count_value_node, count)


    if goods_json.quality == WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON:
        quality_tag_node.hide()
    else:
        quality_tag_node.modulate = GoodsUtils.get_quality_color(goods_json.quality)
        quality_tag_node.show()


    if not item_json.has("origin"):
        item_json.origin = GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS

    var _is_new = false

    if is_right and item_json.origin == GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS:
        new_tag_node.show()
        is_new = true
    elif not is_right and item_json.origin == GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS:
        new_tag_node.show()
        is_new = true
    else:
        is_new = false
        new_tag_node.hide()





    if item_json.has("lock") and item_json.lock:
        is_lock = true
        _lock_effect()

    var _etype = WeaponTypeConstants.get_etype(item_json.uid)
    if WeaponTypeConstants.FORBID_EQUIP_ETYPE_LIST.has(_etype):
        allow_equip = false
    else:
        allow_equip = true


    if GameConfig.ALL_GOODS_SHOW_STAR_FLAG or(goods_json.has("star") and goods_json.star >= GoodsConstants.STAR_EFFECT_MIN_STAR):
        effect_node.show()
        var _star_color = GoodsUtils.get_quality_color(goods_json.star)
        CommonUtils.update_self_color(effect_node, _star_color)



    else:
        effect_node.hide()


    city_location_type_enum = LocationConstants.get_city_location_type_enum(goods_json.etype)

func lock():
    item_json.lock = true
    is_lock = true
    _lock_effect()

func unlock():
    item_json.lock = false
    is_lock = false
    _unlock_effect()

func show_new_tag_animation():
    animation_player_node.play("new_tag")
















func cancel():
    button_node.cancel()
    select_effect_node.hide()

func choose():
    button_node.pressed()


func get_detail_show_position():
    return detail_show_position_node.global_position

func plus_count(_plus_count):
    count += _plus_count
    CommonUtils.set_text(count_value_node, count)

func get_item_json():
    return item_json

func refresh_commodity_price(_commodity_price_ratio: float):
    item_json.commodity_price_ratio = _commodity_price_ratio
    goods_json = GoodsUtils.get_json_by_simple_json(item_json, null)
    CommonUtils.set_text(money_value_node, goods_json.price)

func set_allow_sell(_allow_sell):
    allow_sell = _allow_sell
    if allow_sell:
        pass
    else:
        exchange_button_node.hide()


func get_city_location_type_enum()-> String:
    return city_location_type_enum

func _lock_effect():
    exchange_button_node.hide()
    lock_icon_node.show()

func _unlock_effect():
    lock_icon_node.hide()
    if allow_sell:
        exchange_button_node.show()

func _on_button_b_pressed():
    select_effect_node.show()
    emit_signal("b_pressed", self)


func _on_exchange_button_custom_pressed()-> void:
    emit_signal("exchange", self)