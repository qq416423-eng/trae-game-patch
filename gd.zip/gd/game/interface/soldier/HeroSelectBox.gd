extends Control

@onready var name_node =$Name
@onready var button_node =$Button
@onready var hero_portrait_node: HeroPortrait =$HeroPortrait
@onready var busy_icon_node: TextureRect =$BusyIcon

var item_json

signal b_pressed(_node)


func init(_item_json: Dictionary, _use_select_effect = null)-> void:
    item_json = _item_json
    var _soldier_json = SoldierUtils.get_json2(_item_json)
    CommonUtils.set_text(name_node, _soldier_json.name)

    button_node.set_use_select_effect(_use_select_effect)
    hero_portrait_node.init(_item_json.uid)

    if SoldierUtils.hero_is_busy(item_json.uid):
        button_node.disabled = true
        busy_icon_node.show()
        CommonUtils.set_text(name_node, _soldier_json.name + " (忙碌)")

func unchoose()-> void:
    button_node.cancel()


func choose()-> void:
    button_node.show_select_effect()

func is_equal_by_hero_uid(_hero_uid)-> bool:
    if StringUtils.equals(_hero_uid, item_json.uid):
        return true

    return false


func choose_and_sign(_is_open_sound: bool = true)-> void:
    button_node.pressed(_is_open_sound)

func get_uid()-> String:
    return item_json.uid

func _on_button_b_pressed()-> void:
    emit_signal("b_pressed", self)