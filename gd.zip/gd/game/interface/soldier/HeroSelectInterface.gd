class_name HeroSelectInterface extends Control

const HERO_LIST_VISIBLE_COUNT = 6

@onready var hero_select_box_node =$HeroSelectBox
@onready var v_box_container_node =$VBoxContainer
@onready var hero_select_box_node_origin = preload("res://tscn/game/interface/soldier/HeroSelectBox.tscn")
@onready var down_icon_node: TextureRect =$DownIcon

var select_node
var select_hero_uid: String = ""

var hero_list_scroll_node: ScrollContainer = null
var hero_list_scroll_enabled: = false

signal choose(_item_json)

func init(
    _hero_json_list: Array,
    _select_pre_hero: bool = false
):
    clear()

    var _select_simple_json: Dictionary = _hero_json_list[0]
    var _is_first: = true
    for _item_json: Dictionary in _hero_json_list:
        var hero_select_box_instance = hero_select_box_node_origin.instantiate()
        v_box_container_node.add_child(hero_select_box_instance)
        hero_select_box_instance.init(_item_json, true)
        hero_select_box_instance.connect("b_pressed", _choose)
        if(not _select_pre_hero or StringUtils.is_empty(select_hero_uid)) and _is_first:

            select_node = hero_select_box_instance
            select_hero_uid = hero_select_box_instance.get_uid()
            _select_simple_json = _item_json

            hero_select_box_instance.choose_and_sign(false)
            _is_first = false

        if _select_pre_hero and StringUtils.is_not_empty(select_hero_uid):
            if _item_json.uid == select_hero_uid:
                select_node = hero_select_box_instance
                select_hero_uid = hero_select_box_instance.get_uid()
                _select_simple_json = _item_json
                hero_select_box_instance.choose_and_sign(false)


    hero_select_box_node.init(_select_simple_json)

func clear():
    select_node = null
    CommonUtils.clear_node(v_box_container_node)
    CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/down_icon_16.png")

func enable_hero_list_scroll()-> void:
    hero_list_scroll_enabled = true

func _build_hero_list_scroll()-> void:
    if not hero_list_scroll_enabled or hero_list_scroll_node != null:
        return

    var _origin_index: int = v_box_container_node.get_index()
    var _list_width: float = v_box_container_node.size.x

    hero_list_scroll_node = ScrollContainer.new()
    hero_list_scroll_node.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    hero_list_scroll_node.position = v_box_container_node.position
    hero_list_scroll_node.size = Vector2(_list_width, _get_hero_list_show_height())
    hero_list_scroll_node.visible = false
    add_child(hero_list_scroll_node)
    move_child(hero_list_scroll_node, _origin_index)

    var _origin_parent: Node = v_box_container_node.get_parent()
    if _origin_parent != null:
        _origin_parent.remove_child(v_box_container_node)

    hero_list_scroll_node.add_child(v_box_container_node)
    v_box_container_node.position = Vector2.ZERO
    v_box_container_node.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    v_box_container_node.custom_minimum_size.x = _list_width

func _update_hero_list_scroll_size()-> void:
    if hero_list_scroll_node == null:
        return

    hero_list_scroll_node.size = Vector2(
        hero_list_scroll_node.size.x,
        _get_hero_list_show_height()
    )

func _get_hero_list_show_height()-> float:
    var _item_height: float = _get_hero_item_height()
    if _item_height <= 0.0:
        return 0.0

    var _show_count: int = min(v_box_container_node.get_child_count(), HERO_LIST_VISIBLE_COUNT)
    var _separation: int = 0
    if v_box_container_node is BoxContainer:
        _separation = v_box_container_node.get_theme_constant("separation")

    return _item_height * _show_count + _separation * (_show_count - 1)

func _get_hero_item_height()-> float:
    var _height: float = 0.0
    for _child in v_box_container_node.get_children():
        if _child is Control:
            _height = max(_height, _child.get_combined_minimum_size().y)
            _height = max(_height, _child.size.y)

    if _height <= 0.0:
        _height = hero_select_box_node.get_combined_minimum_size().y

    return _height

func _is_hero_list_show()-> bool:
    if hero_list_scroll_node != null:
        return hero_list_scroll_node.visible

    return v_box_container_node.visible

func _show_hero_list(_show: bool)-> void:
    if hero_list_scroll_node != null:
        hero_list_scroll_node.visible = _show

    v_box_container_node.visible = _show

func choose_by_hero_uid(_hero_uid: String, _is_open_sound: bool = true):
    for _node in v_box_container_node.get_children():
        if _node.visible and _node.is_equal_by_hero_uid(_hero_uid):
            _node.choose_and_sign(_is_open_sound)
            return

func get_current_simple_json():
    return select_node.item_json

func hide_select_area()-> void:
    _show_hero_list(false)

func _choose(_node):
    if select_node != null and select_node != _node:
        select_node.unchoose()

    if select_node == _node:
        pass
    else:
        select_node = _node
        select_hero_uid = _node.get_uid()
        hero_select_box_node.init(_node.item_json)


    _show_hero_list(false)
    CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/down_icon_16.png")

    emit_signal("choose", _node.item_json)


func _on_hero_select_box_b_pressed(_node:):
    if _is_hero_list_show():
        _show_hero_list(false)
        CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/down_icon_16.png")
    else:
        _build_hero_list_scroll()
        _update_hero_list_scroll_size()
        _show_hero_list(true)
        CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/up_icon_16.png")