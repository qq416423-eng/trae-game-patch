class_name HeroUpgradeInterface extends Control

@onready var avatar_ani_node =$ContentRoot / HeroRoot / AvatarAni as AvatarAni
@onready var hero_name_node =$ContentRoot / HeroRoot / HeroName
@onready var remin_point_box_node =$ContentRoot / HeroRoot / ReminPointBox as NumBackground
@onready var prop_root_node =$ContentRoot / PropRoot
@onready var hero_remark_node =$ContentRoot / HeroRoot / HeroRemark
@onready var level_bar_node =$ContentRoot / HeroRoot / LevelBar as LevelBar
@onready var intelligence_card_node: PropCard =$ContentRoot / PropRoot / IntelligenceCard

var soldier_prop: BSSoldierProp

var attr_point = 0
var is_card_forbid = false

signal save_success_sign()
signal close_sign()











func _ready():
    for _node in prop_root_node.get_children():
        _node.connect("plus_sign", _plus_prop)

    intelligence_card_node.update_remark(
        "加快角色学习军事技能的速度, 每" + str(SkillConfig.INTELLIGENCE_PER_SKILL_POINT)
        + "点智力可以提升1级智力型军事技能, 上限为"
        + str(SkillConfig.INTELLIGENCE_SKILL_LEVEL_MAX) + "级"
    )

func init(_simple_json):
    var _soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)
    soldier_prop = _soldier_prop
    avatar_ani_node.init(_soldier_prop)
    CommonUtils.set_text(hero_name_node, _soldier_prop.name)

    var _attr_point = _soldier_prop.attr_point
    attr_point = _attr_point
    remin_point_box_node.update_num(_attr_point)

    _init_card()
    _update_type_style(CommonUtils.get_value(_simple_json, "is_player", false))
    level_bar_node.init_by_hero_uid(_simple_json.uid)

func get_uid():
    return soldier_prop.uid

func _init_card():
    for _node: PropCard in prop_root_node.get_children():
        _node.init(soldier_prop.get(_node.get_prop_field()))

    if attr_point <= 0:
        _all_card_forbid()
    else:
        _all_card_active()

func _update_type_style(_is_player):
    if _is_player:
        hero_remark_node.hide()

    else:
        hero_remark_node.show()


func _all_card_button_show_or_hide(_is_show):
    for _node: PropCard in prop_root_node.get_children():
        if _is_show:
            _node.button_show()
        else:
            _node.button_hide()

func _all_card_forbid():
    if is_card_forbid:
        return

    for _node: PropCard in prop_root_node.get_children():
        _node.plus_forbid()

    is_card_forbid = true

func _all_card_active():
    if not is_card_forbid:
        return

    for _node in prop_root_node.get_children():
        _node.plus_active()

    is_card_forbid = false


func _plus_prop(_count: int, _node: PropCard)-> void:
    if _count > attr_point:
        _count = attr_point

    attr_point -= _count
    _node.plus(_count)

    remin_point_box_node.update_num(attr_point, true)

    if attr_point <= 0:
        _all_card_forbid()
    else:
        _all_card_active()

func _clear():
    pass

func _save_and_reload():
    _save()
    _reload()

func _save():
    var _dif_value_json: = {}
    for _node in prop_root_node.get_children():
        _dif_value_json[_node.get_prop_field()] = _node.get_dif_value()

    var _hero_json = soldier_prop.json

    _hero_json["attr_point"] = attr_point

    for _key in _dif_value_json.keys():
        _hero_json[_key] += _dif_value_json.get(_key)

func _reload():
    self.init(soldier_prop.simple_json)

func _on_close_button_pressed():
    _clear()
    self.hide()
    close_sign.emit()


func _on_save_button_pressed():
    _save_and_reload()
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_SUCCESS)
    save_success_sign.emit()


func _on_restore_button_pressed():
    _reload()
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.REVOCATION_SUCCESS)