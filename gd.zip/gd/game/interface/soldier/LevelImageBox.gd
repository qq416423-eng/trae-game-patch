@tool
class_name LevelImageBox extends Control

@onready var tag_str_node =$LevelImageContainer / TagStr
@onready var level_image_container_node =$LevelImageContainer
@onready var icon_node =$LevelImageContainer / Icon
@onready var remark_node =$Remark

const LEVEL_1_ICON_NODE = preload("res://tscn/baseModule/Level1Icon.tscn")
const LEVEL_5_ICON_NODE = preload("res://tscn/baseModule/Level5Icon.tscn")
const LEVEL_0_ICON_NODE = preload("res://tscn/baseModule/Level0Icon.tscn")
const PLACEHOLDER_NUM: = 2

@export var icon: Texture2D:
    set(_icon):
        icon = _icon
        CommonUtils.update_texture3($LevelImageContainer / Icon, icon)

@export var show_icon: = false:
    set(_show_icon):
        show_icon = _show_icon
        if show_icon:
            $LevelImageContainer / Icon.show()
        else:
            $LevelImageContainer / Icon.hide()

@export var show_title: = false
@export var title: = "":
    set(_title):
        title = _title
        CommonUtils.set_text($LevelImageContainer / TagStr, _title)
@export var alignment: = BoxContainer.AlignmentMode.ALIGNMENT_CENTER:
    set(_alignment):
        alignment = _alignment
        $LevelImageContainer.alignment = _alignment
@export var font_color: Color = Color(1, 1, 1, 1):
    set(_color):
        font_color = _color
        CommonUtils.update_self_color($LevelImageContainer / TagStr, _color)
        CommonUtils.update_self_color($Remark, _color)

@export var is_need_complement: = false

@export var max_level: = 0
@export var show_remark: = false
@export var remark_box_position_x: = 0




func _ready():
    if show_title:
        tag_str_node.show()
    else:
        tag_str_node.hide()

    if show_remark:
        remark_node.show()
        remark_node.position.x = remark_box_position_x - 280
    else:
        remark_node.hide()

func init(_level: int, _title: String)-> void:
    CommonUtils.set_text(tag_str_node, _title)
    update_level(_level)

func update_level(_level):
    _clear()

    _level = int(_level)

    var _str = "LV " + str(_level)
    update_remark(_str)

    var _origin_level = _level

    if max_level > 0:
        _level = min(max_level, _level)

    if _level == 0:
        var _node = LEVEL_0_ICON_NODE.instantiate()
        level_image_container_node.add_child(_node)
        return

    while(_level > 0):

        if _level >= 5 and not is_need_complement:
            _level -= 5
            var _node = LEVEL_5_ICON_NODE.instantiate()
            level_image_container_node.add_child(_node)
        else:
            _level -= 1
            var _node = LEVEL_1_ICON_NODE.instantiate()
            level_image_container_node.add_child(_node)

    if is_need_complement and max_level > 0 and _origin_level < max_level:

        for _index in range(max_level - _origin_level):
            var _node = LEVEL_0_ICON_NODE.instantiate()
            level_image_container_node.add_child(_node)

func update_remark(_remark: String)-> void:
    CommonUtils.set_text(remark_node, _remark)

func _clear():
    if level_image_container_node.get_children().size() <= PLACEHOLDER_NUM:
        return

    for _index in range(level_image_container_node.get_children().size() - PLACEHOLDER_NUM):
        CommonUtils.delete_node(level_image_container_node.get_children()[_index + PLACEHOLDER_NUM])