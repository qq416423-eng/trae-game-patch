class_name PrisonerBox extends Control

@onready var avatar_wb_node: AvatarWB =$AvatarWB
@onready var name_node: Label =$Name
@onready var star_box_value_node: Label =$InfoBox / StarBox / Value
@onready var star_icon_node: TextureRect =$InfoBox / StarBox / StarIcon
@onready var count_node: Label =$Button / SoldierCountBackground / Count
@onready var surrender_recruitment_count_box_node: FadeInAndOutText =$Button / SoldierCountBackground / SurrenderRecruitmentCountBox
@onready var drawer_root_node: TextureRect =$DrawerRoot
@onready var prisoner_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / PrisonerButton
@onready var prisoner_all_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / PrisonerAllButton
@onready var delete_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / DeleteButton
@onready var delete_all_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / DeleteAllButton
@onready var sell_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / SellButton
@onready var sell_all_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / SellAllButton
@onready var money_box_node: Node2D =$InfoBox / MoneyBox
@onready var money_value_node: Label =$InfoBox / MoneyBox / Value
@onready var surrender_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / SurrenderButton
@onready var surrender_all_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / SurrenderAllButton
@onready var func_button_root_node: HBoxContainer =$DrawerRoot / FuncButtonRoot

var _is_choose: = false
var simple_json_list: = []

var surrender_recruitment_count: = 0
var soldier_prop: BSSoldierProp
var money: = 0
var button_put_out_position_x: = 10

enum BUTTON_GROUP_TYPE_ENUM {

    BATTLE_END,

    TEAM_MANAGE,

    SELL_PRISONER
}

signal choose_sign(_node: PrisonerBox)
signal empty_sign()
signal surrender_action_sign()
signal sell_action_sign()


func init(_simple_json_list: Array)-> void:
    simple_json_list = _simple_json_list

    surrender_recruitment_count = 0


    for _simple_json: Dictionary in simple_json_list:
        if _simple_json.has("is_surrend") and _simple_json.is_surrend:
            surrender_recruitment_count += 1


    simple_json_list.sort_custom(SortUtils.sort_by_is_surrend_desc)

    soldier_prop = SoldierUtils.get_bs_soldier_prop(simple_json_list[0])
    avatar_wb_node.init(soldier_prop)
    CommonUtils.set_text(name_node, soldier_prop.name)

    if surrender_recruitment_count > 0:
        surrender_recruitment_count_box_node.cshow()
    else:
        surrender_recruitment_count_box_node.chide()

    _update_star_info(soldier_prop.star)
    drawer_root_node.position.x = 320

    _refresh_button_style()


func update_button_group_type(
    _button_group_type_enum: BUTTON_GROUP_TYPE_ENUM,
    is_special_slave_trader_price: = false
)-> void:
    surrender_button_node.hide()
    surrender_all_button_node.hide()
    delete_button_node.hide()
    delete_all_button_node.hide()
    prisoner_button_node.hide()
    prisoner_all_button_node.hide()
    sell_button_node.hide()
    sell_all_button_node.hide()

    match _button_group_type_enum:
        BUTTON_GROUP_TYPE_ENUM.BATTLE_END:
            prisoner_button_node.show()
            prisoner_all_button_node.show()


        BUTTON_GROUP_TYPE_ENUM.TEAM_MANAGE:
            delete_button_node.show()
            delete_all_button_node.show()
            surrender_button_node.show()
            surrender_all_button_node.show()
        BUTTON_GROUP_TYPE_ENUM.SELL_PRISONER:
            sell_button_node.show()
            sell_all_button_node.show()

            money_box_node.show()

            money = SoldierUtils.get_prisoner_price(
                soldier_prop.star,
                WSData.get_player_team_info().skill_trade,
                is_special_slave_trader_price
            )
            CommonUtils.set_text(money_value_node, money)


    _refresh_button_put_out_position_x()

func _refresh_button_put_out_position_x()-> void:
    var _visible_button_count: int = 0
    for _button_node in func_button_root_node.get_children():
        if _button_node.visible:
            _visible_button_count += 1

    button_put_out_position_x = 320 - 32 - _visible_button_count * 72

func hide_func_button()-> void:
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(drawer_root_node, "position:x", 320, 0.2)
    _is_choose = false


func capture_all():
    if ArrayUtils.is_empty(simple_json_list):
        return

    WSData.capture_enemy(simple_json_list)
    simple_json_list = []

    if surrender_recruitment_count > simple_json_list.size():
        surrender_recruitment_count = simple_json_list.size()


    _refresh_button_style()

func get_count():
    return simple_json_list.size()

func sell_all()-> void:
    if ArrayUtils.is_empty(simple_json_list):
        return

    for _simple_json: Dictionary in simple_json_list:
        _simple_json.sell_money = money

    simple_json_list = []

    if surrender_recruitment_count > simple_json_list.size():
        surrender_recruitment_count = simple_json_list.size()

    _refresh_button_style()

func is_hero()-> bool:
    return false

func get_uid()-> String:
    return soldier_prop.uid

func _update_star_info(_star: int)-> void:
    var _color: Color = SoldierUtils.get_star_color(_star)
    CommonUtils.set_text(star_box_value_node, _star)
    CommonUtils.update_self_color(star_icon_node, _color)

func _show_func_button()-> void:
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)

    _tween.tween_property(drawer_root_node, "position:x", button_put_out_position_x, 0.2).set_trans(Tween.TRANS_SINE)

func _refresh_button_style()-> void:
    CommonUtils.set_text(count_node, simple_json_list.size())
    surrender_recruitment_count_box_node.set_text(surrender_recruitment_count)

    if simple_json_list.size() == 0:
        prisoner_button_node.disable()
        prisoner_all_button_node.disable()
        surrender_button_node.disable()
        surrender_all_button_node.disable()

        _hide_ani()
        empty_sign.emit()

    if surrender_recruitment_count <= 0:
        surrender_button_node.disable()
        surrender_all_button_node.disable()
        surrender_recruitment_count_box_node.chide()

func _hide_ani():
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(self, "modulate:a", 0.0, 0.2)
    _tween.tween_property(self, "custom_minimum_size:y", 0.0, 0.2)
    _tween.connect("finished", _chide)

func _chide():
    self.hide()

func delete()-> void:
    if ArrayUtils.is_empty(simple_json_list):
        return

    for _simple_json: Dictionary in simple_json_list:
        _simple_json.is_deleted = true

    simple_json_list = []

    if surrender_recruitment_count > simple_json_list.size():
        surrender_recruitment_count = simple_json_list.size()

    _refresh_button_style()

func _on_button_pressed()-> void:
    if _is_choose:
        return


    _show_func_button()
    choose_sign.emit(self)
    _is_choose = true


func _on_prisoner_button_pressed()-> void:
    if ArrayUtils.is_empty(simple_json_list):
        return

    WSData.capture_enemy([simple_json_list.pop_front()])

    if surrender_recruitment_count > simple_json_list.size():
        surrender_recruitment_count = simple_json_list.size()


    _refresh_button_style()

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURE_MESSAGE,
        ["1个" + soldier_prop.name]
    )


func _on_prisoner_all_button_pressed()-> void:

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURE_MESSAGE,
        [str(simple_json_list.size()) + "个" + soldier_prop.name]
    )

    capture_all()


func _surrender(_count: int)-> void:
    if surrender_recruitment_count <= 0 and simple_json_list.size() == 0:
        return

    var _sub_count = _count if _count <= surrender_recruitment_count else surrender_recruitment_count


    var _remaining_troop_capacity_nop: int = WSData.get_player_remaining_troop_capacity_nop()
    if _remaining_troop_capacity_nop <= 0:
        GlobalMessageInterface.add_message_exceeded_troop_limit()
        return

    var _need_send_exceeded_troop_limit_message: = false
    if _remaining_troop_capacity_nop < _sub_count:
        _sub_count = _remaining_troop_capacity_nop
        _need_send_exceeded_troop_limit_message = true


    surrender_recruitment_count -= _sub_count

    var _surrender_simple_json_list: = []
    for _index in range(_sub_count):
        var _simple_json: Dictionary = simple_json_list.pop_front()
        _simple_json.is_deleted = true
        _surrender_simple_json_list.append(_simple_json)

        if ArrayUtils.is_empty(simple_json_list):
            break

    WSData.surrender_enemy(_surrender_simple_json_list)
    _refresh_button_style()

    surrender_action_sign.emit()

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.SURRENDER_MESSAGE,
        [str(_surrender_simple_json_list.size()) + "个" + soldier_prop.name]
    )


    if _need_send_exceeded_troop_limit_message:
        GlobalMessageInterface.add_message_exceeded_troop_limit()


func _on_surrender_button_pressed()-> void:
    _surrender(1)


















func _on_surrender_all_button_pressed()-> void:
    _surrender(10000)


func _on_delete_button_pressed()-> void:
    if ArrayUtils.is_empty(simple_json_list):
        return

    var _simple_json: Dictionary = simple_json_list.pop_front()
    _simple_json.is_deleted = true

    if surrender_recruitment_count > simple_json_list.size():
        surrender_recruitment_count = simple_json_list.size()

    _refresh_button_style()


func _on_delete_all_button_pressed()-> void:
    delete()


func _on_sell_button_pressed()-> void:
    if ArrayUtils.is_empty(simple_json_list):
        return

    var _simple_json: Dictionary = simple_json_list.pop_front()
    _simple_json.sell_money = money

    if surrender_recruitment_count > simple_json_list.size():
        surrender_recruitment_count = simple_json_list.size()

    _refresh_button_style()
    sell_action_sign.emit()


func _on_sell_all_button_pressed()-> void:
    sell_all()
    sell_action_sign.emit()