class_name PrisonerBoxHero extends PrisonerBox

@onready var name_hero_node: Label =$NameHero
@onready var talk_button_node: CommonButton =$DrawerRoot / FuncButtonRoot / TalkButton

signal talk_to_prisoner_hero_sign(_hero_uid: String)

func init(_simple_json_list: Array)-> void:
    simple_json_list = _simple_json_list

    surrender_recruitment_count = 0


    for _simple_json: Dictionary in simple_json_list:
        if _simple_json.has("is_surrend") and _simple_json.is_surrend:
            surrender_recruitment_count += 1


    simple_json_list.sort_custom(SortUtils.sort_by_is_surrend_desc)

    soldier_prop = SoldierUtils.get_bs_soldier_prop(simple_json_list[0])
    avatar_wb_node.init(soldier_prop)

    CommonUtils.set_text(name_hero_node, soldier_prop.name)


    if SoldierUtils.is_king_by_hero_uid(soldier_prop.uid):
        CommonUtils.update_self_color(name_hero_node, Color("#ffeb99"))

    if surrender_recruitment_count > 0:
        surrender_recruitment_count_box_node.cshow()
    else:
        surrender_recruitment_count_box_node.chide()

    _update_star_info(soldier_prop.star)
    drawer_root_node.position.x = 320




func update_button_group_type(
    _button_group_type_enum: BUTTON_GROUP_TYPE_ENUM,
    is_special_slave_trader_price: = false
)-> void:
    talk_button_node.show()


    _refresh_button_put_out_position_x()


func capture_all()-> void:
    pass

func is_hero()-> bool:
    return true


func sell_all()-> void:
    pass

func _on_sell_button_pressed()-> void:
    pass

func _on_sell_all_button_pressed()-> void:
    pass

func _on_delete_button_pressed()-> void:
    pass

func _on_delete_all_button_pressed()-> void:
    pass

func _on_prisoner_button_pressed()-> void:
    pass

func _on_prisoner_all_button_pressed()-> void:
    pass

func _on_surrender_button_pressed()-> void:
    pass

func _on_surrender_all_button_pressed()-> void:
    pass

func _on_talk_button_custom_pressed()-> void:
    talk_to_prisoner_hero_sign.emit(get_uid())