class_name PrisonerListInterface extends Control

@onready var v_box_container_node: VBoxContainer =$BaseScrollContainer / VBoxContainer
@onready var no_data_tip_node: Label =$NoDataTip
@onready var title_node: Label =$Background / TitleBackgroundPic / Title

const PRISONER_BOX = preload("res://tscn/game/interface/soldier/PrisonerBox.tscn")
const PRISONER_BOX_HERO = preload("res://tscn/game/interface/soldier/PrisonerBoxHero.tscn")

@export var title: = "本场战斗俘虏"

@export var need_init_surrender: = true
@export var button_group_type: PrisonerBox.BUTTON_GROUP_TYPE_ENUM = PrisonerBox.BUTTON_GROUP_TYPE_ENUM.BATTLE_END
@export var show_hero: bool = true

var choose_node: PrisonerBox


signal empty_sign()
signal surrender_action_sign()
signal sell_action_sign()
signal only_contain_hero_or_empty_sign()
signal talk_to_prisoner_hero_sign(_hero_uid: String)

func _ready()-> void:
    CommonUtils.set_text(title_node, title)




































func init(_simple_json_list: Array, is_special_slave_trader_price: = false)-> void:
    clear()

    if ArrayUtils.is_empty(_simple_json_list):
        no_data_tip_node.show()
        return

    no_data_tip_node.hide()










    var _group_by_uid_dic: Dictionary = CommonUtils.group_by(_simple_json_list, "uid")


    for _simple_json_list_group_item: Array in _hero_sort_front(_group_by_uid_dic.values()):
        var _prisoner_box_node: PrisonerBox

        if SoldierUtils.is_hero_by_simple_json(_simple_json_list_group_item[0]):
            if not show_hero:
                continue

            _prisoner_box_node = PRISONER_BOX_HERO.instantiate()
        else:
            _prisoner_box_node = PRISONER_BOX.instantiate()

        v_box_container_node.add_child(_prisoner_box_node)
        _prisoner_box_node.connect("choose_sign", _choose)
        _prisoner_box_node.connect("empty_sign", _box_empty_hook)
        _prisoner_box_node.connect("surrender_action_sign", _surrender_action)
        _prisoner_box_node.connect("sell_action_sign", _sell_action)

        if _prisoner_box_node.is_hero():
            _prisoner_box_node.connect("talk_to_prisoner_hero_sign", _talk_to_prisoner_hero)

        _prisoner_box_node.init(_simple_json_list_group_item)
        _prisoner_box_node.update_button_group_type(button_group_type, is_special_slave_trader_price)

    _refresh_no_data_tip_and_send_empty_sign()

func _hero_sort_front(_simple_json_list_list: Array)-> Array:
    _simple_json_list_list.sort_custom(
        func(_a: Array, _b: Array):
            var _simple_json: Dictionary = _a[0]
            return SoldierUtils.is_hero_by_simple_json(_simple_json)
    )
    return _simple_json_list_list

func _sell_action():
    sell_action_sign.emit()

func _surrender_action()-> void:
    surrender_action_sign.emit()


func _get_surrender_count(_simple_json_list: Array)-> int:
    var _prob = SoldierUtils.get_surrender_prob(_simple_json_list[0], WSData.get_player_team_info().skill_charisma)
    return CommonUtils.random_count(_simple_json_list.size(), _prob)

func cshow()-> void:
    self.show()
    modulate.a = 0.0
    var _tween = get_tree().create_tween()
    _tween.tween_property(self, "modulate:a", 1, 0.2)

func chide()-> void:
    clear()
    self.hide()


func capture_all()-> void:
    for _node: PrisonerBox in v_box_container_node.get_children():
        if _node.is_hero():
            continue

        _node.capture_all()


func sell_all()-> void:
    for _node: PrisonerBox in v_box_container_node.get_children():
        if _node.is_hero():
            continue

        _node.sell_all()

    _sell_action()

func player_release_hero_hook(_hero_uid: String)-> void:
    for _node: PrisonerBox in v_box_container_node.get_children():
        if _node.get_uid() == _hero_uid:
            _node.delete()
            break


func _box_empty_hook()-> void:
    _refresh_no_data_tip_and_send_empty_sign()

func _refresh_no_data_tip_and_send_empty_sign()-> void:
    var _is_empty = true

    var _only_contain_hero_or_empty: = true

    for _node: PrisonerBox in v_box_container_node.get_children():
        if _node.get_count() > 0:
            _is_empty = false

            if not _node.is_hero():
                _only_contain_hero_or_empty = false
                break

    if _is_empty:
        no_data_tip_node.show()
        empty_sign.emit()

    if _only_contain_hero_or_empty:
        only_contain_hero_or_empty_sign.emit()

func _choose(_node: PrisonerBox)-> void:
    if CommonUtils.is_not_null(choose_node):
        choose_node.hide_func_button()

    choose_node = _node

func _talk_to_prisoner_hero(_hero_uid: String)-> void:
    talk_to_prisoner_hero_sign.emit(_hero_uid)

func clear()-> void:
    CommonUtils.clear_node(v_box_container_node)
    choose_node = null