class_name PropCard extends Control

@onready var prop_title_node =$ContentRoot / PropTitle
@onready var remark_node =$ContentRoot / Remark
@onready var prop_icon_node =$ContentRoot / PropIcon
@onready var prop_value_node =$ContentRoot / PropTitle / PropValue
@onready var plus_button_node =$ButtonRoot / PlusButton
@onready var subtract_button_node =$ButtonRoot / SubtractButton
@onready var plus_10_button_node: IconFloatButton =$ButtonRoot / Plus10Button
@onready var subtract_10_button_node: IconFloatButton =$ButtonRoot / Subtract10Button

@export var propTitle: String = "力量"
@export var remark: String = "增加角色攻击力"
@export var icon: Texture2D

@export var prop_field: String
@export var auto_update_remark: = true

signal plus_sign(_count: int, _node: PropCard)

var init_prop = 0
var current_prop = 0

func _ready()-> void:
    CommonUtils.set_text(prop_title_node, propTitle)


    if auto_update_remark:
        update_remark(remark)

    CommonUtils.update_texture3(prop_icon_node, icon)

func update_remark(_remark: String)-> void:
    CommonUtils.set_text(remark_node, _remark)

func init(_init_prop):
    init_prop = _init_prop
    _update_prop(_init_prop)

func _update_prop(_current_prop):
    current_prop = _current_prop
    var _str = str(_current_prop)
    if _current_prop > init_prop:
        _str += "(+" + str(_current_prop - init_prop) + ")"

    CommonUtils.set_text(prop_value_node, _str)
    if current_prop <= init_prop:
        subtract_button_node.disabled = true
        subtract_10_button_node.disabled = true
    else:
        subtract_button_node.disabled = false
        subtract_10_button_node.disabled = false

func get_prop_field():
    return prop_field

func plus_forbid():
    plus_button_node.disabled = true
    plus_10_button_node.disabled = true

func plus_active():
    plus_button_node.disabled = false
    plus_10_button_node.disabled = false

func button_hide():
    plus_button_node.hide()
    subtract_button_node.hide()

func button_show():
    plus_button_node.show()
    subtract_button_node.show()

func get_dif_value():
    return current_prop - init_prop


func plus(_count)-> void:
    current_prop += _count
    self._update_prop(current_prop)

func _plus(_count):



    if current_prop > init_prop and current_prop + _count < init_prop:
        _count = init_prop - current_prop

    emit_signal("plus_sign", _count, self)

func _on_plus_button_c_pressed():
    self._plus(1)

func _on_subtract_button_c_pressed():
    self._plus(-1)

func _on_plus_10_button_c_pressed()-> void:
    self._plus(10)

func _on_subtract_10_button_c_pressed()-> void:
    self._plus(-10)