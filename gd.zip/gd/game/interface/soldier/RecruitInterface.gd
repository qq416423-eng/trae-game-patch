extends Control
class_name RecruitInterface

@onready var recruit_left_interface_node =$RecruitLeftInterface as RecruitLeftInterface
@onready var recruit_right_interface_node =$RecruitRightInterface as RecruitRightInterface
@onready var confirm_box_node =$SubPageRoot / ConfirmBox















signal close_page_sign()
signal view_soldier_info_sign(_soldier_prop: BSSoldierProp)




func init():

    WSLocationData.recruit_sort(GlobalTempData.current_location_code)
    recruit_left_interface_node.init(
        WSLocationData.city_data.get(GlobalTempData.current_location_code).recruit,
        GlobalTempData.current_location_code
    )
    recruit_right_interface_node.init()

func clear():
    recruit_left_interface_node.clear()
    recruit_right_interface_node.clear()

func close():

    if GlobalTempData.mod_is_armory_recruit:
        var _city_data = WSLocationData.city_data.get(GlobalTempData.current_location_code)
        if _city_data != null:
            _city_data.recruit = GlobalTempData.mod_armory_saved_recruit.duplicate(true)
        GlobalTempData.mod_is_armory_recruit = false
        GlobalTempData.mod_armory_saved_recruit = []
    clear()
    hide()
    close_page_sign.emit()


func _on_recruit_left_interface_choose(_node):
    var _success: = recruit_right_interface_node.add(_node.json, true)
    if not _success:
        return

    recruit_left_interface_node.remove(_node)

func _on_recruit_right_interface_choose(_node):
    recruit_left_interface_node.add(_node.json, true)
    recruit_right_interface_node.remove(_node)

func _on_close_button_pressed():

    if recruit_right_interface_node.get_change_money() != 0:
        confirm_box_node.open()
        return

    self.close()


func _on_sell_all_button_pressed():
    var _node_list = recruit_left_interface_node.get_all_node()
    for _node in _node_list:
        var _success = recruit_right_interface_node.add(_node.json, true)
        if not _success:
            return

        recruit_left_interface_node.remove(_node)

func _on_buy_all_button_pressed():
    var _node_list = recruit_right_interface_node.get_all_node()
    for _node in _node_list:
        recruit_left_interface_node.add(_node.json, true)
        recruit_right_interface_node.remove(_node)


func _on_save_button_pressed():

    var _change_money = recruit_right_interface_node.get_change_money()
    var _success = WSData.update_money(_change_money, true)
    if not _success:

        return


    var add_json_list = recruit_right_interface_node.get_json_list()
    WSData.add_soldier(add_json_list)


    if GlobalTempData.mod_is_armory_recruit:

        var _guard_recruited: int = 0
        for _entry in add_json_list:
            if _entry is Dictionary and _entry.get("uid", "") == "mod_player_guard":
                _guard_recruited += 1

        if _guard_recruited > 0:
            var _player_team_json: Dictionary = TeamUtils.get_player_team_json()
            if not _player_team_json.has("mod_armory_recruited"):
                _player_team_json["mod_armory_recruited"] = {}
            var _prev_count: int = int(_player_team_json["mod_armory_recruited"].get(GlobalTempData.current_location_code, 0))
            _player_team_json["mod_armory_recruited"][GlobalTempData.current_location_code] = _prev_count + _guard_recruited

    var city_recruit_json = recruit_left_interface_node.get_json_list()

    if GlobalTempData.mod_is_armory_recruit:
        city_recruit_json = GlobalTempData.mod_armory_saved_recruit.duplicate(true)
    WSLocationData.save_city_recruit(GlobalTempData.current_location_code, city_recruit_json)



    var _recruited_count = add_json_list.size()
    if GlobalTempData.mod_is_armory_recruit:
        for _entry in add_json_list:
            if _entry is Dictionary and _entry.get("uid", "") == "mod_player_guard":
                _recruited_count -= 1
    WSLocationData.plus_population_working_age_by_nop(GlobalTempData.current_location_code, - _recruited_count)

    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_SUCCESS)

    self.close()


func _on_confirm_box_cancel():
    self.close()


func _on_confirm_box_confirm():
    _on_save_button_pressed()

func _on_recruit_left_interface_view_soldier_info_sign(_soldier_prop: BSSoldierProp)-> void:
    view_soldier_info_sign.emit(_soldier_prop)

func _on_recruit_right_interface_view_soldier_info_sign(_soldier_prop: BSSoldierProp)-> void:
    view_soldier_info_sign.emit(_soldier_prop)