class_name RecruitLeftInterface extends Control

@onready var grid_container_node =$BaseScrollContainer / GridContainer
@onready var empty_hint_node =$Background / EmptyHint
@onready var population_working_age_node: LevelImageBox =$InfoRoot / PopulationWorkingAgeBackground / PopulationWorkingAge
@onready var recruit_score_box_node: KeyValueBox =$InfoRoot / RecruitScoreBackground / RecruitScoreBox
@onready var recruit_score_description_root_node: NinePatchRect =$InfoRoot / RecruitScoreDescriptionRoot
@onready var recruit_score_description_node: Label =$InfoRoot / RecruitScoreDescriptionRoot / RecruitScoreDescription

const SOLDIER_BOX = preload("res://tscn/game/interface/soldier/RecruitSoldierBox.tscn")

signal choose(_node)
signal view_soldier_info_sign(_soldier_prop: BSSoldierProp)

func init(
    json_list: Array, location_code: String
):
    for _json in json_list:
        self.add(_json)

    _handle_empty_hint()
    _init_recruit_info(location_code)

func clear():
    CommonUtils.clear_node(grid_container_node)
    recruit_score_description_root_node.hide()

func add(_json, _need_animation = false):
    var _node: SoldierBox = SOLDIER_BOX.instantiate()
    grid_container_node.add_child(_node)


    var _price_ratio = 1.0

    var _location_country = WSLocationData.get_belong_country(GlobalTempData.current_location_code)
    if _location_country == WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:
        _price_ratio = 0.0
    else:
        _price_ratio = SkillUtils.get_price_ratio_by_skill_charisma(WSData.get_player_team_info().skill_charisma)

    _node.init(_json, _price_ratio)
    _node.connect("choose", _choose)
    _node.connect("view_info_sign", _view_soldier_info)
    if _need_animation:
        _node.show_new_tag_animation()

    _handle_empty_hint()

func remove(_node):
    _node.is_deleted = true
    _node.queue_free()
    _handle_empty_hint()

func get_all_node():
    return grid_container_node.get_children()

func get_json_list():
    var _node_list = self.get_all_node()
    var _json_list = []
    for _node in _node_list:
        _json_list.append(_node.json)

    return _json_list

func _handle_empty_hint():

    var _flag = false
    for _child in self.get_all_node():
        if _child.is_deleted:
            continue

        _flag = true

    if _flag:
        if empty_hint_node.visible:
            empty_hint_node.hide()
    else:
        if not empty_hint_node.visible:
            empty_hint_node.show()

func _view_soldier_info(_soldier_prop: BSSoldierProp)-> void:
    view_soldier_info_sign.emit(_soldier_prop)


func _choose(_node):
    emit_signal("choose", _node)

func _init_recruit_info(_location_code: String)-> void:
    var _location_data: Dictionary = LocationUtils.get_location_data(_location_code)
    population_working_age_node.update_level(_location_data.population_working_age / 200)
    var _recrult_plus_score: = LocationUtils.get_recruit_plus_score(_location_data)
    recruit_score_box_node.set_value(_recrult_plus_score)
    CommonUtils.set_text(
        recruit_score_description_node,
        LocationUtils.get_recruit_plus_score_description(_location_data)
    )


func _on_recruit_score_description_button_custom_pressed()-> void:
    if recruit_score_description_root_node.visible:
        recruit_score_description_root_node.hide()
    else:
        recruit_score_description_root_node.show()