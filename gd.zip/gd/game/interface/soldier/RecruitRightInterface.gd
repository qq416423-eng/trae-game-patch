extends Control
class_name RecruitRightInterface


const SOLDIER_BOX = preload("res://tscn/game/interface/soldier/RecruitSoldierBox.tscn")
@onready var grid_container_node =$BaseScrollContainer / GridContainer
@onready var eg_money_interface_node =$EGMoneyInterface as EGMoneyInterface
@onready var nop_info_node: Label =$Background / TitleBackground / NopInfo

var nop: = 0
var nop_limit: = 0
var change_nop: = 0

signal choose(_node)
signal view_soldier_info_sign(_soldier_prop: BSSoldierProp)

func init():
    eg_money_interface_node.init()
    _init_player_nop_info()
    change_nop = 0

func clear():
    CommonUtils.clear_node(grid_container_node)
    nop = 0
    nop_limit = 0
    change_nop = 0


func add(_json, _need_animation = false)-> bool:
    if nop + change_nop >= nop_limit:
        GlobalMessageInterface.add_message_exceeded_troop_limit()
        return false

    change_nop += 1
    var _node: SoldierBox = SOLDIER_BOX.instantiate()
    grid_container_node.add_child(_node)


    var _price_ratio = 1.0
    var _location_country = WSLocationData.get_belong_country(GlobalTempData.current_location_code)
    if _location_country == WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:
        _price_ratio = 0.0
    else:
        _price_ratio = SkillUtils.get_price_ratio_by_skill_charisma(WSData.get_player_team_info().skill_charisma)

    _node.init(_json, _price_ratio)
    _node.connect("choose", _choose)
    _node.connect("view_info_sign", _view_soldier_info)
    self._update_price()
    if _need_animation:
        _node.show_new_tag_animation()

    _refresh_nop_info()

    return true

func remove(_node):
    change_nop -= 1
    _node.is_deleted = true
    _node.queue_free()
    self._update_price()
    _refresh_nop_info()

func get_all_node():
    return grid_container_node.get_children()

func get_json_list():
    var _node_list = self.get_all_node()
    var _json_list = []
    for _node in _node_list:
        _json_list.append(_node.json)

    return _json_list

func get_change_money():
    return eg_money_interface_node.get_change_money()


func _init_player_nop_info()-> void:
    nop = WSData.get_player_nop()
    nop_limit = WSData.get_player_nop_limit()

    _refresh_nop_info()

func _refresh_nop_info()-> void:
    var _content: = str(nop + change_nop) + "/" + str(nop_limit)
    CommonUtils.set_text(nop_info_node, _content)

    if nop + change_nop >= nop_limit:
        CommonUtils.update_color(nop_info_node, CommonConstants.COLOR_ENUM.RED)
    else:
        CommonUtils.update_color(nop_info_node, CommonConstants.COLOR_ENUM.WHITE)

func _update_price():
    var _change_money = 0
    for _node in grid_container_node.get_children():
        if not _node.is_deleted:
            _change_money -= _node.price

    eg_money_interface_node.update_change_money(_change_money)


func _choose(_node):
    emit_signal("choose", _node)

func _view_soldier_info(_soldier_prop: BSSoldierProp)-> void:
    view_soldier_info_sign.emit(_soldier_prop)