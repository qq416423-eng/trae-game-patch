class_name SoldierBox extends Control

@onready var avatar_ani_node =$AvatarAni as AvatarAni
@onready var money_value_node =$MoneyRoot / Value
@onready var weapon_icon_root_node =$WeaponIconRoot as WeaponIconList
@onready var name_node =$Name
@onready var top_point_node =$PointRoot / TopPoint
@onready var bottom_point_node =$PointRoot / BottomPoint
@onready var button_node =$Button
@onready var animation_player_node =$AnimationPlayer
@onready var money_root_node =$MoneyRoot
@onready var star_node =$StarRoot / Star
@onready var star_root_node =$StarRoot
@onready var level_root_node: HBoxContainer =$LevelRoot
@onready var level_value_node: Label =$LevelRoot / LevelValue

@export var hide_money: = false

var json: Dictionary

var price: int

var is_deleted: = false
var soldier_prop: BSSoldierProp

signal choose(_node)
signal view_info_sign(_soldier_prop: BSSoldierProp)

















func _ready():
    if hide_money:
        money_root_node.hide()

func init_by_uid(_uid: String):
    var _simple_json = {
        "uid": _uid
    }
    SoldierUtils.repair_simple_json(_simple_json)

    init(_simple_json)


func init(_simple_json, _price_ratio: = 1.0)-> void:
    json = _simple_json

    var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)
    soldier_prop = _prop

    avatar_ani_node.init(_prop)
    self.update_price(int(_prop.price * _price_ratio))

    var _soldier_name: String = _prop.name
    if GameConfig.SHOW_SOLDIER_CODE:
        _soldier_name += "(" + _prop.uid + ")"

    CommonUtils.set_text(name_node, _soldier_name)

    weapon_icon_root_node.init(_prop)

    if SoldierUtils.is_hero_by_soldier_prop(_prop):
        CommonUtils.set_text(star_node, "")
        CommonUtils.update_self_color(star_root_node, CommonConstants.COLOR_ENUM.RED)
        money_root_node.hide()
        level_root_node.show()
        CommonUtils.set_text(level_value_node, _prop.level)
    else:
        _update_star_info(_prop.star)






func show_new_tag_animation():

    animation_player_node.call_deferred("play", "new_tag")

func open_select_effect():
    button_node.select_effect = true

func unchoose():
    button_node.cancel()

func select()-> void:
    button_node.choose(false)


func get_point_list(_target_node: SoldierBox)-> PackedVector2Array:
    var _start_point = get_bottom_point_global_position()
    var _end_point = _target_node.get_top_point_global_position()






    return[
        _start_point,
        Vector2(_start_point.x,(_end_point.y + _start_point.y) / 2),
        Vector2(_end_point.x,(_end_point.y + _start_point.y) / 2),
        _end_point
    ]

func set_button_disable(_disable):
    button_node.disabled = _disable




func get_top_point_global_position():
    return top_point_node.global_position

func get_bottom_point_global_position():
    return bottom_point_node.global_position

func update_price(_price: int):
    price = _price
    CommonUtils.set_text(money_value_node, _price)

func update_hide_money():
    money_root_node.hide()

func cshow()-> void:
    self.show()

func chide()-> void:
    self.hide()

func get_star()-> int:
    return soldier_prop.star

func get_uid()-> String:
    return soldier_prop.uid

func get_is_select()-> bool:
    return button_node.is_pressed

func _update_star_info(_star: int):
    var _color: Color = SoldierUtils.get_star_color(_star)

    CommonUtils.set_text(star_node, _star)



    CommonUtils.update_self_color(star_root_node, _color)


func _on_button_b_pressed():
    emit_signal("choose", self)

func _on_info_button_pressed()-> void:
    view_info_sign.emit(soldier_prop)