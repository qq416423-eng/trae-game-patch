class_name SoldierEquipmentAdjustedInterface extends Control

@onready var soldier_equipment_interface_node: SoldierEquipmentInterface =$SoldierEquipmentInterface
@onready var equipment_detail_interface_node: EquipmentDetailInterface =$OtherPageRoot / EquipmentDetailInterface
@onready var show_equipment_detail_interface_point_node: Marker2D =$ShowEquipmentDetailInterfacePoint

func init(_soldier_prop: BSSoldierProp)-> void:
    soldier_equipment_interface_node.init(_soldier_prop)

func cancel_choose_equipment()-> void:
    soldier_equipment_interface_node.cancel_choose_equipment()
    hide_child_page()

func hide_child_page()-> void:
    equipment_detail_interface_node.hide()


func _on_soldier_equipment_interface_choose_equipment(_node: Variant)-> void:
    if _node.json == null or not _node.json.has("uid"):
        equipment_detail_interface_node.hide()
        return

    equipment_detail_interface_node.init(_node.json)

    equipment_detail_interface_node.ishow(
        Vector2(
            show_equipment_detail_interface_point_node.global_position.x,
            _node.get_detail_show_position().y
        )
    )

func clear()-> void:
    soldier_equipment_interface_node.clear()
    hide_child_page()