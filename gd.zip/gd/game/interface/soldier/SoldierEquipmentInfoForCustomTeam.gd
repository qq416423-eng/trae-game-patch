class_name SoldierEquipmentInfoForCustomTeam extends Control

@onready var soldier_equipment_adjusted_interface_node: SoldierEquipmentAdjustedInterface =$SoldierEquipmentAdjustedInterface
@onready var solider_count_node: NumBackground =$SoldierEquipmentAdjustedInterface / SoliderCount
@onready var func_area_root_node: Control =$FuncAreaRoot
@onready var bi_background_node: NinePatchRect =$Background / BIBackground
@onready var group_card_icon_node: GroupCardIcon =$FuncAreaRoot / Background / ButtonRoot2 / FormationButton / GroupCardIcon
@onready var split_group_button_node: CommonButton =$FuncAreaRoot / Background / ButtonRoot2 / SplitGroupButton
@onready var formation_button_node: CommonButton =$FuncAreaRoot / Background / ButtonRoot2 / FormationButton
@onready var button_root_node: HBoxContainer =$FuncAreaRoot / Background / ButtonRoot
@onready var button_root_2_node: HBoxContainer =$FuncAreaRoot / Background / ButtonRoot2
@onready var background_02_node: TextureRect =$FuncAreaRoot / Background / Background02
@onready var background_node: TextureRect =$FuncAreaRoot / Background

const BACKGROUND_0004 = preload("res://resource/baseUI/background_0004.png")

var count: = 0
var is_hero: = false
var button_root_2_node_init_position = Vector2.ZERO

signal plus_soldier_count(_count: int, _min_one_enforced)
signal formation_set_sign()
signal split_group_sign()

func _ready()-> void:
    button_root_2_node_init_position = button_root_2_node.position


func init(_soldier_prop: BSSoldierProp, _count: int)-> void:
    count = _count
    soldier_equipment_adjusted_interface_node.init(_soldier_prop)

    solider_count_node.update_num(
        _count, false
    )

    if SoldierUtils.is_hero_by_soldier_prop(_soldier_prop):
        is_hero = true
        button_root_node.hide()

        button_root_2_node.position = button_root_node.position
        background_02_node.show()
        background_node.self_modulate.a = 0.0
    else:
        is_hero = false
        button_root_node.show()
        button_root_2_node.position = button_root_2_node_init_position
        background_02_node.hide()
        background_node.self_modulate.a = 1.0

func update_num_ani(_count)-> void:
    count = _count
    solider_count_node.update_num(
        _count, true
    )

func cancel_choose_equipment()-> void:
    soldier_equipment_adjusted_interface_node.cancel_choose_equipment()

func hide_info()-> void:
    soldier_equipment_adjusted_interface_node.hide()
    func_area_root_node.hide()

func show_info()-> void:
    soldier_equipment_adjusted_interface_node.show()
    func_area_root_node.show()

func reset_background()-> void:
    CommonUtils.update_texture3(bi_background_node, BACKGROUND_0004)

func update_background(_texture2d: Resource)-> void:
    CommonUtils.update_texture3(bi_background_node, _texture2d)

func refresh_group_card_icon(_group_num: int)-> void:
    group_card_icon_node.init(_group_num)

func show_or_hide_formation_split_button(_is_show: bool)-> void:
    if _is_show:
        formation_button_node.show()
        if is_hero:
            split_group_button_node.hide()
        else:
            split_group_button_node.show()
    else:
        formation_button_node.hide()
        split_group_button_node.hide()

func disable_all_button(_disable: bool)-> void:
    for _button_node in button_root_node.get_children():
        _button_node.disabled = _disable

    for _button_node in button_root_2_node.get_children():
        _button_node.disabled = _disable

func hide_equipment_detail_page()-> void:
    soldier_equipment_adjusted_interface_node.hide_child_page()

func _on_plus_1_button_c_pressed()-> void:
    plus_soldier_count.emit(1, false)

func _on_plus_10_button_c_pressed()-> void:
    plus_soldier_count.emit(10, false)

func _on_sub_1_button_c_pressed()-> void:
    plus_soldier_count.emit(-1, true)

func _on_sub_10_button_c_pressed()-> void:
    plus_soldier_count.emit(-10, true)

func _on_delete_button_custom_pressed()-> void:
    plus_soldier_count.emit(- count, false)

func _on_formation_button_custom_pressed()-> void:
    formation_set_sign.emit()

func _on_split_group_button_custom_pressed()-> void:
    split_group_sign.emit()