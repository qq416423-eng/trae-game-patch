extends Node2D
class_name SoldierEquipmentInterface

@onready var avatar_ani_node =$AvatarAni
@onready var equipment_interface_node =$EquipmentInterface
@onready var name_node =$InfoRoot / Name
@onready var hero_select_interface_node =$HeroSelectInterface as HeroSelectInterface
@onready var level_bar_node =$InfoRoot / LevelBar as LevelBar
@onready var soldier_name_node =$InfoRoot / SoldierName

@export var is_hide_name = false



var temp_hero_json_dic: = {}

var origin_hero_json_dic: = {}

var current_hero_uid: = ""
var left_price_ratio: = GoodsConfig.MY_ITEMS_PRICE_RATIO

signal choose_equipment(_node)
signal change_hero()
signal change_equipment_sign()


func init(_soldier_prop: BSSoldierProp):

    avatar_ani_node.init(_soldier_prop)

    equipment_interface_node.init(_soldier_prop)
    CommonUtils.set_text(name_node, _soldier_prop.name)
    CommonUtils.set_text(soldier_name_node, _soldier_prop.name)

    current_hero_uid = _soldier_prop.uid
    if _soldier_prop.htype == BSSoldierConstants.H_TYPE_ENUM.HERO:
        level_bar_node.show()
        level_bar_node.init_by_hero_uid(_soldier_prop.uid)
        if not is_hide_name:
            name_node.show()
            soldier_name_node.hide()
    else:
        level_bar_node.hide()
        if not is_hide_name:
            name_node.hide()
            soldier_name_node.show()

    if _soldier_prop.is_busy:
        CommonUtils.set_text(name_node, _soldier_prop.name + " (忙碌)")


func init_select(
    _team_json_list: Array,
    _select_pre_hero: bool = false
):
    origin_hero_json_dic = SoldierUtils.get_hero_json_dic(_team_json_list)
    temp_hero_json_dic = origin_hero_json_dic.duplicate(true)

    hero_select_interface_node.init(_team_json_list, _select_pre_hero)




func compute_price():
    var _field_list = WeaponTypeConstants.EQUIPMENT_FIELD_ENUM.values()
    var _part_json_list = []
    for _hero_json in temp_hero_json_dic.values():
        for _field in _field_list:
            var part_json = CommonUtils.get_value(_hero_json, _field, null)
            if part_json != null and part_json.has("uid") and StringUtils.is_not_empty(part_json.uid):
                _part_json_list.append(
                    {
                        "item": part_json,
                        "count": 1
                    }
                )

    return GoodsUtils.compute_price(_part_json_list, GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS)

func is_has_change_goods()-> bool:
    var _field_list = WeaponTypeConstants.EQUIPMENT_FIELD_ENUM.values()
    var _part_json_list = []
    for _hero_json in temp_hero_json_dic.values():
        for _field in _field_list:
            var part_json = CommonUtils.get_value(_hero_json, _field, null)
            if part_json != null and part_json.has("uid") and StringUtils.is_not_empty(part_json.uid):
                _part_json_list.append(
                    {
                        "item": part_json,
                        "count": 1
                    }
                )
    return GoodsUtils.is_has_change_goods(
        _part_json_list,
        GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS
    )

func cancel_choose_equipment():
    equipment_interface_node.cancel_choose()


func update_equip(_field, _equip_json):
    if _equip_json == null:
        _equip_json = {}

    var _old_item_json = equipment_interface_node.update_equip(_field, _equip_json)

    temp_hero_json_dic[current_hero_uid][_field] = _equip_json

    var _soldier_prop: = SoldierUtils.get_bs_soldier_prop_by_json(temp_hero_json_dic[current_hero_uid])
    avatar_ani_node.init(_soldier_prop)


    change_equipment_sign.emit()


    return _old_item_json






func show_allow_exchange_area_weapon():
    equipment_interface_node.show_allow_exchange_area_weapon()

func cancel_show_allow_exchange_area_weapon():
    equipment_interface_node.cancel_show_allow_exchange_area_weapon()


func restore():
    temp_hero_json_dic = origin_hero_json_dic.duplicate(true)


    var _soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_json(temp_hero_json_dic.get(current_hero_uid))
    init(_soldier_prop)


func save():
    var _field_list = WeaponTypeConstants.EQUIPMENT_FIELD_ENUM.values()

    for _hero_json in temp_hero_json_dic.values():

        for _field in _field_list:
            var _equipment_json = CommonUtils.get_value(_hero_json, _field,{})
            if _equipment_json != null and _equipment_json.has("uid"):
                _equipment_json.erase("origin")
                _equipment_json.erase("price_ratio")
                _equipment_json.erase("commodity_price_ratio")

        GlobalSoldierInfo.hero_dic[_hero_json.uid] = _hero_json

    origin_hero_json_dic = temp_hero_json_dic
    temp_hero_json_dic = origin_hero_json_dic.duplicate(true)

    refresh()


func refresh():
    var _soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_json(temp_hero_json_dic.get(current_hero_uid))
    init(_soldier_prop)

func reset_hero_select_interface()-> void:
    hero_select_interface_node.hide_select_area()

func clear()-> void:
    equipment_interface_node.clear()
    current_hero_uid = ""
    temp_hero_json_dic = {}
    origin_hero_json_dic = {}

func get_soldier_prop()-> BSSoldierProp:
    return SoldierUtils.get_bs_soldier_prop_by_json(temp_hero_json_dic.get(current_hero_uid))


func _on_equipment_interface_bchoose(_node):
    emit_signal("choose_equipment", _node)


func _on_hero_select_interface_choose(_item_json):
    if _item_json.uid == current_hero_uid:
        return

    current_hero_uid = _item_json.uid
    var _soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_json(temp_hero_json_dic.get(current_hero_uid))
    self.init(_soldier_prop)
    emit_signal("change_hero")