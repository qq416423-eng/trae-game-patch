class_name SoldierInfoBox extends HBoxContainer

@onready var icon_node =$Icon
@onready var name_node =$Name
@onready var nop_node =$Nop


const LORD_PIC = preload("res://resource/icon/smallIcon/hero_icon_16.png")

func init(_star: int, _name: String, _nop: int):
    if _star >= 0:
        var _color = SoldierUtils.get_star_color(_star)
        CommonUtils.update_self_color(icon_node, _color)
        CommonUtils.set_text(nop_node, "X " + str(_nop))
    else:
        CommonUtils.set_text(nop_node, "")
        CommonUtils.update_texture3(icon_node, LORD_PIC)

    CommonUtils.set_text(name_node, _name)