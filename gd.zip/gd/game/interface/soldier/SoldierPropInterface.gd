class_name SoldierPropInterface extends Control

@onready var practise_prop_root_node =$Column2 / PractiseRoot / PropRoot
@onready var skill_root_node: NinePatchRect =$Column2 / SkillRoot
@onready var battle_prop_root_node: NinePatchRect =$Column1 / BattlePropRoot
@onready var base_prop_soldier_root_node: NinePatchRect =$Column1 / BasePropSoldierRoot
@onready var practise_root_node: NinePatchRect =$Column2 / PractiseRoot
@onready var prop_root_node: VBoxContainer =$Column2 / SkillRoot / PropRoot
@onready var column_1_node: VBoxContainer =$Column1
@onready var column_2_node: VBoxContainer =$Column2
@onready var base_prop_hero_root_node: NinePatchRect =$Column1 / BasePropHeroRoot
@onready var show_change_value_root_node: Control =$ShowChangeValueRoot

const VALUE_SMALL_BOX = preload("res://tscn/game/interface/ValueSmallBox.tscn")

var soldier_interface_min_y: = 0.0
var hero_interface_min_y: = 0.0

const SPECIAL_PROP_NAME_DIC = {
    "HP": "hp"
}
const CUSTOM_FUNC_PROP_NAME_DIC = {
    "ehp": "get_ehp",
    "b_ehp": "get_b_ehp",
    "wages_1_0": "get_wages_10_days_int"
}

var simple_json = {}





var temp_change_value_data: = {}

func _ready():

    for _node in practise_prop_root_node.get_children():
        if _node.visible:
            CommonUtils.set_text(
                _node.get_node("Key"),
                SoldierUtils.get_practise_name(CommonUtils.camel_to_underscore(_node.name))
            )

    soldier_interface_min_y = battle_prop_root_node.position.y + battle_prop_root_node.size.y
    hero_interface_min_y = self.custom_minimum_size.y

func init_by_simple_json(_simple_json: Dictionary):
    simple_json = _simple_json
    var _soldier_prop = SoldierUtils.get_bs_soldier_prop(_simple_json)
    init(_soldier_prop)

func init(
    _soldier_prop: BSSoldierProp,
    _need_show_stat_diff: bool = false
):
    CommonUtils.clear_node(show_change_value_root_node)
    temp_change_value_data = {}


    var _skill_max_config: Dictionary = HeroDefaultData.get_skill_max_info(_soldier_prop.uid)
    var _child_node_list = [
        practise_root_node, skill_root_node,
        battle_prop_root_node, base_prop_soldier_root_node,
        base_prop_hero_root_node,
    ]

    for _child in _child_node_list:
        var _is_skill_prop = false
        if _child.name == "SkillRoot":
            _is_skill_prop = true

        for _prop_node in _child.get_node("PropRoot").get_children():


            var _old_value_num = _prop_node.get_node("Value").text
            var _change_value_str_suffix: = ""

            var _prop_name = CommonUtils.camel_to_underscore(_prop_node.name)
            if SPECIAL_PROP_NAME_DIC.has(_prop_node.name):
                _prop_name = SPECIAL_PROP_NAME_DIC.get(_prop_node.name)

            var _value = 0
            if CUSTOM_FUNC_PROP_NAME_DIC.has(_prop_name):
                _value = _soldier_prop.call(CUSTOM_FUNC_PROP_NAME_DIC.get(_prop_name))
            else:
                _value = _soldier_prop[_prop_name]


            var _new_value_num = _value
            var _is_ensure_value_type: = false


            if BSSoldierConstants.PROP_SHOW_CONFIG.has(_prop_name):
                match BSSoldierConstants.PROP_SHOW_CONFIG.get(_prop_name).type:
                    BSSoldierConstants.COMPUTE_TYPE_ENUM.PERCENT:
                        _new_value_num = int(_value * 100)
                        _old_value_num = int(_old_value_num)
                        _change_value_str_suffix = "%"

                        _is_ensure_value_type = true

                        _value = str(_new_value_num) + "%"
                    BSSoldierConstants.COMPUTE_TYPE_ENUM.THREE_DECIMALS:
                        _new_value_num = int(_value * 1000) / 1000.0
                        _old_value_num = float(_old_value_num)
                        _is_ensure_value_type = true

                        _value = str(_new_value_num)


            if _is_skill_prop:
                _new_value_num = int(_value)
                _old_value_num = int(StringUtils.substringStart(_old_value_num, str(_old_value_num).find("/", 0)))
                _is_ensure_value_type = true

                var _max: int = CommonUtils.get_value(_skill_max_config, _prop_name, SkillConfig.SKILL_MAX_LEVEL)
                _value = str(_value) + "/" + str(_max)

                if SkillUtils.is_special_skill(_prop_name):
                    if _soldier_prop[_prop_name] > 0:
                        _prop_node.show()
                    else:
                        _prop_node.hide()

            if _need_show_stat_diff:
                if not _is_ensure_value_type:
                    _new_value_num = float(_new_value_num)
                    _old_value_num = float(_old_value_num)

                if _old_value_num != _new_value_num:
                    temp_change_value_data[_prop_name] = {
                        "node": _prop_node,
                        "change_value": _new_value_num - _old_value_num,
                        "change_value_str":("+" if _new_value_num - _old_value_num > 0 else "-") \
                        + str(abs(_new_value_num - _old_value_num)) \
                        + _change_value_str_suffix
                    }

            CommonUtils.set_text(_prop_node.get_node("Value"), _value)


    if SoldierUtils.is_hero_by_soldier_prop(_soldier_prop):
        skill_root_node.show()
        base_prop_hero_root_node.show()
        base_prop_soldier_root_node.hide()
        self.custom_minimum_size.y = hero_interface_min_y
    else:
        skill_root_node.hide()
        base_prop_hero_root_node.hide()
        base_prop_soldier_root_node.show()
        self.custom_minimum_size.y = soldier_interface_min_y


    call_deferred("_height_adaptive")

    if _need_show_stat_diff:
        call_deferred("_show_change_value_box")

func refresh():
    init_by_simple_json(simple_json)


func _height_adaptive()-> void:
    var _height = prop_root_node.size.y
    skill_root_node.custom_minimum_size.y = _height + 52
    skill_root_node.size.y = skill_root_node.custom_minimum_size.y

func _show_change_value_box()-> void:

    for _temp_change_value_data_value: Dictionary in temp_change_value_data.values():
        var _node: ValueSmallBox = VALUE_SMALL_BOX.instantiate()
        show_change_value_root_node.add_child(_node)

        var _value_style_enum: = ValueSmallBox.VALUE_STYLE_ENUM.GREEN
        if _temp_change_value_data_value.change_value < 0:
            _value_style_enum = ValueSmallBox.VALUE_STYLE_ENUM.RED


        if["Weight"].has(_temp_change_value_data_value.node.name):
            _value_style_enum = ValueSmallBox.VALUE_STYLE_ENUM.RED if _value_style_enum == ValueSmallBox.VALUE_STYLE_ENUM.GREEN else ValueSmallBox.VALUE_STYLE_ENUM.GREEN

        _node.set_value(
            _temp_change_value_data_value.change_value_str,
            _value_style_enum
        )

        _node.global_position = _temp_change_value_data_value.node.global_position \
        + Vector2(126 + _temp_change_value_data_value.node.get_node("Value").size.x, -4)