class_name SoldierPropWithBackgroundInterface extends Control

@onready var soldier_prop_interface_node: SoldierPropInterface =$BaseScrollContainer / SoldierPropInterface

signal hide_sign()

func init(soldier_prop: BSSoldierProp, _need_show_stat_diff: bool)-> void:
    soldier_prop_interface_node.init(soldier_prop, _need_show_stat_diff)

func chide()-> void:
    self.hide()

func _on_close_button_custom_pressed()-> void:
    self.chide()
    hide_sign.emit()