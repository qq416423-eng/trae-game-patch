class_name SoldierUpgradeInterface extends Control

@onready var origin_soldier_box_node =$OriginSoldierRoot / OriginSoldierBox as SoldierBox
@onready var soldier_box_node = preload("res://tscn/game/interface/soldier/SoldierBox.tscn")
@onready var upgrade_soldier_root_node =$UpgradeSoldierRoot
@onready var connect_line_node = preload("res://tscn/game/interface/ws/ConnectLine.tscn")
@onready var line_root_node =$LineRoot
@onready var num_background_node =$OriginSoldierRoot / OriginSoldierBox / NumBackground as NumBackground
@onready var button_root_node =$ButtonRoot
@onready var upgrade_button_node =$ButtonRoot / UpgradeButton
@onready var upgrade_5_button_node =$ButtonRoot / Upgrade5Button
@onready var eg_money_interface_node =$EGMoneyInterface as EGMoneyInterface
@onready var empty_tip_node =$EmptyTip
@onready var tip_node =$Tip

signal close_sign()
signal view_info_sign(_soldier_prop: BSSoldierProp)

var _json = {
    "uid": "test_soldier_0001",
    "body": {
        "uid": "body_0001",
        "color": Color(0.29, 0.18, 0.08, 1),
    },
    "hair": {
        "uid": "hair_0001",
        "color": Color(0.83, 0.83, 0.83, 1),
    },
}

var select_node = null
var upgrade_simple_json_list: = []
var remain_num = 0
var is_show_button_root = false
var origin_uid = ""

signal upgrade_finish_sign()

func _ready():

    origin_soldier_box_node.set_button_disable(true)
    pass

func init_by_simple_json_list(_simple_json_list: Array):
    _clear()

    var _upgrade_simple_json_list = self._get_upgrade_simple_json_list(_simple_json_list)
    upgrade_simple_json_list = _upgrade_simple_json_list
    self._update_remain_num()
    self.init(_simple_json_list[0])

    eg_money_interface_node.init()

func init(_simple_json: Dictionary):
    origin_uid = _simple_json.uid

    origin_soldier_box_node.init(_simple_json)




    var _upgrade_data = SoldierUtils.get_upgrade_data(origin_uid)
    var _upgrade_list = _upgrade_data.upgrade_uid_list

    if ArrayUtils.is_empty(_upgrade_list):
        empty_tip_node.show()
        return

    empty_tip_node.hide()


    for _soldier_uid in _upgrade_list:
        var _temp_simple_json = _simple_json.duplicate(true)
        SoldierUtils.remove_simple_json_equip_field(_temp_simple_json)
        _temp_simple_json.uid = _soldier_uid
        SoldierUtils.repair_simple_json(_temp_simple_json)
        var soldier_box_instance = soldier_box_node.instantiate() as SoldierBox
        upgrade_soldier_root_node.add_child(soldier_box_instance)
        soldier_box_instance.init(_temp_simple_json)
        soldier_box_instance.open_select_effect()
        soldier_box_instance.connect("choose", _choose)
        soldier_box_instance.connect("view_info_sign", _view_info)

        var _upgrade_price = SoldierUtils.compute_upgrade_price(_simple_json.uid, _soldier_uid)
        soldier_box_instance.update_price(_upgrade_price)


        if remain_num == 0:
            soldier_box_instance.set_button_disable(true)

    if remain_num > 0:
        tip_node.show()
    else:
        tip_node.hide()


    call_deferred("_init_line")

func get_uid():
    return origin_uid


func _init_line():
    for _node in upgrade_soldier_root_node.get_children():
        if _node.is_queued_for_deletion():
            continue

        var _point_list = origin_soldier_box_node.get_point_list(_node)
        var connect_line_instance = connect_line_node.instantiate() as ConnectLine
        line_root_node.add_child(connect_line_instance)
        connect_line_instance.init(_point_list, line_root_node.global_position)











func _choose(_node: SoldierBox):
    tip_node.hide()

    if not is_show_button_root:
        button_root_node.show()
        is_show_button_root = true
        _update_upgrade_button_style()

    if select_node == null:
        self._update_select_node(_node)
        return

    if select_node == _node:
        return

    select_node.unchoose()
    self._update_select_node(_node)


func _update_select_node(_node: SoldierBox):
    if select_node != null:
        var _index = select_node.get_index()
        line_root_node.get_child(_index).default_effect()

    select_node = _node
    var _index = _node.get_index()
    line_root_node.get_child(_index).click_effect()

func _clear():
    select_node = null
    CommonUtils.clear_node(upgrade_soldier_root_node)
    CommonUtils.clear_node(line_root_node)
    is_show_button_root = false
    button_root_node.hide()

func _update_remain_num(_show_effect = false):
    remain_num = upgrade_simple_json_list.size()
    num_background_node.update_num(remain_num, _show_effect)
    if remain_num <= 0:
        _update_upgrade_button_style()

func _get_upgrade_simple_json_list(_simple_json_list):
    var _result = []
    for _simple_json in _simple_json_list:
        if SoldierUtils.check_allow_upgradable_by_simple_json(_simple_json):
            _result.append(_simple_json)

    return _result

func _update_upgrade_button_style():
    if remain_num > 0:
        upgrade_button_node.disabled = false
        upgrade_5_button_node.disabled = false
    else:
        upgrade_button_node.disabled = true
        upgrade_5_button_node.disabled = true


func _upgrade(_count: int):
    if upgrade_simple_json_list.size() == 0:
        return


    var _cost = 0

    var _cost_pre = select_node.price

    var upgrade_num = 0

    var _upgrade_soldier_uid = select_node.json.uid

    for _index in range(_count):
        var _is_money_enough: = WSData.update_money(- _cost_pre)
        if not _is_money_enough:

            break

        _cost += _cost_pre

        var _simple_json = upgrade_simple_json_list.pop_front()


        _simple_json.exp -= SoldierUtils.get_upgrade_need_exp02(get_uid(), _upgrade_soldier_uid)
        _simple_json.uid = _upgrade_soldier_uid


        if _upgrade_soldier_uid.begins_with("mod_player_guard"):

            GlobalSoldierInfo.soldier_cache_info.erase(_simple_json.uid)
            SoldierUtils.repair_simple_json(_simple_json)
        else:
            SoldierUtils.remove_simple_json_equip_field(_simple_json)
            SoldierUtils.repair_simple_json(_simple_json)

        upgrade_num += 1

        if upgrade_simple_json_list.size() == 0:
            break

    if _cost > 0:

        self._update_remain_num(true)

        if remain_num <= 0:
            for soldier_box: SoldierBox in upgrade_soldier_root_node.get_children():
                soldier_box.set_button_disable(true)

        upgrade_finish_sign.emit()

        eg_money_interface_node.init()


        GlobalMessageInterface.add_upgrade_soldier_message(upgrade_num, _cost)
    else:

        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.INSUFFICIENT_FUNDS)

func _view_info(_soldier_prop: BSSoldierProp)-> void:
    view_info_sign.emit(_soldier_prop)

func _on_close_button_pressed():
    _clear()
    self.hide()
    close_sign.emit()


func _on_upgrade_button_c_pressed():
    _upgrade(1)


func _on_upgrade_5_button_c_pressed():
    _upgrade(5)

func _on_origin_soldier_box_view_info_sign(_soldier_prop: BSSoldierProp)-> void:
    view_info_sign.emit(_soldier_prop)