class_name TeamExchangeInterface extends Control

@onready var team_list_interface_node: TeamListInterface =$TeamListInterface
@onready var barracks_list_interface_node: TeamListInterface =$BarracksListInterface
@onready var equipment_info_and_transfer_func_interface_node: EquipmentInfoAndTransferFuncInterface =$EquipmentInfoAndTransferFuncInterface

@onready var max_nop_tip_node: Tip =$MaxNopTip

var choose_node: TeamItemSoldierInterface
var left_simple_json_list: Array
var right_simple_json_list: Array
var allow_nop: = 0
var location_code: = ""

signal close_page_sign()

var test_list = [
    {
        "uid": "wild_soldier_0013_02",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0013_02",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0013_02",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0006",
        "htype": 0,
    },
]

var test_list2 = [
    {
        "uid": "wild_soldier_0014",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0014",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0013_02",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0015",
        "htype": 0,
    },
    {
        "uid": "wild_soldier_0015",
        "htype": 0,
    },
]







func init_by_location_code(_location_code: String)-> void:
    location_code = _location_code
    var max_nop: int = LocationBuildUtils.get_barracks_max_nop(_location_code)

    set_allow_nop(max_nop)
    init(WSData.get_player_team_simple_json_list(), WSLocationData.get_barracks_team_info(_location_code))

func set_allow_nop(_nop: int)-> void:
    allow_nop = _nop

func init(
    _left_simple_json_list: Array,
     _right_simple_json_list: Array,
    _select_pre_left: bool = false,
    _select_pre_right: = false,
    _need_init_sort_assistance_data: = true
)-> void:
    left_simple_json_list = _left_simple_json_list.duplicate(false)
    right_simple_json_list = _right_simple_json_list.duplicate(false)
    equipment_info_and_transfer_func_interface_node.hide_content()
    team_list_interface_node.init(
        _left_simple_json_list, _select_pre_left,
        _need_init_sort_assistance_data
    )
    barracks_list_interface_node.init(
        _right_simple_json_list, _select_pre_right,
        _need_init_sort_assistance_data
    )

    team_list_interface_node.update_nop_limit(WSData.get_player_nop_limit())
    barracks_list_interface_node.update_nop_limit(allow_nop)






    if _right_simple_json_list.size() > allow_nop:
        max_nop_tip_node.show()

    else:
        max_nop_tip_node.hide()


func cshow()-> void:
    self.show()

func chide()-> void:
    self.hide()
    _clear()

func _refresh(_select_pre_left: bool = false, _select_pre_right: = false):
    init(
        left_simple_json_list, right_simple_json_list,
        _select_pre_left, _select_pre_right,
        false
    )

func _clear()-> void:
    choose_node = null
    left_simple_json_list = []
    right_simple_json_list = []
    allow_nop = 0
    location_code = ""

    equipment_info_and_transfer_func_interface_node.clear()
    team_list_interface_node.clear()
    barracks_list_interface_node.clear()


func _on_team_list_interface_bchoose(_node: Variant)-> void:
    choose_node = _node
    equipment_info_and_transfer_func_interface_node.init(_node.soldier_prop, _node.get_total(), true)
    equipment_info_and_transfer_func_interface_node.cancel_choose_equipment()
    barracks_list_interface_node.cancel_choose()


func _on_barracks_list_interface_bchoose(_node: Variant)-> void:
    choose_node = _node
    equipment_info_and_transfer_func_interface_node.init(_node.soldier_prop, _node.get_total(), false)
    equipment_info_and_transfer_func_interface_node.cancel_choose_equipment()
    team_list_interface_node.cancel_choose()


func _on_equipment_info_and_transfer_func_interface_to_right_sign(_count: int)-> void:
    if CommonUtils.is_null(choose_node):
        return


    var _remain_nop: int = allow_nop - right_simple_json_list.size()

    if _remain_nop <= 0:
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.GARRISON_LIMIT_EXCEEDED)
        return

    if _remain_nop < _count:
        _count = _remain_nop
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.GARRISON_LIMIT_EXCEEDED)

    var _soldier_split_group_uid: = choose_node.get_split_group_uid()
    var _transfer_soldier_simple_json_list: Array = team_list_interface_node.pop_simple_json_list(_soldier_split_group_uid, _count, true)
    if ArrayUtils.is_empty(_transfer_soldier_simple_json_list):
        return

    ArrayUtils.remove_ele(left_simple_json_list, _transfer_soldier_simple_json_list)
    right_simple_json_list.append_array(_transfer_soldier_simple_json_list)
    _refresh(true, false)

func _on_close_button_pressed()-> void:
    chide()
    close_page_sign.emit()


func _on_equipment_info_and_transfer_func_interface_to_left_sign(_count: int)-> void:
    if CommonUtils.is_null(choose_node):
        return




    var _nop_limit: int = WSData.get_player_nop_limit()
    var _remain_nop: = _nop_limit - left_simple_json_list.size()
    if _remain_nop <= 0:
        GlobalMessageInterface.add_message_exceeded_troop_limit()
        return

    if _remain_nop < _count:
        _count = _remain_nop
        GlobalMessageInterface.add_message_exceeded_troop_limit()

    var _soldier_split_group_uid: = choose_node.get_split_group_uid()
    var _transfer_soldier_simple_json_list: Array = barracks_list_interface_node.pop_simple_json_list(_soldier_split_group_uid, _count, false)
    if ArrayUtils.is_empty(_transfer_soldier_simple_json_list):
        return

    ArrayUtils.remove_ele(right_simple_json_list, _transfer_soldier_simple_json_list)
    left_simple_json_list.append_array(_transfer_soldier_simple_json_list)
    _refresh(false, true)


func _on_take_all_button_pressed()-> void:
    left_simple_json_list.append_array(right_simple_json_list)
    right_simple_json_list.clear()
    _refresh(true, false)


func _on_save_button_pressed()-> void:
    if StringUtils.is_not_empty(location_code):
        WSData.get_player_data().team = left_simple_json_list
        WSLocationData.save_barracks_team_info(location_code, right_simple_json_list)
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_BARRACKS_TEAM_INFO_SUCCESS)

    _on_close_button_pressed()