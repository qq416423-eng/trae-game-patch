extends VBoxContainer
class_name WeaponIconList

func init(_prop: BSSoldierProp):
    var _field_list = ["weapon1_json", "weapon2_json", "weapon3_json"]
    var _index = 0
    for _field in _field_list:
        var _node = self.get_children()[_index]
        var _path = GoodsUtils.get_weapon_icon(
            CommonUtils.get_value(_prop[_field], "uid", null)
        )
        if StringUtils.is_not_empty(_path):
            CommonUtils.update_texture2(_node, _path)
            _node.show()
        else:
            _node.hide()

        _index += 1