class_name ImportantMessageBox extends Control

@onready var content_node: Label =$BIBackground / Content
@onready var option_root_node: VBoxContainer =$BIBackground / OptionRoot
@onready var message_icon_node: TextureRect =$BIBackground / MessageIconRoot / MessageIcon
@onready var message_icon_root_node: TextureRect =$BIBackground / MessageIconRoot

const QUESTION_PAGE_OPTION_BUTTON = preload("res://tscn/baseModule/QuestionPageOptionButton.tscn")

signal close_page_sign()

var test_json: = {
    "content": "测试问题",
    "options": [
        {
            "name": "回答1"
        },
        {
            "name": "回答2"
        }
    ]
}

func _ready()-> void:


    pass

func init_by_message_type_enum(_message_type_enum: String)-> void:
    var _json: Dictionary = ImportantMessageData.MESSAGE_DATA.get(_message_type_enum)
    init(_json)

func init_by_message_type_enum_dic(_message_type_enum_dic: Dictionary)-> void:
    var _json: Dictionary = ImportantMessageData.MESSAGE_DATA.get(_message_type_enum_dic.type).duplicate(true)
    if CommonUtils.get_value(_json, "replace_str_from_params", false):
        _json["replace_str_list"] = _message_type_enum_dic.replace_str_list
    init(_json)

func init(_message_json: Dictionary)-> void:
    CommonUtils.set_text(
        content_node,
        DialogueUtils.handle_str_from_func(
            _message_json.content,
            CommonUtils.get_value(_message_json, "str_from_func",[])
        ) \
        if not CommonUtils.get_value(_message_json, "replace_str_from_params", false) else \
        StringUtils.replace(_message_json.content, _message_json.replace_str_list, "#")
    )

    for _option_json: Dictionary in _message_json.options:
        var _node: QuestionPageOptionButton = QUESTION_PAGE_OPTION_BUTTON.instantiate()
        option_root_node.add_child(_node)
        _node.init2(_option_json.name)
        _node.connect("pressed_sign", _choose_option)

    if _message_json.has("icon"):
        message_icon_root_node.show()
        CommonUtils.update_texture2(message_icon_node, _message_json.icon)
    else:
        message_icon_root_node.hide()

func cshow()-> void:
    show()

func chide()-> void:
    _clear()
    hide()
    close_page_sign.emit()

func _choose_option(_node: QuestionPageOptionButton)-> void:
    self.chide()

func _clear()-> void:
    CommonUtils.clear_node(option_root_node)