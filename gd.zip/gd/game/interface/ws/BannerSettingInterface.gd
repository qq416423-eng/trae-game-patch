class_name BannerSettingInterface extends Control

@onready var shape_list_node: GridContainer =$LeftRoot / Background / EditBannerRoot / SelectionRoot / ShapeRoot / ShapeList
@onready var color_list_node: GridContainer =$LeftRoot / Background / EditBannerRoot / SelectionRoot / ColorRoot / ColorList
@onready var part_select_button_list_node: PartSelectButtonList =$LeftRoot / PartSelectButtonList
@onready var lord_banner_node: LordBanner =$RightRoot / PreviewRoot / Background / LordBanner

const BANNER_SHAPE_SELECT_BUTTON = preload("res://tscn/baseModule/button/BannerShapeSelectButton.tscn")
const COLOR_SELECT_BUTTON = preload("res://tscn/baseModule/button/ColorSelectButton.tscn")
const BANNER_EMBLEM_SELECT_BUTTON = preload("res://tscn/baseModule/button/BannerEmblemSelectButton.tscn")







var banner_config: = {}
var selected_shape_node: BannerShapeSelectButton
var selected_shape_color_node: ColorSelectButton
var selected_emblem_node: BannerEmblemSelectButton

signal save_sign(_banner_config: Dictionary)
signal close_sign()

func _ready()-> void:

    pass

func init(_banner_config: Dictionary)-> void:
    banner_config = _banner_config.duplicate(true)

    if banner_config.size() == 0:
        banner_config = BannerUtils.random_banner_config()


    part_select_button_list_node.select(0, true)

func cshow()-> void:
    self.show()

func chide()-> void:
    _clear_shape_root_node()
    _clear_color_root_node()
    self.hide()


func _init_shape()-> void:
    _clear_shape_root_node()
    var _shape_is_selected: = false
    var _select_node: BannerShapeSelectButton
    for _shape_code: String in BannerData.SHAPE_DATA_DIC.keys():
        var _node: BannerShapeSelectButton = BANNER_SHAPE_SELECT_BUTTON.instantiate()
        shape_list_node.add_child(_node)
        _node.init(_shape_code)
        _node.connect("choose_sign", _choose_shape)
        if not _shape_is_selected and banner_config.shape_code == _shape_code:


            _select_node = _node
            _shape_is_selected = true


    if not _shape_is_selected:
        CommonUtils.get_node_list_active_first(shape_list_node.get_children()).choose()
    else:
        _select_node.choose()

func _init_emblem()-> void:
    _clear_shape_root_node()
    var _emblem_is_selected: = false
    var _select_node: BannerEmblemSelectButton
    for _emblem_code: String in BannerData.EMBLEM_DATA_DIC.keys():
        var _emblem_data: Dictionary = BannerData.EMBLEM_DATA_DIC.get(_emblem_code)
        if not CommonUtils.get_value(_emblem_data, "visible", true):
            continue

        var _node: BannerEmblemSelectButton = BANNER_EMBLEM_SELECT_BUTTON.instantiate()
        shape_list_node.add_child(_node)
        _node.init(
            {
                "shape_code": banner_config.shape_code,
                "shape_color": banner_config.shape_color,
                "emblem_code": _emblem_code,
                "emblem_color": Color.WHITE,
            }
        )
        _node.connect("choose_sign", _choose_emblem)
        if not _emblem_is_selected and banner_config.emblem_code == _emblem_code:

            _select_node = _node
            _emblem_is_selected = true


    if not _emblem_is_selected:
        CommonUtils.get_node_list_active_first(shape_list_node.get_children()).choose()
    else:
        _select_node.choose()

func _choose_emblem(_selected_emblem_node: BannerEmblemSelectButton)-> void:
    var _emblem_code: String = _selected_emblem_node.get_emblem_code()
    banner_config.emblem_code = _emblem_code

    if CommonUtils.is_not_null(selected_emblem_node):
        selected_emblem_node.unchoose()

    selected_emblem_node = _selected_emblem_node

    _clear_color_root_node()
    var _color_is_selected: = false
    for _color: Color in BannerData.EMBLEM_DATA_DIC.get(_emblem_code).color:
        var _node: ColorSelectButton = COLOR_SELECT_BUTTON.instantiate()
        color_list_node.add_child(_node)
        _node.connect("choose_sign", _choose_emblem_color)
        _node.init(_color)
        if not _color_is_selected and _node.color == banner_config.emblem_color:
            _node.choose()
            _color_is_selected = true


    if not _color_is_selected:
        CommonUtils.get_node_list_active_first(color_list_node.get_children()).choose()

    _custom_choose_emblem()

func _custom_choose_emblem()-> void:
    pass

func _choose_shape(_selected_node: BannerShapeSelectButton)-> void:
    var _shape_code: String = _selected_node.shape_code
    banner_config.shape_code = _shape_code

    if CommonUtils.is_not_null(selected_shape_node):
        selected_shape_node.unchoose()

    selected_shape_node = _selected_node

    _clear_color_root_node()
    var _color_is_selected: = false
    for _color: Color in BannerData.SHAPE_DATA_DIC.get(_shape_code).color:
        var _node: ColorSelectButton = COLOR_SELECT_BUTTON.instantiate()
        color_list_node.add_child(_node)
        _node.connect("choose_sign", _choose_shape_color)
        _node.init(_color)
        if not _color_is_selected and _node.color == banner_config.shape_color:
            _node.choose()
            _color_is_selected = true


    if not _color_is_selected:
        CommonUtils.get_node_list_active_first(color_list_node.get_children()).choose()

    _custom_choose_shape()

func _custom_choose_shape()-> void:
    pass

func _choose_shape_color(_selected_node: ColorSelectButton)-> void:
    banner_config.shape_color = _selected_node.color
    if CommonUtils.is_not_null(selected_shape_color_node):
        selected_shape_color_node.unchoose()

    selected_shape_color_node = _selected_node


    for _node in shape_list_node.get_children():
        if CommonUtils.is_not_null(_node):

            _node.update_color(_selected_node.color)

    _refresh_preview_banner()

    _custom_choose_shape_color()

func _custom_choose_shape_color()-> void:
    pass

func _choose_emblem_color(_selected_node: ColorSelectButton)-> void:
    banner_config.emblem_color = _selected_node.color
    if CommonUtils.is_not_null(selected_shape_color_node):
        selected_shape_color_node.unchoose()

    selected_shape_color_node = _selected_node



    for _node in shape_list_node.get_children():
        if CommonUtils.is_not_null(_node):

            _node.update_emblem_color(_selected_node.color)

    _refresh_preview_banner()

    _custom_choose_emblem_color()

func _custom_choose_emblem_color()-> void:
    pass

func _refresh_preview_banner()-> void:
    lord_banner_node.init_by_banner_config(banner_config)

func _clear_shape_root_node()-> void:
    CommonUtils.clear_node(shape_list_node)

func _clear_color_root_node()-> void:
    CommonUtils.clear_node(color_list_node)

func _on_part_select_button_list_choose_sign(_value: String)-> void:
    match _value:
        "Shape":
            _init_shape()
        "Emblem":
            _init_emblem()

func _on_close_button_custom_pressed()-> void:
    self.chide()
    close_sign.emit()

func _on_save_button_custom_pressed()-> void:
    self.chide()
    save_sign.emit(banner_config)


func _on_random_button_custom_pressed()-> void:
    init(BannerUtils.random_banner_config())