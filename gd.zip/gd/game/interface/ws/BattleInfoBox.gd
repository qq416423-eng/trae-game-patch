class_name BattleInfoBox extends Control

const JOIN_BATTLE_TEAM_DETAIL_INFO_TITLE_ITEM = preload("res://tscn/game/interface/ws/JoinBattleTeamDetailInfoTitleItem.tscn")
const JOIN_BATTLE_TEAM_DETAIL_TEAM_INFO_ITEM = preload("res://tscn/game/interface/ws/JoinBattleTeamDetailTeamInfoItem.tscn")

@onready var left_info_root_node: VBoxContainer =$LeftInfoRoot
@onready var right_info_root_node: VBoxContainer =$RightInfoRoot


var left_total: = 0
var right_total: = 0

var round_left_nop: = 0

var round_right_nop: = 0



func init_by_battle_id(_battle_id: String)-> void:
    var _battle_data: Dictionary = WSData.get_battle_data(_battle_id)

    if not CommonUtils.get_value(_battle_data, "load_by_team_node", true):

        WSData.get_player_team_node().refresh_nop_info()
        left_total = WSData.get_player_active_nop()

        right_total = TeamUtils.list_living_soldier_json(_battle_data.enemy_team).size()
        var _nop_info: Dictionary = TeamUtils.get_turn_sides_soldier_nop_info(
            GlobalPlayerConfig.get_battle_unit_limit(),
            left_total, 0, right_total
        )
        round_left_nop = _nop_info.player_nop
        round_right_nop = _nop_info.enemy_nop
    else:
        var _team_node_info = WSData.get_battle_team_type_info(
            _battle_id,
            WSData.get_player_team_node().get_uid()
        )

        _team_node_info.ally.push_front(WSData.get_player_team_node())
        init(_team_node_info.ally, _team_node_info.enemy)

func init(

    _left_team_node_list: Array,
    _right_team_node_list: Array,
)-> void:

    for _mw_team_node: MWTeam in _left_team_node_list:

        _mw_team_node.refresh_nop_info()

    for _mw_team_node: MWTeam in _right_team_node_list:

        _mw_team_node.refresh_nop_info()

    var _left_active_nop = TeamUtils.get_active_nop(_left_team_node_list)
    var _left_title_node: JoinBattleTeamDetailInfoTitleItem = JOIN_BATTLE_TEAM_DETAIL_INFO_TITLE_ITEM.instantiate()
    left_info_root_node.add_child(_left_title_node)
    _left_title_node.init("我方部队", _left_active_nop, Color("0277bd"))

    for _mw_team_node: MWTeam in _left_team_node_list:
        var _team_info_node: = JOIN_BATTLE_TEAM_DETAIL_TEAM_INFO_ITEM.instantiate()
        left_info_root_node.add_child(_team_info_node)
        _team_info_node.init(_mw_team_node)
        if _mw_team_node.is_player:
            _team_info_node.update_font_color(Color("eede4f"))

    var _right_active_nop = TeamUtils.get_active_nop(_right_team_node_list)
    var _right_title_node: JoinBattleTeamDetailInfoTitleItem = JOIN_BATTLE_TEAM_DETAIL_INFO_TITLE_ITEM.instantiate()
    right_info_root_node.add_child(_right_title_node)
    _right_title_node.init("敌方部队", _right_active_nop, Color("e6465a"))

    for _mw_team_node: MWTeam in _right_team_node_list:
        var _team_info_node: = JOIN_BATTLE_TEAM_DETAIL_TEAM_INFO_ITEM.instantiate()
        right_info_root_node.add_child(_team_info_node)
        _team_info_node.init(_mw_team_node)

    left_total = _left_active_nop
    right_total = _right_active_nop
    var _nop_info: Dictionary = TeamUtils.get_turn_sides_soldier_nop_info(
        GlobalPlayerConfig.get_battle_unit_limit(),
        _left_active_nop, 0, _right_active_nop
    )
    round_left_nop = _nop_info.player_nop
    round_right_nop = _nop_info.enemy_nop

func clear()-> void:
    CommonUtils.clear_node(left_info_root_node)
    CommonUtils.clear_node(right_info_root_node)