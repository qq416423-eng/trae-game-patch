extends CanvasLayer

@onready var scene_transition_ani_node: SceneTransitionAni =$SceneTransitionAni
@onready var battle_info_box_node: BattleInfoBox =$BattleInfoBox
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var title_root_node: Control =$TitleRoot
@onready var single_round_info_root_node: Control =$TitleRoot / SingleRoundInfoRoot
@onready var mult_round_info_root_node: Control =$TitleRoot / MultRoundInfoRoot
@onready var signle_round_total_nop_info: Tip =$TitleRoot / SingleRoundInfoRoot / TotalNopInfo
@onready var mult_round_title_2_node: Tip =$TitleRoot / MultRoundInfoRoot / Title2
@onready var mult_round_total_nop_info_node: Tip =$TitleRoot / MultRoundInfoRoot / TotalNopInfo
@onready var mult_round_round_nop_info_node: Tip =$TitleRoot / MultRoundInfoRoot / RoundNopInfo
@onready var mult_round_total_and_round_nop_info_node: Tip =$TitleRoot / MultRoundInfoRoot / TotalAndRoundNopInfo
@onready var mult_round_animation_player_node: AnimationPlayer =$TitleRoot / MultRoundInfoRoot / AnimationPlayer

signal fade_out_ani_finish_sign()
signal fade_in_ani_finish_sign()

func _ready()-> void:
    scene_transition_ani_node.hide()
    battle_info_box_node.hide()
    battle_info_box_node.modulate.a = 0.0
    title_root_node.hide()
    title_root_node.modulate.a = 0.0

func init_info(
    _battle_id: String,
    _is_first_init: bool
)-> void:
    battle_info_box_node.init_by_battle_id(_battle_id)


    var _is_mult_round_battle: = true
    if _is_first_init:
        if GlobalPlayerConfig.get_battle_unit_limit() >= \
        battle_info_box_node.left_total + battle_info_box_node.right_total:
            _is_mult_round_battle = false
    else:
        _is_mult_round_battle = true

    if _is_mult_round_battle:

        mult_round_info_root_node.show()
        single_round_info_root_node.hide()

        CommonUtils.set_text(
            mult_round_title_2_node,
            "第 " + str(GlobalTempData.mult_battle_current_round_num) + " 回合"
        )








        CommonUtils.set_text(
            mult_round_total_and_round_nop_info_node,
            str(battle_info_box_node.round_left_nop) + "/" + str(battle_info_box_node.left_total) \
            + " 本回合人数/总人数 " + str(battle_info_box_node.round_right_nop) \
            + "/" + str(battle_info_box_node.right_total)
        )
        mult_round_animation_player_node.play("title_ani")
    else:

        mult_round_info_root_node.hide()
        single_round_info_root_node.show()

        CommonUtils.set_text(
            signle_round_total_nop_info,
            str(battle_info_box_node.left_total) + " 总人数 " + str(battle_info_box_node.right_total)
        )


func play_fade_out(
    _show_battle_info: = true
)-> void:
    scene_transition_ani_node.show()
    battle_info_box_node.show()
    title_root_node.show()
    scene_transition_ani_node.play_fade_out()

    if _show_battle_info:
        animation_player_node.play("show_info")


func play_fade_in()-> void:
    scene_transition_ani_node.play_fade_in()

func _on_scene_transition_ani_fade_in_ani_finish_sign()-> void:
    scene_transition_ani_node.hide()
    battle_info_box_node.hide()
    battle_info_box_node.modulate.a = 0.0
    battle_info_box_node.clear()

    fade_in_ani_finish_sign.emit()

func _on_scene_transition_ani_fade_out_ani_finish_sign()-> void:
    fade_out_ani_finish_sign.emit()