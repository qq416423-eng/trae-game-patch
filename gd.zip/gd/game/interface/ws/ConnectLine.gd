class_name ConnectLine extends Line2D

func init(_list: PackedVector2Array, _datum_point: Vector2):
    for _index in range(_list.size()):
        _list[_index] -= _datum_point

    self.points = _list
    self.default_effect()

func focus_effect():
    self.z_index = 1
    self.width = 2
    self.modulate = CommonConstants.COLOR_ENUM.WHITE

func click_effect():
    self.z_index = 1
    self.width = 4
    self.modulate = CommonConstants.COLOR_ENUM.YELLOW

func default_effect():
    self.z_index = 0
    self.width = 2
    self.modulate = CommonConstants.COLOR_ENUM.GREY