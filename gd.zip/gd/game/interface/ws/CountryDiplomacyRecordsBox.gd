class_name CountryDiplomacyRecordsBox extends HBoxContainer

@onready var diplomacy_icon_node: TextureRect =$DiplomacyIcon
@onready var content_node: RichTextLabel =$CenterContainer / Content

func init(_country_diplomacy_records_item_dic: Dictionary)-> void:
    var _player_country_code: String = SoldierUtils.get_player_belong_country()

    var _origin_country_name: String = CountryUtils.get_country_name_by_country_code(_country_diplomacy_records_item_dic.origin_country_code)
    var _target_country_name: String = CountryUtils.get_country_name_by_country_code(_country_diplomacy_records_item_dic.target_country_code)

    var _highlight_color = "#FFD043"

    if _country_diplomacy_records_item_dic.rel_value < 0:
        content_node.text = "第" + str(int(_country_diplomacy_records_item_dic.system_counter)) + \
        "天 | " \
        +("[color=" + _highlight_color + "]" + _origin_country_name + "[/color]" if StringUtils.equals(_player_country_code, _country_diplomacy_records_item_dic.origin_country_code) else _origin_country_name) \
        + " 向 " \
        +("[color=" + _highlight_color + "]" + _target_country_name + "[/color]" if StringUtils.equals(_player_country_code, _country_diplomacy_records_item_dic.target_country_code) else _target_country_name) \
        + " [color=#E05252]宣战[/color]"
        CommonUtils.update_texture2(diplomacy_icon_node, "res://resource/icon/smallIcon/hostile_icon_20.png")
    else:
        content_node.text = "第" + str(int(_country_diplomacy_records_item_dic.system_counter)) + \
        "天 | " \
        +("[color=" + _highlight_color + "]" + _origin_country_name + "[/color]" if StringUtils.equals(_player_country_code, _country_diplomacy_records_item_dic.origin_country_code) else _origin_country_name) \
        + " 与 " \
        +("[color=" + _highlight_color + "]" + _target_country_name + "[/color]" if StringUtils.equals(_player_country_code, _country_diplomacy_records_item_dic.target_country_code) else _target_country_name) \
        + " [color=#52E0A5]达成停战协议[/color]"
        CommonUtils.update_texture2(diplomacy_icon_node, "res://resource/icon/smallIcon/allied_icon_18.png")