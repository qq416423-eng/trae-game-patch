class_name DialogueOptionContentBox extends Control


@onready var rich_content_node: RichTextLabel =$Background / CenterContainer / RichContent

func init(_content: String)-> void:
    rich_content_node.text = "[center]" + _content + "[/center]"