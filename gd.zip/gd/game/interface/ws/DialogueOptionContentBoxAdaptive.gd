class_name DialogueOptionContentBoxAdaptive extends PanelContainer

@onready var rich_content_node: RichTextLabel =$RichContent

func init(_content: String)-> void:
    rich_content_node.text = "[center]" + _content + "[/center]"