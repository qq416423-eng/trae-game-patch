class_name EGMoneyInterface extends Control

@onready var base_money_node =$HBoxContainer / BaseMoney
@onready var change_money_node =$HBoxContainer / ChangeMoney
@onready var h_box_container_node =$HBoxContainer


@export var alignment: = BoxContainer.AlignmentMode.ALIGNMENT_CENTER

var change_money = 0

func init(_money = null):
    if _money == null:
        _money = WSData.get_player_money()

    h_box_container_node.alignment = alignment

    CommonUtils.set_text(base_money_node, int(_money))
    update_change_money(0)

func update_change_money(_change_money):
    change_money = _change_money

    if _change_money == 0:
        change_money_node.hide()
    elif _change_money > 0:
        change_money_node.show()
        CommonUtils.set_text(change_money_node, "(+" + str(_change_money) + ")", CommonConstants.COLOR_ENUM.GREEN)
    else:
        change_money_node.show()
        CommonUtils.set_text(change_money_node, "(" + str(_change_money) + ")", CommonConstants.COLOR_ENUM.RED)

func get_change_money():
    return change_money

func reset():
    update_change_money(0)