extends Control

@onready var equipment_box_toggle_node = preload("res://tscn/game/interface/soldier/EquipmentBoxToggle.tscn")
@onready var equipment_box_root_node =$BoxRoot / ContentRoot / EquipmentBoxRoot
@onready var equipment_detail_interface_node =$BoxRoot / EquipmentDetailInterface
@onready var submit_button_node =$BoxRoot / ContentRoot / ButtonRoot / SubmitButton
@onready var shop_money_interface_node =$BoxRoot / ContentRoot / ShopMoneyInterface

signal cancel_sign()
signal submit_sign()

var team_node_uid: = ""
var test_json: = [
    {
        "item": {
            "uid": "food_0011",
        },
        "count": 1
    },
    {
        "item": {
            "uid": "food_0010",
        },
        "count": 2
    },
    {
        "item": {
            "uid": "oh_sword_0008",
            "quality": 4
        },
        "count": 1
    },
]

func _ready():

    pass


func init(_goods_simple_json_list: Array, _team_node_uid: String)-> void:
    team_node_uid = _team_node_uid

    for _simple_json in _goods_simple_json_list:
        var equipment_box_instance = equipment_box_toggle_node.instantiate() as EquipmentBox
        equipment_box_root_node.add_child(equipment_box_instance)
        equipment_box_instance.init_by_simple_json(_simple_json)
        equipment_box_instance.connect("b_pressed", _choose_equipment_box)

    shop_money_interface_node.init()
    _update_price_and_button()

func chide():
    hide()
    _clear()


func _update_price_and_button():
    var _dif_price: = _get_dif_price()
    shop_money_interface_node.update_change_money(- _dif_price)

    if _dif_price > 0:
        submit_button_node.disabled = false
    else:
        submit_button_node.disabled = true

func _get_dif_price()-> int:
    var _dif_price: = 0.0
    for _equipment_box_node: EquipmentBox in equipment_box_root_node.get_children():
        if _equipment_box_node.is_selected():
            _dif_price += _equipment_box_node.json.price * _equipment_box_node.count

    return int(_dif_price)

func _choose_equipment_box(_node: EquipmentBox):
    equipment_detail_interface_node.init(_node.json)
    equipment_detail_interface_node.ishow()
    _update_price_and_button()

func _clear()-> void:
    CommonUtils.clear_node(equipment_box_root_node)
    equipment_detail_interface_node.close()
    submit_button_node.disabled = true
    team_node_uid = ""

func _get_dif_goods_simple_json_list(_is_selected: = true)-> Array:
    var _json_list: Array = []
    for _equipment_box_node: EquipmentBox in equipment_box_root_node.get_children():
        if _equipment_box_node.is_selected() == _is_selected:
            _json_list.append(_equipment_box_node.simple_json.duplicate(true))

    return _json_list

func _save_exchange_treasure():
    var _json_list: Array = _get_dif_goods_simple_json_list(false)
    var _team_node: MWTeam = WSData.get_team_node(team_node_uid)
    _team_node.update_exchange_treasure(_json_list)


func _on_cancel_button_pressed():
    chide()
    cancel_sign.emit()


func _on_submit_button_pressed():
    var _buy_goods_simple_json_list: Array = _get_dif_goods_simple_json_list()
    if ArrayUtils.is_not_empty(_buy_goods_simple_json_list):
        var _dif_price = shop_money_interface_node.get_change_money()
        var _success = WSData.update_money(_dif_price, true)
        if not _success:

            return

        WSData.add_my_goods(_buy_goods_simple_json_list)

        _save_exchange_treasure()

    chide()
    submit_sign.emit()