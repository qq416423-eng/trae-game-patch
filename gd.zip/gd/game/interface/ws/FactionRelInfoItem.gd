class_name FactionRelInfoItem extends HBoxContainer

@onready var faction_color_pic_node: TextureRect =$FactionColorPic

@onready var faction_rel_node: Label =$FactionRel
@onready var lord_banner_node: LordBanner =$BannerRoot / LordBanner
@onready var rel_icon_node: TextureRect =$RelIcon

@onready var faction_name_node: Label =$FactionNameButton / VBoxContainer / FactionName
@onready var faction_name_v_box_container_node: VBoxContainer =$FactionNameButton / VBoxContainer

var country_code: String = ""

signal choose_faction_sign(_country_code: String)

func init_by_country_code(
    _country_code: String,
    _rel_value: int,
    _start_counter: float
)-> void:
    country_code = _country_code
    var _country_name: String = CountryUtils.get_country_name_by_country_code(_country_code)
    var _country_color: Color = CountryUtils.get_country_color(_country_code)
    var _king_uid: String = CountryUtils.get_king_uid_by_country_code(_country_code)

    var _country_rel_type_content: = "敌对"
    var _country_rel_type_color: Color = Color("#d02000")

    var country_team_rel_type_enum: = TeamUtils.get_rel_type_enum_by_rel_value(_rel_value)

    match country_team_rel_type_enum:
        MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE:

            var _hostile_days: int = int(WSData.get_system_counter() - _start_counter) if _start_counter > 0 else 0
            _country_rel_type_content = "敌对(" + str(_hostile_days) + "天)"
            _country_rel_type_color = Color("#a80000")
            CommonUtils.update_texture2(rel_icon_node, "res://resource/icon/smallIcon/hostile_icon_20.png")
        MWTeamConstants.TEAM_REL_TYPE_ENUM.NEUTRAL:

            if _start_counter > 0:
                _country_rel_type_content = "中立(" + str(int(WSData.get_system_counter() - _start_counter)) + "天)"
            else:
                _country_rel_type_content = "中立"
            _country_rel_type_color = Color("#4a3a2a")

            rel_icon_node.texture = null
        MWTeamConstants.TEAM_REL_TYPE_ENUM.ALLIED:
            _country_rel_type_content = "同盟"
            _country_rel_type_color = Color("#208020")
            CommonUtils.update_texture2(rel_icon_node, "res://resource/icon/smallIcon/allied_icon_18.png")

    init(
        _country_color, _king_uid, _country_name,
        _country_rel_type_content, _country_rel_type_color
    )

func init(
    _faction_color: Color, king_uid: String,
    faction_name: String, faction_rel_content: String,
    faction_rel_content_color: Color
)-> void:
    faction_color_pic_node.self_modulate = _faction_color

    CommonUtils.set_text(faction_name_node, faction_name)
    lord_banner_node.init_by_hero_uid(king_uid)
    CommonUtils.set_text(faction_rel_node, faction_rel_content, faction_rel_content_color)

func update_faction_name_color(_color: Color)-> void:
    CommonUtils.update_color(faction_name_v_box_container_node, _color)

func _on_faction_name_button_custom_pressed()-> void:
    choose_faction_sign.emit(country_code)