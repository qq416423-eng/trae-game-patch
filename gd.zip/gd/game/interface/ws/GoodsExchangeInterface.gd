extends Control
class_name GoodsExchangeInterface

@onready var equipment_detail_interface_node =$Other / EquipmentDetailInterface as EquipmentDetailInterface
@onready var left_show_equipment_detail_interface_point_node =$LeftGoodsListInterface / ShowEquipmentDetailInterfacePoint
@onready var right_show_equipment_detail_interface_point_node =$RightGoodsListInterface / ShowEquipmentDetailInterfacePoint
@onready var soldier_equipment_interface_node =$HeroInfoRoot / SoldierEquipmentInterface as SoldierEquipmentInterface
@onready var mid_show_equipment_detail_interface_point =$HeroInfoRoot / ShowEquipmentDetailInterfacePoint
@onready var left_goods_list_interface_node =$LeftGoodsListInterface as GoodsListInterface
@onready var right_goods_list_interface_node =$RightGoodsListInterface as GoodsListInterface
@onready var button_root_node =$ButtonRoot
@onready var eg_money_interface_node =$HeroInfoRoot / EGMoneyInterface as EGMoneyInterface
@onready var confirm_box_node =$SubPageRoot / ConfirmBox as ConfirmBox
@onready var remark_button_node =$ButtonRoot / RemarkButton
@onready var close_button_node =$ButtonRoot / CloseButton
@onready var sell_all_button_node =$ButtonRoot / SellAllButton
@onready var buy_all_button_node =$ButtonRoot / BuyAllButton
@onready var remark_box_node =$RightGoodsListInterface / RemarkBox as ContentBox
@onready var equip_cancel_button_node: CommonButton2 =$HeroInfoRoot / EquipCancelButton
@onready var store_funds_insufficient_confirm_box_node: ConfirmBox =$SubPageRoot / StoreFundsInsufficientConfirmBox
@onready var remain_loot_confirm_box_node: ConfirmBox =$SubPageRoot / RemainLootConfirmBox
@onready var goods_category_button_list_for_shop_node: GoodsCategoryButtonListForShop =$LeftGoodsListInterface / GoodsCategoryButtonListForShop
@onready var change_category_confirm_box_node: ConfirmBox =$SubPageRoot / ChangeCategoryConfirmBox
@onready var soldier_prop_with_background_interface_node: SoldierPropWithBackgroundInterface =$RightGoodsListInterface / SoldierPropWithBackgroundInterface


@export var right_goods_title: String = ""

@export var is_show_right_goods_flag_pic: bool = true

@export var is_need_compute_price: bool = true
@export var goods_exchange_type_enum: String = CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION

@export var is_hide_equipment_detail_equip_button: = false

var select_node
var equip_replacing

var change_money = 0

var expected_change_money = 0

var init_change_money = 0
var left_price_ratio: = 1.0

var location_type_enum: String = ""
var current_location_code: = ""
var sell_etype_list = []



signal close_sign()

func _ready():
    if StringUtils.is_not_empty(right_goods_title):
        right_goods_list_interface_node.update_title(right_goods_title)


    right_goods_list_interface_node.show_or_hide_flag_pic(is_show_right_goods_flag_pic)

    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:

            remark_button_node.show()
            close_button_node.hide()
            sell_all_button_node.hide()
        CommonConstants.GOODS_EXCHANGE_TYPE.MY_ITEMS:

            remark_button_node.hide()
            sell_all_button_node.hide()
            buy_all_button_node.hide()
        CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:

            remark_button_node.show()
            buy_all_button_node.hide()
        CommonConstants.GOODS_EXCHANGE_TYPE.WAREHOUSE:
            remark_button_node.hide()
            close_button_node.hide()



    equipment_detail_interface_node.update_is_hide_equipment_detail_equip_button(is_hide_equipment_detail_equip_button)
    _custom_ready()

func _custom_ready()-> void:
    soldier_equipment_interface_node.hero_select_interface_node.enable_hero_list_scroll()
















func init_base(
    _left_goods_json: Array, _other_goods_json: Array, _team_data: Dictionary,
    _left_price_ratio: = GoodsConfig.MY_ITEMS_PRICE_RATIO,
    _right_price_ratio: = 1.0,
    _left_commodity_price_ratio: = MWConfig.MY_COMMODITY_ITEMS_PRICE_RATIO,
    _need_clear_category_show: = true,
    _select_pre_hero: bool = false
):




    left_price_ratio = _left_price_ratio


    left_goods_list_interface_node.init(_left_goods_json, _left_price_ratio, _left_commodity_price_ratio, _need_clear_category_show)
    right_goods_list_interface_node.init(_other_goods_json, _right_price_ratio)

    if not _team_data.is_empty():
        soldier_equipment_interface_node.init_select(
            SoldierUtils.get_hero_json_list(_team_data.team),
            _select_pre_hero
        )
        eg_money_interface_node.init(_team_data.money)

    if is_need_compute_price:
        right_goods_list_interface_node.update_is_show_money(true)


func init_location_shop(_location_code: String, _location_type_enum: String):
    location_type_enum = _location_type_enum
    current_location_code = _location_code
    sell_etype_list = LocationConstants.get_sell_etype(_location_type_enum)



    _handle_temp_grocery_price_info()


    left_goods_list_interface_node.set_sell_etype_list(sell_etype_list)

    init(WSLocationData.get_goods_json(_location_code, _location_type_enum))


    right_goods_list_interface_node.update_flag_style(_location_type_enum)


    right_goods_list_interface_node.init_shop_money(WSLocationData.get_shop_money(_location_code, _location_type_enum))


    if WSLocationData.get_location_type(_location_code) == LocationConstants.LOCATION_TYPE_ENUM.CITY:
        goods_category_button_list_for_shop_node.clear()
        goods_category_button_list_for_shop_node.choose(_location_type_enum)
        left_show_category([_location_type_enum])
        goods_category_button_list_for_shop_node.show_ani()
    else:
        goods_category_button_list_for_shop_node.hide()
        left_show_category([_location_type_enum])

func init(
    _other_goods_json = [],
    _need_clear_category_show: = true,

    _select_pre_hero: = false
):
    if goods_exchange_type_enum == CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:
        pass
    else:

        sell_etype_list = []


    var _price_ratio = SkillUtils.get_skill_trade_effect_ratio(WSData.get_player_team_node().team_info.skill_trade)
    var _left_price_ratio: float = 1.0 + _price_ratio
    var _right_price_ratio: float = 1.0 - _price_ratio


    var _left_commodity_price_ratio = _left_price_ratio * MWConfig.MY_COMMODITY_ITEMS_PRICE_RATIO
    _left_price_ratio = _left_price_ratio * GoodsConfig.MY_ITEMS_PRICE_RATIO

    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:
            init_base(
                WSData.player_data.goods, _other_goods_json, WSData.player_data,
                _left_price_ratio, _right_price_ratio,
                _left_commodity_price_ratio,
                _need_clear_category_show,
                _select_pre_hero
            )
        CommonConstants.GOODS_EXCHANGE_TYPE.MY_ITEMS:
            init_base(
                WSData.player_data.goods,[], WSData.player_data,
                _left_price_ratio, _right_price_ratio,
                _left_commodity_price_ratio,
                _need_clear_category_show,
                _select_pre_hero
            )
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:
            init_base(
                WSData.player_data.goods, _other_goods_json, WSData.player_data,
                _left_price_ratio, 1.0,
                _left_commodity_price_ratio,
                _need_clear_category_show,
                _select_pre_hero
            )


    _update_remark_box_content()


func init_warehouse_base(_location_code: String, _left_goods: Array, _right_goods: Array, _right_count_limit: int)-> void:
    current_location_code = _location_code
    right_goods_list_interface_node.show_goods_count_info()
    right_goods_list_interface_node.set_goods_count_limit(_right_count_limit)
    init_base(_left_goods, _right_goods,{})
    left_show_save_category_and_need_save()
    right_goods_list_interface_node.update_flag_style(LocationConstants.CITY_LOCATION_TYPE_ENUM.WAREHOUSE)

func set_change_money(_money: int):
    init_change_money = _money
    change_money = init_change_money
    expected_change_money = change_money
    _update_price_change_node()

func cshow()-> void:

    self.show()


func left_show_save_category_and_need_save()-> void:
    left_goods_list_interface_node.update_need_save_category_show(true)
    left_goods_list_interface_node.show_category_save()

func left_show_category(_loaction_type_enum_list: Array)-> void:
    left_goods_list_interface_node.show_category(_loaction_type_enum_list)


func _handle_temp_grocery_price_info():
    var _temp_json = null
    if location_type_enum == LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY:
        _temp_json = {}
        var _city_data = WSLocationData.get_city_data(current_location_code)
        for _goods_code in _city_data.specialty_grocery:
            var _count = LocationUtils.get_goods_count(_city_data.goods_grocery, _goods_code)
            _temp_json[_goods_code] = {
                "real_production_capacity": LocationUtils.get_real_production_capacity(_city_data, _city_data.specialty_grocery.get(_goods_code)),
                "count": _count
            }


        for _goods_simple_json: Dictionary in _city_data.goods_grocery:
            if not _temp_json.has(_goods_simple_json.item.uid):
                _temp_json[_goods_simple_json.item.uid] = {
                    "real_production_capacity": 0,
                    "count": _goods_simple_json.count
                }

    GlobalTempData.set_grocery_price_info(_temp_json)

func _update_remark_box_content():
    var _text = ""
    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:
            var _player_node: MWTeam = WSData.get_player_team_node()
            _text = "当前团队交易等级: {0}\n购买物品价格减少 {1}%\n卖出物品价格提高 {2}%" \

            + ""
            _text = StringUtils.replace(
                _text,[
                    _player_node.team_info.skill_trade,
                    int(SkillUtils.get_skill_trade_effect_ratio(_player_node.team_info.skill_trade) * 100),
                    int(SkillUtils.get_skill_trade_effect_ratio(_player_node.team_info.skill_trade) * 100)
                ]
            )
        CommonConstants.GOODS_EXCHANGE_TYPE.MY_ITEMS:
            pass
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:
            var _player_node: MWTeam = WSData.get_player_team_node()
            _text = "当前团队掠夺等级: {0}\n战利品掉落率提高 {1}%"
            _text = StringUtils.replace(
                _text,[
                    _player_node.team_info.skill_plunder,
                    int(SkillUtils.get_skill_plunder_effect_ratio(_player_node.team_info.skill_plunder) * 100)
                ]
            )

    remark_box_node.set_text(_text)

func _adjust_remark_box_position():
    remark_box_node.global_position = \
    remark_button_node.global_position - Vector2(remark_box_node.size.x + 4, 0)

func _button_forbid():
    for _child in button_root_node.get_children():
        _child.disable()

func _cancel_button_forbid():
    for _child in button_root_node.get_children():
        _child.cancel_disable()

func _all_area_forbid():
    left_goods_list_interface_node.forbid()
    right_goods_list_interface_node.forbid()
    _button_forbid()

func _all_area_cancel_forbid():
    left_goods_list_interface_node.cancel_forbid()
    right_goods_list_interface_node.cancel_forbid()
    _cancel_button_forbid()


func _maybe_compute_price_and_update_node():
    if not is_need_compute_price:
        return

    _compute_price()
    _update_price_change_node()

    right_goods_list_interface_node.update_change_money(- change_money)


func _compute_price():
    var _left_change_money = left_goods_list_interface_node.compute_price()
    var _right_change_money = right_goods_list_interface_node.compute_price()
    var _mid_change_money = soldier_equipment_interface_node.compute_price()
    change_money = init_change_money + _right_change_money - _left_change_money - _mid_change_money
    expected_change_money = change_money

    if change_money > right_goods_list_interface_node.get_origin_shop_money():
        change_money = right_goods_list_interface_node.get_origin_shop_money()

        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SHOP_NO_BALANCE)

func _update_price_change_node():
    eg_money_interface_node.update_change_money(change_money)

func _clear():
    left_goods_list_interface_node.clear()
    right_goods_list_interface_node.clear()
    soldier_equipment_interface_node.clear()
    change_money = 0
    init_change_money = 0
    expected_change_money = 0

func _refresh():
    init(right_goods_list_interface_node.json, false, true)

func _save()-> bool:

    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:
            var _success = WSData.update_money(change_money, true)
            if not _success:

                return false


            WSLocationData.save_shop_money(current_location_code, location_type_enum, - change_money)
            right_goods_list_interface_node.init_shop_money(WSLocationData.get_shop_money(current_location_code, location_type_enum))







            var _change_excess_goods: = int(expected_change_money * LocationConfig.MONEY_TRAN_RESOURCE_VALUE_RATIO)
            if _change_excess_goods != 0:
                WSLocationData.plus_excess_goods(current_location_code, _change_excess_goods, - _change_excess_goods)
        CommonConstants.GOODS_EXCHANGE_TYPE.MY_ITEMS:
            pass
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:
            WSData.update_money(change_money, true)
        CommonConstants.GOODS_EXCHANGE_TYPE.WAREHOUSE:
            pass




    var _left_goods_json_list = GoodsUtils.organize_goods(left_goods_list_interface_node.json)
    var _right_goods_json_list = GoodsUtils.organize_goods(right_goods_list_interface_node.json)
    right_goods_list_interface_node.json = _right_goods_json_list

    WSData.save_my_goods(_left_goods_json_list)

    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:
            WSLocationData.save_city_goods(current_location_code, location_type_enum, _right_goods_json_list)
        CommonConstants.GOODS_EXCHANGE_TYPE.MY_ITEMS:
            pass
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:
            pass
        CommonConstants.GOODS_EXCHANGE_TYPE.WAREHOUSE:

            WSLocationData.save_warehouse_data(current_location_code, _right_goods_json_list)


    soldier_equipment_interface_node.save()

    change_money = 0
    expected_change_money = 0
    return true

func _close():
    self.hide()
    self._clear()
    equipment_detail_interface_node.close()
    soldier_equipment_interface_node.reset_hero_select_interface()
    close_sign.emit()

func _maybe_refresh_commodity_price(_uid):
    if not location_type_enum == LocationConstants.CITY_LOCATION_TYPE_ENUM.GROCERY:
        return

    left_goods_list_interface_node.refresh_commodity_price(_uid)
    right_goods_list_interface_node.refresh_commodity_price(_uid)

func _equip_weapon_finish_follow(_node):
    equip_replacing = false

    _all_area_cancel_forbid()
    equip_cancel_button_node.hide()
    soldier_equipment_interface_node.cancel_show_allow_exchange_area_weapon()
    _node.call_deferred("cancel")


func _on_left_goods_list_interface_bchoose(_node: GoodsBox):
    select_node = _node
    equipment_detail_interface_node.init(_node.goods_json)





    var _button_group_enum = GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.LEFT_GOODS
    if _node.is_lock:
        _button_group_enum = GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.LEFT_GOODS_LOCK

    equipment_detail_interface_node.init_button(
        _button_group_enum, _node.allow_sell,
        _node.allow_equip, not _node.is_new
    )
    equipment_detail_interface_node.ishow(
        Vector2(
            left_show_equipment_detail_interface_point_node.global_position.x,
            _node.get_detail_show_position().y
        )
    )


    right_goods_list_interface_node.unchoose()
    soldier_equipment_interface_node.cancel_choose_equipment()


func _on_right_goods_list_interface_bchoose(_node: GoodsBox):
    select_node = _node

    equipment_detail_interface_node.init(_node.goods_json)





    equipment_detail_interface_node.init_button(
        GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.RIGHT_GOODS,
        false, _node.allow_equip
    )
    equipment_detail_interface_node.ishow(
        Vector2(
            right_show_equipment_detail_interface_point_node.global_position.x,
            _node.get_detail_show_position().y
        )
    )


    left_goods_list_interface_node.unchoose()
    soldier_equipment_interface_node.cancel_choose_equipment()


func _on_soldier_equipment_interface_choose_equipment(_node):

    if equip_replacing:

        left_goods_list_interface_node.unchoose()
        right_goods_list_interface_node.unchoose()

        match select_node.is_right:
            false:
                left_goods_list_interface_node.subtract(select_node.get_item_json(), 1)
            true:
                right_goods_list_interface_node.subtract(select_node.get_item_json(), 1)

        var _old_item_json = soldier_equipment_interface_node.update_equip(_node.field, select_node.get_item_json())
        left_goods_list_interface_node.add(_old_item_json, 1)

        if select_node.is_right:
            _maybe_compute_price_and_update_node()







        _equip_weapon_finish_follow(_node)
        return

    select_node = _node


    if GoodsUtils.is_null_json(_node.json):
        equipment_detail_interface_node.ihide()
        return

    equipment_detail_interface_node.init(_node.json, left_price_ratio)






    var _allow_sell: = true
    if ArrayUtils.is_not_empty(sell_etype_list):
        var _etype = WeaponTypeConstants.get_etype(_node.json.uid)
        if not sell_etype_list.has(_etype):
            _allow_sell = false

    equipment_detail_interface_node.init_button(GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.MID_GOODS, _allow_sell)
    equipment_detail_interface_node.ishow(
        Vector2(
            mid_show_equipment_detail_interface_point.global_position.x,
            _node.get_detail_show_position().y
        )
    )

    left_goods_list_interface_node.unchoose()
    right_goods_list_interface_node.unchoose()


func _on_equipment_detail_interface_to_right(_count: int):
    GlobalLoadPage.load_open()


    var _prep_count = left_goods_list_interface_node.get_goods_count(select_node.get_item_json())
    if _prep_count > _count:
        _prep_count = _count


    if right_goods_list_interface_node.check_is_over_goods_count_limit(_prep_count):
        _prep_count = right_goods_list_interface_node.get_remain_capacity()
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.OVER_GOODS_COUNT_LIMIT)

    if _prep_count > 0:

        var _subtract_info: Dictionary = left_goods_list_interface_node.subtract(select_node.get_item_json(), _prep_count)
        right_goods_list_interface_node.add(select_node.get_item_json(), _subtract_info.subtract_count)
        if _subtract_info.is_sell_out:
            equipment_detail_interface_node.ihide()

    _maybe_refresh_commodity_price(select_node.get_item_json().uid)
    _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()


func _on_left_goods_list_interface_exchange_sign(_node):
    GlobalLoadPage.load_open()

    if select_node != null:
        select_node = null

    equipment_detail_interface_node.ihide()
    left_goods_list_interface_node.unchoose()
    right_goods_list_interface_node.unchoose()
    var _count: = 1

    if right_goods_list_interface_node.check_is_over_goods_count_limit(_count):
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.OVER_GOODS_COUNT_LIMIT)
        GlobalLoadPage.load_close()
        return

    left_goods_list_interface_node.subtract(_node.get_item_json(), _count)
    right_goods_list_interface_node.add(_node.item_json, _count)

    _maybe_refresh_commodity_price(_node.item_json.uid)
    _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()


func _on_equipment_detail_interface_to_left(_count: int):
    GlobalLoadPage.load_open()



    var _subtract_info: Dictionary = right_goods_list_interface_node.subtract(select_node.get_item_json(), _count)
    left_goods_list_interface_node.add(select_node.get_item_json(), _subtract_info.subtract_count)
    if _subtract_info.is_sell_out:
        equipment_detail_interface_node.ihide()

    _maybe_refresh_commodity_price(select_node.get_item_json().uid)
    _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()


func _on_right_goods_list_interface_exchange_sign(_node):
    GlobalLoadPage.load_open()
    if select_node != null:
        select_node = null

    left_goods_list_interface_node.unchoose()
    right_goods_list_interface_node.unchoose()

    right_goods_list_interface_node.subtract(_node.get_item_json(), 1)
    left_goods_list_interface_node.add(_node.get_item_json(), 1)
    equipment_detail_interface_node.ihide()

    _maybe_refresh_commodity_price(_node.get_item_json().uid)
    _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()


func _on_equipment_detail_interface_m_to_left():
    if select_node == null:
        return

    GlobalLoadPage.load_open()

    var _item_json = select_node.get_item_json()
    if not _item_json.has("price_ratio"):
        _item_json.price_ratio = left_price_ratio

    soldier_equipment_interface_node.cancel_choose_equipment()
    left_goods_list_interface_node.add(_item_json, 1)
    soldier_equipment_interface_node.update_equip(select_node.field, null)
    equipment_detail_interface_node.ihide()

    GlobalLoadPage.load_close()


func _on_equipment_detail_interface_m_to_right():
    if select_node == null:
        return

    GlobalLoadPage.load_open()

    var _item_json = select_node.get_item_json()

    _item_json.lock = false

    if not _item_json.has("price_ratio"):
        _item_json.price_ratio = left_price_ratio

    soldier_equipment_interface_node.cancel_choose_equipment()
    right_goods_list_interface_node.add(_item_json, 1)
    soldier_equipment_interface_node.update_equip(select_node.field, null)
    equipment_detail_interface_node.ihide()
    _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()



func _on_equipment_detail_interface_equip(_group_enum):
    if select_node == null:
        return

    GlobalLoadPage.load_open()

    equipment_detail_interface_node.ihide()


    var _field = WeaponTypeConstants.get_field(select_node.get_item_json().uid)
    if _field == "weapon":
        _all_area_forbid()
        equip_cancel_button_node.show()


        soldier_equipment_interface_node.show_allow_exchange_area_weapon()
        equip_replacing = true
    else:
        left_goods_list_interface_node.unchoose()
        right_goods_list_interface_node.unchoose()

        var _old_item_json = soldier_equipment_interface_node.update_equip(_field, select_node.get_item_json())

        var _need_compute_price = false

        match _group_enum:
            GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.LEFT_GOODS, \
            GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.LEFT_GOODS_LOCK:
                left_goods_list_interface_node.subtract(select_node.get_item_json(), 1)
            GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.RIGHT_GOODS:
                right_goods_list_interface_node.subtract(select_node.get_item_json(), 1)
                _need_compute_price = true

        left_goods_list_interface_node.add(_old_item_json, 1)
        if _need_compute_price:
            _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()


func _on_close_button_custom_pressed()-> void:



















    if _check_has_unsave_transaction():
        confirm_box_node.open()
        return


    _save()
    _close()


func _on_equipment_detail_interface_lock():
    if CommonUtils.is_null(select_node):
        return

    select_node.lock()


    var _item_uid = select_node.get_item_json().uid
    var _goods_list = WSData.get_player_goods()
    for _goods_simple_json in _goods_list:
        if _goods_simple_json.item.uid == _item_uid:
            _goods_simple_json.item.lock = true
            break

    equipment_detail_interface_node.init_button(
        GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.LEFT_GOODS_LOCK,
        false, select_node.allow_equip
    )


func _on_equipment_detail_interface_unlock():
    if CommonUtils.is_null(select_node):
        return

    select_node.unlock()


    var _item_uid = select_node.get_item_json().uid
    var _goods_list = WSData.get_player_goods()
    for _goods_simple_json in _goods_list:
        if _goods_simple_json.item.uid == _item_uid:
            _goods_simple_json.item.lock = false
            break

    equipment_detail_interface_node.init_button(
        GoodsConstants.EQUIPMENT_DETAIL_INTERFACE_BUTTON_GROUP_ENUM.LEFT_GOODS,
        select_node.allow_sell, select_node.allow_equip, not select_node.is_new
    )


func _on_sell_all_button_custom_pressed()-> void:
    GlobalLoadPage.load_open()


    var _left_json: = left_goods_list_interface_node.get_visible_goods_json().duplicate(true)
    for _left_json_item in _left_json:
        if not CommonUtils.get_value(_left_json_item.item, "lock", false):

            if ArrayUtils.is_not_empty(sell_etype_list):
                var _etype = WeaponTypeConstants.get_etype(_left_json_item.item.uid)
                if not sell_etype_list.has(_etype):
                    continue


            var _count: int = _left_json_item.count
            var _real_count: int = _count
            if right_goods_list_interface_node.check_is_over_goods_count_limit(_count):
                _real_count = right_goods_list_interface_node.get_remain_capacity()

            if _real_count > 0:
                left_goods_list_interface_node.subtract(_left_json_item.item, _real_count)
                right_goods_list_interface_node.add(_left_json_item.item, _real_count)

            if _real_count < _count:
                GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.OVER_GOODS_COUNT_LIMIT)
                break

    equipment_detail_interface_node.ihide()

    _maybe_refresh_commodity_price(null)
    _maybe_compute_price_and_update_node()

    GlobalLoadPage.load_close()


func _on_restore_button_custom_pressed()-> void:
    GlobalLoadPage.load_open()
    equipment_detail_interface_node.ihide()
    soldier_equipment_interface_node.cancel_choose_equipment()

    _handle_temp_grocery_price_info()

    left_goods_list_interface_node.restore()
    right_goods_list_interface_node.restore()
    if goods_exchange_type_enum != CommonConstants.GOODS_EXCHANGE_TYPE.WAREHOUSE:
        soldier_equipment_interface_node.restore()

    _maybe_compute_price_and_update_node()

    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.REVOCATION_SUCCESS)
    GlobalLoadPage.load_close()


func _on_save_button_custom_pressed()-> void:
    GlobalLoadPage.load_open()
    equipment_detail_interface_node.ihide()
    soldier_equipment_interface_node.cancel_choose_equipment()

    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.LOCATION:

            if change_money < expected_change_money:
                store_funds_insufficient_confirm_box_node.open()
                store_funds_insufficient_confirm_box_node.update_content(
                    StringUtils.replace(
                        "店铺余额不足, 本应支付 {0} 德里, 然而仅剩 {1} 德里可支付",
                        [expected_change_money, change_money]
                    )
                )
                GlobalLoadPage.load_close()
                return
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:

            if not right_goods_list_interface_node.is_empty():
                remain_loot_confirm_box_node.open()
                GlobalLoadPage.load_close()
                return

    _confirm_save_maybe_close()

    GlobalLoadPage.load_close()

func _confirm_save_maybe_close()-> void:
    var _success: = _save()
    if not _success:
        return

    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_SUCCESS)
    match goods_exchange_type_enum:
        CommonConstants.GOODS_EXCHANGE_TYPE.WAREHOUSE:
            self._close()
            return
        CommonConstants.GOODS_EXCHANGE_TYPE.TROPHY:
            self._close()
            return


    _refresh()


func _check_has_unsave_transaction()-> bool:

    var _has_change_goods = left_goods_list_interface_node.is_has_change_goods()
    if _has_change_goods:
        return true


    _has_change_goods = right_goods_list_interface_node.is_has_change_goods()
    if _has_change_goods:
        return true


    _has_change_goods = soldier_equipment_interface_node.is_has_change_goods()
    if _has_change_goods:
        return true

    return false

func _hide_soldier_prop_with_background_interface_node()-> void:
    soldier_prop_with_background_interface_node.chide()
    button_root_node.show()

func _show_soldier_prop_with_background_interface_node()-> void:
    soldier_prop_with_background_interface_node.show()
    _refresh_soldier_prop_with_background_interface_node(false)
    button_root_node.hide()

func _refresh_soldier_prop_with_background_interface_node(_need_show_stat_diff: bool)-> void:
    if soldier_prop_with_background_interface_node.visible:
        soldier_prop_with_background_interface_node.init(
            soldier_equipment_interface_node.get_soldier_prop(),
            _need_show_stat_diff
        )


func _on_soldier_equipment_interface_change_hero():
    equipment_detail_interface_node.ihide()
    soldier_equipment_interface_node.cancel_choose_equipment()
    _refresh_soldier_prop_with_background_interface_node(false)

func _on_confirm_box_cancel():
    _close()

func _on_confirm_box_confirm():
    var _success: = _save()
    if not _success:
        return

    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_SUCCESS)
    _close()


func _on_buy_all_button_custom_pressed()-> void:
    GlobalLoadPage.load_open()
    var _right_json = right_goods_list_interface_node.json.duplicate(true)
    for _right_json_item in _right_json:
        if not CommonUtils.get_value(_right_json_item.item, "lock", false):
            right_goods_list_interface_node.subtract(_right_json_item.item, _right_json_item.count)
            left_goods_list_interface_node.add(_right_json_item.item, _right_json_item.count)

    _maybe_refresh_commodity_price(null)
    _maybe_compute_price_and_update_node()

    equipment_detail_interface_node.ihide()

    GlobalLoadPage.load_close()


func _on_remark_button_custom_pressed()-> void:
    _adjust_remark_box_position()
    remark_box_node.visible = not remark_box_node.visible

func _on_right_goods_list_interface_commodity_price_need_refresh(_uid):
    left_goods_list_interface_node.refresh_commodity_price(_uid)
    right_goods_list_interface_node.refresh_commodity_price(_uid)


func _on_equip_cancel_button_pressed()-> void:






    _equip_weapon_finish_follow(select_node)

func _on_left_goods_list_interface_change_goods_category_show_sign()-> void:
    equipment_detail_interface_node.ihide()
    soldier_equipment_interface_node.cancel_choose_equipment()


func _on_store_funds_insufficient_confirm_box_confirm()-> void:
    _confirm_save_maybe_close()

func _on_remain_loot_confirm_box_confirm()-> void:
    _confirm_save_maybe_close()

var next_location_type_enum: String = ""

func _on_goods_category_button_list_for_shop_change_category_sign(_location_type_enum: String)-> void:

    var _has_unsave_transaction = _check_has_unsave_transaction()
    if _has_unsave_transaction:
        change_category_confirm_box_node.open()
        next_location_type_enum = _location_type_enum
        return


    init_location_shop(current_location_code, _location_type_enum)

func _on_change_category_confirm_box_cancel()-> void:
    pass

func _on_change_category_confirm_box_confirm()-> void:
    var _success: = _save()
    if not _success:
        return

    init_location_shop(current_location_code, next_location_type_enum)


func _on_show_soldeir_prop_button_custom_pressed()-> void:
    if soldier_prop_with_background_interface_node.visible:
        _hide_soldier_prop_with_background_interface_node()
    else:
        _show_soldier_prop_with_background_interface_node()

func _on_soldier_prop_with_background_interface_hide_sign()-> void:
    button_root_node.show()

func _on_soldier_equipment_interface_change_equipment_sign()-> void:

    _refresh_soldier_prop_with_background_interface_node(true)