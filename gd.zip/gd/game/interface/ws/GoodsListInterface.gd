extends Control
class_name GoodsListInterface

@onready var goods_box_node = preload("res://tscn/game/interface/soldier/GoodsBox.tscn")
@onready var goods_right_box_node = preload("res://tscn/game/interface/soldier/GoodsRightBox.tscn")
@onready var grid_container_node =$BaseScrollContainer / GridContainer
@onready var forbid_area_node =$ForbidArea
@onready var flag_root_node =$FlagRoot
@onready var title_node =$Background / TitleBackground / Title
@onready var flag_icon_node =$FlagRoot / Background / FlagIcon
@onready var money_title_node =$Background / TitleBackgroundMoney / Title
@onready var title_background_node =$Background / TitleBackground
@onready var title_background_money_node =$Background / TitleBackgroundMoney
@onready var shop_money_interface_node =$Background / TitleBackgroundMoney / ShopMoneyInterface
@onready var goods_category_button_list_node: GoodsCategoryButtonList =$GoodsCategoryButtonList
@onready var base_scroll_container_node: ScrollContainer =$BaseScrollContainer
@onready var title_background_count_limit_node: NinePatchRect =$Background / TitleBackgroundCountLimit
@onready var limit_info_node: Label =$Background / TitleBackgroundCountLimit / LimitInfo
@onready var count_limit_title_node: Label =$Background / TitleBackgroundCountLimit / Title

@export var is_right: = false
@export var show_flag: = false
@export var title: String

@export var consider_sell_etype: = false



var select_node = null
var json: = []
var pre_json: = []
var price_ratio: = 1.0
var commodity_price_ratio_origin: = 1.0
var sell_etype_list: = []
var is_show_money: = false
var shop_money_origin: = 0
var change_money: = 0
var need_save_category_show: = false

var goods_count_limit: = -1

var goods_count: = -1

var need_refresh_goods_count: = false

signal bchoose(_node)
signal exchange_sign(_node)

signal change_goods_category_show_sign()

var test_json = [
    {
        "item": {
            "uid": "oh_sword_0001",
            "quality": 4
        },
        "count": 5
    },
    {
        "item": {
            "uid": "oh_shield_0001"
        },
        "count": 10
    }
]

func _ready():

    if show_flag:
        flag_root_node.show()
    else:
        flag_root_node.hide()

    if StringUtils.is_not_empty(title):
        update_title(title)







func init(
    _json: Array,
    _price_ratio: = 1.0,
    _commodity_price_ratio_origin: = 1.0,
    _need_clear_category_show: = true
):
    clear(_need_clear_category_show)
    price_ratio = _price_ratio
    commodity_price_ratio_origin = _commodity_price_ratio_origin

    json = _json.duplicate(true)
    pre_json = _json.duplicate(true)

    for _ritem_json in json:
        _ritem_json.item.price_ratio = _price_ratio


        if GoodsUtils.is_commodity(_ritem_json.item.uid):
            var _plus_count = 0
            if not is_right:
                _plus_count = 1

            var _commodity_price_ratio = GlobalTempData.get_commodity_price_ratio(_ritem_json.item.uid, _plus_count)
            _ritem_json.item.commodity_price_ratio = _commodity_price_ratio
            _ritem_json.item.price_ratio = _commodity_price_ratio_origin


        if is_right:
            _ritem_json.item.origin = GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS
        else:
            _ritem_json.item.origin = GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS





        _create_node(_ritem_json, false)

    if not _need_clear_category_show:
        _handle_category_show(goods_category_button_list_node.get_hide_category_list())

    _maybe_refresh_count_info()

func set_sell_etype_list(_sell_etype_list: Array):
    sell_etype_list = _sell_etype_list

func update_title(_title):
    CommonUtils.set_text(title_node, _title)
    CommonUtils.set_text(money_title_node, _title)
    CommonUtils.set_text(count_limit_title_node, _title)

func update_is_show_money(_is_show_money: bool)-> void:
    is_show_money = _is_show_money
    if is_show_money:
        title_background_node.hide()
        title_background_money_node.show()
    else:
        title_background_node.show()
        title_background_money_node.hide()

func show_goods_count_info()-> void:
    need_refresh_goods_count = true
    title_background_node.hide()
    title_background_money_node.hide()
    title_background_count_limit_node.show()

func show_or_hide_flag_pic(_switch):
    if _switch:
        flag_root_node.show()
    else:
        flag_root_node.hide()

func update_flag_style(_location_type_enum: String):
    var _config = LocationConstants.get_city_location_type_config(_location_type_enum)
    update_title(_config.button_name)
    CommonUtils.update_texture2(flag_icon_node, _config.icon)


func restore():
    init(pre_json, price_ratio, commodity_price_ratio_origin, false)


func exchange(_node):
    emit_signal("exchange_sign", _node)

func choose(_node):





    if select_node != null and select_node != _node:
        select_node.cancel()

    select_node = _node
    emit_signal("bchoose", _node)

func unchoose():
    if select_node == null:
        return

    select_node.cancel()
    select_node = null

func forbid():
    forbid_area_node.show()

func cancel_forbid():
    forbid_area_node.hide()







func subtract(_item_json, _count)-> Dictionary:
    var _result_info: Dictionary = _subtract_node(_item_json, _count)

    GoodsUtils.subtract_goods_simple_json(json, _item_json, _count)


    _maybe_refresh_count_info()

    return _result_info

func add(_item_json, _count):

    if _item_json == null:
        return

    if not _item_json.has("uid"):
        return

    _item_json = _item_json.duplicate(true)

    if not _item_json.has("price_ratio"):
        _item_json.price_ratio = price_ratio

    _add_node(_item_json, _count)
    _add_json(_item_json, _count)


    _maybe_refresh_count_info()

func compute_price():
    return GoodsUtils.compute_price(
        json,
        GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS if is_right else GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS
        )

func is_has_change_goods()-> bool:
    return GoodsUtils.is_has_change_goods(json, GoodsConstants.GOODS_ORIGIN_ENUM.LEFT_GOODS if is_right else GoodsConstants.GOODS_ORIGIN_ENUM.RIGHT_GOODS)









func clear(_need_clear_category_show: = true):
    CommonUtils.clear_node(grid_container_node)

    if _need_clear_category_show:
        goods_category_button_list_node.hide_and_clear()

    need_save_category_show = false

func refresh_commodity_price(_uid)-> void:
    for _node in grid_container_node.get_children():
        if _uid == null or _node.item_json.uid == _uid:
            var _plus_count = 0
            if not is_right:
                _plus_count = 1

            var _commodity_price_ratio = GlobalTempData.get_commodity_price_ratio(_node.item_json.uid, _plus_count)
            _node.refresh_commodity_price(_commodity_price_ratio)

func get_origin_shop_money():
    return shop_money_origin

func init_shop_money(_money: int):
    change_money = 0
    shop_money_origin = _money
    shop_money_interface_node.init(shop_money_origin)

func update_change_money(_change_money: int):
    change_money = _change_money
    shop_money_interface_node.init(shop_money_origin + change_money)

func update_need_save_category_show(_need_save_category_show: bool)-> void:
    need_save_category_show = _need_save_category_show

func show_category(_loaction_type_enum_list: Array)-> void:
    goods_category_button_list_node.update_show_category_list(_loaction_type_enum_list)

func show_category_save()-> void:
    goods_category_button_list_node.show_category_save()


func is_empty()-> bool:
    return json.is_empty()

func set_goods_count_limit(_limit: int)-> void:
    goods_count_limit = _limit


func check_is_over_goods_count_limit(_add_count: int)-> bool:
    if goods_count_limit <= 0:

        return false

    if goods_count_limit - goods_count < _add_count:
        return true

    return false


func get_remain_capacity()-> int:
    return goods_count_limit - goods_count


func get_goods_count(_item_json: Dictionary)-> int:
    for _json: Dictionary in json:
        if GoodsUtils.goods_json_equals(_json.item, _item_json):
            return _json.count

    return 0


func get_visible_goods_json()-> Array:
    var _result: = []
    var _hide_category_list: = goods_category_button_list_node.get_hide_category_list()





    for _goods_box_node: GoodsBox in grid_container_node.get_children():
        if _hide_category_list.has(_goods_box_node.get_city_location_type_enum()):
            pass
        else:
            _result.append(_goods_box_node.ritem_json)

    return _result

func _maybe_refresh_count_info()-> void:
    if need_refresh_goods_count:
        _refresh_count_info()

func _refresh_count_info()-> void:
    goods_count = GoodsUtils.get_goods_count(json)
    CommonUtils.set_text(limit_info_node, str(goods_count) + "/" + str(goods_count_limit))

func _create_node(_ritem_json, _show_new_tag_animation = false):
    var _goods_box_instance = null
    if is_right:
        _goods_box_instance = goods_right_box_node.instantiate()
    else:
        _goods_box_instance = goods_box_node.instantiate()

    grid_container_node.add_child(_goods_box_instance)

    _goods_box_instance.init(_ritem_json)
    _connect_goods_box_sign(_goods_box_instance)

    if consider_sell_etype and ArrayUtils.is_not_empty(sell_etype_list):
        var _etype = WeaponTypeConstants.get_etype(_ritem_json.item.uid)
        if not sell_etype_list.has(_etype):
            _goods_box_instance.set_allow_sell(false)

    if _show_new_tag_animation:
        _goods_box_instance.call_deferred("show_new_tag_animation")


    return _goods_box_instance

func _add_node(_item_json, _count):
    var _node = _find_node(_item_json)
    if _node == null:
        _node = _create_node(
            {
                "item": _item_json,
                "count": _count,
            },
            true
        )
    else:
        _node.plus_count(_count)
        _node.show_new_tag_animation()

    if is_right:
        var _success = GlobalTempData.update_grocery_price_info(_item_json.uid, _count)




    if goods_category_button_list_node.get_hide_category_list().has(_node.get_city_location_type_enum()):
        _node.hide()

func _add_json(_item_json, _count):
    var _assign_json = null
    for _json in json:
        if GoodsUtils.goods_json_equals(_json.item, _item_json):
            _assign_json = _json

    if _assign_json == null:
        json.append(
            {
                "item": _item_json,
                "count": _count
            }
        )
    else:
        _assign_json.count += _count



func _subtract_node(_item_json, _count)-> Dictionary:
    var _node = _find_node(_item_json)

    if _node == null:
        return {
            "subtract_count": 0,
            "is_sell_out": true
        }

    var _is_sell_out = false
    var _plus_count = 0

    if _node.count > _count:
        _plus_count = - _count
        _node.plus_count(_plus_count)
        _node.show_new_tag_animation()
        _is_sell_out = false
    else:
        _plus_count = - _node.count
        _node.queue_free()
        _is_sell_out = true

    if is_right:
        var _success = GlobalTempData.update_grocery_price_info(_item_json.uid, _plus_count)




    return {
        "subtract_count": - _plus_count,
        "is_sell_out": _is_sell_out
    }















func _find_node(_item_json):
    for _child in grid_container_node.get_children():
        if CommonUtils.is_null(_child):
            continue

        if GoodsUtils.goods_json_equals(_child.item_json, _item_json):
            return _child

    return null

func _connect_goods_box_sign(_node):
    _node.connect("b_pressed", choose)
    _node.connect("exchange", exchange)

func _handle_category_show(_hide_category_list: Array)-> void:
    for _goods_box_node: GoodsBox in grid_container_node.get_children():
        if _hide_category_list.has(_goods_box_node.get_city_location_type_enum()):
            _goods_box_node.hide()
        else:
            _goods_box_node.show()

func _on_goods_category_button_list_change_hide_category_sign(_hide_category_list: Array)-> void:
    _handle_category_show(_hide_category_list)

    if need_save_category_show:
        WSData.save_hide_category_list(_hide_category_list)


    change_goods_category_show_sign.emit()