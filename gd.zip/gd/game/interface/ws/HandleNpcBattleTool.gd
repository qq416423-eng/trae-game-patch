class_name HandleNpcBattleTool extends Node

@onready var timer_node: Timer =$Timer


func _handle_npc_battle(_interval_second: float)-> void:
    for _battle_id: String in WSData.battle_data.keys():
        _handle_npc_battle_by_battle_id(_battle_id, _interval_second)

func _handle_npc_battle_by_battle_id(_battle_id: String, _interval_second: float)-> void:

    var is_mutual_attack: bool = _check_is_mutual_attack_and_plus_wait_time(_battle_id, _interval_second)

    if not is_mutual_attack:
        return

    var _team1_mw_team_node_list: Array = WSData.get_team_node_by_battle_id(_battle_id, MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM1)
    var _team2_mw_team_node_list: Array = WSData.get_team_node_by_battle_id(_battle_id, MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2)


    var _team1_atk: = int(TeamUtils.get_team_atk(_team1_mw_team_node_list) * _interval_second)

    var _team2_atk: = int(TeamUtils.get_team_atk(_team2_mw_team_node_list) * _interval_second)

    if _team1_atk > _team2_atk:
        _team1_atk = min(_team1_atk, _team2_atk * TeamConfig.NPC_BATTLE_ATK_MAX_MULT)
    else:
        _team2_atk = min(_team2_atk, _team1_atk * TeamConfig.NPC_BATTLE_ATK_MAX_MULT)

    _team_hurt(_team2_atk, _team1_mw_team_node_list)

    _team_hurt(_team1_atk, _team2_mw_team_node_list)

    BattleUtils.check_and_handle_battle_end(_battle_id)


func _check_is_mutual_attack_and_plus_wait_time(_battle_uid: String, _interval_second: float)-> bool:
    var _battle_data: Dictionary = WSData.get_battle_data(_battle_uid)
    if not _battle_data.has("duration_frame"):
        _battle_data.duration_frame = 0

    _battle_data.duration_frame += _interval_second * 60

    return _battle_data.duration_frame - _interval_second * 60 >= BattleSceneConfig.NPC_BATTLE_START_WAIT_FRAME

func _team_hurt(_atk: int, _mw_team_node_list: Array)-> void:
    var _nop_total: int = TeamUtils.get_team_active_nop(_mw_team_node_list)

    for _mw_team_node: MWTeam in _mw_team_node_list:
        if _mw_team_node.get_active_nop() == 0:
            continue

        var _atk_pre = _atk * _mw_team_node.get_active_nop() / _nop_total
        _mw_team_node.hurt(_atk_pre)


func _on_timer_timeout()-> void:
    _handle_npc_battle(timer_node.wait_time)