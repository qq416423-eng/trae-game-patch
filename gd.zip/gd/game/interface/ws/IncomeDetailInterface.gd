class_name IncomeDetailInterface extends Control

@onready var remark_node: Label =$Background / RemarkRoot / Remark
@onready var v_box_container_node: VBoxContainer =$Background / BaseScrollContainer / VBoxContainer
@onready var total_income_info_node: KeyValueItemInfo =$Background / TotalIncomeInfo

const KEY_VALUE_ITEM_INFO = preload("res://tscn/game/interface/ws/KeyValueItemInfo.tscn")

signal close_sign()

const _SETTLEMENT_INTERVAL_DAYS = TeamConfig.WAGES_INTERVAL_DAYS

func init()-> void:
    CommonUtils.set_text(
        remark_node,
        ". 每" + str(_SETTLEMENT_INTERVAL_DAYS) + "天结算一次税收\n. 距离下次结算还剩 " \
        + str(_SETTLEMENT_INTERVAL_DAYS - int(WSData.system_counter) % _SETTLEMENT_INTERVAL_DAYS) \
        + " 天"
    )

    var _income_total: int = 0
    for _location_code: String in SoldierUtils.get_player_fief_code_list():

        var _locaton_data: Dictionary = LocationUtils.get_location_data(_location_code)
        var _income: int = CommonUtils.get_value(_locaton_data, "pending_income", 0)

        _income_total += _income

        var _key_value_info_node: = KEY_VALUE_ITEM_INFO.instantiate()
        v_box_container_node.add_child(_key_value_info_node)
        _key_value_info_node.init(
            LocationUtils.get_location_name_by_location_code(_location_code) + "税金",
            str(_income) \
            +(
                    "" if CommonUtils.get_value(_locaton_data, "settlement_income_pre", 0) <= 0 \
                    else "(上次结算" + str(_locaton_data.settlement_income_pre) + ")"
                )
        )

    total_income_info_node.init(
        "待结算税收", _income_total
    )

func _on_close_button_custom_pressed()-> void:
    close_sign.emit()