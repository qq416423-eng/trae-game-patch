class_name IncomeDetailMaskInterface extends Control

@onready var income_detail_interface_node: IncomeDetailInterface =$IncomeDetailInterface

func init()-> void:
    income_detail_interface_node.init()

func _delete()-> void:
    self.queue_free()

func _on_income_detail_interface_close_sign()-> void:
    _delete()