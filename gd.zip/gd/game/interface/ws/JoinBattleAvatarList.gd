class_name JoinBattleAvatarList extends Control

const TEAM_AVATAR = preload("res://tscn/game/interface/ws/TeamAvatar.tscn")


@export var max_count: int = 4

func init(team_node_list: Array)-> void:
    var _temp_index: = team_node_list.size()

    for _index: int in range(team_node_list.size() - 1, -1, -1):
        var _mw_team_node: MWTeam = team_node_list[_index]
        var _team_avatar_node: TeamAvatar = TEAM_AVATAR.instantiate()
        self.add_child(_team_avatar_node)
        _team_avatar_node.init(_mw_team_node)
        _team_avatar_node.position.x =(_temp_index - 1) * 24
        _temp_index -= 1

        if team_node_list.size() - _temp_index > max_count:
            break

func clear()-> void:
    CommonUtils.clear_node(self)