class_name JoinBattleTeamDetailInfoBox extends Control

@onready var v_box_container_node: VBoxContainer =$BIBackground / BaseScrollContainer / VBoxContainer

const JOIN_BATTLE_TEAM_DETAIL_INFO_TITLE_ITEM = preload("res://tscn/game/interface/ws/JoinBattleTeamDetailInfoTitleItem.tscn")
const JOIN_BATTLE_TEAM_DETAIL_LINE_ITEM = preload("res://tscn/game/interface/ws/JoinBattleTeamDetailLineItem.tscn")
const JOIN_BATTLE_TEAM_DETAIL_TEAM_INFO_ITEM = preload("res://tscn/game/interface/ws/JoinBattleTeamDetailTeamInfoItem.tscn")

func init(
    _left_team_node_list: Array,
    _right_team_node_list: Array,
)-> void:
    var _left_active_nop = TeamUtils.get_active_nop(_left_team_node_list)
    var _left_title_node: JoinBattleTeamDetailInfoTitleItem = JOIN_BATTLE_TEAM_DETAIL_INFO_TITLE_ITEM.instantiate()
    v_box_container_node.add_child(_left_title_node)

    _left_title_node.init(_left_team_node_list[0].get_team_name() + "方", _left_active_nop, Color("0277bd"))

    var _temp_is_first: = true
    for _mw_team_node: MWTeam in _left_team_node_list:
        var _team_info_node: = JOIN_BATTLE_TEAM_DETAIL_TEAM_INFO_ITEM.instantiate()
        v_box_container_node.add_child(_team_info_node)
        _team_info_node.init(_mw_team_node)
        if _temp_is_first:
            _temp_is_first = not _temp_is_first
            _team_info_node.update_font_color(Color("eede4f"))

    _temp_is_first = true

    var _line_node: = JOIN_BATTLE_TEAM_DETAIL_LINE_ITEM.instantiate()
    v_box_container_node.add_child(_line_node)

    var _right_active_nop = TeamUtils.get_active_nop(_right_team_node_list)
    var _right_title_node: JoinBattleTeamDetailInfoTitleItem = JOIN_BATTLE_TEAM_DETAIL_INFO_TITLE_ITEM.instantiate()
    v_box_container_node.add_child(_right_title_node)

    _right_title_node.init(_right_team_node_list[0].get_team_name() + "方", _right_active_nop, Color("e6465a"))

    for _mw_team_node: MWTeam in _right_team_node_list:
        var _team_info_node: = JOIN_BATTLE_TEAM_DETAIL_TEAM_INFO_ITEM.instantiate()
        v_box_container_node.add_child(_team_info_node)
        _team_info_node.init(_mw_team_node)
        if _temp_is_first:
            _temp_is_first = not _temp_is_first
            _team_info_node.update_font_color(Color("eede4f"))

func clear()-> void:
    CommonUtils.clear_node(v_box_container_node)