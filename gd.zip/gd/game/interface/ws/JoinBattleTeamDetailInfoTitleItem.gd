class_name JoinBattleTeamDetailInfoTitleItem extends Control

@onready var title_node: Label =$Title
@onready var nop_node: Label =$Nop
@onready var tag_icon_node: TextureRect =$TagIcon

func init(
    _left_text: String, _nop: int,
    _tag_color: Color = Color("9c27b0")
)-> void:
    CommonUtils.set_text(title_node, _left_text)
    CommonUtils.set_text(nop_node, "总人数 " + str(_nop))
    CommonUtils.update_color(tag_icon_node, _tag_color)