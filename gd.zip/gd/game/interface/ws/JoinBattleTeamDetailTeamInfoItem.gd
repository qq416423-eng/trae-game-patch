class_name JoinBattleTeamDetailTeamInfoItem extends Control

@onready var team_avatar_node: TeamAvatar =$TeamAvatar
@onready var name_node: Label =$Name
@onready var nop_node: Label =$Nop

func init(_mw_team_node: MWTeam)-> void:
    team_avatar_node.init(_mw_team_node)
    CommonUtils.set_text(name_node, _mw_team_node.get_team_name())
    CommonUtils.set_text(nop_node, _mw_team_node.get_active_nop())

func update_font_color(_color: Color)-> void:
    CommonUtils.update_color(name_node, _color)
    CommonUtils.update_color(nop_node, _color)