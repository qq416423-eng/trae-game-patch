class_name JoinBattleTeamInfoBox extends Control

@onready var left_join_battle_avatar_list_node: JoinBattleAvatarList =$Button / LeftInfo / JoinBattleAvatarList
@onready var left_nop_info_node: Label =$Button / LeftInfo / NopInfo
@onready var right_join_battle_avatar_list_node: JoinBattleAvatarList =$Button / RightInfo / JoinBattleAvatarList
@onready var right_nop_info_node: Label =$Button / RightInfo / NopInfo
@onready var join_battle_team_detail_info_box_node: JoinBattleTeamDetailInfoBox =$JoinBattleTeamDetailInfoBox
@onready var down_icon_node: TextureRect =$Button / DownIcon
@onready var left_team_name_node: Label =$Button / LeftInfo / TeamName
@onready var right_team_name_node: Label =$Button / RightInfo / TeamName

func init(
    _left_team_node_list: Array,
    _right_team_node_list: Array,
)-> void:
    CommonUtils.set_text(left_team_name_node, _left_team_node_list[0].get_team_name())
    CommonUtils.set_text(right_team_name_node, _right_team_node_list[0].get_team_name())

    left_join_battle_avatar_list_node.init(_left_team_node_list)





    CommonUtils.set_text(
        left_nop_info_node,
        str(TeamUtils.get_active_nop(_left_team_node_list))
    )

    right_join_battle_avatar_list_node.init(_right_team_node_list)





    CommonUtils.set_text(
        right_nop_info_node,
        str(TeamUtils.get_active_nop(_right_team_node_list))
    )

    join_battle_team_detail_info_box_node.init(
        _left_team_node_list, _right_team_node_list
    )

func clear()-> void:
    left_join_battle_avatar_list_node.clear()
    right_join_battle_avatar_list_node.clear()
    join_battle_team_detail_info_box_node.clear()
    join_battle_team_detail_info_box_node.visible = false
    CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/down_icon_16.png")

func chide()-> void:
    clear()
    self.hide()

func cshow()-> void:
    self.show()

func _on_button_b_pressed()-> void:
    join_battle_team_detail_info_box_node.visible = not join_battle_team_detail_info_box_node.visible
    if join_battle_team_detail_info_box_node.visible:
        CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/up_icon_16.png")
    else:
        CommonUtils.update_texture2(down_icon_node, "res://resource/icon/smallIcon/down_icon_16.png")