class_name KeyValueItemInfo extends HBoxContainer

@onready var key_node: Label =$Key
@onready var value_node: Label =$Value

@export var key: = ""
@export var value: = ""

func _ready()-> void:
    init(key, value)

func init(_key: String, _value)-> void:
    CommonUtils.set_text(key_node, _key)

    update_value(_value)

func update_value(_value)-> void:
    CommonUtils.set_text(value_node, str(_value))