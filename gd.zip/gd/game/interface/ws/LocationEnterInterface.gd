class_name LocationEnterInterface extends Control

@onready var platform_root_node =$PlatformRoot
@onready var location_info_panel_node: LocationInfoPanel =$InfoRoot / LocationInfoPanel
@onready var info_root_node: Control =$InfoRoot
@onready var location_build_interface_node: LocationBuildInterface =$FullScreenInterfaceRoot / LocationBuildInterface
@onready var build_button_node: CommonButton =$InfoRoot / BuildButton
@onready var location_build_summary_list_node: LocationBuildSummaryList =$InfoRoot / LocationBuildSummaryList


var build_button_right_node: CommonButton = null

func _ready()-> void:
    _mod_setup_right_build_button()

func _mod_setup_right_build_button()-> void:
    if build_button_right_node != null:
        return


    build_button_right_node = build_button_node.duplicate() as CommonButton
    if build_button_right_node == null:
        return
    build_button_right_node.name = "PrisonBuildButton"

    if build_button_right_node.has_method("update_text"):
        build_button_right_node.update_text("特殊建造")
    elif build_button_right_node.has_node("Text"):
        CommonUtils.set_text(build_button_right_node.get_node("Text"), "特殊建造")

    var _al: float = build_button_node.anchor_left
    var _ar: float = build_button_node.anchor_right
    var _ol: float = build_button_node.offset_left
    var _or: float = build_button_node.offset_right
    var _shift_left: float = 80.0
    build_button_right_node.anchor_left = 1.0 - _ar
    build_button_right_node.anchor_right = 1.0 - _al
    build_button_right_node.offset_left = - _or - _shift_left
    build_button_right_node.offset_right = - _ol - _shift_left

    build_button_node.get_parent().add_child(build_button_right_node)

    build_button_right_node.pressed.connect(_on_prison_build_button_pressed)
    build_button_right_node.hide()

var current_node: MWLocationPlanformBase
var location_code: String

signal close()
signal enter_city_location(_node)

func init(_location_node: MWLocationBase):
    build_button_node.hide()
    if build_button_right_node != null:
        build_button_right_node.hide()
    location_code = _location_node.get_location_code()


    var _planform_path = LocationUtils.get_planform_node_path(_location_node.scene_file_path)
    var _node = CommonUtils.load(_planform_path)
    if _node != null:
        var _node_instance = _node.instantiate()
        platform_root_node.add_child(_node_instance)
        _node_instance.connect("enter_city_location", _on_mw_location_planform_base_enter_city_location)
        current_node = _node_instance

        _node_instance.init_button(_location_node.get_location_code())


    location_info_panel_node.init(_location_node.city_data)



    location_build_summary_list_node.hide()
    if LocationUtils.check_belongs_to_player(location_code):
        build_button_node.show()

        if build_button_right_node != null:
            var _loc_type: String = LocationUtils.get_location_type(location_code)
            if _loc_type == LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
                build_button_right_node.show()
            else:
                build_button_right_node.hide()
        _refresh_location_build_summary_list()

func _refresh_location_build_summary_list()-> void:
    location_build_summary_list_node.init(location_code)

func _clear_data():
    current_node = null
    location_code = ""
    CommonUtils.clear_node(platform_root_node)
    location_build_summary_list_node.clear()

func chide():
    _clear_data()
    self.hide()
    location_info_panel_node.hide_emoji_tip()

func show_button()-> void:
    if self.visible:
        current_node.show_button()
        _show_info()

func _hide_info()-> void:
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(info_root_node, "modulate:a", 0.0, 0.2)

func _show_info()-> void:
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(info_root_node, "modulate:a", 1, 0.2)

func _hide_info_and_card()-> void:
    _hide_info()
    current_node.hide_button()

func _show_info_and_card()-> void:
    _show_info()
    show_button()

func _on_close_button_pressed():


    GlobalLocationData.refresh_location_tag(location_code)

    chide()
    emit_signal("close")



func _on_mw_location_planform_base_enter_city_location(_node: LocationCard):
    if _node.get_type() != LocationConstants.CITY_LOCATION_TYPE_ENUM.HOTEL:
        _hide_info()

    emit_signal("enter_city_location", _node)

func _on_build_button_pressed()-> void:
    GlobalTempData.mod_prison_build_mode = false
    location_build_interface_node.show()
    location_build_interface_node.init(location_code)
    _hide_info_and_card()


func _on_prison_build_button_pressed()-> void:
    GlobalTempData.mod_prison_build_mode = true
    location_build_interface_node.show()
    location_build_interface_node.init(location_code)
    _hide_info_and_card()

func _on_location_build_interface_close_page_sign()-> void:

    GlobalTempData.mod_prison_build_mode = false
    current_node.clear()
    current_node.init_button(location_code)
    _show_info_and_card()
    _refresh_location_build_summary_list()