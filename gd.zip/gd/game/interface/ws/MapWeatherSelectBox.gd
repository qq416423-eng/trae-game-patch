class_name MapWeatherSelectBox extends Control

@onready var map_weather_pic_node: TextureRect =$MapWeatherPic
@onready var button_node: CommonButton =$Button
@onready var select_effect_node: TextureRect =$SelectEffect
@onready var content_node: Label =$Content

var value: = ""
var is_select: = false
var content: = ""

signal choose_sign(_node: MapWeatherSelectBox)

func init_by_map_key(_map_key: String)-> void:
    var _map_config: Dictionary = MapConstants.MAP_CONFIG.get(_map_key)
    init(_map_config.cover_path, _map_key, _map_config.content)

func init_by_weather_key(_weather_key: String)-> void:
    var _weather_config: Dictionary = MWorldConstants.WEATHER_CONFIG.get(_weather_key)
    init(_weather_config.cover_path, _weather_key, _weather_config.content)

func init(_pic_path: String, _value: String, _content: String)-> void:
    value = _value
    content = _content

    CommonUtils.update_texture2(map_weather_pic_node, _pic_path)
    CommonUtils.set_text(content_node, _content)

func unchoose()-> void:
    if not is_select:
        return

    is_select = false
    button_node.disabled = false
    select_effect_node.hide()

func choose()-> void:
    if is_select:
        return

    is_select = true
    button_node.disabled = true
    select_effect_node.show()
    choose_sign.emit(self)

func get_value()-> String:
    return value

func get_content()-> String:
    return content

func _on_button_custom_pressed()-> void:
    choose()