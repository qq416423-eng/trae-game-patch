class_name MapWeatherSelectInterface extends Control

@onready var map_h_box_container_node: HBoxContainer =$BIBackground / MapRoot / HBoxContainer
@onready var weather_h_box_container: HBoxContainer =$BIBackground / WeatherRoot / HBoxContainer
@onready var map_info_node: Label =$BIBackground / MapTitleRoot / MapInfo
@onready var weather_info_node: Label =$BIBackground / WeatherTitleRoot / WeatherInfo

const MAP_WEATHER_SELECT_BOX = preload("res://tscn/game/interface/ws/MapWeatherSelectBox.tscn")

var select_weather_node: MapWeatherSelectBox
var select_map_node: MapWeatherSelectBox

signal confirm_start_battle_sign(
    _map_key: String,
    _weather_key: String
)
signal close_sign()

func _ready()-> void:


    pass

func init()-> void:

    var _random_map_select_node: = MAP_WEATHER_SELECT_BOX.instantiate()
    map_h_box_container_node.add_child(_random_map_select_node)
    _random_map_select_node.init(
        "res://resource/map/mapCover/random_map.png",
        "random", "随机地图"
    )
    _random_map_select_node.connect("choose_sign", _choose_map)

    for _key: String in MapConstants.MAP_CONFIG.keys():

        var _map_select_node: = MAP_WEATHER_SELECT_BOX.instantiate()
        map_h_box_container_node.add_child(_map_select_node)
        _map_select_node.init_by_map_key(_key)
        _map_select_node.connect("choose_sign", _choose_map)


    var _weather_select_node: = MAP_WEATHER_SELECT_BOX.instantiate()
    weather_h_box_container.add_child(_weather_select_node)
    _weather_select_node.init(
        "res://resource/map/mapCover/random_weather.png",
        "random", "随机天气"
    )
    _weather_select_node.connect("choose_sign", _choose_weather)

    for _key in MWorldConstants.WEATHER_CONFIG.keys():

        var _map_select_node: = MAP_WEATHER_SELECT_BOX.instantiate()
        weather_h_box_container.add_child(_map_select_node)
        _map_select_node.init_by_weather_key(_key)
        _map_select_node.connect("choose_sign", _choose_weather)

func init_choose(_map_key: String, _weather_key: String)-> void:
    for _node: MapWeatherSelectBox in map_h_box_container_node.get_children():
        if _node.get_value() == _map_key:
            _node.choose()
            break

    for _node: MapWeatherSelectBox in weather_h_box_container.get_children():
        if _node.get_value() == _weather_key:
            _node.choose()
            break

func cshow()-> void:
    init()
    self.show()

func clear()-> void:
    CommonUtils.clear_node(map_h_box_container_node)
    CommonUtils.clear_node(weather_h_box_container)

func chide()-> void:
    self.hide()
    clear()

func get_map_key()-> String:
    return select_map_node.get_value()

func get_weather_key()-> String:
    return select_weather_node.get_value()

func _choose_weather(_node: MapWeatherSelectBox)-> void:
    if CommonUtils.is_not_null(select_weather_node):
        select_weather_node.unchoose()

    select_weather_node = _node
    CommonUtils.set_text(weather_info_node, "(" + select_weather_node.get_content() + ")")

func _choose_map(_node: MapWeatherSelectBox)-> void:
    if CommonUtils.is_not_null(select_map_node):
        select_map_node.unchoose()

    select_map_node = _node
    CommonUtils.set_text(map_info_node, "(" + select_map_node.get_content() + ")")

func _on_cancel_button_custom_pressed()-> void:
    chide()
    close_sign.emit()

func _on_start_battle_button_custom_pressed()-> void:

    _on_cancel_button_custom_pressed()

    confirm_start_battle_sign.emit(
        select_map_node.get_value(),
        select_weather_node.get_value()
    )