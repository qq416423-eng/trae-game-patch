class_name MoraleInfoBox extends Control

@onready var current_morale_node =$ContentRoot / OverviewRoot / CurrentMorale
@onready var base_morale_node =$ContentRoot / OverviewRoot / BaseMorale
@onready var skill_manage_node =$ContentRoot / DetailRoot / SkillManage
@onready var food_staple_node =$ContentRoot / DetailRoot / FoodStaple
@onready var food_accompaniment_node =$ContentRoot / DetailRoot / FoodAccompaniment
@onready var tired_node =$ContentRoot / DetailRoot / Tired
@onready var battle_node =$ContentRoot / DetailRoot / Battle
@onready var food_option_1_node =$ContentRoot / OptionRoot / FoodOptionRoot / FoodOption1
@onready var food_option_2_node =$ContentRoot / OptionRoot / FoodOptionRoot / FoodOption2
@onready var food_option_3_node =$ContentRoot / OptionRoot / FoodOptionRoot / FoodOption3
@onready var nop_effect_node: IconKeyValue =$ContentRoot / DetailRoot / NopEffect
@onready var init_morale_node: IconKeyValue =$ContentRoot / DetailRoot / InitMorale
@onready var soldier_compatibility_node: IconKeyValue =$ContentRoot / DetailRoot / SoldierCompatibility
@onready var food_richness_node: IconKeyValue =$ContentRoot / DetailRoot / FoodRichness

var current_button = null
var team_info: TeamInfo





func init(_team_info: TeamInfo)-> void:
    team_info = _team_info
    current_morale_node.update_value(
        str(CommonUtils.format_float(_team_info.current_morale, 1))
        + "(" + CommonUtils.num_to_str(CommonUtils.format_float(_team_info.current_morale - _team_info.base_morale, 1), true) + ")"
    )
    base_morale_node.update_value(CommonUtils.format_float(_team_info.base_morale, 1))

    init_morale_node.update_num_value(
        BattleSceneConfig.MORALE_DEFAULT \
        + SkillUtils.get_skill_special_methodical_effect_morale(_team_info.skill_special_methodical)
    )

    var _nop_effect_morale = - _team_info.total
    nop_effect_node.update_num_value(_nop_effect_morale)
    skill_manage_node.update_num_value(min(int(_team_info.skill_manage * SkillConfig.MANAGE_SKILL_EFFECT_MORALE_FACTOR), - _nop_effect_morale))
    soldier_compatibility_node.update_num_value(0)
    food_richness_node.update_num_value(_team_info.food_variety_morale)

    var _food_staple_morale: float = _team_info.get_food_staple_morale()
    var _food_accompaniment_morale: float = _team_info.get_food_accompaniment_morale()
    if _food_staple_morale + _food_accompaniment_morale <= 0:
        _food_staple_morale = -10000
        _food_accompaniment_morale = -10000

    food_staple_node.update_num_value(_food_staple_morale)
    food_accompaniment_node.update_num_value(_food_accompaniment_morale)

    tired_node.update_num_value(_team_info.tired_morale)
    battle_node.update_num_value(_team_info.current_morale - _team_info.base_morale)
    food_option_1_node.text = "节俭(+" + str(
        CommonUtils.format_float(_team_info.get_food_morale(FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS), 1)
    ) + ")"
    food_option_2_node.text = "普通(+" + str(
        CommonUtils.format_float(_team_info.get_food_morale(FoodConstants.FOOD_CONSUME_TYPE_ENUM.COMMON), 1)
    ) + ")"
    food_option_3_node.text = "奢侈(+" + str(
        CommonUtils.format_float(_team_info.get_food_morale(FoodConstants.FOOD_CONSUME_TYPE_ENUM.LUXURIOUS), 1)
    ) + ")"


    match _team_info.food_consume_type:
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS:
            food_option_1_node.button_pressed = true
            current_button = food_option_1_node
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.COMMON:
            food_option_2_node.button_pressed = true
            current_button = food_option_2_node
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.LUXURIOUS:
            food_option_3_node.button_pressed = true
            current_button = food_option_3_node

func _refresh():
    init(team_info)

func _choose_food_consume_type(_food_consume_type):
    team_info.json.food_consume_type = _food_consume_type
    team_info.refresh_morale()
    _refresh()

func _on_food_option_1_pressed():
    if current_button.name == "FoodOption1":
        current_button.button_pressed = true
        return

    current_button.button_pressed = false
    _choose_food_consume_type(FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS)

func _on_food_option_2_pressed():
    if current_button.name == "FoodOption2":
        current_button.button_pressed = true
        return

    current_button.button_pressed = false
    _choose_food_consume_type(FoodConstants.FOOD_CONSUME_TYPE_ENUM.COMMON)

func _on_food_option_3_pressed():
    if current_button.name == "FoodOption3":
        current_button.button_pressed = true
        return

    current_button.button_pressed = false
    _choose_food_consume_type(FoodConstants.FOOD_CONSUME_TYPE_ENUM.LUXURIOUS)