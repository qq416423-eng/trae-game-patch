class_name PlayerFactionRelInterface extends Control

@onready var background_node: NinePatchRect =$Background / Background
@onready var faction_rel_info_v_box_node: VBoxContainer =$ContentRoot / FactionRelInfoVBox
@onready var current_faction_info_node: IconKeyValue =$ContentRoot / CurrentFactionInfo
@onready var country_diplomacy_records_v_box_container_node: VBoxContainer =$CountryDiplomacyRecordsRoot / VBoxContainer
@onready var faction_info_key_node: Label =$ContentRoot / CurrentFactionInfoBox / Key
@onready var faction_info_faction_color_pic_node: TextureRect =$ContentRoot / CurrentFactionInfoBox / FactionColorPic
@onready var faction_info_lord_banner_node: LordBanner =$ContentRoot / CurrentFactionInfoBox / BannerRoot / LordBanner
@onready var faction_info_value_node: Label =$ContentRoot / CurrentFactionInfoBox / Value
@onready var banner_root_node: Control =$ContentRoot / CurrentFactionInfoBox / BannerRoot
@onready var current_faction_info_box_node: HBoxContainer =$ContentRoot / CurrentFactionInfoBox

const COUNTRY_DIPLOMACY_RECORDS_BOX = preload("res://tscn/game/interface/ws/CountryDiplomacyRecordsBox.tscn")
const FACTION_REL_INFO_ITEM = preload("res://tscn/game/interface/ws/FactionRelInfoItem.tscn")

var current_choose_country_code: = ""

func _ready()-> void:
    background_node.hide()

func init()-> void:

    var _country_code: String = SoldierUtils.get_player_belong_country()
    _refresh_faction_rel_interface(_country_code)

    _init_country_diplomacy_records()

func _refresh_faction_rel_interface(
    _base_country_code: String
)-> void:
    current_choose_country_code = _base_country_code

    CommonUtils.clear_node(faction_rel_info_v_box_node)

    for _country_code: String in WSCountryData.COUNTRY_INFO.keys():
        if StringUtils.equals(_base_country_code, _country_code):
            continue

        _add_faction_rel_info_item(_base_country_code, _country_code)

    var _player_country_code: String = SoldierUtils.get_player_belong_country()

    if StringUtils.equals(_player_country_code, _base_country_code):

        CommonUtils.update_text(faction_info_key_node, "玩家所属阵营:")
    else:

        CommonUtils.update_text(faction_info_key_node, "当前阵营:")


    if StringUtils.equals(_base_country_code, WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION) \
    or StringUtils.equals(_base_country_code, WSCountryData.COUNTRY_NAME_ENUM.NONE) \
    or StringUtils.is_empty(_base_country_code):
        faction_info_faction_color_pic_node.hide()
        banner_root_node.hide()
    else:
        faction_info_faction_color_pic_node.show()
        banner_root_node.show()
        var _country_color: Color = CountryUtils.get_country_color(_base_country_code)
        var _king_uid: String = CountryUtils.get_king_uid_by_country_code(_base_country_code)
        faction_info_faction_color_pic_node.self_modulate = _country_color
        faction_info_lord_banner_node.init_by_hero_uid(_king_uid)


    CommonUtils.update_text(
        faction_info_value_node,
        CountryUtils.get_country_name_by_country_code(_base_country_code)
    )

func _add_faction_rel_info_item(_base_country_code: String, _country_code: String)-> void:
    var _node: FactionRelInfoItem = FACTION_REL_INFO_ITEM.instantiate()
    faction_rel_info_v_box_node.add_child(_node)


    var _country_rel_data: Dictionary = GlobalCountryData.get_target_country_rel_data(_base_country_code, _country_code)

    _node.init_by_country_code(
        _country_code, _country_rel_data.rel_value, _country_rel_data.start_time
    )
    _node.connect("choose_faction_sign", _choose_faction)

    if StringUtils.equals(SoldierUtils.get_player_belong_country(), _country_code):
        _node.update_faction_name_color(Color("208020"))

func _choose_faction(_country_code: String)-> void:
    current_choose_country_code = _country_code


    var _tween = create_tween().set_parallel(true)
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(current_faction_info_box_node, "modulate:a", 0.2, 0.2)
    _tween.tween_property(faction_rel_info_v_box_node, "modulate:a", 0.2, 0.2)
    _tween.connect("finished", _refresh_faction_rel_interface_ani)

func _refresh_faction_rel_interface_ani()-> void:
    _refresh_faction_rel_interface(current_choose_country_code)
    var _tween = create_tween().set_parallel(true)
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(current_faction_info_box_node, "modulate:a", 1.0, 0.3)
    _tween.tween_property(faction_rel_info_v_box_node, "modulate:a", 1.0, 0.3)


func _init_country_diplomacy_records()-> void:
    CommonUtils.clear_node(country_diplomacy_records_v_box_container_node)

    for _index in range(GlobalCountryData.country_diplomacy_records.size() - 1, -1, -1):
        var _country_diplomacy_records_item_dic: Dictionary = GlobalCountryData.country_diplomacy_records[_index]
        var _node: CountryDiplomacyRecordsBox = COUNTRY_DIPLOMACY_RECORDS_BOX.instantiate()
        country_diplomacy_records_v_box_container_node.add_child(_node)
        _node.init(_country_diplomacy_records_item_dic)