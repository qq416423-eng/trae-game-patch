class_name PlayerRelInfoInterface extends Control

@onready var part_select_button_list_for_scroll: PartSelectButtonList =$MenuRoot / MenuScrollRoot / PartSelectButtonListForScroll
@onready var team_info_interface_node: TeamInfoInterface =$ChildPageRoot / TeamInfoInterface
@onready var child_page_root_node: Control =$ChildPageRoot
@onready var player_faction_rel_interface_node: PlayerFactionRelInterface =$ChildPageRoot / PlayerFactionRelInterface

signal close_page_sign()

func init()-> void:
    part_select_button_list_for_scroll.select(0, true)

func _on_part_select_button_list_for_scroll_choose_sign(_value: String)-> void:
    for _child_page_node in child_page_root_node.get_children():
        _child_page_node.hide()

    match _value:
        "TEAM_INFO":
            team_info_interface_node.show()
            team_info_interface_node.init(WSData.get_player_team_node().team_info)
        "FACTION_REL":
            player_faction_rel_interface_node.show()
            player_faction_rel_interface_node.init()

func _on_close_button_custom_pressed()-> void:
    close_page_sign.emit()
    self.queue_free()