class_name SceneTransitionAni extends ColorRect

@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

@export var ani_duration_time: float = 0.5

signal fade_out_ani_finish_sign()
signal fade_in_ani_finish_sign()

func _ready()-> void:

    animation_player_node.speed_scale = 1 / ani_duration_time


func play_fade_out()-> void:



    animation_player_node.play("fade_out")


func play_fade_in()-> void:


    animation_player_node.play("fade_in")

func fade_out_ani_finish()-> void:
    fade_out_ani_finish_sign.emit()

func fade_in_ani_finish()-> void:
    fade_in_ani_finish_sign.emit()