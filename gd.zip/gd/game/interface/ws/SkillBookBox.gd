class_name SkillBookBox extends Control

@onready var skill_icon_node =$LeftBox / SkillIcon as SkillIcon
@onready var skill_name_node =$LeftBox / SkillName
@onready var intelligence_plus_root_node =$RightBox / VBoxContainer / intelligencePlusRoot as KeyValueBox
@onready var aptitude_plus_root_node =$RightBox / VBoxContainer / AptitudePlusRoot as KeyValueBox
@onready var level_value_node =$RightBox / LevelRoot / LevelValue
@onready var aptitude_root_node =$RightBox / AptitudeRoot as KeyValueBox
@onready var skill_upgrade_bar_node =$SkillUpgradeBar as SkillUpgradeBar
@onready var content_node =$Content
@onready var boundary_node: Label =$RightBox / VBoxContainer / Boundary
@onready var intelligence_bonus_level_node: KeyValueBox =$RightBox / VBoxContainer / IntelligenceBonusLevel

func init(_soldier_prop: BSSoldierProp):
    var _learn_skill = _soldier_prop.learn_skill
    var _skill_config: Dictionary = SkillUtils.get_skill_config(_learn_skill)
    var _skill_level: int = _soldier_prop.get(_learn_skill)

    var _real_skill_level: = _skill_level

    var _intelligence_skill_bonus_level: int = _soldier_prop.intelligence_skill_bonus_level

    var _is_intelligence_skill: bool = SkillUtils.is_intelligence_skill(_learn_skill)
    if _is_intelligence_skill:
        _real_skill_level -= _intelligence_skill_bonus_level
        boundary_node.show()
        intelligence_bonus_level_node.show()

        intelligence_bonus_level_node.set_value(_intelligence_skill_bonus_level)
    else:
        boundary_node.hide()
        intelligence_bonus_level_node.hide()

    var _skill_aptitude = _soldier_prop.get_skill_aptitude(_learn_skill)
    var _skill_exp = _soldier_prop.get_skill_exp(_learn_skill)
    var _skill_exp_upgrade = SkillUtils.get_skill_upgrade_exp(_real_skill_level)

    var _skill_level_str = str(_real_skill_level)
    if _real_skill_level != _skill_level:
        _skill_level_str = str(_skill_level - _real_skill_level) + "+" + str(_real_skill_level)


    skill_icon_node.set_pic(SkillUtils.get_skill_icon_path(_learn_skill))
    CommonUtils.set_text(skill_name_node, _skill_config.name)


    CommonUtils.set_text(
        level_value_node,

        "LV " + _skill_level_str + "/" + str(_soldier_prop.get_skill_max(_learn_skill))
    )
    intelligence_plus_root_node.set_value(
        "+ " + StringUtils.get_percent_str(
            SkillUtils.get_skill_learn_plus_by_intelligence(_soldier_prop.base_intelligence)
        )
    )
    aptitude_plus_root_node.set_value(
        "+ " \
        + StringUtils.get_percent_str(
            SkillUtils.get_skill_learn_plus_by_aptitude(_skill_aptitude)
        )
    )
    var _aptitude_info = SkillUtils.get_aptitude_info(_skill_aptitude)
    aptitude_root_node.set_value(_aptitude_info.name, _aptitude_info.color)


    skill_upgrade_bar_node.init(_real_skill_level, _skill_exp, _skill_exp_upgrade)
    skill_upgrade_bar_node.show_or_hide_max_effect(

        _real_skill_level >= _soldier_prop.get_skill_max(_learn_skill)
    )



    CommonUtils.set_text(content_node, _skill_config.remark)