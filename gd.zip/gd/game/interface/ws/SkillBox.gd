class_name SkillBox extends Control

@onready var skill_name_node =$SkillName
@onready var aptitude_value_node =$AptitudeRoot / AptitudeValue
@onready var skill_icon_node =$SkillIcon as SkillIcon
@onready var button_node =$Button
@onready var type_root_node =$TypeRoot
@onready var type_value_node =$TypeRoot / TypeValue
@onready var level_background_node =$LevelBackground
@onready var level_image_box_node =$LevelImageBox
@onready var special_skill_icon_node: TextureRect =$SpecialSkillIcon
@onready var is_intelligence_related_icon_node: TextureRect =$IsIntelligenceRelatedIcon

const TYPE_BACKGROUND_ICON_2_PIC = preload("res://resource/icon/skillIcon/type_background_icon2.png")
const TYPE_BACKGROUND_ICON_3_PIC = preload("res://resource/icon/skillIcon/type_background_icon3.png")

var field: String

signal choose_sign(_node)

func init(_field: String, _skill_json: Dictionary):
    field = _field
    CommonUtils.set_text(skill_name_node, _skill_json.name)
    skill_icon_node.set_pic(SkillUtils.get_skill_icon_path(_field))
    match _skill_json.type:
        SkillConstants.SKILL_TYPE.INDIVIDUAL:
            CommonUtils.set_text(type_value_node, "个人")
        SkillConstants.SKILL_TYPE.TEAM:
            CommonUtils.set_text(type_value_node, "团队")
            CommonUtils.update_texture3(type_root_node, TYPE_BACKGROUND_ICON_2_PIC)
        SkillConstants.SKILL_TYPE.ALL:
            CommonUtils.set_text(type_value_node, "混合")
            CommonUtils.update_texture3(type_root_node, TYPE_BACKGROUND_ICON_3_PIC)


    if SkillUtils.is_special_skill(_field):
        special_skill_icon_node.show()



    if _skill_json.is_intelligence_related:
        is_intelligence_related_icon_node.show()
    else:
        is_intelligence_related_icon_node.hide()




func update_info(
    _current_level: int, _aptitude_value: int,
    _max_level: int, _intelligence_skill_bonus_level: int
):
    var _real_level = _current_level
    if SkillUtils.is_intelligence_skill(field):
        _real_level -= _intelligence_skill_bonus_level

    var _level_str = str(_real_level)
    if _real_level != _current_level:
        _level_str = str(_current_level - _real_level) + "+" + _level_str

    level_image_box_node.init(_current_level, "LV " + _level_str + "/" + str(_max_level))

    var _aptitude_info = SkillUtils.get_aptitude_info(_aptitude_value)
    CommonUtils.set_text(aptitude_value_node, _aptitude_info.name, _aptitude_info.color)


    if _real_level >= _max_level:
        button_node.self_modulate = Color.VIOLET
    else:
        button_node.self_modulate = Color.WHITE

func choose(_is_open_sound: bool = true):
    button_node.pressed(_is_open_sound)

func unchoose():
    button_node.cancel()

func _on_button_b_pressed():
    emit_signal("choose_sign", self)