class_name SkillIcon extends Control

@onready var icon_node =$Icon

func set_pic(_path: String):
    CommonUtils.update_texture2(icon_node, _path)