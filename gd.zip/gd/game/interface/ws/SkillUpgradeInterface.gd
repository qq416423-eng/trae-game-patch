class_name SkillUpgradeInterface extends Control

@onready var hero_select_interface_node =$LeftBox / HeroSelectInterface as HeroSelectInterface
@onready var skill_box_node = preload("res://tscn/game/interface/ws/SkillBox.tscn")
@onready var skill_list_grid_container_node =$RightBox / BaseScrollContainer / GridContainer
@onready var skill_book_box_node =$LeftBox / SkillBookBox as SkillBookBox

var select_skill_box_node = null

signal close_sign()

func _ready():

    pass

func init(_team_json: Array, _choose_hero_uid: String):
    self._skill_list(_choose_hero_uid)


    var _hero_simple_json_list = TeamUtils.list_hero_simple_json(_team_json)
    hero_select_interface_node.init(_hero_simple_json_list)
    hero_select_interface_node.choose_by_hero_uid(_choose_hero_uid, false)


func _skill_list(_hero_uid: String):
    var _hero_json: = SoldierUtils.get_json_by_hero_uid(_hero_uid)

    for _key: String in SkillConstants.SKILL_CONFIG.keys():

        if SkillUtils.is_special_skill(_key):
            if _hero_json.has(_key) and _hero_json.get(_key) > 0:
                pass
            else:
                continue

        var _skill_item_json = SkillUtils.get_skill_config(_key)
        var _skill_box_instance = skill_box_node.instantiate() as SkillBox
        skill_list_grid_container_node.add_child(_skill_box_instance)
        _skill_box_instance.init(_key, _skill_item_json)
        _skill_box_instance.connect("choose_sign", _choose_skill)

func _choose_skill(_node: SkillBox):



    if select_skill_box_node != null:
        select_skill_box_node.unchoose()

    select_skill_box_node = _node

    var _simple_json = hero_select_interface_node.get_current_simple_json()
    var _hero_json = SoldierUtils.get_json2(_simple_json)
    _hero_json.learn_skill = _node.field
    _update_book(_simple_json)

func _clear():
    CommonUtils.clear_node(skill_list_grid_container_node)
    select_skill_box_node = null
    hero_select_interface_node.clear()

func _update_book(_simple_json)-> BSSoldierProp:
    var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)

    skill_book_box_node.init(_prop)
    return _prop


func _on_hero_select_interface_choose(_simple_json):




    select_skill_box_node = null

    CommonUtils.clear_node(skill_list_grid_container_node)
    _skill_list(_simple_json.uid)

    var _prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop(_simple_json)


    var _skill_code = ""

    for _node: SkillBox in skill_list_grid_container_node.get_children():
        if CommonUtils.is_null(_node):
            continue

        _skill_code = _node.field
        _node.update_info(
            _prop.get_skill_level(_skill_code), _prop.get_skill_aptitude(_skill_code),

            SoldierUtils.get_hero_skill_level_max(_simple_json.uid, _skill_code),
            _prop.intelligence_skill_bonus_level
        )

        if _node.field == _prop.learn_skill:
            _node.choose(false)

func _on_close_button_pressed():
    self.hide()
    _clear()
    close_sign.emit()