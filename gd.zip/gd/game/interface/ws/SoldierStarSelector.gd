class_name SoldierStarSelector extends Control

@onready var h_box_container_node: HBoxContainer =$HBoxContainer

signal choose_sign(_value: int)

func _ready()-> void:
    _connect_sign()
    _init_star_color()

func reset()-> void:
    for _star_button: GoodsCategoryButton in h_box_container_node.get_children():
        _star_button.switch(true)

func _connect_sign()-> void:
    for _star_button: GoodsCategoryButton in h_box_container_node.get_children():
        _star_button.connect("pressed_sign", _click_button)

func _click_button(_is_choose: bool, _value: String)-> void:
    var _star: int = int(_value)

    for _star_button: GoodsCategoryButton in h_box_container_node.get_children():
        if _star <= 0:
            _star_button.switch(true)
        elif _star == int(_star_button.get_value()):
            _star_button.switch(true)
        else:
            _star_button.switch(false)

    choose_sign.emit(_star)

func _init_star_color()-> void:
    for _star_button: GoodsCategoryButton in h_box_container_node.get_children():
        var _star: = int(_star_button.get_value())
        if _star > 0:
            var _color: Color = SoldierUtils.get_star_color(_star)
            CommonUtils.update_self_color(_star_button.get_node("StarRoot"), _color)