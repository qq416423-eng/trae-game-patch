class_name SpecialFunctionInterface extends Control

signal repair_goods_count_sign()


func _on_confirm_button_pressed()-> void:
    repair_goods_count_sign.emit()