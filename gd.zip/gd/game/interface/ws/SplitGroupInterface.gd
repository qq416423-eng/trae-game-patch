class_name SplitGroupInterface extends Control

@onready var name_node: Label =$Background / InfoRoot / Name
@onready var total_node: IconKeyValue =$Background / InfoRoot / Total
@onready var avatar_ani_node: AvatarAni =$Background / InfoRoot / AvatarAni
@onready var split_tool_node: SplitTool =$SplitTool
@onready var add_group_button_node: CommonButton2 =$PageButtonRoot / AddGroupButton
@onready var subtract_group_button_node: CommonButton2 =$PageButtonRoot / SubtractGroupButton
@onready var average_button_node: CommonButton2 =$PageButtonRoot / AverageButton

var soldier_prop: BSSoldierProp

signal close_sign()
signal save_sign(_uid: String, _int_list: Array)

func init(_soldier_prop: BSSoldierProp, _nop_list: Array)-> void:
    soldier_prop = _soldier_prop

    var _total: int = ArrayUtils.get_total(_nop_list)
    avatar_ani_node.init(_soldier_prop, true)
    total_node.update_value(_total)
    split_tool_node.init(_nop_list)
    CommonUtils.set_text(name_node, _soldier_prop.name)
    _refresh_button_style()

func get_uid()-> String:
    if CommonUtils.is_null(soldier_prop):
        return ""

    return soldier_prop.uid

func _refresh_button_style()-> void:
    if split_tool_node.get_group_size() >= 3 or split_tool_node.get_group_size() >= split_tool_node.get_total():
        add_group_button_node.disabled = true
    else:
        add_group_button_node.disabled = false

    if split_tool_node.get_group_size() <= 1:
        subtract_group_button_node.disabled = true
        average_button_node.disabled = true
    else:
        subtract_group_button_node.disabled = false
        average_button_node.disabled = false

func _on_close_button_pressed()-> void:
    close_sign.emit()

func _on_add_group_button_pressed()-> void:
    split_tool_node.add_group()
    _refresh_button_style()

func _on_subtract_group_button_pressed()-> void:
    split_tool_node.subtract_group()
    _refresh_button_style()

func _on_average_button_pressed()-> void:
    split_tool_node.average()

func _on_save_button_pressed()-> void:
    save_sign.emit(get_uid(), split_tool_node.get_result())