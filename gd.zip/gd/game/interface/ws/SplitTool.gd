@tool
class_name SplitTool extends Control

@onready var background_node: NinePatchRect =$Background
@onready var slider_button_1_node: SliderButton0002 =$SliderRoot / SliderButton1
@onready var slider_button_2_node: SliderButton0002 =$SliderRoot / SliderButton2
@onready var bar_3_node: NinePatchRect =$BarRoot / Bar3
@onready var bar_2_node: NinePatchRect =$BarRoot / Bar2
@onready var bar_1_node: NinePatchRect =$BarRoot / Bar1
@onready var split_tool_tag_1_node: SplitToolTag =$TagRoot / SplitToolTag1
@onready var split_tool_tag_2_node: SplitToolTag =$TagRoot / SplitToolTag2
@onready var split_tool_tag_3_node: SplitToolTag =$TagRoot / SplitToolTag3


@export var length: = 576:
    set(_value):
        length = _value
        $Background.size.x = _value
@export var is_show_connect_line: = true:
    set(_value):
        is_show_connect_line = _value
        if not _value:
            $ConnectLineRoot.hide()
            $TagRoot.hide()
            $SliderRoot / SliderButton1 / Line.hide()
            $SliderRoot / SliderButton2 / Line.hide()

@export var allow_zero: = false
@export var bar1_color: Color = Color("e0e0e0")
@export var bar2_color: Color = Color("039be5")
@export var bar3_color: Color = Color("9c27b0")

var button_edge_length: = 28
var button_min_x: = 0
var button_max_x: = 0
var button_range: float = 0
var bar_edge_length: = 12
var bar_min_x: = 0
var bar_max_x: = 0
var bar_range: float = 0
var current_part_num: = 0
var button_width: = 0


var num_list: = []
var total: = 0
var first_num_change_sign_record: = -1

signal first_num_change_sign(_num: int)

func _ready()-> void:
    button_width = slider_button_1_node.get_button_size().x
    button_min_x = button_edge_length
    button_max_x = background_node.size.x - button_edge_length
    button_range = button_max_x - button_min_x
    bar_min_x = bar_edge_length
    bar_max_x = background_node.size.x - bar_edge_length
    bar_range = bar_max_x - bar_min_x

    CommonUtils.update_color(bar_1_node, bar1_color)
    CommonUtils.update_color(bar_2_node, bar2_color)
    CommonUtils.update_color(bar_3_node, bar3_color)

func init(_num_list: Array)-> void:
    first_num_change_sign_record = -1
    num_list = _num_list
    bar_2_node.hide()
    bar_3_node.hide()
    slider_button_1_node.hide()
    slider_button_2_node.hide()
    split_tool_tag_2_node.hide()
    split_tool_tag_3_node.hide()

    total = ArrayUtils.get_total(_num_list)

    if _num_list.size() >= 1:
        pass
    if _num_list.size() >= 2:
        var _positon_x: float =(_num_list[0] * bar_range / total) + bar_edge_length
        slider_button_1_node.init(_positon_x, button_min_x, button_max_x)
        slider_button_1_node.cshow()

        bar_2_node.show()
        split_tool_tag_2_node.show()
    if _num_list.size() >= 3:
        var _positon_x: float = bar_range + bar_edge_length -(_num_list[2] * bar_range / total)
        slider_button_2_node.init(_positon_x, slider_button_1_node.position.x + button_width, button_max_x)
        slider_button_2_node.cshow()

        slider_button_1_node.update_max_x(slider_button_2_node.position.x - button_width)
        bar_3_node.show()
        split_tool_tag_3_node.show()

    _update_bar_position_length()
    _maybe_end_first_num_change_sign()


func add_group()-> void:
    if num_list.size() >= 3:
        return

    num_list[num_list.size() - 1] = float(num_list[num_list.size() - 1]) / 2
    num_list.append(num_list[num_list.size() - 1])
    num_list = ComputeUtils.split_int(total, num_list)
    init(num_list)

func subtract_group()-> void:
    if num_list.size() <= 1:
        return

    num_list[num_list.size() - 2] += num_list[num_list.size() - 1]
    num_list.remove_at(num_list.size() - 1)
    init(num_list)

func get_group_size():
    return num_list.size()

func average():
    var _temp_list = []
    for _index in range(num_list.size()):
        _temp_list.append(1)

    num_list = ComputeUtils.split_int(total, _temp_list)
    init(num_list)

func get_result()-> Array:
    return num_list

func get_total()-> int:
    return total

func get_count()-> int:
    return num_list[0]

func _maybe_end_first_num_change_sign()-> void:
    if num_list[0] != first_num_change_sign_record:
        first_num_change_sign_record = num_list[0]
        first_num_change_sign.emit(first_num_change_sign_record)

func _update_bar_position_length():
    var _button_1_position_x = slider_button_1_node.position.x
    var _button_2_position_x = slider_button_2_node.position.x

    var _bar_length_list: = []

    match num_list.size():
        1:
            bar_1_node.size.x = bar_range
            split_tool_tag_1_node.position.x =(bar_min_x + bar_max_x) / 2
            _bar_length_list.append_array([
                bar_1_node.size.x
            ])
        2:
            bar_1_node.size.x = _button_1_position_x - bar_edge_length
            bar_2_node.position.x = _button_1_position_x
            bar_2_node.size.x = bar_range + bar_edge_length - _button_1_position_x
            split_tool_tag_1_node.position.x =(bar_edge_length + _button_1_position_x) / 2
            split_tool_tag_2_node.position.x =(_button_1_position_x + bar_max_x) / 2
            _bar_length_list.append_array([
                bar_1_node.size.x,
                bar_2_node.size.x,
            ])
        3:
            bar_1_node.size.x = _button_1_position_x - bar_edge_length
            bar_2_node.position.x = _button_1_position_x
            bar_2_node.size.x = _button_2_position_x - _button_1_position_x
            bar_3_node.position.x = _button_2_position_x
            bar_3_node.size.x = bar_range + bar_edge_length - _button_2_position_x
            split_tool_tag_1_node.position.x =(bar_edge_length + _button_1_position_x) / 2
            split_tool_tag_2_node.position.x =(_button_1_position_x + _button_2_position_x) / 2
            split_tool_tag_3_node.position.x =(_button_2_position_x + bar_max_x) / 2
            _bar_length_list.append_array([
                bar_1_node.size.x,
                bar_2_node.size.x,
                bar_3_node.size.x,
            ])

    if _bar_length_list.size() >= 2 and allow_zero:
        var _temp_length = button_edge_length - bar_edge_length
        _bar_length_list[0] -= _temp_length
        _bar_length_list[_bar_length_list.size() - 1] -= _temp_length

    num_list = ComputeUtils.split_int(total, _bar_length_list, allow_zero)
    if num_list.size() >= 1:
        split_tool_tag_1_node.set_value(num_list[0])

    if num_list.size() >= 2:
        split_tool_tag_2_node.set_value(num_list[1])

    if num_list.size() >= 3:
        split_tool_tag_3_node.set_value(num_list[2])

func _on_slider_button_1_update_position_x(_x: float)-> void:
    _update_bar_position_length()
    if slider_button_2_node.visible:
        slider_button_2_node.update_min_x(_x + button_width)

    _maybe_end_first_num_change_sign()

func _on_slider_button_2_update_position_x(_x: float)-> void:
    _update_bar_position_length()
    slider_button_1_node.update_max_x(_x - button_width)
    _maybe_end_first_num_change_sign()