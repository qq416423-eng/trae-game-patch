class_name SplitToolTag extends Control

@onready var group_icon_node: TextureRect =$SoldierCountBackground / GroupIcon
@onready var count_node: Label =$SoldierCountBackground / Count

const GROUP_0002_ICON_12 = preload("res://resource/icon/smallIcon/group_0002_icon_12.png")
const GROUP_0003_ICON_12 = preload("res://resource/icon/smallIcon/group_0003_icon_12.png")

@export var _group_num: int = 1

func _ready()-> void:
    match _group_num:
        2:
            CommonUtils.update_texture3(group_icon_node, GROUP_0002_ICON_12)
        3:
            CommonUtils.update_texture3(group_icon_node, GROUP_0003_ICON_12)

func set_value(_value)-> void:
    CommonUtils.set_text(count_node, _value)