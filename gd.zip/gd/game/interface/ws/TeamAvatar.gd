class_name TeamAvatar extends Control

@onready var avatar_node: Avatar =$AvatarFrame / Avatar

func init(_mw_team_node: MWTeam)-> void:
    avatar_node.init_by_json(_mw_team_node.get_leader_json())