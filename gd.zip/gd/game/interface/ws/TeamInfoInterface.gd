class_name TeamInfoInterface extends Control

@onready var morale_info_box_node =$ContentRoot / BaseScrollContainer / VBoxContainer / MoraleInfoBox
@onready var team_speed_info_box_node: TeamSpeedInfoBox =$ContentRoot / BaseScrollContainer / VBoxContainer / TeamSpeedInfoBox
@onready var troop_overview_panel_node: TroopOverviewPanel =$ContentRoot / BaseScrollContainer / VBoxContainer / TroopOverviewPanel
@onready var banner_setting_interface_node: BannerSettingInterface =$OtherFullPageRoot / BannerSettingInterface
@onready var other_full_page_root_node: Control =$OtherFullPageRoot
@onready var base_scroll_container_node: ScrollContainer =$ContentRoot / BaseScrollContainer

const WAGES_DETAIL_MASK_INTERFACE = preload("res://tscn/game/interface/ws/WagesDetailMaskInterface.tscn")
const INCOME_DETAIL_MASK_INTERFACE = preload("res://tscn/game/interface/ws/IncomeDetailMaskInterface.tscn")

signal close_sign()

func init(team_info: TeamInfo):
    morale_info_box_node.init(team_info)
    team_speed_info_box_node.init(team_info)
    troop_overview_panel_node.init()
    base_scroll_container_node.scroll_vertical = 0

func _on_close_button_pressed():
    self.hide()
    close_sign.emit()

func _on_troop_overview_panel_edit_banner_sign()-> void:
    banner_setting_interface_node.cshow()
    banner_setting_interface_node.init(
        SoldierUtils.get_player_banner_config()
    )

func _on_banner_setting_interface_save_sign(_banner_config: Dictionary)-> void:
    SoldierUtils.save_player_banner_config(_banner_config)
    troop_overview_panel_node.refresh_banner()


    SoldierUtils.refresh_player_world_banner()

func _on_troop_overview_panel_show_wages_detail_page_sign()-> void:
    var _node: = WAGES_DETAIL_MASK_INTERFACE.instantiate()
    other_full_page_root_node.add_child(_node)
    _node.init_player_wages_info()

func _on_troop_overview_panel_show_income_detail_page_sign()-> void:
    var _node: = INCOME_DETAIL_MASK_INTERFACE.instantiate()
    other_full_page_root_node.add_child(_node)
    _node.init()