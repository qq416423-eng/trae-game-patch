class_name TeamSkillInterface extends Control

@onready var icon_switch_button_small_node =$IconSwitchButtonSmall as IconSwitchButton
@onready var skill_page_root_node =$SkillPageRoot
@onready var prop_root_node =$SkillPageRoot / PropRoot

func refresh():
    self.init(WSData.get_player_data())

func init(_node_json: Dictionary):
    var _team_info = TeamInfo.new(_node_json)
    for _prop_node in prop_root_node.get_children():
        var _prop_name = CommonUtils.camel_to_underscore(_prop_node.name)

        var _value = _team_info.get(_prop_name)
        CommonUtils.set_text(_prop_node.get_node("Value"), _value)


func page_close():
    icon_switch_button_small_node.switch(false)

func button_disable(_disable: bool)-> void:
    icon_switch_button_small_node.disabled = _disable

func _on_icon_switch_button_small_cpressed(_value: bool):
    if _value:
        skill_page_root_node.show()
    else:
        skill_page_root_node.hide()