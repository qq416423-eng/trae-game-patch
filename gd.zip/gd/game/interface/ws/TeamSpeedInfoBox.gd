class_name TeamSpeedInfoBox extends Control

@onready var current_speed_node: IconKeyValue =$ContentRoot / OverviewRoot / CurrentSpeed
@onready var init_speed_node: IconKeyValue =$ContentRoot / DetailRoot / InitSpeed
@onready var morale_effect_node: IconKeyValue =$ContentRoot / DetailRoot / MoraleEffect
@onready var terrain_effect_node: IconKeyValue =$ContentRoot / DetailRoot / TerrainEffect
@onready var night_effect_node: IconKeyValue =$ContentRoot / DetailRoot / NightEffect
@onready var skill_motility_effect_node: IconKeyValue =$ContentRoot / DetailRoot / SkillMotilityEffect
@onready var horse_effect_node: IconKeyValue =$ContentRoot / DetailRoot / HorseEffect
@onready var nop_effect_node: IconKeyValue =$ContentRoot / DetailRoot / NopEffect
@onready var weight_node: IconKeyValue =$ContentRoot / DetailRoot / Weight
@onready var weight_effect_node: IconKeyValue =$ContentRoot / DetailRoot / WeightEffect
@onready var cart_effect_node: IconKeyValue =$ContentRoot / DetailRoot / CartEffect
@onready var carrying_capacity_node: IconKeyValue =$ContentRoot / DetailRoot / CarryingCapacity

func init(_team_info: TeamInfo)-> void:
    current_speed_node.update_num_value(_team_info.speed)
    init_speed_node.update_num_value(_team_info.speed_base - _team_info.speed_inventory_horse_effect - _team_info.speed_nop_effect)
    morale_effect_node.update_num_value(_team_info.speed_morale_effect)
    terrain_effect_node.update_num_value(_team_info.speed_terrain_effect)
    night_effect_node.update_num_value(_team_info.speed_night_effect)
    skill_motility_effect_node.update_num_value(_team_info.speed_skill_motility_effect)
    horse_effect_node.update_num_value(_team_info.speed_inventory_horse_effect)
    nop_effect_node.update_num_value(_team_info.speed_nop_effect)
    weight_node.update_value(_team_info.inventory_weight)
    weight_effect_node.update_num_value(- _team_info.origin_speed * _team_info.speed_inventory_weight_effect_ratio)
    cart_effect_node.update_num_value(_team_info.origin_speed * _team_info.speed_inventory_weight_effect_ratio - _team_info.origin_speed * _team_info.real_speed_inventory_weight_effect_ratio)
    carrying_capacity_node.update_value(_team_info.carrying_capacity)