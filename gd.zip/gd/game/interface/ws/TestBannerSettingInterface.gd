extends BannerSettingInterface

func _ready()-> void:
    init({})

func _custom_choose_emblem_color()-> void:
    print_debug(banner_config)

func _custom_choose_shape_color()-> void:
    print_debug(banner_config)

func _custom_choose_shape()-> void:
    print_debug(banner_config)

func _custom_choose_emblem()-> void:
    print_debug(banner_config)