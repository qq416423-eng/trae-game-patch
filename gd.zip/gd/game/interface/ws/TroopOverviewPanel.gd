class_name TroopOverviewPanel extends Control

@onready var nop_limit_node: IconKeyValue =$ContentRoot / NopLimitInfoRoot / NopLimit
@onready var base_nop_limit_node: IconKeyValue =$ContentRoot / NopLimitInfoRoot / BaseNopLimit
@onready var manage_skill_plus_nop_limit_node: IconKeyValue =$ContentRoot / NopLimitInfoRoot / ManageSkillPlusNopLimit
@onready var reputation_value_plus_nop_limit_node: IconKeyValue =$ContentRoot / NopLimitInfoRoot / ReputationValuePlusNopLimit
@onready var reputation_value_node: IconKeyValue =$ContentRoot / OtherInfoRoot / ReputationValue

@onready var edit_banner_button_node: Button =$ContentRoot / BannerRoot / EditBannerButton
@onready var tip_node: Label =$ContentRoot / BannerRoot / Tip
@onready var lord_banner_node: LordBanner =$ContentRoot / BannerRoot / LordBanner
@onready var total_wages_node: IconKeyValue =$ContentRoot / WagesInfoRoot / TotalWages
@onready var field_wages_node: IconKeyValue =$ContentRoot / WagesInfoRoot / FieldWages
@onready var garrison_wages_node: IconKeyValue =$ContentRoot / WagesInfoRoot / GarrisonWages
@onready var unpaid_wages_node: IconKeyValue =$ContentRoot / WagesInfoRoot / UnpaidWages
@onready var morality_value_node: IconKeyValue =$ContentRoot / OtherInfoRoot / MoralityValue




signal edit_banner_sign()
signal show_wages_detail_page_sign()
signal show_income_detail_page_sign()

func init()-> void:
    var _team_info: TeamInfo = WSData.get_player_team_info()
    nop_limit_node.update_value(_team_info.nop_limit)
    base_nop_limit_node.update_num_value(TeamConfig.PLAYER_BASE_NOP_LIMIT)
    manage_skill_plus_nop_limit_node.update_num_value(_team_info.skill_manage * SkillConfig.MANAGE_SKILL_EFFECT_NOP_LIMIT)
    reputation_value_plus_nop_limit_node.update_num_value(min(WSData.get_player_reputation_value_int() / 20, 60))

    var _reputation_value_int: int = SoldierUtils.get_player_reputation_value_int()
    reputation_value_node.update_value(
        str(_reputation_value_int) \
        + " (" + SoldierUtils.get_reputation_value_label(_reputation_value_int) + ")"
    )


    var _morality_value_int: int = SoldierUtils.get_player_morality_value_int()
    morality_value_node.update_value(
        str(_morality_value_int) \
        + " (" + SoldierUtils.get_morality_value_label(_morality_value_int) + ")"
    )


    var _player_hero_json: Dictionary = SoldierUtils.get_player_hero_json()

    if SoldierUtils.get_player_belong_country() != WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION \
    or not CommonUtils.get_value(_player_hero_json, "banner_config",{}).is_empty():
        edit_banner_button_node.disabled = false
        if StringUtils.is_not_empty(CommonUtils.get_value(_player_hero_json, "belong_country", "")):
            CommonUtils.update_text(
                tip_node,
                "当前身份: " + CountryUtils.get_country_name_by_country_code(_player_hero_json.belong_country) + "的领主",
                Color("0288d1")
            )
        else:
            CommonUtils.update_text(
                tip_node, "当前身份: 自由冒险者", Color("3e2723")
            )
    else:
        edit_banner_button_node.disabled = true
        CommonUtils.update_text(
            tip_node, "您还不是贵族, 无法编辑旗帜", Color("3e2723")
        )

    refresh_banner()


    field_wages_node.update_value(WSData.get_field_wages_interval())
    total_wages_node.update_value(
        WSData.get_total_wages_interval() + WSData.get_unpaid_wages()
    )
    garrison_wages_node.update_value(int(WSData.get_garrison_wages_interval()))
    unpaid_wages_node.update_value(WSData.get_unpaid_wages())

func refresh_banner()-> void:
    lord_banner_node.init_by_hero_uid(
        SoldierUtils.get_player_hero_uid()
    )

func _on_edit_banner_button_custom_pressed()-> void:
    edit_banner_sign.emit()


func _on_show_wages_detail_page_button_custom_pressed()-> void:
    show_wages_detail_page_sign.emit()

func _on_income_detail_button_custom_pressed()-> void:
    show_income_detail_page_sign.emit()