class_name UnitTreeBox extends Control

@onready var unit_tree_root_node =$UnitTreeRoot
@onready var line_root_node =$LineRoot
const UNIT_TREE_ROW_NODE = preload("res://tscn/game/interface/ws/UnitTreeRow.tscn")
const CONNECT_LINE_NODE = preload("res://tscn/game/interface/ws/ConnectLine.tscn")
const UNIT_TREE_INSTRUCTIONS_NODE = preload("res://tscn/game/interface/ws/UnitTreeInstructions.tscn")

var node_dic = {}
var unit_upgrade_tree_data = []

signal view_info_sign(_soldier_prop: BSSoldierProp)

func _ready():
    pass


func init(_unit_tree_code: String):
    _clear()
    unit_upgrade_tree_data = UnitTreeConstants.get_unit_upgrade_tree_data(_unit_tree_code)

    for _item: Dictionary in unit_upgrade_tree_data:
        var _uid_list: Array = _item.keys()
        var unit_tree_row_instance = UNIT_TREE_ROW_NODE.instantiate()
        unit_tree_root_node.add_child(unit_tree_row_instance)
        unit_tree_row_instance.connect("view_info_sign", _view_info)

        var _node_dic: Dictionary = unit_tree_row_instance.init(_uid_list)
        for _key in _node_dic.keys():
            node_dic[_key] = _node_dic.get(_key)






    var unit_tree_instructions_instance = UNIT_TREE_INSTRUCTIONS_NODE.instantiate()
    unit_tree_root_node.add_child(unit_tree_instructions_instance)
    var _text = ""
    var _unit_tree_data = UnitTreeConstants.get_unit_tree_data(_unit_tree_code)
    if not WSData.unit_tree_is_unlock(_unit_tree_code) and _unit_tree_data.has("unlock_instructions"):
        _text = "解锁方式: " + _unit_tree_data.unlock_instructions

    _text +=("\n背景故事: " + CommonUtils.get_value(_unit_tree_data, "remark", "..."))

    unit_tree_instructions_instance.set_text(_text)


    call_deferred("_update_size")

func _update_size():
    custom_minimum_size = unit_tree_root_node.size

    call_deferred("_connect_line")

func _connect_line():
    for _item: Dictionary in unit_upgrade_tree_data:
        for _key in _item.keys():
            for _uid in _item.get(_key):
                var _point_list = node_dic.get(_key).get_point_list(node_dic.get(_uid))

                var connect_line_instance = CONNECT_LINE_NODE.instantiate() as ConnectLine
                line_root_node.add_child(connect_line_instance)
                connect_line_instance.init(_point_list, line_root_node.global_position)
                connect_line_instance.focus_effect()

func _clear():
    node_dic = {}
    unit_upgrade_tree_data = []
    CommonUtils.clear_node(unit_tree_root_node)
    CommonUtils.clear_node(line_root_node)

func _view_info(_soldier_prop: BSSoldierProp)-> void:
    view_info_sign.emit(_soldier_prop)