class_name UnitTreeInstructions extends Control

@onready var instructions_node =$Instructions

func set_text(_text)-> void:
    CommonUtils.set_text(instructions_node, _text)