class_name UnitTreeInterface extends Control

const UNIT_TREE_CHOOSE_BUTTON_02_NODE = preload("res://tscn/baseModule/button/UnitTreeChooseButton02.tscn")
@onready var animation_player_node =$UnitTreeBoxRoot / AnimationPlayer
@onready var unit_tree_box_node =$UnitTreeBoxRoot / BaseScrollContainer / UnitTreeBox
@onready var unit_list_v_box_container_node =$UnitListRoot / BaseScrollContainer / VBoxContainer
@onready var unit_tree_box_scroll_container_node =$UnitTreeBoxRoot / BaseScrollContainer
@onready var unlock_icon_node =$UnitTreeBoxRoot / LockIconRoot / UnlockIcon
@onready var lock_icon_node =$UnitTreeBoxRoot / LockIconRoot / LockIcon
@onready var name_node =$UnitTreeBoxRoot / NameRoot / Name

var choose_node = null

signal view_info_sign(_soldier_prop: BSSoldierProp)

func _ready():
    animation_player_node.play("icon_animation")

func init():

    _init_unit_tree_list()

    _refresh_data()


    unit_list_v_box_container_node.get_children()[0].choose(false)

func clear():
    CommonUtils.clear_node(unit_list_v_box_container_node)


func _refresh_data():
    for _node: UnitTreeChooseButton02 in unit_list_v_box_container_node.get_children():
        _node.refresh_data()


func _init_unit_tree_list():
    var _key_list: = []
    for _key in UnitTreeConstants.UNIT_TREE_DATA.keys():

        if not WSData.unit_tree_is_unlock(_key):
            continue

        var _data = UnitTreeConstants.get_unit_tree_data(_key)
        if not CommonUtils.get_value(_data, "is_show", true):
            continue

        _key_list.append(_key)

    for _key in UnitTreeConstants.UNIT_TREE_DATA.keys():

        if WSData.unit_tree_is_unlock(_key):
            continue

        var _data = UnitTreeConstants.get_unit_tree_data(_key)
        if not CommonUtils.get_value(_data, "is_show", true):
            continue

        _key_list.append(_key)

    for _key in _key_list:
        var unit_tree_choose_button_02_instance = UNIT_TREE_CHOOSE_BUTTON_02_NODE.instantiate()
        unit_list_v_box_container_node.add_child(unit_tree_choose_button_02_instance)
        unit_tree_choose_button_02_instance.init(_key)
        unit_tree_choose_button_02_instance.connect("b_pressed2_sign", _choose_unit_tree)

func _choose_unit_tree(_node):

    if is_instance_valid(choose_node) and choose_node.get_code() != _node.get_code():
        choose_node.cancel()

    choose_node = _node


    unit_tree_box_scroll_container_node.scroll_vertical = 0
    unit_tree_box_node.init(_node.get_code())

    var _color: Color = SoldierUtils.get_star_color(_node.get_max_star())
    CommonUtils.update_self_color(name_node, Color(_color.r * 1.3, _color.g * 1.3, _color.b * 1.3, _color.a))
    CommonUtils.set_text(name_node, _node.get_unit_tree_name())


    if WSData.unit_tree_is_unlock(_node.get_code()):
        unlock_icon_node.show()
        lock_icon_node.hide()
    else:
        unlock_icon_node.hide()
        lock_icon_node.show()

func _on_unit_tree_box_view_info_sign(_soldier_prop: BSSoldierProp)-> void:
    view_info_sign.emit(_soldier_prop)