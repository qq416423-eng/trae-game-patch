class_name UnitTreeRow extends HBoxContainer

const SOLDIER_BOX_NODE = preload("res://tscn/game/interface/soldier/SoldierBox.tscn")

signal view_info_sign(_soldier_prop: BSSoldierProp)

func init(_uid_list: Array)-> Dictionary:
    var result_dic = {}

    for _uid: String in _uid_list:
        var soldier_box_instance = SOLDIER_BOX_NODE.instantiate()
        add_child(soldier_box_instance)
        soldier_box_instance.size_flags_vertical = Control.SIZE_SHRINK_END
        soldier_box_instance.init_by_uid(_uid)

        soldier_box_instance.set_button_disable(true)
        result_dic[_uid] = soldier_box_instance
        soldier_box_instance.connect("view_info_sign", _view_info)


    return result_dic

func _view_info(_soldier_prop: BSSoldierProp)-> void:
    view_info_sign.emit(_soldier_prop)