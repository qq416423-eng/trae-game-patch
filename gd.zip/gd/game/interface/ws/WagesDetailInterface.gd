class_name WagesDetailInterface extends Control

@onready var v_box_container_node: VBoxContainer =$Background / BaseScrollContainer / VBoxContainer
@onready var total_wage_info_node: KeyValueItemInfo =$Background / TotalWageInfo
@onready var remark_node: Label =$Background / RemarkRoot / Remark
@onready var title_node: Label =$Background / TitleBackground / Title

const WAGES_ITEM_INFO = preload("res://tscn/game/interface/ws/KeyValueItemInfo.tscn")

signal close_sign()

var test_wages_info: = {
    "field_wages": 1000,
    "garrison_wages": {
        "MWVillage0029": 100,
        "MWCity0001": 1000,
        "MWVillage0001": 200,
        "MWSpecialLocation0004": 150,
        "MWSpecialLocation0001": 170,
        "MWSpecialLocation0002": 0,
    }
}

func _ready()-> void:
    CommonUtils.set_text(
        remark_node,

        ". 仅需支付驻军士兵" + str(TeamConfig.WAGES_GARRISON_FIELD * 100) + "%的薪酬" \
        + "\n. 每" + str(TeamConfig.WAGES_INTERVAL_DAYS) + "天发一次军饷"
    )
    CommonUtils.set_text(title_node, "军饷详情(每" + str(TeamConfig.WAGES_INTERVAL_DAYS) + "天)")




func init_by_wages_info(_wages_info_interval: Dictionary)-> void:
    _clear()

    var _total_wages: int = 0
    var _field_wages_info_node: = WAGES_ITEM_INFO.instantiate()
    v_box_container_node.add_child(_field_wages_info_node)
    _field_wages_info_node.init("随行部队", _wages_info_interval.field_wages)
    _total_wages += _wages_info_interval.field_wages


    var _location_code_list: Array = _wages_info_interval.garrison_wages.keys()

    _location_code_list.sort_custom(SortUtils.location_code_sort_by_type_desc)

    for _location_code: String in _location_code_list:
        var _wages_interval: int = _wages_info_interval.garrison_wages.get(_location_code)
        if _wages_interval <= 0:
            continue

        _total_wages += _wages_interval

        var _garrison_wages_info_node: = WAGES_ITEM_INFO.instantiate()
        v_box_container_node.add_child(_garrison_wages_info_node)
        _garrison_wages_info_node.init(
            LocationUtils.get_location_name_by_location_code(_location_code) + "驻军",

            int(_wages_interval)
        )



    var _unpaid_wages_info_node: = WAGES_ITEM_INFO.instantiate()
    v_box_container_node.add_child(_unpaid_wages_info_node)
    _unpaid_wages_info_node.init("历史欠薪", WSData.get_unpaid_wages())


    total_wage_info_node.update_value(_total_wages + WSData.get_unpaid_wages())

func chide()-> void:
    self.hide()

func _clear()-> void:
    CommonUtils.clear_node(v_box_container_node)

func _on_close_button_custom_pressed()-> void:


    close_sign.emit()