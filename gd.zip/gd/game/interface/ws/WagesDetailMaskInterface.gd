class_name WagesDetailMaskInterface extends Control

@onready var wages_detail_interface_node: WagesDetailInterface =$WagesDetailInterface

func init_player_wages_info()-> void:
    wages_detail_interface_node.init_by_wages_info(
        WSData.wages_info_interval
    )

func _delete()-> void:
    self.queue_free()

func _on_wages_detail_interface_close_sign()-> void:
    _delete()