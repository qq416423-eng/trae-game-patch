class_name WarehouseInterface extends GoodsExchangeInterface

var test_left_goods = []

func _custom_ready()-> void:

    pass

func init_warehouse(_location_code: String)-> void:
    init_warehouse_base(
        _location_code,
        WSData.get_player_goods(),
        WSLocationData.get_location_warehouse_json(_location_code),
        WSLocationData.get_warehouse_goods_count_limit(_location_code)
    )

func _test_add_good(_list_dic: Dictionary):
    var _goods_list: = [
        {
            "item": {
                "uid": "food_0001",
            },
            "count": 5
        },
    ]
    for _key: String in _list_dic.keys():
        _goods_list.append(
            {
                "item": {
                    "uid": _key,

                },
                "count": 1
            }
        )

    test_left_goods.append_array(_goods_list)