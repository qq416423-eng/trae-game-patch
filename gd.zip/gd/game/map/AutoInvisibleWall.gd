class_name AutoInvisibleWall extends StaticBody2D

@onready var collision_shape_2d_node: CollisionShape2D =$CollisionShape2D
@onready var collision_shape_2d_2_node: CollisionShape2D =$CollisionShape2D2
@onready var collision_shape_2d_3_node: CollisionShape2D =$CollisionShape2D3
@onready var collision_shape_2d_4_node: CollisionShape2D =$CollisionShape2D4









func init(
    left_top: Vector2, right_top: Vector2,
    right_bottom: Vector2, left_bottom: Vector2
)-> void:


















    collision_shape_2d_node.shape.segments = [
        left_top, right_top
    ]
    collision_shape_2d_2_node.shape.segments = [
        right_top, right_bottom
    ]
    collision_shape_2d_3_node.shape.segments = [
        right_bottom, left_bottom
    ]
    collision_shape_2d_4_node.shape.segments = [
        left_bottom, left_top
    ]