extends Control

@onready var floor_node =$Floor
@onready var bss_spray_node =$BSSSpray
@onready var bsb_spray_node =$BSBSpray
@onready var bss_rain_node =$BSSRain
@onready var bsb_rain_node =$BSBRain

@export var terrain_type: MWorldConstants.TERRAIN_TYPE_ENUM = MWorldConstants.TERRAIN_TYPE_ENUM.FLATLANDS

var origin_rain_speed_scale: = 0

func _ready():












    origin_rain_speed_scale = bss_spray_node.texture.speed_scale
    GlobalTimeControl.connect("time_scale_update_sign", _time_scale_update)

func update_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM)-> void:
    match _weather:
        MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
            pass
        MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN, MWorldConstants.WEATHER_TYPE_ENUM.RAIN:
            bss_rain_node.show()
            bss_spray_node.show()
        MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
            bsb_rain_node.show()
            bsb_spray_node.show()

func _time_scale_update(_time_scale: float)-> void:

    bss_spray_node.texture.speed_scale = origin_rain_speed_scale * _time_scale
    bsb_spray_node.texture.speed_scale = origin_rain_speed_scale * _time_scale
    bss_rain_node.texture.speed_scale = origin_rain_speed_scale * _time_scale
    bsb_rain_node.texture.speed_scale = origin_rain_speed_scale * _time_scale

func get_max_xy():
    var _max = size.x
    if size.y > _max:
        _max = size.y

    return _max