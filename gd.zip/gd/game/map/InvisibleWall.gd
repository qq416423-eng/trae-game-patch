class_name InvisibleWall extends CollisionPolygon2D

@onready var collision_polygon_2d_node =$StaticBody2D / CollisionPolygon2D

func _ready():
    collision_polygon_2d_node.polygon = polygon