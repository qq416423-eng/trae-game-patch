class_name LocationInfoTag extends HBoxContainer

@onready var name_node: Label =$PanelContainer / HBoxContainer / Name
@onready var flag_background_village_node: TextureRect =$FlagBackgroundVillage
@onready var flag_background_castle_node: TextureRect =$FlagBackgroundCastle
@onready var flag_background_city_node: TextureRect =$FlagBackgroundCity
@onready var flag_village_node: TextureRect =$FlagBackgroundVillage / FlagVillage
@onready var flag_castle_node: TextureRect =$FlagBackgroundCastle / FlagCastle
@onready var flag_city_node: TextureRect =$FlagBackgroundCity / FlagCity
@onready var hero_nop_node: Label =$PanelContainer / HBoxContainer / HeroNop
@onready var soldier_nop_node: Label =$PanelContainer / HBoxContainer / SoldierNop
@onready var soldier_nop_icon_node: TextureRect =$PanelContainer / HBoxContainer / SoldierNopIcon
@onready var hero_nop_icon_root_node: Container =$PanelContainer / HBoxContainer / HeroNopIconRoot
@onready var lord_banner_root_node: HBoxContainer =$LordBannerRoot
@onready var lord_banner_node: LordBanner =$LordBannerRoot / LordBanner

@export var type: String = "CITY"

func _ready():
    flag_background_village_node.hide()
    flag_background_castle_node.hide()
    flag_background_city_node.hide()

    var _font_size: int = 22
    match type:
        "VILLAGE":
            flag_background_village_node.show()
            hero_nop_node.hide()
            soldier_nop_node.hide()
            hero_nop_icon_root_node.hide()
            soldier_nop_icon_node.hide()
        "CASTLE":
            flag_background_castle_node.show()
        "CITY":
            _font_size = 24
            flag_background_city_node.show()

    name_node.set("theme_override_font_sizes/font_size", _font_size)
    hero_nop_node.set("theme_override_font_sizes/font_size", _font_size)
    soldier_nop_node.set("theme_override_font_sizes/font_size", _font_size)

func update_name(_name: String)-> void:
    CommonUtils.set_text(name_node, _name)


func update_by_country(_belong_country: String)-> void:
    var _country_color: Color = CountryUtils.get_country_color(_belong_country)
    match type:
        "VILLAGE":
            CommonUtils.update_self_color(flag_village_node, _country_color)
        "CASTLE":
            CommonUtils.update_self_color(flag_castle_node, _country_color)
        "CITY":
            CommonUtils.update_self_color(flag_city_node, _country_color)

func update_nop_info_color(_color: Color, _need_outline_size: = false)-> void:
    CommonUtils.update_color(hero_nop_node, _color)
    CommonUtils.update_color(soldier_nop_node, _color)







func update_nop_info(_hero_count: int, _soldier_count: int)-> void:
    CommonUtils.set_text(hero_nop_node, _hero_count)
    CommonUtils.set_text(soldier_nop_node, _soldier_count)

func refresh_banner(_owner_uid: String)-> void:
    if StringUtils.is_empty(_owner_uid):
        lord_banner_root_node.hide()
        return

    lord_banner_root_node.show()
    lord_banner_node.init_by_hero_uid(_owner_uid)