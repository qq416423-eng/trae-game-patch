extends RefCounted


const MOD_DENSE_FOREST_BASE_SCENE: String = "res://tscn/game/map/bMap/BMapForest0001.tscn"


const MOD_DENSE_TREE_TEX_PATHS: Array = [
    "res://resource/map/mod/tree_dense_0001.png",
    "res://resource/map/mod/tree_dense_0002.png",
]
const MOD_DENSE_BUSH_TEX_PATH: String = "res://resource/map/mod/bush_dense_0001.png"


const MOD_DENSE_MAP_W: float = 6000.0
const MOD_DENSE_MAP_H: float = 3600.0
const MOD_DENSE_TREE_COUNT: int = 360
const MOD_DENSE_BUSH_COUNT: int = 280
const MOD_DENSE_LCG_SEED: int = 20260827


var _mod_lcg_state: int = 0

func _mod_lcg_next()-> int:
    _mod_lcg_state =(_mod_lcg_state * 1103515245 + 12345) % -2147483648
    return _mod_lcg_state

func _mod_lcg_randf()-> float:
    return float(_mod_lcg_next()) / 2147483648.0


func instantiate()-> Control:
    var _scene: PackedScene = load(MOD_DENSE_FOREST_BASE_SCENE)
    if _scene == null:
        push_error("[MOD] 密林地图: 底图加载失败 " + MOD_DENSE_FOREST_BASE_SCENE)
        return null
    var _base: Control = _scene.instantiate()
    if _base == null or not(_base is Control):
        push_error("[MOD] 密林地图: 底图实例化异常")
        return null
    _mod_lcg_state = MOD_DENSE_LCG_SEED
    _scatter_forest(_base)
    return _base



func _scatter_forest(_base: Control)-> void:
    var _tree_tex_list: Array = []
    for _path in MOD_DENSE_TREE_TEX_PATHS:
        var _tex = load(_path)
        if _tex == null:
            push_warning("[MOD] 密林地图: 树贴图缺失 " + _path)
            return
        _tree_tex_list.append(_tex)
    var _bush_tex = load(MOD_DENSE_BUSH_TEX_PATH)
    if _bush_tex == null:
        push_warning("[MOD] 密林地图: 灌木贴图缺失 " + MOD_DENSE_BUSH_TEX_PATH)
        return


    for _i in range(MOD_DENSE_BUSH_COUNT):
        var _sp: Sprite2D = Sprite2D.new()
        _sp.texture = _bush_tex
        _sp.position = Vector2(_mod_lcg_randf() * MOD_DENSE_MAP_W, _mod_lcg_randf() * MOD_DENSE_MAP_H)
        var _s: float = 0.5 + _mod_lcg_randf() * 0.45
        _sp.scale = Vector2(_s, _s)
        _sp.flip_h = _mod_lcg_randf() < 0.5
        _sp.z_index = 0
        _sp.modulate = _mod_leaf_tint(0.8)
        _base.add_child(_sp)


    var _tree_pos_list: Array = []
    for _i in range(MOD_DENSE_TREE_COUNT):
        _tree_pos_list.append(
            Vector2(_mod_lcg_randf() * MOD_DENSE_MAP_W, _mod_lcg_randf() * MOD_DENSE_MAP_H)
        )
    _tree_pos_list.sort_custom(func(a, b): return a.y < b.y)
    for _pos in _tree_pos_list:
        var _tex = _tree_tex_list[_mod_lcg_next() % _tree_tex_list.size()]
        var _sp: Sprite2D = Sprite2D.new()
        _sp.texture = _tex
        _sp.position = _pos
        var _s: float = 0.62 + _mod_lcg_randf() * 0.55
        _sp.scale = Vector2(_s, _s)
        _sp.flip_h = _mod_lcg_randf() < 0.5
        _sp.z_index = 0
        _sp.modulate = _mod_leaf_tint(0.88)
        _base.add_child(_sp)


func _mod_leaf_tint(_dark: float)-> Color:
    var _v: float = _dark + _mod_lcg_randf() *(1.0 - _dark)
    return Color(_v, _v *(1.0 + _mod_lcg_randf() * 0.06), _v *(0.94 + _mod_lcg_randf() * 0.05), 1.0)