class_name ShoalTerrainArea extends TerrainArea


@export var cavalry_deceleration_ratio = 0.6

@export var infantry_deceleration_ratio = 0.45

func _custom_body_enter(_node: BSSoldier):
    _node.enter_shoal()
    var _deceleration_ratio = cavalry_deceleration_ratio
    if SoldierUtils.is_infantry(_node.bs_soldier_prop):
        _deceleration_ratio = infantry_deceleration_ratio

    _node.update_speed_mult(1.0 - _deceleration_ratio)

func _custom_body_exit(_node: BSSoldier):
    _node.exit_shoal()
    _node.update_speed_mult(1.0)

func _custom_area_enter(_node):
    _node.owner.set_in_water(true)

func _custom_area_exit(_node):
    if is_instance_valid(_node.owner):
        _node.owner.set_in_water(false)