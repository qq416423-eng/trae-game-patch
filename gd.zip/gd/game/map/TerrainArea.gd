class_name TerrainArea extends CollisionPolygon2D

@onready var area2d_collision_polygon2d_node =$Area2D / CollisionPolygon2D

func _ready():
    area2d_collision_polygon2d_node.polygon = polygon


func _custom_body_enter(_node: BSSoldier):
    pass


func _custom_body_exit(_node: BSSoldier):
    pass

func _custom_area_enter(_node):
    pass

func _custom_area_exit(_node):
    pass

func _on_area_2d_body_entered(body):
    _custom_body_enter(body)

func _on_area_2d_body_exited(body):
    _custom_body_exit(body)

func _on_area_2d_area_entered(area: Area2D)-> void:
    _custom_area_enter(area)

func _on_area_2d_area_exited(area: Area2D)-> void:
    _custom_area_exit(area)