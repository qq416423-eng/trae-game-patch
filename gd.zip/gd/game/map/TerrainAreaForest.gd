class_name TerrainAreaForest extends TerrainArea


@export var cavalry_deceleration_ratio = 0.4

@export var infantry_deceleration_ratio = 0.15

func _custom_body_enter(_node: BSSoldier):


    if _node != null and _node.has_method("mod_forest_swallow_enter") \
    and _node.mod_forest_swallow_enter():
        return

    var _deceleration_ratio = cavalry_deceleration_ratio
    if SoldierUtils.is_infantry(_node.bs_soldier_prop):
        _deceleration_ratio = infantry_deceleration_ratio

    _node.update_speed_mult(1.0 - _deceleration_ratio)

func _custom_body_exit(_node: BSSoldier):


    if _node != null and _node.has_method("mod_forest_swallow_exit") \
    and _node.mod_forest_swallow_exit():
        return

    _node.update_speed_mult(1.0)