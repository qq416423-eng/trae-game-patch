class_name BCloud extends TextureRect

var move_speed: = 1.0
var origin_move_speed: = move_speed
var move_direction = CommonConstants.DIRECTION_ENUM.RIGHT
var cloud_size: = Vector2.ZERO
var map_size: = Vector2.ZERO
var counter: = 0

var create_cloud_prob = 0.1

var has_send_need_create_cloud_sign: = false

signal need_create_cloud_sign(is_edge: bool)

func _ready():
    GlobalTimeControl.connect("time_scale_update_sign", _update_speed_by_time_scale)

func _update_speed_by_time_scale(_time_scale: float)-> void:
    move_speed = origin_move_speed * _time_scale

func _physics_process(_delta):
    counter += 1
    position.x += move_speed *(1 if move_direction == CommonConstants.DIRECTION_ENUM.RIGHT else -1)
    match move_direction:
        CommonConstants.DIRECTION_ENUM.RIGHT:
            if position.x > map_size.x:
                send_need_create_cloud_sign()
                CommonUtils.delete_node(self)
        CommonConstants.DIRECTION_ENUM.LEFT:
            if position.x < - cloud_size.x:
                send_need_create_cloud_sign()
                CommonUtils.delete_node(self)


    if CommonUtils.counter_is_true(counter, 30):
        match move_direction:
            CommonConstants.DIRECTION_ENUM.RIGHT:
                if position.x > 0 and CommonUtils.prob_true(create_cloud_prob):
                    send_need_create_cloud_sign()
            CommonConstants.DIRECTION_ENUM.LEFT:
                if position.x + cloud_size.x < map_size.x and CommonUtils.prob_true(create_cloud_prob):
                    send_need_create_cloud_sign()

func send_need_create_cloud_sign():
    if not has_send_need_create_cloud_sign:
        has_send_need_create_cloud_sign = true
        need_create_cloud_sign.emit(true)


func init(
    _texture: Texture2D, _map_size: Vector2, _move_direction: int,

    _is_edge: bool):
    CommonUtils.update_texture3(self, _texture)

    move_direction = _move_direction
    cloud_size = _texture.get_size() * 2
    map_size = _map_size

    var _allow_y_range = [- cloud_size.y + 500, map_size.y - 500]
    var _init_x = 0
    match move_direction:
        CommonConstants.DIRECTION_ENUM.LEFT:
            _init_x = map_size.x
        CommonConstants.DIRECTION_ENUM.RIGHT:
            _init_x = - cloud_size.x

    if not _is_edge:
        _init_x = CommonUtils.random_num(map_size.x)

    position = Vector2(_init_x, CommonUtils.random_num2(_allow_y_range[0], _allow_y_range[1]))