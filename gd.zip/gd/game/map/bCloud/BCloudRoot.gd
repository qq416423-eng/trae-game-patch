class_name BCloudRoot extends Node2D



const CLOUD_PIC_LIST = [
    preload("res://resource/map/bcloud/cloud0001.png"),
    preload("res://resource/map/bcloud/cloud0002.png"),
    preload("res://resource/map/bcloud/cloud0003.png"),
    preload("res://resource/map/bcloud/cloud0004.png"),
    preload("res://resource/map/bcloud/cloud0005.png"),
    preload("res://resource/map/bcloud/cloud0006.png"),
    preload("res://resource/map/bcloud/cloud0007.png"),
    preload("res://resource/map/bcloud/cloud0008.png"),
    preload("res://resource/map/bcloud/cloud0009.png"),
    preload("res://resource/map/bcloud/cloud0010.png"),
    preload("res://resource/map/bcloud/cloud0011.png"),
    preload("res://resource/map/bcloud/cloud0012.png"),
]

const B_CLOUD_NODE = preload("res://tscn/game/map/bCloud/BCloud.tscn")

var map_size: = Vector2.ZERO
var direction: = CommonConstants.DIRECTION_ENUM.RIGHT

func init(_map_size: Vector2):
    map_size = _map_size
    direction = [CommonConstants.DIRECTION_ENUM.LEFT, CommonConstants.DIRECTION_ENUM.RIGHT].pick_random()

    create_cloud(false)

func open_or_close_by_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM):
    if _weather == MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
        pass
    else:
        clear()

func create_cloud(_is_edge: bool = true):
    var b_cloud_instance = B_CLOUD_NODE.instantiate()
    add_child(b_cloud_instance)
    b_cloud_instance.init(CLOUD_PIC_LIST.pick_random(), map_size, direction, _is_edge)
    b_cloud_instance.connect("need_create_cloud_sign", create_cloud)

func clear():
    CommonUtils.clear_node(self)