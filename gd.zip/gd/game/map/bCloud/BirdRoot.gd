class_name BirdRoot extends Node2D

const MW_BIRDS_NODE = preload("res://tscn/game/mw/MWBirds.tscn")


@export var bird_speed: = 220
@export var bird_height = 400

var map_size = Vector2.ZERO


var counter: = 0

func init(_map_size: Vector2):
    map_size = _map_size
    var _random_count = CommonUtils.random_num2(2, 5)
    for _index in range(_random_count):
        create_bird(false)

func open_or_close_by_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM):
    if _weather == MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
        set_physics_process(true)
    else:
        set_physics_process(false)
        clear()

func _physics_process(_delta):
    counter += 1
    if CommonUtils.counter_is_true(counter, 30) and CommonUtils.prob_true(0.1):
        create_bird(true)


func create_bird(_is_edge: bool):
    var mw_birds_instance = MW_BIRDS_NODE.instantiate()
    self.add_child(mw_birds_instance)

    var _random_position_list: = _get_random_position_list()
    mw_birds_instance.random_init(5, _random_position_list, bird_height, _is_edge, bird_speed)

func _get_random_position_list()-> Array[Vector2]:
    var random_num: = CommonUtils.random_num(3)
    var random_position_list: Array[Vector2] = []
    var _extra_value = 200
    match random_num:
        0:

            random_position_list = [
                Vector2(- _extra_value, CommonUtils.random_num2(_extra_value, map_size.y - _extra_value)),
                Vector2(map_size.x, CommonUtils.random_num2(0, map_size.y))
            ]
        1:

            random_position_list = [
                Vector2(CommonUtils.random_num2(_extra_value, map_size.x - _extra_value), - _extra_value),
                Vector2(CommonUtils.random_num2(0, map_size.x), map_size.y)
            ]
        2:

            random_position_list = [
                Vector2(map_size.x + _extra_value, CommonUtils.random_num2(_extra_value, map_size.y - _extra_value)),
                Vector2(0, CommonUtils.random_num2(0, map_size.y))
            ]
        3:

            random_position_list = [
                Vector2(CommonUtils.random_num2(_extra_value, map_size.x - _extra_value), map_size.y + _extra_value),
                Vector2(CommonUtils.random_num2(0, map_size.x), 0)
            ]

    return random_position_list

func clear():
    CommonUtils.clear_node(self)
    counter = 0