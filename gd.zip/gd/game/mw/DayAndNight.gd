extends Node2D
class_name DayAndNight

@onready var animation_player_node =$AnimationPlayer

var init_seek_ratio: = 0.0

signal to_night_sign()
signal to_day_sign()

func _ready()-> void:
    pass

func start():
    var _speed = 1.0 / MWConfig.ONE_DAY_SECONDS
    animation_player_node.speed_scale = _speed
    animation_player_node.play("run")

    seek(init_seek_ratio)




func to_night():
    emit_signal("to_night_sign")

func to_day():
    emit_signal("to_day_sign")

func update_init_seek(_time: float):
    init_seek_ratio = _time

func seek(_time: float):

    animation_player_node.seek(
        animation_player_node.get_animation("run").length * init_seek_ratio,
        true, true
    )