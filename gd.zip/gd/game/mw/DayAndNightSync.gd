class_name DayAndNightSync extends Node2D

@onready var canvas_modulate_node: CanvasModulate =$CanvasModulate

var init_seek_ratio: = 0.0
var _world_node: MWorldScene

signal to_night_sign()
signal to_day_sign()

func _ready()-> void:
    _world_node = owner
    stop()

func _physics_process(delta: float)-> void:
    canvas_modulate_node.color = _world_node.get_day_light_color()

func start()-> void:
    set_physics_process(true)
    canvas_modulate_node.color = _world_node.get_day_light_color()

func stop()-> void:
    set_physics_process(false)