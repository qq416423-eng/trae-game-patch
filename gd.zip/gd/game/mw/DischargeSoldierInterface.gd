class_name DischargeSoldierInterface extends Control

@onready var count_node: Label =$FuncRoot / Content / Count
@onready var plus_button_node: IconFloatButton =$FuncRoot / PlusButton
@onready var subtract_button_node: IconFloatButton =$FuncRoot / SubtractButton
@onready var confirm_button_node: CommonButton2 =$ButtonRoot / ConfirmButton

var max_count: = 0
var current_count: = 0


signal wanna_discharge_soldier_sign(_count: int)

func cshow(_max_count: int):
    current_count = 0
    max_count = _max_count
    _refresh_count_content()
    _refresh_button_style()
    self.show()

func chide():
    self.hide()

func _refresh_count_content():
    CommonUtils.set_text(count_node, str(current_count) + "/" + str(max_count))

func _refresh_button_style():
    plus_button_node.cancel_disable()
    subtract_button_node.cancel_disable()
    confirm_button_node.disabled = false

    if current_count <= 0:
        subtract_button_node.disable()
        confirm_button_node.disabled = true
    elif current_count >= max_count:
        plus_button_node.disable()

func _on_plus_button_c_pressed()-> void:
    current_count += 1
    if current_count > max_count:
        current_count = max_count

    _refresh_count_content()
    _refresh_button_style()

func _on_subtract_button_c_pressed()-> void:
    current_count -= 1
    if current_count < 0:
        current_count = 0

    _refresh_count_content()
    _refresh_button_style()

func _on_close_button_pressed()-> void:
    chide()


func _on_confirm_button_pressed()-> void:
    wanna_discharge_soldier_sign.emit(current_count)


func _on_all_button_pressed()-> void:
    current_count = max_count

    _refresh_count_content()
    _refresh_button_style()