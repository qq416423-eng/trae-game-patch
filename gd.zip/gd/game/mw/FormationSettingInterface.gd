class_name FormationSettingInterface extends Control

const FORMATION_ICON_BUTTON_NODE = preload("res://tscn/game/interface/button/FormationIconButton.tscn")
const FORMATION_ICON_BUTTON_ONLY_BACKGROUND_NODE = preload("res://tscn/game/interface/button/FormationIconButtonOnlyBackground.tscn")

@onready var num_grid_container =$FormationSettingPage / NumArea / GridContainer
@onready var icon_grid_container =$IconSettingPage / IconArea / GridContainer
@onready var color_grid_container =$IconSettingPage / ColorArea / GridContainer
@onready var icon_setting_button_node =$FormationSettingPage / IconSettingButton
@onready var icon_setting_page_node =$IconSettingPage
@onready var icon_area_node =$IconSettingPage / IconArea
@onready var color_area_node =$IconSettingPage / ColorArea

var select_num_node = null
var select_icon_node = null
var select_color_node = null

signal need_refresh_sign(_group_num)
signal close_sign()

func _ready():
    _init_num_list()
    _init_icon_list()
    _init_color_list()

func init_by_uid(_split_group_uid: String)-> void:
    _clear()
    var _group_num: int = WSData.get_group_num(_split_group_uid)
    if _group_num != -1:
        init_by_group_num(_group_num)
        icon_setting_button_node.disabled = false
    else:
        icon_setting_button_node.disabled = true

func init_by_group_num(_group_num: int):
    choose_by_group_num(_group_num)
    var _config = WSData.get_group_icon_config(_group_num)
    choose_icon_by_icon_code(_config.code)
    choose_color_by_color(_config.color)
    need_refresh_sign.emit(get_current_group_num())

func choose_color_by_color(_color: Color)-> void:
    for _node: FormationIconButton in color_grid_container.get_children():
        if _node.color == _color:
            _node.choose(false)
            break

func choose_icon_by_icon_code(_code: String)-> void:
    if select_icon_node != null:
        select_icon_node.cancel()

    for _node: FormationIconButton in icon_grid_container.get_children():
        if _node.code == _code:
            _node.show_select_effect()
            select_icon_node = _node
            break

func choose_by_group_num(_group_num: int)-> void:
    if select_num_node != null:
        select_num_node.cancel()

    for _node: FormationIconButton in num_grid_container.get_children():
        if _node.value == _group_num:


            _node.show_select_effect()
            select_num_node = _node
            if icon_setting_button_node.disabled:
                icon_setting_button_node.disabled = false

            break

func get_current_group_num():
    return select_num_node.value

func _init_num_list():
    for _node: FormationIconButton in num_grid_container.get_children():
        _node.init_by_group_num(_node.value)
        _node.connect("b_pressed2_sign", _choose_num)

func _init_icon_list():
    for _key in GroupConstants.GROUP_ICON_CONFIG.keys():
        var _dic_value: Dictionary = GroupConstants.GROUP_ICON_CONFIG.get(_key)
        var _instance: FormationIconButton = FORMATION_ICON_BUTTON_NODE.instantiate()
        icon_grid_container.add_child(_instance)
        _instance.update_icon(_dic_value.path)
        _instance.set_code(_key)
        _instance.connect("b_pressed2_sign", _choose_icon)

func _init_color_list():
    for _color: Color in GroupConstants.GROUP_ICON_BACKGROUND_COLOR_LIST:
        var _instance: FormationIconButton = FORMATION_ICON_BUTTON_ONLY_BACKGROUND_NODE.instantiate()
        color_grid_container.add_child(_instance)
        _instance.update_color(_color)
        _instance.connect("b_pressed2_sign", _choose_color)

func _choose_color(_choose_node):
    if select_color_node != null and select_color_node != _choose_node:
        select_color_node.cancel()

    for _node: FormationIconButton in icon_grid_container.get_children():
        _node.update_color(_choose_node.color)

    select_color_node = _choose_node
    var _group_num = get_current_group_num()
    if _group_num != -1:
        WSData.update_group_icon_config(_group_num, null, _choose_node.color)
        _refresh_num_style()

func _choose_icon(_choose_node):
    if CommonUtils.is_not_null(select_icon_node) and _choose_node != select_icon_node:
        select_icon_node.cancel()

    select_icon_node = _choose_node
    var _group_num = get_current_group_num()
    if _group_num != -1:
        WSData.update_group_icon_config(_group_num, _choose_node.code, null)
        _refresh_num_style()

func _choose_num(_choose_node):
    init_by_group_num(_choose_node.value)

func _refresh_num_style():
    if select_num_node == null:
        return

    select_num_node.refresh()
    need_refresh_sign.emit(get_current_group_num())


func _clear():
    if select_num_node != null:
        select_num_node.cancel()
    if select_icon_node != null:
        select_icon_node.cancel()
    if select_color_node != null:
        select_color_node.cancel()

func _open_icon_setting_page():
    icon_setting_page_node.show()
    icon_setting_button_node.disabled = true

func chide():
    hide()
    hide_icon_setting_page()

func hide_icon_setting_page():
    icon_setting_page_node.hide()

func _on_icon_setting_button_pressed():
    _open_icon_setting_page()

func _on_close_button_custom_pressed()-> void:
    chide()
    close_sign.emit()