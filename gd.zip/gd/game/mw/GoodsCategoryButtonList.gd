class_name GoodsCategoryButtonList extends Control

@onready var h_box_container_node: HBoxContainer =$HBoxContainer



var hide_category_list = []
var category_list = []

signal change_hide_category_sign(_hide_category_list: Array)

func _ready()-> void:
    for _node: GoodsCategoryButton in h_box_container_node.get_children():
        category_list.append(_node.get_value())

func hide_category(_city_location_type_enum: String)-> void:
    if hide_category_list.has(_city_location_type_enum):
        return

    hide_category_list.append(_city_location_type_enum)

func show_category(_city_location_type_enum: String)-> void:
    if hide_category_list.has(_city_location_type_enum):
        hide_category_list.erase(_city_location_type_enum)

func get_hide_category_list()-> Array:
    return hide_category_list

func update_show_category_list(_show_category_list: Array)-> void:
    update_hide_category_list(_tranfer_hide_category_list(_show_category_list))

func update_hide_category_list(_hide_category_list: Array)-> void:
    hide_category_list = _hide_category_list
    for _node: GoodsCategoryButton in h_box_container_node.get_children():
        _node.switch(not hide_category_list.has(_node.get_value()))

    change_hide_category_sign.emit(hide_category_list)
    _appear()

func hide_and_clear()-> void:
    hide_category_list = []
    chide()

func chide()-> void:
    self.hide()

func show_category_save()-> void:
    var _save_hide_category_list = WSData.get_save_hide_category_list()
    update_hide_category_list(_save_hide_category_list)

func cshow()-> void:
    self.show()

func _appear()-> void:
    cshow()
    self.modulate.a = 0.0
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(self, "modulate:a", 0, 0.7)
    _tween.tween_property(self, "modulate:a", 1.0, 0.3)

func _tranfer_hide_category_list(_show_category_list: Array)-> Array:
    var _result: = []
    for _category: String in category_list:
        if not _show_category_list.has(_category):
            _result.append(_category)

    return _result

func _on_weapon_button_pressed_sign(_is_choose: bool, _location_type_enum: String)-> void:
    _change_category_show(_is_choose, _location_type_enum)

func _on_armour_button_pressed_sign(_is_choose: bool, _location_type_enum: String)-> void:
    _change_category_show(_is_choose, _location_type_enum)

func _on_horse_button_pressed_sign(_is_choose: bool, _location_type_enum: String)-> void:
    _change_category_show(_is_choose, _location_type_enum)

func _on_grocery_button_pressed_sign(_is_choose: bool, _location_type_enum: String)-> void:
    _change_category_show(_is_choose, _location_type_enum)

func _change_category_show(_is_choose: bool, _location_type_enum: String)-> void:
    if _is_choose:
        show_category(_location_type_enum)
    else:
        hide_category(_location_type_enum)

    change_hide_category_sign.emit(hide_category_list)