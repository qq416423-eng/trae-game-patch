class_name GoodsCategoryButtonListForShop extends Control

@onready var h_box_container_node: HBoxContainer =$HBoxContainer


@export var is_switch_style_on_press: = true

var choose_node: GoodsCategoryButton = null

signal change_category_sign(_location_type_enum)

func _ready()-> void:
    for _node: GoodsCategoryButton in h_box_container_node.get_children():
        _node.is_switch_style_on_press = is_switch_style_on_press

func show_ani()-> void:
    self.show()

func choose(_location_type_enum: String)-> void:
    if CommonUtils.is_not_null(choose_node):
        choose_node.switch(false)

    for _node: GoodsCategoryButton in h_box_container_node.get_children():
        if _node.get_value() == _location_type_enum:
            _node.switch(true)
            choose_node = _node
            break

func clear()-> void:
    choose_node = null
    for _node: GoodsCategoryButton in h_box_container_node.get_children():
        _node.switch(false)

func _on_category_button_pressed_sign(_is_choose: bool, _value: String)-> void:
    if _is_choose and is_switch_style_on_press:
        choose(_value)

    change_category_sign.emit(_value)