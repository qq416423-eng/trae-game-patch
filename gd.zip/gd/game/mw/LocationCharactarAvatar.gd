class_name LocationCharactarAvatar extends Control

@onready var avatar_wb_node: AvatarWB =$Mask / AvatarWB
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

func init_and_play_effect(_hero_uid: String)-> void:
    self.modulate.a = 0.0
    avatar_wb_node.init(
        SoldierUtils.get_bs_soldier_prop_by_uid(_hero_uid)
    )
    GlobalTimeControl.connect("time_scale_update_sign", _update_speed_by_time_scale)
    animation_player_node.speed_scale = 1 / GlobalTimeControl.current_time_scale

    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(self, "modulate:a", 0.5, 0.3)

    await _tween.finished
    animation_player_node.play("effect")

func _update_speed_by_time_scale(_time_scale: float)-> void:
    animation_player_node.speed_scale = 1 / _time_scale

func delete()-> void:
    animation_player_node.stop()
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(self, "modulate:a", 0, 0.3)

    await _tween.finished
    self.queue_free()