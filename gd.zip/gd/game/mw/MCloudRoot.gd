class_name MCloudRoot extends Node2D

const MW_CLOUD_NODE = preload("res://tscn/game/mw/MWCloud.tscn")

var map_size: = Vector2.ZERO
var counter: = 0

func _physics_process(delta):
    counter += 1
    if CommonUtils.counter_is_true(counter, 60) and CommonUtils.prob_true(0.06):
        _create_cloud(true)

func init(_map_size: Vector2):
    map_size = _map_size
    var _init_count = CommonUtils.random_num2(3, 6)
    for _index in range(_init_count):
        _create_cloud(false)

func _create_cloud(_is_edge: bool)-> void:
    var _random_position = _get_random_position(_is_edge)
    var mw_cloud_instance = MW_CLOUD_NODE.instantiate()
    self.add_child(mw_cloud_instance)
    mw_cloud_instance.init(_random_position, map_size)

func _get_random_position(_is_edge: bool)-> Vector2:
    var _flat = false
    var _position: = Vector2.ZERO
    while(not _flat):
        _flat = true
        _position = Vector2(-300, CommonUtils.random_num2(200, map_size.y - 200))
        if not _is_edge:
            _position.x = CommonUtils.random_num2(0, map_size.x)

        for _cloud_node in self.get_children():
            if CommonUtils.get_distance_square2(_position, _cloud_node.position) < 300 * 300:
                _flat = false
                continue

    return _position