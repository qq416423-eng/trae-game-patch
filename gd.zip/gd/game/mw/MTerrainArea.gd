class_name MTerrainArea extends CollisionPolygon2D

@onready var area2d_collision_polygon2d_node =$Area2D / CollisionPolygon2D

@export var terrain_type: = MWorldConstants.TERRAIN_TYPE_ENUM.FLATLANDS

func _ready():
    area2d_collision_polygon2d_node.polygon = polygon


func _custom_body_enter(_node: MWTeam):
    pass


func _custom_body_exit(_node: MWTeam):
    pass

func _on_area_2d_body_entered(body):

    body.terrain_enter(terrain_type)
    _custom_body_enter(body)

func _on_area_2d_body_exited(body):
    if GlobalNode.get_is_in_battle():


        return

    body.terrain_exit(terrain_type)
    _custom_body_exit(body)