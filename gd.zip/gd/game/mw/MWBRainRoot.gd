class_name MWBRainRoot extends Node2D

@onready var mwb_rain_node =$MWBRain
@onready var mwb_rain_2_node =$MWBRain2

var open_rain1: = false
var open_rain2: = false
var current_weather: = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR

func update_size(_size: Vector2)-> void:
    mwb_rain_node.size = _size / 2
    mwb_rain_2_node.size = _size / 2

func update_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM)-> void:
    if current_weather == _weather:
        return

    var _open_rain1: = false
    var _open_rain2: = false

    match _weather:
        MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
            pass
        MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN:
            _open_rain1 = true
        MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
            _open_rain1 = true
            _open_rain2 = true

    if _open_rain1 != open_rain1:
        var _tween = get_tree().create_tween()
        _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        if _open_rain1:
            mwb_rain_node.show()
            _tween.tween_property(
                mwb_rain_node, "self_modulate:a",
                1.0, 0.5
            )
        else:
            _tween.tween_property(
                mwb_rain_node, "self_modulate:a",
                0.0, 0.5
            )
            _tween.connect("finished", mwb_rain_node.hide)

    if _open_rain2 != open_rain2:
        var _tween = get_tree().create_tween()
        _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        if _open_rain2:
            mwb_rain_2_node.show()
            _tween.tween_property(
                mwb_rain_2_node, "self_modulate:a",
                1.0, 0.5
            )
        else:
            _tween.tween_property(
                mwb_rain_2_node, "self_modulate:a",
                0.0, 0.5
            )
            _tween.connect("finished", mwb_rain_2_node.hide)

    open_rain1 = _open_rain1
    open_rain2 = _open_rain2
    current_weather = _weather