extends Node2D

@onready var bird_root_node =$BirdRoot
@onready var shadow_root_node =$ShadowRoot

const MW_BIRDS_NODE = preload("res://tscn/game/mw/MWBird.tscn")
const MW_BIRD_SHADOW_NODE = preload("res://tscn/game/mw/MWBirdShadow.tscn")

var origin_speed: float = 0.0005
var speed: float = 0.0005
var start_point: Vector2
var current_time: float = 0.0
var peak_point: Vector2
var color_list: = [
    Color("a1887f"),
    Color("8d6e63"),
    Color("795548"),
    Color("6d4c41"),
    Color("5d4037"),
    Color("4e342e"),
    Color("3e2723"),
    Color("757575"),
    Color("e0e0e0"),
    Color("bdbdbd"),
    Color("bcaaa4")
]

@export var end_point: Vector2
@export var bird_color: Color
@export var bird_point_list: Array[Vector2] = [Vector2(0, 0)]

func _ready():
    GlobalTimeControl.connect("time_scale_update_sign", _update_speed_by_time_scale)

func _physics_process(_delta):
    self._fly()


func random_init(
    _max_count: int, _random_position_list: Array,
    _bird_height: int, _is_edge: bool,
    _bird_speed: int
    )-> void:
    start_point = _random_position_list[0]
    end_point = _random_position_list[1]

    peak_point =(start_point + end_point) / 2 \
    + Vector2(CommonUtils.random_num2(-3000, 3000), 0).rotated((end_point - start_point).angle() +(PI / 2))

    _random_color()
    CommonUtils.update_color(bird_root_node, bird_color)

    shadow_root_node.position.y = _bird_height




    _update_speed(CommonUtils.random_num2(_bird_speed - 20, _bird_speed + 20))
    bird_point_list = random_position(CommonUtils.random_num2(1, _max_count))


    for _point: Vector2 in bird_point_list:
        var _bird_instance = MW_BIRDS_NODE.instantiate()
        bird_root_node.add_child(_bird_instance)
        _bird_instance.position = _point
        var _frame = _bird_instance.seek_fly_animation()

        var _shadow_shadow_instance = MW_BIRD_SHADOW_NODE.instantiate()
        shadow_root_node.add_child(_shadow_shadow_instance)
        _shadow_shadow_instance.position = _point
        _shadow_shadow_instance.seek_fly_animation(_frame)

    if _is_edge:
        self.position = start_point
    else:
        _seek(CommonUtils.random_float(0.0, 1.0))

    _update_speed_by_time_scale(GlobalTimeControl.get_current_time_scale())

func _update_speed_by_time_scale(_time_scale: float)-> void:
    speed = origin_speed * _time_scale

func _update_speed(_speed: float)-> void:
    speed = _speed /(CommonUtils.get_distance(end_point, start_point) * 60)
    origin_speed = speed

func _random_color()-> void:
    bird_color = color_list.pick_random()


func random_position(_count: int)-> Array[Vector2]:
    var range_vector: = Vector2(200, 200)
    var distance_min_square: = 20 * 20

    var _result: Array[Vector2] = []
    for _index in range(_count):

        var _success = false
        var _random_position: = Vector2.ZERO
        while(not _success):
            _random_position = Vector2(CommonUtils.random_num(range_vector.x), CommonUtils.random_num(range_vector.x))
            _success = true
            for _position in _result:
                if CommonUtils.get_distance_square2(_position, _random_position) > distance_min_square:
                    pass
                else:
                    _success = false

        _result.append(_random_position)

    return _result

func _seek(_current_time: float)-> void:
    current_time = _current_time
    _fly()

func _fly():
    var _q0 = start_point.lerp(peak_point, current_time)
    var _q1 = peak_point.lerp(end_point, current_time)

    var _r = _q0.lerp(_q1, current_time)
    self.global_position = _r
    bird_root_node.rotation = _q0.direction_to(_q1).angle()
    shadow_root_node.rotation = _q0.direction_to(_q1).angle()
    current_time += speed

    if current_time > 1.0:
        CommonUtils.delete_node(self)