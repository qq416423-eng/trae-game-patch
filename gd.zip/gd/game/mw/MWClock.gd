class_name MWClockAndDayLightController extends Control

@onready var animation_player_node =$AnimationPlayer

@onready var canvas_modulate_node: CanvasModulate =$CanvasModulate

var init_seek_ratio: float = 0

signal system_time_pass_sign(_plus_time)
signal to_night_sign()
signal to_day_sign()

func start():
    var _speed = 1.0 / MWConfig.ONE_DAY_SECONDS
    animation_player_node.speed_scale = _speed
    animation_player_node.play("run")


    animation_player_node.seek(animation_player_node.get_animation("run").length * init_seek_ratio, true, true)

func stop():
    animation_player_node.pause()


func restart():
    animation_player_node.play("run")



func add_time(_plus_time: float):
    WSData.plus_system_counter(_plus_time)
    emit_signal("system_time_pass_sign", _plus_time)









func update_init_seek(_ratio: float):
    init_seek_ratio = _ratio

func to_night():
    emit_signal("to_night_sign")

func to_day():
    emit_signal("to_day_sign")

func get_day_light_color()-> Color:
    return canvas_modulate_node.color