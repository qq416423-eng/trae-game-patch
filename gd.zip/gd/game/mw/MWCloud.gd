extends Node2D

@onready var shadow_node =$Shadow
@onready var cloud_node =$Cloud


const SHAPE_NUM = 5
const CLOUD_PIC_PATH_ORIGIN = "res://resource/mw/cloud/cloud_{0}.png"
const CLOUD_SHADOW_PATH_ORIGIN = "res://resource/mw/cloud/cloud_s_{0}.png"

var speed = 0.5

var zoom_x_standard = 1.1
var zoom_x_min = 0.5
var zoom_x_section = zoom_x_standard - zoom_x_min
var max_transparency: = MWConfig.CLOUD_SECTION_MAX_TRANSPARENCY


var map_size = Vector2.ZERO

func _ready():
    var _random_num = CommonUtils.random_num(SHAPE_NUM - 1)
    var _cloud_pic_path = StringUtils.replace(CLOUD_PIC_PATH_ORIGIN,[_random_num])
    var _shadow_pic_path = StringUtils.replace(CLOUD_SHADOW_PATH_ORIGIN,[_random_num])
    CommonUtils.update_texture2(shadow_node, _shadow_pic_path)
    CommonUtils.update_texture2(cloud_node, _cloud_pic_path)
    speed = CommonUtils.random_num2(30, 60) / 100.0

    GlobalApplication.connect("change_zoom_sign", _mw_update_zoom)

    cloud_node.modulate.a = 0.0

func _physics_process(delta):
    position += Vector2(self.speed, 0)
    if position.x > map_size.x + 300:
        CommonUtils.delete_node(self)




func init(_position: Vector2, _map_size: Vector2):
    position = _position
    map_size = _map_size
    _mw_update_zoom(GlobalNode.get_mw_zoom())

func _mw_update_zoom(_zoom: Vector2):
    var _transparency = 0.0
    if _zoom.x < zoom_x_standard:
        _transparency =(zoom_x_standard - _zoom.x) * max_transparency / zoom_x_section

    if _transparency > max_transparency:
        _transparency = max_transparency

    CommonUtils.update_color(cloud_node, Color(1, 1, 1, _transparency))