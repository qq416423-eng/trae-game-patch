class_name MWTopBox extends Control

@onready var terrain_switch_icon_node =$TerrainSwitchIcon
@onready var weather_switch_icon_node =$WeatherSwitchIcon
@onready var day_node: Label =$DayInfoRoot / Day

func update_ferrain_type(_ferrain_type: int)-> void:
    terrain_switch_icon_node.update_terrain_type(_ferrain_type)

func update_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM)-> void:
    weather_switch_icon_node.update_weather(_weather)

func update_day_or_night(_is_day: bool)-> void:
    terrain_switch_icon_node.update_day_or_night(_is_day)
    weather_switch_icon_node.update_day_or_night(_is_day)

func update_day():
    _update_day(int(WSData.system_counter) + 1)

func _update_day(_day: int)-> void:
    CommonUtils.set_text(day_node, _day)