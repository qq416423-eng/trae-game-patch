class_name MWorldLeftInfoArea extends Control

@onready var stop_run_button_node =$StopRunButton as IconSwitchButton
@onready var money_box_node =$InfoRoot / MoneyBox as IconValueBox
@onready var hp_box_node =$InfoRoot / HpBox as IconValueBox
@onready var nop_box_node =$InfoRoot / NopBox as IconValueBox
@onready var hurt_nop_box_node =$InfoRoot / HurtNopBox as IconValueBox
@onready var morale_box_node =$InfoRoot / MoraleBox as IconValueBox
@onready var food_box_node =$InfoRoot / FoodBox as IconValueBox
@onready var speed_box_node =$InfoRoot / SpeedBox
@onready var view_button_node: IconSwitchButton =$ViewButton
@onready var append_button_background_node: TextureRect =$StopRunButton / AppendButtonBackground
@onready var common_speed_button_node: MenuButton2 =$StopRunButton / AppendButtonBackground / CommonSpeedButton
@onready var double_speed_button_node: MenuButton2 =$StopRunButton / AppendButtonBackground / DoubleSpeedButton
@onready var surrender_nop_box_node: IconValueBox =$InfoRoot / SurrenderNopBox
@onready var rest_button_background_node: TextureRect =$StopRunButton / RestButtonBackground


var is_quick_speed: = false
var _button_disable: = false

signal stop_or_run_sign(_value)
signal view_mode_sign()
signal player_camping_sign()
signal player_train_sign()

func speed_button_init():
    common_speed_button_node.pressed(false)


func refresh():


    var team_info: TeamInfo = WSData.get_player_team_info()

    money_box_node.set_text(WSData.get_player_money())
    hp_box_node.set_text(str(team_info.hp_percent) + "%")
    nop_box_node.set_text(team_info.count)
    hurt_nop_box_node.set_text(team_info.hurt_nop)
    morale_box_node.set_text(int(team_info.current_morale))
    food_box_node.set_text(team_info.food_stock_value)
    speed_box_node.set_text(team_info.get_speed())
    surrender_nop_box_node.set_text(

        str(team_info.surrender_count) + "/" + str(team_info.capture_count)
    )

func get_value():
    return stop_run_button_node.current_value

func stop_button():
    stop_run_button_node.switch(false)

func run_button():
    stop_run_button_node.switch(true)

    if is_quick_speed:
        double_speed_button_node.pressed(false)
    else:
        common_speed_button_node.pressed(false)

func disable_button(_disable: bool)-> void:
    view_button_node.disabled = _disable
    stop_run_button_node.disabled = _disable
    _button_disable = _disable

func hide_train_and_camping_button()-> void:
    rest_button_background_node.hide()

func maybe_hide_train_and_camping_button()-> void:
    if[
        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY
    ].has(TeamUtils.get_player_action_status()):







        hide_train_and_camping_button()

func _on_stop_run_button_cpressed(_value):
    emit_signal("stop_or_run_sign", _value)
    if _value:
        append_button_background_node.show()
        rest_button_background_node.hide()
        if is_quick_speed:
            double_speed_button_node.pressed(false)
        else:
            common_speed_button_node.pressed(false)
    else:
        append_button_background_node.hide()
        rest_button_background_node.show()

    maybe_hide_train_and_camping_button()

func _on_timer_timeout():
    self.refresh()


func _on_view_button_cpressed(_value):
    view_mode_sign.emit()

func _on_common_speed_button_b_pressed_2_sign(_node: Variant)-> void:


    if _button_disable:
        return

    is_quick_speed = false
    GlobalTimeControl.time_normal()
    double_speed_button_node.cancel()

func _on_double_speed_button_b_pressed_2_sign(_node: Variant)-> void:


    if _button_disable:
        return



    is_quick_speed = true
    GlobalTimeControl.time_quick()
    common_speed_button_node.cancel()


func _on_train_button_b_pressed_2_sign(_node: Variant)-> void:

    if TeamUtils.get_player_morale() <= 0:
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.LOW_MORALE_CANNOT_TRAIN)
        return


    player_train_sign.emit()
    run_button()


func _on_camping_button_b_pressed_2_sign(_node: Variant)-> void:

    player_camping_sign.emit()
    run_button()