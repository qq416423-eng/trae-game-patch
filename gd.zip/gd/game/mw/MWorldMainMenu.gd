class_name MWorldMainMenu extends Control

@onready var button_root_node: Control =$Background / ButtonRoot
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var background_node: TextureRect =$Background
@onready var background_defeat_node: TextureRect =$BackgroundDefeat

signal back_game_sign()
signal save_game_sign()
signal back_main_menu_sign()
signal load_recent_save_sign()
signal open_settings_page_sign()

func _ready()-> void:
    button_enable(false)

func button_enable(_enable: bool)-> void:
    for _button_node in button_root_node.get_children():
        _button_node.enable(_enable)


func cshow(_is_defeat_menu: = false):
    if _is_defeat_menu:
        background_node.hide()
        background_defeat_node.show()
    else:
        background_node.show()
        background_defeat_node.hide()

    show()
    animation_player_node.play("show")

func chide():
    animation_player_node.play("hide")


func _on_back_button_pressed()-> void:
    chide()
    back_game_sign.emit()

func _on_quick_save_button_pressed()-> void:
    chide()
    save_game_sign.emit()


func _on_back_main_menu_button_pressed()-> void:
    chide()
    back_main_menu_sign.emit()


func _on_quick_load_button_pressed()-> void:
    chide()
    load_recent_save_sign.emit()

func _on_settings_button_pressed()-> void:

    open_settings_page_sign.emit()