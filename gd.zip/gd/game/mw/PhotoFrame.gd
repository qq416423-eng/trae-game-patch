class_name PhotoFrame extends Control

@onready var default_tip_node: Label =$DefaultTip
@onready var hero_portrait_node: HeroPortrait =$HeroPortrait
@onready var button_node: CommonButton =$Button
@onready var frame_node: TextureRect =$Frame
@onready var disable_frame_node: TextureRect =$DisableFrame

@export var default_tip: = "点击选择执行负责人"
@export var allow_click: = true

signal click_sign()

func _ready()-> void:
    CommonUtils.set_text(default_tip_node, default_tip)
    if not allow_click:
        button_node.disable()
        frame_node.hide()
        disable_frame_node.show()

func init(_hero_uid: String)-> void:
    if StringUtils.is_empty(_hero_uid):
        default_tip_node.show()
        hero_portrait_node.hide()
    else:
        default_tip_node.hide()
        hero_portrait_node.show()
        hero_portrait_node.init(_hero_uid)

func _on_button_pressed()-> void:
    click_sign.emit()

func _on_close_button_pressed()-> void:
    self.hide()