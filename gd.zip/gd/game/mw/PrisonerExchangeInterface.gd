class_name PrisonerExchangeInterface extends Control

@onready var prisoner_list_interface_node: PrisonerListInterface =$PrisonerListInterface
@onready var eg_money_interface_node: EGMoneyInterface =$EGMoneyInterface
@onready var save_button_node: CommonButton =$ButtonRoot / SaveButton
@onready var close_button_node: CommonButton =$ButtonRoot / CloseButton

var temp_simple_json_list: = []
var is_special_slave_trader_price: = false

var slave_trader_uid: = ""

signal close_sign()



func init(_is_special_slave_trader_price: = false, _slave_trader_uid: = "")-> void:
    is_special_slave_trader_price = _is_special_slave_trader_price
    slave_trader_uid = _slave_trader_uid

    var _simple_json_list: Array = WSData.get_capture()
    temp_simple_json_list = _simple_json_list.duplicate(true)

    prisoner_list_interface_node.init(_simple_json_list, _is_special_slave_trader_price)
    eg_money_interface_node.init()
    save_button_node.hide()
    close_button_node.show()

func _clear()-> void:
    temp_simple_json_list = []
    slave_trader_uid = ""
    is_special_slave_trader_price = false

func chide()-> void:
    _clear()
    self.hide()

func _refresh_change_money()-> void:
    var _change_money: int = 0
    for _simple_json: Dictionary in WSData.get_capture():
        if _simple_json.has("sell_money"):
            _change_money += _simple_json.sell_money

    eg_money_interface_node.update_change_money(_change_money)
    if _change_money != 0 and close_button_node.visible:
        save_button_node.show()
        close_button_node.hide()


func _on_prisoner_list_interface_sell_action_sign()-> void:
    _refresh_change_money()


func _on_sell_all_button_pressed()-> void:
    prisoner_list_interface_node.sell_all()


func _on_reset_button_pressed()-> void:
    WSData.update_capture(temp_simple_json_list)
    init(is_special_slave_trader_price)
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.REVOCATION_SUCCESS)


func _on_save_button_pressed()-> void:
    if eg_money_interface_node.get_change_money() == 0:
        return

    var _count: int = WSData.handle_deleted_capture()

    if slave_trader_uid == "minor_hero_0004":
        AchievementMetaDataUtils.plus_minor_hero_0004_sell_slave_count(_count)


    WSData.update_money(eg_money_interface_node.get_change_money(), true)

    var _simple_json_list: Array = WSData.get_capture()
    temp_simple_json_list = _simple_json_list.duplicate(true)

    eg_money_interface_node.init()

    save_button_node.hide()
    close_button_node.show()
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_SUCCESS)

func _on_close_button_pressed()-> void:
    chide()
    close_sign.emit()