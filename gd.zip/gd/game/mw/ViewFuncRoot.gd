class_name ViewFuncRoot extends Control

@onready var team_info_panel_node =$TeamInfoPanel
@onready var location_info_panel_node =$LocationInfoPanel02

var show_mode: = false

signal exit_view_mode_sign()

func cshow():
    self.show()
    show_mode = true

func init_team_info(_team_info: TeamInfo, _refer_combat_power = null, _is_player: = false, _view_level: = 1):
    team_info_panel_node.init(_team_info, _refer_combat_power, _is_player, _view_level)
    team_info_panel_node.show()
    location_info_panel_node.hide()

func init_location_info(_location_info: Dictionary):
    location_info_panel_node.init(_location_info)
    team_info_panel_node.hide()
    location_info_panel_node.show()

func _on_exit_view_mode_button_pressed():
    show_mode = false
    self.hide()
    exit_view_mode_sign.emit()
    team_info_panel_node.hide()
    location_info_panel_node.hide()