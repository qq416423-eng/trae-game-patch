class_name WeatherExecutor extends Node

var counter: = 0

var rain_remain_counter: = 0

var current_weather: = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR

signal change_weather_sign(_weather: MWorldConstants.WEATHER_TYPE_ENUM)

func _physics_process(_delta):
    counter += 1
    if CommonUtils.counter_is_true(counter, MWConfig.WEATHER_CHANGE_CHECK_COUNTER_INTERVAL):
        if current_weather == MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
            if CommonUtils.prob_true(MWConfig.RAIN_PROP):
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.RAIN)

        elif current_weather == MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN:
            rain_remain_counter -= 1 * MWConfig.WEATHER_CHANGE_CHECK_COUNTER_INTERVAL
            if rain_remain_counter <= 0:
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.CLEAR)
                return

            if CommonUtils.prob_true(MWConfig.SMALL_TO_BIG_RAIN_PROP):
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN)

        elif current_weather == MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
            rain_remain_counter -= 1
            if rain_remain_counter <= 0:
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.CLEAR)
                return


            if CommonUtils.prob_true(MWConfig.BIG_TO_SMALL_PROP):
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN)

func init(_weather: MWorldConstants.WEATHER_TYPE_ENUM, _rain_remain_counter: int)-> void:
    current_weather = _weather
    rain_remain_counter = _rain_remain_counter

func _change_weather(_weather: MWorldConstants.WEATHER_TYPE_ENUM)-> void:
    match _weather:
        MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
            change_weather_sign.emit(_weather)
        MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN:
            change_weather_sign.emit(_weather)
        MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
            change_weather_sign.emit(_weather)
        MWorldConstants.WEATHER_TYPE_ENUM.RAIN:

            rain_remain_counter = CommonUtils.random_num2(
                MWConfig.RAIN_DURATION_COUNTER_CONFIG[0], MWConfig.RAIN_DURATION_COUNTER_CONFIG[1]
            )
            if CommonUtils.prob_true(
                MWConfig.BIG_TO_SMALL_PROP /(MWConfig.BIG_TO_SMALL_PROP + MWConfig.SMALL_TO_BIG_RAIN_PROP)
            ):
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN)
            else:
                _change_weather(MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN)
            return

    current_weather = _weather