class_name WildSoldierGenerateArea extends CollisionPolygon2D

@onready var line_2d_node =$Line2D
@onready var debug_message_node =$DebugMessageRoot / DebugMessage
@onready var debug_message_root_node =$DebugMessageRoot
@onready var timer_node =$Timer



@export var wild_team_type: = ""

@export var soldier_code_list: Array = []


@export var generate_enery: float = 400.0
@export var generate_enery_max: float = 900.0




@export var enery_plus_speed: float = 1
@export var team_type: = MWTeamConstants.TEAM_ROLE_ENUM.ROBBER
@export var runnable: = true





@export var early_game_monster_spawn_factor: = 0.2



@export var early_game_monster_spawn_system_counter_standard: = 100

@export var spawn_start_counter: = 0.0

@export var spawn_nop_range: = [45, 85]



var used_enery: = 0.0
var min_x: float = 0
var max_x: float = 0
var min_y: float = 0
var max_y: float = 0
var center_point: = Vector2.ZERO

var temp_prob_list: Array[float] = []
var temp_nop_list: Array[int] = []


var generate_enery_max_ratio: = 0.8

func _ready():
    generate_enery_max *= generate_enery_max_ratio

    var _points: = polygon
    min_x = _points[0].x
    max_x = _points[0].x
    min_y = _points[0].y
    max_y = _points[0].y

    for _point in _points:
        min_x = min(min_x, _point.x)
        max_x = max(max_x, _point.x)
        min_y = min(min_y, _point.y)
        max_y = max(max_y, _point.y)
        center_point += _point

    center_point = center_point / _points.size()

    if GameConfig.SHOW_WILD_GENERATE_AREA_BOX and runnable:
        line_2d_node.points = polygon
        line_2d_node.show()

        _update_debug_info()
        debug_message_root_node.position = center_point
        debug_message_root_node.show()

    if ArrayUtils.is_empty(soldier_code_list) and StringUtils.is_not_empty(wild_team_type):
        soldier_code_list = MWTeamConstants.TEAM_SMALL_TYPE_CONFIG.get(wild_team_type).soldier_list

    var _temp_float: = 1.0
    for _soldier_code in soldier_code_list:
        temp_nop_list.append(0)
        temp_prob_list.append(_temp_float)


        _temp_float /= 1.8

    if not runnable:
        timer_node.stop()

func get_save_data()-> Dictionary:
    return {
        "generate_enery": generate_enery,
        "used_enery": used_enery,
    }

func load_save_data(_save_data: Dictionary)-> void:
    generate_enery = _save_data.generate_enery
    used_enery = _save_data.used_enery

    _update_debug_info()


func plus_used_enery(_plus_used_enery: float):
    used_enery += _plus_used_enery


func get_random_point()-> Vector2:
    var _random_point: = Vector2(randf_range(min_x, max_x), randf_range(min_y, max_y))
    while not _point_in_polygon(_random_point):
        _random_point = Vector2(randf_range(min_x, max_x), randf_range(min_y, max_y))

    return _random_point + global_position


func _maybe_generate_wild():
    if ArrayUtils.is_empty(soldier_code_list):
        print_debug("error, soldier_code_list is empty")
        return

    if generate_enery < spawn_nop_range[0] * LocationConfig.ENERATE_ENERY_REAL_NOP_RATIO:

        return

    var _generate_prob: float = generate_enery / MWConfig.WILD_AREA_GENERATE_PROB_FACTOR
    if not CommonUtils.prob_true(_generate_prob):
        return







    var _random_generate_enery: int = min(
        generate_enery,
        spawn_nop_range[1] * LocationConfig.ENERATE_ENERY_REAL_NOP_RATIO
    )
    _random_generate_enery = CommonUtils.random_num2(
        spawn_nop_range[0] * LocationConfig.ENERATE_ENERY_REAL_NOP_RATIO,
        _random_generate_enery
    )

    var _random_point: Vector2 = get_random_point()

    if CommonUtils.get_distance_square2(_random_point, WSData.get_player_team_node().global_position) < 200 * 200:

        return


    var _real_early_game_monster_spawn_factor: = 1.0
    var _generate_enery_ratio = 1.0
    if WSData.system_counter < early_game_monster_spawn_system_counter_standard + spawn_start_counter:
        _real_early_game_monster_spawn_factor = CommonUtils.get_section_value(
            [early_game_monster_spawn_factor, 1.0],
            [spawn_start_counter, spawn_start_counter + early_game_monster_spawn_system_counter_standard],
            WSData.get_system_counter()
        )

    var _team_list = _generate_team_list(_random_generate_enery, _real_early_game_monster_spawn_factor)




    _random_generate_enery = int(_random_generate_enery * _generate_enery_ratio)
    generate_enery -= _random_generate_enery
    used_enery += _random_generate_enery

    var _wild_team_json = TeamUtils.generate_team_json(team_type, _team_list, _random_point)

    _wild_team_json.generate_origin = name
    _wild_team_json.generate_enery = _random_generate_enery
    _wild_team_json.team_small_type = wild_team_type

    var _config: Dictionary = MWTeamConstants.TEAM_SMALL_TYPE_CONFIG.get(wild_team_type)
    _wild_team_json.current_food_morale = MWTeamConstants.get_npc_random_morale(_config)
    _wild_team_json.food_stock_value = MWTeamConstants.get_npc_random_food_stock_value(_config, _team_list.size())
    _wild_team_json.money = MWTeamConstants.get_random_money(_config, _team_list.size())


    if _config.has("team_name"):
        _wild_team_json.team_name = _config.team_name

    GlobalNode.mworld_scene.create_team(
        _wild_team_json)



func _generate_team_list(_random_generate_enery: int, _count_ratio: = 1.0)-> Array:
    var _nop: = int(_random_generate_enery * _count_ratio * MWConfig.WILD_AREA_GENERATE_NOP_FACTOR / LocationConfig.ENERATE_ENERY_REAL_NOP_RATIO)
    if _nop <= 0:
        _nop = 1
    var _team: Array = TeamUtils.generate_team_json_list(_nop, temp_prob_list, soldier_code_list)
    return _team


func _generate_wild():
    var _random_point = get_random_point()



func _point_in_polygon(_point: Vector2)-> bool:
    return Geometry2D.is_point_in_polygon(_point, polygon)

func _update_debug_info():
    if GameConfig.SHOW_WILD_GENERATE_AREA_BOX:
        CommonUtils.set_text(
            debug_message_node,
            "可使用能量: " + str(generate_enery) + "\n"
            + "已使用能量: " + str(used_enery)
        )


func _get_enery_plus_speed()-> float:
    var total_enery = used_enery + generate_enery
    if total_enery > generate_enery_max:
        return 0.0

    var _real_enery_plus_speed = enery_plus_speed
    var _refer_value = generate_enery_max / 2
    while total_enery > _refer_value:
        _refer_value +=(generate_enery_max - _refer_value) / 2
        _real_enery_plus_speed /= 2

    return _real_enery_plus_speed

func _on_timer_timeout():

    if WSData.get_system_counter() < spawn_start_counter:
        return

    var _real_enery_plus_speed = _get_enery_plus_speed()


    generate_enery += _real_enery_plus_speed
    _maybe_generate_wild()
    _update_debug_info()