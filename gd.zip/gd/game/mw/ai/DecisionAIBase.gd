class_name DecisionAIBase extends Node


func should_execute()-> bool:
    return true

func action()-> void:
    pass

func get_ai_type_enum()-> String:
    return ""