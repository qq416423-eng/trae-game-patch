extends DecisionAIBase

var mw_team_node: MWTeamLord = owner


func _ready()-> void:
    mw_team_node = owner


func should_execute()-> bool:

    return false


func action()-> void:
    _find_enemy_or_return_to_patrol()


func get_ai_type_enum()-> String:
    return HeroConstants.LORD_DECISION_AI_TYPE_ENUM.FOLLOW_PLAYER



func _find_enemy_or_return_to_patrol()-> void:
    var _enemy_node: MWTeam = _find_nearest_hostile_team()

    if _enemy_node != null:

        mw_team_node.move_to_team(_enemy_node, true, true)
    else:

        _return_to_patrol_origin()



func _find_nearest_hostile_team()-> MWTeam:
    var _nearest_node: MWTeam = null
    var _nearest_distance_sq: float = INF
    var _search_radius: float = 500.0


    var _all_team_nodes: Array = WSData.team_node_info.values()
    for _node in _all_team_nodes:
        if _node == mw_team_node:
            continue
        if _node == TeamUtils.get_player_team_node():
            continue

        var _dist_sq: float = CommonUtils.get_distance_square(mw_team_node, _node)
        if _dist_sq > _search_radius * _search_radius:
            continue

        if _dist_sq < _nearest_distance_sq:
            var _rel_enum = TeamUtils.get_team_rel_type_enum(mw_team_node, _node)
            if _rel_enum == MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE:
                _nearest_distance_sq = _dist_sq
                _nearest_node = _node

    return _nearest_node



func _return_to_patrol_origin()-> void:
    var _behavior_data: Dictionary = mw_team_node.json.behavior_data
    var _patrol_origin: Vector2 = _behavior_data.get("patrol_origin_position", mw_team_node.global_position)

    var _random_offset: Vector2 = Vector2(
        CommonUtils.random_num2(-100, 100),
        CommonUtils.random_num2(-100, 100)
    )

    mw_team_node.move_to_target(_patrol_origin + _random_offset, true, true)