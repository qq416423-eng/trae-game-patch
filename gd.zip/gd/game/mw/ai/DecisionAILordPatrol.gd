extends DecisionAIBase

var mw_team_node: MWTeamLord = owner

func _ready()-> void:
    mw_team_node = owner

func action()-> void:

    _handle_patrol_origin_position()


    var _patrol_target_position: Vector2 = mw_team_node.get_next_patrol_position(true)
    mw_team_node.move_to_target(
        _patrol_target_position,
        true, true
    )

func _handle_patrol_origin_position()-> void:

    mw_team_node.handle_patrol_origin_position()

func get_ai_type_enum()-> String:
    return HeroConstants.LORD_DECISION_AI_TYPE_ENUM.PATROL