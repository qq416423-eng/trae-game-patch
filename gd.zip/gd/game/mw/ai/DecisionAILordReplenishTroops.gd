extends DecisionAIBase

var mw_team_node: MWTeamLord = owner

func _ready()-> void:
    mw_team_node = owner


func should_execute()-> bool:

    var _replenish_prop: float = mw_team_node.custom_get_replenish_prop()
    return CommonUtils.prob_true(_replenish_prop)

func action()-> void:



    var _owned_location_code_list: Array = mw_team_node.get_owned_location_code_list()

    var _goto_owned_location_prob: float = 0.0
    if ArrayUtils.is_not_empty(_owned_location_code_list):
        _goto_owned_location_prob = 0.75

    var _target_location_code: = ""
    if CommonUtils.prob_true(_goto_owned_location_prob):

        if _owned_location_code_list.size() == 1:
            _target_location_code = _owned_location_code_list[0]
        else:

            _target_location_code = GlobalLocationData.get_nearest_location_code_by_location_code_list(
                mw_team_node.global_position,
                _owned_location_code_list
            )
    else:


        if CommonUtils.prob_true(0.6):
            _target_location_code = GlobalLocationData.get_nearest_location_code(
                mw_team_node.global_position, mw_team_node.belong_country,
                [LocationConstants.LOCATION_TYPE_ENUM.CITY]
            )
        else:
            _target_location_code = GlobalLocationData.get_nearest_location_code(
                mw_team_node.global_position, mw_team_node.belong_country,
                [LocationConstants.LOCATION_TYPE_ENUM.VILLAGE]
            )

    mw_team_node.move_to_location(
        _target_location_code, true, false,
    )

func get_ai_type_enum()-> String:
    return HeroConstants.LORD_DECISION_AI_TYPE_ENUM.REPLENISH_TROOPS