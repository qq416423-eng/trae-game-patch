class_name LordDecisionAI extends DecisionAITopBase



var mw_team_node: MWTeamLord = owner

func _ready()-> void:
    mw_team_node = owner

func action()-> void:
    for _ai_node: DecisionAIBase in get_children():
        if _ai_node.should_execute():
            mw_team_node.save_decision_ai_data(_ai_node.get_ai_type_enum())
            _ai_node.action()
            return