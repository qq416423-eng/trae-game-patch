class_name BirdShadow extends AnimatedSprite2D

var _frame_num = 7

func seek_fly_animation(_frame: = -1)-> int:
    if _frame < 0:
        _frame = CommonUtils.random_num(_frame_num - 1)
    set_frame_and_progress(_frame, true)
    return _frame