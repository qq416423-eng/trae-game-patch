@tool
class_name LordBanner extends Control

@onready var custom_banner_node: Control =$CustomBanner
@onready var default_node: TextureRect =$Default
@onready var shadow_node: TextureRect =$CustomBanner / Shadow
@onready var shape_node: TextureRect =$CustomBanner / Shape
@onready var emblem_node: TextureRect =$CustomBanner / Shape / Emblem
@onready var shape_detail_shadow_node: TextureRect =$CustomBanner / ShapeDetailShadow
@onready var pole_node: TextureRect =$CustomBanner / Pole

@export var show_pole: = true
@export var show_shadow: = true
@export var show_shape_detail_shadow: = true

func _ready()-> void:
    if not show_pole:
        pole_node.hide()

    if not show_shadow:
        shadow_node.hide()

    if not show_shape_detail_shadow:
        shape_detail_shadow_node.hide()

func init_by_hero_uid(_hero_uid: String)-> void:
    if StringUtils.is_empty(_hero_uid):
        init_by_banner_config({})
        return

    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)

    init_by_banner_config(
        CommonUtils.get_value(_hero_json, "banner_config",{})

    )

func init_by_banner_config(_banner_config: Dictionary)-> void:
    if _banner_config.is_empty():
        custom_banner_node.hide()
        default_node.show()
        return

    custom_banner_node.show()
    default_node.hide()

    CommonUtils.update_texture2(
        shape_node,
        BannerUtils.get_shape_pic_path(_banner_config.shape_code)
    )
    CommonUtils.update_self_color(shape_node, _banner_config.shape_color)

    if show_shadow:
        CommonUtils.update_texture2(
            shadow_node,
            BannerUtils.get_shape_shadow_pic_path(_banner_config.shape_code)
        )

    CommonUtils.update_texture2(
        emblem_node,
        BannerUtils.get_emblem_pic_path(_banner_config.emblem_code)
    )
    CommonUtils.update_self_color(emblem_node, _banner_config.emblem_color)

    if show_shape_detail_shadow:
        CommonUtils.update_texture2(
            shape_detail_shadow_node,
            BannerUtils.get_shape_detail_shadow_pic_path(_banner_config.shape_code)
        )

func update_emblem_color(_color: Color)-> void:
    CommonUtils.update_self_color(emblem_node, _color)