class_name TeamInfoPanel extends Control

@onready var total_nop_key_value_node =$Background01 / InfoRoot01 / TotalNopKeyValue
@onready var infantry_nop_key_value_node =$Background02 / InfoRoot02 / VBoxContainer / InfantryNopKeyValue
@onready var cavalry_nop_key_value_node =$Background02 / InfoRoot02 / VBoxContainer / CavalryNopKeyValue
@onready var danger_key_value_node =$Background02 / InfoRoot02 / VBoxContainer / DangerKeyValue
@onready var team_name_node =$Background01 / TeamName
@onready var speed_key_value_node =$Background01 / InfoRoot01 / SpeedKeyValue
@onready var infantry_detail_03_node =$Background02 / InfoRoot02 / VBoxContainer / InfantryNopKeyValue / InfantryDetailRoot / Detail03
@onready var infantry_detail_04_node =$Background02 / InfoRoot02 / VBoxContainer / InfantryNopKeyValue / InfantryDetailRoot / Detail04
@onready var cavalry_detail_03_node =$Background02 / InfoRoot02 / VBoxContainer / CavalryNopKeyValue / CavalryDetailRoot / Detail03
@onready var cavalry_detail_04_node =$Background02 / InfoRoot02 / VBoxContainer / CavalryNopKeyValue / CavalryDetailRoot / Detail04
@onready var solier_simple_info_container_node =$Background03 / VBoxContainer
@onready var background_01_node =$Background01
@onready var background_02_node =$Background02
@onready var background_03_node =$Background03
@onready var line_node =$Line
@onready var line_2_node =$Line2
@onready var infantry_detail_root_node =$Background02 / InfoRoot02 / VBoxContainer / InfantryNopKeyValue / InfantryDetailRoot
@onready var cavalry_detail_root_node =$Background02 / InfoRoot02 / VBoxContainer / CavalryNopKeyValue / CavalryDetailRoot

const SOLDIER_INFO_BOX_NODE = preload("res://tscn/game/interface/soldier/SoldierInfoBox.tscn")



func init(_team_info: TeamInfo, _refer_combat_power = null, _is_player: = false, _view_level: = 1):
    if _refer_combat_power == null:
        _refer_combat_power = WSData.get_player_team_info().combat_power
    if _is_player:
        _view_level = 3

    var _count_str: = str(_team_info.count)
    match _view_level:
        1:
            _count_str = CommonUtils.get_vague_num_str(_team_info.count)
            background_02_node.hide()
            background_03_node.hide()
            speed_key_value_node.hide()
            line_2_node.hide()
        2:
            background_02_node.show()
            background_03_node.hide()
            speed_key_value_node.show()
            infantry_detail_root_node.hide()
            cavalry_detail_root_node.hide()
            line_2_node.show()
        3:
            background_02_node.show()
            background_03_node.show()
            speed_key_value_node.show()
            infantry_detail_root_node.show()
            cavalry_detail_root_node.show()
            line_2_node.show()

    CommonUtils.set_text(team_name_node, _team_info.team_name)
    total_nop_key_value_node.update_value(_count_str)
    infantry_nop_key_value_node.update_value(_team_info.infantry_count)
    cavalry_nop_key_value_node.update_value(_team_info.cavalry_count)
    speed_key_value_node.update_value(_team_info.get_speed())
    _update_danger_value(_team_info.combat_power, _refer_combat_power, _is_player)
    CommonUtils.set_text(infantry_detail_03_node, str(_team_info.infantry_melee_count) + " ")
    CommonUtils.set_text(infantry_detail_04_node, _team_info.infantry_remote_count)
    CommonUtils.set_text(cavalry_detail_03_node, str(_team_info.cavalry_melee_count) + " ")
    CommonUtils.set_text(cavalry_detail_04_node, _team_info.cavalry_remote_count)
    if background_03_node.visible:
        _init_solier_simple_info(_team_info.soldier_simple_info_list)

func _init_solier_simple_info(_soldier_simple_info_list: Array)-> void:
    CommonUtils.clear_node(solier_simple_info_container_node)
    for _soldier_simple_info: Dictionary in _soldier_simple_info_list:
        var soldier_info_box_node = SOLDIER_INFO_BOX_NODE.instantiate()
        solier_simple_info_container_node.add_child(soldier_info_box_node)
        soldier_info_box_node.init(_soldier_simple_info.star, _soldier_simple_info.name, _soldier_simple_info.nop)


    call_deferred("_adjust_background03_y")

func _adjust_background03_y():
    var _y = solier_simple_info_container_node.size.y
    background_03_node.size.y = _y + 44




func _update_danger_value(_self_value: int, _refer_value: int, _is_player: = false):
    if _is_player:
        danger_key_value_node.update_value_color(CommonConstants.COLOR_ENUM.WHITE)
        danger_key_value_node.update_value("- - -")
        return

    var _danger_config = TeamUtils.get_danger_config(_self_value, _refer_value)

    danger_key_value_node.update_value(_danger_config.name)
    danger_key_value_node.update_value_color(_danger_config.color)