class_name BuildHeroSelectInterface extends Control

const BUILD_HERO_SELECT_ITEM_BOX = preload("res://tscn/game/mwBuild/BuildHeroSelectItemBox.tscn")

@onready var v_box_container_node: VBoxContainer =$BaseScrollContainer / VBoxContainer

signal choose_sign(_node: BuildHeroSelectItemBox)
signal close_page_sign()

@export var build_mode: = LocationBuildConstants.BUILD_MODE_ENUM.BUILD

var choose_node: BuildHeroSelectItemBox

func init_by_player_hero(_ideal_skill_info: Dictionary, _default_hero_uid: String)-> void:
    _clear()

    var _all_hero_simple_json_list: Array = TeamUtils.list_hero_simple_json(WSData.get_player_team_simple_json_list())
    var _hero_uid_list: = []
    for _simple_json: Dictionary in _all_hero_simple_json_list:
        if CommonUtils.get_value(_simple_json, "is_player", false):
            continue




        _hero_uid_list.append(_simple_json.uid)


    var node_empty: BuildHeroSelectItemBox = BUILD_HERO_SELECT_ITEM_BOX.instantiate()
    v_box_container_node.add_child(node_empty)
    node_empty.init("", _ideal_skill_info, build_mode)
    node_empty.connect("choose_sign", _choose)
    if StringUtils.is_empty(_default_hero_uid):
        node_empty.choose_effect()
        choose_node = node_empty

    var _temp_node_list = []
    for _hero_uid in _hero_uid_list:
        var _node: BuildHeroSelectItemBox = BUILD_HERO_SELECT_ITEM_BOX.instantiate()
        v_box_container_node.add_child(_node)
        _node.init(_hero_uid, _ideal_skill_info, build_mode)
        _node.connect("choose_sign", _choose)
        if _hero_uid == _default_hero_uid:
            _node.choose_effect()
            choose_node = _node

        _temp_node_list.append(_node)


    _temp_node_list.sort_custom(_build_level_sort_desc)
    for _node_index: int in range(_temp_node_list.size()):
        v_box_container_node.move_child(_temp_node_list[_node_index], _node_index + 1)

func chide()-> void:
    _clear()
    self.hide()
    close_page_sign.emit()

func cshow()-> void:
    self.show()

func _build_level_sort_desc(_node1: BuildHeroSelectItemBox, _node2: BuildHeroSelectItemBox)-> bool:
    return _node1.build_level > _node2.build_level

func _choose(_node: BuildHeroSelectItemBox)-> void:
    if CommonUtils.is_not_null(choose_node):
        choose_node.unchoose()

    choose_node = _node
    choose_sign.emit(_node)
    chide()

func _clear()-> void:
    CommonUtils.clear_node(v_box_container_node)

func _on_close_button_pressed()-> void:
    chide()