class_name BuildHeroSelectItemBox extends Control

@onready var hero_name_node: Label =$InfoRoot / HeroName
@onready var skill_info_node: Label =$InfoRoot / SkillInfo
@onready var build_level_node: Label =$InfoRoot / BuildLevel
@onready var build_level_icon_node: TextureRect =$InfoRoot / BuildLevelIcon
@onready var hero_portrait_node: HeroPortrait =$InfoRoot / HeroPortrait
@onready var info_root_node: Control =$InfoRoot
@onready var empty_root_node: Control =$EmptyRoot
@onready var button_node: BaseSelectButton =$Button
@onready var busy_icon_node: TextureRect =$InfoRoot / BusyIcon
@onready var upgrade_level_node: Label =$InfoRoot / UpgradeLevel

signal choose_sign(_node: BuildHeroSelectItemBox)

var hero_uid: String
var build_level: int = 0

func init(
    _hero_uid: String, _ideal_skill_info: Dictionary,
    _build_mode: LocationBuildConstants.BUILD_MODE_ENUM
)-> void:
    if StringUtils.is_empty(_hero_uid):
        _hero_uid = ""
        info_root_node.hide()
        empty_root_node.show()
    else:
        info_root_node.show()
        empty_root_node.hide()
        var _hero_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_uid(_hero_uid)
        var _skil_require_info: Dictionary = LocationBuildUtils.get_build_skil_require_info(_ideal_skill_info, _hero_prop)
        hero_portrait_node.init(_hero_uid)
        CommonUtils.set_text(hero_name_node, _hero_prop.name)
        CommonUtils.set_text(skill_info_node, _skil_require_info.hero_skill_content)

        var _color: Color
        match _build_mode:
            LocationBuildConstants.BUILD_MODE_ENUM.BUILD:
                CommonUtils.set_text(build_level_node, "预计建筑等级: " + str(_skil_require_info.build_level))
                _color = GoodsUtils.get_quality_color(_skil_require_info.build_level)
            LocationBuildConstants.BUILD_MODE_ENUM.UPGRADE:
                CommonUtils.set_text(upgrade_level_node, "升级后等级: " + str(_skil_require_info.upgrade_build_level))
                upgrade_level_node.show()
                build_level_node.hide()
                _color = GoodsUtils.get_quality_color(_skil_require_info.upgrade_build_level)

        CommonUtils.update_self_color(build_level_icon_node, _color)


        if SoldierUtils.hero_is_busy(_hero_uid):
            CommonUtils.update_self_color(button_node, CommonConstants.COLOR_ENUM.DARK_GRAY)
            button_node.disabled = true
            busy_icon_node.show()
            CommonUtils.set_text(hero_name_node, _hero_prop.name + " (忙碌)")

        build_level = _skil_require_info.build_level

    hero_uid = _hero_uid

func get_hero_uid()-> String:
    return hero_uid

func choose_effect():
    button_node.show_select_effect()

func unchoose()-> void:
    button_node.cancel()

func _on_button_b_pressed()-> void:
    choose_sign.emit(self)