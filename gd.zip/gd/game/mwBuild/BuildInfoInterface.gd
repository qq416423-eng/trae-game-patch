class_name BuildInfoInterface extends Control

@onready var title_pic_node: TextureRect =$TitlePic
@onready var content_root_node: Control =$ContentRoot
@onready var skill_require_info_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / ManagerInfoRoot / InfoVBox / SkillRequireInfo
@onready var manager_name_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / ManagerInfoRoot / InfoVBox / ManagerName
@onready var manager_skill_info_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / ManagerInfoRoot / InfoVBox / ManagerSkillInfo
@onready var build_level_info_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildLevelInfo
@onready var build_cost_info_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildCostInfo
@onready var build_days_info_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildDaysInfo
@onready var effect_info_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / BuildLevelInfoRoot / InfoVBox / EffectInfo
@onready var description_node: Label =$ContentRoot / EmptyStatusRoot / BuildInfoRoot / Description
@onready var build_slot_type_node: IconKeyValue =$ContentRoot / EmptyStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildSlotType
@onready var build_level_icon_node: TextureRect =$ContentRoot / EmptyStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildLevelInfo / BuildLevelIcon
@onready var title_node: Label =$TitlePic / Title
@onready var icon_node: TextureRect =$TitlePic / Icon
@onready var build_hero_select_interface_node: BuildHeroSelectInterface =$BuildHeroSelectInterface
@onready var photo_frame_node: PhotoFrame =$ContentRoot / EmptyStatusRoot / ManagerInfoRoot / PhotoFrame
@onready var build_button_node: CommonButton2 =$ContentRoot / EmptyStatusRoot / ManagerInfoRoot / BuildButton
@onready var build_forbid_tip_node: Label =$ContentRoot / EmptyStatusRoot / ManagerInfoRoot / BuildForbidTip
@onready var empty_status_root_node: Control =$ContentRoot / EmptyStatusRoot
@onready var building_status_root_node: Control =$ContentRoot / BuildingStatusRoot
@onready var finish_status_root_node: Control =$ContentRoot / FinishStatusRoot
@onready var photo_frame_node2: PhotoFrame =$ContentRoot / BuildingStatusRoot / ManagerInfoRoot / PhotoFrame
@onready var manager_name_node2: IconKeyValue =$ContentRoot / BuildingStatusRoot / ManagerInfoRoot / InfoVBox / ManagerName
@onready var build_slot_type_node2: IconKeyValue =$ContentRoot / BuildingStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildSlotType
@onready var build_level_info_node2: IconKeyValue =$ContentRoot / BuildingStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildLevelInfo
@onready var build_level_icon_node2: TextureRect =$ContentRoot / BuildingStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildLevelInfo / BuildLevelIcon
@onready var build_days_info_node2: IconKeyValue =$ContentRoot / BuildingStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildDaysInfo
@onready var effect_info_node2: IconKeyValue =$ContentRoot / BuildingStatusRoot / BuildLevelInfoRoot / InfoVBox / EffectInfo
@onready var description_node2: Label =$ContentRoot / BuildingStatusRoot / BuildInfoRoot / Description
@onready var build_status_text_node: Label =$ContentRoot / BuildingStatusRoot / ManagerInfoRoot / BuildingStatusIcon / BuildStatusText
@onready var build_level_info_node3: IconKeyValue =$ContentRoot / FinishStatusRoot / BuildLevelInfoRoot / InfoVBox / BuildLevelInfo
@onready var effect_info_node3: IconKeyValue =$ContentRoot / FinishStatusRoot / BuildLevelInfoRoot / InfoVBox / EffectInfo
@onready var description_node3: Label =$ContentRoot / FinishStatusRoot / BuildInfoRoot / Description
@onready var upgrade_status_root_node: Control =$ContentRoot / UpgradeStatusRoot
@onready var upgrade_photo_frame_node: PhotoFrame =$ContentRoot / UpgradeStatusRoot / UpgradeManagerInfoRoot / UpgradePhotoFrame
@onready var upgrade_status_text_node: Label =$ContentRoot / UpgradeStatusRoot / UpgradeManagerInfoRoot / UpgradeStatusIcon / UpgradeStatusText
@onready var upgrade_manager_name_node: IconKeyValue =$ContentRoot / UpgradeStatusRoot / UpgradeManagerInfoRoot / InfoVBox / UpgradeManagerName
@onready var upgrade_level_info_node: IconKeyValue =$ContentRoot / UpgradeStatusRoot / UpgradeManagerInfoRoot / InfoVBox / UpgradeLevelInfo
@onready var effect_info_node4: IconKeyValue =$ContentRoot / UpgradeStatusRoot / UpgradeManagerInfoRoot / InfoVBox / EffectInfo
@onready var upgrade_effect_info_node: IconKeyValue =$ContentRoot / UpgradeStatusRoot / UpgradeManagerInfoRoot / InfoVBox / UpgradeEffectInfo
@onready var manager_photo_frame_node: PhotoFrame =$ContentRoot / UpgradeStatusRoot / ManagerInfoRoot / ManagerPhotoFrame
@onready var upgrade_button_node: CommonButton2 =$ContentRoot / FinishStatusRoot / ManagerInfoRoot / UpgradeButton

var build_code: String
var location_code: String
var manager_hero_uid: String
var slot_info: Dictionary

var allow_build: = true
var build_name: = ""
var build_spend_money: = 0
var build_level: = 0

signal build_confirm_sign(_name: String, _money: int)
signal build_success_sign()

signal destroy_confirm_sign()
signal upgrade_button_click_sign()
signal cancel_upgrade_confirm_sign()

func init(
    _location_code: String,
    _build_code: String,
    _slot_info: Dictionary,

    _build_info: Dictionary = {}
)-> void:
    location_code = _location_code
    build_code = _build_code
    slot_info = _slot_info

    title_pic_node.show()
    content_root_node.show()
    empty_status_root_node.hide()
    building_status_root_node.hide()
    finish_status_root_node.hide()
    upgrade_status_root_node.hide()

    var _build_status: LocationBuildConstants.BUILD_STATUS_ENUM \
    = CommonUtils.get_value(_build_info, "build_status", LocationBuildConstants.BUILD_STATUS_ENUM.EMPTY)

    match _build_status:
        LocationBuildConstants.BUILD_STATUS_ENUM.EMPTY:
            init_empty(_build_code, _slot_info, _build_info)
        LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING:
            init_building(_build_code, _slot_info, _build_info)
        LocationBuildConstants.BUILD_STATUS_ENUM.FINISH:
            init_finish(_build_code, _slot_info, _build_info)
        LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE:
            init_upgrade(_build_code, _slot_info, _build_info)

func init_empty(
    _build_code: String,
    _slot_info: Dictionary,

    _build_info: Dictionary = {}
)-> void:
    empty_status_root_node.show()

    allow_build = LocationBuildUtils.check_build_conditions(_build_code, _slot_info)
    if not allow_build:
        build_button_node.hide()
        build_forbid_tip_node.show()
    else:
        build_button_node.show()
        build_forbid_tip_node.hide()

    var _processed_build_info: Dictionary = LocationBuildUtils.get_processed_build_info(_build_code, manager_hero_uid)

    photo_frame_node.init(manager_hero_uid)

    if StringUtils.is_empty(manager_hero_uid):
        manager_name_node.update_value("未选择负责人")
    else:
        manager_name_node.update_value(_processed_build_info.hero_prop.name)

    skill_require_info_node.update_value(_processed_build_info.skill_require_info_content)
    manager_skill_info_node.update_value(_processed_build_info.hero_rel_skill_info_content)
    build_level_info_node.update_value(_processed_build_info.build_level)

    var _color = GoodsUtils.get_quality_color(_processed_build_info.build_level)
    CommonUtils.update_self_color(build_level_icon_node, _color)

    build_cost_info_node.update_value(str(_processed_build_info.build_spend_money) + " 德里")
    build_spend_money = int(_processed_build_info.build_spend_money)

    build_days_info_node.update_value(str(_processed_build_info.build_spend_days) + " 天")
    build_slot_type_node.update_value(LocationBuildConstants.get_slot_type_name(_processed_build_info.slot_type))
    effect_info_node.update_value(_processed_build_info.effect_description)
    CommonUtils.set_text(description_node, _processed_build_info.description)
    CommonUtils.set_text(title_node, _processed_build_info.name)
    build_name = _processed_build_info.name

    CommonUtils.update_texture2(icon_node, _processed_build_info.icon_path)

func init_building(
    _build_code: String,
    _slot_info: Dictionary,

    _build_info: Dictionary = {}
)-> void:
    manager_hero_uid = _build_info.manager_hero_uid

    building_status_root_node.show()

    var _processed_build_info: Dictionary = LocationBuildUtils.get_processed_build_info(
        _build_code, manager_hero_uid, _build_info.build_level
    )

    build_name = _processed_build_info.name

    photo_frame_node2.init(manager_hero_uid)

    if StringUtils.is_empty(manager_hero_uid):
        manager_name_node2.update_value("未选择负责人")
    else:
        manager_name_node2.update_value(_processed_build_info.hero_prop.name)

    build_level_info_node2.update_value(_processed_build_info.build_level)

    var _color = GoodsUtils.get_quality_color(_processed_build_info.build_level)
    CommonUtils.update_self_color(build_level_icon_node, _color)

    build_days_info_node2.update_value(str(int(_build_info.end_time - WSData.system_counter)) + " 天")
    build_slot_type_node2.update_value(LocationBuildConstants.get_slot_type_name(_processed_build_info.slot_type))
    effect_info_node2.update_value(_processed_build_info.effect_description)
    CommonUtils.set_text(description_node2, _processed_build_info.description)
    CommonUtils.set_text(title_node, build_name)
    CommonUtils.update_texture2(icon_node, _processed_build_info.icon_path)



    var _percent: int = LocationBuildUtils.get_build_progress_percent(_build_info)
    build_status_text_node.set_text("建造中 (" + str(_percent) + "%" + ")")

func init_finish(
    _build_code: String, _slot_info: Dictionary,
    _build_info: Dictionary = {}
)-> void:
    finish_status_root_node.show()

    var _processed_build_info: Dictionary = LocationBuildUtils.get_processed_build_info(
        _build_code, "", _build_info.build_level
    )

    build_name = _processed_build_info.name

    build_level_info_node3.update_value(_processed_build_info.build_level)
    effect_info_node3.update_value(_processed_build_info.effect_description)
    CommonUtils.set_text(description_node3, _processed_build_info.description)
    CommonUtils.set_text(title_node, build_name)
    CommonUtils.update_texture2(icon_node, _processed_build_info.icon_path)

    var _max_lv: int = LocationConfig.BUILD_MAX_LEVEL
    if _build_code == LocationBuildConstants.BUILD_CODE_ENUM.PRISON_SMALL:
        _max_lv = 2
    if _processed_build_info.build_level >= _max_lv:
        upgrade_button_node.disabled = true
        build_level_info_node3.append_value(" (MAX)")
    else:
        upgrade_button_node.disabled = false

func init_upgrade(
    _build_code: String, _slot_info: Dictionary,
    _build_info: Dictionary = {}
)-> void:
    upgrade_status_root_node.show()

    var _processed_build_info: Dictionary = LocationBuildUtils.get_processed_build_info(
        _build_code, _build_info.manager_hero_uid, _build_info.build_level
    )

    build_name = _processed_build_info.name

    var _percent: int = LocationBuildUtils.get_build_progress_percent(_build_info)

    upgrade_photo_frame_node.init(_build_info.manager_hero_uid)
    upgrade_status_text_node.set_text("升级中 (" + str(_percent) + "%" + ")")

    if StringUtils.is_not_empty(_build_info.manager_hero_uid):
        upgrade_manager_name_node.update_value(_processed_build_info.hero_prop.name)
    else:
        upgrade_manager_name_node.update_value("未选择负责人")

    upgrade_level_info_node.update_value(
        str(_processed_build_info.build_level) + " -> " + str(_processed_build_info.upgrade_build_level)
    )
    effect_info_node4.update_value(_processed_build_info.effect_description)
    upgrade_effect_info_node.update_value(_processed_build_info.upgrade_effect_description)


func init_by_build_info(_location_code: String, _build_info: Dictionary)-> void:
    init(_location_code, _build_info.build_code,{}, _build_info)

func clear()-> void:
    build_code = ""
    location_code = ""
    title_pic_node.hide()
    content_root_node.hide()

func close_hero_select_interface()-> void:
    build_hero_select_interface_node.chide()

func clear_manager()-> void:
    manager_hero_uid = ""

func build()-> void:

    var _allow_build: bool = LocationBuildUtils.check_build_conditions(build_code, slot_info)
    if not _allow_build:
        return

    WSLocationData.new_build(
        location_code, slot_info.code, build_code, manager_hero_uid
    )

    build_success_sign.emit()

func get_build_name()-> String:
    return build_name


func _on_photo_frame_click_sign()-> void:
    if build_hero_select_interface_node.visible:
        close_hero_select_interface()
    else:
        build_button_node.disabled = true
        build_hero_select_interface_node.show()

        var _build_config: Dictionary = LocationBuildConstants.get_build_config(build_code)
        build_hero_select_interface_node.init_by_player_hero(_build_config.ideal_skill, manager_hero_uid)


func _on_build_hero_select_interface_choose_sign(_node: BuildHeroSelectItemBox)-> void:
    manager_hero_uid = _node.get_hero_uid()
    init(location_code, build_code, slot_info)

func _on_build_hero_select_interface_close_page_sign()-> void:
    build_button_node.disabled = false


func _on_build_button_pressed()-> void:
    build_confirm_sign.emit(build_name, build_spend_money)


func _on_destroy_button_pressed()-> void:

    destroy_confirm_sign.emit()


func _on_upgrade_button_pressed()-> void:
    upgrade_button_click_sign.emit()


func _on_upgrade_cancel_button_pressed()-> void:
    cancel_upgrade_confirm_sign.emit()