class_name BuildItemBox extends Control

@onready var button_node: BaseSelectButton =$Button
@onready var icon_node: TextureRect =$Icon
@onready var name_node: Label =$Name
@onready var forbid_icon_node: TextureRect =$ForbidIcon

var build_code: String

signal choose_sign(_node)


func init(_build_info: Dictionary)-> void:
    build_code = _build_info.build_code
    var _build_config: Dictionary = LocationBuildConstants.get_build_config(_build_info.build_code)
    CommonUtils.update_texture2(icon_node, _build_config.icon_path)
    CommonUtils.set_text(name_node, _build_config.name)
    if not _build_info.allow_build:
        _forbid_style()

func get_build_code()-> String:
    return build_code

func choose()-> void:
    button_node.choose(false)

func unchoose()-> void:
    button_node.cancel()


func _forbid_style()-> void:
    forbid_icon_node.show()
    CommonUtils.update_self_color(button_node, CommonConstants.COLOR_ENUM.DARK_GRAY)

func _on_button_b_pressed()-> void:
    choose_sign.emit(self)