class_name BuildListInterface extends Control

const BUILD_ITEM_BOX = preload("res://tscn/game/mwBuild/BuildItemBox.tscn")

@onready var v_box_container_node: VBoxContainer =$BaseScrollContainer / VBoxContainer

var choose_node: BuildItemBox

signal choose_sign(_node: BuildItemBox)

func init(_location_code: String, _slot_info: Dictionary)-> void:
    clear()
    var _build_code_list: Array = WSLocationData.list_build_code(_location_code)

    if ArrayUtils.is_empty(_build_code_list):
        _build_code_list = []


    if GlobalTempData.mod_prison_build_mode:
        var _loc_data: Dictionary = WSLocationData.get_city_data(_location_code)
        var _is_village: bool = _loc_data.get("type", "") == LocationConstants.LOCATION_TYPE_ENUM.VILLAGE
        if _is_village:



            var _belong_country: String = WSLocationData.get_belong_country(_location_code)
            if _belong_country == WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:
                _build_code_list = [
                    LocationBuildConstants.BUILD_CODE_ENUM.PRISON,
                    LocationBuildConstants.BUILD_CODE_ENUM.PRISON_SMALL,
                    LocationBuildConstants.BUILD_CODE_ENUM.MINT,
                    LocationBuildConstants.BUILD_CODE_ENUM.MINT_SMALL
                ]
            else:
                _build_code_list = [
                    LocationBuildConstants.BUILD_CODE_ENUM.PRISON_SMALL,
                    LocationBuildConstants.BUILD_CODE_ENUM.MINT_SMALL
                ]
        else:

            _build_code_list = []
    else:

        var _non_special_list: Array = []
        for _code in _build_code_list:
            if not LocationBuildConstants.MOD_SPECIAL_CODE_LIST.has(_code):
                _non_special_list.append(_code)
        _build_code_list = _non_special_list

    if ArrayUtils.is_empty(_build_code_list):
        return

    var _allow_build_info_list = _get_allow_build_info_list(_build_code_list, _slot_info)
    _allow_build_info_list.sort_custom(_allow_build_info_sort)

    for _allow_build_info: Dictionary in _allow_build_info_list:
        var build_item_box_node: BuildItemBox = BUILD_ITEM_BOX.instantiate()
        v_box_container_node.add_child(build_item_box_node)
        build_item_box_node.init(_allow_build_info)
        build_item_box_node.connect("choose_sign", _choose)

    _choose_first()

func chide()-> void:
    self.hide()
    clear()

func _allow_build_info_sort(_a: Dictionary, _b: Dictionary)-> bool:
    return not _b.allow_build



func _get_allow_build_info_list(_build_code_list: Array, _slot_info: Dictionary)-> Array:
    var _build_info_list: = []
    for _build_code in _build_code_list:
        var _allow_build: = LocationBuildUtils.check_build_conditions(
            _build_code, _slot_info
        )

        _build_info_list.append({
            "build_code": _build_code,
            "allow_build": _allow_build
        })

    return _build_info_list

func _choose_first():
    for _node in v_box_container_node.get_children():
        if CommonUtils.is_not_null(_node):
            _node.choose()
            return

func _choose(_node: BuildItemBox)-> void:
    if CommonUtils.is_not_null(choose_node):
        choose_node.unchoose()

    choose_node = _node
    choose_sign.emit(_node)

func clear()-> void:
    CommonUtils.clear_node(v_box_container_node)