class_name BuildSlotBoxBase extends Control

const UPGRADING_ICON_20 = preload("res://resource/icon/smallIcon/upgrading_icon_20.png")

@onready var button_node: BaseTextureSelectButton =$Button
@onready var free_status_root_node: Control =$FreeStatusRoot
@onready var building_status_root_node: Control =$BuildingStatusRoot
@onready var level_icon_node: TextureRect =$BuildingStatusRoot / LevelIcon
@onready var build_progress_value_node: IconValueBox =$BuildingStatusRoot / BuildProgressValue
@onready var build_icon_node: TextureRect =$BuildingStatusRoot / BuildIcon
@onready var finish_status_root_node: Control =$FinishStatusRoot
@onready var build_icon_finish_node: TextureRect =$FinishStatusRoot / BuildIcon
@onready var level_icon_finish_node: TextureRect =$FinishStatusRoot / LevelIcon
@onready var level_value_node: Label =$BuildingStatusRoot / LevelIcon / LevelValue
@onready var level_value_finish_node: Label =$FinishStatusRoot / LevelIcon / LevelValue

signal choose_sign(_node)

var slot_info: Dictionary = {}
var build_info: Dictionary = {}


func init(_build_slot_info: Dictionary, _build_info: Dictionary)-> void:
    slot_info = _build_slot_info
    build_info = _build_info

    free_status_root_node.hide()
    building_status_root_node.hide()
    finish_status_root_node.hide()

    var _build_status = CommonUtils.get_value(build_info, "build_status", LocationBuildConstants.BUILD_STATUS_ENUM.EMPTY)

    match _build_status:
        LocationBuildConstants.BUILD_STATUS_ENUM.EMPTY:
            free_status_root_node.show()

        LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING, \
        LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE:
            var _build_level = _build_info.build_level



            building_status_root_node.show()
            var _color = GoodsUtils.get_quality_color(_build_level)
            CommonUtils.update_self_color(level_icon_node, _color)

            var _percent: int = LocationBuildUtils.get_build_progress_percent(_build_info)
            build_progress_value_node.set_text(str(_percent) + "%")
            var _build_config: = LocationBuildConstants.get_build_config(_build_info.build_code)
            CommonUtils.update_texture2(build_icon_node, _build_config.icon_path)
            CommonUtils.set_text(level_value_node, _build_level)

            if _build_status == LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE:
                build_progress_value_node.update_icon(UPGRADING_ICON_20)

        LocationBuildConstants.BUILD_STATUS_ENUM.FINISH:
            finish_status_root_node.show()
            var _color = GoodsUtils.get_quality_color(_build_info.build_level)
            CommonUtils.update_self_color(level_icon_finish_node, _color)
            var _build_config: = LocationBuildConstants.get_build_config(_build_info.build_code)
            CommonUtils.update_texture2(build_icon_finish_node, _build_config.icon_path)
            CommonUtils.set_text(level_value_finish_node, _build_info.build_level)

func get_slot_info()-> Dictionary:
    return slot_info

func get_build_info()-> Dictionary:
    return build_info

func unchoose()-> void:
    button_node.cancel()

func choose(_is_open_sound: bool = true)-> void:
    button_node.choose(_is_open_sound)

func get_build_status()-> LocationBuildConstants.BUILD_STATUS_ENUM:
    return CommonUtils.get_value(build_info, "build_status", LocationBuildConstants.BUILD_STATUS_ENUM.EMPTY)

func _on_button_b_pressed()-> void:
    choose_sign.emit(self)