class_name BuildSlotListInterface extends Control

const BUILD_SLOT_BOX_BASE = preload("res://tscn/game/mwBuild/BuildSlotBoxBase.tscn")
const BUILD_SLOT_BOX_SMALL = preload("res://tscn/game/mwBuild/BuildSlotBoxSmall.tscn")

@onready var grid_container_node: GridContainer =$BaseScrollContainer / GridContainer

var choose_node: BuildSlotBoxBase

signal choose_sign(_node: BuildSlotBoxBase)

func init(_location_code: String, _select_pre: = false)-> void:
    var _pre_slot_code: = ""
    if _select_pre and CommonUtils.is_not_null(choose_node):
        _pre_slot_code = choose_node.get_slot_info().code

    clear()
    var _location_data: Dictionary = WSLocationData.get_city_data(_location_code)
    if not _location_data.has("build_slot"):
        return


    var _max_slots: int = 999
    if _location_data.get("type", "") == LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
        var _belong_country: String = WSLocationData.get_belong_country(_location_code)
        if _belong_country != WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:
            _max_slots = 1

    var _slot_count: int = 0
    for _build_slot_info: Dictionary in _location_data.build_slot:
        if _slot_count >= _max_slots:
            break
        _slot_count += 1
        var _node: BuildSlotBoxBase
        match _build_slot_info.type:
            LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.BIG_SLOT:
                _node = BUILD_SLOT_BOX_BASE.instantiate()
            LocationBuildConstants.BUILD_SLOT_TYPE_ENUM.SMALL_SLOT:
                _node = BUILD_SLOT_BOX_SMALL.instantiate()

        if CommonUtils.is_null(_node):
            continue

        grid_container_node.add_child(_node)

        var _build_info: Dictionary = WSLocationData.get_build_info(_location_code, _build_slot_info.code)
        _node.init(_build_slot_info, _build_info)
        _node.connect("choose_sign", _choose)

        if _select_pre:
            if _build_slot_info.code == _pre_slot_code:
                _node.choose(false)

func clear()-> void:
    CommonUtils.clear_node(grid_container_node)
    choose_node = null

func get_slot_info()-> Dictionary:
    return choose_node.get_slot_info()

func get_current_slot_code()-> String:
    return get_slot_info().code

func _choose(_node: BuildSlotBoxBase)-> void:
    if CommonUtils.is_not_null(choose_node):
        choose_node.unchoose()

    choose_node = _node
    choose_sign.emit(_node)