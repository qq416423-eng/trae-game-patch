class_name BuildUpgradeInterface extends Control

@onready var upgrade_manager_name_node: IconKeyValue =$ManagerInfoRoot / InfoVBox / UpgradeManagerName
@onready var skill_require_info_node: IconKeyValue =$ManagerInfoRoot / InfoVBox / SkillRequireInfo
@onready var upgrade_level_info_node: IconKeyValue =$BuildLevelInfoRoot / InfoVBox / UpgradeLevelInfo
@onready var upgrade_money_info_node: IconKeyValue =$BuildLevelInfoRoot / InfoVBox / UpgradeMoneyInfo
@onready var current_effect_info_node: IconKeyValue =$BuildLevelInfoRoot / InfoVBox / CurrentEffectInfo
@onready var upgrade_effect_info_node: IconKeyValue =$BuildLevelInfoRoot / InfoVBox / UpgradeEffectInfo
@onready var build_hero_select_interface_node: BuildHeroSelectInterface =$BuildHeroSelectInterface
@onready var upgrade_button_node: CommonButton2 =$ManagerInfoRoot / UpgradeButton
@onready var photo_frame_node: PhotoFrame =$ManagerInfoRoot / PhotoFrame
@onready var upgrade_days_info_node: IconKeyValue =$BuildLevelInfoRoot / InfoVBox / UpgradeDaysInfo

var upgrade_manager_uid: = ""
var location_code: = ""
var slot_code: = ""
var build_info: = {}

var build_level: = 0

var upgrade_build_level: = 0
var build_name: = ""
var upgrade_cost_money: = 0
var upgrade_days: = 0

signal upgrade_confirm_sign(_build_name: String, _cost_money: int, _build_level: int, _upgrade_build_level: int)

func cshow()-> void:
    self.show()

func init(_location_code: String, _slot_code: String)-> void:
    location_code = _location_code
    slot_code = _slot_code

    var _build_info: Dictionary = WSLocationData.get_build_info(_location_code, _slot_code)
    build_info = _build_info

    var _processed_build_info: = LocationBuildUtils.get_processed_build_info(
        _build_info.build_code, upgrade_manager_uid, _build_info.build_level
    )

    build_name = _processed_build_info.name
    upgrade_cost_money = _processed_build_info.build_upgrade_money
    build_level = _processed_build_info.build_level
    upgrade_build_level = _processed_build_info.upgrade_build_level
    upgrade_days = _processed_build_info.upgrade_spend_days

    upgrade_manager_name_node.update_value(
        "未选择负责人" if CommonUtils.is_null(_processed_build_info.hero_prop) else _processed_build_info.hero_prop.name
    )
    skill_require_info_node.update_value(_processed_build_info.skill_require_info_content)
    upgrade_level_info_node.update_value(
        str(build_level) + " -> " + str(upgrade_build_level) \
        +("" if upgrade_build_level > build_level else " (无法升级)")
    )
    if upgrade_build_level > build_level:
        upgrade_button_node.disabled = false
    else:
        upgrade_button_node.disabled = true

    upgrade_money_info_node.update_value(upgrade_cost_money)
    current_effect_info_node.update_value(_processed_build_info.effect_description)
    upgrade_effect_info_node.update_value(_processed_build_info.upgrade_effect_description)
    upgrade_days_info_node.update_value(str(upgrade_days) + " 天")
    photo_frame_node.init(upgrade_manager_uid)

func chide()-> void:
    _clear()
    self.hide()

func get_build_upgrade_money()-> int:
    return upgrade_cost_money

func get_upgrade_build_level()-> int:
    return upgrade_build_level

func get_upgrade_hero_uid()-> String:
    return upgrade_manager_uid

func get_upgrade_days()-> int:
    return upgrade_days

func _refresh()-> void:
    init(location_code, slot_code)

func _clear()-> void:
    upgrade_manager_uid = ""
    location_code = ""
    slot_code = ""
    build_info = {}
    upgrade_build_level = 0
    build_name = ""
    upgrade_cost_money = 0
    upgrade_days = 0

func _on_close_button_pressed()-> void:
    chide()


func _on_photo_frame_click_sign()-> void:
    if build_hero_select_interface_node.visible:
        build_hero_select_interface_node.chide()
    else:
        build_hero_select_interface_node.cshow()
        var _build_config: Dictionary = LocationBuildConstants.get_build_config(build_info.build_code)
        build_hero_select_interface_node.init_by_player_hero(_build_config.ideal_skill, upgrade_manager_uid)


func _on_build_hero_select_interface_choose_sign(_node: BuildHeroSelectItemBox)-> void:
    upgrade_manager_uid = _node.get_hero_uid()
    _refresh()


func _on_upgrade_button_pressed()-> void:
    if not upgrade_build_level > build_level:
        return

    upgrade_confirm_sign.emit(
        build_name, upgrade_cost_money,
        build_level, upgrade_build_level
    )