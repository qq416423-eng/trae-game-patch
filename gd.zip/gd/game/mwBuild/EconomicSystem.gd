class_name EconomicSystem extends Node2D

@onready var debug_info_node =$DebugInfo
@onready var timer_node =$Timer






















var city_data = {}

var speed = 4.0



signal one_turn_sign()

func _ready():
    if GameConfig.DEBUG_CONFIG_IS_DEBUG:

        debug_info_node.show()

func init(_city_data):







    city_data = _city_data

    _update_debuf_info()

func start():
    timer_node.start()


func subtract(
    _resource_json: Dictionary,

):
    for _key in _resource_json.keys():

        city_data[_key] -= _resource_json.get(_key)




    _update_debuf_info()

func increase(
    _resource_json: Dictionary,

):
    for _key in _resource_json.keys():

        city_data[_key] += _resource_json.get(_key)





    LocationUtils.location_data_repair(city_data)
    _update_debuf_info()


func trade(_team_json: Dictionary):
    var _resource_json: Dictionary = _team_json.resource_json
    var _team_role: int = _team_json.team_role
    var _trade_count = _resource_json.excess_goods


    match _team_role:
        MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER:
            city_data.consumption_goods -= _trade_count / 2
            city_data.excess_goods += _trade_count / 2

            _resource_json.excess_goods = 0
            _resource_json.consumption_goods += _trade_count













        MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY:
            city_data.consumption_goods += _trade_count / 2
            city_data.excess_goods -= _trade_count / 2

            _resource_json.excess_goods = 0
            _resource_json.consumption_goods += _trade_count















            _team_json.self_location_resource = {
                "value": int(_team_json.self_location_resource.value),
                "location_code": city_data.location_code
            }


    _update_debuf_info()
    _team_json.is_trade_finish = true
    return _resource_json


func _one_turn():

    var _origin_plus_consumption_goods = city_data.population_total * 0.0015 * speed
    var _ratio = city_data.consumption_goods /(_origin_plus_consumption_goods * 300 / speed)
    if _ratio > 2.5:
        _ratio = 2.5


    city_data.population_working_age +=(city_data.population_total * 0.00008 * speed)

    city_data.population_total +=(city_data.population_total *((_ratio - 0.6) / 1.5) * 0.0001 * speed)

    city_data.consumption_goods +=(city_data.population_total * 0.001 *(1 - city_data.tax_ratio) * speed)



    city_data.excess_goods +=(city_data.population_total * 0.001 *(1 - city_data.tax_ratio) * speed)



    var _actual_plus_consumption_goods = _origin_plus_consumption_goods * _ratio
    city_data.consumption_goods -= _actual_plus_consumption_goods


    LocationUtils.location_data_repair(city_data)

    _update_debuf_info()
    one_turn_sign.emit()

func _one_turn_old():

    var _origin_plus_consumption_goods = city_data.population_total * 0.0015 * speed
    var _ratio = city_data.consumption_goods /(_origin_plus_consumption_goods * 300 / speed)
    if _ratio > 2.5:
        _ratio = 2.5



    city_data.population_working_age = city_data.population_working_age + CommonUtils.get_limit_increment(
        city_data.population_working_age, city_data.location_size_max,
        city_data.population_total * 0.0001 * speed
    )

    city_data.population_total = city_data.population_total + CommonUtils.get_limit_increment(
        city_data.population_total, city_data.location_size_max,
        city_data.population_total *(_ratio / 1.8) *(1 +(city_data.happiness_level * 0.001)) * 0.001 * speed
    )

    city_data.consumption_goods = city_data.consumption_goods + CommonUtils.get_limit_increment(city_data.consumption_goods, city_data.location_size_max * 2, city_data.population_total * 0.001 *(1 - city_data.tax_ratio) * speed)

    city_data.excess_goods = city_data.excess_goods + CommonUtils.get_limit_increment(city_data.excess_goods, city_data.location_size_max * 2, city_data.population_total * 0.001 *(1 - city_data.tax_ratio) * speed)












    var _actual_plus_consumption_goods = _origin_plus_consumption_goods * _ratio
    city_data.consumption_goods = city_data.consumption_goods - _actual_plus_consumption_goods

    var _plus_happiness_level =(_ratio - 0.8) * 20 / speed




    city_data.happiness_level = max(
        LocationConfig.MIN_HAPPINESS_LEVEL,
        city_data.happiness_level + CommonUtils.get_limit_increment(city_data.happiness_level, LocationConfig.MAX_HAPPINESS_LEVEL, _plus_happiness_level)
    )



    _update_debuf_info()
    one_turn_sign.emit()

func _update_debuf_info():
    if not GameConfig.DEBUG_CONFIG_IS_DEBUG:
        return

    var _str =(

        "总人口: " + str(int(city_data.population_total)) + "\n"
        + "年轻人口: " + str(int(city_data.population_working_age)) + "\n"
        + "自用物资: " + str(int(city_data.consumption_goods)) + "\n"
        + "多余物资: " + str(int(city_data.excess_goods)) + "\n"
        + "幸福度: " + str(int(city_data.happiness_level)) + "\n"
        + "税收: " + str(city_data.tax_ratio) + "\n"
        + "规模上限: " + str(int(city_data.location_size_max)) + "\n")

    CommonUtils.set_text(debug_info_node, _str)

func _on_timer_timeout():
    _one_turn()