class_name LocationBuildInterface extends Control

@onready var build_slot_list_interface_node: BuildSlotListInterface =$BuildSlotListInterface
@onready var build_list_interface_node: BuildListInterface =$BuildListInterface
@onready var build_info_interface_node: BuildInfoInterface =$BuildInfoInterface
@onready var build_confirm_box_node: ConfirmBox =$OtherFullScreenRoot / BuildConfirmBox
@onready var destory_confirm_box_node: ConfirmBox =$OtherFullScreenRoot / DestoryConfirmBox
@onready var build_upgrade_interface_node: BuildUpgradeInterface =$BuildUpgradeInterface
@onready var upgrade_confirm_box_node: ConfirmBox =$OtherFullScreenRoot / UpgradeConfirmBox
@onready var cancel_upgrade_confirm_box_node: ConfirmBox =$OtherFullScreenRoot / CancelUpgradeConfirmBox

var location_code: String
var build_destory_money: = 0
var build_spend_money: = 0
var cancel_upgrade_refund_money: = 0

signal close_page_sign()





func init(_location_code: String, _select_pre: = false)-> void:
    location_code = _location_code
    build_list_interface_node.hide()
    build_info_interface_node.clear()
    build_slot_list_interface_node.init(_location_code, _select_pre)

func _refresh():
    init(location_code, true)

func _clear()-> void:
    build_slot_list_interface_node.clear()
    build_list_interface_node.clear()
    build_info_interface_node.clear()

func _on_build_list_interface_choose_sign(_node: BuildItemBox)-> void:
    build_info_interface_node.clear_manager()
    build_info_interface_node.init(location_code, _node.get_build_code(), build_slot_list_interface_node.get_slot_info())
    build_info_interface_node.close_hero_select_interface()

func _on_close_button_pressed()-> void:
    self.hide()
    _clear()
    close_page_sign.emit()


func _on_build_slot_list_interface_choose_sign(_node: BuildSlotBoxBase)-> void:
    var _build_status: LocationBuildConstants.BUILD_STATUS_ENUM = _node.get_build_status()

    if _build_status == LocationBuildConstants.BUILD_STATUS_ENUM.EMPTY:
        build_list_interface_node.show()
        build_list_interface_node.init(location_code, _node.get_slot_info())
    else:
        build_list_interface_node.chide()
        build_info_interface_node.init_by_build_info(location_code, _node.get_build_info())

    build_info_interface_node.close_hero_select_interface()
    build_upgrade_interface_node.chide()


func _on_build_info_interface_build_confirm_sign(_build_name: String, _money: int)-> void:
    build_spend_money = _money

    var _content = "确认建造设施[{0}]? 将会花费 {1} 德里"
    _content = StringUtils.replace(_content,[_build_name, _money])

    build_confirm_box_node.show()
    build_confirm_box_node.update_content(_content)


func _on_build_info_interface_build_success_sign()-> void:
    _refresh()


func _on_build_confirm_box_confirm()-> void:

    var success = WSData.update_money(- build_spend_money, true)
    if success:
        build_info_interface_node.build()


func _on_build_info_interface_destroy_confirm_sign()-> void:
    var _build_info: Dictionary = WSLocationData.get_build_info(
        location_code,
        build_slot_list_interface_node.get_current_slot_code()
    )

    if _build_info.is_empty():
        build_destory_money = 0
        return


    if[
        LocationBuildConstants.BUILD_CODE_ENUM.BARRACKS,
        LocationBuildConstants.BUILD_CODE_ENUM.BARRACKS_SMALL
    ].has(_build_info.build_code):

        if WSLocationData.check_barracks_has_data(location_code):
            GlobalMessageInterface.show_confirm_box("拆除失败, 请先将驻军全部转移至我方队伍")
            return

    if[
        LocationBuildConstants.BUILD_CODE_ENUM.WAREHOUSE,
        LocationBuildConstants.BUILD_CODE_ENUM.WAREHOUSE_SMALL
    ].has(_build_info.build_code):

        if WSLocationData.check_warehouse_has_data(location_code):
            GlobalMessageInterface.show_confirm_box("拆除失败, 请先取回仓库内所有物品")
            return

    var _content = "确认拆除设施[{0}]? 将会回收 {1} 德里."

    destory_confirm_box_node.show()

    var _processed_build_info: = LocationBuildUtils.get_processed_build_info(
        _build_info.build_code,
        "",
        _build_info.build_level
    )

    build_destory_money = _processed_build_info.build_destory_money

    _content = StringUtils.replace(
        _content,
        [
            _processed_build_info.name,
            build_destory_money,
        ]
    )


    match _build_info.build_code:
        LocationBuildConstants.BUILD_CODE_ENUM.BARRACKS, LocationBuildConstants.BUILD_CODE_ENUM.BARRACKS_SMALL:
            _content = "请在拆除所有驻军点前取出所有驻军士兵!\n" + _content

    destory_confirm_box_node.update_content(_content)


func _on_destory_confirm_box_confirm()-> void:

    WSLocationData.delete_build(location_code, build_slot_list_interface_node.get_current_slot_code())


    WSData.update_money(build_destory_money, false)

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.DESTORY_BUILD_SUCCESS,
        [build_destory_money]
    )

    _refresh()

func _on_build_info_interface_upgrade_button_click_sign()-> void:
    build_upgrade_interface_node.cshow()
    build_upgrade_interface_node.init(location_code, build_slot_list_interface_node.get_current_slot_code())


func _on_build_upgrade_interface_upgrade_confirm_sign(
    _build_name: String, _cost_money: int,
    _build_level: int, _upgrade_build_level: int)-> void:
    var _content: = "设施[{0}]准备升级: {1}, 将会花费 {2} 德里, 是否继续?"
    _content = StringUtils.replace(
        _content,
        [
            _build_name,
            str(_build_level) + " -> " + str(_upgrade_build_level),
            _cost_money
        ]
    )

    upgrade_confirm_box_node.update_content(_content)
    upgrade_confirm_box_node.show()


func _on_upgrade_confirm_box_confirm()-> void:

    var success: bool = WSData.update_money(- build_upgrade_interface_node.get_build_upgrade_money(), false)
    if success:

        WSLocationData.build_upgrade(
            location_code, build_slot_list_interface_node.get_current_slot_code(),
            build_upgrade_interface_node.get_upgrade_build_level(),
            build_upgrade_interface_node.get_upgrade_hero_uid(),
            build_upgrade_interface_node.get_upgrade_days()
        )

        GlobalMessageInterface.add_message(
            MessageConstants.MESSAGE_ENUM.BUILD_UPGRADE_CONFIRM,
            [
                build_info_interface_node.get_build_name(),
                str(- build_upgrade_interface_node.get_build_upgrade_money())
            ]
        )

        _refresh()

func _on_build_info_interface_cancel_upgrade_confirm_sign()-> void:
    var _content: = "确认取消升级设施[{0}]? 将会回收 {1} 德里"

    var _build_info: = WSLocationData.get_build_info(
        location_code,
        build_slot_list_interface_node.get_current_slot_code()
    )

    if _build_info.is_empty():
        return

    var _processed_build_info: = LocationBuildUtils.get_processed_build_info(
        _build_info.build_code, _build_info.manager_hero_uid,
        _build_info.build_level
    )

    cancel_upgrade_refund_money = _processed_build_info.build_cancel_upgrade_refund_money

    _content = StringUtils.replace(
        _content,
        [_processed_build_info.name, cancel_upgrade_refund_money]
    )

    cancel_upgrade_confirm_box_node.update_content(_content)
    cancel_upgrade_confirm_box_node.show()


func _on_cancel_upgrade_confirm_box_confirm()-> void:

    WSLocationData.build_cancel_upgrade(
        location_code,
        build_slot_list_interface_node.get_current_slot_code()
    )


    WSData.update_money(cancel_upgrade_refund_money, false)

    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.BUILD_CANCEL_UPGRADE_SUCCESS,
        [cancel_upgrade_refund_money]
    )

    _refresh()