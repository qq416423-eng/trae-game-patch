class_name LocationBuildSummaryBox extends Control

@onready var icon_node: TextureRect =$Background / Icon
@onready var level_icon_node: TextureRect =$Background / LevelIcon

func init(_finish_build_info: Dictionary)-> void:
    var _build_config: = LocationBuildConstants.get_build_config(_finish_build_info.build_code)
    CommonUtils.update_texture2(icon_node, _build_config.icon_path)
    var _color: = GoodsUtils.get_quality_color(_finish_build_info.build_level)
    CommonUtils.update_self_color(level_icon_node, _color)