class_name LocationBuildSummaryList extends Control

const LOCATION_BUILD_SUMMARY_BOX = preload("res://tscn/game/mwBuild/LocationBuildSummaryBox.tscn")

@onready var h_box_container_node: HBoxContainer =$PanelContainer / HBoxContainer

func init(_location_code: String)-> void:
    clear()

    var _finish_build_info_list: = WSLocationData.get_finish_build_info_list(_location_code)

    if ArrayUtils.is_empty(_finish_build_info_list):
        chide()
    else:
        cshow()

    for _finish_build_info: Dictionary in _finish_build_info_list:
        var _node: LocationBuildSummaryBox = LOCATION_BUILD_SUMMARY_BOX.instantiate()
        h_box_container_node.add_child(_node)
        _node.init(_finish_build_info)

func cshow():
    self.show()

func chide():
    self.hide()

func clear()-> void:
    CommonUtils.clear_node(h_box_container_node)