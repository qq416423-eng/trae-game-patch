class_name LocationCard extends Control

@onready var title_node: Label =$StyleRoot / StyleRoot2 / Title
@onready var icon_node: TextureRect =$StyleRoot / StyleRoot2 / Icon
@onready var button_pic_node: TextureRect =$StyleRoot / StyleRoot2 / Button / ButtonPic
@onready var style_root_node: Control =$StyleRoot
@onready var style_root_2_node: Control =$StyleRoot / StyleRoot2
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer
@onready var small_icon_node: TextureRect =$StyleRoot / StyleRoot2 / SmallIcon

const LOCATION_CARD_BASE_2 = preload("res://resource/mw/localtion/location_card_base2.png")
const LOCATION_CARD_BASE_3 = preload("res://resource/mw/localtion/location_card_base3.png")

var button_name: = ""
var type: = ""


var enter_build_name: = ""
var is_click_ani_playing: = false

signal pressed_sign(_node)

func init(_type: String, _plus_y: float = 0)-> void:
    style_root_node.position.y += _plus_y
    var _config = LocationConstants.get_city_location_type_config(_type)

    button_name = _config.button_name
    type = _type
    enter_build_name = CommonUtils.get_value(_config, "enter_build_name", "")

    CommonUtils.set_text(title_node, _config.button_name)

    CommonUtils.update_texture2(small_icon_node, _config.icon)

    match _config.button_style_type:
        LocationConstants.LOCATION_CARD_STYLE_TYPE_ENUM.FUNC:
            CommonUtils.update_texture3(button_pic_node, LOCATION_CARD_BASE_2)
        LocationConstants.LOCATION_CARD_STYLE_TYPE_ENUM.SPECIAL:
            CommonUtils.update_texture3(button_pic_node, LOCATION_CARD_BASE_3)

func get_type()-> String:
    return type

func get_button_name()-> String:
    return button_name

func get_enter_build_name()-> String:
    return enter_build_name

func unchoose()-> void:
    animation_player_node.play("down")
    is_click_ani_playing = false

func _click_animation_finish()-> void:
    pressed_sign.emit(self)

func _on_button_pressed()-> void:
    if is_click_ani_playing:
        return

    is_click_ani_playing = true
    animation_player_node.play("up")