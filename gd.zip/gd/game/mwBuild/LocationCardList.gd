class_name LocationCardList extends Control

@onready var h_box_container_node: HBoxContainer =$HBoxContainer
const LOCATION_CARD = preload("res://tscn/game/mwBuild/LocationCard.tscn")

signal choose_sign(_node: LocationCard)

func init(_type_list: Array)-> void:
    var _index: = 0
    for _type: String in _type_list:
        var _node = LOCATION_CARD.instantiate()
        h_box_container_node.add_child(_node)
        _node.connect("pressed_sign", _choose)
        _node.init(_type, 0 if _index % 2 == 0 else -6)
        _index += 1

func clear()-> void:
    CommonUtils.clear_node(h_box_container_node)

func _choose(_node: LocationCard):
    choose_sign.emit(_node)