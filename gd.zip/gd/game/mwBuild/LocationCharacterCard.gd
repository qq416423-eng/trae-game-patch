class_name LocationCharacterCard extends Control

@onready var hero_portrait_node: HeroPortrait =$StyleRoot / StyleRoot2 / HeroPortrait
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

@onready var hero_portrait_name_node: Label =$StyleRoot / StyleRoot2 / HeroPortraitName
@onready var avatar_name_node: Label =$StyleRoot / StyleRoot2 / AvatarName

@onready var button_node: CommonButton =$StyleRoot / StyleRoot2 / Button
@onready var style_root_node: Control =$StyleRoot
@onready var info_button_node: CommonButton =$StyleRoot / StyleRoot2 / InfoButton

var hero_uid: String = ""
var is_pressed: = false
var npc_info: = {}

signal choose_sign(_node: LocationCharacterCard)
signal view_info_sign(_uid: String)

func init_by_npc_info(_npc_info: Dictionary)-> void:
    npc_info = _npc_info

    if _npc_info.get("hide_portrait", false):
        hero_portrait_node.hide()
        hero_portrait_name_node.hide()
        avatar_name_node.show()
        CommonUtils.set_text(avatar_name_node, _npc_info.get("npc_name", ""))
        if CommonUtils.get_value(_npc_info, "func_type", "") == LocationConstants.NPC_FUNC_TYPE_ENUM.MERCENARY:
            info_button_node.show()
        else:
            info_button_node.hide()
        return
    init(_npc_info.npc_uid)

    if _npc_info.has("npc_name") and not str(_npc_info.npc_name).is_empty():
        if hero_portrait_node.visible:
            hero_portrait_name_node.show()
            avatar_name_node.hide()
            CommonUtils.set_text(hero_portrait_name_node, _npc_info.npc_name)
        else:
            hero_portrait_name_node.hide()
            avatar_name_node.show()
            CommonUtils.set_text(avatar_name_node, _npc_info.npc_name)
    if CommonUtils.get_value(_npc_info, "func_type", "") == LocationConstants.NPC_FUNC_TYPE_ENUM.MERCENARY:
        info_button_node.show()
    else:
        info_button_node.hide()

func init(_hero_uid: String)-> void:
    hero_uid = _hero_uid

    var _hero_json: Dictionary = hero_portrait_node.init(_hero_uid, false)

    if hero_portrait_node.visible:
        hero_portrait_name_node.show()
        avatar_name_node.hide()

        CommonUtils.set_text(hero_portrait_name_node, SoldierUtils.get_nickname(_hero_json))

        self.custom_minimum_size.y += 64
        style_root_node.position.y += 64
    else:

        hero_portrait_name_node.hide()
        avatar_name_node.show()


        CommonUtils.set_text(avatar_name_node, SoldierUtils.get_nickname(_hero_json))

func pop_animation_finish()-> void:
    choose_sign.emit(self)

func get_hero_uid()-> String:
    return hero_uid

func get_npc_info()-> Dictionary:
    return npc_info

func unchoose()-> void:
    button_node.cancel_disable()
    info_button_node.cancel_disable()
    is_pressed = false
    animation_player_node.play("reset")


func _on_button_pressed()-> void:
    if is_pressed:
        return

    button_node.disable()
    info_button_node.disable()
    is_pressed = true
    animation_player_node.play("pop")

func _on_info_button_pressed()-> void:

    view_info_sign.emit(npc_info.npc_uid)