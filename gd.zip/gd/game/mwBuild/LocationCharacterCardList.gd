class_name LocationCharacterCardList extends Control

@onready var v_box_container_node: VBoxContainer =$VBoxContainer

const LOCATION_CHARACTER_CARD = preload("res://tscn/game/mwBuild/LocationCharacterCard.tscn")

var choose_node: LocationCharacterCard


signal choose_sign(_npc_info: Dictionary)
signal view_soldier_info_sign(_uid: String)

func _ready()-> void:
    v_box_container_node.size = self.size
    v_box_container_node.size.x -= 48

func init(_hero_uid_list: Array)-> void:
    _clear()

    for _hero_uid: String in _hero_uid_list:
        if StringUtils.is_empty(_hero_uid):
            continue

        var _node: LocationCharacterCard = LOCATION_CHARACTER_CARD.instantiate()
        v_box_container_node.add_child(_node)
        _node.connect("choose_sign", _choose)
        _node.init(_hero_uid)





func init_by_npc_info(_npc_info_list: Array)-> void:
    _clear()

    for _npc_info: Dictionary in _npc_info_list:
        var _node: LocationCharacterCard = LOCATION_CHARACTER_CARD.instantiate()
        v_box_container_node.add_child(_node)
        _node.connect("choose_sign", _choose)
        _node.connect("view_info_sign", _view_soldier_info)
        _node.init_by_npc_info(_npc_info)

func unchoose()-> void:
    if CommonUtils.is_not_null(choose_node):
        choose_node.unchoose()
        choose_node = null


func _choose(_node: LocationCharacterCard)-> void:
    choose_node = _node
    choose_sign.emit(_node.get_npc_info())

func _clear()-> void:
    choose_node = null
    CommonUtils.clear_node(v_box_container_node)

func _view_soldier_info(_uid: String)-> void:
    view_soldier_info_sign.emit(_uid)