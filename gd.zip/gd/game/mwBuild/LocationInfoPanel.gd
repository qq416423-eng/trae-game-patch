class_name LocationInfoPanel extends Control

@onready var population_total_node =$InfoRoot / InfoBox / PopulationTotal
@onready var population_working_age_node =$InfoRoot / InfoBox / PopulationWorkingAge
@onready var consumption_goods_node =$InfoRoot / InfoBox / ConsumptionGoods
@onready var excess_goods_node =$InfoRoot / InfoBox / ExcessGoods
@onready var development_level_node =$InfoRoot / InfoBox / DevelopmentLevel
@onready var happiness_level_node =$InfoRoot / InfoBox / HappinessLevel
@onready var hygiene_level_node =$InfoRoot / InfoBox / HygieneLevel

@onready var title_node =$InfoRoot / Title
@onready var info_box_node: VBoxContainer =$InfoRoot / InfoBox
@onready var location_description_node: Label =$InfoRoot / LocationDescription
@onready var ruler_node: LevelImageBox =$InfoRoot / InfoBox / Ruler
@onready var kingdom_node: LevelImageBox =$InfoRoot / InfoBox / Kingdom
@onready var banner_background_node: TextureRect =$BannerBackground
@onready var lord_banner_node: LordBanner =$BannerBackground / LordBanner
@onready var background_02_node: TextureRect =$Background02
@onready var relation_emoji_node: RelationEmoji =$RelationEmoji




func init_old(_location_info: Dictionary, is_open_economic_system: bool)-> void:

    CommonUtils.set_text(title_node, _location_info.name)

    if is_open_economic_system:
        info_box_node.show()
        location_description_node.hide()
        population_total_node.update_level(_location_info.population_total / 200)
        population_working_age_node.update_level(_location_info.population_working_age / 200)
        consumption_goods_node.update_level(_location_info.consumption_goods / 100)
        excess_goods_node.update_level(_location_info.excess_goods / 100)
        development_level_node.update_level(_location_info.development_level / 100)
        happiness_level_node.update_level(_location_info.happiness_level / 200)
        hygiene_level_node.update_level(_location_info.hygiene_level / 200)
    else:
        info_box_node.hide()
        location_description_node.show()
        CommonUtils.set_text(
            location_description_node,
            CommonUtils.get_value(_location_info, "description", "")
        )


    if _location_info.has("owner_uid") and StringUtils.is_not_empty(_location_info.owner_uid):
        var _owner_nickname: String = SoldierUtils.get_nickname_by_hero_uid(_location_info.owner_uid)
        ruler_node.update_remark(_owner_nickname)
        banner_background_node.show()
        lord_banner_node.init_by_hero_uid(_location_info.owner_uid)
    else:
        ruler_node.update_remark("无")
        banner_background_node.hide()


    if _location_info.has("belong_country"):
        var _country_name: String = CountryUtils.get_country_name_by_country_code(_location_info.belong_country)
        kingdom_node.update_remark(_country_name)


    match _location_info.type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background_03.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background_03.png")
            relation_emoji_node.show()
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background_02.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background_02.png")
            relation_emoji_node.hide()
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE, LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background.png")
            relation_emoji_node.show()

    if relation_emoji_node.visible:
        relation_emoji_node.init(
            LocationUtils.get_player_relation_value_int(_location_info.location_code)
        )


func init(_location_info: Dictionary)-> void:
    CommonUtils.set_text(title_node, _location_info.name)

    population_total_node.show()
    population_working_age_node.show()
    consumption_goods_node.show()
    excess_goods_node.show()




    match _location_info.type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY, LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            info_box_node.show()
            location_description_node.hide()
            population_total_node.update_level(_location_info.population_total / 200)
            population_working_age_node.update_level(_location_info.population_working_age / 200)
            consumption_goods_node.update_level(_location_info.consumption_goods / 100)
            excess_goods_node.update_level(_location_info.excess_goods / 100)



        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            info_box_node.show()
            location_description_node.hide()
            population_total_node.hide()
            population_working_age_node.hide()
            consumption_goods_node.hide()
            excess_goods_node.hide()
            development_level_node.hide()
            happiness_level_node.hide()
            hygiene_level_node.hide()
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:
            info_box_node.hide()
            location_description_node.show()
            CommonUtils.set_text(
                location_description_node,
                CommonUtils.get_value(_location_info, "description", "")
            )


    if _location_info.has("owner_uid") and StringUtils.is_not_empty(_location_info.owner_uid):
        var _owner_nickname: String = SoldierUtils.get_nickname_by_hero_uid(_location_info.owner_uid)
        ruler_node.update_remark(_owner_nickname)
        banner_background_node.show()
        lord_banner_node.init_by_hero_uid(_location_info.owner_uid)
    else:
        ruler_node.update_remark("无")
        banner_background_node.hide()


    if _location_info.has("belong_country"):
        var _country_name: String = CountryUtils.get_country_name_by_country_code(_location_info.belong_country)
        kingdom_node.update_remark(_country_name)


    match _location_info.type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background_03.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background_03.png")
            relation_emoji_node.show()
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background_04.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background_02.png")
            relation_emoji_node.hide()
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background.png")
            relation_emoji_node.show()
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:
            CommonUtils.update_texture2(background_02_node, "res://resource/background/location_info_panel_background.png")
            CommonUtils.update_texture2(banner_background_node, "res://resource/background/location_info_panel_banner_background.png")
            relation_emoji_node.hide()

    if relation_emoji_node.visible:
        relation_emoji_node.init(
            LocationUtils.get_player_relation_value_int(_location_info.location_code)
        )

func hide_emoji_tip()-> void:
    relation_emoji_node.hide_tip()