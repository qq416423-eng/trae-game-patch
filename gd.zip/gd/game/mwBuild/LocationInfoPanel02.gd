extends Control

@onready var location_name_node =$Background01 / LocationName

func init(_location_info: Dictionary)-> void:
    CommonUtils.set_text(location_name_node, _location_info.name)