class_name MWLocationBase extends Node2D

@onready var focus_effect_node =$Shape / FocusEffect
@onready var select_effect_node =$Shape / SelectEffect

@onready var animation_player_node =$AnimationPlayer
@onready var economic_system_node =$EconomicSystem as EconomicSystem
@onready var entrance_root_node =$EntranceRoot
@onready var nav_link_root_node =$NavLinkRoot

@onready var section_node =$Shape / Section
@onready var view_focus_effect_node =$Shape / ViewFocusEffect
@onready var view_select_effect_node =$Shape / ViewSelectEffect


@onready var window_light_2_node: Sprite2D =$Shape / WindowLight2
@onready var checked_box_node: Area2D =$Shape / CheckedBox
@onready var location_info_tag_node: LocationInfoTag =$Shape / InfoRoot / HBoxRoot / LocationInfoTag
@onready var location_tag_list_node: HBoxContainer =$Shape / InfoRoot / HBoxRoot / LocationTagList
@onready var info_root_node: Node2D =$Shape / InfoRoot

@export var location_type: String
@export var tag_scale_standard: = 0.8

@export var need_refresh_goods: = true

@export var open_light_effect: = true

@export var open_economic_system: = true

@export var is_belong_country: = true
@export var need_show_section: = false

@export var is_detectable_by_player: = false

const NOP_INFO_COLOR_DETECTED: = Color(0.6, 1.0, 0.6)
const NOP_INFO_COLOR_UNDETECTED: = Color(0.6, 0.6, 0.6)
const STRONGHOLD_TAG = preload("res://tscn/game/mwBuild/locationTag/StrongholdTag.tscn")
const SMALL_HAMMER_PERCENT_PLUGIN = preload("res://tscn/baseModule/SmallHammerPercentPlugin.tscn")
const SMALL_UPGRADE_PERCENT_PLUGIN = preload("res://tscn/baseModule/SmallUpgradePercentPlugin.tscn")
const BARRACKS_WORLD_TAG = preload("res://tscn/game/mwBuild/locationTag/BarracksWorldTag.tscn")



var city_data = {}
var player_avatar_node: LocationCharactarAvatar


var zoom_x_standard = 0.45
var zoom_x_min = 0.35
var zoom_x_section = zoom_x_standard - zoom_x_min
var max_transparency: = MWConfig.CITY_SECTION_MAX_TRANSPARENCY



var nav_link_points: = []


var is_being_detected_by_player: = false

var in_location_lord_team_uid_dic: = {}

signal choose(_location_node)
signal mobile_drag_sign(_relative)
signal update_camera_zoom_sign(_update_value: float)

func _ready():
    location_info_tag_node.update_nop_info_color(NOP_INFO_COLOR_UNDETECTED)

    if is_detectable_by_player:
        checked_box_node.monitorable = true
        checked_box_node.get_node("CollisionShape2D").disabled = false

    if open_economic_system:
        economic_system_node.start()

    GlobalLocationData.set_location_node(get_location_code(), self)


    _handle_nav_link()

    var _location_name: String = WSLocationData.get_location_name(get_location_code())
    location_info_tag_node.update_name(_location_name)

    GlobalApplication.connect("change_zoom_sign", _mw_update_zoom)

    _mw_update_zoom(Vector2.ONE)

    section_node.modulate.a = 0.0























    window_light_2_node.self_modulate.a = 0.0


    focus_effect_node.texture = select_effect_node.texture
    view_focus_effect_node.texture = view_select_effect_node.texture
    CommonUtils.update_self_color(focus_effect_node, MWorldConstants.VIEW_FOCUS_COLOR)
    CommonUtils.update_self_color(view_focus_effect_node, MWorldConstants.VIEW_FOCUS_COLOR)

    checked_box_node.global_position = self.global_position

    _costom_ready()

func init(_city_json: Dictionary):

    _handle_city_json(_city_json)
    economic_system_node.init(_city_json)

    if is_belong_country:

        var _belong_country: String = LocationUtils.get_belong_country(get_location_code())
        location_info_tag_node.update_by_country(_belong_country)
        var _country_color: Color = CountryUtils.get_country_color(_belong_country)
        CommonUtils.update_self_color(section_node, _country_color)

    _custom_init()

    refresh_location_tag()

    _refresh_banner(city_data.owner_uid)





func get_near_entrance_position(_refer_point: Vector2)-> Vector2:
    var _entrance_point_list: Array[Vector2] = _list_entrance_position()
    return CommonUtils.get_nearest_point(_entrance_point_list, _refer_point)

func get_random_entrance_position()-> Vector2:
    return _list_entrance_position().pick_random()





func get_type():
    return location_type

func cancel_click():




    select_effect_node.hide()
    view_select_effect_node.hide()
    focus_effect_node.hide()
    view_focus_effect_node.hide()

func light():
    if not open_light_effect:
        return









    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(window_light_2_node, "self_modulate:a", 0.7, 0.3)

func turn_off_light():
    if not open_light_effect:
        return








    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(window_light_2_node, "self_modulate:a", 0.0, 0.3)


func trade(_team_json: Dictionary)-> Dictionary:
    return economic_system_node.trade(_team_json)




func trade_recycle(
    _team_json: Dictionary,

)-> void:
    economic_system_node.increase(_team_json)
    LocationUtils.location_data_repair(city_data)

func get_location_code():
    return self.name



func refresh_goods_and_money_and_recruit():
    if not need_refresh_goods:
        return


    LocationUtils.handle_refresh_goods_and_money(city_data)

    LocationUtils.handle_refresh_recruit(city_data)

func subtract_resource(_resource: Dictionary):
    economic_system_node.subtract(_resource)

func hide_or_show_tag(is_show: bool)-> void:
    location_info_tag_node.hide()

func view_mode_unchoose():
    view_focus_effect_node.hide()
    view_select_effect_node.hide()

func get_location_name()-> String:
    return city_data.name


func refresh_location_tag()-> void:
    CommonUtils.clear_node(location_tag_list_node)

    var _location_code: String = get_location_code()


    if not LocationUtils.check_belongs_to_player(_location_code):
        return

    var _has_build: bool = LocationBuildUtils.has_build(city_data)
    if _has_build or city_data.owner_uid == SoldierUtils.get_player_hero_uid():
        location_tag_list_node.add_child(STRONGHOLD_TAG.instantiate())



    if LocationBuildUtils.check_has_build_barracks(_location_code):
        var _node: BarracksWorldTag = BARRACKS_WORLD_TAG.instantiate()
        location_tag_list_node.add_child(_node)

        var _barracks_nop: = LocationBuildUtils.get_barracks_nop(_location_code)
        var _barracks_max_nop: = LocationBuildUtils.get_barracks_max_nop(_location_code)


        if _barracks_nop > _barracks_max_nop:
            _node.update_count(_barracks_nop, CommonConstants.COLOR_ENUM.RED)
        else:
            _node.update_count(_barracks_nop)

    var _percent_float_info_list: Array = LocationBuildUtils.list_build_progress_info(city_data)
    for _percent_float_info: Dictionary in _percent_float_info_list:
        var _node
        match _percent_float_info.build_status:
            LocationBuildConstants.BUILD_STATUS_ENUM.BUILDING:
                _node = SMALL_HAMMER_PERCENT_PLUGIN.instantiate()
            LocationBuildConstants.BUILD_STATUS_ENUM.UPGRADE:
                _node = SMALL_UPGRADE_PERCENT_PLUGIN.instantiate()

        if CommonUtils.is_null(_node):
            continue

        location_tag_list_node.add_child(_node)
        _node.update_value(_percent_float_info.progress_percent_float * 100)


func refresh_npc_info()-> void:
    pass

func show_player_avatar()-> void:
    var _location_charactar_avatar_node: = load("res://tscn/game/mw/LocationCharactarAvatar.tscn")
    var _location_charactar_avatar_instance: LocationCharactarAvatar = _location_charactar_avatar_node.instantiate()
    self.add_child(_location_charactar_avatar_instance)
    _location_charactar_avatar_instance.init_and_play_effect(CreateCharacterConstants.PLAYER_HERO_CODE)
    player_avatar_node = _location_charactar_avatar_instance

func delete_player_avatar()-> void:
    if CommonUtils.is_not_null(player_avatar_node):
        player_avatar_node.delete()
        player_avatar_node = null

func refresh_nop_info()-> void:
    if not is_being_detected_by_player:
        is_being_detected_by_player = true
        location_info_tag_node.update_nop_info_color(NOP_INFO_COLOR_DETECTED, true)

    var _hero_count: int = in_location_lord_team_uid_dic.size()
    var _soldier_count: int = TeamUtils.get_active_nop_by_team_uid_list(in_location_lord_team_uid_dic.keys())
    location_info_tag_node.update_nop_info(_hero_count, _soldier_count)

func maybe_refresh_nop_info()-> void:
    if is_being_detected_by_player:
        refresh_nop_info()

func disable_player_detection()-> void:
    is_being_detected_by_player = false
    location_info_tag_node.update_nop_info_color(NOP_INFO_COLOR_UNDETECTED)

func handle_hero_team_enter_location(_team_uid: String)-> void:
    in_location_lord_team_uid_dic[_team_uid] = 1
    maybe_refresh_nop_info()

func handle_hero_team_exit_location(_team_uid: String)-> void:
    in_location_lord_team_uid_dic.erase(_team_uid)
    maybe_refresh_nop_info()

func refresh_banner()-> void:
    var _owner_uid = CommonUtils.get_value(city_data, "owner_uid", "")
    if StringUtils.is_not_empty(_owner_uid):
        _refresh_banner(_owner_uid)

func _refresh_banner(_owner_uid: String)-> void:
    location_info_tag_node.refresh_banner(_owner_uid)


func refresh_country_display()-> void:
    if is_belong_country:
        var _belong_country: String = LocationUtils.get_belong_country(get_location_code())
        location_info_tag_node.update_by_country(_belong_country)
        var _country_color: Color = CountryUtils.get_country_color(_belong_country)
        CommonUtils.update_self_color(section_node, _country_color)

func _clear_location_tag_list()-> void:
    CommonUtils.clear_node(location_tag_list_node)

func _custom_init():
    pass

func _costom_ready()-> void:
    pass


func _handle_city_json(_city_json):
    city_data = _city_json























    _init_repair(city_data)


    LocationUtils.location_data_repair(city_data)

func _init_repair(_city_data: Dictionary)-> void:
    if is_nan(_city_data.population_total):
        _city_data.population_total = 0
    if is_nan(_city_data.population_working_age):
        _city_data.population_working_age = 0
    if is_nan(_city_data.consumption_goods):
        _city_data.consumption_goods = 0
    if is_nan(_city_data.excess_goods):
        _city_data.excess_goods = 0
    if is_nan(_city_data.happiness_level):
        _city_data.happiness_level = 0

func _list_entrance_position()-> Array[Vector2]:
    var _list: Array[Vector2] = []
    for _child in entrance_root_node.get_children():
        _list.append(_child.global_position)

    return _list












func _handle_nav_link()-> void:
    if nav_link_root_node.get_children().size() > 0:
        var _nav_link_node: NavigationLink2D = nav_link_root_node.get_children()[0]
        WSLinkData.add_location_link(
            _nav_link_node.get_rid(),
            self.name,
        )
        nav_link_points = [
            self.global_position + _nav_link_node.start_position,
            self.global_position + _nav_link_node.end_position
        ]

func _mw_update_zoom(_zoom: Vector2):
    var _scale = tag_scale_standard / _zoom.x
    if _zoom.x > 1:
        _scale = tag_scale_standard

    info_root_node.scale = Vector2(_scale, _scale)

    var _transparency = 0.0
    if _zoom.x < zoom_x_standard:
        _transparency =(zoom_x_standard - _zoom.x) * max_transparency / zoom_x_section

    if _transparency > max_transparency:
        _transparency = max_transparency

    if need_show_section:
        CommonUtils.update_color(section_node, Color(1, 1, 1, _transparency))

func _on_check_choose_area_focus():
    if not GlobalNode.is_world_input_active():
        return


    if CommonUtils.platform_is_pc():
        if GlobalNode.is_show_mode():
            view_focus_effect_node.show()
        else:
            focus_effect_node.show()

func _on_check_choose_area_cancel_focus():

    if CommonUtils.platform_is_pc():
        focus_effect_node.hide()
        view_focus_effect_node.hide()

func _on_check_choose_area_click():
    if not GlobalNode.is_world_input_active():
        return





    emit_signal("choose", self)

    if GlobalNode.is_show_mode():
        view_select_effect_node.show()
    else:
        select_effect_node.show()

func _on_economic_system_one_turn_sign():
    pass


func _on_check_choose_area_mobile_drag_sign(_relative)-> void:
    mobile_drag_sign.emit(_relative)

func _on_check_choose_area_update_camera_zoom_sign(_update_value: float)-> void:
    update_camera_zoom_sign.emit(_update_value)