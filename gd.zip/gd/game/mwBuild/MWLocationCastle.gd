class_name MWLocationCastle extends MWLocationBase


@export var adjacent_nodes: Array[String] = []