class_name MWLocationCity extends MWLocationBase

@export var trade_city_code_list: Array[String] = []

@export var adjacent_nodes: Array[String] = []


func refresh_npc_info()-> void:
    if city_data.has("npc_refresh_time") and WSData.get_system_counter() - city_data.npc_refresh_time < 1.0:

        return

    _remove_leave_npc()
    _maybe_add_mercenary()
    city_data.npc_refresh_time = WSData.get_system_counter()



func _maybe_add_mercenary()-> void:
    var _count: int = _get_mercenary_type_count()
    if _count >= 2:
        return

    while(_count < 2):
        var _mercenary_prob: float = _get_generate_mercenary_prob(_count)
        if not CommonUtils.prob_true(_mercenary_prob):
            return

        var _npc_info: Dictionary = _generate_mercenary_npc_info()
        WSLocationData.add_location_npc_info(
            get_location_code() + ":" + "Tavern", _npc_info
        )
        _count += 1


func _generate_mercenary_npc_info()-> Dictionary:
    var _generate_mercenary_config: Array = CommonUtils.get_value(
        city_data, "generate_mercenary_config", LocationConfig.DEFAULT_GENERATE_MERCENARY_CONFIG
    )

    var _seed_key: String = CommonConstants.SEED_KEY_ENUM.NPC_REFRESH + get_location_code()

    seed(WSData.get_custom_seed(_seed_key))

    var _random_generate_mercenary_config: Dictionary = CommonUtils.random_by_weight(_generate_mercenary_config)

    WSData.change_custom_seed(_seed_key)

    return {
        "npc_uid": _random_generate_mercenary_config.uid,
        "is_static_npc": false,
        "soldier_count": CommonUtils.random_num2(
            LocationConfig.GENERATE_MERCENARY_COUNT_CONFIG[0],
            LocationConfig.GENERATE_MERCENARY_COUNT_CONFIG[1]
        ),
        "func_type": LocationConstants.NPC_FUNC_TYPE_ENUM.MERCENARY,
        "leave_time": WSData.get_system_counter() + CommonUtils.random_num2(
            LocationConfig.MERCENARY_DURATION_CONFIG[0],
            LocationConfig.MERCENARY_DURATION_CONFIG[1]
        ),
    }


func _get_generate_mercenary_prob(_current_mercenary_type_count: int)-> float:
    if _current_mercenary_type_count == 0:
        return city_data.mercenary_spawn_prob

    if _current_mercenary_type_count == 1:
        return city_data.mercenary_spawn_prob / 5

    return 0.0


func _get_mercenary_type_count()-> int:
    if not city_data.has("npc_info"):
        return 0

    if not city_data.npc_info.has("Tavern"):
        return 0

    var _count: = 0
    for _npc_info: Dictionary in city_data.npc_info.Tavern:
        if CommonUtils.get_value(_npc_info, "func_type", "") == LocationConstants.NPC_FUNC_TYPE_ENUM.MERCENARY:
            _count += 1

    return _count


func _remove_leave_npc()-> void:
    if not city_data.has("npc_info"):
        return

    for _location_type: String in city_data.npc_info.keys():
        var _npc_info_list: Array = city_data.npc_info.get(_location_type)
        for _index in range(_npc_info_list.size() - 1, -1, -1):
            var _npc_info = _npc_info_list[_index]
            if not _npc_info.has("leave_time"):
                continue

            if _npc_info.leave_time < WSData.get_system_counter():
                city_data.npc_info.get(_location_type).remove_at(_index)


func _on_economic_system_one_turn_sign():
    if ArrayUtils.is_empty(trade_city_code_list):
        return


    if city_data.excess_goods > 500:
        var _prob = CommonUtils.get_section_value(
            [0.01 * LocationConfig.LOCATION_END_TRADE_TEAM_FACTOR, 0.1 * LocationConfig.LOCATION_END_TRADE_TEAM_FACTOR],
            [300, 2000], city_data.excess_goods
        )

        if CommonUtils.prob_true(_prob):

            var _resource_json = TradeUtils.get_resource_json(city_data)

            var _target_location_code: String = trade_city_code_list.pick_random()


            var _team_json = TeamUtils.generate_merchant_convoy_team_json(
                _resource_json,
                self.get_near_entrance_position(GlobalLocationData.get_location_point(_target_location_code)),
                get_location_code(),
                _target_location_code,
                city_data.name
            )


            economic_system_node.subtract(
                _resource_json,
            )


            GlobalNode.mworld_scene.create_team(
                _team_json)