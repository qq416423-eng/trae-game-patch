class_name MWLocationPlanformBase extends Control

@onready var location_button_root_node =$ButtonRoot / LocationButtonRoot
@onready var location_card_list_node: LocationCardList =$LocationCardList

var choose_node: LocationCard

signal enter_city_location(_node)

func _ready():





    pass

func init_button(_location_code: String)-> void:


    var _build_button_type_list: = LocationUtils.get_build_button_type_list(_location_code)


    var _button_type_list: = WSLocationData.get_button_type_list(_location_code)
    _build_button_type_list.append_array(_button_type_list)

    location_card_list_node.init(_build_button_type_list)





func hide_button():
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(location_card_list_node, "modulate:a", 0.0, 0.2)

func show_button():
    var _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(location_card_list_node, "modulate:a", 1.0, 0.2)
    if CommonUtils.is_not_null(choose_node):
        choose_node.unchoose()
        choose_node = null

func clear():
    location_card_list_node.clear()
    choose_node = null

func _on_location_card_list_choose_sign(_node: LocationCard)-> void:
    choose_node = _node
    hide_button()
    emit_signal("enter_city_location", _node)