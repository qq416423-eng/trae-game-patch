class_name MWLocationVillage extends MWLocationBase


@export var master_location_name: String


func _custom_init():

    WSLocationData.plus_specialty_grocery(
        master_location_name, city_data.specialty_grocery,
        LocationConfig.VILLAGE_SPECIALTY_GROCERY_ENHANCE_RATIO, true
    )


func _on_economic_system_one_turn_sign():

    if city_data.excess_goods > 200:
        var _prob = CommonUtils.get_section_value(
            [0.01 * LocationConfig.LOCATION_VILLAGE_TRADE_TEAM_FACTOR, 0.1 * LocationConfig.LOCATION_VILLAGE_TRADE_TEAM_FACTOR],
            [200, 1000], city_data.excess_goods
        )

        if CommonUtils.prob_true(_prob):

            var _resource_json = TradeUtils.get_resource_json(city_data)


            var _team_json = TeamUtils.generate_villager_team_json(
                _resource_json,

                self.get_near_entrance_position(GlobalLocationData.get_location_point(master_location_name)),
                get_location_code(),
                master_location_name,

                city_data.ethnicity,
                city_data.name
            )


            economic_system_node.subtract(
                _resource_json,
            )


            GlobalNode.mworld_scene.create_team(
                _team_json)

func _costom_ready()-> void:
    location_tag_list_node.global_position = location_info_tag_node.global_position - Vector2(- location_tag_list_node.size.x, -48)