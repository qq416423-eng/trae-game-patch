class_name BarracksWorldTag extends Control

@onready var count_node: Label =$Icon / Count

func update_count(_count: int, _color = null)-> void:
    CommonUtils.set_text(count_node, _count)
    if _color != null:
        CommonUtils.update_self_color(count_node, _color)
    else:
        CommonUtils.update_self_color(count_node, CommonConstants.COLOR_ENUM.WHITE)