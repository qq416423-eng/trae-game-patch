extends Control

signal close_page_sign

var _item_list_scroll: ScrollContainer
var _item_list_vbox: VBoxContainer
var _confirm_button: Button
var _close_button: Button
var _message_label: Label
var _title_label: Label
var _selected_items: Dictionary = {}


var distribute_mode: String = "armor"

static var _shared_panel_style: StyleBoxFlat
static var _shared_list_style: StyleBoxFlat

const MODE_ARMOR: = "armor"
const MODE_WEAPON1: = "weapon1"
const MODE_WEAPON2: = "weapon2"
const MODE_WEAPON3: = "weapon3"
const MODE_HORSE: = "horse"
const MODE_HARMOUR: = "harmour"


func _ready()-> void:
    _build_ui()


func _get_panel_style()-> StyleBoxFlat:
    if _shared_panel_style == null:
        _shared_panel_style = StyleBoxFlat.new()
        _shared_panel_style.bg_color = Color(0.82, 0.72, 0.55, 0.92)
        _shared_panel_style.border_width_left = 3
        _shared_panel_style.border_width_right = 3
        _shared_panel_style.border_width_top = 3
        _shared_panel_style.border_width_bottom = 3
        _shared_panel_style.border_color = Color(0.4, 0.3, 0.15, 1.0)
    return _shared_panel_style


func _get_list_style()-> StyleBoxFlat:
    if _shared_list_style == null:
        _shared_list_style = StyleBoxFlat.new()
        _shared_list_style.bg_color = Color(0.75, 0.65, 0.48, 0.85)
        _shared_list_style.border_width_left = 2
        _shared_list_style.border_width_right = 2
        _shared_list_style.border_width_top = 2
        _shared_list_style.border_width_bottom = 2
        _shared_list_style.border_color = Color(0.35, 0.28, 0.15, 0.8)
    return _shared_list_style


func _build_ui()-> void:
    set_anchors_preset(PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP

    var _vp = get_viewport_rect().size

    var _bg = ColorRect.new()
    _bg.color = Color(0.86, 0.78, 0.62, 0.95)
    _bg.set_anchors_preset(PRESET_FULL_RECT)
    add_child(_bg)

    var _root = Panel.new()
    _root.set_anchors_preset(PRESET_FULL_RECT)
    _root.add_theme_stylebox_override("panel", _get_panel_style())
    add_child(_root)

    _title_label = Label.new()
    _title_label.add_theme_font_size_override("font_size", 26)
    _title_label.add_theme_color_override("font_color", Color(0.3, 0.2, 0.05))
    _title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _title_label.position = Vector2(0, 30)
    _title_label.size = Vector2(_vp.x, 50)
    _root.add_child(_title_label)

    _item_list_scroll = ScrollContainer.new()
    _item_list_scroll.position = Vector2(_vp.x * 0.15, 90)
    _item_list_scroll.size = Vector2(_vp.x * 0.7, _vp.y - 250)
    _item_list_scroll.add_theme_stylebox_override("panel", _get_list_style())
    _root.add_child(_item_list_scroll)

    _item_list_vbox = VBoxContainer.new()
    _item_list_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _item_list_vbox.add_theme_constant_override("separation", 8)
    _item_list_scroll.add_child(_item_list_vbox)

    _message_label = Label.new()
    _message_label.add_theme_font_size_override("font_size", 20)
    _message_label.add_theme_color_override("font_color", Color(0.4, 0.15, 0.05))
    _message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _message_label.position = Vector2(0, _vp.y - 120)
    _message_label.size = Vector2(_vp.x, 40)
    _message_label.text = ""
    _root.add_child(_message_label)

    _confirm_button = Button.new()
    _confirm_button.text = "确认分发"
    _confirm_button.add_theme_font_size_override("font_size", 22)
    _confirm_button.custom_minimum_size = Vector2(200, 55)
    _confirm_button.position = Vector2(_vp.x * 0.35, _vp.y - 70)
    _confirm_button.size = Vector2(200, 55)
    _confirm_button.pressed.connect(_on_confirm_pressed)
    _root.add_child(_confirm_button)

    _close_button = Button.new()
    _close_button.text = "关闭"
    _close_button.add_theme_font_size_override("font_size", 20)
    _close_button.custom_minimum_size = Vector2(150, 55)
    _close_button.position = Vector2(_vp.x * 0.55, _vp.y - 70)
    _close_button.size = Vector2(150, 55)
    _close_button.pressed.connect(_on_close_pressed)
    _root.add_child(_close_button)



func _is_etype_allowed(_etype: String)-> bool:
    match distribute_mode:
        MODE_ARMOR:
            return _etype in[
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET,
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR,
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE,
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER,
            ]
        MODE_WEAPON1, MODE_WEAPON2, MODE_WEAPON3:
            return _etype == WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON
        MODE_HORSE:
            return _etype == WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HORSE
        MODE_HARMOUR:
            return _etype == WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HARMOUR
        _:
            return false



func _get_slot_field(_etype: String)-> String:
    match distribute_mode:
        MODE_WEAPON1:
            return "weapon1"
        MODE_WEAPON2:
            return "weapon2"
        MODE_WEAPON3:
            return "weapon3"
        MODE_HORSE:
            return "horse"
        MODE_HARMOUR:
            return "harmour"
        MODE_ARMOR:
            match _etype:
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET:
                    return "helmet"
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR:
                    return "armour"
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE:
                    return "shoe"
                WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER:
                    return "shoulder"

    match _etype:
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.WEAPON:
            return "weapon1"
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HELMET:
            return "helmet"
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.ARMOUR:
            return "armour"
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOE:
            return "shoe"
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.SHOULDER:
            return "shoulder"
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HORSE:
            return "horse"
        WeaponTypeConstants.EQUIPMENT_TYPE_ENUM.HARMOUR:
            return "harmour"
        _:
            return ""


func _get_mode_title()-> String:
    match distribute_mode:
        MODE_ARMOR:
            return "分发装备给私卫（防具类）"
        MODE_WEAPON1:
            return "分发主武器给私卫（武器槽位1）"
        MODE_WEAPON2:
            return "分发副武器给私卫（武器槽位2）"
        MODE_WEAPON3:
            return "分发备用武器给私卫（武器槽位3）"
        MODE_HORSE:
            return "分发马匹给私卫"
        MODE_HARMOUR:
            return "分发马铠给私卫"
        _:
            return "分发装备给私卫"


func _refresh_item_list()-> void:
    for _child in _item_list_vbox.get_children():
        _child.queue_free()
    _selected_items.clear()

    _title_label.text = _get_mode_title()







    WSData.save_my_goods(GoodsUtils.organize_goods(WSData.get_player_goods()))

    var _player_goods: Array = WSData.get_player_goods()
    var _has_items: bool = false

    for _goods_entry in _player_goods:
        var _item_simple_json: Dictionary = _goods_entry.item
        var _count: int = _goods_entry.count


        if _count <= 0:
            continue

        if CommonUtils.get_value(_item_simple_json, "lock", false):
            continue

        var _full_json: Dictionary = GoodsUtils.get_json_by_simple_json(_item_simple_json)
        var _uid: String = _full_json.get("uid", "")

        var _etype: String = WeaponTypeConstants.get_etype(_uid)
        if WeaponTypeConstants.FORBID_EQUIP_ETYPE_LIST.has(_etype):
            continue


        if not _is_etype_allowed(_etype):
            continue

        var _name: String = _full_json.get("name", "未知")
        _has_items = true

        var _row = HBoxContainer.new()
        _row.custom_minimum_size = Vector2(0, 50)
        _row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _row.add_theme_constant_override("separation", 10)

        var _checkbox = CheckBox.new()
        _checkbox.text = _name + "  (持有: " + str(_count) + ")"
        _checkbox.add_theme_font_size_override("font_size", 18)
        _checkbox.custom_minimum_size = Vector2(400, 50)
        _row.add_child(_checkbox)

        var _spin_label = Label.new()
        _spin_label.text = "分发数:"
        _spin_label.add_theme_font_size_override("font_size", 16)
        _row.add_child(_spin_label)

        var _spinbox = SpinBox.new()
        _spinbox.min_value = 0
        _spinbox.max_value = _count
        _spinbox.value = 0
        _spinbox.custom_minimum_size = Vector2(100, 40)
        _spinbox.value_changed.connect(_on_spinbox_changed.bind(_item_simple_json))
        _row.add_child(_spinbox)

        _item_list_vbox.add_child(_row)

    if not _has_items:
        var _empty_label = Label.new()
        _empty_label.text = "背包中没有可分配的此类装备"
        _empty_label.add_theme_font_size_override("font_size", 18)
        _empty_label.add_theme_color_override("font_color", Color(0.3, 0.25, 0.1))
        _empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        _item_list_vbox.add_child(_empty_label)


func _on_spinbox_changed(_value: float, _simple_json: Dictionary)-> void:
    var _count: int = int(_value)
    if _count > 0:
        _selected_items[_simple_json] = _count
    else:
        _selected_items.erase(_simple_json)




func _mod_is_slot_equipped(_slot_val)-> bool:
    if _slot_val is Dictionary:
        var _slot_uid = _slot_val.get("uid", null)
        return _slot_uid != null and _slot_uid != ""
    return false






func _mod_is_same_item(_item_a: Dictionary, _item_b: Dictionary)-> bool:
    return GoodsUtils.goods_json_equals(_item_a.duplicate(), _item_b.duplicate())


func _on_confirm_pressed()-> void:
    if _selected_items.is_empty():
        _message_label.text = "请先选择要分配的装备"
        _message_label.add_theme_color_override("font_color", Color(0.5, 0.2, 0.1))
        return

    var _guards: Array = []
    for _soldier in WSData.player_data.team:
        if _soldier is Dictionary and _soldier.get("uid", "").begins_with("mod_player_guard"):
            _guards.append(_soldier)

    if _guards.is_empty():
        _message_label.text = "随行部队中没有私卫可以分配装备"
        _message_label.add_theme_color_override("font_color", Color(0.6, 0.1, 0.1))
        return

    var _total_distributed: int = 0

    for _simple_json in _selected_items:
        var _distribute_count: int = _selected_items[_simple_json]
        var _full_json: Dictionary = GoodsUtils.get_json_by_simple_json(_simple_json)
        var _uid: String = _full_json.get("uid", "")
        var _etype: String = WeaponTypeConstants.get_etype(_uid)
        var _slot_field: String = _get_slot_field(_etype)
        if _slot_field == "":
            continue

        var _actually_distributed: int = 0
        var _assigned_indices: Array = []
        for _i in range(_distribute_count):
            var _target_idx: int = -1


            for _gi in range(_guards.size()):
                if _assigned_indices.has(_gi):
                    continue
                if not _mod_is_slot_equipped(_guards[_gi].get(_slot_field,{})):
                    _target_idx = _gi
                    break






            var _old_item: Dictionary = {}
            if _target_idx < 0:
                for _gi in range(_guards.size()):
                    if _assigned_indices.has(_gi):
                        continue
                    var _slot_val = _guards[_gi].get(_slot_field,{})
                    if not _mod_is_slot_equipped(_slot_val):
                        continue
                    if _mod_is_same_item(_slot_val, _simple_json):
                        continue
                    _target_idx = _gi
                    _old_item = _slot_val
                    break


            if _target_idx < 0:
                break


            if not _old_item.is_empty():
                GoodsUtils.player_add_goods_by_simple_json(_old_item.duplicate(), 1)

            _guards[_target_idx][_slot_field] = _simple_json.duplicate()
            _assigned_indices.append(_target_idx)
            _total_distributed += 1
            _actually_distributed += 1



        GoodsUtils.player_add_goods_by_simple_json(_simple_json.duplicate(), - _actually_distributed)

    _message_label.text = "分配完成！共分配 " + str(_total_distributed) + " 件装备给 " + str(_guards.size()) + " 名私卫"
    _message_label.add_theme_color_override("font_color", Color(0.1, 0.4, 0.1))
    _refresh_item_list()


func _on_close_pressed()-> void:
    hide_interface()
    close_page_sign.emit()


func show_interface()-> void:
    visible = true
    _message_label.text = ""
    _refresh_item_list()


func set_forge_type(_type: String)-> void:
    pass


func hide_interface()-> void:
    visible = false