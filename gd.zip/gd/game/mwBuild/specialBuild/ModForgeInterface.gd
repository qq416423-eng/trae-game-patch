extends Control

signal close_page_sign

var _item_list_scroll: ScrollContainer
var _item_list_vbox: VBoxContainer
var _popup_panel: Panel
var _popup_title: Label
var _message_label: Label
var _selected_item_json: Dictionary = {}
var _selected_item_simple_json: Dictionary = {}
var _forge_type: String = ""

const FORGE_TYPE_ETYPES: Dictionary = {
    "ARMOUR": ["HELMET", "ARMOUR", "SHOULDER", "SHOE"],
    "WEAPON": ["WEAPON"],
    "HARMOUR": ["HARMOUR"],
}


static var _shared_panel_style: StyleBoxFlat
static var _shared_list_style: StyleBoxFlat
static var _shared_popup_style: StyleBoxFlat


func _ready()-> void:
    _build_ui()


func _get_panel_style()-> StyleBoxFlat:
    if _shared_panel_style == null:
        _shared_panel_style = StyleBoxFlat.new()
        _shared_panel_style.bg_color = Color(0.82, 0.72, 0.55, 0.92)
        _shared_panel_style.border_width_left = 3
        _shared_panel_style.border_width_right = 3
        _shared_panel_style.border_width_top = 3
        _shared_panel_style.border_width_bottom = 3
        _shared_panel_style.border_color = Color(0.4, 0.3, 0.15, 1.0)
    return _shared_panel_style


func _get_list_style()-> StyleBoxFlat:
    if _shared_list_style == null:
        _shared_list_style = StyleBoxFlat.new()
        _shared_list_style.bg_color = Color(0.75, 0.65, 0.48, 0.85)
        _shared_list_style.border_width_left = 2
        _shared_list_style.border_width_right = 2
        _shared_list_style.border_width_top = 2
        _shared_list_style.border_width_bottom = 2
        _shared_list_style.border_color = Color(0.35, 0.28, 0.15, 0.8)
    return _shared_list_style


func _get_popup_style()-> StyleBoxFlat:
    if _shared_popup_style == null:
        _shared_popup_style = StyleBoxFlat.new()
        _shared_popup_style.bg_color = Color(0.85, 0.75, 0.58, 0.97)
        _shared_popup_style.border_width_left = 3
        _shared_popup_style.border_width_right = 3
        _shared_popup_style.border_width_top = 3
        _shared_popup_style.border_width_bottom = 3
        _shared_popup_style.border_color = Color(0.45, 0.35, 0.18, 1.0)
    return _shared_popup_style


func _build_ui()-> void:
    set_anchors_preset(PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP

    var _viewport_size = get_viewport_rect().size


    var _bg = ColorRect.new()
    _bg.color = Color(0.86, 0.78, 0.62, 0.95)
    _bg.set_anchors_preset(PRESET_FULL_RECT)
    add_child(_bg)

    var _root_panel = Panel.new()
    _root_panel.set_anchors_preset(PRESET_FULL_RECT)
    _root_panel.add_theme_stylebox_override("panel", _get_panel_style())
    add_child(_root_panel)

    var _title = Label.new()
    _title.text = "锻造装备"
    _title.add_theme_font_size_override("font_size", 28)
    _title.add_theme_color_override("font_color", Color(0.3, 0.2, 0.05))
    _title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _title.position = Vector2(0, 30)
    _title.size = Vector2(_viewport_size.x, 50)
    _root_panel.add_child(_title)

    var _desc = Label.new()
    _desc.text = "选择背包中未锁定的装备进行锻造（费用 = 装备价格 × (1+(星级-1)×0.8%) × (1+品质×17%) × 数量）"
    _desc.add_theme_font_size_override("font_size", 16)
    _desc.add_theme_color_override("font_color", Color(0.35, 0.25, 0.1))
    _desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _desc.position = Vector2(0, 75)
    _desc.size = Vector2(_viewport_size.x, 30)
    _root_panel.add_child(_desc)

    _item_list_scroll = ScrollContainer.new()
    _item_list_scroll.position = Vector2(_viewport_size.x * 0.15, 120)
    _item_list_scroll.size = Vector2(_viewport_size.x * 0.7, _viewport_size.y - 200)
    _item_list_scroll.add_theme_stylebox_override("panel", _get_list_style())
    _root_panel.add_child(_item_list_scroll)

    _item_list_vbox = VBoxContainer.new()
    _item_list_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _item_list_vbox.add_theme_constant_override("separation", 8)
    _item_list_scroll.add_child(_item_list_vbox)

    _message_label = Label.new()
    _message_label.add_theme_font_size_override("font_size", 20)
    _message_label.add_theme_color_override("font_color", Color(0.4, 0.15, 0.05))
    _message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _message_label.position = Vector2(0, _viewport_size.y - 70)
    _message_label.size = Vector2(_viewport_size.x, 40)
    _message_label.text = ""
    _root_panel.add_child(_message_label)

    _popup_panel = Panel.new()
    _popup_panel.visible = false
    _popup_panel.custom_minimum_size = Vector2(400, 320)
    var _popup_x = _viewport_size.x * 0.5 - 200
    var _popup_y = _viewport_size.y * 0.5 - 160
    _popup_panel.position = Vector2(_popup_x, _popup_y)
    _popup_panel.size = Vector2(400, 320)
    _popup_panel.add_theme_stylebox_override("panel", _get_popup_style())
    _root_panel.add_child(_popup_panel)

    _popup_title = Label.new()
    _popup_title.add_theme_font_size_override("font_size", 20)
    _popup_title.add_theme_color_override("font_color", Color(0.3, 0.2, 0.05))
    _popup_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _popup_title.position = Vector2(0, 20)
    _popup_title.size = Vector2(400, 40)
    _popup_panel.add_child(_popup_title)

    var _quantities = [1, 5, 10, 20]
    var _btn_y = 80
    for _qty in _quantities:
        var _btn = Button.new()
        _btn.text = "锻造 " + str(_qty) + " 个"
        _btn.add_theme_font_size_override("font_size", 20)
        _btn.custom_minimum_size = Vector2(300, 45)
        _btn.position = Vector2(50, _btn_y)
        _btn.size = Vector2(300, 45)
        _btn.pressed.connect(_on_forge_qty_pressed.bind(_qty))
        _popup_panel.add_child(_btn)
        _btn_y += 55

    var _cancel_btn = Button.new()
    _cancel_btn.text = "取消"
    _cancel_btn.add_theme_font_size_override("font_size", 18)
    _cancel_btn.custom_minimum_size = Vector2(300, 40)
    _cancel_btn.position = Vector2(50, _btn_y)
    _cancel_btn.size = Vector2(300, 40)
    _cancel_btn.pressed.connect(_on_popup_cancel)
    _popup_panel.add_child(_cancel_btn)


func _refresh_item_list()-> void:
    for _child in _item_list_vbox.get_children():
        _child.queue_free()

    var _player_goods: Array = WSData.get_player_goods()
    var _has_items: bool = false

    for _goods_entry in _player_goods:
        var _item_simple_json: Dictionary = _goods_entry.item
        var _count: int = _goods_entry.count

        if CommonUtils.get_value(_item_simple_json, "lock", false):
            continue

        var _full_json: Dictionary = GoodsUtils.get_json_by_simple_json(_item_simple_json)
        var _uid: String = _full_json.get("uid", "")

        var _etype: String = WeaponTypeConstants.get_etype(_uid)
        var _allowed_etypes: Array = FORGE_TYPE_ETYPES.get(_forge_type,[])
        if not _allowed_etypes.has(_etype):
            continue

        var _base_price: int = int(_full_json.get("price", 0))
        if _base_price <= 0:
            continue

        var _star: int = int(_full_json.get("star", 3))
        var _quality: int = int(_item_simple_json.get("quality", 0))
        var _forge_price: int = _calc_forge_price(_base_price, _star, _quality)

        _has_items = true

        var _row = Button.new()
        _row.text = _full_json.get("name", "未知") + "    锻造价: " + str(_forge_price) + "    持有: " + str(_count)
        _row.add_theme_font_size_override("font_size", 18)
        _row.custom_minimum_size = Vector2(0, 50)
        _row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _row.alignment = HORIZONTAL_ALIGNMENT_LEFT
        _row.pressed.connect(_on_item_pressed.bind(_item_simple_json, _full_json, _forge_price))
        _item_list_vbox.add_child(_row)

    if not _has_items:
        var _empty_label = Label.new()
        _empty_label.text = "背包中没有可锻造的装备"
        _empty_label.add_theme_font_size_override("font_size", 18)
        _empty_label.add_theme_color_override("font_color", Color(0.3, 0.25, 0.1))
        _empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        _item_list_vbox.add_child(_empty_label)


static func _calc_forge_price(_base_price: int, _star: int, _quality: int)-> int:
    var _star_mult: float = 1.0 + max(0, _star - 1) * 0.008
    var _quality_mult: float = 1.0 + max(0, _quality) * 0.17
    return int(_base_price * _star_mult * _quality_mult)


func _on_item_pressed(_simple_json: Dictionary, _full_json: Dictionary, _forge_price: int)-> void:
    _selected_item_simple_json = _simple_json
    _selected_item_json = _full_json
    _popup_title.text = _full_json.get("name", "未知") + " (单价: " + str(_forge_price) + ")"
    _popup_panel.visible = true


func _on_forge_qty_pressed(_qty: int)-> void:
    if _selected_item_json.is_empty():
        return

    var _base_price: int = int(_selected_item_json.get("price", 0))
    var _star: int = int(_selected_item_json.get("star", 3))
    var _quality: int = int(_selected_item_simple_json.get("quality", 0))
    var _unit_price: int = _calc_forge_price(_base_price, _star, _quality)
    var _total_cost: int = _unit_price * _qty
    var _player_money: int = WSData.player_data.money

    if _player_money < _total_cost:
        _message_label.text = "锻造失败！金钱不足（需要 " + str(_total_cost) + "，持有 " + str(_player_money) + "）"
        _message_label.add_theme_color_override("font_color", Color(0.6, 0.1, 0.1))
        _popup_panel.visible = false
        return

    WSData.update_money(- _total_cost, true)
    GoodsUtils.player_add_goods_by_simple_json(_selected_item_simple_json, _qty)

    _message_label.text = "锻造成功！获得 " + str(_qty) + " 个 " + _selected_item_json.get("name", "") + "，花费 " + str(_total_cost) + " 金"
    _message_label.add_theme_color_override("font_color", Color(0.1, 0.4, 0.1))
    _popup_panel.visible = false
    _refresh_item_list()


func _on_popup_cancel()-> void:
    _popup_panel.visible = false


func show_interface()-> void:
    visible = true
    _message_label.text = ""
    _refresh_item_list()


func set_forge_type(_type: String)-> void:
    _forge_type = _type


func hide_interface()-> void:
    visible = false