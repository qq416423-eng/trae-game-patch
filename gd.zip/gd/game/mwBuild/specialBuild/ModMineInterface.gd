extends Control

signal close_page_sign
signal manage_workers_sign
signal manage_food_sign
signal take_ore_confirm_sign(ratio: float)
signal supply_tools_sign
signal deepen_mine_sign
signal drain_water_sign
signal supply_timber_sign
signal talk_manager_sign


const MOD_C_OVERLAY: Color = Color(0.0, 0.0, 0.0, 0.55)
const MOD_C_PANEL_BG: Color = Color(0.45, 0.45, 0.5, 0.95)
const MOD_C_CARD_BG: Color = Color(0.55, 0.55, 0.6, 0.9)
const MOD_C_BAR_BG: Color = Color(0.36, 0.36, 0.42)
const MOD_C_BORDER: Color = Color(0.25, 0.25, 0.3)
const MOD_C_TEXT: Color = Color(0.95, 0.95, 1.0)
const MOD_C_TEXT_DIM: Color = Color(0.78, 0.78, 0.85)
const MOD_C_GREEN: Color = Color(0.4, 0.78, 0.45)
const MOD_C_YELLOW: Color = Color(0.88, 0.72, 0.28)
const MOD_C_RED: Color = Color(0.88, 0.38, 0.32)
const MOD_C_BLUE: Color = Color(0.48, 0.64, 0.92)

const MOD_C_BTN_BG: Color = Color(0.5, 0.48, 0.52)
const MOD_C_BTN_BG_HV: Color = Color(0.58, 0.56, 0.61)
const MOD_C_BTN_BORDER: Color = Color(0.25, 0.25, 0.3)
const MOD_C_BTN_TEXT: Color = Color(0.95, 0.95, 1.0)
const MOD_C_BTN_TEXT_HV: Color = Color(0.95, 0.95, 1.0)

const MOD_C_TAKE_FILL: Color = Color(0.9, 0.55, 0.16)
const MOD_C_TAKE_FILL_HL: Color = Color(1.0, 0.66, 0.25)
const MOD_C_TAKE_DARK: Color = Color(0.55, 0.3, 0.08)


var _core_label: Label = null
var _warn_box: VBoxContainer = null
var _stat_grid: GridContainer = null
var _bar_box: VBoxContainer = null
var _slider_box: VBoxContainer = null
var _chip_row: HBoxContainer = null
var _detail_label: Label = null
var _ore_take_card: PanelContainer = null
var _ore_slider: HSlider = null
var _ore_pct_label: Label = null
var _ore_preview_label: Label = null
var _ore_stock_cache: Dictionary = {"copper": 0.0, "iron": 0.0, "silver": 0.0}


func _ready()-> void:

    _fit_to_screen()
    mouse_filter = Control.MOUSE_FILTER_STOP
    _build_static_ui()
    var _vp: Viewport = get_viewport()
    if _vp != null:
        _vp.size_changed.connect(_fit_to_screen)



func _fit_to_screen()-> void:
    var _vs: Vector2 = get_viewport_rect().size
    position = Vector2.ZERO
    size = _vs


func show_interface()-> void:
    _fit_to_screen()
    visible = true


func hide_interface()-> void:
    visible = false



func update_status(_core, _detail = null)-> void:
    if _core is Dictionary:
        _apply_rich(_core)
    else:
        _apply_text(str(_core), str(_detail) if _detail != null else "")



func _build_static_ui()-> void:
    var _overlay: ColorRect = ColorRect.new()
    _overlay.color = MOD_C_OVERLAY
    _overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(_overlay)

    var _safe: MarginContainer = MarginContainer.new()
    _safe.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _safe.add_theme_constant_override("margin_left", 16)
    _safe.add_theme_constant_override("margin_right", 16)
    _safe.add_theme_constant_override("margin_top", 12)
    _safe.add_theme_constant_override("margin_bottom", 12)
    add_child(_safe)

    var _center: CenterContainer = CenterContainer.new()
    _safe.add_child(_center)

    var _panel: PanelContainer = PanelContainer.new()
    _panel.custom_minimum_size = Vector2(840, 640)
    _panel.add_theme_stylebox_override("panel", _flat(MOD_C_PANEL_BG, MOD_C_BORDER, 3, 0))
    _center.add_child(_panel)

    var _margin: MarginContainer = MarginContainer.new()
    _margin.add_theme_constant_override("margin_left", 22)
    _margin.add_theme_constant_override("margin_right", 22)
    _margin.add_theme_constant_override("margin_top", 16)
    _margin.add_theme_constant_override("margin_bottom", 16)
    _panel.add_child(_margin)

    var _root: VBoxContainer = VBoxContainer.new()
    _root.add_theme_constant_override("separation", 12)
    _margin.add_child(_root)


    var _title_bar: HBoxContainer = HBoxContainer.new()
    _root.add_child(_title_bar)
    var _title: Label = Label.new()
    _title.text = "采矿场"
    _title.add_theme_font_size_override("font_size", 24)
    _title.add_theme_color_override("font_color", MOD_C_TEXT)
    _title_bar.add_child(_title)
    var _spacer: Control = Control.new()
    _spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _title_bar.add_child(_spacer)
    var _close_btn: Button = Button.new()
    _close_btn.text = "✕ 关闭"
    _close_btn.custom_minimum_size = Vector2(96, 38)
    _style_button(_close_btn)
    _close_btn.pressed.connect(func(): close_page_sign.emit())
    _title_bar.add_child(_close_btn)


    var _scroll: ScrollContainer = ScrollContainer.new()
    _scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    _root.add_child(_scroll)

    var _content: VBoxContainer = VBoxContainer.new()
    _content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _content.add_theme_constant_override("separation", 10)
    _scroll.add_child(_content)


    _warn_box = VBoxContainer.new()
    _warn_box.add_theme_constant_override("separation", 6)
    _content.add_child(_warn_box)


    _core_label = Label.new()
    _core_label.add_theme_font_size_override("font_size", 17)
    _core_label.add_theme_color_override("font_color", MOD_C_TEXT)
    _core_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _core_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _content.add_child(_core_label)


    _stat_grid = GridContainer.new()
    _stat_grid.columns = 2
    _stat_grid.add_theme_constant_override("h_separation", 24)
    _stat_grid.add_theme_constant_override("v_separation", 8)
    _stat_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _content.add_child(_stat_grid)


    _bar_box = VBoxContainer.new()
    _bar_box.add_theme_constant_override("separation", 8)
    _content.add_child(_bar_box)


    _slider_box = VBoxContainer.new()
    _slider_box.add_theme_constant_override("separation", 8)
    _content.add_child(_slider_box)


    _chip_row = HBoxContainer.new()
    _chip_row.add_theme_constant_override("separation", 8)
    _content.add_child(_chip_row)


    _detail_label = Label.new()
    _detail_label.add_theme_font_size_override("font_size", 13)
    _detail_label.add_theme_color_override("font_color", MOD_C_TEXT_DIM)
    _detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _detail_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _content.add_child(_detail_label)


    _build_ore_take_card(_content)


    var _btn_grid: GridContainer = GridContainer.new()
    _btn_grid.columns = 2
    _btn_grid.add_theme_constant_override("h_separation", 10)
    _btn_grid.add_theme_constant_override("v_separation", 10)
    _root.add_child(_btn_grid)
    _add_btn(_btn_grid, "管理工人", manage_workers_sign)
    _add_btn(_btn_grid, "管理粮库", manage_food_sign)
    _add_btn(_btn_grid, "补给工具", supply_tools_sign)
    _add_btn(_btn_grid, "补充木材支撑", supply_timber_sign)
    _add_btn(_btn_grid, "排水", drain_water_sign)
    _add_btn(_btn_grid, "加深矿井", deepen_mine_sign)
    _add_btn(_btn_grid, "与管理员对话", talk_manager_sign)



func _build_ore_take_card(_parent: VBoxContainer)-> void:
    _ore_take_card = PanelContainer.new()
    _ore_take_card.add_theme_stylebox_override("panel", _flat(MOD_C_CARD_BG, MOD_C_BORDER, 2, 0))
    _ore_take_card.visible = false
    _parent.add_child(_ore_take_card)

    var _card_margin: MarginContainer = MarginContainer.new()
    _card_margin.add_theme_constant_override("margin_left", 12)
    _card_margin.add_theme_constant_override("margin_right", 12)
    _card_margin.add_theme_constant_override("margin_top", 10)
    _card_margin.add_theme_constant_override("margin_bottom", 10)
    _ore_take_card.add_child(_card_margin)

    var _card_v: VBoxContainer = VBoxContainer.new()
    _card_v.add_theme_constant_override("separation", 8)
    _card_margin.add_child(_card_v)


    var _title_row: HBoxContainer = HBoxContainer.new()
    _title_row.add_theme_constant_override("separation", 8)
    _card_v.add_child(_title_row)
    var _t: Label = Label.new()
    _t.text = "取出矿石(滑动选择比例)"
    _t.add_theme_font_size_override("font_size", 15)
    _t.add_theme_color_override("font_color", MOD_C_TEXT)
    _title_row.add_child(_t)
    var _t_spacer: Control = Control.new()
    _t_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _title_row.add_child(_t_spacer)
    _ore_pct_label = Label.new()
    _ore_pct_label.text = "100%"
    _ore_pct_label.add_theme_font_size_override("font_size", 17)
    _ore_pct_label.add_theme_color_override("font_color", MOD_C_TAKE_FILL_HL)
    _title_row.add_child(_ore_pct_label)


    _ore_slider = HSlider.new()
    _ore_slider.min_value = 0.0
    _ore_slider.max_value = 100.0
    _ore_slider.step = 1.0
    _ore_slider.value = 100.0
    _ore_slider.custom_minimum_size = Vector2(0, 34)
    _ore_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var _groove_sb: StyleBoxFlat = _flat(MOD_C_BAR_BG, MOD_C_BORDER, 2, 7)
    _groove_sb.content_margin_top = 6.0
    _groove_sb.content_margin_bottom = 6.0
    _ore_slider.add_theme_stylebox_override("slider", _groove_sb)
    var _take_fill_sb: StyleBoxFlat = _flat(MOD_C_TAKE_FILL, MOD_C_TAKE_FILL, 0, 7)
    _take_fill_sb.content_margin_top = 6.0
    _take_fill_sb.content_margin_bottom = 6.0
    _ore_slider.add_theme_stylebox_override("grabber_area", _take_fill_sb)
    var _take_fill_hl: StyleBoxFlat = _flat(MOD_C_TAKE_FILL_HL, MOD_C_TAKE_FILL_HL, 0, 7)
    _take_fill_hl.content_margin_top = 6.0
    _take_fill_hl.content_margin_bottom = 6.0
    _ore_slider.add_theme_stylebox_override("grabber_area_highlight", _take_fill_hl)
    _ore_slider.add_theme_icon_override("grabber", _make_grabber_icon(Color(1.0, 1.0, 0.98), MOD_C_TAKE_DARK, 26))
    _ore_slider.add_theme_icon_override("grabber_highlight", _make_grabber_icon(Color(1.0, 1.0, 0.98), MOD_C_TAKE_DARK, 30))
    _ore_slider.add_theme_icon_override("grabber_pressed", _make_grabber_icon(MOD_C_TAKE_FILL_HL, MOD_C_TAKE_DARK, 30))
    _ore_slider.value_changed.connect(_on_ore_slider_changed)
    _card_v.add_child(_ore_slider)


    _ore_preview_label = Label.new()
    _ore_preview_label.add_theme_font_size_override("font_size", 13)
    _ore_preview_label.add_theme_color_override("font_color", MOD_C_TEXT_DIM)
    _ore_preview_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _card_v.add_child(_ore_preview_label)


    var _confirm_btn: Button = Button.new()
    _confirm_btn.text = "确认取出"
    _confirm_btn.custom_minimum_size = Vector2(0, 42)
    _confirm_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _style_button(_confirm_btn)
    _confirm_btn.pressed.connect(func(): take_ore_confirm_sign.emit(clampf(_ore_slider.value / 100.0, 0.0, 1.0)))
    _card_v.add_child(_confirm_btn)


func _add_btn(_grid: GridContainer, _text: String, _sig: Signal)-> void:
    var _b: Button = Button.new()
    _b.text = _text
    _b.custom_minimum_size = Vector2(320, 44)
    _b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _style_button(_b)
    _b.pressed.connect(func(): _sig.emit())
    _grid.add_child(_b)












func _apply_rich(_data: Dictionary)-> void:
    _clear_children(_warn_box)
    _clear_children(_stat_grid)
    _clear_children(_bar_box)
    _clear_children(_slider_box)
    _clear_children(_chip_row)
    var _idle: bool = bool(_data.get("idle", false))
    if _idle:
        _apply_text(str(_data.get("idle_hint", "可租用或购买")), "")
        return
    _apply_text("", "")
    for _w in _data.get("warnings",[]):
        _warn_box.add_child(_mk_chip("⚠ " + str(_w), "red"))
    for _s in _data.get("stats",[]):
        _stat_grid.add_child(_mk_stat(str(_s.get("k", "")), str(_s.get("v", "")), str(_s.get("c", "white"))))
    for _b in _data.get("bars",[]):
        _bar_box.add_child(_mk_bar(str(_b.get("label", "")), float(_b.get("value", 0.0)), float(_b.get("max", 100.0)), str(_b.get("text", "")), bool(_b.get("bad_high", false))))

    for _sl in _data.get("sliders",[]):
        _slider_box.add_child(_mk_read_slider(str(_sl.get("label", "")), float(_sl.get("value", 0.0)), float(_sl.get("max", 100.0)), str(_sl.get("text", "")), str(_sl.get("c", ""))))
    for _c in _data.get("chips",[]):
        _chip_row.add_child(_mk_chip(str(_c.get("text", "")), str(_c.get("c", "dim"))))
    _detail_label.text = str(_data.get("detail", ""))

    if _data.has("ore_stock"):
        var _os: Dictionary = _data.get("ore_stock",{})
        _ore_stock_cache = {
            "copper": float(_os.get("copper", 0.0)),
            "iron": float(_os.get("iron", 0.0)),
            "silver": float(_os.get("silver", 0.0)),
        }
        _ore_take_card.visible = true
        _ore_slider.value = 100.0
        _update_ore_preview()
    else:
        _ore_take_card.visible = false



func _apply_text(_core: String, _detail: String)-> void:
    _core_label.text = _core
    _core_label.visible = _core != ""
    if _core != "":
        _clear_children(_warn_box)
        _clear_children(_stat_grid)
        _clear_children(_bar_box)
        _clear_children(_slider_box)
        _clear_children(_chip_row)
        if _ore_take_card != null:
            _ore_take_card.visible = false
    _detail_label.text = _detail



func _on_ore_slider_changed(_v: float)-> void:
    if _ore_pct_label != null:
        _ore_pct_label.text = str(int(_v)) + "%"
    _update_ore_preview()


func _update_ore_preview()-> void:
    if _ore_slider == null or _ore_preview_label == null:
        return
    var _ratio: float = clampf(_ore_slider.value / 100.0, 0.0, 1.0)
    var _copper: int = int(float(_ore_stock_cache.get("copper", 0.0)) * _ratio)
    var _iron: int = int(float(_ore_stock_cache.get("iron", 0.0)) * _ratio)
    var _silver: int = int(float(_ore_stock_cache.get("silver", 0.0)) * _ratio)
    var _total: int = _copper + _iron + _silver
    var _pct: String = str(int(_ore_slider.value)) + "%"
    if _total <= 0:
        _ore_preview_label.text = "按 " + _pct + " 取出: 没有整数矿石可取(存量为浮点累积, 比例太小取不出整数)"
        _ore_preview_label.add_theme_color_override("font_color", MOD_C_YELLOW)
    else:
        _ore_preview_label.text = "按 " + _pct + " 取出: 铜" + str(_copper) + " · 铁" + str(_iron) + " · 银" + str(_silver) + " (共" + str(_total) + "个) · 余数留场继续累积"
        _ore_preview_label.add_theme_color_override("font_color", MOD_C_TEXT_DIM)



func _mk_stat(_k: String, _v: String, _c: String)-> Control:
    var _row: HBoxContainer = HBoxContainer.new()
    _row.add_theme_constant_override("separation", 8)
    _row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var _kl: Label = Label.new()
    _kl.text = _k
    _kl.custom_minimum_size = Vector2(92, 0)
    _kl.add_theme_font_size_override("font_size", 14)
    _kl.add_theme_color_override("font_color", MOD_C_TEXT_DIM)
    _row.add_child(_kl)
    var _vl: Label = Label.new()
    _vl.text = _v
    _vl.add_theme_font_size_override("font_size", 17)
    _vl.add_theme_color_override("font_color", _col(_c))
    _row.add_child(_vl)
    return _row


func _mk_bar(_label: String, _value: float, _max: float, _text: String, _bad_high: bool)-> Control:
    var _row: HBoxContainer = HBoxContainer.new()
    _row.add_theme_constant_override("separation", 8)
    _row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var _kl: Label = Label.new()
    _kl.text = _label
    _kl.custom_minimum_size = Vector2(92, 0)
    _kl.add_theme_font_size_override("font_size", 14)
    _kl.add_theme_color_override("font_color", MOD_C_TEXT)
    _row.add_child(_kl)
    var _ratio: float = 0.0
    if _max > 0.0:
        _ratio = clampf(_value / _max, 0.0, 1.0)
    var _bc: Color = _bar_col(_ratio, _bad_high)
    var _pb: ProgressBar = ProgressBar.new()
    _pb.custom_minimum_size = Vector2(0, 12)
    _pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _pb.min_value = 0.0
    _pb.max_value = 1.0
    _pb.value = _ratio
    _pb.show_percentage = false
    _pb.add_theme_stylebox_override("background", _flat(MOD_C_BAR_BG, MOD_C_BAR_BG, 0, 4))
    _pb.add_theme_stylebox_override("fill", _flat(_bc, _bc, 0, 4))
    _row.add_child(_pb)
    var _vl: Label = Label.new()
    if _text == "":
        _text = str(int(_value)) + "/" + str(int(_max))
    _vl.text = _text
    _vl.custom_minimum_size = Vector2(130, 0)
    _vl.add_theme_font_size_override("font_size", 13)
    _vl.add_theme_color_override("font_color", _bc)
    _row.add_child(_vl)
    return _row




func _mk_read_slider(_label: String, _value: float, _max: float, _text: String, _c: String = "")-> Control:
    var _row: HBoxContainer = HBoxContainer.new()
    _row.add_theme_constant_override("separation", 8)
    _row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var _kl: Label = Label.new()
    _kl.text = _label
    _kl.custom_minimum_size = Vector2(92, 0)
    _kl.add_theme_font_size_override("font_size", 14)
    _kl.add_theme_color_override("font_color", MOD_C_TEXT)
    _row.add_child(_kl)
    var _ratio: float = 0.0
    if _max > 0.0:
        _ratio = clampf(_value / _max, 0.0, 1.0)
    var _col_v: Color = _bar_col(_ratio, false) if _c == "" else _col(_c)

    var _track: Control = Control.new()
    _track.custom_minimum_size = Vector2(0, 16)
    _track.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var _slot: Panel = Panel.new()
    _slot.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _slot.add_theme_stylebox_override("panel", _flat(MOD_C_BAR_BG, MOD_C_BORDER, 0, 4))
    _track.add_child(_slot)
    var _fill: Panel = Panel.new()
    _fill.set_anchor(SIDE_LEFT, 0.0)
    _fill.set_anchor(SIDE_RIGHT, _ratio)
    _fill.set_anchor(SIDE_TOP, 0.0)
    _fill.set_anchor(SIDE_BOTTOM, 1.0)
    _fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _fill.add_theme_stylebox_override("panel", _flat(_col_v, _col_v, 0, 4))
    _track.add_child(_fill)

    var _thumb_pos: float = clampf(_ratio, 0.02, 0.98)
    var _thumb: Panel = Panel.new()
    _thumb.set_anchor(SIDE_LEFT, _thumb_pos)
    _thumb.set_anchor(SIDE_RIGHT, _thumb_pos)
    _thumb.set_anchor(SIDE_TOP, 0.0)
    _thumb.set_anchor(SIDE_BOTTOM, 1.0)
    _thumb.offset_left = -6
    _thumb.offset_right = 6
    _thumb.offset_top = 2
    _thumb.offset_bottom = -2
    _thumb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _thumb.add_theme_stylebox_override("panel", _flat(MOD_C_TEXT, _col_v, 2, 6))
    _track.add_child(_thumb)
    _row.add_child(_track)
    var _vl: Label = Label.new()
    if _text == "":
        _text = str(int(_value)) + "/" + str(int(_max))
    _vl.text = _text
    _vl.custom_minimum_size = Vector2(210, 0)
    _vl.add_theme_font_size_override("font_size", 13)
    _vl.add_theme_color_override("font_color", _col_v)
    _row.add_child(_vl)
    return _row




func _make_grabber_icon(_core: Color, _edge: Color, _size: int)-> ImageTexture:
    var _img: Image = Image.create(_size, _size, false, Image.FORMAT_RGBA8)
    _img.fill(Color(0.0, 0.0, 0.0, 0.0))
    var _c: float = float(_size) / 2.0
    var _r_edge: float = float(_size) / 2.0 - 1.0
    var _r_core: float = float(_size) / 2.0 - 3.5
    for _x in range(_size):
        for _y in range(_size):
            var _dx: float = float(_x) + 0.5 - _c
            var _dy: float = float(_y) + 0.5 - _c
            var _d: float = sqrt(_dx * _dx + _dy * _dy)
            if _d <= _r_edge:
                _img.set_pixel(_x, _y, _edge if _d > _r_core else _core)
    return ImageTexture.create_from_image(_img)


func _mk_chip(_text: String, _c: String)-> PanelContainer:
    var _col_v: Color = _col(_c)
    var _p: PanelContainer = PanelContainer.new()
    var _sb: StyleBoxFlat = _flat(Color(_col_v.r, _col_v.g, _col_v.b, 0.16), Color(_col_v.r, _col_v.g, _col_v.b, 0.55), 1, 8)
    _sb.content_margin_left = 10.0
    _sb.content_margin_right = 10.0
    _sb.content_margin_top = 3.0
    _sb.content_margin_bottom = 3.0
    _p.add_theme_stylebox_override("panel", _sb)
    var _l: Label = Label.new()
    _l.text = _text
    _l.add_theme_font_size_override("font_size", 14)
    _l.add_theme_color_override("font_color", _col_v)
    _p.add_child(_l)
    return _p


func _bar_col(_ratio: float, _bad_high: bool)-> Color:
    var _r: float =(1.0 - _ratio) if _bad_high else _ratio
    if _r >= 0.55:
        return MOD_C_GREEN
    if _r >= 0.25:
        return MOD_C_YELLOW
    return MOD_C_RED


func _col(_name: String)-> Color:
    match _name:
        "green": return MOD_C_GREEN
        "yellow": return MOD_C_YELLOW
        "red": return MOD_C_RED
        "blue": return MOD_C_BLUE
        "dim": return MOD_C_TEXT_DIM
        _: return MOD_C_TEXT




func _style_button(_b: Button)-> void:
    _b.add_theme_font_size_override("font_size", 16)
    _b.add_theme_color_override("font_color", MOD_C_BTN_TEXT)
    _b.add_theme_color_override("font_hover_color", MOD_C_BTN_TEXT_HV)
    _b.add_theme_color_override("font_pressed_color", MOD_C_BTN_TEXT_HV)
    _b.add_theme_color_override("font_focus_color", MOD_C_BTN_TEXT)
    var _sb_n: StyleBoxFlat = _flat(MOD_C_BTN_BG, MOD_C_BTN_BORDER, 2, 0)
    _sb_n.content_margin_left = 8.0
    _sb_n.content_margin_right = 8.0
    _sb_n.content_margin_top = 4.0
    _sb_n.content_margin_bottom = 4.0
    var _sb_h: StyleBoxFlat = _flat(MOD_C_BTN_BG_HV, MOD_C_BTN_BORDER, 2, 0)
    _sb_h.content_margin_left = 8.0
    _sb_h.content_margin_right = 8.0
    _sb_h.content_margin_top = 4.0
    _sb_h.content_margin_bottom = 4.0
    _b.add_theme_stylebox_override("normal", _sb_n)
    _b.add_theme_stylebox_override("hover", _sb_h)
    _b.add_theme_stylebox_override("pressed", _sb_h)
    _b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())


func _flat(_bg: Color, _border: Color, _border_w: int, _radius: int)-> StyleBoxFlat:
    var _sb: StyleBoxFlat = StyleBoxFlat.new()
    _sb.bg_color = _bg
    _sb.border_color = _border
    _sb.set_border_width_all(_border_w)
    _sb.set_corner_radius_all(_radius)
    return _sb


func _clear_children(_node: Node)-> void:
    for _child in _node.get_children():
        _node.remove_child(_child)
        _child.queue_free()