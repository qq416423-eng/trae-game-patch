extends Control




























signal close_page_sign
signal slot_add_ore_sign(_idx: int, _amount: int)
signal slot_add_ingot_sign(_idx: int, _amount: int)
signal slot_add_wood_sign(_idx: int, _amount: int)
signal slot_take_ore_sign(_idx: int, _amount: int)
signal slot_take_ingot_sign(_idx: int, _amount: int)
signal slot_take_wood_sign(_idx: int, _amount: int)
signal slot_take_product_ingot_sign(_idx: int, _amount: int)
signal slot_take_money_sign(_idx: int, _amount: int)


const MOD_C_OVERLAY: Color = Color(0.1, 0.07, 0.03, 0.55)
const MOD_C_PANEL_BG: Color = Color(0.91, 0.86, 0.76)
const MOD_C_CARD: Color = Color(0.96, 0.93, 0.86)
const MOD_C_BORDER: Color = Color(0.68, 0.58, 0.42)
const MOD_C_TEXT: Color = Color(0.23, 0.15, 0.06)
const MOD_C_DIM: Color = Color(0.52, 0.43, 0.28)
const MOD_C_ACCENT: Color = Color(0.78, 0.56, 0.15)

const MOD_C_WHITE_BG: Color = Color(0.99, 0.98, 0.93)
const MOD_C_WHITE_BD: Color = Color(0.76, 0.69, 0.54)
const MOD_C_GREEN_BG: Color = Color(0.82, 0.9, 0.72)
const MOD_C_GREEN_BD: Color = Color(0.32, 0.52, 0.26)
const MOD_C_GREEN_TX: Color = Color(0.2, 0.34, 0.14)
const MOD_C_GOLD_BG: Color = Color(0.98, 0.9, 0.63)
const MOD_C_GOLD_BD: Color = Color(0.7, 0.53, 0.12)
const MOD_C_GOLD_TX: Color = Color(0.45, 0.33, 0.06)

const MOD_C_PURPLE: Color = Color(0.55, 0.36, 0.82)
const MOD_C_ORANGE: Color = Color(0.86, 0.54, 0.16)
const MOD_C_GREEN_AC: Color = Color(0.33, 0.56, 0.27)
const MOD_C_RED: Color = Color(0.66, 0.3, 0.22)
const MOD_C_YELLOW: Color = Color(0.76, 0.58, 0.1)


var _main_panel: PanelContainer = null
var _title_label: Label = null
var _state_chip: Label = null
var _stats_label: Label = null
var _warn_box: VBoxContainer = null
var _furnace_hint: Label = null
var _legend_label: Label = null
var _grid: GridContainer = null

var _ore_tag: Label = null
var _ore_slider: HSlider = null
var _ore_value: Label = null
var _ore_btn: Button = null
var _ingot_tag: Label = null
var _ingot_slider: HSlider = null
var _ingot_value: Label = null
var _ingot_btn: Button = null
var _wood_tag: Label = null
var _wood_slider: HSlider = null
var _wood_value: Label = null
var _wood_btn: Button = null

var _take_ore_edit: LineEdit = null
var _take_ore_btn: Button = null
var _take_ingot_edit: LineEdit = null
var _take_ingot_btn: Button = null
var _take_wood_edit: LineEdit = null
var _take_wood_btn: Button = null
var _take_prodingot_edit: LineEdit = null
var _take_prodingot_btn: Button = null
var _take_money_edit: LineEdit = null
var _take_money_btn: Button = null

var _feedback_panel: PanelContainer = null
var _feedback_label: Label = null
var _feedback_timer: Timer = null


var _slot_infos: Array = []
var _furnace_cells: Array = []
var _selected_idx: int = 0
var _bag_copper: int = 0
var _bag_ingot: int = 0
var _bag_wood: int = 0


func _ready()-> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    _build_static_ui()
    _fit_to_screen()
    var _vp: Viewport = get_viewport()
    if _vp != null:
        _vp.size_changed.connect(_fit_to_screen)


func _fit_to_screen()-> void:
    var _vs: Vector2 = get_viewport_rect().size
    position = Vector2.ZERO
    size = _vs
    if _main_panel != null:

        var _w: int = clampi(int(_vs.x) - 24, 320, 620)
        var _h: int = maxi(int(_vs.y) - 24, 240)
        _main_panel.custom_minimum_size = Vector2(_w, _h)


func show_interface()-> void:
    _fit_to_screen()
    visible = true


func hide_interface()-> void:
    visible = false



func update_status(_data: Dictionary)-> void:
    if _title_label == null:
        return
    var _level: String = str(_data.get("level", ""))
    if _level == "big":
        _title_label.text = "铸钱厂(大)"
    elif _level == "small":
        _title_label.text = "铸钱厂(小)"
    else:
        _title_label.text = "铸钱厂"

    var _fs: String = str(_data.get("furnace_state", "idle"))
    match _fs:
        "burning":
            _mk_chip(_state_chip, "烧炼中", MOD_C_GREEN_AC)
        "no_wood":
            _mk_chip(_state_chip, "缺燃料", MOD_C_YELLOW)
        "idle":
            _mk_chip(_state_chip, "待投料", MOD_C_DIM)
        _:
            _mk_chip(_state_chip, "未建厂", MOD_C_DIM)

    for _child in _warn_box.get_children():
        _warn_box.remove_child(_child)
        _child.queue_free()
    for _w in _data.get("warnings",[]):
        _warn_box.add_child(_mk_chip_label(str(_w), MOD_C_RED))

    var _today: int = int(_data.get("today_income", 0))
    var _total: int = int(_data.get("total_income", 0))
    _bag_copper = int(_data.get("bag_copper", 0))
    _bag_ingot = int(_data.get("bag_ingot", 0))
    _bag_wood = int(_data.get("bag_wood", 0))
    var _cap_in: int = int(_data.get("input_max", 60))
    var _cap_wd: int = int(_data.get("wood_max", 40))
    _stats_label.text = "今日 +" + _fmt_money(_today) + " 德里 · 累计 +" + _fmt_money(_total) \
    + "\n背包: 铜矿石 " + str(_bag_copper) + " · 铜锭 " + str(_bag_ingot) + " · 木材 " + str(_bag_wood)

    if _legend_label != null:
        _legend_label.text = "固定2个熔炉槽·升星扩容：白框=投入(铜矿石/铜锭·上限" + str(_cap_in) \
        + ") 绿框=木材燃料(上限" + str(_cap_wd) + ") 金框=产出\n流程：铜矿石→烧成铜锭→取出→再投白框→烧成德里"

    _slot_infos = _data.get("slots",[])
    if _slot_infos.is_empty():
        _furnace_hint.text = "未建成铸钱厂或没有熔炼槽"
    else:
        _furnace_hint.text = "点某条熔炉列选中(高亮) · 底部滑条放料 · 右侧数字框取出"
    _sync_furnace_cells()
    _selected_idx = clampi(_selected_idx, 0, maxi(_slot_infos.size() - 1, 0))
    _refresh_furnace_cells()
    _update_sliders()



func show_feedback(_text: String, _kind: String = "ok", _duration: float = 2.6)-> void:
    if _feedback_panel == null or _feedback_label == null:
        return
    _feedback_label.text = _text
    var _bg: Color = MOD_C_GREEN_AC
    match _kind:
        "err":
            _bg = MOD_C_RED
        "info":
            _bg = Color(0.3, 0.45, 0.7)
    _feedback_panel.add_theme_stylebox_override("panel", _flat(Color(_bg.r, _bg.g, _bg.b, 0.16), _bg, 1, 4))
    _feedback_panel.visible = true
    if _feedback_timer == null:
        _feedback_timer = Timer.new()
        _feedback_timer.one_shot = true
        _feedback_timer.timeout.connect(_hide_feedback)
        add_child(_feedback_timer)
    _feedback_timer.stop()
    _feedback_timer.wait_time = maxf(0.4, _duration)
    _feedback_timer.start()


func _hide_feedback()-> void:
    if _feedback_panel != null:
        _feedback_panel.visible = false



func _sync_furnace_cells()-> void:
    if _grid == null:
        return
    var _count: int = _slot_infos.size()
    if _furnace_cells.size() != _count:

        for _cell in _furnace_cells:
            var _b: Button = _cell["btn"]
            if is_instance_valid(_b):
                _b.queue_free()
        _furnace_cells.clear()
        _grid.columns = clampi(_count, 2, 5)
        for _i: int in range(_count):
            _furnace_cells.append(_mk_furnace_cell(_i))


func _mk_furnace_cell(_i: int)-> Dictionary:
    var _btn: Button = Button.new()
    _btn.text = ""
    _btn.custom_minimum_size = Vector2(84, 150)
    _btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _btn.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _btn.pressed.connect(func(): _select_furnace(_i))
    _grid.add_child(_btn)

    var _margin: MarginContainer = MarginContainer.new()
    _margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _margin.add_theme_constant_override("margin_left", 6)
    _margin.add_theme_constant_override("margin_right", 6)
    _margin.add_theme_constant_override("margin_top", 5)
    _margin.add_theme_constant_override("margin_bottom", 5)
    _btn.add_child(_margin)
    var _vb: VBoxContainer = VBoxContainer.new()
    _vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _vb.add_theme_constant_override("separation", 4)
    _margin.add_child(_vb)
    var _header: Label = Label.new()
    _header.text = "槽 " + str(_i + 1)
    _header.custom_minimum_size = Vector2(0, 16)
    _header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _header.add_theme_font_size_override("font_size", 12)
    _header.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _vb.add_child(_header)
    var _white: Label = _mk_box("空", MOD_C_WHITE_BG, MOD_C_WHITE_BD, MOD_C_TEXT, 3.0)
    _vb.add_child(_white)
    var _green: Label = _mk_box("无木", MOD_C_GREEN_BG, MOD_C_GREEN_BD, MOD_C_GREEN_TX, 2.0)
    _vb.add_child(_green)
    var _gold: Label = _mk_box("空", MOD_C_GOLD_BG, MOD_C_GOLD_BD, MOD_C_GOLD_TX, 3.0)
    _vb.add_child(_gold)
    return {"btn": _btn, "header": _header, "white": _white, "green": _green, "gold": _gold}


func _mk_box(_text: String, _bg: Color, _bd: Color, _tx: Color, _stretch: float)-> Label:
    var _l: Label = Label.new()
    _l.text = _text
    _l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _l.custom_minimum_size = Vector2(0, 34)
    _l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _l.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _l.size_flags_stretch_ratio = _stretch
    _l.add_theme_font_size_override("font_size", 13)
    _l.add_theme_color_override("font_color", _tx)
    _l.add_theme_stylebox_override("normal", _flat(_bg, _bd, 2, 6))
    _l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return _l


func _select_furnace(_idx: int)-> void:
    if _idx < 0 or _idx >= _slot_infos.size():
        return
    _selected_idx = _idx
    _refresh_furnace_cells()
    _update_sliders()


func _refresh_furnace_cells()-> void:
    for _i: int in range(_furnace_cells.size()):
        var _cell: Dictionary = _furnace_cells[_i]
        var _info: Dictionary = {} if _i >= _slot_infos.size() else _slot_infos[_i]
        var _ore: int = int(_info.get("ore", 0))
        var _ingot: int = int(_info.get("ingot", 0))
        var _wood: int = int(_info.get("wood", 0))
        var _out_ingot: int = int(_info.get("out_ingot", 0))
        var _money: int = int(_info.get("money", 0))
        var _state: String = str(_info.get("state", "empty"))

        var _head: String = ""
        if _i == _selected_idx:
            _head = "▶ 槽 " + str(_i + 1)
        else:
            _head = "槽 " + str(_i + 1)
        (cell_header(_cell) as Label).text = _head
        (cell_header(_cell) as Label).add_theme_color_override("font_color", _state_color(_state))

        if _ore > 0:
            (_cell["white"] as Label).text = "铜矿石 " + str(_ore)
        elif _ingot > 0:
            (_cell["white"] as Label).text = "铜锭 " + str(_ingot)
        else:
            (_cell["white"] as Label).text = "空"

        if _wood > 0:
            (_cell["green"] as Label).text = "木 " + str(_wood)
        else:
            (_cell["green"] as Label).text = "无木"

        var _out: String = ""
        if _out_ingot > 0:
            _out = "锭 " + str(_out_ingot)
        if _money > 0:
            if _out != "":
                _out += " · "
            _out += _fmt_money(_money)
        if _out == "":
            _out = "空"
        (_cell["gold"] as Label).text = _out

        var _btn: Button = _cell["btn"]
        if _i == _selected_idx:
            _btn.add_theme_stylebox_override("normal", _flat(Color(0.99, 0.92, 0.72), MOD_C_ACCENT, 3, 8))
            _btn.add_theme_stylebox_override("hover", _flat(Color(1.0, 0.95, 0.8), MOD_C_ACCENT, 3, 8))
            _btn.add_theme_stylebox_override("pressed", _flat(Color(1.0, 0.95, 0.8), MOD_C_ACCENT, 3, 8))
        else:
            _btn.add_theme_stylebox_override("normal", _flat(MOD_C_CARD, MOD_C_BORDER, 1, 8))
            _btn.add_theme_stylebox_override("hover", _flat(Color(0.99, 0.96, 0.9), MOD_C_BORDER, 1, 8))
            _btn.add_theme_stylebox_override("pressed", _flat(MOD_C_CARD, MOD_C_BORDER, 1, 8))


func cell_header(_cell: Dictionary)-> Label:
    return _cell["header"]


func _state_color(_state: String)-> Color:
    match _state:
        "burning":
            return MOD_C_GREEN_AC
        "no_wood":
            return MOD_C_YELLOW
        _:
            return MOD_C_DIM



func _update_sliders()-> void:
    var _valid: bool = _slot_infos.size() > 0 and _selected_idx >= 0 and _selected_idx < _slot_infos.size()
    if not _valid:
        _reset_slider(_ore_slider, _ore_value)
        _reset_slider(_ingot_slider, _ingot_value)
        _reset_slider(_wood_slider, _wood_value)
        return
    var _info: Dictionary = _slot_infos[_selected_idx]
    var _ore_max: int = int(_info.get("ore_max", 0))
    var _ingot_max: int = int(_info.get("ingot_max", 0))
    var _wood_add: int = int(_info.get("wood_max", 0))
    var _ore: int = int(_info.get("ore", 0))
    var _ingot: int = int(_info.get("ingot", 0))

    _ore_slider.max_value = float(_ore_max)
    _ore_slider.value = 0.0
    _ore_slider.editable = _ore_max > 0
    _ore_value.text = "0"
    if _ingot > 0:
        _ore_tag.text = "铜矿石放入(白框已放锭)"
        _ore_tag.add_theme_color_override("font_color", MOD_C_DIM)
    else:
        _ore_tag.text = "铜矿石放入·背包" + str(_bag_copper)
        _ore_tag.add_theme_color_override("font_color", MOD_C_PURPLE)

    _ingot_slider.max_value = float(_ingot_max)
    _ingot_slider.value = 0.0
    _ingot_slider.editable = _ingot_max > 0
    _ingot_value.text = "0"
    if _ore > 0:
        _ingot_tag.text = "铜锭放入(白框已放矿)"
        _ingot_tag.add_theme_color_override("font_color", MOD_C_DIM)
    else:
        _ingot_tag.text = "铜锭放入·背包" + str(_bag_ingot)
        _ingot_tag.add_theme_color_override("font_color", MOD_C_ORANGE)

    _wood_slider.max_value = float(_wood_add)
    _wood_slider.value = 0.0
    _wood_slider.editable = _wood_add > 0
    _wood_value.text = "0"
    _wood_tag.text = "木材放入·背包" + str(_bag_wood)
    _wood_tag.add_theme_color_override("font_color", MOD_C_GREEN_AC)


func _reset_slider(_slider: HSlider, _value_label: Label)-> void:
    _slider.max_value = 0.0
    _slider.value = 0.0
    _slider.editable = false
    _value_label.text = "0"


func _on_ore_put()-> void:
    slot_add_ore_sign.emit(_selected_idx, int(_ore_slider.value))


func _on_ingot_put()-> void:
    slot_add_ingot_sign.emit(_selected_idx, int(_ingot_slider.value))


func _on_wood_put()-> void:
    slot_add_wood_sign.emit(_selected_idx, int(_wood_slider.value))



func _on_take_ore()-> void:
    slot_take_ore_sign.emit(_selected_idx, _parse_amount(_take_ore_edit))


func _on_take_ingot()-> void:
    slot_take_ingot_sign.emit(_selected_idx, _parse_amount(_take_ingot_edit))


func _on_take_wood()-> void:
    slot_take_wood_sign.emit(_selected_idx, _parse_amount(_take_wood_edit))


func _on_take_prodingot()-> void:
    slot_take_product_ingot_sign.emit(_selected_idx, _parse_amount(_take_prodingot_edit))


func _on_take_money()-> void:
    slot_take_money_sign.emit(_selected_idx, _parse_amount(_take_money_edit))


func _parse_amount(_edit: LineEdit)-> int:
    var _t: String = _edit.text.strip_edges()
    if _t == "":
        return 0
    if _t.is_valid_int():
        return maxi(int(_t), 0)
    return 0



func _build_static_ui()-> void:

    var _overlay: ColorRect = ColorRect.new()
    _overlay.color = MOD_C_OVERLAY
    _overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_overlay)

    var _center: CenterContainer = CenterContainer.new()
    _center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(_center)
    _main_panel = PanelContainer.new()
    _main_panel.add_theme_stylebox_override("panel", _flat(MOD_C_PANEL_BG, MOD_C_BORDER, 2, 14))
    _center.add_child(_main_panel)

    var _pm: MarginContainer = MarginContainer.new()
    _pm.add_theme_constant_override("margin_left", 14)
    _pm.add_theme_constant_override("margin_right", 14)
    _pm.add_theme_constant_override("margin_top", 10)
    _pm.add_theme_constant_override("margin_bottom", 10)
    _main_panel.add_child(_pm)
    var _root: VBoxContainer = VBoxContainer.new()
    _root.add_theme_constant_override("separation", 8)
    _pm.add_child(_root)

    var _title_row: HBoxContainer = HBoxContainer.new()
    _title_row.add_theme_constant_override("separation", 8)
    _root.add_child(_title_row)
    _title_label = Label.new()
    _title_label.text = "铸钱厂"
    _title_label.add_theme_font_size_override("font_size", 20)
    _title_label.add_theme_color_override("font_color", MOD_C_TEXT)
    _title_row.add_child(_title_label)
    _state_chip = Label.new()
    _state_chip.add_theme_font_size_override("font_size", 12)
    _title_row.add_child(_state_chip)
    var _spacer: Control = Control.new()
    _spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _title_row.add_child(_spacer)
    var _close_btn: Button = _mk_btn("✕ 关闭", 78, 30, 13)
    _close_btn.pressed.connect(func(): close_page_sign.emit())
    _title_row.add_child(_close_btn)

    _stats_label = Label.new()
    _stats_label.text = "今日 +0 德里 · 累计 +0\n背包: 铜矿石 0 · 铜锭 0 · 木材 0"
    _stats_label.add_theme_font_size_override("font_size", 13)
    _stats_label.add_theme_color_override("font_color", MOD_C_DIM)
    _root.add_child(_stats_label)

    _warn_box = VBoxContainer.new()
    _warn_box.add_theme_constant_override("separation", 3)
    _root.add_child(_warn_box)

    var _main: HBoxContainer = HBoxContainer.new()
    _main.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _main.add_theme_constant_override("separation", 10)
    _root.add_child(_main)

    var _left: VBoxContainer = VBoxContainer.new()
    _left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _left.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _left.add_theme_constant_override("separation", 5)
    _main.add_child(_left)
    _furnace_hint = Label.new()
    _furnace_hint.text = "点某条熔炉列选中 · 底部滑条放料 · 右侧数字框取出"
    _furnace_hint.add_theme_font_size_override("font_size", 12)
    _furnace_hint.add_theme_color_override("font_color", MOD_C_DIM)
    _furnace_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _left.add_child(_furnace_hint)
    _legend_label = Label.new()
    _legend_label.text = "固定2个熔炉槽·升星扩容：白框=投入(铜矿石/铜锭) 绿框=木材燃料 金框=产出\n流程：铜矿石→烧成铜锭→取出→再投白框→烧成德里"
    _legend_label.add_theme_font_size_override("font_size", 12)
    _legend_label.add_theme_color_override("font_color", MOD_C_DIM)
    _legend_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _left.add_child(_legend_label)
    _grid = GridContainer.new()
    _grid.columns = 4
    _grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _grid.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _grid.add_theme_constant_override("h_separation", 6)
    _grid.add_theme_constant_override("v_separation", 6)
    _left.add_child(_grid)

    var _rp: PanelContainer = PanelContainer.new()
    _rp.custom_minimum_size = Vector2(200, 0)
    _rp.add_theme_stylebox_override("panel", _flat(MOD_C_CARD, MOD_C_BORDER, 1, 8))
    _main.add_child(_rp)
    var _rm: MarginContainer = MarginContainer.new()
    _rm.add_theme_constant_override("margin_left", 8)
    _rm.add_theme_constant_override("margin_right", 8)
    _rm.add_theme_constant_override("margin_top", 6)
    _rm.add_theme_constant_override("margin_bottom", 6)
    _rp.add_child(_rm)
    var _rv: VBoxContainer = VBoxContainer.new()
    _rv.add_theme_constant_override("separation", 6)
    _rm.add_child(_rv)
    var _rt: Label = Label.new()
    _rt.text = "数字取出(输入数量点[取], 空=全部)"
    _rt.add_theme_font_size_override("font_size", 12)
    _rt.add_theme_color_override("font_color", MOD_C_DIM)
    _rt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _rv.add_child(_rt)
    _take_ore_edit = _mk_edit()
    _take_ore_btn = _mk_small_btn("取", MOD_C_RED)
    _take_ore_btn.pressed.connect(_on_take_ore)
    _rv.add_child(_mk_take_row("取回投入的铜矿石", _take_ore_edit, _take_ore_btn))
    _take_ingot_edit = _mk_edit()
    _take_ingot_btn = _mk_small_btn("取", MOD_C_RED)
    _take_ingot_btn.pressed.connect(_on_take_ingot)
    _rv.add_child(_mk_take_row("取回投入的铜锭", _take_ingot_edit, _take_ingot_btn))
    _take_wood_edit = _mk_edit()
    _take_wood_btn = _mk_small_btn("取", MOD_C_RED)
    _take_wood_btn.pressed.connect(_on_take_wood)
    _rv.add_child(_mk_take_row("取回木材燃料", _take_wood_edit, _take_wood_btn))
    _take_prodingot_edit = _mk_edit()
    _take_prodingot_btn = _mk_small_btn("取", MOD_C_RED)
    _take_prodingot_btn.pressed.connect(_on_take_prodingot)
    _rv.add_child(_mk_take_row("取走炼好的铜锭", _take_prodingot_edit, _take_prodingot_btn))
    _take_money_edit = _mk_edit()
    _take_money_btn = _mk_small_btn("取", MOD_C_RED)
    _take_money_btn.pressed.connect(_on_take_money)
    _rv.add_child(_mk_take_row("取走铸成的德里", _take_money_edit, _take_money_btn))

    var _sl: VBoxContainer = VBoxContainer.new()
    _sl.add_theme_constant_override("separation", 6)
    _root.add_child(_sl)
    _ore_tag = _mk_tag_label("铜矿石放入", MOD_C_PURPLE)
    _ore_slider = _mk_slider()
    _ore_value = _mk_value_label()
    _ore_btn = _mk_small_btn("放入", MOD_C_PURPLE)
    _ore_btn.pressed.connect(_on_ore_put)
    _sl.add_child(_mk_slider_row(_ore_tag, _ore_slider, _ore_value, _ore_btn))
    _ingot_tag = _mk_tag_label("铜锭放入", MOD_C_ORANGE)
    _ingot_slider = _mk_slider()
    _ingot_value = _mk_value_label()
    _ingot_btn = _mk_small_btn("放入", MOD_C_ORANGE)
    _ingot_btn.pressed.connect(_on_ingot_put)
    _sl.add_child(_mk_slider_row(_ingot_tag, _ingot_slider, _ingot_value, _ingot_btn))
    _wood_tag = _mk_tag_label("木材放入", MOD_C_GREEN_AC)
    _wood_slider = _mk_slider()
    _wood_value = _mk_value_label()
    _wood_btn = _mk_small_btn("放入", MOD_C_GREEN_AC)
    _wood_btn.pressed.connect(_on_wood_put)
    _sl.add_child(_mk_slider_row(_wood_tag, _wood_slider, _wood_value, _wood_btn))

    _feedback_panel = PanelContainer.new()
    _feedback_panel.visible = false
    _feedback_panel.add_theme_stylebox_override("panel", _flat(Color(0.9, 0.84, 0.72), MOD_C_BORDER, 1, 6))
    _root.add_child(_feedback_panel)
    _feedback_label = Label.new()
    _feedback_label.add_theme_font_size_override("font_size", 13)
    _feedback_label.add_theme_color_override("font_color", MOD_C_TEXT)
    _feedback_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _feedback_panel.add_child(_feedback_label)


func _mk_tag_label(_text: String, _c: Color)-> Label:
    var _l: Label = Label.new()
    _l.text = _text
    _l.custom_minimum_size = Vector2(140, 0)
    _l.add_theme_font_size_override("font_size", 13)
    _l.add_theme_color_override("font_color", _c)
    _l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return _l


func _mk_value_label()-> Label:
    var _l: Label = Label.new()
    _l.text = "0"
    _l.custom_minimum_size = Vector2(30, 0)
    _l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    _l.add_theme_font_size_override("font_size", 13)
    _l.add_theme_color_override("font_color", MOD_C_TEXT)
    return _l


func _mk_slider()-> HSlider:
    var _s: HSlider = HSlider.new()
    _s.min_value = 0.0
    _s.max_value = 0.0
    _s.value = 0.0
    _s.step = 1.0
    _s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _s.custom_minimum_size = Vector2(0, 26)
    return _s


func _mk_slider_row(_tag: Label, _slider: HSlider, _value: Label, _btn: Button)-> HBoxContainer:
    var _row: HBoxContainer = HBoxContainer.new()
    _row.add_theme_constant_override("separation", 6)
    _row.add_child(_tag)
    _row.add_child(_slider)
    _row.add_child(_value)
    _row.add_child(_btn)
    _slider.value_changed.connect(_on_any_slider.bind(_value))
    return _row


func _on_any_slider(_v: float, _value_label: Label)-> void:
    _value_label.text = str(int(_v))


func _mk_edit()-> LineEdit:
    var _e: LineEdit = LineEdit.new()
    _e.placeholder_text = "空=全部"
    _e.custom_minimum_size = Vector2(0, 28)
    _e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _e.add_theme_font_size_override("font_size", 13)
    return _e


func _mk_take_row(_label_text: String, _edit: LineEdit, _btn: Button)-> VBoxContainer:
    var _box: VBoxContainer = VBoxContainer.new()
    _box.add_theme_constant_override("separation", 2)
    var _l: Label = Label.new()
    _l.text = _label_text
    _l.add_theme_font_size_override("font_size", 12)
    _l.add_theme_color_override("font_color", MOD_C_TEXT)
    _l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _box.add_child(_l)
    var _row: HBoxContainer = HBoxContainer.new()
    _row.add_theme_constant_override("separation", 6)
    _row.add_child(_edit)
    _row.add_child(_btn)
    _box.add_child(_row)
    return _box



func _flat(_bg: Color, _border: Color, _bw: int, _r: int)-> StyleBoxFlat:
    var _sb: StyleBoxFlat = StyleBoxFlat.new()
    _sb.bg_color = _bg
    _sb.border_color = _border
    _sb.set_border_width_all(_bw)
    _sb.set_corner_radius_all(_r)
    return _sb


func _mk_btn(_text: String, _w: int, _h: int, _fs: int)-> Button:
    var _btn: Button = Button.new()
    _btn.text = _text
    if _w > 0:
        _btn.custom_minimum_size = Vector2(_w, _h)
    else:
        _btn.custom_minimum_size = Vector2(0, _h)
    _btn.add_theme_font_size_override("font_size", _fs)
    _btn.add_theme_color_override("font_color", MOD_C_TEXT)
    _btn.add_theme_color_override("font_hover_color", MOD_C_TEXT)
    _btn.add_theme_color_override("font_pressed_color", MOD_C_TEXT)
    _btn.add_theme_stylebox_override("normal", _flat(Color(0.8, 0.72, 0.58), MOD_C_BORDER, 1, 6))
    _btn.add_theme_stylebox_override("hover", _flat(Color(0.86, 0.79, 0.66), MOD_C_BORDER, 1, 6))
    _btn.add_theme_stylebox_override("pressed", _flat(Color(0.86, 0.79, 0.66), MOD_C_BORDER, 2, 6))
    return _btn


func _mk_small_btn(_text: String, _c: Color)-> Button:
    var _btn: Button = Button.new()
    _btn.text = _text
    _btn.custom_minimum_size = Vector2(52, 28)
    _btn.add_theme_font_size_override("font_size", 13)
    _btn.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0))
    _btn.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 1.0))
    _btn.add_theme_color_override("font_pressed_color", Color(1.0, 1.0, 1.0))
    _btn.add_theme_stylebox_override("normal", _flat(_c, _c.darkened(0.25), 1, 6))
    _btn.add_theme_stylebox_override("hover", _flat(_c.lightened(0.1), _c.darkened(0.25), 1, 6))
    _btn.add_theme_stylebox_override("pressed", _flat(_c.lightened(0.1), _c.darkened(0.25), 2, 6))
    return _btn


func _mk_chip(_label: Label, _text: String, _c: Color)-> void:
    if _label == null:
        return
    _label.text = " " + _text + " "
    _label.add_theme_font_size_override("font_size", 12)
    _label.add_theme_color_override("font_color", _c)
    _label.add_theme_stylebox_override("normal", _flat(Color(_c.r, _c.g, _c.b, 0.14), _c, 1, 4))


func _mk_chip_label(_text: String, _c: Color)-> Label:
    var _label: Label = Label.new()
    _mk_chip(_label, _text, _c)
    return _label


func _fmt_money(_v: int)-> String:
    var _s: String = str(_v)
    var _out: String = ""
    var _count: int = 0
    for _i: int in range(_s.length() - 1, -1, -1):
        _out = _s[_i] + _out
        _count += 1
        if _count % 3 == 0 and _i > 0:
            _out = "," + _out
    return _out