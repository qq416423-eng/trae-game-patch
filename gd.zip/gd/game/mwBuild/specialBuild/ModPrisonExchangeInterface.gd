extends "res://gd/game/interface/soldier/TeamExchangeInterface.gd"


func init_by_location_code(_location_code: String)-> void:
    location_code = _location_code
    var max_nop: int = WSLocationData.get_prison_max_nop(_location_code)
    set_allow_nop(max_nop)

    init(WSData.get_capture(), WSLocationData.get_prison_capture_info(_location_code))
    _mod_fix_prison_titles()


func _mod_fix_prison_titles()-> void:
    if team_list_interface_node != null:
        team_list_interface_node.title = "俘虏管理"
        CommonUtils.set_text(team_list_interface_node.title_node, "俘虏管理")
        CommonUtils.set_text(team_list_interface_node.long_title_node, "俘虏管理")
    if barracks_list_interface_node != null:
        barracks_list_interface_node.title = "监狱"
        CommonUtils.set_text(barracks_list_interface_node.title_node, "监狱")
        CommonUtils.set_text(barracks_list_interface_node.long_title_node, "监狱")


func _on_save_button_pressed()-> void:
    if StringUtils.is_not_empty(location_code):
        WSData.update_capture(left_simple_json_list)
        WSLocationData.save_prison_capture_info(location_code, right_simple_json_list)
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_BARRACKS_TEAM_INFO_SUCCESS)
    _on_close_button_pressed()


func _on_equipment_info_and_transfer_func_interface_to_right_sign(_count: int)-> void:
    if CommonUtils.is_null(choose_node):
        return

    var _remain_nop: int = allow_nop - right_simple_json_list.size()

    if _remain_nop <= 0:
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.GARRISON_LIMIT_EXCEEDED)
        return

    if _remain_nop < _count:
        _count = _remain_nop
        GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.GARRISON_LIMIT_EXCEEDED)

    var _soldier_split_group_uid: = choose_node.get_split_group_uid()
    var _transfer_simple_json_list: Array = team_list_interface_node.pop_simple_json_list(_soldier_split_group_uid, _count, true)
    if ArrayUtils.is_empty(_transfer_simple_json_list):
        return

    ArrayUtils.remove_ele(left_simple_json_list, _transfer_simple_json_list)
    right_simple_json_list.append_array(_transfer_simple_json_list)
    _refresh(true, false)


func _on_equipment_info_and_transfer_func_interface_to_left_sign(_count: int)-> void:
    if CommonUtils.is_null(choose_node):
        return

    var _soldier_split_group_uid: = choose_node.get_split_group_uid()
    var _transfer_simple_json_list: Array = barracks_list_interface_node.pop_simple_json_list(_soldier_split_group_uid, _count, false)
    if ArrayUtils.is_empty(_transfer_simple_json_list):
        return

    ArrayUtils.remove_ele(right_simple_json_list, _transfer_simple_json_list)
    left_simple_json_list.append_array(_transfer_simple_json_list)
    _refresh(false, true)