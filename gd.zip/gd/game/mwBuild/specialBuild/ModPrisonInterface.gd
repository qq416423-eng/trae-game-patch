extends Control

signal close_page_sign

var _location_code: String = ""

var _left_scroll: ScrollContainer
var _left_vbox: VBoxContainer
var _right_scroll: ScrollContainer
var _right_vbox: VBoxContainer
var _title_label: Label
var _capacity_label: Label
var _message_label: Label
var _all_in_button: Button
var _close_button: Button


var _player_groups: Dictionary = {}

var _prison_groups: Dictionary = {}

static var _shared_panel_style: StyleBoxFlat
static var _shared_list_style: StyleBoxFlat


func _ready()-> void:
    _build_ui()


func _get_panel_style()-> StyleBoxFlat:
    if _shared_panel_style == null:
        _shared_panel_style = StyleBoxFlat.new()
        _shared_panel_style.bg_color = Color(0.82, 0.72, 0.55, 0.92)
        _shared_panel_style.border_width_left = 3
        _shared_panel_style.border_width_right = 3
        _shared_panel_style.border_width_top = 3
        _shared_panel_style.border_width_bottom = 3
        _shared_panel_style.border_color = Color(0.4, 0.3, 0.15, 1.0)
    return _shared_panel_style


func _get_list_style()-> StyleBoxFlat:
    if _shared_list_style == null:
        _shared_list_style = StyleBoxFlat.new()
        _shared_list_style.bg_color = Color(0.75, 0.65, 0.48, 0.85)
        _shared_list_style.border_width_left = 2
        _shared_list_style.border_width_right = 2
        _shared_list_style.border_width_top = 2
        _shared_list_style.border_width_bottom = 2
        _shared_list_style.border_color = Color(0.35, 0.28, 0.15, 0.8)
    return _shared_list_style


func _build_ui()-> void:
    set_anchors_preset(PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP

    var _vp = get_viewport_rect().size

    var _bg = ColorRect.new()
    _bg.color = Color(0.86, 0.78, 0.62, 0.95)
    _bg.set_anchors_preset(PRESET_FULL_RECT)
    add_child(_bg)

    var _root = Panel.new()
    _root.set_anchors_preset(PRESET_FULL_RECT)
    _root.add_theme_stylebox_override("panel", _get_panel_style())
    add_child(_root)


    _title_label = Label.new()
    _title_label.add_theme_font_size_override("font_size", 28)
    _title_label.add_theme_color_override("font_color", Color(0.3, 0.2, 0.05))
    _title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _title_label.position = Vector2(0, 20)
    _title_label.size = Vector2(_vp.x, 50)
    _title_label.text = "监狱"
    _root.add_child(_title_label)


    _capacity_label = Label.new()
    _capacity_label.add_theme_font_size_override("font_size", 18)
    _capacity_label.add_theme_color_override("font_color", Color(0.35, 0.2, 0.05))
    _capacity_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _capacity_label.position = Vector2(0, 70)
    _capacity_label.size = Vector2(_vp.x, 30)
    _root.add_child(_capacity_label)

    var _col_w: float = _vp.x * 0.42
    var _col_h: float = _vp.y - 280
    var _left_x: float = _vp.x * 0.04
    var _right_x: float = _vp.x * 0.54


    var _left_title = Label.new()
    _left_title.text = "俘虏管理（玩家俘虏）"
    _left_title.add_theme_font_size_override("font_size", 20)
    _left_title.add_theme_color_override("font_color", Color(0.25, 0.15, 0.05))
    _left_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _left_title.position = Vector2(_left_x, 105)
    _left_title.size = Vector2(_col_w, 30)
    _root.add_child(_left_title)


    _left_scroll = ScrollContainer.new()
    _left_scroll.position = Vector2(_left_x, 140)
    _left_scroll.size = Vector2(_col_w, _col_h)
    _left_scroll.add_theme_stylebox_override("panel", _get_list_style())
    _root.add_child(_left_scroll)

    _left_vbox = VBoxContainer.new()
    _left_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _left_vbox.add_theme_constant_override("separation", 6)
    _left_scroll.add_child(_left_vbox)


    var _right_title = Label.new()
    _right_title.text = "监狱关押"
    _right_title.add_theme_font_size_override("font_size", 20)
    _right_title.add_theme_color_override("font_color", Color(0.25, 0.15, 0.05))
    _right_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _right_title.position = Vector2(_right_x, 105)
    _right_title.size = Vector2(_col_w, 30)
    _root.add_child(_right_title)


    _right_scroll = ScrollContainer.new()
    _right_scroll.position = Vector2(_right_x, 140)
    _right_scroll.size = Vector2(_col_w, _col_h)
    _right_scroll.add_theme_stylebox_override("panel", _get_list_style())
    _root.add_child(_right_scroll)

    _right_vbox = VBoxContainer.new()
    _right_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _right_vbox.add_theme_constant_override("separation", 6)
    _right_scroll.add_child(_right_vbox)


    _message_label = Label.new()
    _message_label.add_theme_font_size_override("font_size", 18)
    _message_label.add_theme_color_override("font_color", Color(0.4, 0.15, 0.05))
    _message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _message_label.position = Vector2(0, _vp.y - 115)
    _message_label.size = Vector2(_vp.x, 30)
    _message_label.text = ""
    _root.add_child(_message_label)


    _all_in_button = Button.new()
    _all_in_button.text = "全部存入监狱"
    _all_in_button.add_theme_font_size_override("font_size", 20)
    _all_in_button.custom_minimum_size = Vector2(220, 55)
    _all_in_button.position = Vector2(_vp.x * 0.28, _vp.y - 70)
    _all_in_button.size = Vector2(220, 55)
    _all_in_button.pressed.connect(_on_all_in_pressed)
    _root.add_child(_all_in_button)


    _close_button = Button.new()
    _close_button.text = "关闭"
    _close_button.add_theme_font_size_override("font_size", 20)
    _close_button.custom_minimum_size = Vector2(160, 55)
    _close_button.position = Vector2(_vp.x * 0.55, _vp.y - 70)
    _close_button.size = Vector2(160, 55)
    _close_button.pressed.connect(_on_close_pressed)
    _root.add_child(_close_button)



func init_by_location_code(_code: String)-> void:
    _location_code = _code



func _get_group_name(_uid: String, _list: Array)-> String:
    if _list.is_empty():
        return str(_uid)
    var _first: Dictionary = _list[0]
    if SoldierUtils.is_hero_by_simple_json(_first):
        var _hero_json: Dictionary = SoldierUtils.get_hero_json(_uid)
        if not _hero_json.is_empty() and _hero_json.has("name"):
            return _hero_json.name

    var _prop = SoldierUtils.get_bs_soldier_prop(_first)
    if _prop != null:
        return _prop.name
    return str(_uid)



func _group_by_uid(_list: Array)-> Dictionary:
    var _groups: Dictionary = {}
    for _simple_json in _list:
        if not(_simple_json is Dictionary):
            continue
        var _uid = _simple_json.get("uid", "")
        if _uid == "":
            continue
        if not _groups.has(_uid):
            _groups[_uid] = []
        _groups[_uid].append(_simple_json)
    return _groups



func _get_prison_count()-> int:
    return WSLocationData.get_prison_capture_info(_location_code).size()


func _refresh()-> void:
    for _child in _left_vbox.get_children():
        _child.queue_free()
    for _child in _right_vbox.get_children():
        _child.queue_free()

    _player_groups = _group_by_uid(WSData.get_capture())
    _prison_groups = _group_by_uid(WSLocationData.get_prison_capture_info(_location_code))

    var _max_nop: int = WSLocationData.get_prison_max_nop(_location_code)
    _capacity_label.text = "监狱容量: " + str(_get_prison_count()) + " / " + str(_max_nop)


    if _player_groups.is_empty():
        var _empty = Label.new()
        _empty.text = "没有俘虏"
        _empty.add_theme_font_size_override("font_size", 16)
        _empty.add_theme_color_override("font_color", Color(0.3, 0.25, 0.1))
        _empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        _left_vbox.add_child(_empty)
    else:
        for _uid in _player_groups.keys():
            _left_vbox.add_child(_make_row(_uid, _player_groups[_uid], true))


    if _prison_groups.is_empty():
        var _empty = Label.new()
        _empty.text = "监狱空置"
        _empty.add_theme_font_size_override("font_size", 16)
        _empty.add_theme_color_override("font_color", Color(0.3, 0.25, 0.1))
        _empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        _right_vbox.add_child(_empty)
    else:
        for _uid in _prison_groups.keys():
            _right_vbox.add_child(_make_row(_uid, _prison_groups[_uid], false))




func _make_row(_uid: String, _list: Array, _is_player_side: bool)-> HBoxContainer:
    var _row = HBoxContainer.new()
    _row.custom_minimum_size = Vector2(0, 46)
    _row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _row.add_theme_constant_override("separation", 6)

    var _name = _get_group_name(_uid, _list)
    var _count: int = _list.size()

    var _label = Label.new()
    _label.text = _name + " ×" + str(_count)
    _label.add_theme_font_size_override("font_size", 16)
    _label.custom_minimum_size = Vector2(160, 40)
    _label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _row.add_child(_label)

    var _spinbox = SpinBox.new()
    _spinbox.min_value = 0
    _spinbox.max_value = _count
    _spinbox.value = _count
    _spinbox.custom_minimum_size = Vector2(80, 40)
    _row.add_child(_spinbox)

    var _btn = Button.new()
    if _is_player_side:
        _btn.text = "存入"
    else:
        _btn.text = "带回"
    _btn.add_theme_font_size_override("font_size", 16)
    _btn.custom_minimum_size = Vector2(70, 40)
    _btn.pressed.connect(_on_transfer.bind(_uid, _is_player_side, _spinbox))
    _row.add_child(_btn)

    return _row



func _on_transfer(_uid: String, _is_player_side: bool, _spinbox: SpinBox)-> void:
    var _n: int = int(_spinbox.value)
    if _n <= 0:
        _message_label.text = "数量需大于0"
        _message_label.add_theme_color_override("font_color", Color(0.6, 0.2, 0.1))
        return

    if _is_player_side:

        var _max_nop: int = WSLocationData.get_prison_max_nop(_location_code)
        var _prison_now: int = _get_prison_count()
        var _available: int = _max_nop - _prison_now
        if _available <= 0:
            _message_label.text = "监狱已满，无法关押更多俘虏"
            _message_label.add_theme_color_override("font_color", Color(0.6, 0.2, 0.1))
            return
        _n = min(_n, _available)
        _move_player_to_prison(_uid, _n)
        _message_label.text = "已存入 " + str(_n) + " 名俘虏到监狱"
        _message_label.add_theme_color_override("font_color", Color(0.1, 0.4, 0.1))
    else:

        _move_prison_to_player(_uid, _n)
        _message_label.text = "已带回 " + str(_n) + " 名俘虏"
        _message_label.add_theme_color_override("font_color", Color(0.1, 0.4, 0.1))

    _refresh()



func _move_player_to_prison(_uid: String, _n: int)-> void:
    var _player_capture: Array = WSData.get_capture()
    var _prison_capture: Array = WSLocationData.get_prison_capture_info(_location_code)

    var _moved: Array = []
    var _moved_count: int = 0

    for _i in range(_player_capture.size() - 1, -1, -1):
        if _moved_count >= _n:
            break
        var _sj = _player_capture[_i]
        if _sj is Dictionary and _sj.get("uid", "") == _uid:
            _moved.append(_sj)
            _player_capture.remove_at(_i)
            _moved_count += 1

    if not _moved.is_empty():
        _prison_capture.append_array(_moved)
        WSData.update_capture(_player_capture)
        WSLocationData.save_prison_capture_info(_location_code, _prison_capture)



func _move_prison_to_player(_uid: String, _n: int)-> void:
    var _player_capture: Array = WSData.get_capture()
    var _prison_capture: Array = WSLocationData.get_prison_capture_info(_location_code)

    var _moved: Array = []
    var _moved_count: int = 0
    for _i in range(_prison_capture.size() - 1, -1, -1):
        if _moved_count >= _n:
            break
        var _sj = _prison_capture[_i]
        if _sj is Dictionary and _sj.get("uid", "") == _uid:
            _moved.append(_sj)
            _prison_capture.remove_at(_i)
            _moved_count += 1

    if not _moved.is_empty():
        _player_capture.append_array(_moved)
        WSData.update_capture(_player_capture)
        WSLocationData.save_prison_capture_info(_location_code, _prison_capture)



func _on_all_in_pressed()-> void:
    var _player_capture: Array = WSData.get_capture()
    if _player_capture.is_empty():
        _message_label.text = "没有俘虏可存入"
        _message_label.add_theme_color_override("font_color", Color(0.6, 0.2, 0.1))
        return

    var _max_nop: int = WSLocationData.get_prison_max_nop(_location_code)
    var _prison_now: int = _get_prison_count()
    var _available: int = _max_nop - _prison_now
    if _available <= 0:
        _message_label.text = "监狱已满，无法关押更多俘虏"
        _message_label.add_theme_color_override("font_color", Color(0.6, 0.2, 0.1))
        return


    var _to_move: Array = []
    for _i in range(_player_capture.size() - 1, -1, -1):
        if _to_move.size() >= _available:
            break
        _to_move.append(_player_capture[_i])
        _player_capture.remove_at(_i)

    if not _to_move.is_empty():
        var _prison_capture: Array = WSLocationData.get_prison_capture_info(_location_code)
        _prison_capture.append_array(_to_move)
        WSData.update_capture(_player_capture)
        WSLocationData.save_prison_capture_info(_location_code, _prison_capture)
        _message_label.text = "已存入 " + str(_to_move.size()) + " 名俘虏到监狱"
        _message_label.add_theme_color_override("font_color", Color(0.1, 0.4, 0.1))
    _refresh()


func _on_close_pressed()-> void:
    hide_interface()
    close_page_sign.emit()


func show_interface()-> void:
    visible = true
    _message_label.text = ""
    _refresh()


func hide_interface()-> void:
    visible = false