extends Control

signal close_page_sign
signal interact_with_charactar_sign(_npc_info: Dictionary)

const HERO_UID: = "mod_village_blacksmith"
const NPC_NAME: = "铁匠"
const PORTRAIT_PATH: = "res://resource/portrait/unknow_male.png"

var _npc_card: Panel
var _npc_portrait: TextureRect
var _npc_name_label: Label
var _npc_button: Button
var _close_button: Button


func _ready()-> void:
    _build_ui()


func _build_ui()-> void:
    set_anchors_preset(PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP


    var _bg: = ColorRect.new()
    _bg.color = Color(0, 0, 0, 0.6)
    _bg.set_anchors_preset(PRESET_FULL_RECT)
    add_child(_bg)


    var _root_panel = Panel.new()
    _root_panel.set_anchors_preset(PRESET_FULL_RECT)
    _root_panel.add_theme_stylebox_override("panel", _create_panel_style())
    add_child(_root_panel)

    var _viewport_size = get_viewport_rect().size


    _npc_card = Panel.new()
    _npc_card.custom_minimum_size = Vector2(200, 280)
    _npc_card.add_theme_stylebox_override("panel", _create_card_style())

    var _card_x = _viewport_size.x * 0.5 - 100
    var _card_y = _viewport_size.y * 0.25
    _npc_card.position = Vector2(_card_x, _card_y)
    _npc_card.size = Vector2(200, 280)
    _root_panel.add_child(_npc_card)


    _npc_portrait = TextureRect.new()
    _npc_portrait.texture = load(PORTRAIT_PATH)
    _npc_portrait.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
    _npc_portrait.position = Vector2(35, 20)
    _npc_portrait.size = Vector2(130, 160)
    _npc_card.add_child(_npc_portrait)


    _npc_name_label = Label.new()
    _npc_name_label.text = NPC_NAME
    _npc_name_label.add_theme_font_size_override("font_size", 22)
    _npc_name_label.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
    _npc_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _npc_name_label.position = Vector2(0, 190)
    _npc_name_label.size = Vector2(200, 40)
    _npc_card.add_child(_npc_name_label)


    _npc_button = Button.new()
    _npc_button.text = ""
    _npc_button.position = Vector2(0, 0)
    _npc_button.size = Vector2(200, 280)
    _npc_button.add_theme_stylebox_override("normal", _create_transparent_style())
    _npc_button.add_theme_stylebox_override("hover", _create_transparent_style())
    _npc_button.add_theme_stylebox_override("pressed", _create_transparent_style())
    _npc_button.add_theme_stylebox_override("focus", _create_transparent_style())
    _npc_button.pressed.connect(_on_npc_card_pressed)
    _npc_card.add_child(_npc_button)


    _close_button = Button.new()
    _close_button.text = "×"
    _close_button.add_theme_font_size_override("font_size", 36)
    _close_button.custom_minimum_size = Vector2(60, 60)
    _close_button.position = Vector2(_viewport_size.x - 80, 20)
    _close_button.size = Vector2(60, 60)
    _close_button.pressed.connect(_on_close_button_pressed)
    _root_panel.add_child(_close_button)


func show_interface()-> void:
    visible = true


func hide_interface()-> void:
    visible = false


func _on_npc_card_pressed()-> void:
    var _npc_info: Dictionary = {
        "npc_uid": HERO_UID,
        "func_type": "",
        "npc_name": NPC_NAME,
    }
    interact_with_charactar_sign.emit(_npc_info)


func _on_close_button_pressed()-> void:
    hide_interface()
    close_page_sign.emit()




func _create_panel_style()-> StyleBoxFlat:
    var _style = StyleBoxFlat.new()
    _style.bg_color = Color(0.12, 0.1, 0.08, 0.95)
    _style.border_width_left = 4
    _style.border_width_right = 4
    _style.border_width_top = 4
    _style.border_width_bottom = 4
    _style.border_color = Color(0.5, 0.4, 0.2, 1.0)
    _style.corner_radius_top_left = 12
    _style.corner_radius_top_right = 12
    _style.corner_radius_bottom_left = 12
    _style.corner_radius_bottom_right = 12
    return _style


func _create_card_style()-> StyleBoxFlat:
    var _style = StyleBoxFlat.new()
    _style.bg_color = Color(0.15, 0.13, 0.1, 1.0)
    _style.border_width_left = 2
    _style.border_width_right = 2
    _style.border_width_top = 2
    _style.border_width_bottom = 2
    _style.border_color = Color(0.4, 0.35, 0.2, 0.8)
    _style.corner_radius_top_left = 8
    _style.corner_radius_top_right = 8
    _style.corner_radius_bottom_left = 8
    _style.corner_radius_bottom_right = 8
    return _style


func _create_transparent_style()-> StyleBoxEmpty:
    return StyleBoxEmpty.new()