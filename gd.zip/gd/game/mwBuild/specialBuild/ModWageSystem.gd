extends RefCounted







func pay_facility_extra_wage(_money_before_wage: int, _lm_workers: Array, _mine_workers: Array)-> Dictionary:
    var _result: Dictionary = {
        "paid": false,
        "extra": 0,
        "count": 0,
        "lm_count": 0,
        "mine_count": 0,
        "original_wage": 0,
        "reason": "",
    }

    var _interval: int = TeamConfig.WAGES_INTERVAL_DAYS
    if int(WSData.system_counter) % _interval != 0:
        _result["reason"] = "not_wage_day"
        return _result


    var _money_after: int = WSData.get_player_money()
    var _original_wage: int = _money_before_wage - _money_after
    _result["original_wage"] = _original_wage

    if _original_wage <= 0:
        _result["reason"] = "no_original_wage"
        return _result


    var _lm_count: int = 0
    var _mine_count: int = 0
    for _worker in _lm_workers:
        if not bool(_worker.get("is_prisoner", false)):
            _lm_count += 1
    for _worker in _mine_workers:
        if not bool(_worker.get("is_prisoner", false)):
            _mine_count += 1
    var _facility_count: int = _lm_count + _mine_count
    _result["count"] = _facility_count
    _result["lm_count"] = _lm_count
    _result["mine_count"] = _mine_count

    if _facility_count == 0:
        _result["reason"] = "no_facility_soldiers"
        return _result


    var _team_count: int = WSData.player_data.team.size()
    var _facility_base_wage: int = 0


    const _WAGE_FALLBACK_THRESHOLD: int = 3
    if _team_count > _WAGE_FALLBACK_THRESHOLD:

        var _per_soldier_wage: float = float(_original_wage) / float(_team_count)
        _facility_base_wage = int(_per_soldier_wage * float(_facility_count))
    else:


        _facility_base_wage = _estimate_facility_wage_by_star(_lm_workers, _mine_workers)



    var _extra: int = int(float(_facility_base_wage) * 1.2)
    _result["extra"] = _extra

    if _extra <= 0:
        _result["reason"] = "zero_extra"
        return _result


    var _player_money: int = WSData.get_player_money()
    if _player_money < _extra:
        _result["reason"] = "insufficient_money"
        return _result

    WSData.update_money(- _extra, false)
    _result["paid"] = true
    print("[MapMod] 设施工人军饷: count=", _facility_count, " extra=", _extra, " original_wage=", _original_wage)
    return _result




func _estimate_facility_wage_by_star(_lm_workers: Array, _mine_workers: Array)-> int:
    var _interval: int = TeamConfig.WAGES_INTERVAL_DAYS
    var _total: int = 0
    for _worker in _lm_workers:
        if not bool(_worker.get("is_prisoner", false)):
            _total += _get_base_daily_wage_by_star(_worker_star(_worker))
    for _worker in _mine_workers:
        if not bool(_worker.get("is_prisoner", false)):
            _total += _get_base_daily_wage_by_star(_worker_star(_worker))
    return _total * _interval



func _worker_star(_worker: Dictionary)-> int:
    if _worker.has("star"):
        var _s: int = int(_worker["star"])
        if _s > 0:
            return _s
    var _cfg: Dictionary = SoldierUtils.get_json_by_uid(str(_worker.get("uid", "")))
    if not _cfg.is_empty() and _cfg.has("star"):
        return clampi(int(_cfg["star"]), 1, 5)
    return 1



func _get_base_daily_wage_by_star(_star: int)-> int:
    match _star:
        1: return 10
        2: return 15
        3: return 25
        4: return 40
        5: return 60
        _: return 10




func show_wage_message(_result: Dictionary)-> void:
    if not _result.get("paid", false):
        var _reason: String = _result.get("reason", "")
        if _reason == "insufficient_money":
            _show_msg("金币不足支付设施工人军饷!\n工人士气可能下降", false)

        return
    var _extra: int = int(_result.get("extra", 0))
    var _count: int = int(_result.get("count", 0))
    var _msg: String = "设施工人军饷(" + str(_count) + "名士兵, 比随行多20%)\n"
    _msg += "伐木场: " + str(_result.get("lm_count", 0)) + "人  "
    _msg += "采矿场: " + str(_result.get("mine_count", 0)) + "人\n"
    _msg += "扣除: " + str(_extra) + "金币"
    _show_msg(_msg, false)



func _show_msg(_content: String, _is_success: bool)-> void:
    print("[MapMod] ", _content)
    var _message_info: Dictionary = {
        "content": _content,
        "message_type": MessageConstants.MESSAGE_TYPE_ENUM.SUCCESS if _is_success else MessageConstants.MESSAGE_TYPE_ENUM.WARN,
        "color": MessageConstants.MESSAGE_COLOR_ENUM.SUCCESS if _is_success else MessageConstants.MESSAGE_COLOR_ENUM.DANGER,
    }
    if GlobalMessageInterface != null:
        GlobalMessageInterface.message_list.append(_message_info)