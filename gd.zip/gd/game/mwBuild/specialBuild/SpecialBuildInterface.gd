class_name SpecialBuildInterface extends Control

@onready var special_build_root_node: Control =$SpecialBuildRoot
@onready var location_character_card_list_node: LocationCharacterCardList =$LocationCharacterCardList
@onready var flag_icon_node: TextureRect =$FlagRoot / FlagIcon

signal close_page_sign()
signal interact_with_charactar_sign(_npc_info: Dictionary)
signal view_soldier_info_sign(_uid: String)

func init(
    _location_code: String,
    _location_type_enum: String,
    _special_build_node_name: String)-> void:

    if _special_build_node_name != "":
        var _node_pre: = load("res://tscn/game/mwBuild/specialBuild/" + _special_build_node_name + ".tscn")
        special_build_root_node.add_child(_node_pre.instantiate())


    var npc_info_list: Array
    if _location_type_enum == LocationConstants.CITY_LOCATION_TYPE_ENUM.MOD_VILLAGE_HALL:
        npc_info_list = [
            {
                "npc_uid": "mod_blacksmith_armour",
                "func_type": "",
                "npc_name": "盔甲铁匠",
                "hide_portrait": true,
                "mod_forge_type": "ARMOUR",
            },
            {
                "npc_uid": "mod_blacksmith_weapon",
                "func_type": "",
                "npc_name": "武器铁匠",
                "hide_portrait": true,
                "mod_forge_type": "WEAPON",
            },
            {
                "npc_uid": "mod_blacksmith_harmour",
                "func_type": "",
                "npc_name": "马铠铁匠",
                "hide_portrait": true,
                "mod_forge_type": "HARMOUR",
            },
            {
                "npc_uid": "mod_quartermaster",
                "func_type": "",
                "npc_name": "军需人员",
                "hide_portrait": true,
                "mod_is_quartermaster": true,
            },
        ]
    else:
        npc_info_list = WSLocationData.get_npc_info_list(_location_code, _location_type_enum)

        if _location_type_enum == LocationConstants.CITY_LOCATION_TYPE_ENUM.TAVERN:
            npc_info_list.append({
                "npc_uid": "mod_gambler",
                "func_type": "",
                "npc_name": "赌徒老鬼",
                "hide_portrait": true,
            })

            npc_info_list.append({
                "npc_uid": "mod_appraiser",
                "func_type": "",
                "npc_name": "赌物人",
                "hide_portrait": true,
            })

    location_character_card_list_node.init_by_npc_info(npc_info_list)
    var _config: = LocationConstants.get_city_location_type_config(_location_type_enum)
    if _config != null and not _config.is_empty() and _config.has("icon"):
        CommonUtils.update_texture2(flag_icon_node, _config.icon)

    if _location_type_enum == LocationConstants.CITY_LOCATION_TYPE_ENUM.MOD_VILLAGE_HALL:
        _mod_fix_title_text(_config.button_name)

func chide()-> void:
    self.hide()
    _clear()

func unchoose_charactar_card()-> void:
    location_character_card_list_node.unchoose()

func _clear()-> void:
    CommonUtils.clear_node(special_build_root_node)

func _on_close_button_pressed()-> void:
    self.chide()
    close_page_sign.emit()


func _mod_fix_title_text(_correct_text: String)-> void:
    _mod_find_and_fix_labels(self, _correct_text)

func _mod_find_and_fix_labels(_node: Node, _correct_text: String)-> void:
    if _node is Label:
        var _label: Label = _node
        if _label.text == "酒馆" or _label.text == "Tavern":
            _label.text = _correct_text
    for _child in _node.get_children():
        _mod_find_and_fix_labels(_child, _correct_text)




func _on_location_character_card_list_choose_sign(_npc_info: Dictionary)-> void:
    interact_with_charactar_sign.emit(_npc_info)

func _on_location_character_card_list_view_soldier_info_sign(_uid: String)-> void:
    view_soldier_info_sign.emit(_uid)