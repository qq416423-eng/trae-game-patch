class_name Avatar extends Node2D

@onready var body_node =$Body
@onready var hair_node =$Hair
@onready var armour_node =$Armour
@onready var helmet_node =$Helmet

func init_by_json(_json: Dictionary)-> void:
    var _bs_soldier_prop: = SoldierUtils.get_bs_soldier_prop_by_json(_json)
    init(_bs_soldier_prop)

func init_by_uid(_uid: String)-> void:
    var _bs_soldier_prop: = SoldierUtils.get_bs_soldier_prop_by_uid(_uid)
    init(_bs_soldier_prop)

func init(_bs_soldier_prop: BSSoldierProp)-> void:
    CommonUtils.update_texture(body_node, _bs_soldier_prop.body_json)
    CommonUtils.update_texture(hair_node, _bs_soldier_prop.hair_json)
    CommonUtils.update_texture(armour_node, _bs_soldier_prop.armour_json)
    CommonUtils.update_texture(helmet_node, _bs_soldier_prop.helmet_json)

    if not GlobalPlayerConfig.is_show_hero_helmet_in_battle_scene \
    and SoldierUtils.is_hero_by_soldier_prop(_bs_soldier_prop):
        helmet_node.hide()
    else:
        helmet_node.show()

func init_hair_by_simple_json(_simple_json):
    var _json = GoodsUtils.get_json_by_simple_json(_simple_json)
    CommonUtils.update_texture(hair_node, _json)

func init_body_by_simple_json(_simple_json):
    var _json = GoodsUtils.get_json_by_simple_json(_simple_json)
    CommonUtils.update_texture(body_node, _json)

func update_hair_color(_color: Color)-> void:
    CommonUtils.update_self_color(hair_node, _color)

func update_body_color(_color: Color)-> void:
    CommonUtils.update_self_color(body_node, _color)