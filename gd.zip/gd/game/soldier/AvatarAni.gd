class_name AvatarAni extends Node2D

@onready var shape_node =$Shape
@onready var horse_node =$Shape / Horse
@onready var shadow_node =$Shape / Shadow
@onready var body_node =$Shape / Body
@onready var hair_node =$Shape / Hair
@onready var armour_node =$Shape / Armour
@onready var helmet_node =$Shape / Helmet
@onready var vice_weapon_node =$Shape / ViceWeapon
@onready var main_weapon_node =$Shape / MainWeapon
@onready var action_animation_node =$ActionAnimation
@onready var animation_timer_node =$ActionAnimation / AnimationTimer
@onready var b_shield_node =$Shape / BShield
@onready var harmour_node =$Shape / Harmour

var bs_soldier_prop: BSSoldierProp
var origin_shape_position
var shadow_texture_path
var animation_list = [BSSoldierConstants.ANIMATION_NAME_ENUM.IDLE, BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE]
var current_animation_index = 0
var horse_origin_position_y: = 0.0

signal play_animation_sign(_animation_name)

func _ready():
    origin_shape_position = shape_node.position
    shadow_texture_path = shadow_node.texture.get_path()
    horse_origin_position_y = horse_node.position.y

func init(_soldier_prop: BSSoldierProp, _play_animation: = true)-> void:
    bs_soldier_prop = _soldier_prop


    _handle_cavalry_sprite()
    _init_body_skin()
    _init_weapon_skin()

    if _play_animation:

        _play_animation(current_animation_index)
        if animation_timer_node.is_stopped():

            animation_timer_node.start()

func init_by_uid(_uid: String)-> void:
    var _soldier_prop: BSSoldierProp = SoldierUtils.get_bs_soldier_prop_by_uid(_uid)
    init(_soldier_prop)

func is_cavalry()-> bool:
    return SoldierUtils.is_cavalry(bs_soldier_prop)

func get_uid()-> String:
    return bs_soldier_prop.uid

func play_animation()-> void:

    _play_animation(current_animation_index)
    if animation_timer_node.is_stopped():

        animation_timer_node.start()

func animation_stop():
    current_animation_index = 0
    _play_animation(current_animation_index)
    action_animation_node.stop()
    animation_timer_node.stop()

func _play_animation(_animation_index):
    current_animation_index = _animation_index % animation_list.size()
    var _animation_name_enum = animation_list[current_animation_index]


    var _animation_name: String = _animation_name_enum.animation_name
    var _is_need_random_frame = false

    if["idle", "move"].has(_animation_name):
        _is_need_random_frame = true

    if SoldierUtils.is_cavalry(bs_soldier_prop):
        _animation_name = _animation_name_enum.h_animation_name

    if action_animation_node.current_animation == _animation_name:
        _is_need_random_frame = false

    action_animation_node.play(_animation_name)
    play_animation_sign.emit(_animation_name)

func _handle_cavalry_sprite():
    horse_node.position.y = horse_origin_position_y
    harmour_node.position.y = horse_origin_position_y
    var _vframes = BSSoldierConstants.INFANTRY_SPRITE_CONFIG.vframe
    if bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.INFANTRY:
        shape_node.position = origin_shape_position
        horse_node.hide()
        harmour_node.hide()
        CommonUtils.update_texture2(shadow_node, shadow_texture_path)
    else:

        _vframes = BSSoldierConstants.CAVALRY_SPRITE_CONFIG.vframe


        var _position_update = BSSoldierConstants.CAVALRY_SPRITE_CONFIG.position_update + Vector2(0, - bs_soldier_prop.character_y_plus)
        shape_node.position = origin_shape_position + _position_update
        horse_node.show()
        if bs_soldier_prop.is_harmour_match:
            harmour_node.show()
        else:
            harmour_node.hide()

        if bs_soldier_prop.character_y_plus != 0:
            horse_node.position.y += bs_soldier_prop.character_y_plus
            harmour_node.position.y += bs_soldier_prop.character_y_plus


        CommonUtils.update_texture2(shadow_node, SoldierPartUtils.get_cavalry_t_path(shadow_texture_path))

    body_node.vframes = _vframes
    hair_node.vframes = _vframes
    armour_node.vframes = _vframes
    helmet_node.vframes = _vframes
    vice_weapon_node.vframes = _vframes
    main_weapon_node.vframes = _vframes
    horse_node.vframes = _vframes
    harmour_node.vframes = _vframes

func _init_body_skin():
    CommonUtils.update_texture(body_node, bs_soldier_prop.body_json)
    CommonUtils.update_texture(hair_node, bs_soldier_prop.hair_json)
    CommonUtils.update_texture(armour_node, bs_soldier_prop.armour_json)
    CommonUtils.update_texture(helmet_node, bs_soldier_prop.helmet_json)
    CommonUtils.update_texture(horse_node, bs_soldier_prop.horse_json)
    CommonUtils.update_texture(harmour_node, bs_soldier_prop.harmour_json)

    if not GlobalPlayerConfig.is_show_hero_helmet_in_battle_scene \
    and SoldierUtils.is_hero_by_soldier_prop(bs_soldier_prop):
        helmet_node.hide()
    else:
        helmet_node.show()

func _init_weapon_skin():
    CommonUtils.update_texture(main_weapon_node, bs_soldier_prop.main_weapon_json)
    CommonUtils.update_texture(vice_weapon_node, bs_soldier_prop.vice_weapon_json)

    if bs_soldier_prop.b_vice_weapon_json != null:
        CommonUtils.update_texture(b_shield_node, bs_soldier_prop.b_vice_weapon_json, "bs_t_path")
        b_shield_node.show()
    else:
        b_shield_node.hide()


func _on_animation_timer_timeout():
    _play_animation(current_animation_index + 1)