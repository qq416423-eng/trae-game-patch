class_name AvatarWB extends Node2D

@onready var horse_node =$Horse
@onready var body_node =$Body
@onready var hair_node =$Hair
@onready var armour_node =$Armour
@onready var helmet_node =$Helmet
@onready var vice_weapon_node =$ViceWeapon
@onready var main_weapon_node =$MainWeapon
@onready var b_shield_node =$BShield
@onready var harmour_node =$Harmour

var bs_soldier_prop: BSSoldierProp

func init(_soldier_prop: BSSoldierProp):
    bs_soldier_prop = _soldier_prop


    _handle_cavalry_sprite()

    _init_body_skin()
    _init_weapon_skin()

func _handle_cavalry_sprite():
    if bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.INFANTRY:
        pass
    else:
        horse_node.show()
        if bs_soldier_prop.is_harmour_match:
            harmour_node.show()
        else:
            harmour_node.hide()

func _init_body_skin():
    CommonUtils.update_texture(body_node, bs_soldier_prop.body_json)
    CommonUtils.update_texture(hair_node, bs_soldier_prop.hair_json)
    CommonUtils.update_texture(armour_node, bs_soldier_prop.armour_json)
    CommonUtils.update_texture(helmet_node, bs_soldier_prop.helmet_json)
    CommonUtils.update_texture(horse_node, bs_soldier_prop.horse_json)
    CommonUtils.update_texture(harmour_node, bs_soldier_prop.harmour_json)

    if not GlobalPlayerConfig.is_show_hero_helmet_in_battle_scene \
    and SoldierUtils.is_hero_by_soldier_prop(bs_soldier_prop):
        helmet_node.hide()
    else:
        helmet_node.show()

    if bs_soldier_prop.character_y_plus != null:
        horse_node.position.y += bs_soldier_prop.character_y_plus * 0.5
        harmour_node.position.y += bs_soldier_prop.character_y_plus * 0.5
        horse_node.region_rect.size.y -= bs_soldier_prop.character_y_plus
        harmour_node.region_rect.size.y -= bs_soldier_prop.character_y_plus

func _init_weapon_skin():
    CommonUtils.update_texture(main_weapon_node, bs_soldier_prop.main_weapon_json)
    CommonUtils.update_texture(vice_weapon_node, bs_soldier_prop.vice_weapon_json)

    if bs_soldier_prop.b_vice_weapon_json != null:
        CommonUtils.update_texture(b_shield_node, bs_soldier_prop.b_vice_weapon_json, "bs_t_path")
        b_shield_node.show()
    else:
        b_shield_node.hide()