class_name BSSoldier extends CharacterBody2D

@onready var status_machine_node =$StatusMachine
@onready var action_animation_node =$Animation / ActionAnimation
@onready var ray_detect_node =$RayDetect
@onready var collision_shape_2d_node =$CollisionShape2D
@onready var shape_node =$Shape
@onready var shape_bottom_node =$ShapeBottom
@onready var body_node =$Shape / Body
@onready var hair_node =$Shape / Hair
@onready var armour_node =$Shape / Armour
@onready var helmet_node =$Shape / Helmet
@onready var vice_weapon_node =$Shape / ViceWeapon
@onready var main_weapon_node =$Shape / MainWeapon
@onready var horse_node =$ShapeBottom / Horse
@onready var harmour_node =$ShapeBottom / Harmour
@onready var blood_node =$Shape / Blood
@onready var shadow_node =$ShapeBottom / Shadow
@onready var flyer_node = preload("res://tscn/game/soldier/Flyer.tscn")

@onready var hurt_box_node =$HurtBox
@onready var damage_label_node = preload("res://tscn/game/soldier/DamageLabel.tscn")
@onready var damage_root_node =$DamageRoot
@onready var flyer_adhering_node = preload("res://tscn/game/soldier/FlyerAdhering.tscn")
@onready var flyer_root_node =$Shape / FlyerRoot
@onready var append_animation_node =$Animation / AppendAnimation
@onready var wait_effect_node =$Animation / WaitEffect
@onready var wait_effect_animation_node =$Animation / WaitEffect / WaitEffectAnimation
@onready var body_effect_root_node =$BodyEffectRoot
@onready var soldier_body_effect_node = preload("res://tscn/game/soldier/SoldierBodyEffect.tscn")
@onready var horse_animation_node =$Animation / HorseAnimation
@onready var horse_disappear_animation_node =$Animation / HorseDisappearAnimation
@onready var die_blood_root_node =$Shape / DieBloodRoot
@onready var hero_tag_node =$HeroTag
@onready var bs_soldier_avatar_tag_node = preload("res://tscn/game/soldier/BSSoldierAvatarTag.tscn")
@onready var choose_effect_node =$ShapeBottom / ChooseEffect
@onready var target_line_node =$TargetLine as TargetLine
@onready var b_shield_node =$Shape / BShield
@onready var l_shield_place_node = preload("res://tscn/game/soldier/LShieldPlace.tscn")
@onready var change_weapon_tag_root_node =$ChangeWeaponTagRoot
@onready var change_weapon_tag_node = preload("res://tscn/game/soldier/ChangeWeaponTag.tscn")
@onready var lance_break_effect_root_node =$Shape / LanceBreakEffectRoot
@onready var flyer_start_point_node: Marker2D =$Shape / FlyerStartPoint
@onready var focus_effect_root_node =$ShapeBottom / FocusEffectRoot
@onready var flee_timer_node =$FleeTimer
@onready var horse_collision_area_node =$ShapeBottom / HorseCollisionArea
@onready var horse_collision_area_node_collision_node =$ShapeBottom / HorseCollisionArea / CollisionShape2D
@onready var buff_icon_root_node =$BuffIconRoot
@onready var horse_raise_dust_root_node =$HorseRaiseDustRoot
@onready var bmain_weapon_node =$BackShape / MainWeapon
@onready var back_shape_node =$BackShape
@onready var infantry_water_mask_node: Sprite2D =$Shape / InfantryWaterMask
@onready var cavalry_water_mask_node: Sprite2D =$Shape / CavalryWaterMask
@onready var b_cavalry_water_mask_node: Sprite2D =$ShapeBottom / BCavalryWaterMask


@onready var infantry_water_effect_node: SoldierBodyEffect =$HorseRaiseDustRoot / InfantryWaterEffect
@onready var cavalry_water_effect_node: SoldierBodyEffect =$HorseRaiseDustRoot / CavalryWaterEffect
@onready var bs_terrain_buff_handler_node: Node =$BSTerrainBuffHandler
@onready var debuf_info_node: Label =$DebufInfo
@onready var main_sfx_node: AudioStreamPlayer2D =$SoundRoot / MainSFX
@onready var secondary_sfx_node: AudioStreamPlayer2D =$SoundRoot / SecondarySFX

@onready var firearm_trajectory_detect_tool_node: DetectObstacleTool =$Shape / FirearmTrajectoryDetectTool
@onready var soldier_buff_manager_node: SoldierBuffManager =$SoldierBuffManager
@onready var chat_root_node: Node2D =$ChatRoot

const DIE_LEFT_WATER_MASK_PIC = preload("res://resource/bs/soldierPart/die_left_water_mask.png")
const BATTLE_CHAT_BUBBLE = preload("res://tscn/game/bs/BattleChatBubble.tscn")


@export var enemy_group_list: Array[String] = []
@export var select_collision_mask: = 1
@export var bs_bgroup: String = BSSoldierConstants.BS_BGROUP_ENUM.ALLY.code
@export var bs_group: String = BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP


var simple_json: Dictionary = {}


var search_physics_shape_query_parameters2d_node = PhysicsShapeQueryParameters2D.new()
var search_circle_shape = CircleShape2D.new()
var direct_space_state = null


var bs_soldier_prop: BSSoldierProp = null

var bs_soldier_avatar_tag_instance = null


var move_target: = Vector2.ZERO

var move_mode: = BSSoldierConstants.MOVE_MODE_ENUM.DIRECT_MOVE
var action_status: = BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE
var target_origin_vector: = Vector2.ZERO

var is_mobile_shooting_action: = false


var counter: = CommonUtils.random_num(1000)
var attack_target = null
var living_status: = BSSoldierConstants.LIVING_STATUS_ENUM.ACTIVE
var hp: = 800

var prep_change_weapon_user_type = null

var prepare_action = null

var move_direction = null

var body_direction = null




var force_direction = null
var origin_collision_mask = self.collision_mask

var knock_back_vector = Vector2.ZERO

var injured_level = BSSoldierConstants.INJURED_LEVEL_ENUM.COMMON

var stun_counter = 0

var stun_effect_node = null


var post_stun_slow_counter = 0
var post_stun_slow_ratio = 0.0


var mod_fear_value: float = 0.0

var mod_fear_triggered_flee: bool = false


var mod_iai_dashing: bool = false
var mod_iai_dir: Vector2 = Vector2.ZERO
var mod_iai_mult: float = 1.0
var mod_iai_is_lance: bool = false
var mod_iai_ignore_block: bool = false
var mod_iai_hit_list: Array = []
var mod_iai_layers: Array = []
var mod_iai_origin: Vector2 = Vector2.ZERO
var mod_iai_bow: float = 0.0
var mod_iai_tween: Tween = null
var mod_iai_cd_counter: int = 0
var mod_iai_is_big: bool = true
var mod_iai_fx_scale: float = 1.0




var mod_bite_active: bool = false
var mod_bite_target = null
var mod_bite_counter: int = 0
var mod_bite_offset: Vector2 = Vector2.ZERO
const MOD_BITE_INTERVAL_FRAMES: int = 30
const MOD_BITE_STICK_DIST: float = 16.0






var _mod_forest_swallow_block_count: int = 0
var _mod_forest_swallow_in_forest: bool = false
var _mod_forest_swallow_attack_speed_origin: float = 1.0
const MOD_FOREST_SWALLOW_ATTACK_SPEED_BONUS: float = 0.1





var _mod_swallow_dodge_cd_counter: int = 0
var _mod_swallow_dodge_tween: Tween = null
const MOD_SWALLOW_DODGE_PROB: float = 0.65
const MOD_SWALLOW_DODGE_DIST: float = 40.5
const MOD_SWALLOW_DODGE_TIME: float = 0.11
const MOD_SWALLOW_DODGE_CD_FRAMES: int = 24
const MOD_DODGE_THREAT_SCAN_RADIUS: float = 120.0
const MOD_DODGE_GHOST_TINT: Color = Color(0.6, 0.8, 1.0, 0.5)
const MOD_DODGE_GHOST_LIFE: float = 0.4
const MOD_DODGE_GHOST_TIME_FRACTIONS: Array = [0.0, 0.15, 0.35]

var is_charge = false


var mod_boss_phase: int = 1
var mod_boss_invulnerable: bool = false
var mod_boss_fear_aura_counter: int = 0
var mod_boss_original_hp_max: int = 0
var mod_boss_original_atk: int = 0
var mod_boss_final_death_triggered: bool = false
var mod_boss_invisible_timer: float = 0.0
var mod_boss_is_invisible: bool = false

var l_shield_place_instance = null

var murderer_bgroup: = ""

var equipment_capture_prob: = 0.0

var want_flee: = false

var is_fleeing: = false

var horse_collision_area_collision_node_origin_position: = Vector2.ZERO

var pike_sign_node_list = []
var origin_vice_weapon_node_position = Vector2.ZERO
var in_water: = false


var enemy_attack_intent_count = 0
var dialogue_gd: BaseDialogue


var guard_rect: Rect2 = Rect2()





signal soldier_die_sign(_bs_group, _simple_json, _murderer_bgroup, _is_flee_success, _soldier_node)
signal hurt_sign()

func _ready():

    self.collision_mask |= 1
    origin_collision_mask = self.collision_mask
    search_physics_shape_query_parameters2d_node.collide_with_areas = false
    search_physics_shape_query_parameters2d_node.collide_with_bodies = true
    direct_space_state = get_world_2d().direct_space_state
    horse_collision_area_collision_node_origin_position = horse_collision_area_node_collision_node.position
    firearm_trajectory_detect_tool_node.position = FirearmShootSmokeEffect.get_muzzle_rel_position()


func _physics_process(_delta):
    counter += 1







    if post_stun_slow_counter > 0:
        post_stun_slow_counter -= 1
        if post_stun_slow_counter <= 0:
            post_stun_slow_ratio = 0.0


    if mod_iai_cd_counter > 0:
        mod_iai_cd_counter -= 1


    if _mod_swallow_dodge_cd_counter > 0:
        _mod_swallow_dodge_cd_counter -= 1


    if mod_iai_dashing:
        _mod_iai_dash_process()


    if mod_bite_active:
        _mod_bite_process()


    if knock_back_vector != Vector2.ZERO:
        knock_back_vector = knock_back_vector.move_toward(Vector2.ZERO, 3)
        self.velocity = knock_back_vector

        self.move_and_slide()




    _handle_check_flee()


    if mod_boss_phase >= 3 and not mod_boss_invulnerable:
        mod_boss_fear_aura_counter += 1
        if mod_boss_fear_aura_counter >= 60:
            mod_boss_fear_aura_counter = 0
            _mod_boss_fear_aura()


    if mod_boss_phase == 4 and not mod_boss_invulnerable:
        mod_boss_invisible_timer += get_process_delta_time()
        if not mod_boss_is_invisible and mod_boss_invisible_timer >= 2.0:

            mod_boss_is_invisible = true
            mod_boss_invisible_timer = 0.0
            modulate.a = 0.1
            hurt_box_node.set_deferred("monitoring", false)
        elif mod_boss_is_invisible and mod_boss_invisible_timer >= 1.2:

            mod_boss_is_invisible = false
            mod_boss_invisible_timer = 0.0
            modulate.a = 1.0
            hurt_box_node.set_deferred("monitoring", true)
















func init(
    _simple_json, _is_day: bool = true,
    _weather: MWorldConstants.WEATHER_TYPE_ENUM = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR
)-> void:
    simple_json = _simple_json


    bs_soldier_prop = SoldierUtils.get_bs_soldier_prop(_simple_json, _is_day, _weather)
    bs_soldier_prop.set_bs_group(bs_group)


    hp = bs_soldier_prop.hp

    velocity = Vector2.ZERO


    _init_all_skin()
    origin_vice_weapon_node_position = vice_weapon_node.position

    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)


    var _ray_max_length = ray_detect_node.ray_max_length

    ray_detect_node.collision_mask = 1
    if is_cavalry():

        _ray_max_length = 22
        if GameConfig.OPEN_CAVALRY_IMPACT_COLLIDER:
            _open_horse_collision_area_check()



    if SoldierUtils.is_hero_or_leader2(self):
        _handle_hero()


    ray_detect_node.create_ray_list(_ray_max_length)
    ray_detect_node.launch_detect()


    if simple_json.has("uid") and simple_json.uid == "mod_boss_conquest_knight":
        is_charge = true
        mod_boss_original_hp_max = bs_soldier_prop.hp_max
        mod_boss_original_atk = bs_soldier_prop.atk
        print("[Mod] BOSS征伐骑士init: is_charge=true, phase=1, hp_max=", bs_soldier_prop.hp_max, ", atk=", bs_soldier_prop.atk)

    _custom_init()

func _custom_init()-> void:
    pass

func move_to_target(_target_vector: Vector2, _show_target_line = false, _line_color: Color = CommonConstants.COLOR_ENUM.WHITE, _direction_enum = null):
    if not SoldierUtils.is_living(self.living_status):
        return



    force_direction = _direction_enum

    move_mode = BSSoldierConstants.MOVE_MODE_ENUM.DIRECT_MOVE
    set_move_target(_target_vector, _show_target_line, CommonConstants.COLOR_ENUM.MOVE_COLOR)


    if BSSoldierConstants.CANT_INTERRUPT_ACTION_STATUS_LIST.has(get_action_status()):
        return

    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE)

func set_move_target(_target_vector, _show_target_line = false, _line_color: Color = CommonConstants.COLOR_ENUM.WHITE):
    move_target = _target_vector

    if _show_target_line and _target_vector != Vector2.ZERO:
        target_line_node.start(_target_vector, _line_color)

func empty_move_target():
    set_move_target(Vector2.ZERO)

func play_mobile_shooting_animation():
    var _animation_name_enum = get_attack_animation_name_enum()
    self.play_attack_animation(_animation_name_enum, "", true)


func play_attack_animation(_animation_name_enum, _suffix: String = "", _is_mobile_shooting = false):
    play_animation(_animation_name_enum, _suffix, _is_mobile_shooting, bs_soldier_prop.attack_speed)

func play_animation(_animation_name_enum, _suffix: String = "", _is_mobile_shooting = false, _speed_scale = 1.0):

    var _animation_name: String = _animation_name_enum.animation_name
    var _is_need_random_frame = false


    if["idle", "move"].has(_animation_name):
        _is_need_random_frame = true

    if is_cavalry():
        _animation_name = _animation_name_enum.h_animation_name
        var _ha_animation_name = _animation_name_enum.ha_animation_name
        if _is_mobile_shooting:
            _ha_animation_name = "move"

        if StringUtils.is_not_empty(_ha_animation_name):
            var _is_need_random_frame_ha = true
            if horse_animation_node.current_animation == _ha_animation_name:
                _is_need_random_frame_ha = false

            horse_animation_node.play(_ha_animation_name)
            horse_animation_node.speed_scale = bs_soldier_prop.horse_animation_speed

            if _is_need_random_frame_ha:

                horse_animation_node.seek(
                    CommonUtils.random_num(horse_animation_node.current_animation_length * 1000) / 1000.0,
                )

    _animation_name += _suffix


    if _is_mobile_shooting:
        _animation_name = _animation_name_enum.mobile_shooting_animation_name

    if action_animation_node.current_animation == _animation_name:
        _is_need_random_frame = false

    action_animation_node.play(_animation_name)
    action_animation_node.speed_scale = _speed_scale

    if _is_need_random_frame:

        action_animation_node.seek(CommonUtils.random_num(action_animation_node.current_animation_length * 1000) / 1000.0)

func change_status(_action_status):




    status_machine_node.change_status(_action_status)

func update_direction(_is_body = null):
    update_direction2(target_origin_vector, _is_body)

func update_direction2(_vector, _is_body = null):





    var _direction_enum = CommonConstants.DIRECTION_ENUM.RIGHT
    if _vector.x < 0:
        _direction_enum = CommonConstants.DIRECTION_ENUM.LEFT

    update_direction3(_direction_enum, _is_body)


func update_direction3(_direction_enum, _is_body = null):
    if _is_body == null:
        update_direction3(_direction_enum, true)
        update_direction3(_direction_enum, false)
        return

    if _is_body:
        _update_part_direction(shape_node, _direction_enum, "body_direction")

    else:
        _update_part_direction(shape_bottom_node, _direction_enum, "move_direction")


func move_and_se(_target_vector: Vector2, _show_target_line = false, _direction_enum = null):
    if not SoldierUtils.is_living(self.living_status):
        return



    force_direction = _direction_enum

    move_mode = BSSoldierConstants.MOVE_MODE_ENUM.MAS_MOVE
    set_move_target(_target_vector, _show_target_line, CommonConstants.COLOR_ENUM.ATTACK_COLOR)


    if BSSoldierConstants.CANT_INTERRUPT_ACTION_STATUS_LIST.has(get_action_status()):
        return


    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_AND_SE)

func move():
    return self.move2(move_target, BSSoldierConfig.CHECK_ARRIVE_LENGTH_SQUARED)



func move2(
    _target_position, _check_arrive_length_squared,


):
    if knock_back_vector != Vector2.ZERO:
        return

    target_origin_vector = _target_position - global_position
    var _current_target_vector: = target_origin_vector


    if is_cavalry():
        if velocity == Vector2.ZERO:
            velocity = target_origin_vector.normalized()


        var _angle_diff: = velocity.angle_to(target_origin_vector)

        if target_origin_vector.length_squared() > 8100 \
        or abs(_angle_diff) < 1.57 \

        or(
                CommonUtils.is_not_null(attack_target) \
                and SoldierUtils.is_attack_target_each_other(attack_target, self) \
                and is_instance_valid(attack_target) and not attack_target.has_meta("is_wooden_wall") \
                and attack_target.is_cavalry()
            ):
            _angle_diff = clamp(_angle_diff, -1.0, 1.0)
        else:
            _angle_diff = clamp(_angle_diff, -0.01, 0.01)




        _current_target_vector = velocity.rotated(_angle_diff)


    ray_detect_node.rotation = _current_target_vector.angle()


    var _target_velocity: Vector2 = ray_detect_node.get_direction2().normalized() * get_move_speed()

    if is_cavalry():
        velocity = velocity.move_toward(_target_velocity, BSSoldierConfig.WALK_ACCELERATION)
    else:
        velocity = _target_velocity

    var _prev_pos: Vector2 = global_position
    self.move_and_slide()


    if guard_rect.has_area() and not guard_rect.has_point(global_position) and bs_soldier_prop.is_use_remote_weapon:
        global_position = _prev_pos
        velocity = Vector2.ZERO

    if is_mobile_shooting_action and _has_attack_target():
        update_direction2(velocity, false)
    else:
        update_direction2(velocity)


    if is_horse_collision_area_open:
        match move_direction:
            CommonConstants.DIRECTION_ENUM.LEFT:

                horse_collision_area_node.rotation = - velocity.angle() + PI
            CommonConstants.DIRECTION_ENUM.RIGHT:
                horse_collision_area_node.rotation = velocity.angle()



    if target_origin_vector.length_squared() < _check_arrive_length_squared:

        return true

    return false


func inertial_move(_acceleration)-> bool:
    if velocity == Vector2.ZERO:
        return true

    velocity = velocity.move_toward(Vector2.ZERO, _acceleration)

    self.move_and_slide()





    return false

func handle_search_enemy()-> bool:
    var success = search_enemy()
    if success:
        if get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_MOVE:
            pass
        else:
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY)
    else:
        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)

    return success


func is_enemy(_enemy_group_list: Array):


    for _my_group_name in _enemy_group_list:
        if self.is_in_group(_my_group_name):
            return true

    return false


func attack(
    _mult = 1,
    _is_lance_or_set_pike: = false,
    _is_ignore_block: = false
):
    if attack_target == null:
        return


    if mod_bite_active:
        return


    if is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):


        if attack_target.has_meta("is_arrow_tower"):
            var _tparent: Node2D = attack_target.get_parent()
            if _tparent != null and is_instance_valid(_tparent):
                var _tidx: int = GlobalNode._mod_tower_nodes.find(_tparent)
                if _tidx >= 0 and GlobalNode._mod_tower_hps[_tidx] > 0:
                    _play_attack_sfx()
            return

        if attack_target.has_meta("is_small_wooden_wall"):
            var _parent: Node2D = attack_target.get_parent()
            if _parent != null and is_instance_valid(_parent):
                var _idx: int = GlobalNode._mod_small_wall_nodes.find(_parent)
                if _idx >= 0 and GlobalNode._mod_small_wall_hps[_idx] > 0:
                    _play_attack_sfx()
                    GlobalNode._mod_damage_small_wall_by_arrow(_idx, get_atk() * _mult)
            return

        if GlobalNode._mod_is_wooden_wall_alive():
            _play_attack_sfx()
            GlobalNode._mod_damage_wooden_wall_by_arrow(get_atk() * _mult)
        return





    _play_attack_sfx()



    if _try_start_iai_cut(_mult, _is_lance_or_set_pike, _is_ignore_block):
        return

    attack_target.hurt(
        get_atk() * _mult, bs_soldier_prop.get_attack_type(),

        self,
        attack_target.global_position - self.global_position,
        bs_soldier_prop.weapon_special_attr_dic,
        _is_lance_or_set_pike,
        _is_ignore_block
    )


    _apply_splash_damage(_mult, _is_lance_or_set_pike, _is_ignore_block)


    if bs_soldier_prop.get_attack_type() == WeaponTypeConstants.ATTACK_TYPE_ENUM.CLOSE_IN \
    and bs_soldier_prop.skill_special_bite > 0 \
    and is_instance_valid(attack_target) \
    and SoldierUtils.is_living_by_soldier_node(attack_target):
        if CommonUtils.prob_true(0.03 * bs_soldier_prop.skill_special_bite):
            _mod_start_savage_bite()






func _apply_splash_damage(_mult, _is_lance_or_set_pike: bool, _is_ignore_block: bool)-> void:
    if not bs_soldier_prop.weapon_special_attr_dic.has("splash_damage"):
        return

    if attack_target == null or not is_instance_valid(attack_target):
        return

    var _attack_range: float = get_attack_range()
    if _attack_range <= 0:
        return

    var _splash_radius: float = _attack_range * 1.5
    var _splash_radius_sq: float = _splash_radius * _splash_radius


    var _attack_vec: Vector2 = attack_target.global_position - global_position
    var _attack_dir: Vector2 = _attack_vec.normalized()


    var _enemy_list: Array = GlobalNode.battle_scene.list_search_target_soldier_node(enemy_group_list)

    for _enemy_node in _enemy_list:

        if _enemy_node == attack_target:
            continue


        if not SoldierUtils.is_living_by_soldier_node(_enemy_node):
            continue

        var _to_enemy: Vector2 = _enemy_node.global_position - global_position
        var _dist_sq: float = _to_enemy.length_squared()


        if _dist_sq > _splash_radius_sq:
            continue


        var _dist: float = sqrt(_dist_sq)
        if _dist < 1.0:
            _dist = 1.0
        var _dot: float = _attack_dir.dot(_to_enemy) / _dist
        if _dot < 0.0:
            continue


        var _splash_mult: float = 0.0
        if _dist <= _attack_range * 0.5:
            _splash_mult = 1.0
        elif _dist <= _attack_range * 1.0:
            _splash_mult = 0.55
        else:
            _splash_mult = 0.25


        _enemy_node.hurt(
            get_atk() * _mult * _splash_mult,
            bs_soldier_prop.get_attack_type(),
            self,
            _to_enemy,
            bs_soldier_prop.weapon_special_attr_dic,
            _is_lance_or_set_pike,
            _is_ignore_block
        )










func _try_start_iai_cut(_mult, _is_lance_or_set_pike: bool, _is_ignore_block: bool)-> bool:
    if not bs_soldier_prop.weapon_special_attr_dic.has("iai_cut"):
        return false

    if mod_iai_dashing:
        return false


    if _mod_swallow_dodge_tween != null and is_instance_valid(_mod_swallow_dodge_tween) \
    and _mod_swallow_dodge_tween.is_running():
        return false

    if attack_target == null or not is_instance_valid(attack_target):
        return false

    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return false

    var _dic: Dictionary = bs_soldier_prop.weapon_special_attr_dic


    var _is_big: bool = mod_iai_cd_counter <= 0


    if _is_big and _mod_is_hawk_tachi():
        _is_big = false
    if _is_big:
        var _iai_cd_seconds: float = CommonUtils.get_value(_dic, "iai_cut_cd", 3.0)
        mod_iai_cd_counter = int(max(_iai_cd_seconds, 0.5) * 60)

    mod_iai_is_big = _is_big

    mod_iai_fx_scale = 1.4 if _is_big else 0.55


    var _attack_dir: Vector2 =(attack_target.global_position - global_position).normalized()

    if _attack_dir == Vector2.ZERO:
        _attack_dir = Vector2.RIGHT if force_direction == null or force_direction == CommonConstants.DIRECTION_ENUM.RIGHT else Vector2.LEFT


    var _dash_distance: float = 90.0
    if _dic.has("iai_cut_dash"):
        _dash_distance = float(_dic["iai_cut_dash"])
    if not _is_big:
        _dash_distance *= CommonUtils.get_value(_dic, "iai_cut_dash_small_ratio", 0.45)


    var _try_dist: float = _dash_distance
    while _try_dist > 0.0 and GlobalNode.battle_scene.check_out_map_edge(global_position + _attack_dir * _try_dist):
        _try_dist -= 8.0
    if _try_dist < 10.0:
        return false


    mod_iai_dashing = true
    mod_iai_dir = _attack_dir
    mod_iai_mult = _mult
    mod_iai_is_lance = _is_lance_or_set_pike
    mod_iai_ignore_block = _is_ignore_block
    mod_iai_hit_list = []
    mod_iai_origin = global_position

    knock_back_vector = Vector2.ZERO

    mod_iai_bow =(randf() * 2.0 - 1.0) * min(_try_dist * 0.055, 7.0)



    _create_iai_trail()
    _spawn_iai_glint(global_position)
    if _is_big:
        _spawn_iai_ring(global_position)
        _spawn_iai_petals(global_position, 10)
    else:
        _spawn_iai_petals(global_position, 2)


    var _dash_time: float = 0.16 if _is_big else 0.11
    var _end_pos: Vector2 = global_position + _attack_dir * _try_dist
    mod_iai_tween = create_tween()
    mod_iai_tween.tween_property(self, "global_position", _end_pos, _dash_time) \
    .set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    mod_iai_tween.finished.connect(_finish_iai_dash)

    return true




func _mod_get_iai_engage_extra_range()-> int:
    if mod_iai_dashing:
        return 0
    var _dic: Dictionary = bs_soldier_prop.weapon_special_attr_dic
    if not _dic.has("iai_cut"):
        return 0
    var _dash: float = 90.0
    if _dic.has("iai_cut_dash"):
        _dash = float(_dic["iai_cut_dash"])
    if mod_iai_cd_counter > 0 or _mod_is_hawk_tachi():
        _dash *= CommonUtils.get_value(_dic, "iai_cut_dash_small_ratio", 0.45)
    return int(_dash * 0.9)


func _mod_iai_dash_process()-> void:

    if not SoldierUtils.is_living(living_status):


        if mod_iai_tween != null and mod_iai_tween.is_valid():
            mod_iai_tween.kill()
        _finish_iai_dash()
        return


    _update_iai_trail()


    _spawn_iai_petals(global_position, 2 if mod_iai_is_big else 1)
    _spawn_iai_speed_lines()
    if mod_iai_is_big:
        _spawn_iai_speed_lines()


    var _hit_radius: float = 36.0 if mod_iai_is_big else 29.0
    var _hit_radius_sq: float = _hit_radius * _hit_radius
    var _enemy_list: Array = GlobalNode.battle_scene.list_search_target_soldier_node(enemy_group_list)

    for _enemy_node in _enemy_list:

        if mod_iai_hit_list.has(_enemy_node):
            continue


        if not SoldierUtils.is_living_by_soldier_node(_enemy_node):
            continue

        var _to_enemy: Vector2 = _enemy_node.global_position - global_position


        if _to_enemy.length_squared() > _hit_radius_sq:
            continue


        if mod_iai_dir.dot(_to_enemy) < 0.0:
            continue

        mod_iai_hit_list.append(_enemy_node)


        var _enemy_hp_before: int = _enemy_node.hp
        _enemy_node.hurt(
            get_atk() * mod_iai_mult,
            bs_soldier_prop.get_attack_type(),
            self,
            _to_enemy,
            bs_soldier_prop.weapon_special_attr_dic,
            mod_iai_is_lance,
            mod_iai_ignore_block
        )

        if _enemy_node.hp < _enemy_hp_before:
            _spawn_iai_impact(_enemy_node.global_position)



func _finish_iai_dash()-> void:

    if not mod_iai_dashing:
        return






    if attack_target != null and is_instance_valid(attack_target):
        if not mod_iai_hit_list.has(attack_target):
            if SoldierUtils.is_living_by_soldier_node(attack_target):

                var _target_hp_before: int = attack_target.hp
                attack_target.hurt(
                    get_atk() * mod_iai_mult,
                    bs_soldier_prop.get_attack_type(),
                    self,
                    attack_target.global_position - global_position,
                    bs_soldier_prop.weapon_special_attr_dic,
                    mod_iai_is_lance,
                    mod_iai_ignore_block
                )
                if attack_target.hp < _target_hp_before:
                    _spawn_iai_impact(attack_target.global_position)

    mod_iai_dashing = false
    mod_iai_hit_list = []
    mod_iai_tween = null


    _spawn_iai_ground_scar()
    _spawn_iai_finish_glint(global_position)

    var _layers: Array = mod_iai_layers
    mod_iai_layers = []

    var _fade_times: Array = [0.52, 0.26, 0.1] if mod_iai_is_big else[0.32, 0.18, 0.08]

    for _i in range(_layers.size()):
        var _layer = _layers[_i]
        if not is_instance_valid(_layer):
            continue
        var _tween = _layer.create_tween()
        _tween.set_parallel(true)
        _tween.tween_property(_layer, "modulate:a", 0.0, _fade_times[_i])
        _tween.tween_property(_layer, "width", _layer.width * 0.4, _fade_times[_i])
        _tween.chain().tween_callback(_layer.queue_free)







func _mod_swallow_dodge_try(_origin_soldier_node: BSSoldier, _attack_vector: Vector2)-> bool:

    var _dodge_prob: float = _mod_get_hurt_dodge_prob()
    if _dodge_prob <= 0.0:
        return false

    if _origin_soldier_node == null or not is_instance_valid(_origin_soldier_node):
        return false

    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return false

    if mod_iai_dashing or _mod_swallow_dodge_cd_counter > 0:
        return false

    if status_machine_node != null and is_instance_valid(status_machine_node) \
    and status_machine_node.get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN:
        return false


    if not CommonUtils.prob_true(_dodge_prob):
        return false


    var _dist: float = _mod_get_swallow_dodge_dist()


    var _dodge_dir: Vector2 = _mod_pick_dodge_direction(_attack_vector, _dist)


    var _try_dist: float = _mod_swallow_dodge_shrink(_dodge_dir, _dist)
    if _try_dist < 12.0:
        return false


    _mod_swallow_dodge_cd_counter = MOD_SWALLOW_DODGE_CD_FRAMES


    _spawn_dodge_wind_swirl(global_position)
    _spawn_dodge_ripple(global_position)


    var _end_pos: Vector2 = global_position + _dodge_dir * _try_dist
    var _tween: Tween = create_tween()
    _tween.tween_property(self, "global_position", _end_pos, MOD_SWALLOW_DODGE_TIME) \
    .set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    _mod_swallow_dodge_tween = _tween

    _tween.finished.connect(_spawn_dodge_ripple.bind(_end_pos))


    var _ghost_tween: Tween = create_tween()
    for _gi in range(MOD_DODGE_GHOST_TIME_FRACTIONS.size()):
        var _frac: float = MOD_DODGE_GHOST_TIME_FRACTIONS[_gi]
        if _frac > 0.0:
            _ghost_tween.tween_interval(MOD_SWALLOW_DODGE_TIME * _frac)
        _ghost_tween.tween_callback(_mod_spawn_dodge_ghost.bind(_gi))

    return true






var _mod_guard_dodge_prob_cache: float = -1.0

func _mod_get_hurt_dodge_prob()-> float:
    if simple_json == null or not simple_json.has("uid"):
        return 0.0
    var _uid: String = simple_json.uid
    if _uid == "mod_lord_hero_0002":
        return MOD_SWALLOW_DODGE_PROB
    if _uid == "regular_soldier_0055":
        if _mod_guard_dodge_prob_cache < 0.0:
            var _soldier_json: Dictionary = SoldierUtils.get_json2(simple_json)
            _mod_guard_dodge_prob_cache = float(
                CommonUtils.get_value(_soldier_json, "mod_dodge_rate", 0.0)
            )
        return _mod_guard_dodge_prob_cache
    return 0.0


func _mod_get_swallow_dodge_dist()-> float:
    var _dic: Dictionary = bs_soldier_prop.weapon_special_attr_dic
    if not _dic.has("iai_cut"):
        return MOD_SWALLOW_DODGE_DIST
    var _dash: float = 90.0
    if _dic.has("iai_cut_dash"):
        _dash = float(_dic["iai_cut_dash"])
    return _dash * CommonUtils.get_value(_dic, "iai_cut_dash_small_ratio", 0.45)







func _mod_pick_dodge_direction(_attack_vector: Vector2, _dist: float)-> Vector2:
    var _incoming: Vector2 = _attack_vector.normalized()


    var _enemy_list: Array = []
    if GlobalNode.battle_scene != null and is_instance_valid(GlobalNode.battle_scene):
        _enemy_list = GlobalNode.battle_scene.list_search_target_soldier_node(enemy_group_list)

    var _best_dirs: Array = []
    var _best_score: float = -99999.0


    for _i in range(12):
        var _dir: Vector2 = Vector2(cos(TAU * _i / 12.0), sin(TAU * _i / 12.0))
        var _end_pos: Vector2 = global_position + _dir * _dist
        var _score: float = 0.0
        var _in_active_front: bool = false

        for _enemy_node in _enemy_list:
            if _enemy_node == null or not is_instance_valid(_enemy_node):
                continue
            if _enemy_node == self:
                continue
            var _e_prop = _enemy_node.bs_soldier_prop
            if _e_prop == null:
                continue
            var _e_pos: Vector2 = _enemy_node.global_position

            if _e_pos.distance_to(global_position) > MOD_DODGE_THREAT_SCAN_RADIUS:
                continue
            var _dist_to_end: float = _e_pos.distance_to(_end_pos)

            var _is_attacking: bool = _enemy_node.status_machine_node != null \
            and is_instance_valid(_enemy_node.status_machine_node) \
            and _enemy_node.status_machine_node.get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.ATTACK

            var _facing: Vector2 = Vector2.RIGHT
            if _enemy_node.move_direction == CommonConstants.DIRECTION_ENUM.LEFT:
                _facing = Vector2.LEFT
            var _behind: bool = _facing.dot((_end_pos - _e_pos).normalized()) < -0.25


            if _dist_to_end > _e_prop.attack_range + 12.0:
                _score += 1.0
                continue
            if _behind:


                _score += 0.8
            elif _dist_to_end < 16.0:

                _score -= 0.6
            elif _is_attacking:

                _in_active_front = true
            else:

                _score -= 0.2

        if _in_active_front:
            continue
        if _score > _best_score:
            _best_score = _score
            _best_dirs = [_dir]
        elif _score == _best_score:
            _best_dirs.append(_dir)


    if _best_dirs.is_empty():
        var _side: float = 1.0 if randf() < 0.5 else -1.0
        return _incoming.rotated(_side * deg_to_rad(75.0 + randf() * 30.0))
    return _best_dirs.pick_random()


func _mod_swallow_dodge_shrink(_dir: Vector2, _dist: float)-> float:
    var _try: float = _dist
    while _try > 0.0 and GlobalNode.battle_scene.check_out_map_edge(global_position + _dir * _try):
        _try -= 6.0
    return _try





func _mod_spawn_dodge_ghost(_index: int)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return
    if shape_node == null or not is_instance_valid(shape_node):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _ghost_root: Node2D = Node2D.new()
    _ghost_root.z_index = 90
    _bs.add_child(_ghost_root)

    _ghost_root.global_transform = shape_node.global_transform


    var _part_list: Array = [
        body_node, hair_node, armour_node, helmet_node,
        vice_weapon_node, main_weapon_node, b_shield_node,
    ]
    var _part_count: int = 0
    for _part in _part_list:
        if _part == null or not is_instance_valid(_part):
            continue
        if not(_part is Sprite2D):
            continue
        if not _part.visible or _part.texture == null:
            continue
        var _gp: Sprite2D = Sprite2D.new()
        _gp.texture = _part.texture
        _gp.hframes = _part.hframes
        _gp.vframes = _part.vframes
        _gp.frame = _part.frame
        _gp.flip_h = _part.flip_h
        _gp.flip_v = _part.flip_v
        _gp.centered = _part.centered
        _gp.offset = _part.offset
        _gp.region_enabled = _part.region_enabled
        if _part.region_enabled:
            _gp.region_rect = _part.region_rect
        _gp.position = _part.position
        _gp.rotation = _part.rotation
        _gp.scale = _part.scale
        _gp.modulate = _part.modulate
        _gp.self_modulate = _part.self_modulate
        _ghost_root.add_child(_gp)
        _part_count += 1


    if _part_count == 0:
        _ghost_root.queue_free()
        return


    var _tint: Color = MOD_DODGE_GHOST_TINT
    _tint.a *=(1.0 - 0.18 * _index)
    _ghost_root.modulate = _tint


    var _tween: Tween = _ghost_root.create_tween()
    _tween.set_parallel(true)
    _tween.tween_property(_ghost_root, "modulate:a", 0.0, MOD_DODGE_GHOST_LIFE) \
    .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
    _tween.tween_property(_ghost_root, "scale", _ghost_root.scale * 0.94, MOD_DODGE_GHOST_LIFE)
    _tween.chain().tween_callback(_ghost_root.queue_free)






func _spawn_dodge_wind_swirl(_global_pos: Vector2)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _center: Vector2 = _global_pos - _bs.global_position


    for _i in range(3):
        var _base_a: float = randf() * TAU
        var _arc_span: float = deg_to_rad(100.0 + randf() * 60.0)
        var _radius: float = 10.0 + randf() * 4.0
        var _spin: float = 1.5 + randf() * 1.5

        var _arc: Line2D = Line2D.new()
        _arc.width = 2.0
        _arc.default_color = Color(0.55, 0.85, 1.0, 0.85)
        _arc.z_index = 101
        _arc.joint_mode = Line2D.LINE_JOINT_ROUND
        _arc.begin_cap_mode = Line2D.LINE_CAP_ROUND
        _arc.end_cap_mode = Line2D.LINE_CAP_ROUND

        var _pts: PackedVector2Array = PackedVector2Array()
        for _j in range(8):
            var _a: float = _base_a + _arc_span * _j / 7.0
            _pts.append(Vector2(cos(_a), sin(_a)) * _radius)
        _arc.points = _pts
        _arc.position = _center
        _bs.add_child(_arc)


        var _tween: Tween = _arc.create_tween()
        _tween.set_parallel(true)
        _tween.tween_property(_arc, "scale", Vector2(2.6, 2.6), 0.32) \
        .set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        _tween.tween_property(_arc, "rotation", _arc.rotation + _spin, 0.32)
        _tween.tween_property(_arc, "modulate:a", 0.0, 0.32).set_ease(Tween.EASE_IN)
        _tween.tween_property(_arc, "width", 0.4, 0.32)
        _tween.chain().tween_callback(_arc.queue_free)



func _spawn_dodge_ripple(_global_pos: Vector2)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _center: Vector2 = _global_pos - _bs.global_position

    var _ring: Line2D = Line2D.new()
    _ring.width = 1.8
    _ring.default_color = Color(0.6, 0.88, 1.0, 0.7)
    _ring.z_index = 101
    _ring.joint_mode = Line2D.LINE_JOINT_ROUND
    _ring.begin_cap_mode = Line2D.LINE_CAP_ROUND
    _ring.end_cap_mode = Line2D.LINE_CAP_ROUND

    var _pts: PackedVector2Array = PackedVector2Array()
    var _seg: int = 24
    for _i in range(_seg + 1):
        var _a: float = TAU * _i / _seg
        _pts.append(Vector2(cos(_a), sin(_a)) * 7.0)
    _ring.points = _pts
    _ring.position = _center
    _bs.add_child(_ring)

    var _tween: Tween = _ring.create_tween()
    _tween.set_parallel(true)
    _tween.tween_property(_ring, "scale", Vector2(2.2, 2.2), 0.26) \
    .set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    _tween.tween_property(_ring, "modulate:a", 0.0, 0.26).set_ease(Tween.EASE_IN)
    _tween.tween_property(_ring, "width", 0.4, 0.26)
    _tween.chain().tween_callback(_ring.queue_free)






func _mod_is_hawk_tachi()-> bool:
    var _w_json = bs_soldier_prop.main_weapon_json
    return _w_json != null and _w_json.get("uid", "") == "th_blunt_0008"




func _mod_iai_palette()-> Dictionary:
    if _mod_is_hawk_tachi():
        return {
            "layers": [
                [Color(0.72, 0.8, 0.94), 0.1, 0.3, 0.48],
                [Color(0.9, 0.94, 1.0), 0.22, 0.52, 0.82],
                [Color(1.0, 1.0, 1.0), 0.55, 0.92, 1.0],
            ],
            "ring": Color(0.92, 0.96, 1.0),
            "petals": [
                Color(1.0, 1.0, 1.0, 0.95),
                Color(0.94, 0.96, 1.0, 0.92),
                Color(0.86, 0.91, 1.0, 0.9),
                Color(0.97, 0.98, 1.0, 0.88),
            ],
            "scar": Color(0.9, 0.94, 1.0),
            "glint": Color(0.97, 0.99, 1.0),
            "flash": Color(0.98, 0.99, 1.0),
            "spark": Color(0.95, 0.97, 1.0),
        }
    return {
        "layers": [
            [Color(0.58, 0.4, 0.96), 0.1, 0.3, 0.48],
            [Color(0.8, 0.62, 1.0), 0.22, 0.52, 0.82],
            [Color(0.99, 0.96, 1.0), 0.55, 0.92, 1.0],
        ],
        "ring": Color(0.92, 0.85, 1.0),
        "petals": [
            Color(1.0, 0.98, 1.0, 0.95),
            Color(0.9, 0.8, 1.0, 0.92),
            Color(1.0, 0.87, 0.95, 0.9),
            Color(0.84, 0.74, 0.98, 0.88),
        ],
        "scar": Color(0.86, 0.76, 1.0),
        "glint": Color(1.0, 0.97, 0.9),
        "flash": Color(1.0, 0.98, 0.95),
        "spark": Color(1.0, 0.9, 0.72),
    }

func _create_iai_trail()-> void:

    for _old_layer in mod_iai_layers:
        if is_instance_valid(_old_layer):
            _old_layer.queue_free()
    mod_iai_layers = []

    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _local_pos: Vector2 = global_position - _bs.global_position




    var _fx: float = mod_iai_fx_scale
    var _ai: float = 1.25 if mod_iai_is_big else 1.0
    var _pal: Dictionary = _mod_iai_palette()
    var _layer_specs: Array = [
        [26.0 * _fx, _pal["layers"][0][0], _pal["layers"][0][1], _pal["layers"][0][2], _pal["layers"][0][3], 99],
        [11.0 * _fx, _pal["layers"][1][0], _pal["layers"][1][1], _pal["layers"][1][2], _pal["layers"][1][3], 100],
        [3.6 * _fx, _pal["layers"][2][0], _pal["layers"][2][1], _pal["layers"][2][2], _pal["layers"][2][3], 101],
    ]


    var _width_curve: Curve = Curve.new()
    _width_curve.add_point(Vector2(0.0, 0.05))
    _width_curve.add_point(Vector2(0.35, 0.55))
    _width_curve.add_point(Vector2(1.0, 1.0))

    for _spec in _layer_specs:
        var _line: Line2D = Line2D.new()
        _line.width = _spec[0]
        _line.default_color = _spec[1]
        _line.z_index = _spec[5]
        _line.joint_mode = Line2D.LINE_JOINT_ROUND
        _line.begin_cap_mode = Line2D.LINE_CAP_ROUND
        _line.end_cap_mode = Line2D.LINE_CAP_ROUND
        _line.width_curve = _width_curve



        var _grad: Gradient = Gradient.new()
        _grad.set_color(0, Color(_spec[1].r, _spec[1].g, _spec[1].b, minf(_spec[2] * _ai, 1.0)))
        _grad.add_point(0.45, Color(_spec[1].r, _spec[1].g, _spec[1].b, minf(_spec[3] * _ai, 1.0)))
        _grad.set_color(2, Color(_spec[1].r, _spec[1].g, _spec[1].b, minf(_spec[4] * _ai, 1.0)))
        _line.gradient = _grad

        _line.add_point(_local_pos)
        _line.add_point(_local_pos)
        _bs.add_child(_line)
        mod_iai_layers.append(_line)

    _update_iai_trail()


func _update_iai_trail()-> void:
    if mod_iai_layers.is_empty():
        return

    var _pts: PackedVector2Array = _calc_iai_arc_points()
    if _pts.is_empty():
        return

    for _layer in mod_iai_layers:
        if is_instance_valid(_layer):
            _layer.points = _pts



func _calc_iai_arc_points()-> PackedVector2Array:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return PackedVector2Array()

    var _bs: Node2D = GlobalNode.battle_scene
    var _o: Vector2 = mod_iai_origin - _bs.global_position
    var _c: Vector2 = global_position - _bs.global_position
    var _vec: Vector2 = _c - _o
    if _vec.length() < 1.0:
        return PackedVector2Array()

    var _perp: Vector2 = _vec.normalized().orthogonal() * mod_iai_bow
    var _pts: PackedVector2Array = PackedVector2Array()
    for _i in range(5):
        var _t: float = _i / 4.0
        _pts.append(_o + _vec * _t + _perp * sin(_t * PI))
    return _pts


func _spawn_iai_glint(_global_pos: Vector2)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _center: Vector2 = _global_pos - _bs.global_position
    var _base_a: float = mod_iai_dir.angle()



    var _fx: float = mod_iai_fx_scale
    var _aw: float = 1.3 if mod_iai_is_big else 1.0

    var _pal_g: Dictionary = _mod_iai_palette()
    var _g_c: Color = _pal_g["glint"]
    var _streaks: Array = [
        [0.0, 26.0 * _fx, 2.2, 0.95, 0.15],
        [PI / 2.0, 11.0 * _fx, 1.6, 0.88, 0.12],
        [PI / 4.0, 8.0 * _fx, 1.3, 0.76, 0.11],
        [PI * 3.0 / 4.0, 7.0 * _fx, 1.3, 0.7, 0.11],
    ]

    for _s in _streaks:
        var _a: float = _base_a + _s[0]
        var _d: Vector2 = Vector2(cos(_a), sin(_a))
        var _glint: Line2D = Line2D.new()
        _glint.width = _s[2] * _aw

        _glint.default_color = Color(_g_c.r, _g_c.g, _g_c.b, _s[3])
        _glint.z_index = 102
        _glint.add_point(_center - _d * _s[1])
        _glint.add_point(_center + _d * _s[1])
        _bs.add_child(_glint)

        var _tween = _glint.create_tween()
        _tween.set_parallel(true)
        _tween.tween_property(_glint, "modulate:a", 0.0, _s[4])
        _tween.tween_property(_glint, "width", _glint.width * 0.5, _s[4])
        _tween.chain().tween_callback(_glint.queue_free)



func _spawn_iai_ring(_global_pos: Vector2)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _center: Vector2 = _global_pos - _bs.global_position
    _spawn_iai_ring_single(_bs, _center, 13.0, 3.8, 4.5, 0.3, 0.92, 0.0)
    _spawn_iai_ring_single(_bs, _center, 8.0, 3.2, 3.0, 0.26, 0.8, 0.08)

func _spawn_iai_ring_single(_bs: Node2D, _center: Vector2, _radius: float, _end_scale: float, _width: float, _life: float, _alpha: float, _delay: float)-> void:
    var _ring: Line2D = Line2D.new()
    _ring.width = _width

    var _r_c: Color = _mod_iai_palette()["ring"]
    _ring.default_color = Color(_r_c.r, _r_c.g, _r_c.b, _alpha)
    _ring.z_index = 102
    _ring.joint_mode = Line2D.LINE_JOINT_ROUND
    _ring.begin_cap_mode = Line2D.LINE_CAP_ROUND
    _ring.end_cap_mode = Line2D.LINE_CAP_ROUND


    var _pts: PackedVector2Array = PackedVector2Array()
    var _seg: int = 32
    for _i in range(_seg + 1):
        var _a: float = TAU * _i / _seg
        _pts.append(Vector2(cos(_a), sin(_a)) * _radius)
    _ring.points = _pts
    _ring.position = _center
    _bs.add_child(_ring)

    var _tween = _ring.create_tween()
    if _delay > 0.0:

        _ring.modulate.a = 0.0
        _tween.tween_interval(_delay)
        _tween.tween_property(_ring, "modulate:a", 1.0, 0.04)
    _tween.set_parallel(true)
    _tween.tween_property(_ring, "scale", Vector2(_end_scale, _end_scale), _life) \
    .set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    _tween.tween_property(_ring, "modulate:a", 0.0, _life)
    _tween.tween_property(_ring, "width", 0.6, _life)
    _tween.chain().tween_callback(_ring.queue_free)



func _spawn_iai_petals(_global_pos: Vector2, _count: int = 1)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _perp: Vector2 = mod_iai_dir.orthogonal()



    var _petal_colors: Array = _mod_iai_palette()["petals"]


    var _petal_shape: PackedVector2Array = PackedVector2Array([
        Vector2(0.0, -4.2), Vector2(2.0, -1.6), Vector2(1.3, 1.9),
        Vector2(0.0, 4.2), Vector2(-1.3, 1.9), Vector2(-2.0, -1.6),
    ])

    for _i in range(_count):
        var _petal: Polygon2D = Polygon2D.new()
        _petal.polygon = _petal_shape
        _petal.color = _petal_colors.pick_random()
        _petal.z_index = 103
        _petal.position = _global_pos - _bs.global_position + Vector2(randf_range(-6.0, 6.0), randf_range(-6.0, 6.0))
        _petal.rotation = randf() * TAU
        _petal.scale = Vector2.ONE * randf_range(0.7, 1.4)
        _bs.add_child(_petal)


        var _drift: Vector2 = - mod_iai_dir * randf_range(16.0, 42.0) + _perp * randf_range(-26.0, 26.0)
        var _spin: float = randf_range(-5.5, 5.5)
        var _life: float = randf_range(0.55, 0.95)

        var _tween = _petal.create_tween()
        _tween.set_parallel(true)
        _tween.tween_property(_petal, "position", _petal.position + _drift, _life) \
        .set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        _tween.tween_property(_petal, "rotation", _petal.rotation + _spin, _life)
        _tween.tween_property(_petal, "modulate:a", 0.0, _life).set_ease(Tween.EASE_IN)
        _tween.tween_property(_petal, "scale", _petal.scale * 0.55, _life)
        _tween.chain().tween_callback(_petal.queue_free)


func _spawn_iai_speed_lines()-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _perp: Vector2 = mod_iai_dir.orthogonal()

    var _anchor: Vector2 = global_position - mod_iai_dir * randf_range(8.0, 18.0) \
    + _perp * randf_range(9.0, 22.0) *(1.0 if randf() < 0.5 else -1.0)
    var _len: float = randf_range(14.0, 28.0)

    var _streak: Line2D = Line2D.new()
    _streak.width = randf_range(1.0, 1.8)
    _streak.default_color = Color(1.0, 0.97, 1.0, randf_range(0.3, 0.5))
    _streak.z_index = 98
    _streak.begin_cap_mode = Line2D.LINE_CAP_ROUND
    _streak.end_cap_mode = Line2D.LINE_CAP_ROUND
    var _local: Vector2 = _anchor - _bs.global_position
    _streak.add_point(_local - mod_iai_dir * _len * 0.5)
    _streak.add_point(_local + mod_iai_dir * _len * 0.5)
    _bs.add_child(_streak)

    var _tween = _streak.create_tween()
    _tween.set_parallel(true)
    _tween.tween_property(_streak, "modulate:a", 0.0, 0.14)
    _tween.tween_property(_streak, "width", 0.4, 0.14)
    _tween.chain().tween_callback(_streak.queue_free)


func _spawn_iai_ground_scar()-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _pts: PackedVector2Array = _calc_iai_arc_points()
    if _pts.size() < 2:
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _scar: Line2D = Line2D.new()

    var _is_big_scar: bool = mod_iai_is_big

    var _sc_c: Color = _mod_iai_palette()["scar"]
    _scar.width =(3.0 if _is_big_scar else 1.8) * mod_iai_fx_scale
    _scar.default_color = Color(_sc_c.r, _sc_c.g, _sc_c.b, 0.72 if _is_big_scar else 0.55)
    _scar.z_index = 97
    _scar.joint_mode = Line2D.LINE_JOINT_ROUND
    _scar.begin_cap_mode = Line2D.LINE_CAP_ROUND
    _scar.end_cap_mode = Line2D.LINE_CAP_ROUND
    _scar.points = _pts
    _bs.add_child(_scar)

    var _scar_life: float = 0.85 if _is_big_scar else 0.55
    var _tween = _scar.create_tween()
    _tween.set_parallel(true)
    _tween.tween_property(_scar, "modulate:a", 0.0, _scar_life).set_ease(Tween.EASE_IN)
    _tween.tween_property(_scar, "width", 0.6, _scar_life)
    _tween.chain().tween_callback(_scar.queue_free)


func _spawn_iai_finish_glint(_global_pos: Vector2)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _center: Vector2 = _global_pos - _bs.global_position
    var _base_a: float = mod_iai_dir.angle()


    var _fx: float = mod_iai_fx_scale
    var _aw: float = 1.3 if mod_iai_is_big else 1.0

    var _fg_c: Color = _mod_iai_palette()["glint"]
    var _streaks: Array = [
        [0.0, 16.0 * _fx, 1.8, 0.92, 0.12],
        [PI / 3.0, 7.0 * _fx, 1.2, 0.75, 0.11],
        [- PI / 3.0, 7.0 * _fx, 1.2, 0.75, 0.11],
    ]

    for _s in _streaks:
        var _a: float = _base_a + _s[0]
        var _d: Vector2 = Vector2(cos(_a), sin(_a))
        var _glint: Line2D = Line2D.new()
        _glint.width = _s[2] * _aw

        _glint.default_color = Color(_fg_c.r, _fg_c.g, _fg_c.b, _s[3])
        _glint.z_index = 102
        _glint.add_point(_center - _d * _s[1])
        _glint.add_point(_center + _d * _s[1])
        _bs.add_child(_glint)

        var _tween = _glint.create_tween()
        _tween.set_parallel(true)
        _tween.tween_property(_glint, "modulate:a", 0.0, _s[4])
        _tween.tween_property(_glint, "width", _glint.width * 0.5, _s[4])
        _tween.chain().tween_callback(_glint.queue_free)


func _spawn_iai_impact(_global_pos: Vector2)-> void:
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    var _bs: Node2D = GlobalNode.battle_scene
    var _center: Vector2 = _global_pos - _bs.global_position


    var _imp: float = 1.45 if mod_iai_is_big else 1.0

    var _pal_i: Dictionary = _mod_iai_palette()
    var _fl_c: Color = _pal_i["flash"]
    var _sp_c: Color = _pal_i["spark"]


    var _cut_dir: Vector2 = mod_iai_dir.rotated(0.5)
    var _flash_len: float = 24.0 * _imp
    var _flash: Line2D = Line2D.new()
    _flash.width = 3.4 * _imp

    _flash.default_color = Color(_fl_c.r, _fl_c.g, _fl_c.b, 0.98)
    _flash.z_index = 102
    _flash.add_point(_center - _cut_dir * _flash_len)
    _flash.add_point(_center + _cut_dir * _flash_len)
    _bs.add_child(_flash)
    var _flash_life: float = 0.18 if mod_iai_is_big else 0.14
    var _flash_tween = _flash.create_tween()
    _flash_tween.set_parallel(true)
    _flash_tween.tween_property(_flash, "modulate:a", 0.0, _flash_life)
    _flash_tween.tween_property(_flash, "width", 1.0, _flash_life)
    _flash_tween.chain().tween_callback(_flash.queue_free)


    var _base_a: float = mod_iai_dir.angle()
    for _i in range(8 +(5 if mod_iai_is_big else 0)):
        var _a: float = _base_a +(PI / 2.0 if randf() < 0.5 else - PI / 2.0) + randf_range(-0.7, 0.7)
        var _spd: Vector2 = Vector2(cos(_a), sin(_a))
        var _spark: Line2D = Line2D.new()
        _spark.width = 1.8 * _imp

        _spark.default_color = Color(_sp_c.r, _sp_c.g, _sp_c.b, 0.92)
        _spark.z_index = 102
        var _seg: Vector2 = _spd * randf_range(7.0, 12.0) * _imp
        var _start: Vector2 = _center + _spd * 4.0
        _spark.add_point(_start)
        _spark.add_point(_start + _seg)
        _bs.add_child(_spark)

        var _spark_life: float = 0.3 if mod_iai_is_big else 0.24
        var _spark_tween = _spark.create_tween()
        _spark_tween.set_parallel(true)
        _spark_tween.tween_property(
            _spark, "position", _spark.position + _spd * randf_range(20.0, 36.0) * _imp, _spark_life
        ).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
        _spark_tween.tween_property(_spark, "modulate:a", 0.0, _spark_life)
        _spark_tween.tween_property(_spark, "width", 0.5, _spark_life)
        _spark_tween.chain().tween_callback(_spark.queue_free)

func launch():
    if check_enemy_die():


        var success = search_enemy()
        if not success:
            return


    var _flag = handle_check_allow_attack()
    if not _flag:
        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
        return


    if bs_soldier_prop.main_weapon_json != null and bs_soldier_prop.main_weapon_json.get("straight_shot", false):
        call_deferred("_straight_beam_attack")
        return



    if is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):
        attack()
        return

    call_deferred("_launch_flyer")

func get_hurt_box_position()-> Vector2:
    return hurt_box_node.global_position




func firearm_shoot()-> void:
    if check_enemy_die():




        return


    var _flag = handle_check_allow_attack()
    if not _flag:
        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
        return

    bs_soldier_prop.plus_shot_count(-1)


    var _misfire_ratio: float = bs_soldier_prop.misfire_ratio


    if CommonUtils.prob_true(_misfire_ratio):

        _play_misfire_sfx()
        _effect_add(BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.MISFIRE, change_weapon_tag_root_node)
        GlobalNode.battle_scene.create_misfire_effect(
            global_position,
            body_direction == CommonConstants.DIRECTION_ENUM.LEFT
        )
        return

    var _target_position: Vector2
    if is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):
        _target_position = attack_target.global_position
    elif is_instance_valid(attack_target):
        _target_position = attack_target.get_hurt_box_position()
    else:
        return


    var _blocker_node = _handle_firearm_shoot_blocker(
        _target_position.x > global_position.x
    )

    if CommonUtils.is_not_null(_blocker_node):
        var _start_position = _get_firearm_shoot_position()
        var _x: float = _blocker_node.global_position.x
        _target_position = Vector2(
            _x,
            lerp(
                _start_position.y, _target_position.y,
                (_x - _start_position.x) /(_target_position.x - _start_position.x)
            )
        )

    _play_firearm_shoot_sfx()


    _bullet_trajectory_effect(global_position, _target_position)

    if CommonUtils.is_not_null(_blocker_node):

        if _blocker_node is LShieldPlace:
            _blocker_node.hurt(get_atk())


        return



    if is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):
        var _atk = get_atk() * GlobalNode._mod_get_facility_damage_mult(self)
        if attack_target.has_meta("is_arrow_tower"):
            var _tidx: int = attack_target.get_meta("tower_idx", -1)
            if _tidx >= 0 and GlobalNode._mod_tower_hps[_tidx] > 0:
                GlobalNode._mod_damage_arrow_tower(_tidx, _atk)
        elif attack_target.has_meta("is_small_wooden_wall"):
            var _sidx: int = attack_target.get_meta("small_wall_idx", -1)
            if _sidx >= 0 and GlobalNode._mod_small_wall_hps[_sidx] > 0:
                GlobalNode._mod_damage_small_wall_by_arrow(_sidx, _atk)
        else:
            if GlobalNode._mod_is_wooden_wall_alive():
                GlobalNode._mod_damage_wooden_wall_by_arrow(_atk)
        return


    var _distance: int = global_position.distance_to(attack_target.global_position)
    bs_soldier_prop.update_hit_ratio_by_min_max(_distance)

    attack_target.hurt(
        get_atk(), bs_soldier_prop.get_attack_type(),
        self,
        attack_target.global_position - self.global_position,
        bs_soldier_prop.weapon_special_attr_dic
    )

func handle_firearm_trajectory_detect_area()-> void:
    if check_enemy_die():
        var success = search_enemy()
        if not success:
            return

    var _traj_target: Vector2
    if is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):
        _traj_target = attack_target.global_position
    else:
        _traj_target = attack_target.get_hurt_box_position()
    firearm_trajectory_detect_tool_node.set_detect_area(
        _get_firearm_shoot_position(),
        _traj_target,
        body_direction == CommonConstants.DIRECTION_ENUM.LEFT
    )

func check_enemy_die()-> bool:
    return SoldierUtils.is_not_living_by_soldier_node(attack_target)


func handle_check_allow_attack()-> bool:
    if check_enemy_die():


        handle_search_enemy()
        return false


    if attack_target != null and is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):

        if attack_target.has_meta("is_arrow_tower") or attack_target.has_meta("is_small_wooden_wall"):
            var _obs_dist: float = global_position.distance_to(attack_target.global_position)
            if _obs_dist < get_attack_range():
                return true
            elif _obs_dist < get_want_attack_range():
                change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY)
                return false
            else:
                if not is_allow_mobile_shooting():
                    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
                return false

        var _wx: float = attack_target.global_position.x
        var _dist_to_surface: float = abs(global_position.x - _wx) - 100.0
        if _dist_to_surface < get_attack_range():
            return true
        elif _dist_to_surface < get_want_attack_range():
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY)
            return false
        else:
            if not is_allow_mobile_shooting():
                change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
            return false

    if CommonUtils.in_scope(self, attack_target, get_attack_range()):
        return true
    elif CommonUtils.not_in_scope(self, attack_target, get_attack_range()) \
    and CommonUtils.in_scope(self, attack_target, get_want_attack_range()):

        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY)
        return false
    else:

        if not is_allow_mobile_shooting():
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)

        return false



func handle_check_allow_attack_and_maybe_remote_to_close_in():

    if not bs_soldier_prop.check_shot_count_enough():

        prepare_action = BSSoldierConstants.PREPARE_ACTION_ENUM.MAIN_WEAPON_BREAK
        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE)
        return

    var _flag = handle_check_allow_attack()
    if _flag:

        if not is_mobile_shooting_action \
        and CommonUtils.in_scope(self, attack_target, BSSoldierConfig.CHANGE_CLOSE_IN_WEAPON_DISTANCE):

            _maybe_change_weapon_remote_to_close_in()

func hurt(
    _damage, _attack_type_enum,


    _origin_soldier_node: BSSoldier,
    _attack_vector: Vector2,

    _weapon_special_attr_dic = null,

    _is_lance_or_set_pike: = false,

    _is_ignore_block: = false
):




    if _origin_soldier_node == null or not is_instance_valid(_origin_soldier_node):
        return

    _damage *= SoldierUtils.get_morale_damage_ratio(_origin_soldier_node.bs_group)


    if GlobalNode._mod_village_guard_active and _origin_soldier_node.is_in_group("bs_enemy") and not self.is_in_group("bs_player"):
        _damage = int(ceil(_damage * 1.45))

    var _origin_bs_soldier_prop = _origin_soldier_node.bs_soldier_prop
    if SoldierUtils.is_not_living_by_soldier_node(self):
        return


    if mod_boss_invulnerable:
        return


    if simple_json.has("uid") and simple_json.uid == "mod_boss_conquest_knight" and mod_boss_phase == 3:
        if CommonUtils.prob_true(0.5):
            if GlobalPlayerConfig.is_show_damage_text and counter % BattleSceneConfig.SHOW_DAMAGE_LABEL_WEIGHT == 0:
                call_deferred("_show_damage_label_miss")
            return

    if CommonUtils.prob_true(1 - _origin_bs_soldier_prop.hit_ratio):
        if GlobalPlayerConfig.is_show_damage_text and counter % BattleSceneConfig.SHOW_DAMAGE_LABEL_WEIGHT == 0:
            call_deferred("_show_damage_label_miss")

        return



    if _damage > 0 and _mod_swallow_dodge_try(_origin_soldier_node, _attack_vector):
        if GlobalPlayerConfig.is_show_damage_text and counter % BattleSceneConfig.SHOW_DAMAGE_LABEL_WEIGHT == 0:
            call_deferred("_show_damage_label_miss")
        return



    if _origin_bs_soldier_prop.knock_back > 0 and SoldierUtils.is_infantry(self.bs_soldier_prop):
        be_knock_back(_attack_vector.normalized() * _origin_bs_soldier_prop.knock_back * BSSoldierConfig.WEAPON_KNOCK_BACK_MULT)


    var _is_back_attack = false
    var _attack_direction = CommonConstants.DIRECTION_ENUM.RIGHT
    if _attack_vector.x < 0:
        _attack_direction = CommonConstants.DIRECTION_ENUM.LEFT

    if _attack_direction == move_direction:
        _is_back_attack = true


    var _shield_damage_ratio: float = CommonUtils.get_value(_weapon_special_attr_dic, "shield_pierce", 1.0)

    var _is_block = false

    if not _is_back_attack and not _is_ignore_block and bs_soldier_prop.block_prob > 0 and CommonUtils.prob_true(bs_soldier_prop.block_prob):

        var _shield_damage: = int(_damage * _shield_damage_ratio)
        if CommonUtils.prob_true(CommonUtils.get_value(_weapon_special_attr_dic, "shield_break_ratio", 0.0)):
            _shield_damage = 100000


        var _is_break = bs_soldier_prop.vice_hurt_and_check_is_break(_shield_damage)
        if _is_break:

            call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DEF_BREAK)

            bs_soldier_prop.delete_vice_weapon()
            _init_weapon_skin()
        else:

            if _shield_damage_ratio > 1.0:
                call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.SHIELD_PIERCE)
            else:
                call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DEF)


        _is_block = true


    if _is_back_attack and not _is_ignore_block and bs_soldier_prop.b_block_prob > 0 and CommonUtils.prob_true(bs_soldier_prop.b_block_prob):

        var _shield_damage: = int(_damage * _shield_damage_ratio)
        if CommonUtils.prob_true(CommonUtils.get_value(_weapon_special_attr_dic, "shield_break_ratio", 0.0)):
            _shield_damage = 100000


        var _is_break = bs_soldier_prop.b_vice_hurt_and_check_is_break(_shield_damage)
        if _is_break:

            call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DEF_BREAK)

            bs_soldier_prop.delete_b_vice_weapon()
            _init_weapon_skin()
        else:

            if _shield_damage_ratio > 1.0:
                call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.SHIELD_PIERCE)
            else:
                call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DEF)


        _is_block = true


    if _weapon_special_attr_dic == null:
        _weapon_special_attr_dic = {}









    if _is_block:
        _damage = 0











    var _is_crit = false
    if CommonUtils.prob_true(_origin_bs_soldier_prop.crit_prob):
        _damage *= _origin_bs_soldier_prop.crit_atk_ratio
        _is_crit = true

    var _pre_hp: = hp


    if _damage > 0:

        var _damage_addition_ratio = 0
        if _is_back_attack:
            _damage_addition_ratio = BSSoldierConfig.BACK_ATTACK_ADDITION_RATIO


        if _weapon_special_attr_dic.has("attack_bonus_cavalvy") and SoldierUtils.is_cavalry(bs_soldier_prop):
            _damage_addition_ratio += _weapon_special_attr_dic.attack_bonus_cavalvy


        if _origin_bs_soldier_prop.melee_damage_to_stunned_target_plus > 0 \
        and get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN \
        and _attack_type_enum == WeaponTypeConstants.ATTACK_TYPE_ENUM.CLOSE_IN:
            _damage_addition_ratio += _origin_bs_soldier_prop.melee_damage_to_stunned_target_plus

        var _def = bs_soldier_prop.def

        if _is_crit:
            _def = bs_soldier_prop.crit_def


        if _weapon_special_attr_dic.has("ignore_def"):
            _def -= _weapon_special_attr_dic.ignore_def
            if _def < 0:
                _def = 0


        if _weapon_special_attr_dic.has("mod_fear_weapon") and mod_fear_value > 0:
            _def -= int(mod_fear_value * 2.5)
            if _def < 0:
                _def = 0

        _damage = SoldierUtils.get_damage(_damage, _def)











        if _damage > 0 and enemy_attack_intent_count > 1 \
        and simple_json.has("uid") and simple_json.uid == "mod_lord_hero_0002":
            var _mod_pressure_ratio: float = min(float(enemy_attack_intent_count - 1) * 0.12, 0.48)
            _damage = int(_damage *(1.0 - _mod_pressure_ratio))


        if _attack_type_enum == WeaponTypeConstants.ATTACK_TYPE_ENUM.REMOTE and bs_soldier_prop.remote_hurt_plus != 0.0:
            var _ratio: float = 1 + bs_soldier_prop.remote_hurt_plus
            if _ratio < 0:
                _ratio = 0
            _damage = int(_damage * _ratio)


        if _is_lance_or_set_pike and bs_soldier_prop.cavalry_charge_damage_plus > 0:
            _damage = int(_damage *(1 + bs_soldier_prop.cavalry_charge_damage_plus))
            _damage_addition_ratio = _damage_addition_ratio *(1 + bs_soldier_prop.cavalry_charge_damage_plus)

        hp -= _damage
        var _addition_damage = null
        if _damage_addition_ratio > 0:
            _addition_damage = int(_damage * _damage_addition_ratio)
            hp -= _addition_damage


        if _damage > 0 and _attack_type_enum == WeaponTypeConstants.ATTACK_TYPE_ENUM.CLOSE_IN:
            if _origin_soldier_node.bs_soldier_prop.skill_special_vampire > 0:
                _origin_soldier_node._mod_apply_vampire_lifesteal()

        if GlobalPlayerConfig.is_show_damage_text:
            call_deferred("_show_damage_label", _damage, _is_crit, _addition_damage)


        var _effect_name = BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.HURT
        if _attack_type_enum == WeaponTypeConstants.ATTACK_TYPE_ENUM.REMOTE:
            _effect_name = BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.BOW_HURT

        call_deferred("_body_effect_add", _effect_name)

        if bs_soldier_avatar_tag_instance != null:
            bs_soldier_avatar_tag_instance.update_progress(bs_soldier_prop.hp_max, hp)

            hurt_sign.emit()


        call_deferred("_update_injured_effect")

    if _is_lance_or_set_pike:

        call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.LANCE_ATTACK)

    if hp > 0:



        if _damage > 0 and _weapon_special_attr_dic.has("mod_fear_weapon") and CommonUtils.is_not_null(_origin_soldier_node) and is_instance_valid(_origin_soldier_node):
            var _fear_count = _mod_count_fear_equipment(_origin_soldier_node)

            _fear_count += 1
            if _fear_count > 0:
                var _fear_add = float(_damage) * float(_fear_count) / 3.5
                mod_fear_value += _fear_add





        var _mod_iai_stun_mode: int = 0
        if CommonUtils.is_not_null(_origin_soldier_node) and is_instance_valid(_origin_soldier_node) \
        and _origin_soldier_node.bs_soldier_prop.weapon_special_attr_dic.has("iai_cut"):
            if _origin_soldier_node.mod_iai_dashing:
                _mod_iai_stun_mode = 1 if _origin_soldier_node.mod_iai_is_big else 2
            else:
                _mod_iai_stun_mode = 2
        var _mod_iai_stun_ok: bool = true
        if _mod_iai_stun_mode == 2:
            _mod_iai_stun_ok = _is_crit

        if _mod_iai_stun_ok \
        and(_mod_iai_stun_mode == 1 or CommonUtils.prob_true(_origin_bs_soldier_prop.stun_prop)):
            stun_counter = _origin_bs_soldier_prop.stun_second * 60
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN)

            var _slow_ratio = CommonUtils.get_value(_weapon_special_attr_dic, "post_stun_slow_ratio", 0.0)
            var _slow_seconds = CommonUtils.get_value(_weapon_special_attr_dic, "post_stun_slow_seconds", 0.0)
            if _slow_ratio > 0.0 and _slow_seconds > 0.0:
                post_stun_slow_ratio = _slow_ratio
                post_stun_slow_counter = int((_origin_bs_soldier_prop.stun_second + _slow_seconds) * 60)
            return


        if _attack_type_enum == WeaponTypeConstants.ATTACK_TYPE_ENUM.CLOSE_IN \

        and status_machine_node.get_action_status() != BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE:
            if _origin_soldier_node != null and SoldierUtils.is_living_by_soldier_node(_origin_soldier_node):
                var is_change_to_colse_in: = _maybe_change_weapon_remote_to_close_in()
                if is_change_to_colse_in:
                    self._set_attack_target(_origin_soldier_node)


        if _damage > 0:
            _handle_maybe_apply_panic_buff(_origin_soldier_node, _attack_type_enum)

            custom_maybe_injured_chat(hp, _pre_hp, bs_soldier_prop.hp_max)

            if CommonUtils.prob_true(_origin_soldier_node.bs_soldier_prop.armor_pen_5_seconds_rate):
                var _prop_config: Dictionary = GoodsUtils.get_prop_config("armor_pen_5_seconds_rate")
                _add_buff(_prop_config.buff_type_enum, _prop_config.buff_props)

    else:


        if simple_json.has("uid") and simple_json.uid == "mod_boss_conquest_knight" and mod_boss_phase < 4:
            mod_boss_phase += 1
            mod_boss_invulnerable = true
            _mod_boss_phase_transition()
            return


        if simple_json.has("uid") and simple_json.uid == "mod_boss_conquest_knight" and mod_boss_phase >= 4 and not mod_boss_final_death_triggered:
            mod_boss_final_death_triggered = true
            mod_boss_invulnerable = true
            hp = 1

            if CommonUtils.is_not_null(_origin_soldier_node):
                murderer_bgroup = _origin_bs_soldier_prop.bs_group
            _set_attack_target(null)

            living_status = BSSoldierConstants.LIVING_STATUS_ENUM.DEATH
            _clear_enemy_targets()
            collision_shape_2d_node.set_deferred("disabled", true)
            hurt_box_node.set_deferred("monitoring", false)
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
            print("[Mod] BOSS征伐骑士四阶段死亡, 5秒后真正死亡")
            var _death_tween = get_tree().create_tween()
            _death_tween.tween_property(self, "modulate:a", 0.0, 0.5)
            _death_tween.tween_interval(4.5)
            _death_tween.tween_callback(_mod_boss_final_death)
            return

        if CommonUtils.is_not_null(_origin_soldier_node):
            _origin_soldier_node.kill_soldier_hook(_weapon_special_attr_dic)

        custom_die_chat()

        self.hp = 0


        if SoldierUtils.is_conquest_knight_soldier(simple_json):
            equipment_capture_prob = 0.0
        else:
            equipment_capture_prob = _origin_bs_soldier_prop.capture_prob

        murderer_bgroup = _origin_bs_soldier_prop.bs_group
        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIEING)


        if _weapon_special_attr_dic != null and _weapon_special_attr_dic.has("mod_fear_weapon"):
            _mod_add_fear_to_team(50.0)


        if SoldierUtils.is_hero_or_leader2(self) and CommonUtils.is_not_null(_origin_soldier_node):
            var _hero_name = ""
            if is_hero() and is_leader():

                _hero_name = get_soldier_name()

            _origin_soldier_node.custom_kill_hero_chat(_hero_name)

func get_soldier_name()-> String:
    return bs_soldier_prop.name




































































































































































































func close_collision(_close_self_collision: = true):

    if _close_self_collision:
        collision_shape_2d_node.set_deferred("disabled", true)

    ray_detect_node.delaunch_detect()
    _close_horse_collision_area_check()

func close_collision_shallow():
    self.set_deferred("collision_mask", 0)

func open_collision_shallow():
    self.set_deferred("collision_mask", origin_collision_mask)


func stop_service():
    _handle_die_water()

    hurt_box_node.set_deferred("monitoring", false)
    hurt_box_node.get_node("CollisionShape2D").disabled = true
    collision_shape_2d_node.set_deferred("disabled", true)






    status_machine_node.set_physics_process(false)
    wait_effect_node.hide()
    wait_effect_animation_node.stop()
    target_line_node.stop()
    flee_timer_node.stop()






    set_physics_process(false)

func stop_animation():
    action_animation_node.stop()


func search_enemy():


    if guard_rect.has_area() and not guard_rect.has_point(global_position) and bs_soldier_prop.is_use_remote_weapon:
        return false

    if GlobalNode.battle_scene.scene_mode == BattleConstants.BATTLE_SCENE_MODE_ENUM.FORMATION_MODE:
        return false


    if(is_in_group("bs_player") or is_in_group("bs_teammate")) and GlobalNode._mod_is_wooden_wall_alive():
        var _wall_target: StaticBody2D = GlobalNode._mod_get_wooden_wall_target_node()
        if _wall_target != null:
            var _wall_pos: Vector2 = _wall_target.global_position
            var _dist_to_surface: float = abs(global_position.x - _wall_pos.x) - 100.0
            if _dist_to_surface < get_want_attack_range() or global_position.distance_to(_wall_pos) < get_want_attack_range():
                _set_attack_target(_wall_target)
                return true

    var _enemy_node = _physics_shape_search(get_want_attack_range())

    if _enemy_node != null and is_instance_valid(_enemy_node) and _enemy_node.has_meta("is_wooden_wall"):
        if _enemy_node.has_meta("is_arrow_tower") or _enemy_node.has_meta("is_small_wooden_wall"):
            _enemy_node = null
    _set_attack_target(_enemy_node)

    if _enemy_node == null:
        return false
    else:
        return true

func get_move_speed():
    var _speed = bs_soldier_prop.move_speed

    if post_stun_slow_counter > 0 and stun_counter <= 0:
        _speed = _speed *(1.0 - post_stun_slow_ratio)
    return _speed

func get_atk():
    return bs_soldier_prop.atk


func _mod_apply_vampire_lifesteal()-> void:

    if hp <= 0:
        return
    var _heal: int = SoldierUtils.get_vampire_lifesteal_by_strength(bs_soldier_prop)
    if _heal <= 0:
        return

    if hp >= bs_soldier_prop.hp_max:
        call_deferred("_show_heal_label", _heal)
        return
    hp = min(hp + _heal, bs_soldier_prop.hp_max)
    if bs_soldier_avatar_tag_instance != null:
        bs_soldier_avatar_tag_instance.update_progress(bs_soldier_prop.hp_max, hp)

    call_deferred("_show_heal_label", _heal)


func _mod_start_savage_bite()-> void:
    mod_bite_target = attack_target
    mod_bite_active = true
    mod_bite_counter = 0

    var _dir: Vector2 =(global_position - mod_bite_target.global_position).normalized()
    if _dir == Vector2.ZERO:
        _dir = Vector2.LEFT
    mod_bite_offset = _dir * MOD_BITE_STICK_DIST

    empty_move_target()
    stop_move()
    status_machine_node.stop()

    _mod_do_one_bite()


func _mod_bite_process()-> void:

    if not SoldierUtils.is_living(living_status):
        _mod_end_savage_bite()
        return

    if stun_counter > 0:
        _mod_end_savage_bite()
        return

    if mod_bite_target == null or not is_instance_valid(mod_bite_target) \
    or not SoldierUtils.is_living_by_soldier_node(mod_bite_target):
        _mod_end_savage_bite()
        return


    var _stick_pos: Vector2 = mod_bite_target.global_position + mod_bite_offset
    if GlobalNode.battle_scene.check_out_map_edge(_stick_pos):
        _stick_pos = mod_bite_target.global_position
    global_position = _stick_pos
    velocity = Vector2.ZERO

    knock_back_vector = Vector2.ZERO

    update_direction2(mod_bite_target.global_position - global_position)

    mod_bite_counter += 1
    if mod_bite_counter >= MOD_BITE_INTERVAL_FRAMES:
        mod_bite_counter = 0
        _mod_do_one_bite()


func _mod_do_one_bite()-> void:
    if mod_bite_target == null or not is_instance_valid(mod_bite_target):
        _mod_end_savage_bite()
        return

    play_attack_animation(get_attack_animation_name_enum())
    _play_attack_sfx()

    var _bite_damage: int = int(bs_soldier_prop.base_strength * 2.5)
    if _bite_damage <= 0:
        return
    var _pre_hp: int = mod_bite_target.hp
    mod_bite_target.hurt(
        _bite_damage, bs_soldier_prop.get_attack_type(),
        self,
        mod_bite_target.global_position - global_position,
        {},
        false,
        false
    )

    var _real_damage: int = _pre_hp - mod_bite_target.hp
    if _real_damage > 0 and hp > 0:

        if hp < bs_soldier_prop.hp_max:
            hp = min(hp + _real_damage, bs_soldier_prop.hp_max)
            if bs_soldier_avatar_tag_instance != null:
                bs_soldier_avatar_tag_instance.update_progress(bs_soldier_prop.hp_max, hp)

        call_deferred("_show_heal_label", _real_damage)





func _mod_end_savage_bite()-> void:
    if not mod_bite_active:
        return
    mod_bite_active = false
    mod_bite_target = null
    mod_bite_counter = 0
    status_machine_node.start()
    if stun_counter > 0:
        return
    if not SoldierUtils.is_living(living_status):
        return
    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
    stop_move()

func get_attack_range():

    if is_mobile_shooting_action:
        return bs_soldier_prop.attack_range_mobile_shooting
    else:

        var _iai_extra: int = _mod_get_iai_engage_extra_range()
        if _iai_extra > 0:
            return bs_soldier_prop.attack_range + _iai_extra
        return bs_soldier_prop.attack_range

func get_want_attack_range():

    if is_charge:
        return GlobalNode.battle_scene.get_max_xy()

    if is_mobile_shooting_action:
        return bs_soldier_prop.want_attack_range_mobile_shooting
    else:
        return bs_soldier_prop.want_attack_range

func get_attack_range_square():

    if is_mobile_shooting_action:
        return bs_soldier_prop.attack_range_square_mobile_shooting
    else:




        return bs_soldier_prop.attack_range_square

func get_attack_range_small_square()-> int:

    var _iai_extra: int = _mod_get_iai_engage_extra_range()
    if _iai_extra > 0:
        var _extend_range: int = bs_soldier_prop.attack_range + _iai_extra
        return int(pow(_extend_range - 10, 2))
    return bs_soldier_prop.attack_range_small_square

func get_action_status():
    return status_machine_node.get_action_status()




func get_main_weapon_json()-> Dictionary:
    return bs_soldier_prop.main_weapon_json


func handle_attack_direction():
    if attack_target == null:
        return;

    target_origin_vector = attack_target.global_position - self.global_position
    update_direction();


func handle_attack_direction_for_body():
    if attack_target == null:
        return;

    target_origin_vector = attack_target.global_position - self.global_position
    update_direction(true);


func flyer_root_disappear():
    append_animation_node.play("flyerRootDisappear")


func reach():
    stop_move()
    if force_direction != null:
        update_direction3(force_direction)
        force_direction = null

func stop_move():
    velocity = Vector2.ZERO

func get_attack_animation_name_enum():


    var _anim_override: String = CommonUtils.get_value(bs_soldier_prop.main_weapon_json, "mod_attack_animation", "")
    if _anim_override != "":
        return BSSoldierConstants.ANIMATION_NAME_ENUM.get(_anim_override)
    return BSSoldierConstants.ANIMATION_NAME_ENUM.get(bs_soldier_prop.main_weapon_json.animation_name_enum)

func start_wait_effect():

    wait_effect_node.show()


    wait_effect_animation_node.play("prepare")


func prepare_finish():
    wait_effect_node.hide()

    if not SoldierUtils.is_living(living_status):
        return

    if[BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN].has(get_action_status()):

        return;



    if prepare_action == null:
        printerr("prepare_action == null")

    match prepare_action:
        BSSoldierConstants.PREPARE_ACTION_ENUM.CHANGE_WEAPON:

            _change_weapon(prep_change_weapon_user_type)
            if move_target != Vector2.ZERO and move_mode == BSSoldierConstants.MOVE_MODE_ENUM.DIRECT_MOVE:

                change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE)
            else:
                handle_search_enemy()


        BSSoldierConstants.PREPARE_ACTION_ENUM.MAIN_WEAPON_BREAK:
            var _change_weapon_result = bs_soldier_prop.delete_main_weapon_and_choose_weapon()
            var _change_weapon_uid = _get_change_weapon_uid(_change_weapon_result)

            _init_weapon_skin(_change_weapon_uid)
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
        BSSoldierConstants.PREPARE_ACTION_ENUM.PLACE_L_SHIELD:


            var _l_shield_json = bs_soldier_prop.handle_place_l_shield_data()
            _init_weapon_skin()

            _place_l_shield(_l_shield_json)
            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.ATTACK)


        BSSoldierConstants.PREPARE_ACTION_ENUM.PICK_L_SHIELD:


            if CommonUtils.is_not_null(l_shield_place_instance):
                var _l_shield_json = l_shield_place_instance.l_shield_json

                bs_soldier_prop.pick_l_shield(_l_shield_json)
                _init_weapon_skin()

                l_shield_place_instance.disappear()
                l_shield_place_instance = null


            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)


    _prepare_finish_reset_data()

func is_cavalry():
    return bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.CAVALRY

func is_infantry():
    return not is_cavalry();

func horse_disappear_finish():
    horse_node.hide()
    harmour_node.hide()
    horse_animation_node.stop()


func horse_disappear():
    horse_disappear_animation_node.play("horse_disappear")

var before_mult: = 1.0



func update_speed_mult(_mult, _greater_than_before = null)-> bool:
    if _greater_than_before != null:


        if _greater_than_before and _mult < before_mult:
            return false
        elif not _greater_than_before and _mult > before_mult:
            return false

    if not SoldierUtils.is_living_by_soldier_node(self):
        return false

    bs_soldier_prop.update_speed_mult(_mult)

    if _mult > before_mult:
        bs_soldier_prop.enable_weapon(WeaponTypeConstants.STYPE_ENUM.OH_LANCE, true)
        call_deferred("_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.BUFF_ACCELERATION, buff_icon_root_node)
    elif _mult < before_mult:
        call_deferred("_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.BUFF_DECELERATION, buff_icon_root_node)

    before_mult = _mult


    if bs_soldier_prop.main_weapon_json.stype == WeaponTypeConstants.STYPE_ENUM.OH_LANCE and _mult < 1.0:
        bs_soldier_prop.enable_weapon(WeaponTypeConstants.STYPE_ENUM.OH_LANCE, false)
        _change_weapon_prepare()

    return true

func update_horse_animation_speed(_mult: float):
    horse_animation_node.speed_scale = _mult






func _mod_is_forest_swallow_hero()-> bool:
    return simple_json != null and simple_json.has("uid") and simple_json.uid == "mod_lord_hero_0002"

func mod_forest_swallow_enter()-> bool:


    if not _mod_is_forest_swallow_hero():
        return false
    _mod_forest_swallow_block_count += 1
    if _mod_forest_swallow_block_count == 1 and not _mod_forest_swallow_in_forest:
        _mod_forest_swallow_in_forest = true
        _mod_forest_swallow_attack_speed_origin = bs_soldier_prop.attack_speed
        bs_soldier_prop.attack_speed = _mod_forest_swallow_attack_speed_origin *(1.0 + MOD_FOREST_SWALLOW_ATTACK_SPEED_BONUS)
    return true

func mod_forest_swallow_exit()-> bool:


    if not _mod_is_forest_swallow_hero():
        return false
    if _mod_forest_swallow_block_count > 0:
        _mod_forest_swallow_block_count -= 1
    if _mod_forest_swallow_block_count == 0 and _mod_forest_swallow_in_forest:
        _mod_forest_swallow_in_forest = false
        bs_soldier_prop.attack_speed = _mod_forest_swallow_attack_speed_origin
    return true

func flat_lance_finish():
    play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.LANCE_MOVE)









func be_knock_back(_knock_back_vector):
    knock_back_vector = _knock_back_vector


func lance_pack_up_finish():


    _change_weapon(WeaponTypeConstants.USER_TYPE_ENUM.CLOSE_IN_SWITCH)
    handle_search_enemy()


func add_die_blood_effect(_x: int):
    var soldier_body_effect_instance = soldier_body_effect_node.instantiate()
    die_blood_root_node.add_child(soldier_body_effect_instance)
    soldier_body_effect_instance.position.x = _x
    soldier_body_effect_instance.animation_play(BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DIE_BLOOD)

func set_living_status(_living_status):
    living_status = _living_status


func change_weapon_to_close_in():




    _change_weapon_prepare(WeaponTypeConstants.USER_TYPE_ENUM.CLOSE_IN_SWITCH)


func show_stun_effect():




    stun_effect_node = _effect_add(
            BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.STUN,
            damage_root_node
        )

func hide_effect():
    hide_stun_effect()
    choose_effect_node.hide()

func hide_stun_effect():
    if stun_effect_node == null:
        return

    stun_effect_node.queue_free()
    stun_effect_node = null

func hero_tag_disappear():
    if bs_soldier_avatar_tag_instance != null:
        bs_soldier_avatar_tag_instance.disappear()

func choose():
    choose_effect_node.show()

func unchoose():
    choose_effect_node.hide()


func emit_die_sign(_is_flee_success: = false):

    emit_signal("soldier_die_sign", self.bs_group, simple_json, murderer_bgroup, _is_flee_success, self)


func charge(_show_icon: bool = false)-> void:
    if want_flee:
        return

    if _show_icon:
        _create_charge_icon()


    if move_target != Vector2.ZERO:
        move_and_se(move_target)

    move_mode = BSSoldierConstants.MOVE_MODE_ENUM.MAS_MOVE
    is_charge = true

    custom_charge_chat()

func is_leader()-> bool:
    return bs_soldier_prop.is_leader


func custom_charge_chat()-> void:
    pass


func custom_move_chat()-> void:
    pass


func custom_attack_chat()-> void:
    pass


func custom_kill_hero_chat(_target_hero_name: String)-> void:
    pass

func custom_maybe_injured_chat(
    _hp: int, _pre_hp: int,
    _hp_max: int
)-> void:
    pass

func custom_die_chat()-> void:
    pass

func custom_ai_charge_chat()-> void:
    pass

func custom_ai_defensive_chat()-> void:
    pass

func custom_ai_advancing_attack_chat()-> void:
    pass

func custom_vectory_chat()-> void:
    pass

func add_chat(_content: String)-> void:
    for _node: BattleChatBubble in chat_root_node.get_children():
        _node.chide()

    var _node: = BATTLE_CHAT_BUBBLE.instantiate()
    chat_root_node.add_child(_node)
    GlobalNode.battle_scene.connect("change_zoom_sign", _node.change_zoom)
    _node.change_zoom_by_x(GlobalNode.battle_scene.get_camera_zoom())

    _custom_init_chat_bubble(_node, _content)

func _custom_init_chat_bubble(_battle_chat_bubble_node: BattleChatBubble, _content: String)-> void:
    _battle_chat_bubble_node.init(_content, 4)

func get_star()-> int:
    return bs_soldier_prop.star

func cancel_charge()-> void:
    if is_charge:
        is_charge = false



func maybe_change_weapon_remote():
    var _flag = false



    var _target_living = SoldierUtils.is_living_by_soldier_node(attack_target)
    if not _target_living \
    or not CommonUtils.in_scope(self, attack_target, BSSoldierConfig.CHANGE_CLOSE_IN_WEAPON_DISTANCE * 2):
        _flag = bs_soldier_prop.is_allow_change_weapon_remote()
        if _flag:



            _change_weapon_prepare(WeaponTypeConstants.USER_TYPE_ENUM.REMOTE_SWITCH)

    return _flag


func lance_maybe_break():
    var _prob = bs_soldier_prop.main_weapon_json.lance_break_prob
    if CommonUtils.prob_true(_prob):
        _effect_add(
            BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.LANCE_BREAK,
            lance_break_effect_root_node
        )





        bs_soldier_prop.delete_main_weapon()

        return BSSoldierConstants.ANIMATION_NAME_ENUM.LANCE_PACK_UP_BREAK
    else:
        return BSSoldierConstants.ANIMATION_NAME_ENUM.LANCE_PACK_UP

func is_allow_mobile_shooting():
    return bs_soldier_prop.is_allow_mobile_shooting


func save():

    simple_json.hp = self.hp
    simple_json.living_status = self.living_status








func handle_living_status_death():
    var _change_to_living_status = BSSoldierConstants.LIVING_STATUS_ENUM.DEATH


    if SoldierUtils.is_conquest_knight_soldier(simple_json):
        self.set_living_status(_change_to_living_status)
        return

    if SoldierUtils.is_hero(self):

        _change_to_living_status = BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY


    elif equipment_capture_prob > 0.001 and CommonUtils.prob_true(equipment_capture_prob):


        call_deferred("_effect_add_capture")

        _change_to_living_status = BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY
    else:

        if CommonUtils.prob_true(BSSoldierConfig.DEFAULT_SERIOUS_INJURY_PROP):
            _change_to_living_status = BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY

    self.set_living_status(_change_to_living_status)


func focus_effect():
    _effect_add(
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.FOCUS_EFFECT,
        focus_effect_root_node
    )


func set_attack_target_list(_node_list: Array)-> void:
    if not SoldierUtils.is_living(living_status):
        return

    _node_list.shuffle()

    for _node in _node_list:
        if _node == null or not is_instance_valid(_node):
            continue
        if not _node.has_meta("is_wooden_wall"):
            if CommonUtils.in_scope(self, _node, get_attack_range()):
                _set_attack_target(_node)
                return


    for _node in _node_list:
        if _node == null or not is_instance_valid(_node):
            continue
        if _node.has_meta("is_wooden_wall"):
            if CommonUtils.in_scope(self, _node, get_want_attack_range()):
                _set_attack_target(_node)
                change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY)
                return


    _set_attack_target(null)


func handle_enter_flee():
    is_fleeing = true
    choose_effect_node.hide()
    _effect_add(BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.FLEE_EFFECT, change_weapon_tag_root_node)

    _main_weapon_disappear()

    flee_timer_node.start()


func handle_flee_success():
    var _tween = get_tree().create_tween()
    _tween.tween_property(self, "modulate", Color(1, 1, 1, 0), 0.5)

    set_living_status(BSSoldierConstants.LIVING_STATUS_ENUM.FLEE_SUCCESS)
    close_collision()
    stop_service()


    if mod_fear_triggered_flee:
        _mod_add_fear_to_team(125.0)

    emit_die_sign()


func change_weapon_tag_root_disappear():
    var _tween = get_tree().create_tween()
    _tween.tween_property(change_weapon_tag_root_node, "modulate", Color(1, 1, 1, 0), 0.5)


func horse_collision_area_lance_mode():
    _open_horse_collision_area_check()



func horse_collision_area_common_mode():
    if not GameConfig.OPEN_CAVALRY_IMPACT_COLLIDER:
        _close_horse_collision_area_check()





func maybe_set_pike(_target_soldier_node: BSSoldier):
    if not bs_soldier_prop.allow_pike():
        return


    if not SoldierUtils.is_living_by_soldier_node(self):
        return
    if[
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN,

    ].has(status_machine_node.get_action_status()):
        return

    _set_attack_target(_target_soldier_node)

    _pike_sign(_target_soldier_node)
    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.SET_PIKE)

func add_set_pike_effect():
    call_deferred("_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.SET_PIKE, buff_icon_root_node)

func add_pick_pike_effect():
    call_deferred("_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.PICK_PIKE, buff_icon_root_node)


func maybe_spike_hurt():
    if attack_target != null and is_instance_valid(attack_target) and not attack_target.has_meta("is_wooden_wall"):
        attack_target.maybe_spike_attack(self)


func maybe_spike_attack(_target_node: BSSoldier):

    if not status_machine_node.get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.SET_PIKE:
        return


    if _target_node.move_direction == move_direction:
        return

    _set_attack_target(_target_node)
    attack(BSSoldierConfig.SET_PICK_DAMAGE_MULT, true, true)

func check_pike_sign():
    for _index in range(pike_sign_node_list.size() - 1, -1, -1):
        var _node: BSSoldier = pike_sign_node_list[_index]
        if _node.get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE \



        or not[
                BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_MOVE,
                BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_PACK_UP,
                BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIEING,
            ].has(_node.get_action_status()):
            pike_sign_node_list.remove_at(_index)

    return ArrayUtils.is_empty(pike_sign_node_list)

func get_uid()-> String:
    return simple_json.uid

func get_split_group_uid()-> String:
    return bs_soldier_prop.split_group_uid

func update_allow_remote(_allow_remote: bool)-> void:
    if not SoldierUtils.is_living_by_soldier_node(self):
        return

    bs_soldier_prop.update_allow_remote(_allow_remote)

    if bs_soldier_prop.is_use_remote_weapon and not _allow_remote:
        change_weapon_to_close_in()

func enter_shoal()-> void:
    in_water = true

    var _tween = get_tree().create_tween()
    _tween.tween_property(shadow_node, "modulate", Color(1, 1, 1, 0), 0.4)
    _tween.parallel().tween_property(choose_effect_node, "modulate", Color(1, 1, 1, 0.6), 0.4)

    if SoldierUtils.is_cavalry(bs_soldier_prop):
        _tween.parallel().tween_property(cavalry_water_mask_node, "modulate", Color(1, 1, 1, 1), 0.4)
        _tween.parallel().tween_property(b_cavalry_water_mask_node, "modulate", Color(1, 1, 1, 1), 0.4)
        _tween.parallel().tween_property(cavalry_water_effect_node, "modulate", Color(1, 1, 1, 1), 0.4)
    else:
        _tween.parallel().tween_property(infantry_water_mask_node, "modulate", Color(1, 1, 1, 1), 0.4)
        _tween.parallel().tween_property(infantry_water_effect_node, "modulate", Color(1, 1, 1, 1), 0.4)

func exit_shoal()-> void:
    if not SoldierUtils.is_living_by_soldier_node(self):
        return

    in_water = false

    var tween = get_tree().create_tween()
    tween.tween_property(shadow_node, "modulate", Color(1, 1, 1, 1), 0.4)
    tween.parallel().tween_property(choose_effect_node, "modulate", Color(1, 1, 1, 1), 0.4)

    if SoldierUtils.is_cavalry(bs_soldier_prop):
        tween.parallel().tween_property(cavalry_water_mask_node, "modulate", Color(1, 1, 1, 0), 0.4)
        tween.parallel().tween_property(b_cavalry_water_mask_node, "modulate", Color(1, 1, 1, 0), 0.4)
        tween.parallel().tween_property(cavalry_water_effect_node, "modulate", Color(1, 1, 1, 0), 0.4)
    else:
        tween.parallel().tween_property(infantry_water_mask_node, "modulate", Color(1, 1, 1, 0), 0.4)
        tween.parallel().tween_property(infantry_water_effect_node, "modulate", Color(1, 1, 1, 0), 0.4)

func get_sort()-> int:
    return -1 if not simple_json.has("sort") else simple_json.sort

func handle_terrain_buff()-> void:


    if mod_boss_invulnerable:
        return

    if bs_soldier_prop.desert_resistance >= 100:
        return

    var _damage = int(
        bs_soldier_prop.hp_max * BattleSceneConfig.DESERT_BUFF_HP_DRAIN_PER_TURN_PERCENT \
        *(1 - 0.01 * bs_soldier_prop.desert_resistance)
    )
    hp -= _damage
    call_deferred("_show_damage_label", _damage, false, null)
    call_deferred("_update_injured_effect")

    if bs_soldier_avatar_tag_instance != null:
        bs_soldier_avatar_tag_instance.update_progress(bs_soldier_prop.hp_max, hp)

        hurt_sign.emit()
    if hp <= 0:
        hp = 0
        change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIEING)

func open_terrain_buff_handler()-> void:
    bs_terrain_buff_handler_node.open_func()

func close_terrain_buff_handler()-> void:
    bs_terrain_buff_handler_node.close_func()

func enemy_attack_intent_count_plus()-> void:
    enemy_attack_intent_count += 1

func enemy_attack_intent_count_subtract()-> void:
    enemy_attack_intent_count -= 1
    CommonUtils.set_text(debuf_info_node, enemy_attack_intent_count)


func is_use_melee_weapon()-> bool:
    return not bs_soldier_prop.is_use_remote_weapon


func is_use_remote_weapon()-> bool:
    return bs_soldier_prop.is_use_remote_weapon

func get_arms_small_type_enum()-> int:
    return bs_soldier_prop.arms_small_type_enum

func get_is_has_panic_buff_melee_attack_on_infantry()-> bool:
    return bs_soldier_prop.is_has_panic_buff_melee_attack_on_infantry

func get_is_has_panic_buff_camel_melee_attack()-> bool:
    return bs_soldier_prop.is_has_panic_buff_camel_melee_attack

func get_is_panic_buff_weapon_small_to_cavalry()-> bool:
    return bs_soldier_prop.is_has_panic_buff_weapon_small_to_cavalry

func get_is_panic_buff_weapon_big_to_cavalry()-> bool:
    return bs_soldier_prop.is_has_panic_buff_weapon_big_to_cavalry

func get_team_small_type()-> String:

    return CommonUtils.get_value(simple_json, "team_small_type", "")

func show_buff_icon(_buff_icon: Texture2D)-> void:
    var change_weapon_tag_instance: ChangeWeaponTag = change_weapon_tag_node.instantiate()
    change_weapon_tag_root_node.add_child(change_weapon_tag_instance)
    change_weapon_tag_instance.init_and_start_by_texture2d(_buff_icon)

func plus_atk_ratio(_ratio: float)-> void:
    bs_soldier_prop.plus_atk_ratio(_ratio)

func is_hero()-> bool:
    return SoldierUtils.is_hero(self)

func get_combat_power()-> int:
    if not SoldierUtils.is_living_by_soldier_node(self):
        return 0

    return bs_soldier_prop.combat_power

func get_json()-> Dictionary:
    return bs_soldier_prop.json

func get_hero_level()-> int:
    return bs_soldier_prop.level













func kill_soldier_hook(_weapon_special_attr_dic: Dictionary)-> void:
    pass

func _hero_kill_soldier_hook(_weapon_special_attr_dic: Dictionary)-> void:
    if _weapon_special_attr_dic.has("on_kill_atk_boost_30s") and _weapon_special_attr_dic.on_kill_atk_boost_30s > 0:

        var _prop_config: Dictionary = GoodsUtils.get_prop_config("on_kill_atk_boost_30s")
        var _buff_props: Dictionary = _prop_config.buff_props.duplicate(true)
        _buff_props.attack_plus_ratio = _weapon_special_attr_dic.on_kill_atk_boost_30s
        _add_buff(
            _prop_config.buff_type_enum,
            _buff_props
        )

    if _weapon_special_attr_dic.has("kill_guaranteed_melee_hit_seconds") and _weapon_special_attr_dic.kill_guaranteed_melee_hit_seconds > 0:

        var _prop_config: Dictionary = GoodsUtils.get_prop_config("kill_guaranteed_melee_hit_seconds")
        _add_buff(
            _prop_config.buff_type_enum,
            {
                "time_left_seconds": _weapon_special_attr_dic.kill_guaranteed_melee_hit_seconds,
                "allow_cover": true,
            }
        )


func armor_open()-> void:
    bs_soldier_prop.armor_open()


func armor_open_cancel()-> void:
    bs_soldier_prop.armor_open_cancel()

func melee_perfect_hit()-> void:
    bs_soldier_prop.melee_perfect_hit()

func cancel_melee_perfect_hit()-> void:
    bs_soldier_prop.cancel_melee_perfect_hit()



func _handle_maybe_apply_panic_buff(_origin_soldier_node: BSSoldier, _attack_type_enum: String)-> void:
    if _attack_type_enum == WeaponTypeConstants.ATTACK_TYPE_ENUM.REMOTE:
        return

    if _origin_soldier_node.get_is_panic_buff_weapon_big_to_cavalry() \
    and bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.CAVALRY:
        var _prop_config: Dictionary = GoodsUtils.get_prop_config("panic_buff_weapon_big_to_cavalry")
        _add_buff(_prop_config.buff_type_enum, _prop_config.buff_props)
        return

    if _origin_soldier_node.get_is_has_panic_buff_melee_attack_on_infantry() \
    and bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.INFANTRY:
        var _prop_config: Dictionary = GoodsUtils.get_prop_config("panic_buff_melee_attack_on_infantry")
        _add_buff(_prop_config.buff_type_enum, _prop_config.buff_props)
        return

    if _origin_soldier_node.get_is_has_panic_buff_camel_melee_attack() \

    and bs_soldier_prop.mount_type != GoodsConstants.MOUNT_TYPE_ENUM.CAMEL:
        var _prop_config: Dictionary = GoodsUtils.get_prop_config("panic_buff_camel_melee_attack")
        _add_buff(_prop_config.buff_type_enum, _prop_config.buff_props)
        return

    if _origin_soldier_node.get_is_panic_buff_weapon_small_to_cavalry() \
    and bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.CAVALRY:
        var _prop_config: Dictionary = GoodsUtils.get_prop_config("panic_buff_weapon_small_to_cavalry")
        _add_buff(_prop_config.buff_type_enum, _prop_config.buff_props)
        return

func _add_buff(
    _buff_type_enum: String,
    _buff_props: Dictionary = {}
)-> void:

    if _buff_type_enum == SoldierBuffConstants.BUFF_TYPE_ENUM.PANIC and _get_soldier_traits().has("ignore_panic_buff"):
        return

    soldier_buff_manager_node.add_buff(_buff_type_enum, _buff_props)

func _get_soldier_traits()-> Dictionary:
    return CommonUtils.get_value(bs_soldier_prop.json, "soldier_traits",{})

func _get_firearm_shoot_position()-> Vector2:
    return firearm_trajectory_detect_tool_node.global_position









func _play_main_sfx(_sfx_type_enum: BattleSFX.SFX_TYPE_ENUM, volume_ratio: = 1.0)-> void:
    var _stream = GlobalNode.battle_scene.maybe_get_sfx_steam(_sfx_type_enum)
    if CommonUtils.is_null(_stream):
        return

    main_sfx_node.stream = _stream

    main_sfx_node.volume_db =(volume_ratio * min(GlobalNode.battle_scene.get_camera_zoom() + 0.3, 1.2) - 1.0) * 40
    main_sfx_node.pitch_scale = randf_range(0.95, 1.05)
    main_sfx_node.play()

func _play_secondary_sfx(_sfx_type_enum: BattleSFX.SFX_TYPE_ENUM, volume_ratio: = 1.0)-> void:
    var _stream = GlobalNode.battle_scene.maybe_get_sfx_steam(_sfx_type_enum)
    if CommonUtils.is_null(_stream):
        return

    secondary_sfx_node.stream = _stream

    secondary_sfx_node.volume_db =(volume_ratio * min(GlobalNode.battle_scene.get_camera_zoom() + 0.3, 1.2) - 1.0) * 40
    secondary_sfx_node.pitch_scale = randf_range(0.95, 1.05)
    secondary_sfx_node.play()



func _handle_firearm_shoot_blocker(_is_direction_right: bool)-> Node2D:
    var _area_list: Array = firearm_trajectory_detect_tool_node.detect()

    if ArrayUtils.is_empty(_area_list):
        return null


    _area_list.sort_custom(func(a, b): return a.global_position.x < b.global_position.x)

    for _area_node: Area2D in _area_list:
        var _node = _area_node.owner
        if _node is BaseTree:


            if CommonUtils.prob_true(BattleSceneConfig.FLYER_BLOCKED_PROB):
                return _node
        elif _node is LShieldPlace:
            if _node.get_hurt_collision_mask() == hurt_box_node.collision_mask:

                continue

            if not _node.is_break:

                return _node
        elif _area_node.name == "AirWall" or _area_node.name == "WallTarget":

            if is_in_group("bs_player") or is_in_group("bs_teammate"):
                GlobalNode._mod_damage_wooden_wall_by_arrow(get_atk())
            return _area_node

    return null

func _bullet_trajectory_effect(_soldier_position: Vector2, _end_position: Vector2)-> void:
    GlobalNode.battle_scene.create_firearm_shoot_effect(
        _soldier_position, _end_position
    )

func _play_death_sfx()-> void:
    match bs_soldier_prop.gender:
        BSSoldierConstants.GENDER_ENUM.MALE:
            _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.MALE_DEATH, 1.0)
        _:
            _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.FEMALE_DEATH, 1.0)

func _play_body_fall_sfx()-> void:
    _play_secondary_sfx(BattleSFX.SFX_TYPE_ENUM.BODY_FALL, 0.8)

func _play_walk_sfx()-> void:
    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.WALK, 0.8)

func _play_horse_idle_sfx()-> void:
    _play_secondary_sfx(BattleSFX.SFX_TYPE_ENUM.HORSE_IDLE, 0.8)

func _play_horse_footstep_sfx()-> void:
    _play_secondary_sfx(BattleSFX.SFX_TYPE_ENUM.HORSE_FOOTSTEP, 0.7)

func _play_camel_footstep_sfx()-> void:
    _play_secondary_sfx(BattleSFX.SFX_TYPE_ENUM.CAMEL_FOOTSTEP, 1.0)

func _play_lance_hit_sfx()-> void:
    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.LANCE_HIT, 1.0)

func _play_pole_hit_sfx()-> void:
    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.ATTACK_POLE, 0.9)

func _play_blunt_hit_sfx()-> void:
    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.ATTACK_BLUNT, 0.9)

func _play_default_melee_attack_sfx()-> void:
    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.DEFAULT_MELEE_ATTACK, 0.9)

func _play_camel_idle_sfx()-> void:
    _play_secondary_sfx(BattleSFX.SFX_TYPE_ENUM.CAMEL_IDLE, 0.7)

func _play_attack_throw_sfx()-> void:
    _play_secondary_sfx(BattleSFX.SFX_TYPE_ENUM.ATTACK_THROW, 1.0)

func _play_mount_idle_sfx()-> void:
    match bs_soldier_prop.mount_type:
        GoodsConstants.MOUNT_TYPE_ENUM.HORSE:
            _play_horse_idle_sfx()
        GoodsConstants.MOUNT_TYPE_ENUM.CAMEL:
            _play_camel_idle_sfx()

func _play_mount_footstep_sfx()-> void:
    match bs_soldier_prop.mount_type:
        GoodsConstants.MOUNT_TYPE_ENUM.HORSE:
            _play_horse_footstep_sfx()
        GoodsConstants.MOUNT_TYPE_ENUM.CAMEL:
            _play_camel_footstep_sfx()

func _play_attack_sfx()-> void:
    match bs_soldier_prop.get_main_weapon_stype():
        WeaponTypeConstants.STYPE_ENUM.OH_LANCE:
            _play_lance_hit_sfx()
        WeaponTypeConstants.STYPE_ENUM.TH_POLE, WeaponTypeConstants.STYPE_ENUM.OH_POLE:
            _play_pole_hit_sfx()
        WeaponTypeConstants.STYPE_ENUM.TH_BLUNT, WeaponTypeConstants.STYPE_ENUM.OH_BLUNT:
            _play_blunt_hit_sfx()
        _:
            _play_default_melee_attack_sfx()

func _play_firearm_shoot_sfx()-> void:


    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.FIREARM_SHOOT, 0.8)

func _play_misfire_sfx()-> void:
    _play_main_sfx(BattleSFX.SFX_TYPE_ENUM.MISFIRE, 0.6)

func _has_attack_target()-> bool:
    return CommonUtils.is_not_null(attack_target)
    CommonUtils.set_text(debuf_info_node, enemy_attack_intent_count)



func _handle_die_water()-> void:
    if not in_water:
        return













    var tween = get_tree().create_tween()
    tween.tween_property(self, "modulate", Color(1, 1, 1, 0), 3)
    if SoldierUtils.is_cavalry(bs_soldier_prop):
        tween.parallel().tween_property(cavalry_water_mask_node, "modulate", Color(1, 1, 1, 0), 0.4)
        tween.parallel().tween_property(b_cavalry_water_mask_node, "modulate", Color(1, 1, 1, 0), 0.4)
    else:
        tween.parallel().tween_property(infantry_water_mask_node, "modulate", Color(1, 1, 1, 0), 0.4)

func _change_weapon_prepare(_prep_change_weapon_user_type = null):
    prep_change_weapon_user_type = _prep_change_weapon_user_type
    prepare_action = BSSoldierConstants.PREPARE_ACTION_ENUM.CHANGE_WEAPON

    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE)

func _main_weapon_disappear():
    var tween = get_tree().create_tween()
    tween.tween_property(main_weapon_node, "modulate", Color(1, 1, 1, 0), 0.5)
    tween.parallel().tween_property(bmain_weapon_node, "modulate", Color(1, 1, 1, 0), 0.5)

func _pike_sign(_node: BSSoldier):
    pike_sign_node_list.append(_node)


func _handle_check_flee():
    if want_flee:
        return


    if GlobalNode.battle_scene.is_battle_end:
        return

    if GlobalNode.battle_scene.scene_mode == BattleConstants.BATTLE_SCENE_MODE_ENUM.FORMATION_MODE:

        return

    if counter % 60 == 0:
        if not SoldierUtils.is_living_by_soldier_node(self):
            return

        if SoldierUtils.is_hero_or_leader2(self):

            return


        if mod_fear_value > 0 and bs_soldier_prop.hp_max > 0:
            var _fear_threshold = float(bs_soldier_prop.hp_max) / 2.0
            if mod_fear_value >= _fear_threshold:
                if BSSoldierConstants.CANT_INTERRUPT_ACTION_STATUS_LIST.has(get_action_status()):
                    return

                want_flee = true
                mod_fear_triggered_flee = true
                change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE)
                return

        var _flee_prob: float = SoldierUtils.get_flee_prob(bs_group, bs_soldier_prop)
        if CommonUtils.prob_true(_flee_prob):
            want_flee = true
            if BSSoldierConstants.CANT_INTERRUPT_ACTION_STATUS_LIST.has(get_action_status()):
                return

            change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE)


var is_horse_collision_area_open = false

func _open_horse_collision_area_check():
    is_horse_collision_area_open = true
    horse_collision_area_node.monitoring = true

    horse_collision_area_node_collision_node.set_deferred("disabled", false)

func _close_horse_collision_area_check():
    is_horse_collision_area_open = false
    horse_collision_area_node.monitoring = false

    horse_collision_area_node_collision_node.set_deferred("disabled", true)

func _update_part_direction(_node, _direction_enum, _field):



    if _field == "body_direction":
        if body_direction == _direction_enum:
            return
    elif _field == "move_direction" and move_direction == _direction_enum:
        return
    match _direction_enum:
        CommonConstants.DIRECTION_ENUM.RIGHT:
            if self.get(_field) == CommonConstants.DIRECTION_ENUM.RIGHT:
                return

            _node.scale = Vector2(1, 1)
            if _node == shape_node:
                back_shape_node.scale = Vector2(1, 1)
                if _field == "body_direction":
                    main_weapon_node.show()
                    bmain_weapon_node.hide()
                    vice_weapon_node.position = origin_vice_weapon_node_position


            self.set(_field, CommonConstants.DIRECTION_ENUM.RIGHT)
        CommonConstants.DIRECTION_ENUM.LEFT:
            if self.get(_field) == CommonConstants.DIRECTION_ENUM.LEFT:
                return

            _node.scale = Vector2(-1, 1)
            if _node == shape_node:
                back_shape_node.scale = Vector2(-1, 1)

                if _field == "body_direction" and bs_soldier_prop.is_oh_weapon():
                    main_weapon_node.hide()
                    bmain_weapon_node.show()
                    vice_weapon_node.position += Vector2(-4, 0)

            self.set(_field, CommonConstants.DIRECTION_ENUM.LEFT)

func _effect_add_capture():
    _effect_add(
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.CAPTURE_EFFECT,
        damage_root_node
    )

func _create_change_weapon_tag(_uid):
    var change_weapon_tag_instance = change_weapon_tag_node.instantiate() as ChangeWeaponTag
    change_weapon_tag_root_node.add_child(change_weapon_tag_instance)
    change_weapon_tag_instance.init_and_start(_uid)

func _create_charge_icon():
    var change_weapon_tag_instance = change_weapon_tag_node.instantiate() as ChangeWeaponTag
    change_weapon_tag_root_node.add_child(change_weapon_tag_instance)
    change_weapon_tag_instance.init_and_start_charge_icon()


func _place_l_shield(_l_shield_json):
    var _l_shield_place_instance = l_shield_place_node.instantiate() as LShieldPlace

    GlobalNode.battle_scene.add_l_shield(_l_shield_place_instance)
    _l_shield_place_instance.init(
        _l_shield_json, self.global_position,
        attack_target.global_position, hurt_box_node.collision_mask,
        in_water
    )
    l_shield_place_instance = _l_shield_place_instance


func _handle_hero():

    _handle_hero_avatar_tag()

func _handle_hero_avatar_tag():
    var _bs_soldier_avatar_tag_instance = bs_soldier_avatar_tag_node.instantiate()
    hero_tag_node.add_child(_bs_soldier_avatar_tag_instance)
    _bs_soldier_avatar_tag_instance.init(self)
    bs_soldier_avatar_tag_instance = _bs_soldier_avatar_tag_instance


func _body_effect_add(_effect_name_enum):



    _effect_add(_effect_name_enum, body_effect_root_node)

func _effect_add(
    _effect_name_enum, _node,
    _direction_opposite: = false
)-> SoldierBodyEffect:


    var soldier_body_effect_instance = soldier_body_effect_node.instantiate()
    _node.add_child(soldier_body_effect_instance)

    if _direction_opposite:
        soldier_body_effect_instance.flip_h = true

    soldier_body_effect_instance.animation_play(_effect_name_enum)
    return soldier_body_effect_instance

func _prepare_finish_reset_data():



    if get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE:
        return

    prepare_action = null
    prep_change_weapon_user_type = null

func _set_attack_target(_node):
    if CommonUtils.is_not_null(attack_target):
        if attack_target.has_method("enemy_attack_intent_count_subtract"):
            attack_target.enemy_attack_intent_count_subtract()

    attack_target = _node
    if CommonUtils.is_not_null(attack_target):
        if attack_target.has_method("enemy_attack_intent_count_plus"):
            attack_target.enemy_attack_intent_count_plus()


func _show_damage_label(_damage, _is_crit, addition_damage_text = null):
    if _damage <= 0:
        return




    var damage_label_instance = damage_label_node.instantiate()
    damage_root_node.add_child(damage_label_instance)
    damage_label_instance.init_and_start(
        - _damage, _is_crit, null if addition_damage_text == null else - addition_damage_text)


func _show_damage_label_miss():

    var damage_label_instance = damage_label_node.instantiate()
    damage_root_node.add_child(damage_label_instance)
    damage_label_instance.play_miss()



func _show_heal_label(_heal):
    if _heal <= 0:
        return
    if not GlobalPlayerConfig.is_show_damage_text:
        return
    var damage_label_instance = damage_label_node.instantiate()
    damage_root_node.add_child(damage_label_instance)
    damage_label_instance.play_heal("+" + str(_heal))


func _update_injured_effect():
    if hp > bs_soldier_prop.slight_wound_hp:
        return

    var _injured_level = BSSoldierConstants.INJURED_LEVEL_ENUM.COMMON
    if hp > bs_soldier_prop.severe_wound_hp and hp <= bs_soldier_prop.slight_wound_hp:
        _injured_level = BSSoldierConstants.INJURED_LEVEL_ENUM.SLIGHT_WOUND
    else:
        _injured_level = BSSoldierConstants.INJURED_LEVEL_ENUM.SEVERE_WOUND

    if injured_level != _injured_level:
        injured_level = _injured_level

        var _pic_path = ""
        match injured_level:
            BSSoldierConstants.INJURED_LEVEL_ENUM.SLIGHT_WOUND:
                _pic_path = "res://resource/bs/soldierPart/blood/blood_0001.png"
            BSSoldierConstants.INJURED_LEVEL_ENUM.SEVERE_WOUND:
                _pic_path = "res://resource/bs/soldierPart/blood/blood_0002.png"

        if is_cavalry():
            _pic_path = SoldierPartUtils.get_cavalry_t_path(_pic_path)

        CommonUtils.update_texture2(blood_node, _pic_path)
        blood_node.show()




func _straight_beam_attack():
    if CommonUtils.is_null(attack_target) or not is_instance_valid(attack_target):
        return
    if not is_instance_valid(flyer_start_point_node):
        return
    if GlobalNode.battle_scene == null or not is_instance_valid(GlobalNode.battle_scene):
        return

    bs_soldier_prop.plus_shot_count(-1)

    var _start_pos: Vector2 = flyer_start_point_node.global_position
    var _target_pos: Vector2
    if attack_target.has_meta("is_wooden_wall"):
        _target_pos = attack_target.global_position
    else:
        _target_pos = attack_target.get_hurt_box_position()


    _play_main_sfx(2)


    var _line: Line2D = Line2D.new()
    _line.width = 3.0
    _line.default_color = Color(1.0, 0.85, 0.3, 0.9)
    _line.z_index = 100
    var _bs: Node2D = GlobalNode.battle_scene
    _line.add_point(_start_pos - _bs.global_position)
    _line.add_point(_target_pos - _bs.global_position)
    _bs.add_child(_line)
    var _tween = _line.create_tween()
    _tween.tween_property(_line, "modulate:a", 0.0, 0.15)
    _tween.tween_callback(_line.queue_free)


    if attack_target.has_meta("is_wooden_wall"):
        var _atk = get_atk() * GlobalNode._mod_get_facility_damage_mult(self)
        if attack_target.has_meta("is_arrow_tower"):
            var _tidx: int = attack_target.get_meta("tower_idx", -1)
            if _tidx >= 0 and _mod_tower_hps_safe(_tidx):
                GlobalNode._mod_damage_arrow_tower(_tidx, _atk)
        elif attack_target.has_meta("is_small_wooden_wall"):
            var _sidx: int = attack_target.get_meta("small_wall_idx", -1)
            if _sidx >= 0 and _mod_small_wall_hps_safe(_sidx):
                GlobalNode._mod_damage_small_wall_by_arrow(_sidx, _atk)
        else:
            if GlobalNode._mod_is_wooden_wall_alive():
                GlobalNode._mod_damage_wooden_wall_by_arrow(_atk)
        return





    attack_target.hurt(
        get_atk(), bs_soldier_prop.get_attack_type(),
        self,
        attack_target.global_position - self.global_position,
        bs_soldier_prop.weapon_special_attr_dic,
        false,
        true
    )

func _mod_tower_hps_safe(_idx: int)-> bool:
    if _idx < 0 or _idx >= GlobalNode._mod_tower_hps.size():
        return false
    return GlobalNode._mod_tower_hps[_idx] > 0

func _mod_small_wall_hps_safe(_idx: int)-> bool:
    if _idx < 0 or _idx >= GlobalNode._mod_small_wall_hps.size():
        return false
    return GlobalNode._mod_small_wall_hps[_idx] > 0

func _launch_flyer():
    if CommonUtils.is_null(attack_target):
        return

    var flyer_instance: Flyer
    var _is_lethal_strike_flyer: = false
    if CommonUtils.prob_true(bs_soldier_prop.lethal_strike_5000_rate):

        flyer_instance = load("res://tscn/game/soldier/FlyerWithTrail.tscn").instantiate()
        _is_lethal_strike_flyer = true
    else:
        flyer_instance = flyer_node.instantiate()


    GlobalNode.battle_scene.add_flyer(flyer_instance)

    var _flyer_target: Vector2
    if is_instance_valid(attack_target) and attack_target.has_meta("is_wooden_wall"):
        _flyer_target = attack_target.global_position
    else:
        _flyer_target = attack_target.get_hurt_box_position()
    var _flyer_velocity: Vector2 = Vector2.ZERO
    if is_instance_valid(attack_target) and not attack_target.has_meta("is_wooden_wall"):
        _flyer_velocity = attack_target.velocity
    flyer_instance.init(

        flyer_start_point_node.global_position,
        _flyer_target,
        BSSoldierConstants.BS_BGROUP_ENUM.get(bs_bgroup).against,

        _flyer_velocity,


        self,
        is_mobile_shooting_action
    )

    if _is_lethal_strike_flyer:
        flyer_instance.set_atk(5000)

    flyer_instance.launch()

    bs_soldier_prop.plus_shot_count(-1)
    match bs_soldier_prop.get_main_weapon_stype():
        WeaponTypeConstants.STYPE_ENUM.TH_BOW:
            _play_main_sfx(0)
        WeaponTypeConstants.STYPE_ENUM.TH_CROSSBOW:
            _play_main_sfx(2)
        WeaponTypeConstants.STYPE_ENUM.OH_THROW:
            _play_attack_throw_sfx()


func _init_all_skin():

    _handle_cavalry_sprite()

    _init_body_skin()
    _init_weapon_skin()

    _update_injured_effect()

func _handle_cavalry_sprite():
    var _vframes = BSSoldierConstants.INFANTRY_SPRITE_CONFIG.vframe
    if bs_soldier_prop.ic_type == BSSoldierConstants.IC_TYPE.INFANTRY:
        pass
    else:

        _vframes = BSSoldierConstants.CAVALRY_SPRITE_CONFIG.vframe


        var _position_update: = BSSoldierConstants.CAVALRY_SPRITE_CONFIG.position_update + Vector2(0, - bs_soldier_prop.character_y_plus)
        shape_node.position += _position_update
        back_shape_node.position += _position_update
        shape_bottom_node.position += _position_update
        hurt_box_node.position += _position_update
        damage_root_node.position += _position_update
        body_effect_root_node.position += _position_update
        hero_tag_node.position += _position_update
        change_weapon_tag_root_node.position += _position_update
        chat_root_node.position += _position_update

        shape_bottom_node.position.y += bs_soldier_prop.character_y_plus


        die_blood_root_node.position -= _position_update
        horse_collision_area_node.position -= _position_update
        focus_effect_root_node.position -= _position_update
        cavalry_water_mask_node.position -= _position_update
        b_cavalry_water_mask_node.position -= _position_update


        horse_node.show()
        if bs_soldier_prop.is_harmour_match:
            harmour_node.show()
        else:
            harmour_node.hide()


        CommonUtils.update_texture2(shadow_node, SoldierPartUtils.get_cavalry_t_path(shadow_node.texture.get_path()))
        CommonUtils.update_texture2(choose_effect_node, SoldierPartUtils.get_cavalry_t_path(choose_effect_node.texture.get_path()))

    body_node.vframes = _vframes
    hair_node.vframes = _vframes
    armour_node.vframes = _vframes
    helmet_node.vframes = _vframes
    vice_weapon_node.vframes = _vframes
    main_weapon_node.vframes = _vframes
    bmain_weapon_node.vframes = _vframes
    blood_node.vframes = _vframes
    horse_node.vframes = _vframes
    harmour_node.vframes = _vframes

func _init_body_skin():
    CommonUtils.update_texture(body_node, bs_soldier_prop.body_json)
    CommonUtils.update_texture(hair_node, bs_soldier_prop.hair_json)
    CommonUtils.update_texture(armour_node, bs_soldier_prop.armour_json)
    CommonUtils.update_texture(helmet_node, bs_soldier_prop.helmet_json)
    CommonUtils.update_texture(horse_node, bs_soldier_prop.horse_json)
    CommonUtils.update_texture(harmour_node, bs_soldier_prop.harmour_json)

    if SoldierUtils.is_hero(self) and not GlobalPlayerConfig.is_show_hero_helmet_in_battle_scene:
        helmet_node.hide()

func _init_weapon_skin(_change_weapon_uid = null):
    CommonUtils.update_texture(main_weapon_node, bs_soldier_prop.main_weapon_json)
    CommonUtils.update_texture(bmain_weapon_node, bs_soldier_prop.main_weapon_json)
    CommonUtils.update_texture(vice_weapon_node, bs_soldier_prop.vice_weapon_json)




    if bs_soldier_prop.b_vice_weapon_json != null:
        CommonUtils.update_texture(b_shield_node, bs_soldier_prop.b_vice_weapon_json, "bs_t_path")
        b_shield_node.show()


        var _b_vice_stype = WeaponTypeConstants.get_stype(bs_soldier_prop.b_vice_weapon_json.get("uid", ""))
        if _b_vice_stype == "l_shield":
            b_shield_node.z_index = 5
        else:
            b_shield_node.z_index = 0
    else:
        b_shield_node.hide()


    if _change_weapon_uid != null:
        _create_change_weapon_tag(_change_weapon_uid)

    if body_direction == CommonConstants.DIRECTION_ENUM.LEFT:
        if bmain_weapon_node.visible and bs_soldier_prop.is_th_weapon():
            main_weapon_node.show()
            bmain_weapon_node.hide()
            vice_weapon_node.position = origin_vice_weapon_node_position
        elif not bmain_weapon_node.visible and bs_soldier_prop.is_oh_weapon():
            main_weapon_node.hide()
            bmain_weapon_node.show()
            vice_weapon_node.position += Vector2(-4, 0)







func _physics_shape_search(_search_range):
    var _target_node = null


    var _min_attack_inverse_weight = CommonConstants.INT_MAX

    var _temp_attack_inverse_weight = CommonConstants.INT_MAX


    if is_charge:


        var _target_soldier_node_list: Array = GlobalNode.battle_scene.list_search_target_soldier_node(enemy_group_list)
        for _soldier_node in _target_soldier_node_list:
            if SoldierUtils.is_living_by_soldier_node(_soldier_node):


                if CommonUtils.in_scope(self, _soldier_node, get_attack_range()):
                    return _soldier_node




                var _eic2 = _soldier_node.get("enemy_attack_intent_count")
                if _eic2 == null:
                    _eic2 = 0
                _temp_attack_inverse_weight = _get_attack_inverse_weight(_eic2, _soldier_node.global_position)
                if _temp_attack_inverse_weight < _min_attack_inverse_weight:
                    _target_node = _soldier_node
                    _min_attack_inverse_weight = _temp_attack_inverse_weight
    else:

        search_physics_shape_query_parameters2d_node.set_shape(search_circle_shape)
        search_physics_shape_query_parameters2d_node.collision_mask = select_collision_mask
        search_circle_shape.radius = _search_range
        search_physics_shape_query_parameters2d_node.transform = Transform2D(0, global_position)
        var _selected_list = direct_space_state.intersect_shape(search_physics_shape_query_parameters2d_node, 1000)
        for _unit in _selected_list:
            var _soldier_node = _unit.collider
            if(SoldierUtils.is_living_by_soldier_node(_soldier_node)


                ):


                var _eic = _soldier_node.get("enemy_attack_intent_count")
                if _eic == null:
                    _eic = 0
                _temp_attack_inverse_weight = _get_attack_inverse_weight(_eic, _soldier_node.global_position)
                if _temp_attack_inverse_weight < _min_attack_inverse_weight:
                    _target_node = _soldier_node
                    _min_attack_inverse_weight = _temp_attack_inverse_weight

    return _target_node


func _get_attack_inverse_weight(enemy_attack_intent_count: int, _position: Vector2)-> int:
    var _result: = 0
    if enemy_attack_intent_count > 2:
        _result +=(enemy_attack_intent_count - 2) * 250



    return _result + global_position.distance_to(_position)

func _flyer_adhering(_flyer_node):

    var flyer_adhering_instance: FlyerAdhering = flyer_adhering_node.instantiate()
    flyer_root_node.add_child(flyer_adhering_instance)
    flyer_adhering_instance.init(_flyer_node, shape_node.scale)
    _flyer_node.destory()



func _maybe_change_weapon_remote_to_close_in()-> bool:
    if not bs_soldier_prop.is_use_remote_switch and prepare_action == null:
        return false


    if bs_soldier_prop.main_weapon_json != null:
        var _melee_forbid: bool = bs_soldier_prop.main_weapon_json.get("melee_forbid", false)
        if _melee_forbid:
            return false

    change_weapon_to_close_in()




    return true

func _change_weapon(_user_type_enum = null):
    var _result = bs_soldier_prop.choose_weapon(_user_type_enum)
    var _change_weapon_uid = _get_change_weapon_uid(_result)

    _init_weapon_skin(_change_weapon_uid)

func _get_change_weapon_uid(_result):
    var _change_weapon_uid = null
    if _result.old != null and _result.old != _result.new:
        _change_weapon_uid = _result.new

    return _change_weapon_uid


func _raise_dust_effect():
    var _direction_opposite =(move_direction == CommonConstants.DIRECTION_ENUM.LEFT)
    if in_water:
        GlobalNode.battle_scene.call_deferred(
            "_add_effect",
            BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.CAVALRY_SPLASH_EFFECT,
            horse_raise_dust_root_node.global_position, _direction_opposite
        )
    else:
        GlobalNode.battle_scene.call_deferred("add_horse_raise_dust", horse_raise_dust_root_node.global_position, _direction_opposite)


func _raise_dust_walk_effect():
    if in_water:
        var _direction_opposite =(move_direction == CommonConstants.DIRECTION_ENUM.LEFT)
        GlobalNode.battle_scene.call_deferred(
            "_add_effect",
            BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.INFANTRY_SPLASH_EFFECT,
            horse_raise_dust_root_node.global_position,
            _direction_opposite
        )
    else:
        pass



func _on_hurt_box_area_entered(_area):
    var _flyer_node: Flyer = _area.owner
    _flyer_node.stop()

    var _direction_vector = Vector2.RIGHT
    if move_direction == CommonConstants.DIRECTION_ENUM.LEFT:
        _direction_vector = Vector2.LEFT

    hurt(
        _flyer_node.atk, WeaponTypeConstants.ATTACK_TYPE_ENUM.REMOTE,

        _flyer_node.origin_soldier_node,
        _flyer_node.target_point - _flyer_node.init_point,
        _flyer_node.weapon_special_attr_dic
    )

    _flyer_adhering(_flyer_node)


func _on_flee_timer_timeout():

    if not SoldierUtils.is_living_by_soldier_node(self):
        return

    handle_flee_success()


func _on_area_2d_body_entered(body):

    if GlobalNode.battle_scene.scene_mode == BattleConstants.BATTLE_SCENE_MODE_ENUM.FORMATION_MODE:
        return
    var _knock_length = velocity.length() * 0.5
    if[
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_MOVE,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_PACK_UP,
    ].has(status_machine_node.get_action_status()):

        if body.get_action_status() == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.SET_PIKE:
            pass
        else:
            _knock_length = velocity.length()

            body.hurt(
                50, WeaponTypeConstants.ATTACK_TYPE_ENUM.CLOSE_IN,
                self, body.global_position - global_position
            )

    if SoldierUtils.is_infantry(body.bs_soldier_prop):
        body.be_knock_back((body.global_position - global_position).normalized() * _knock_length)





const MOD_FEAR_SET_UIDS = ["armour_0105", "helmet_0132", "shoe_0084", "shoulder_0072"]

const MOD_FEAR_WEAPON_UID = "th_blunt_0006"


func _mod_has_fear_equipment()-> bool:
    return _mod_count_fear_equipment(self) > 0 or _mod_has_fear_weapon() or _mod_has_fear_shield()


func _mod_has_fear_shield()-> bool:
    var _shield_uid = "oh_shield_0037"

    if simple_json.has("vice_weapon"):
        var _equip = simple_json["vice_weapon"]
        if _equip != null and _equip is Dictionary and _equip.has("uid"):
            if _equip["uid"] == _shield_uid:
                return true

    if bs_soldier_prop != null:
        if bs_soldier_prop.vice_weapon_json != null and bs_soldier_prop.vice_weapon_json.get("uid", "") == _shield_uid:
            return true
        if bs_soldier_prop.b_vice_weapon_json != null and bs_soldier_prop.b_vice_weapon_json.get("uid", "") == _shield_uid:
            return true
    return false


func _mod_has_fear_weapon()-> bool:

    if simple_json.has("weapon"):
        var _equip = simple_json["weapon"]
        if _equip != null and _equip is Dictionary and _equip.has("uid"):
            if _equip["uid"] == MOD_FEAR_WEAPON_UID:
                return true

    if bs_soldier_prop != null:
        if bs_soldier_prop.main_weapon_json != null and bs_soldier_prop.main_weapon_json.get("uid", "") == MOD_FEAR_WEAPON_UID:
            return true
        if bs_soldier_prop.vice_weapon_json != null and bs_soldier_prop.vice_weapon_json.get("uid", "") == MOD_FEAR_WEAPON_UID:
            return true
    return false



func _mod_count_fear_equipment(_soldier_node: BSSoldier)-> int:
    var _count = 0

    var _fields = ["armour", "helmet", "shoe", "shoulder", "vice_weapon"]
    for _field in _fields:
        if _soldier_node.simple_json.has(_field):
            var _equip = _soldier_node.simple_json[_field]
            if _equip != null and _equip is Dictionary and _equip.has("uid"):
                if _equip["uid"] in MOD_FEAR_SET_UIDS:
                    _count += 1

    if _count == 0 and _soldier_node.bs_soldier_prop != null:
        if _soldier_node.bs_soldier_prop.armour_json != null and _soldier_node.bs_soldier_prop.armour_json.get("uid", "") in MOD_FEAR_SET_UIDS:
            _count += 1
        if _soldier_node.bs_soldier_prop.helmet_json != null and _soldier_node.bs_soldier_prop.helmet_json.get("uid", "") in MOD_FEAR_SET_UIDS:
            _count += 1
        if _soldier_node.bs_soldier_prop.shoe_json != null and _soldier_node.bs_soldier_prop.shoe_json.get("uid", "") in MOD_FEAR_SET_UIDS:
            _count += 1
        if _soldier_node.bs_soldier_prop.shoulder_json != null and _soldier_node.bs_soldier_prop.shoulder_json.get("uid", "") in MOD_FEAR_SET_UIDS:
            _count += 1
    return _count


func _mod_add_fear_to_team(_amount: float):
    var _groups = ["bs_player", "bs_enemy", "bs_teammate"]
    for _group_name in _groups:
        for _node in get_tree().get_nodes_in_group(_group_name):
            if _node is BSSoldier and _node.bs_group == self.bs_group:
                if _node != self and SoldierUtils.is_living_by_soldier_node(_node):
                    _node.mod_fear_value += _amount





func _mod_boss_phase_transition():
    _set_attack_target(null)

    if mod_boss_phase == 2:
        hp = mod_boss_original_hp_max * 4
        bs_soldier_prop.hp_max = mod_boss_original_hp_max * 4
    elif mod_boss_phase == 3:
        hp = mod_boss_original_hp_max
        bs_soldier_prop.hp_max = mod_boss_original_hp_max
    elif mod_boss_phase == 4:

        hp = mod_boss_original_hp_max
        bs_soldier_prop.hp_max = mod_boss_original_hp_max

    living_status = BSSoldierConstants.LIVING_STATUS_ENUM.DEATH

    _clear_enemy_targets()

    collision_shape_2d_node.set_deferred("disabled", true)
    hurt_box_node.set_deferred("monitoring", false)
    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
    var _phase_name = "未知"
    var _resurrect_delay: float = 3.2
    if mod_boss_phase == 2:
        _phase_name = "二阶段(血量x4)"
        _resurrect_delay = 3.2
    elif mod_boss_phase == 3:
        _phase_name = "三阶段(攻击x3+恐惧光环+50%无视攻击+减敌方3士气)"
        _resurrect_delay = 5.2
    elif mod_boss_phase == 4:
        _phase_name = "四阶段(正常状态+每2秒隐身1.2秒)"
        _resurrect_delay = 5.2
    print("[Mod] BOSS征伐骑士进入第", mod_boss_phase, "阶段: ", _phase_name, ", hp=", hp, ", 复活延迟=", _resurrect_delay + 0.8, "秒")

    var _tween = get_tree().create_tween()
    _tween.tween_property(self, "modulate:a", 0.0, 0.4)
    _tween.tween_interval(_resurrect_delay)
    _tween.tween_property(self, "modulate:a", 1.0, 0.4)
    _tween.tween_callback(_mod_boss_apply_phase)


func _mod_boss_apply_phase():

    living_status = BSSoldierConstants.LIVING_STATUS_ENUM.ACTIVE

    hurt_box_node.set_deferred("monitoring", true)
    collision_shape_2d_node.set_deferred("disabled", false)
    if mod_boss_phase == 3:

        bs_soldier_prop.atk = bs_soldier_prop.atk * 3
    elif mod_boss_phase == 4:

        bs_soldier_prop.atk = mod_boss_original_atk

    if bs_soldier_avatar_tag_instance != null:
        bs_soldier_avatar_tag_instance.update_progress(bs_soldier_prop.hp_max, hp)
    mod_boss_invulnerable = false
    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)
    print("[Mod] BOSS征伐骑士复活完成, phase=", mod_boss_phase, ", hp=", hp, ", pos=", global_position)



func _clear_enemy_targets():
    var _groups = ["bs_player", "bs_teammate"]
    for _group_name in _groups:
        for _node in get_tree().get_nodes_in_group(_group_name):
            if _node is BSSoldier and _node.bs_group != self.bs_group:
                if _node.attack_target == self:
                    _node._set_attack_target(null)



func _mod_boss_fear_aura():
    var _groups = ["bs_player", "bs_teammate"]
    for _group_name in _groups:
        for _node in get_tree().get_nodes_in_group(_group_name):
            if _node is BSSoldier and _node.bs_group != self.bs_group:
                if SoldierUtils.is_living_by_soldier_node(_node):

                    if _node.bs_soldier_prop.star >= 5:
                        _node.mod_fear_value += randf_range(35.0, 60.0)
                    else:
                        _node.mod_fear_value += randf_range(40.0, 80.0)
    if GlobalNode.battle_scene != null and is_instance_valid(GlobalNode.battle_scene):
        GlobalNode.battle_scene._update_morale(BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP, -3.0)
        GlobalNode.battle_scene._update_morale(BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP, -3.0)


func _mod_boss_final_death():
    print("[Mod] BOSS征伐骑士最终死亡, 执行死亡流程")
    mod_boss_invulnerable = false
    hp = 0

    equipment_capture_prob = 0.0
    change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIEING)













var _mod_death_hidden: bool = false
func mod_vanish_after_death():
    hide()
    _mod_death_hidden = true