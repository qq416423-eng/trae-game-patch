class_name BSSoldierAvatarTag extends Node2D

@onready var base_texture_progress_node =$BaseTextureProgress
@onready var animation_player_node =$AnimationPlayer
@onready var base_texture_progress_shadow_node =$BaseTextureProgressShadow
@onready var avatar_box_node =$AvatarBox
@onready var avatar_node: Avatar02 =$AvatarBox / Avatar02

const MW_TEAM_AVATAR_FRAME_ENEMY = preload("res://resource/mw/mwTeam/mw_team_avatar_frame_enemy.png")
const MW_TEAM_AVATAR_FRAME_MY_TEAM = preload("res://resource/mw/mwTeam/mw_team_avatar_frame_my_team.png")
const MW_TEAM_AVATAR_FRAME_TEAMMATE = preload("res://resource/mw/mwTeam/mw_team_avatar_frame_teammate.png")

var ratio = 100.0

var ratio_bak = 100.0

func _physics_process(_delta):
    if ratio_bak >= ratio:
        ratio_bak -= 0.25
        base_texture_progress_shadow_node.value = ratio_bak

func init(_node: BSSoldier):
    avatar_node.init(_node.bs_soldier_prop)

    var _group = _node.bs_group
    match _node.bs_group:
        BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP:
            CommonUtils.update_texture3(avatar_box_node, MW_TEAM_AVATAR_FRAME_MY_TEAM)
        BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP:
            CommonUtils.update_texture3(avatar_box_node, MW_TEAM_AVATAR_FRAME_TEAMMATE)
        BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP:
            CommonUtils.update_texture3(avatar_box_node, MW_TEAM_AVATAR_FRAME_ENEMY)

    update_progress(_node.bs_soldier_prop.hp_max, _node.hp)

func update_progress(_max, _value):
    var _ratio = 0
    if _value <= 0:
        _ratio = 0

    _ratio = _value * 100.0 / _max
    if _ratio == ratio:
        return

    ratio = _ratio
    _update_progress()

func disappear():
    animation_player_node.play("disappear")

func _stop():
    set_physics_process(false)

func _update_progress():
    base_texture_progress_node.value = ratio