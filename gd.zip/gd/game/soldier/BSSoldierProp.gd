class_name BSSoldierProp

var json = {}
var simple_json = {}

var uid: String

var split_group_uid: String

var split_index: = 0


const DEFAULT_PART_JSON = {"uid": ""}
var body_json = DEFAULT_PART_JSON
var hair_json = DEFAULT_PART_JSON
var armour_json = DEFAULT_PART_JSON
var shoe_json = DEFAULT_PART_JSON
var shoulder_json = DEFAULT_PART_JSON
var helmet_json = DEFAULT_PART_JSON
var weapon1_json = DEFAULT_PART_JSON
var weapon2_json = DEFAULT_PART_JSON
var weapon3_json = DEFAULT_PART_JSON
var horse_json = DEFAULT_PART_JSON

var harmour_json = DEFAULT_PART_JSON



var name: = ""

var split_group_name = ""

var base_strength = 0

var base_agile = 0

var base_physical = 0

var base_intelligence = 0

var gender: = BSSoldierConstants.GENDER_ENUM.MALE

var mount_type: = GoodsConstants.MOUNT_TYPE_ENUM.NONE



var skill_strength = 0
var skill_agile = 0
var skill_physical = 0

var skill_medical = 0

var skill_operation = 0

var skill_investigation = 0

var skill_motility = 0

var skill_manage = 0

var skill_trade = 0

var skill_plunder = 0

var skill_engineer = 0




var skill_battle_talent = 0

var skill_train = 0

var skill_charisma = 0

var skill_special_methodical: = 0

var skill_special_blunt_master = 0

var skill_special_fear_ride = 0

var skill_special_vampire = 0

var skill_special_bite = 0


var skill_stop_leveling = 0


var practise_oh_sword = 0

var practise_th_sword = 0

var practise_oh_axe = 0

var practise_th_axe = 0

var practise_oh_blunt = 0

var practise_th_blunt = 0


var practise_oh_lance = 0


var practise_oh_shield = 0

var practise_oh_pole = 0

var practise_th_pole = 0

var practise_th_bow = 0

var practise_th_firearm = 0

var practise_th_crossbow = 0

var practise_oh_throw = 0


var practise_horse = 0


var practise_mobile = 0

var base_practise_mobile: = 0




var attr_point = 0

var learn_skill = ""




var body_def: = 0

var body_crit_def: = 0

var def: = 0

var crit_def: = 0

var atk: = 0

var base_atk: = 0

var hit_ratio: = 0.0
var origin_hit_ratio: = 0.0

var crit_prob: = 0.0

var crit_atk_ratio: = 2.0

var move_speed: = 0.0
var origin_move_speed: = 0.0

var weight: float = 0.0

var hit_ratio_min: float = 0.0

var hit_ratio_max: float = 0.0

var misfire_ratio_rain_min: = 0.0

var misfire_ratio_rain_max: = 0.0

var misfire_ratio: = 0.0



var attack_speed: = 1.0

var want_attack_range: = 0
var want_attack_range_mobile_shooting: = 0

var attack_range: = 0
var attack_range_square: = 0
var attack_range_small_square: = 0


var attack_range_mobile_shooting: = 0
var attack_range_square_mobile_shooting: = 0

var hp_max: = 0
var hp: = 0

var block_prob: = 0.0

var b_block_prob: = 0.0

var ic_type: = BSSoldierConstants.IC_TYPE.INFANTRY

var arms_small_type_enum: = BSSoldierConstants.ARMS_SMALL_TYPE_ENUM.INFANTRY_MELEE


var shot_accuracy: = 0

var body_shot_accuracy: = 0

var slight_wound_hp: = 0

var severe_wound_hp: = 0

var stun_prop: = 0.0

var stun_second: = 0.0

var melee_stun_second_plus: = 0.0

var melee_stun_prop_plus: = 0.0

var knock_back: = 0
var htype: = BSSoldierConstants.H_TYPE_ENUM.SOLDIER



var star: = 1

var level: = 1

var price: = 0



var capture_prob: = 0.0

var combat_power: = 0

var remote_hurt_plus: = 0.0

var attack_speed_plus_th_melee: = 0.0
var attack_speed_plus_oh_melee: = 0.0

var character_y_plus: = 0
var horse_animation_speed: = 1.0

var is_harmour_match: = false

var desert_resistance: = 0

var cavalry_charge_damage_plus: = 0.0

var attack_damage_plus_oh_throw: = 0.0

var attack_speed_plus_th_bow: = 0.0

var attack_speed_plus_th_crossbow: = 0.0

var attack_damage_plus_th_melee: = 0.0

var attack_damage_plus_oh_melee: = 0.0

var infantry_speed_plus: = 0.0

var equipment_base_physical_plus: = 0
var equipment_base_strength_plus: = 0
var equipment_base_agile_plus: = 0

var th_crossbow_plus_crit_prob_ratio: = 0.0

var th_bow_plus_crit_prob_ratio: = 0.0

var th_bow_attack_plus_ratio: = 0.0




var weapon_assemble_dic: = {}

var main_weapon_json = null

var vice_weapon_json = null

var b_vice_weapon_json = null

var current_weapon_use_type = null



var weapon_special_attr_dic = {}

var attack_allow_place_l_shield = false


var is_has_remote_switch: = false

var is_use_remote_switch: = false


var is_has_remote_weapon: = false

var is_use_remote_weapon: = false

var is_use_long_range_weapon: = false

var search_enemy_interval = BSSoldierConfig.SEARCH_ENEMY_INTERVAL

var bs_group

var is_allow_mobile_shooting = false

var flyer_texture_path = null

var throw_rotate = false

var flyer_speed: int = 0

var allow_remote: = true
var is_day: bool = true
var weather = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR



var is_busy: = false
var busy_data: = {}

var skill_max_info: = {}

var cant_ride: = false

var intelligence_skill_bonus_level: = 0

var wages_daily: float = 0.0

var is_has_panic_buff_melee_attack_on_infantry: = false
var is_has_panic_buff_camel_melee_attack: = false
var is_has_panic_buff_weapon_small_to_cavalry: = false
var is_has_panic_buff_weapon_big_to_cavalry: = false

var atk_ratio: = 1.0




var melee_attack_range_plus: int = 0

var bow_lethal_strike_5000_rate = 0.0

var lethal_strike_5000_rate: float = 0.0

var is_leader: bool = false


var body_equipment_melee_damage_to_stunned_target_plus: = 0.0

var melee_damage_to_stunned_target_plus = 0.0

var armor_pen_5_seconds_rate: = 0.0

var open_melee_perfect_hit_buff: = false

var buff_duration_bonus_rate: = 0.0

func set_bs_group(_bs_group):
    bs_group = _bs_group

func init(
    _simple_json: Dictionary, _is_day: bool = true,
    _weather: MWorldConstants.WEATHER_TYPE_ENUM = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR
    ):
    simple_json = _simple_json
    var _soldier_json = SoldierUtils.get_json2(_simple_json)

    var _hp_is_max: = false
    if not simple_json.has("hp"):
        _hp_is_max = true

    init2(_soldier_json, _is_day, _weather, _hp_is_max)

func init2(
    _soldier_json: Dictionary,
    _is_day: bool = true,
    _weather: MWorldConstants.WEATHER_TYPE_ENUM = MWorldConstants.WEATHER_TYPE_ENUM.CLEAR,
    _hp_is_max: bool = false
):
    is_day = _is_day
    weather = _weather
    json = _soldier_json
    combat_power = SoldierUtils.get_combat_power_by_json(_soldier_json)
    is_leader = SoldierUtils.is_leader(_soldier_json)
    uid = _soldier_json.uid
    split_group_uid = SoldierUtils.get_split_group_uid(_soldier_json)
    split_index = 0 if not _soldier_json.has("split_index") else _soldier_json.split_index

    name = CommonUtils.get_value(_soldier_json, "name", "未命名")
    split_group_name = name
    if _soldier_json.has("split_index"):
        split_group_name += "(" + str(_soldier_json.split_index + 1) + ")"

    base_strength = CommonUtils.get_value(_soldier_json, "base_strength", 0)
    base_agile = CommonUtils.get_value(_soldier_json, "base_agile", 0)
    base_physical = CommonUtils.get_value(_soldier_json, "base_physical", 0)
    base_intelligence = CommonUtils.get_value(_soldier_json, "base_intelligence", 0)
    gender = CommonUtils.get_value(_soldier_json, "gender", BSSoldierConstants.GENDER_ENUM.MALE)

    skill_strength = CommonUtils.get_value(_soldier_json, "skill_strength", 0)
    skill_agile = CommonUtils.get_value(_soldier_json, "skill_agile", 0)
    skill_physical = CommonUtils.get_value(_soldier_json, "skill_physical", 0)
    skill_medical = CommonUtils.get_value(_soldier_json, "skill_medical", 0)
    skill_operation = CommonUtils.get_value(_soldier_json, "skill_operation", 0)
    skill_investigation = CommonUtils.get_value(_soldier_json, "skill_investigation", 0)
    skill_motility = CommonUtils.get_value(_soldier_json, "skill_motility", 0)
    skill_manage = CommonUtils.get_value(_soldier_json, "skill_manage", 0)
    skill_trade = CommonUtils.get_value(_soldier_json, "skill_trade", 0)
    skill_plunder = CommonUtils.get_value(_soldier_json, "skill_plunder", 0)
    skill_engineer = CommonUtils.get_value(_soldier_json, "skill_engineer", 0)
    skill_battle_talent = CommonUtils.get_value(_soldier_json, "skill_battle_talent", 0)
    skill_train = CommonUtils.get_value(_soldier_json, "skill_train", 0)
    skill_charisma = CommonUtils.get_value(_soldier_json, "skill_charisma", 0)
    skill_special_methodical = CommonUtils.get_value(_soldier_json, "skill_special_methodical", 0)
    skill_special_blunt_master = CommonUtils.get_value(_soldier_json, "skill_special_blunt_master", 0)
    skill_special_fear_ride = CommonUtils.get_value(_soldier_json, "skill_special_fear_ride", 0)
    skill_special_vampire = CommonUtils.get_value(_soldier_json, "skill_special_vampire", 0)

    skill_special_bite = CommonUtils.get_value(_soldier_json, "skill_special_bite", 0)
    skill_stop_leveling = CommonUtils.get_value(_soldier_json, "skill_stop_leveling", 0)


    intelligence_skill_bonus_level = min(
        int(base_intelligence / SkillConfig.INTELLIGENCE_PER_SKILL_POINT),
        SkillConfig.INTELLIGENCE_SKILL_LEVEL_MAX
    )

    _plus_intelligence_skill()


    base_strength += skill_strength * SkillConfig.SKILL_BASE_PROP_PLUS
    base_agile += skill_agile * SkillConfig.SKILL_BASE_PROP_PLUS
    base_physical += skill_physical * SkillConfig.SKILL_BASE_PROP_PLUS


    learn_skill = CommonUtils.get_value(_soldier_json, "learn_skill", SkillConstants.SKILL_CONFIG.keys()[0])

    attr_point = CommonUtils.get_value(_soldier_json, "attr_point", 0)

    htype = CommonUtils.get_value(_soldier_json, "htype", BSSoldierConstants.H_TYPE_ENUM.SOLDIER)

    horse_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "horse",{}), ic_type
    )

    if skill_special_fear_ride > 0 and skill_special_fear_ride < 10:
        cant_ride = true


    if cant_ride or horse_json == null or horse_json.is_empty():
        ic_type = BSSoldierConstants.IC_TYPE.INFANTRY
    else:

        ic_type = BSSoldierConstants.IC_TYPE.CAVALRY
        is_has_panic_buff_melee_attack_on_infantry = CommonUtils.get_value(horse_json, "panic_buff_melee_attack_on_infantry", false)
        is_has_panic_buff_camel_melee_attack = CommonUtils.get_value(horse_json, "panic_buff_camel_melee_attack", false)

    arms_small_type_enum = SoldierUtils.get_arms_small_type_enum_by_json(_soldier_json)

    body_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "body",{"uid": "body_0001"}), ic_type
    )
    hair_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "hair",{"uid": "hair_0001"}), ic_type
    )
    armour_json = GoodsUtils.get_json_by_simple_json(_soldier_json.armour, ic_type)
    helmet_json = GoodsUtils.get_json_by_simple_json(_soldier_json.helmet, ic_type)
    shoe_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "shoe",{}), ic_type
    )
    shoulder_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "shoulder",{}), ic_type
    )
    weapon1_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "weapon1",{}), ic_type
    )
    weapon2_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "weapon2",{}), ic_type
    )
    weapon3_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "weapon3",{}), ic_type
    )
    harmour_json = GoodsUtils.get_json_by_simple_json(
        CommonUtils.get_value(_soldier_json, "harmour",{}), ic_type
    )


    for _practise_field: String in SoldierPractiseConstants.PRACTISE_FIELD_LIST:



        var _practise_value: int = CommonUtils.get_value(_soldier_json, _practise_field, 0)

        _practise_value += CommonUtils.get_value_sum(
            [armour_json, helmet_json, shoe_json, shoulder_json], _practise_field
        )
        set(_practise_field, SoldierUtils.limit_practise(_practise_value, _practise_field))

    base_practise_mobile = practise_mobile




    body_def = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "def"
    )
    body_crit_def = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "crit_def"
    )
    weight = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json, weapon1_json, weapon2_json, weapon3_json], "weight"
    )

    remote_hurt_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "remote_hurt_plus"
    )






    attack_speed_plus_th_melee = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_speed_plus_th_melee"
    )
    attack_speed_plus_oh_melee = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_speed_plus_oh_melee"
    )
    desert_resistance = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, horse_json], "desert_resistance"
    )
    cavalry_charge_damage_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "cavalry_charge_damage_plus"
    )
    attack_damage_plus_oh_throw = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_damage_plus_oh_throw"
    )
    attack_speed_plus_th_bow = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_speed_plus_th_bow"
    )
    attack_speed_plus_th_crossbow = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_speed_plus_th_crossbow"
    )
    attack_damage_plus_th_melee = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_damage_plus_th_melee"
    )
    attack_damage_plus_oh_melee = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "attack_damage_plus_oh_melee"
    )
    infantry_speed_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "infantry_speed_plus"
    )
    equipment_base_physical_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "base_physical_plus"
    )
    equipment_base_strength_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "base_strength_plus"
    )
    equipment_base_agile_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "base_agile_plus"
    )
    th_crossbow_plus_crit_prob_ratio = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "th_crossbow_plus_crit_prob_ratio"
    )
    th_bow_plus_crit_prob_ratio = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "th_bow_plus_crit_prob_ratio"
    )
    th_bow_attack_plus_ratio = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "th_bow_attack_plus_ratio"
    )
    melee_attack_range_plus = CommonUtils.get_value_sum(
        [horse_json], "melee_attack_range_plus"
    )
    bow_lethal_strike_5000_rate = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "bow_lethal_strike_5000_rate"
    )

    melee_stun_second_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "melee_stun_second_plus"
    )
    body_equipment_melee_damage_to_stunned_target_plus = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "melee_damage_to_stunned_target_plus"
    )
    body_shot_accuracy = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "bow_crossbow_shot_accuracy"
    )
    buff_duration_bonus_rate = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "buff_duration_bonus_rate"
    )


    base_physical += equipment_base_physical_plus
    base_strength += equipment_base_strength_plus
    base_agile += equipment_base_agile_plus


    _handle_weapon_index()


    _assemble_and_choose_weapon()

    move_speed = BSSoldierConfig.DEFAULT_INFANTRY_SPEED + infantry_speed_plus
    origin_move_speed = move_speed


    if GoodsUtils.is_not_null_json(horse_json) and not cant_ride:
        move_speed = horse_json.speed
        mount_type = CommonUtils.get_value(horse_json, "mount_type", GoodsConstants.MOUNT_TYPE_ENUM.HORSE)


        if horse_json.has("light_speed") and horse_json.light_speed > 0 \
        and weight < 20:
            move_speed *=(1 + horse_json.light_speed)

        origin_move_speed = move_speed
        character_y_plus = CommonUtils.get_value(horse_json, "character_y_plus", 0)
        horse_animation_speed = CommonUtils.get_value(horse_json, "horse_animation_speed", 1.0)
        if harmour_json != null \
        and mount_type == CommonUtils.get_value(harmour_json, "mount_type", GoodsConstants.MOUNT_TYPE_ENUM.HORSE):
            is_harmour_match = true

    star = CommonUtils.get_value(_soldier_json, "star", 1)


    if htype == BSSoldierConstants.H_TYPE_ENUM.HERO:
        star = 6

    level = CommonUtils.get_value(_soldier_json, "level", -1)
    price = CommonUtils.get_value(_soldier_json, "price", 0)
    hp_max = SoldierUtils.get_hp_max_by_prop(self)
    slight_wound_hp = hp_max * 2 / 3
    severe_wound_hp = hp_max / 3

    if _hp_is_max:

        hp = hp_max
    else:
        hp = CommonUtils.get_value(_soldier_json, "hp", hp_max)


    hp = min(hp, hp_max)


    skill_max_info = HeroDefaultData.get_skill_max_info(uid)

    is_busy = CommonUtils.get_value(_soldier_json, "is_busy", false)
    busy_data = CommonUtils.get_value(_soldier_json, "busy_data",{})

    wages_daily = SoldierUtils.get_wages_daily(_soldier_json.uid)

func get_skill_max(_skill_field: String)-> int:
    return CommonUtils.get_value(skill_max_info, _skill_field, SkillConfig.SKILL_MAX_LEVEL)


func choose_weapon(_user_type_enum = null)-> Dictionary:
    var _old_main_weapon_uid = null if main_weapon_json == null else main_weapon_json.uid
    var _choose_user_type_list = [_user_type_enum]
    if _user_type_enum == null:
        _choose_user_type_list = [
            WeaponTypeConstants.USER_TYPE_ENUM.REMOTE_SWITCH,
            WeaponTypeConstants.USER_TYPE_ENUM.CLOSE_IN_SWITCH
        ]

    for _choose_user_type in _choose_user_type_list:
        if weapon_assemble_dic.has(_choose_user_type):
            current_weapon_use_type = _choose_user_type
            _choose_weapon2(weapon_assemble_dic.get(_choose_user_type))
            break

    return {
        "old": _old_main_weapon_uid,
        "new": null if main_weapon_json == null else main_weapon_json.uid
    }

func get_attack_type():
    return main_weapon_json.attack_type


func plus_shot_count(_plus_count):
    main_weapon_json.shot_count += _plus_count


func check_shot_count_enough():
    return main_weapon_json.shot_count > 0













func enable_weapon(_stype: String, enable: bool)-> bool:
    var _weapon_json_list: Array = [weapon1_json, weapon2_json, weapon3_json]
    for _weapon_json in _weapon_json_list:


        if GoodsUtils.is_null_json(_weapon_json):
            continue

        if WeaponTypeConstants.get_stype(_weapon_json.uid) == _stype:
            _weapon_json.disable = not enable
            _assemble_weapon()
            return true

    return false


func delete_main_weapon_and_choose_weapon():
    delete_main_weapon()
    return choose_weapon()

func delete_main_weapon():
    main_weapon_json.break = true

    weight -= main_weapon_json.weight

    _assemble_weapon()


func delete_vice_weapon():
    vice_weapon_json.break = true

    weight -= vice_weapon_json.weight
    _assemble_weapon()
    choose_weapon(current_weapon_use_type)


func delete_b_vice_weapon():
    b_vice_weapon_json.break = true
    weight -= b_vice_weapon_json.weight
    _assemble_weapon()
    choose_weapon(current_weapon_use_type)


func pick_l_shield(_l_shield_json: Dictionary):
    var _field = "weapon" + str(_l_shield_json.weapon_index) + "_json"
    self.set(_field, _l_shield_json)


    weight += _l_shield_json.weight

    _assemble_weapon()
    choose_weapon(current_weapon_use_type)


func vice_hurt_and_check_is_break(_damage)-> bool:

    var _real_damage: = int(_damage /(1 + practise_oh_shield * GoodsConfig.PRACTISE_OH_SHIELD_EHP_RATIO))
    if _real_damage < 1:
        _real_damage = 1

    vice_weapon_json.e_hp -= _real_damage
    return vice_weapon_json.e_hp <= 0


func b_vice_hurt_and_check_is_break(_damage)-> bool:
    b_vice_weapon_json.e_hp -= _damage
    return b_vice_weapon_json.e_hp <= 0

func update_speed_mult(_mult):
    move_speed = int(origin_move_speed * _mult)

func get_hp_percent():
    return int(hp * 100 / hp_max)


func handle_place_l_shield_data():
    var _temp_b_vice_weapon_json = b_vice_weapon_json

    var _weapon_json_field = "weapon" + str(b_vice_weapon_json.weapon_index) + "_json"
    self.set(_weapon_json_field, null)
    b_vice_weapon_json = null


    weight -= _temp_b_vice_weapon_json.weight

    _assemble_and_choose_weapon()

    return _temp_b_vice_weapon_json


func is_allow_change_weapon_remote():
    if current_weapon_use_type == WeaponTypeConstants.USER_TYPE_ENUM.CLOSE_IN_SWITCH \
    and is_has_remote_switch:


        if not allow_remote:
            return false

        return true

    return false


func allow_pike():
    if main_weapon_json.has("set_pike") and main_weapon_json.set_pike:
        return true

    return false


func get_skill_aptitude(_skill_name):
    var _field = "aptitude_" + _skill_name
    var _learn_aptitude = SkillConfig.DEFAULT_LEARN_APTITUDE
    if json.has(_field):
        _learn_aptitude = json.get(_field)

    return _learn_aptitude


func get_skill_exp(_skill_name)-> int:

    var _field = SoldierUtils.get_skill_exp_field(_skill_name)
    var _skill_exp = 0
    if json.has(_field):
        _skill_exp = json.get(_field)

    return _skill_exp

func get_skill_level(_skill_name)-> int:
    return self.get(_skill_name)

func get_origin_skill_level(_skill_field: String)-> int:
    var _origin_skill_level: = get_skill_level(_skill_field)
    if SkillUtils.is_intelligence_skill(_skill_field):
        _origin_skill_level -= intelligence_skill_bonus_level

    return _origin_skill_level











func is_oh_weapon():
    return main_weapon_json.oot == WeaponTypeConstants.OOT_ENUM.ONE


func is_th_weapon():
    return not is_oh_weapon()


func update_allow_remote(_allow_remote: bool):
    allow_remote = _allow_remote

func get_main_weapon_stype()-> String:
    return main_weapon_json.stype


func update_hit_ratio_by_min_max(_target_distance: float)-> void:
    hit_ratio = CommonUtils.get_section_value(
        [hit_ratio_max, hit_ratio_min],
        [0, attack_range], _target_distance
    )

func get_ehp()-> int:


    var _e_hp: int = CommonUtils.get_value(vice_weapon_json, "e_hp", 0)

    return GoodsUtils.get_real_e_hp(_e_hp, practise_oh_shield)

func get_b_ehp()-> int:
    return CommonUtils.get_value(b_vice_weapon_json, "e_hp", 0)

func get_wages_10_days_int()-> int:
    return int(wages_daily * 10)

func armor_open()-> void:
    body_def = 0
    body_crit_def = 0
    def = int(body_def + CommonUtils.get_value_sum(
        [vice_weapon_json], "def"
    ))
    crit_def = int(body_crit_def + CommonUtils.get_value_sum(
        [vice_weapon_json], "crit_def"
    ))

func armor_open_cancel()-> void:
    body_def = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "def"
    )
    body_crit_def = CommonUtils.get_value_sum(
        [armour_json, helmet_json, shoe_json, shoulder_json], "crit_def"
    )
    def = int(body_def + CommonUtils.get_value_sum(
        [vice_weapon_json], "def"
    ))
    crit_def = int(body_crit_def + CommonUtils.get_value_sum(
        [vice_weapon_json], "crit_def"
    ))


func plus_atk_ratio(_ratio: float)-> void:
    atk_ratio += _ratio
    atk = max(int(base_atk * atk_ratio), 0)

func melee_perfect_hit()-> void:
    open_melee_perfect_hit_buff = true
    hit_ratio = 1.0

func cancel_melee_perfect_hit()-> void:
    open_melee_perfect_hit_buff = false
    hit_ratio = origin_hit_ratio


func _plus_intelligence_skill()-> void:
    if intelligence_skill_bonus_level == 0:
        return

    for _skill_field: String in SkillConstants.SKILL_CONFIG.keys():
        if SkillUtils.is_intelligence_skill(_skill_field):
            if SkillUtils.is_special_skill(_skill_field):

                if get_origin_skill_level(_skill_field) > 0:
                    set(_skill_field, get(_skill_field) + intelligence_skill_bonus_level)
            else:
                set(_skill_field, get(_skill_field) + intelligence_skill_bonus_level)


func _handle_weapon_index()-> void:
    if weapon1_json != null:
        weapon1_json.weapon_index = 1
    if weapon2_json != null:
        weapon2_json.weapon_index = 2
    if weapon3_json != null:
        weapon3_json.weapon_index = 3


func _assemble_and_choose_weapon():

    _assemble_weapon()

    choose_weapon()


func _assemble_weapon():
    weapon_assemble_dic = {}
    var _weapon_json_list: = [weapon1_json, weapon2_json, weapon3_json]

    for _index in range(_weapon_json_list.size()):
        var _item_json = _weapon_json_list[_index]


        if GoodsUtils.is_null_json(_item_json):
            continue

        if SoldierPartUtils.is_forbid(_weapon_json_list[_index]):
            _weapon_json_list[_index] = null


        if SoldierUtils.is_cavalry(self):
            if _item_json.has("cavalvy_forbid") and _item_json.cavalvy_forbid:
                _weapon_json_list[_index] = null


            if _item_json.stype == WeaponTypeConstants.STYPE_ENUM.OH_LANCE and horse_json != null and CommonUtils.get_value(horse_json, "lance_forbid", false):
                _weapon_json_list[_index] = null
        else:
            if _item_json.has("infantry_forbid") and _item_json.infantry_forbid:
                _weapon_json_list[_index] = null


    var _bshield_weapon_json = null
    var _shield_weapon_json_list = []

    var _has_close_in_switch = false
    for _weapon_json in _weapon_json_list:



        if GoodsUtils.is_null_json(_weapon_json):
            continue


        if StringUtils.equals(_weapon_json.utype, WeaponTypeConstants.USER_TYPE_ENUM.CLOSE_IN_SWITCH):
            _has_close_in_switch = true


        if _bshield_weapon_json == null and StringUtils.equals(_weapon_json.utype, WeaponTypeConstants.USER_TYPE_ENUM.LARGE_SHIELD):
            _bshield_weapon_json = _weapon_json
            continue


        if StringUtils.equals(_weapon_json.utype, WeaponTypeConstants.USER_TYPE_ENUM.SHIELD):
            _shield_weapon_json_list.append(_weapon_json)
            continue


    if not _has_close_in_switch:
        _weapon_json_list.append(
            GoodsUtils.get_json_by_simple_json(
                {
                    "uid": BSSoldierConfig.DEFAULT_CLOSE_IN_SWITCH_WEAPON_UID
                }
                , ic_type
            )
        )


    is_has_remote_switch = false
    is_has_remote_weapon = false
    var _main_weapon_user_type_list = WeaponTypeConstants.MAIN_WEAPON_USER_TYPE_LIST
    for _weapon_json in _weapon_json_list:


        if GoodsUtils.is_null_json(_weapon_json):
            continue

        if not _main_weapon_user_type_list.has(_weapon_json.utype):
            continue

        if weapon_assemble_dic.has(_weapon_json.utype):
            continue

        var _weapon_assemble_list = []
        _weapon_assemble_list.append(_weapon_json)


        var _temp_shield_weapon_json_list = _shield_weapon_json_list.duplicate(false)
        if _weapon_json.oot == WeaponTypeConstants.OOT_ENUM.ONE and ArrayUtils.is_not_empty(_temp_shield_weapon_json_list):
            _weapon_assemble_list.append(_temp_shield_weapon_json_list.pop_front())
        else:

            _weapon_assemble_list.append(null)


        if _bshield_weapon_json != null:
            _weapon_assemble_list.append(_bshield_weapon_json)
        elif ArrayUtils.is_not_empty(_temp_shield_weapon_json_list):


            for _index: int in range(_temp_shield_weapon_json_list.size() - 1, -1, -1):
                var _shield_weapon_json: Dictionary = _temp_shield_weapon_json_list[_index]
                if not CommonUtils.get_value(_shield_weapon_json, "disable_back_equip", false):
                    _weapon_assemble_list.append(_shield_weapon_json)
                    _temp_shield_weapon_json_list.remove_at(_index)
                    break

            _weapon_assemble_list.append(null)
        else:

            _weapon_assemble_list.append(null)

        weapon_assemble_dic[_weapon_json.utype] = _weapon_assemble_list
        if not is_has_remote_switch and _weapon_json.utype == WeaponTypeConstants.USER_TYPE_ENUM.REMOTE_SWITCH:
            is_has_remote_switch = true

        if not is_has_remote_weapon and WeaponTypeConstants.ALLOW_REMOTE_WEAPON_STYPE_LIST.has(_weapon_json.stype):
            is_has_remote_weapon = true







func _choose_weapon2(_weapon_json_list: Array):
    main_weapon_json = _weapon_json_list[0]
    vice_weapon_json = _weapon_json_list[1]
    b_vice_weapon_json = _weapon_json_list[2]

    lethal_strike_5000_rate = 0.0






    if WeaponTypeConstants.ALLOW_REMOTE_WEAPON_STYPE_LIST.has(main_weapon_json.stype):
        is_use_remote_weapon = true
    else:
        is_use_remote_weapon = false

    if WeaponTypeConstants.REMOTE_SOLDIER_WEAPON_STYPE_LIST.has(main_weapon_json.stype):
        is_use_long_range_weapon = true
    else:
        is_use_long_range_weapon = false

    if main_weapon_json.utype == WeaponTypeConstants.USER_TYPE_ENUM.REMOTE_SWITCH:
        is_use_remote_switch = true
    else:
        is_use_remote_switch = false


    if b_vice_weapon_json != null and b_vice_weapon_json.stype == WeaponTypeConstants.WEAPON_BTYPE_ENUM.L_SHIELD \

    and WeaponTypeConstants.L_SHIELD_PLACE_MAIN_WEAPON_STYPE_LIST.has(main_weapon_json.stype):
        attack_allow_place_l_shield = true
    else:
        attack_allow_place_l_shield = false


    atk = CommonUtils.get_value_sum(
        [main_weapon_json], "atk"
    )
    hit_ratio = CommonUtils.get_value_sum(
        [main_weapon_json], "hit_ratio"
    )
    crit_prob = CommonUtils.get_value_sum(
        [main_weapon_json], "crit_prob"
    )
    hit_ratio_min = CommonUtils.get_value_sum(
        [main_weapon_json], "hit_ratio_min"
    )
    hit_ratio_max = CommonUtils.get_value_sum(
        [main_weapon_json], "hit_ratio_max"
    )
    misfire_ratio_rain_min = CommonUtils.get_value_sum(
        [main_weapon_json], "misfire_ratio_rain_min"
    )
    misfire_ratio_rain_max = CommonUtils.get_value_sum(
        [main_weapon_json], "misfire_ratio_rain_max"
    )


    var _attack_plus_ratio_real: = 0.0



    if main_weapon_json.btype == WeaponTypeConstants.WEAPON_BTYPE_ENUM.OH_THROW:

        _attack_plus_ratio_real += attack_damage_plus_oh_throw

    if GoodsUtils.is_th_melee(main_weapon_json.stype):

        _attack_plus_ratio_real += attack_damage_plus_th_melee

    if GoodsUtils.is_oh_melee(main_weapon_json.stype):

        _attack_plus_ratio_real += attack_damage_plus_oh_melee

    if main_weapon_json.stype == WeaponTypeConstants.STYPE_ENUM.TH_BOW:

        _attack_plus_ratio_real += th_bow_attack_plus_ratio
        crit_prob += th_bow_plus_crit_prob_ratio






    if[
        WeaponTypeConstants.STYPE_ENUM.TH_CROSSBOW,
        WeaponTypeConstants.STYPE_ENUM.TH_FIREARM
    ].has(main_weapon_json.stype):
        crit_prob += th_crossbow_plus_crit_prob_ratio


    crit_prob = crit_prob * SoldierUtils.get_crit_prob_plus_ratio_by_base_agile(base_agile)
    crit_atk_ratio = CommonUtils.get_value_sum(
        [main_weapon_json], "crit_atk_ratio"
    )

    crit_atk_ratio = crit_atk_ratio * SoldierUtils.get_crit_prob_plus_ratio_by_base_agile(base_agile)
    want_attack_range = CommonUtils.get_value_sum(
        [main_weapon_json], "want_attack_range"
    )
    attack_range = CommonUtils.get_value_sum(
        [main_weapon_json], "attack_range"
    )


    if melee_attack_range_plus > 0 and get_attack_type() == WeaponTypeConstants.ATTACK_TYPE_ENUM.CLOSE_IN:
        attack_range += melee_attack_range_plus

    block_prob = CommonUtils.get_value_sum(
        [vice_weapon_json], "block_prob"
    )
    b_block_prob = CommonUtils.get_value_sum(
        [b_vice_weapon_json], "b_block_prob"
    )
    stun_prop = CommonUtils.get_value_sum(
        [main_weapon_json], "stun_prop"
    )
    if stun_prop > 0:
        stun_prop += melee_stun_prop_plus

    stun_second = CommonUtils.get_value_sum(
        [main_weapon_json], "stun_second"
    )
    stun_second += melee_stun_second_plus


    shot_accuracy = CommonUtils.get_value_sum(
        [main_weapon_json], "shot_accuracy"
    )
    shot_accuracy += body_shot_accuracy
    knock_back = CommonUtils.get_value_sum(
        [main_weapon_json], "knock_back"
    )
    capture_prob = CommonUtils.get_value_sum(
        [main_weapon_json], "capture_prob"
    )

    def = int(body_def + CommonUtils.get_value_sum(
        [vice_weapon_json], "def"
    ))
    crit_def = int(body_crit_def + CommonUtils.get_value_sum(
        [vice_weapon_json], "crit_def"
    ))



    armor_pen_5_seconds_rate = CommonUtils.get_value_sum(
        [main_weapon_json], "armor_pen_5_seconds_rate"
    )

    attack_range_square = attack_range * attack_range
    attack_range_small_square = pow(attack_range - 10, 2)

    melee_damage_to_stunned_target_plus = CommonUtils.get_value_sum(
        [main_weapon_json], "melee_damage_to_stunned_target_plus"
    )
    melee_damage_to_stunned_target_plus += body_equipment_melee_damage_to_stunned_target_plus

    practise_mobile = base_practise_mobile + CommonUtils.get_value_sum(
        [main_weapon_json], "practise_mobile"
    )
    practise_mobile = SoldierUtils.limit_practise(practise_mobile, "practise_mobile")


    var _practise_field = SoldierUtils.get_practise_field(main_weapon_json)


    var _attack_speed_plus_ratio = CommonUtils.get_value_sum(
        [main_weapon_json, armour_json, helmet_json, shoulder_json, shoe_json], "attack_speed_plus"
    )


    if main_weapon_json.stype == WeaponTypeConstants.STYPE_ENUM.TH_BOW:
        _attack_speed_plus_ratio += attack_speed_plus_th_bow
        lethal_strike_5000_rate = bow_lethal_strike_5000_rate


    if[
        WeaponTypeConstants.STYPE_ENUM.TH_CROSSBOW,
        WeaponTypeConstants.STYPE_ENUM.TH_FIREARM
    ].has(main_weapon_json.stype):
        _attack_speed_plus_ratio += attack_speed_plus_th_crossbow


    if skill_special_blunt_master > 0 and GoodsUtils.is_blunt(main_weapon_json.stype):
        _attack_speed_plus_ratio +=(0.05 + skill_special_blunt_master * 0.01)


    if attack_speed_plus_th_melee > 0 and GoodsUtils.is_th_melee(main_weapon_json.stype):
        _attack_speed_plus_ratio += attack_speed_plus_th_melee

    if attack_speed_plus_oh_melee > 0 and GoodsUtils.is_oh_melee(main_weapon_json.stype):
        _attack_speed_plus_ratio += attack_speed_plus_oh_melee

    if hit_ratio == 0:
        hit_ratio = 1


    weapon_special_attr_dic = GoodsUtils.get_weapon_special_attr_dic(main_weapon_json)

    if CommonUtils.get_value(main_weapon_json, "attack_ignore_def_by_practise_0_5", false):
        weapon_special_attr_dic.ignore_def =(self.get(_practise_field) * 0.5)


    if main_weapon_json.btype == WeaponTypeConstants.WEAPON_BTYPE_ENUM.OH_LANCE:
        search_enemy_interval = BSSoldierConfig.SEARCH_ENEMY_INTERVAL / 2
    else:
        search_enemy_interval = BSSoldierConfig.SEARCH_ENEMY_INTERVAL


    if is_use_remote_weapon:
        var _shot_accuracy_ratio: = 1.0
        var _attack_range_ratio: = 1.0
        var _atk_ratio: = 1.0
        if not is_day:
            _shot_accuracy_ratio = BattleSceneConfig.NIGHT_REMOTE_SHOT_ACCURACY_RATIO
            _attack_range_ratio = BattleSceneConfig.NIGHT_REMOTE_RANGE_RATIO


        var _weather_config = BattleSceneConfig.WEATHER_BUFF_CONFIG.get(weather)
        if _weather_config != null:
            if _weather_config.has("remote_range_ratio"):
                _attack_range_ratio *= _weather_config.remote_range_ratio
            if _weather_config.has("remote_atk_ratio"):
                _atk_ratio *= _weather_config.remote_atk_ratio
            if _weather_config.has("remote_shot_accuracy_ratio"):
                _shot_accuracy_ratio *= _weather_config.remote_shot_accuracy_ratio

        shot_accuracy *= _shot_accuracy_ratio
        attack_range *= _attack_range_ratio
        want_attack_range *= _attack_range_ratio
        attack_range_square = attack_range * attack_range
        attack_range_small_square = pow(attack_range - 10, 2)

        atk = int(atk * _atk_ratio)


    if SoldierUtils.is_cavalry(self) and WeaponTypeConstants.ALLOW_MOBILE_SHOOTING_WEAPON_STYPE_LIST.has(main_weapon_json.stype):
        is_allow_mobile_shooting = true
    else:
        is_allow_mobile_shooting = false


    if SoldierUtils.is_cavalry(self):


        var _horse_hit_rate_info: Dictionary = SoldierUtils.get_horse_hit_rate_info(
            horse_json.stability, practise_horse, practise_mobile, attack_range
        )

        hit_ratio *= _horse_hit_rate_info.melee_hit_rate
        shot_accuracy *= _horse_hit_rate_info.ranged_hit_rate


        attack_range_mobile_shooting = attack_range * _horse_hit_rate_info.ranged_range_ratio
        attack_range_square_mobile_shooting = attack_range_mobile_shooting * attack_range_mobile_shooting
        want_attack_range_mobile_shooting = want_attack_range * _horse_hit_rate_info.ranged_range_ratio


    if main_weapon_json.has("flyer_path"):
        flyer_texture_path = main_weapon_json.flyer_path
    else:
        flyer_texture_path = null

    if main_weapon_json.has("throw_rotate"):
        throw_rotate = main_weapon_json.throw_rotate
    else:
        throw_rotate = false

    if main_weapon_json.has("flyer_speed"):
        flyer_speed = main_weapon_json.flyer_speed
    else:
        flyer_speed = 0


    if main_weapon_json.stype == WeaponTypeConstants.STYPE_ENUM.OH_LANCE and practise_oh_lance > 0:
        var _practise_oh_lance_effect_ratio: float = PractiseUtils.get_practise_oh_lance_effect_ratio(practise_oh_lance)
        hit_ratio *=(1 + _practise_oh_lance_effect_ratio)


        atk = int(atk *(1 + _practise_oh_lance_effect_ratio))


    if vice_weapon_json != null and practise_oh_shield > 0:
        var _practise_oh_shield_effect_ratio: float = PractiseUtils.get_practise_oh_shield_effect_ratio(practise_oh_shield)
        block_prob *=(1 + _practise_oh_shield_effect_ratio)

    shot_accuracy = int(shot_accuracy)

    hit_ratio = min(hit_ratio, 1.0)
    crit_prob = min(crit_prob, 1.0)

    block_prob = min(block_prob, 0.8)


    origin_hit_ratio = hit_ratio
    if open_melee_perfect_hit_buff:
        hit_ratio = 1.0

    attack_speed = SoldierUtils.get_attack_speed(
        weight, self.get(_practise_field),

        _attack_speed_plus_ratio,
        main_weapon_json
    )


    var _strength_plus_atk_ratio: = SoldierUtils.get_atk_plus_ratio_by_base_strength(base_strength)
    if CommonUtils.get_value(main_weapon_json, "ignores_strength_bonus_atk", false):
        _strength_plus_atk_ratio = 1.0

    atk = int(
        atk * _strength_plus_atk_ratio *(1 + _attack_plus_ratio_real)
    )


    match weather:
        MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
            misfire_ratio = 0.0
        MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN:
            misfire_ratio = misfire_ratio_rain_min
        MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
            misfire_ratio = misfire_ratio_rain_max

    _set_base_atk(atk)


    is_has_panic_buff_weapon_small_to_cavalry = CommonUtils.get_value(main_weapon_json, "panic_buff_weapon_small_to_cavalry", false)
    is_has_panic_buff_weapon_big_to_cavalry = CommonUtils.get_value(main_weapon_json, "panic_buff_weapon_big_to_cavalry", false)

func _set_base_atk(_base_atk: int)-> void:
    base_atk = _base_atk
    atk = max(int(base_atk * atk_ratio), 0)