extends Node

@onready var status_machine_idle_node =$StatusMachineIdle
@onready var status_machine_move_node =$StatusMachineMove
@onready var status_machine_attack_node =$StatusMachineAttack
@onready var status_machine_move_and_se_node =$StatusMachineMoveAndSE
@onready var status_machine_move_to_enemy_node =$StatusMachineMoveToEnemy
@onready var status_machine_die_node =$StatusMachineDie
@onready var status_machine_prepare_node =$StatusMachinePrepare
@onready var status_machine_lance_move_node =$StatusMachineLanceMove
@onready var status_machine_lance_pack_up_node =$StatusMachineLancePackUp
@onready var status_machine_dieing_node =$StatusMachineDieing
@onready var status_machine_stun_node =$StatusMachineStun
@onready var status_machine_flee_node =$StatusMachineFlee
@onready var status_machine_set_pike_node =$StatusMachineSetPike

var soldier_node: BSSoldier = owner
var current_status_machine_node = null
var status_machine_node_dic = {}

func _ready():
    await owner.ready

    status_machine_node_dic = {
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE: status_machine_idle_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE: status_machine_move_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.ATTACK: status_machine_attack_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_AND_SE: status_machine_move_and_se_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY: status_machine_move_to_enemy_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE: status_machine_die_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE: status_machine_prepare_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_MOVE: status_machine_lance_move_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_PACK_UP: status_machine_lance_pack_up_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIEING: status_machine_dieing_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN: status_machine_stun_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE: status_machine_flee_node,
        BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.SET_PIKE: status_machine_set_pike_node,
    }

func _physics_process(_delta):
    current_status_machine_node.action()

func get_action_status():
    return current_status_machine_node.get_action_status()

func change_status(_action_status):
    if current_status_machine_node != null:
        if current_status_machine_node.get_action_status() == _action_status:
            current_status_machine_node.enter_necessary()
            return

        var _success = current_status_machine_node.exit_status(_action_status)
        if not _success:
            return

    current_status_machine_node = status_machine_node_dic.get(_action_status)
    current_status_machine_node.enter_status();