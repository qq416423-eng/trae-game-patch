extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():
    if soldier_node.is_infantry() or soldier_node.is_use_remote_weapon():
        soldier_node.stop_move()


    if soldier_node.bs_soldier_prop.attack_allow_place_l_shield:
        soldier_node.call_deferred("_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.SET_SHIELD, soldier_node.buff_icon_root_node)
        soldier_node.prepare_action = BSSoldierConstants.PREPARE_ACTION_ENUM.PLACE_L_SHIELD
        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE)
        return









    soldier_node.play_attack_animation(soldier_node.get_attack_animation_name_enum())

func action():
    if soldier_node.is_cavalry() \

    and soldier_node.is_use_melee_weapon():

        soldier_node.move2(
            soldier_node.attack_target.global_position \
            +(soldier_node.attack_target.global_position - soldier_node.global_position).normalized().rotated(-1.57) * 10,
            soldier_node.get_attack_range_small_square()
        )

func exit_status(_next_status)-> bool:

    if _next_status == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_AND_SE:
        return false

    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.ATTACK