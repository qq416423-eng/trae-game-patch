extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():


    soldier_node.stop_service()




func action():
    pass

func exit_status(_next_status)-> bool:
    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE