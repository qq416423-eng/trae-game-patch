extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():

    soldier_node.close_terrain_buff_handler()
    soldier_node.hide_effect()


    soldier_node.handle_living_status_death()

    soldier_node.flyer_root_disappear()
    soldier_node.close_collision(false)





    if soldier_node._mod_has_fear_equipment():
        soldier_node.helmet_node.hide()
        soldier_node.horse_disappear()
        soldier_node.hero_tag_disappear()
        soldier_node.change_weapon_tag_root_disappear()
        soldier_node.mod_vanish_after_death()
        soldier_node.emit_die_sign()
        soldier_node._set_attack_target(null)
        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE)
        return



    if SoldierUtils.is_conquest_knight_soldier(soldier_node.simple_json):
        soldier_node.helmet_node.hide()
        soldier_node.horse_disappear()
        soldier_node.hero_tag_disappear()
        soldier_node.change_weapon_tag_root_disappear()
        soldier_node.mod_vanish_after_death()
        soldier_node.emit_die_sign()
        soldier_node._set_attack_target(null)
        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE)
        return

    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.DIE, str(CommonUtils.random_num2(0, 1)))


    if soldier_node.bs_soldier_prop != null and soldier_node.bs_soldier_prop.helmet_json != null:
        if soldier_node.bs_soldier_prop.helmet_json.get("vanish_on_death", false):
            soldier_node.helmet_node.hide()

    soldier_node.horse_disappear()
    soldier_node.hero_tag_disappear()
    soldier_node.change_weapon_tag_root_disappear()

    soldier_node.emit_die_sign()

    soldier_node._set_attack_target(null)

func action():



    if soldier_node.is_cavalry():
        if not soldier_node.inertial_move(2):
            return

    if soldier_node.knock_back_vector == Vector2.ZERO:
        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE)

func exit_status(_next_status)-> bool:
    if _next_status != BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIE:
        return false

    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.DIEING