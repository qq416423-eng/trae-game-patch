extends StatusMachineBase

var soldier_node: BSSoldier = null
var counter: int = 0

func _ready():
    soldier_node = owner

func enter_status():
    soldier_node.handle_enter_flee()

    var _flee_target: Vector2 = GlobalNode.battle_scene.get_flee_target(soldier_node.global_position)
    soldier_node.set_move_target(_flee_target)
    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE)

    soldier_node._set_attack_target(null)

func action():
    counter += 1
    soldier_node.move()


    if counter % 30 == 0 and GlobalNode.battle_scene.check_out_map_edge(soldier_node.global_position):
        soldier_node.handle_flee_success()

func exit_status(_next_status)-> bool:
    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE