extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():
    if soldier_node.move_target != Vector2.ZERO \
    and soldier_node.move_mode == BSSoldierConstants.MOVE_MODE_ENUM.DIRECT_MOVE:
        soldier_node.move_to_target(soldier_node.move_target)
        return






    var _flag = soldier_node.maybe_change_weapon_remote()
    if _flag:
        return









    if soldier_node.move_target != Vector2.ZERO and soldier_node.move_mode == BSSoldierConstants.MOVE_MODE_ENUM.MAS_MOVE:
        soldier_node.move_and_se(soldier_node.move_target)
        return

    soldier_node.stop_move()






    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.IDLE)

func action():

    if soldier_node.counter % BSSoldierConfig.SEARCH_ENEMY_INTERVAL == 0:




        soldier_node.handle_search_enemy()


    if CommonUtils.counter_is_true(soldier_node.counter, BSSoldierConfig.SEARCH_ENEMY_INTERVAL):
        soldier_node.maybe_change_weapon_remote()

func exit_status(_next_status)-> bool:
    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE