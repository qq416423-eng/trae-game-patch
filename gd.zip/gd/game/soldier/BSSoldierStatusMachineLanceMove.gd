extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():
    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.FLAT_LANCE)
    soldier_node.handle_attack_direction()

    soldier_node.update_speed_mult(BSSoldierConfig.LANCE_MOVE_SPEED_MULT)
    soldier_node.update_horse_animation_speed(BSSoldierConfig.LANCE_MOVE_SPEED_MULT)
    soldier_node.horse_collision_area_lance_mode()


    if soldier_node.attack_target != null:
        soldier_node.attack_target.maybe_set_pike(soldier_node)

func action():

    if(

            soldier_node.check_enemy_die()
            or CommonUtils.counter_is_true(soldier_node.counter, BSSoldierConfig.SEARCH_ENEMY_INTERVAL)
        ):




        var _success = soldier_node.handle_search_enemy()
        if _success:
            soldier_node.attack_target.maybe_set_pike(soldier_node)

        return






    var is_reach = soldier_node.move2(
        soldier_node.attack_target.global_position \
        +(soldier_node.attack_target.global_position - soldier_node.global_position).normalized().rotated(-1.57) * 10,
        soldier_node.get_attack_range_small_square()
    )




    if is_reach:



        soldier_node.maybe_spike_hurt()


        soldier_node.attack(
            BSSoldierConfig.LANCE_ATTACK_DAMAGE_MULT * soldier_node.velocity.length() / 220,
            true,


            false
        )

        if SoldierUtils.is_living_by_soldier_node(soldier_node):
            soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_PACK_UP)

func exit_status(_next_status)-> bool:
    if _next_status == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_AND_SE:
        return false


    soldier_node.update_speed_mult(1, false)
    soldier_node.update_horse_animation_speed(1)

    soldier_node.horse_collision_area_common_mode()
    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_MOVE