extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():



    var _animation_name_enum = soldier_node.lance_maybe_break()

    soldier_node.play_animation(_animation_name_enum)
    soldier_node.horse_collision_area_lance_mode()


    soldier_node.velocity *= 0.85

func action():


    soldier_node.inertial_move(2)




func exit_status(_next_status)-> bool:




    soldier_node.horse_collision_area_common_mode()


    if soldier_node.want_flee:
        if _next_status == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE:
            return true

        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE)
        return false

    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_PACK_UP