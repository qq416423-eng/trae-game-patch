extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_necessary():
    soldier_node.target_origin_vector = soldier_node.move_target - soldier_node.global_position
    if soldier_node.is_mobile_shooting_action:
        soldier_node.update_direction(false)
    else:

        pass

func enter_status():

    if soldier_node.l_shield_place_instance != null and not soldier_node.l_shield_place_instance.is_break:
        soldier_node.call_deferred("_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.PICK_SHIELD, soldier_node.buff_icon_root_node)
        soldier_node.prepare_action = BSSoldierConstants.PREPARE_ACTION_ENUM.PICK_L_SHIELD
        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE)
        return

    enter_necessary()

    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE)

    if soldier_node.is_allow_mobile_shooting():
        soldier_node.is_mobile_shooting_action = true
        var success = soldier_node.search_enemy()
        if success:
            soldier_node.play_mobile_shooting_animation()
    else:
        soldier_node.is_mobile_shooting_action = false

func action():
    var is_reach = soldier_node.move()
    if is_reach:

        soldier_node.empty_move_target()
        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)

        soldier_node.reach()


    if CommonUtils.counter_is_true(soldier_node.counter, BSSoldierConfig.SEARCH_ENEMY_INTERVAL):
        soldier_node.maybe_change_weapon_remote()


    if soldier_node.is_allow_mobile_shooting() \
    and CommonUtils.counter_is_true(soldier_node.counter, soldier_node.bs_soldier_prop.search_enemy_interval) \
    and soldier_node.check_enemy_die():
        var success = soldier_node.search_enemy()
        if success:
            soldier_node.play_mobile_shooting_animation()

func exit_status(_next_status)-> bool:
    soldier_node.is_mobile_shooting_action = false
    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE