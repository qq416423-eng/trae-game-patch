extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner


func may_lance_move_interrupt()-> bool:

    if soldier_node.get_main_weapon_json().btype == WeaponTypeConstants.WEAPON_BTYPE_ENUM.OH_LANCE:
        if CommonUtils.not_in_scope(soldier_node, soldier_node.attack_target, BSSoldierConfig.LANCE_MOVE_MAX_DISTANCE):
            return false
        if CommonUtils.not_in_scope(soldier_node, soldier_node.attack_target, BSSoldierConfig.LANCE_MOVE_MIN_DISTANCE):
            soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.LANCE_MOVE)
            return true
        else:

            soldier_node.change_weapon_to_close_in()
            return true

    return false

func enter_status():











    if may_lance_move_interrupt():
        return

    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE)


func action():

    if(

            soldier_node.check_enemy_die()
            or CommonUtils.counter_is_true(soldier_node.counter, BSSoldierConfig.SEARCH_ENEMY_INTERVAL)
        ):

        soldier_node.handle_search_enemy()
        soldier_node.maybe_change_weapon_remote()
        return


    if may_lance_move_interrupt():
        return

    var _target_position: Vector2 = soldier_node.attack_target.global_position
    if soldier_node.is_cavalry():

        _target_position +=((_target_position - soldier_node.global_position).normalized().rotated(-1.57) * 10)

    var is_reach = soldier_node.move2(
        _target_position,


        soldier_node.get_attack_range_small_square()
    )



    if is_reach:


        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.ATTACK)

func exit_status(_next_status)-> bool:

    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.MOVE_TO_ENEMY