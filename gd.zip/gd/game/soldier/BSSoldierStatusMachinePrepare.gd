extends StatusMachineBase

var soldier_node: BSSoldier = null
var is_move: = false

func _ready():
    soldier_node = owner

func enter_status():

    soldier_node.start_wait_effect()



    if soldier_node.velocity != Vector2.ZERO:
        is_move = true
        soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE)
    else:
        is_move = false
        soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.IDLE)

func action():
    if soldier_node.move_target != Vector2.ZERO \
    and soldier_node.move_mode == BSSoldierConstants.MOVE_MODE_ENUM.DIRECT_MOVE:
        if not is_move:
            is_move = true
            soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE)

        soldier_node.move()
        return

    if SoldierUtils.is_living_by_soldier_node(soldier_node.attack_target):
        if not is_move:
            is_move = true
            soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.MOVE)

        soldier_node.move2(soldier_node.attack_target.global_position, soldier_node.get_attack_range_square())
        return

    if is_move:
        is_move = false
        soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.IDLE)



















func exit_status(_next_status)-> bool:

    if soldier_node.want_flee:
        if _next_status == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE:
            return true

        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE)
        return false

    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.PREPARE