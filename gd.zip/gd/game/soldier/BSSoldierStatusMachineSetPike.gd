extends StatusMachineBase

var soldier_node: BSSoldier = null
var counter: int = 0

func _ready():
    soldier_node = owner

func enter_status():

    var _direction = soldier_node.move_direction
    if soldier_node.attack_target != null \
    and soldier_node.attack_target.move_direction == _direction:
        _direction = CommonUtils.get_opposite_direction(_direction)
        soldier_node.update_direction3(_direction)

    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.SET_PIKE)
    soldier_node.add_set_pike_effect()

func action():

    if CommonUtils.counter_is_true(counter, 10):
        var alow_pick_pike = soldier_node.check_pike_sign()
        if alow_pick_pike:
            soldier_node.add_pick_pike_effect()
            soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.IDLE)

func exit_status(_next_status)-> bool:
    soldier_node.pike_sign_node_list = []
    counter = 0
    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.SET_PIKE