extends StatusMachineBase

var soldier_node: BSSoldier = null

func _ready():
    soldier_node = owner

func enter_status():
    soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.STUN_IDLE)

    soldier_node.show_stun_effect()


func action():
    soldier_node.stun_counter -= 1


    if SoldierUtils.is_cavalry(soldier_node.bs_soldier_prop):
        var _slow_down_finish: = soldier_node.inertial_move(3)
        if _slow_down_finish:
            soldier_node.play_animation(BSSoldierConstants.ANIMATION_NAME_ENUM.IDLE)

    if soldier_node.stun_counter <= 0:

        soldier_node.handle_search_enemy()

func exit_status(_next_status)-> bool:
    soldier_node.hide_stun_effect()


    if soldier_node.want_flee:
        if _next_status == BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE:
            return true

        soldier_node.change_status(BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.FLEE)
        return false

    return true

func get_action_status():
    return BSSoldierConstants.BS_SOLDIER_ACTION_ENUM.STUN