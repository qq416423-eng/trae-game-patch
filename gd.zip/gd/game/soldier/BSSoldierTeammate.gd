class_name BSSoldierTeammate extends BSSoldier

func _custom_init_chat_bubble(_battle_chat_bubble_node: BattleChatBubble, _content: String)-> void:
    _battle_chat_bubble_node.init(
        _content, 4, BattleChatBubble.LEFT_OR_RIGHT_ENUM.LEFT,
        BattleChatBubble.BACKGROUND_COLOR_ENUM.GREEN
    )