class_name BSSoldierTeammateHeroOrLeader extends BSSoldierTeammate

func _custom_init()-> void:
    BattleChatUtils.init_dialogue_gd(self)

func custom_charge_chat()-> void:
    BattleChatUtils.custom_charge_chat(self)

func custom_kill_hero_chat(_target_hero_name: String)-> void:
    BattleChatUtils.custom_kill_hero_chat(self, _target_hero_name)

func custom_maybe_injured_chat(
    _hp: int, _pre_hp: int,
    _hp_max: int
)-> void:
    BattleChatUtils.custom_maybe_injured_chat(
        self, _hp, _pre_hp, _hp_max
    )

func custom_die_chat()-> void:
    BattleChatUtils.custom_die_chat(self)

func custom_ai_defensive_chat()-> void:
    var allow_chat: = BattleChatUtils.check_allow_chat(self)
    if not allow_chat:
        return

    add_chat(dialogue_gd.get_battle_chat_ai_ally_defensive_chat())

func custom_ai_advancing_attack_chat()-> void:
    var allow_chat: = BattleChatUtils.check_allow_chat(self)
    if not allow_chat:
        return

    add_chat(dialogue_gd.get_battle_chat_ai_advancing_attack_chat())

func custom_vectory_chat()-> void:
    BattleChatUtils.custom_vectory_chat(self)

func kill_soldier_hook(_weapon_special_attr_dic: Dictionary)-> void:
    _hero_kill_soldier_hook(_weapon_special_attr_dic)