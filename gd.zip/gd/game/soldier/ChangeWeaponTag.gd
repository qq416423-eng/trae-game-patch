class_name ChangeWeaponTag extends Node2D

@onready var animation_player_node =$AnimationPlayer
@onready var tag_pic_node =$TagPic

func init_and_start(_uid)-> void:
    var _path = GoodsUtils.get_weapon_icon(_uid)
    CommonUtils.update_texture2(tag_pic_node, _path)
    animation_player_node.play("show")

func delete()-> void:
    self.queue_free()

func init_and_start_charge_icon()-> void:
    var _path = "res://resource/icon/weaponIcon/charge_icon.png"
    CommonUtils.update_texture2(tag_pic_node, _path)
    animation_player_node.play("show")

func init_and_start_by_texture2d(_icon: Texture2D)-> void:
    CommonUtils.update_texture3(tag_pic_node, _icon)
    animation_player_node.play("show")