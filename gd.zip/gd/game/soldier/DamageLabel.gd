extends Label

@onready var animation_player_node =$AnimationPlayer
@onready var addition_damage_label_node =$AdditionDamageLabel

func init_and_start(_text, _is_crit, _addition_damage_text = null):
    _text = str(_text)
    if _is_crit:




        self.set("theme_override_colors/font_color", Color("FF4500"))
        self.set("theme_override_font_sizes/font_size", 18)
        self.set("theme_override_constants/outline_size", 4)







    if _addition_damage_text != null:
        _text += str(_addition_damage_text)


    CommonUtils.set_text(self, _text)

    if CommonUtils.is_not_null(animation_player_node):


        animation_player_node.stop()
        animation_player_node.play("play")

func play_miss():
    self.text = str("MISS")

    self.set("theme_override_colors/font_color", CommonConstants.COLOR_ENUM.GRAY)


    animation_player_node.stop()
    animation_player_node.play("play")


func play_heal(_text):
    self.text = str(_text)
    self.set("theme_override_colors/font_color", CommonConstants.COLOR_ENUM.GREEN)
    animation_player_node.stop()
    animation_player_node.play("play")

func destory():
    self.queue_free()
