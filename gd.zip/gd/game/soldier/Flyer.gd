extends Sprite2D
class_name Flyer



@onready var hit_box_node =$HitBox
@onready var destory_timer_node =$DestoryTimer
@onready var animation_player_node =$AnimationPlayer


@export var high_factor_scope = [0.5, 0.2]

@export var high_factor_distance_scope = [800, 200]
@export var precision_distance_scope = [800, 0]








var init_point = Vector2.ZERO

var target_point = Vector2.ZERO

var speed = 0
var atk = 0


var precision_vector_scope: Array[Vector2] = []



var peak_point = Vector2.ZERO

var time_speed: = 0.0


var current_time: = 0.0

var damage_open_time: = 1.0

var end_time: = 1.0
var is_stop = false
var is_open_damage = false


var origin_soldier_node = null

var shoot_direction

var weapon_special_attr_dic

var throw_rotate = false
var target_bgroup: String = BSSoldierConstants.BS_BGROUP_ENUM.ALLY.code
var in_water: = false

func _ready():
    self.hide()
    set_physics_process(false)

func _physics_process(_delta):

    _fly()
    _custom_process()



func init(
    _init_point, _target_point, _target_bgroup,

    _attack_move_vector,

    _origin_soldier_node: BSSoldier,

    is_mobile_shooting_action = false
):
    target_bgroup = _target_bgroup
    origin_soldier_node = _origin_soldier_node
    var _bs_soldier_prop = _origin_soldier_node.bs_soldier_prop

    var _atk = _bs_soldier_prop.atk




    var _shot_accuracy = _bs_soldier_prop.shot_accuracy

    if is_mobile_shooting_action:
        _shot_accuracy = int(_shot_accuracy * BattleSceneConfig.MOBILE_SHOOT_SHOT_ACCURACY_RATIO)




    if _bs_soldier_prop.main_weapon_json != null:
        if _bs_soldier_prop.main_weapon_json.get("straight_shot", false):
            var _shot_dir =(_target_point - _init_point).normalized()
            _init_point = _init_point + _shot_dir * 15

    var _track_vector: Vector2 =(_target_point - _init_point)
    var _track_length = _track_vector.length()



    target_point = _target_point + _attack_move_vector /(800.0 / int(_track_length))

    precision_vector_scope = FlyerUtils.get_precision_vector_scope(_shot_accuracy)


    if _bs_soldier_prop.main_weapon_json != null:
        if _bs_soldier_prop.main_weapon_json.get("straight_shot", false):
            for _i in range(precision_vector_scope.size()):
                precision_vector_scope[_i] = precision_vector_scope[_i] * 0.13

    target_point = _random_position(target_point, int(_track_length))

    init_point = _init_point

    speed = 65
    if _bs_soldier_prop.flyer_speed > 0:
        speed = _bs_soldier_prop.flyer_speed

    atk = _atk
    self.global_position = _init_point
    self.show()











    var _shot_radian_ratio = 1.0
    if _bs_soldier_prop.main_weapon_json.has("shot_radian"):
        _shot_radian_ratio = _bs_soldier_prop.main_weapon_json.shot_radian / 100.0


    var _is_straight_shot: bool = false
    if _bs_soldier_prop.main_weapon_json != null:
        _is_straight_shot = _bs_soldier_prop.main_weapon_json.get("straight_shot", false)

    if _is_straight_shot:
        peak_point = _init_point +(_track_vector / 2)
        time_speed =(speed * 1.0) /(_track_length * 5)
        end_time = 1.0
    else:
        high_factor_scope = [high_factor_scope[0] * _shot_radian_ratio, high_factor_scope[1] * _shot_radian_ratio]


        var _mid_up_vector = Vector2(0, _track_length * CommonUtils.get_section_value(high_factor_scope, high_factor_distance_scope, _track_length))
        peak_point = _init_point +(_track_vector / 2) - _mid_up_vector
        time_speed =(speed * 1.0) /(_track_length * 5)
        end_time = 1 + 8.0 / _mid_up_vector.y

    damage_open_time =(_track_length - 30) * 1.0 / _track_length
    weapon_special_attr_dic = _bs_soldier_prop.weapon_special_attr_dic


    if StringUtils.is_not_empty(_bs_soldier_prop.flyer_texture_path):
        CommonUtils.update_texture2(self, _bs_soldier_prop.flyer_texture_path)


    throw_rotate = _bs_soldier_prop.throw_rotate


func launch():
    set_physics_process(true)

func set_atk(_atk: int)-> void:
    atk = _atk

func stop():
    if is_stop:
        return

    is_stop = true
    set_physics_process(false)

    hit_box_node.set_deferred("monitorable", false)

    set_deferred("y_sort_enabled", true)

    destory_timer_node.start()
    set_deferred("z_index", 0)
    _custom_stop()


func destory():
    self.queue_free()










func set_in_water(_in_water: bool)-> void:
    in_water = _in_water

func _custom_process()-> void:
    pass

func _custom_stop()-> void:
    pass


func _fly():
    var q0 = init_point.lerp(peak_point, current_time)
    var q1 = peak_point.lerp(target_point, current_time)

    var r = q0.lerp(q1, current_time)


    self.global_position = r

    if throw_rotate:
        self.rotation += 0.6 * GlobalTimeControl.current_time_scale
    else:
        self.rotation = q0.direction_to(q1).angle()

    current_time += time_speed * GlobalTimeControl.current_time_scale

    if current_time > end_time:
        stop()

        if in_water:


            var _battle_scene = GlobalNode.battle_scene
            if _battle_scene != null and is_instance_valid(_battle_scene):
                _battle_scene.call_deferred(
                    "_add_effect",
                    BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.ARROW_SPLASH_EFFECT,
                    hit_box_node.global_position
                )

            _on_destory_timer_timeout()
    elif current_time > damage_open_time:
        _damage_open()

func _damage_open():
    if is_open_damage:
        return

    is_open_damage = true


    match target_bgroup:
        BSSoldierConstants.BS_BGROUP_ENUM.ALLY.code:
            hit_box_node.collision_layer = 2
        BSSoldierConstants.BS_BGROUP_ENUM.ENEMY.code:
            hit_box_node.collision_layer = 4


func _random_position(_target_point, _distance):
    var _precision_vector = CommonUtils.get_section_value(precision_vector_scope, precision_distance_scope, _distance)

    return CommonUtils.random_position(_target_point - _precision_vector, _target_point + _precision_vector)

func _on_destory_timer_timeout():
    animation_player_node.play("destory")