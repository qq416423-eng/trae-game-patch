class_name FlyerAdhering extends Sprite2D

@onready var destory_timer_node = $DestoryTimer
@onready var animation_player_node = $AnimationPlayer

func init(_flyer_node: Flyer, _scale: Vector2 = Vector2(1, 1)):
    self.texture = _flyer_node.texture
    self.global_position = _flyer_node.global_position
    self.rotation = _flyer_node.rotation
    if _scale.x < 0:
        self.rotation = - self.rotation - PI

    destory_timer_node.start()

func _destory():
    self.queue_free()

func _on_destory_timer_timeout():
    animation_player_node.play("destory")
