class_name FlyerWithTrail extends Flyer

@onready var trail_node: Line2D =$Trail

@export var length: int = 12

var counter: = 0

func _custom_process()-> void:

    trail_node.add_point(global_position)



    if counter >= length:
        trail_node.remove_point(0)

    counter += 1

func _custom_stop()-> void:
    trail_node.hide()