class_name FocusFireCircle02 extends Node2D

@onready var animation_player_node =$AnimationPlayer

func start():
    animation_player_node.play("show")

func show_finish():
    queue_free()