class_name GroupCard extends Control

@onready var animation_player_node =$AnimationPlayer
@onready var button_background_node =$ModuleRoot / ButtonBackground
@onready var button_all_background_node =$ModuleRoot / ButtonAllBackground
@onready var group_card_nop_bar_node =$ModuleRoot / ButtonBackground / CountRoot / GroupCardNopBar
@onready var count_node =$ModuleRoot / ButtonBackground / CountRoot / Count
@onready var group_card_hero_box_node =$ModuleRoot / ButtonBackground / HeroRoot / GroupCardHeroBox
@onready var group_card_hero_box_2_node =$ModuleRoot / ButtonBackground / HeroRoot / GroupCardHeroBox2
@onready var group_card_icon_node =$ModuleRoot / ButtonBackground / GroupIconRoot / GroupCardIcon
@onready var group_num_node =$ModuleRoot / ButtonBackground / GroupIconRoot / GroupNum
@onready var forbid_effect_node =$ModuleRoot / ButtonBackground / ForbidEffect
@onready var module_root_node =$ModuleRoot

@export var is_all: = false

signal chick_sign(_group_num, _is_choose, _is_full)

var is_choose: = false
var is_forbid: = false
var nop_max: = 0
var nop_current: = 0
var group_num: = -1

func _ready():
    if is_all:
        button_all_background_node.show()
        button_background_node.hide()
    else:
        button_all_background_node.hide()
        button_background_node.show()


func init(_data: Dictionary):
    nop_max = _data.nop
    nop_current = _data.nop
    group_num = _data.group_num
    CommonUtils.set_text(count_node, _data.nop)

    group_card_nop_bar_node.init(_data.nop)


    _handle_hero_data(_data.hero_node_list)


    group_card_icon_node.init(group_num)


func update_count(_plus_count: int):
    var _current_nop: int = group_card_nop_bar_node.update_count(_plus_count)
    CommonUtils.set_text(count_node, _current_nop)


    if _current_nop <= 0:
        _forbid()

func _forbid():
    is_forbid = true

    var tween = get_tree().create_tween()
    tween.tween_property(forbid_effect_node, "modulate", Color(1, 1, 1, 1), 0.2)
    if is_choose:
        animation_player_node.play_backwards("choose")
        is_choose = false

    tween.tween_property(module_root_node, "position", Vector2(0, 16), 0.2)

    group_card_icon_node.forbid_effect()

func update_choose(_choose):
    if _choose == is_choose:
        return

    if is_forbid:
        return

    is_choose = _choose

    if is_choose:
        animation_player_node.play("choose")
    else:
        animation_player_node.play_backwards("choose")


func _handle_hero_data(_hero_node_list: Array):
    if ArrayUtils.is_empty(_hero_node_list):
        return


    var _count_max = 2
    for _hero_node: BSSoldier in _hero_node_list:
        if _count_max <= 0:
            break

        if _count_max == 2:
            group_card_hero_box_node.init(_hero_node)
        else:
            group_card_hero_box_2_node.init(_hero_node)

        _count_max -= 1

func _on_button_pressed():
    if is_forbid:
        return

    if is_choose:
        emit_signal("chick_sign", group_num, is_choose, true)
        return

    is_choose = not is_choose

    if is_choose:
        animation_player_node.play("choose")
    else:
        animation_player_node.play_backwards("choose")

    emit_signal("chick_sign", group_num, is_choose, true)

func _on_incremental_button_pressed():
    if is_forbid:
        return

    is_choose = not is_choose
    if is_choose:
        animation_player_node.play("choose")
    else:
        animation_player_node.play_backwards("choose")

    emit_signal("chick_sign", group_num, is_choose, false)