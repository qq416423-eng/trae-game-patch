class_name GroupCardHeroBox extends Control

@onready var empty_effect_node =$EmptyEffect
@onready var avatar_node =$Avatar
@onready var hero_hp_bar_node =$HeroHpBar

var ref_soldier_node: BSSoldier

func init(_soldier_node: BSSoldier)-> void:
    ref_soldier_node = _soldier_node

    avatar_node.show()
    empty_effect_node.hide()

    avatar_node.init(_soldier_node.bs_soldier_prop)
    show()
    _soldier_node.connect("hurt_sign", _hero_hurt)
    _refresh_hp_bar()


func _hero_hurt():
    _refresh_hp_bar()

func _refresh_hp_bar():
    var _value =(ref_soldier_node.bs_soldier_prop.hp_max - ref_soldier_node.hp) * 100 / ref_soldier_node.bs_soldier_prop.hp_max
    hero_hp_bar_node.value = _value