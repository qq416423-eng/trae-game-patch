class_name GroupCardIcon extends Control

@onready var background_node =$Background
@onready var icon_node =$Icon
@onready var group_num_node =$GroupNum

@export var hide_icon: = false
@export var hide_group_num: = true

func _ready():
    if hide_icon:
        icon_node.hide()

    if not hide_group_num:
        group_num_node.show()

func init(_group_num: int)-> Dictionary:
    var _config = WSData.get_group_icon_config(_group_num)
    init_by_config(_config)
    update_group_num(_group_num)
    return _config

func update_group_num(_group_num: int)-> void:
    var _str = "?"
    if _group_num != -1:
        _str = str(_group_num)

    CommonUtils.set_text(group_num_node, _str)

func init_by_config(_config: Dictionary):
    update_icon(_config.icon_path)
    update_color(_config.color)

func update_icon(_path: String):
    CommonUtils.update_texture2(icon_node, _path)

func update_color(_color: Color):
    CommonUtils.update_color(background_node, _color)

func forbid_effect():
    var tween = get_tree().create_tween()
    tween.tween_property(background_node, "modulate", Color(0.47, 0.47, 0.47, 1), 0.2)

func update_hide_group_num(_hide_group_num: bool)-> void:
    hide_group_num = _hide_group_num

    if hide_group_num:
        group_num_node.hide()
    else:
        group_num_node.show()