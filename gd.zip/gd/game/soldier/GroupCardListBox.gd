class_name GroupCardListBox extends Control

@onready var group_card_node = preload("res://tscn/game/soldier/GroupCard.tscn")
@onready var group_card_all_node = preload("res://tscn/game/soldier/GroupCardAll.tscn")
@onready var h_box_container_node =$HBoxContainer

var group_num_node_dic: = {}
var all_node: GroupCard = null
var child_node_list: = []
var current_group_num: = []
var group_num_list: = []

signal update_choose_sign(_group_num_list)


func init(_init_data: Dictionary)-> void:
    _clear()

    var _temp_data: Array = _init_data.values()
    _temp_data.sort_custom(SortUtils.group_num_asc)


    var _group_card_all_instance = group_card_all_node.instantiate()
    h_box_container_node.add_child(_group_card_all_instance)
    all_node = _group_card_all_instance
    _group_card_all_instance.connect("chick_sign", _click_card)

    for _data: Dictionary in _temp_data:
        if _data.group_num == -1:
            continue

        var _group_card_instance: GroupCard = group_card_node.instantiate()
        h_box_container_node.add_child(_group_card_instance)
        _group_card_instance.init(_data)
        group_num_node_dic[_data.group_num] = _group_card_instance
        child_node_list.append(_group_card_instance)
        _group_card_instance.connect("chick_sign", _click_card)
        group_num_list.append(_data.group_num)

func update_count(_split_group_uid: String, _plus_count: int)-> void:
    var _group_num = WSData.get_group_num(_split_group_uid)
    if not group_num_node_dic.has(_group_num):
        return

    group_num_node_dic.get(_group_num).update_count(_plus_count)

func choose_all():
    _click_card(-1, true, true)


func choose_all_card():
    var _group_num_list: = [-1]
    _group_num_list.append_array(group_num_list)
    current_group_num = _group_num_list
    _update_card_choose_style()

func unchoose_all_card():
    current_group_num = []
    _update_card_choose_style()

func get_choose_group_num_list()-> Array:
    return current_group_num.duplicate(true)

func _click_card(_group_num: int, _is_choose: bool, _is_full: bool)-> Array:
    if _group_num == -1:
        current_group_num = [-1]
        current_group_num.append_array(group_num_list)
    else:
        if _is_full:
            current_group_num = [_group_num]
        else:
            if _is_choose:
                current_group_num.append(_group_num)
            else:
                current_group_num.erase(_group_num)
                current_group_num.erase(-1)

    emit_signal("update_choose_sign", current_group_num)

    _update_card_choose_style()

    return current_group_num

func _update_card_choose_style():
    for _card_node: GroupCard in h_box_container_node.get_children():
        if current_group_num.has(_card_node.group_num):
            _card_node.update_choose(true)
        else:
            _card_node.update_choose(false)

func _clear():
    CommonUtils.clear_node(h_box_container_node)
    group_num_node_dic = {}
    all_node = null
    child_node_list = []
    current_group_num = []
    group_num_list = []