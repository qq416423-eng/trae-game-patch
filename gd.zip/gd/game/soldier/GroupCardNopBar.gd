class_name GroupCardNopBar extends TextureProgressBar

var count_max: = 0
var count_current: = 0

func init(_count_max: int)-> void:
    count_max = _count_max
    count_current = _count_max

    value = 100

func update_count(_plus_count: int)-> int:
    count_current += _plus_count
    value = count_current * 100 / count_max
    return count_current