@tool
class_name HeroPortrait extends Node2D

@onready var whole_pic_node: Sprite2D =$WholePic

@export var custom_region: Rect2 = Rect2(0, 0, 160, 160):
    set(_rect2):
        custom_region = _rect2
        $WholePic.region_rect = _rect2

func init_by_gender(_gender: BSSoldierConstants.GENDER_ENUM):
    var _whole_pic_path: = ""
    match _gender:
        BSSoldierConstants.GENDER_ENUM.MALE:
            _whole_pic_path = "res://resource/portrait/unknow_male.png"
        BSSoldierConstants.GENDER_ENUM.FEMALE:
            _whole_pic_path = "res://resource/portrait/unknow_female.png"

    CommonUtils.update_texture2(whole_pic_node, _whole_pic_path)


func init(_hero_uid: String, use_default: = true)-> Dictionary:
    if StringUtils.is_empty(_hero_uid):
        self.hide()
        return {}

    var _is_whole_pic: = true
    var _whole_pic_path: = ""

    var _leader_json: Dictionary = SoldierUtils.get_json_by_uid(_hero_uid)


    if _hero_uid == "mod_boss_conquest_knight":
        _whole_pic_path = "res://resource/portrait/mod_boss_conquest_knight.png"

    if StringUtils.is_empty(_whole_pic_path) and HeroDefaultData.hero_default_data.has(_hero_uid):
        var _config = HeroDefaultData.hero_default_data.get(_hero_uid)
        if _config.has("use_whole") and _config.use_whole:
            _whole_pic_path = _config.whole_pic

    if StringUtils.is_empty(_whole_pic_path) and use_default:
        match CommonUtils.get_value(_leader_json, "gender", BSSoldierConstants.GENDER_ENUM.MALE):
            BSSoldierConstants.GENDER_ENUM.MALE:
                _whole_pic_path = "res://resource/portrait/unknow_male.png"
            BSSoldierConstants.GENDER_ENUM.FEMALE:
                _whole_pic_path = "res://resource/portrait/unknow_female.png"

    if StringUtils.is_not_empty(_whole_pic_path):
        CommonUtils.update_texture2(whole_pic_node, _whole_pic_path)
        self.show()
    else:
        self.hide()

    return _leader_json