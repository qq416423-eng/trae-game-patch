class_name HeroUpDownAnimation extends AnimatedSprite2D

@export var up_color: Color = CommonConstants.COLOR_ENUM.WHITE
@export var down_color: Color = CommonConstants.COLOR_ENUM.WHITE

func play_up()-> void:
    CommonUtils.update_color(self, up_color)
    play("up")

func play_down()-> void:
    CommonUtils.update_color(self, down_color)
    play("down")

func _on_animation_finished():
    queue_free()