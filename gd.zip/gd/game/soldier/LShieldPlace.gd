class_name LShieldPlace extends Node2D

@onready var l_shield_node =$LShield
@onready var animation_player_node =$AnimationPlayer
@onready var hurt_box_node =$HurtBox
@onready var flyer_adhering_node = preload("res://tscn/game/soldier/FlyerAdhering.tscn")
@onready var flyer_root_node =$FlyerRoot
@onready var soldier_body_effect_node = preload("res://tscn/game/soldier/SoldierBodyEffect.tscn")
@onready var body_effect_root_node =$BodyEffectRoot
@onready var water_mask_node: TextureRect =$LShield / WaterMask

var l_shield_json

var is_break = false

func init(
    _l_shield_json, _start_positon: Vector2,
    _attack_target_position: Vector2,
    _collision_mask: int,
    _in_water: = false
    ):
    l_shield_json = _l_shield_json

    hurt_box_node.collision_mask = _collision_mask


    var _position = _get_place_pisition(_start_positon, _attack_target_position)
    self.global_position = _position


    var _temp_vector: = _attack_target_position - _start_positon
    var _t_path_field
    if _temp_vector.y <= 0:

        _t_path_field = "place_t_path_up"
    else:

        _t_path_field = "place_t_path_down"


    if _temp_vector.x < 0:
        l_shield_node.scale.x *= -1

    if _in_water:
        water_mask_node.show()

    CommonUtils.update_texture(l_shield_node, _l_shield_json, _t_path_field)

    z_index = 10
    animation_player_node.play("show")

func disappear():
    animation_player_node.play("disappear")


func hurt(_atk: int)-> void:

    l_shield_json.e_hp -= _atk
    if l_shield_json.e_hp <= 0:
        is_break = true
        hurt_box_node.monitoring = false
        hurt_box_node.monitorable = false

        call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DEF_BREAK)

        disappear()
        return


    call_deferred("_body_effect_add", BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DEF)

func get_hurt_collision_mask()-> int:
    return hurt_box_node.collision_mask

func _get_place_pisition(_start_positon: Vector2, _attack_target_position: Vector2):
    return _start_positon + Vector2(0, -6) +(_attack_target_position - _start_positon).normalized() * 16


func _on_hurt_box_area_entered(_area):

    var _flyer_node: Flyer = _area.owner
    _flyer_node.stop()


    _flyer_adhering(_flyer_node)


func _flyer_adhering(_flyer_node):

    var flyer_adhering_instance: FlyerAdhering = flyer_adhering_node.instantiate()
    flyer_root_node.add_child(flyer_adhering_instance)
    flyer_adhering_instance.init(_flyer_node, l_shield_node.scale)
    _flyer_node.destory()

    hurt(_flyer_node.atk)


func _body_effect_add(_effect_name_enum):

    var soldier_body_effect_instance = soldier_body_effect_node.instantiate()
    body_effect_root_node.add_child(soldier_body_effect_instance)
    soldier_body_effect_instance.animation_play(_effect_name_enum)

func delete():
    self.queue_free()