class_name LevelBar extends TextureProgressBar

@onready var level_value_node =$LevelValue
@onready var progress_value_node =$ProgressValue
@onready var max_level_effect_node: TextureRect =$MaxLevelEffect

func init_by_hero_uid(_hero_uid):
    var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    self.init(_hero_json.level, _hero_json.exp, SoldierUtils.get_upgrade_need_exp_by_level(_hero_json.level))

func init(_level, _exp, _exp_max):
    CommonUtils.set_text(level_value_node, "LV " + str(_level))


    var _effective_max = BSSoldierConfig.HERO_LEVEL_MAX
    var _player_team = WSData.get_player_team_simple_json_list()
    for _pj in _player_team:
        if _pj.htype == BSSoldierConstants.H_TYPE_ENUM.HERO:
            var _ph = SoldierUtils.get_json2(_pj)
            if CommonUtils.get_value(_ph, "skill_stop_leveling", 0) >= 1:
                _effective_max = 100
                break

    if _level >= _effective_max:
        max_level_effect_node.show()
        return
    else:
        max_level_effect_node.hide()

    self.value = _exp * 100 / _exp_max
    CommonUtils.set_text(progress_value_node, str(self.value) + "%")