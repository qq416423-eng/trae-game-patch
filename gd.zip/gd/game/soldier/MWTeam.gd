class_name MWTeam extends CharacterBody2D

@onready var avatar_node =$Shape / AvatarFrame / Avatar
@onready var navigation_agent_node: NavigationAgent2D =$NavigationAgent2D
@onready var status_machine_node =$StatusMachine
@onready var shape_node =$Shape
@onready var animation_player_node =$AnimationPlayer
@onready var name_node =$InfoRoot / TopInfoRoot / Name
@onready var count_node =$InfoRoot / Count
@onready var focus_effect_node =$Shape / FocusEffect
@onready var select_effect_node =$Shape / SelectEffect
@onready var check_choose_area_node =$CheckChooseArea
@onready var click_effect_node = preload("res://tscn/game/effect/ClickEffect.tscn")


@onready var check_area_node =$AreaRoot / CheckArea
@onready var check_area_collision_shape_2d_node =$AreaRoot / CheckArea / CollisionShape2D
@onready var status_icon_node =$InfoRoot / StatusIcon as MWTeamStatusIcon
@onready var debug_info_status_node =$InfoRoot / DebugInfoStatus
@onready var debug_info_node =$InfoRoot / DebugInfo
@onready var timer_node =$Timer
@onready var role_type_icon_node =$InfoRoot / TopInfoRoot / RoleTypeIcon
@onready var view_focus_effect_node =$Shape / ViewFocusEffect
@onready var view_select_effect_node =$Shape / ViewSelectEffect
@onready var danger_tag_node: TextureRect =$InfoRoot / DangerTag
@onready var info_root_node: Node2D =$InfoRoot
@onready var lord_banner_node: LordBanner =$InfoRoot / LordBanner


@export var is_danger: bool = true

var json = {}




var npc_battle_temp_team = []

var npc_injured_simple_json_list: = []

var is_player = false
var move_type: = MWTeamConstants.MOVE_TYPE_ENUM.NONE

var move_need_flee: = false

var move_need_pursue: = false


var flee_speed_boost_mult: = 1.0
var flee_speed_boost_counter: = 0

var move_target: = Vector2.ZERO

var move_target_node: MWTeam

var current_target_location_code: = ""
var team_info: TeamInfo

var warning_team_list = []



var ai_node: BTRoot

var living_status = MWTeamConstants.LIVING_STATUS_ENUM.ACTIVE

var gate_exit_point: Vector2

var gate_location_code: String = ""

var pre_debug_info_status = ""
var counter: int = CommonUtils.random_num(1000)

var is_show: = false

var is_open_detact: = false



var view_level: = 1



var will_attack_player = true

var will_attack_player_counter: = 0


var ignore_food_consume: = false

var is_in_location: = false

var in_location_code: = ""


var is_init_status: = false

var belong_country: = WSCountryData.COUNTRY_NAME_ENUM.NONE

var belong_robber_faction: = false


func _is_village_garrison()-> bool:
    var _uid: String = json.get("leader_uid", "")
    return _uid == "village_guard" or _uid == "village_defender"

signal player_meet_sign(_meet_node)
signal reach_point_sign()
signal choose_team_sign(_node, _is_left_click)


func _ready():
    if GameConfig.DEBUG_CONFIG_IS_AI_DEBUG:
        debug_info_status_node.show()
    if GameConfig.SHOW_TEAM_DEBUF_INFO:
        debug_info_node.show()

    CommonUtils.update_self_color(view_focus_effect_node, MWorldConstants.VIEW_FOCUS_COLOR)
    CommonUtils.update_self_color(view_select_effect_node, MWorldConstants.VIEW_SELECT_COLOR)


    collision_mask |= 1024

func _physics_process(delta):
    counter += 1
    if will_attack_player_counter > 0:
        will_attack_player_counter -= 1
        if will_attack_player_counter == 0:
            will_attack_player = true


    if flee_speed_boost_counter > 0:
        flee_speed_boost_counter -= 1
        if flee_speed_boost_counter == 0:
            flee_speed_boost_mult = 1.0


    if not is_player and counter % 30 == 0:
        _check_appointed_team_nearby()

    _custom_physics_process(delta)

func init(_json):
    if not _json.has("uid"):
        _json.uid = CommonUtils.generate_uuid(CommonConstants.UUID_PREFIX_ENUM.TEAM)


    WSData.save_team_node(_json.uid, self)

    if _json.has("current_target_location_code"):
        current_target_location_code = _json.current_target_location_code
    if _json.has("is_in_location"):
        is_in_location = _json.is_in_location
    if _json.has("in_location_code") and StringUtils.is_not_empty(_json.in_location_code):
        in_location_code = _json.in_location_code
    if _json.has("belong_country"):
        belong_country = _json.belong_country
    if _json.has("belong_robber_faction"):
        belong_robber_faction = _json.belong_robber_faction

    json = _json

    ignore_food_consume = CommonUtils.get_value(_json, "ignore_food_consume", false)

    self.global_position = _json.position


    refresh_team_info(true)

    avatar_node.init_by_json(get_leader_json())


    show_or_hide_body_and_detect(false, true, true, false)


    _custom_init()

    if get_leader_uid() == "mod_boss_conquest_knight":
        will_attack_player = false
        will_attack_player_counter = -1


    _custom_handle_team_info_color()



    _update_debug_info()


    status_machine_node.start()


    _init_status()




    timer_node.start()

    refresh_injured_simple_json()

    refresh_banner()


func show_or_hide_body_and_detect(
    _is_show_self: bool, _is_open_detect: bool,
    is_force: = false, _player_animation: = true
)-> void:
    _show_or_hide_body(_is_show_self, is_force, _player_animation)
    _open_or_close_detect(_is_open_detect, is_force)

func reset_move_target_node()-> void:
    move_target_node = null

func set_move_target(_target_point: Vector2)-> void:
    move_target = _target_point
    navigation_agent_node.target_position = _target_point


func status_thinking_action()-> void:
    pass


func get_location_sub_status_by_thinking()-> Dictionary:
    return {
        "status": MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_IN,
        "callable": Callable()
    }

func move_to_location(
        _location_code: String,
        _flee: = false,
        _pursue: = false,
        _callable: Callable = Callable()
    )-> void:
    move_need_flee = _flee
    move_need_pursue = _pursue
    move_type = MWTeamConstants.MOVE_TYPE_ENUM.LOCATION
    current_target_location_code = _location_code

    change_status_to_move(_callable)

func move_to_target(
    _target_position: Vector2,
    _flee: = false,
    _pursue: = false
):
    move_need_flee = _flee
    move_need_pursue = _pursue
    move_type = MWTeamConstants.MOVE_TYPE_ENUM.FIXED
    set_move_target(_target_position)

    change_status_to_move()

func move_to_team(
    _node: MWTeam,
    _flee: = false,
    _pursue: = false
):
    move_need_flee = _flee
    move_need_pursue = _pursue
    move_target_node = _node
    move_type = MWTeamConstants.MOVE_TYPE_ENUM.DYNAMIC

    change_status_to_move()

func get_move_target_position()-> Vector2:
    match move_type:
        MWTeamConstants.MOVE_TYPE_ENUM.FIXED:
            return move_target
        MWTeamConstants.MOVE_TYPE_ENUM.DYNAMIC:
            if CommonUtils.is_not_null(move_target_node):
                return move_target_node.global_position
        MWTeamConstants.MOVE_TYPE_ENUM.LOCATION:
            var _loc_node = GlobalLocationData.get_location_node(current_target_location_code)
            if _loc_node:
                return _loc_node.global_position
            return global_position

    return self.global_position

func reset_flee_pursue_setting()-> void:
    move_need_flee = false
    move_need_pursue = false

func clear_move_info()-> void:
    move_type = MWTeamConstants.MOVE_TYPE_ENUM.NONE
    move_need_flee = false
    move_need_pursue = false
    move_target = Vector2.ZERO
    move_target_node = null
    current_target_location_code = ""


func reach_point()-> void:
    pass

func enter_location()-> void:
    pass


func in_location()-> void:
    pass

func reach_location()-> void:
    change_status_to_location_stay()

func exit_location_begin()-> void:
    pass

func exit_location_end()-> void:
    pass

func change_status_to_move(_callable: Callable = Callable())-> void:
    change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.MOVE, _callable)

func change_status_to_location_stay()-> void:
    status_machine_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY)

func change_status_to_location_outside_replenish()-> void:
    status_machine_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_OUTSIDE_REPLENISH)

func change_status_to_idle():
    status_machine_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE)

func change_status(_action_status: int, _callable: Callable = Callable())-> void:
    status_machine_node.change_status(_action_status, _callable)


func load_init_status(_action_status: int)-> void:
    status_machine_node.load_init_status(_action_status)


func change_status_to_thinking()-> void:
    status_machine_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.THINKING)

func get_status()-> MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM:
    return status_machine_node.get_action_status()


func move(_allow_offset_square: int = -1)-> bool:


    var _move_speed = team_info.get_speed() * flee_speed_boost_mult
    velocity =(navigation_agent_node.get_next_path_position() - self.global_position).normalized() * _move_speed
    self.move_and_slide()

    _custom_move()

    if _allow_offset_square < 0:
        return navigation_agent_node.is_navigation_finished()
    else:
        return global_position.distance_squared_to(navigation_agent_node.target_position) < _allow_offset_square




func move_stop():
    velocity = Vector2.ZERO


func handle_maybe_flee_pursue()-> bool:
    if move_need_flee:
        if check_danger():
            change_status_to_flee()

            return true

    if move_need_pursue:
        if check_has_attack_target():
            change_status_to_pursue()

            return true

    return false

func set_move_target_node(_mw_team: MWTeam)-> void:
    move_target_node = _mw_team

func get_json():
    return json


func emit_sign_reach():
    emit_signal("move_reach")



























func delete(_need_plus_power_value: = true):

    _heal_all_hero()


    WSData.delete_team_data(get_uid())

    _custom_handle_delete()

    self.queue_free()









func trade()-> void:

    if json.has("is_trade_finish") and json.is_trade_finish:
        pass
    else:
        var _trade_node = GlobalLocationData.get_location_node(in_location_code)
        if _trade_node:
            _trade_node.trade(json)


























func trade_recycle():



    var _population_total = team_info.total * LocationConfig.POPULATION_TOTAL_REAL_NOP_RATIO
    json.resource_json.population_total = _population_total

    json.resource_json.population_working_age = _population_total




    var _recycle_node = GlobalLocationData.get_location_node(in_location_code)
    if _recycle_node:
        _recycle_node.trade_recycle(json.resource_json)

func show_animation()-> void:
    animation_player_node.play("appear")

func disappear_animation()-> void:
    animation_player_node.play("diappear")


func check_danger()-> bool:
    var _node_list = get_danger_node_list(false, true)
    return ArrayUtils.is_not_empty(_node_list)


func check_has_attack_target()-> bool:
    var _node_list = get_danger_node_list(true, true)
    return ArrayUtils.is_not_empty(_node_list)

func get_pursue_target_node()-> MWTeam:
    var _pursue_node_list: = get_danger_node_list(true)
    if ArrayUtils.is_empty(_pursue_node_list):
        return null

    var _pursue_target_node
    var _nearest_distance_square = pow(100000, 2)
    var _distance_square
    for _node in _pursue_node_list:
        _distance_square = CommonUtils.get_distance_square(self, _node)
        if _distance_square < _nearest_distance_square:
            _nearest_distance_square = _distance_square
            _pursue_target_node = _node

    return _pursue_target_node



func get_danger_node_list(
    _is_power_than: bool,
    require_only_one: = false
)-> Array:


    var _is_villain_boss: bool = false
    if _is_power_than:
        var _npc_code: String = json.get("npc_team_code", "")
        _is_villain_boss = NpcTeamConfig.VILLAIN_BOSS_CONFIG.has(_npc_code)

    var _result = []
    var _node_list = TeamUtils.get_rel_node_list(self, warning_team_list, MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE)

    for _node: MWTeam in _node_list:
        if CommonUtils.is_null(_node):
            continue


        if _node.get_leader_uid() == "minor_hero_0012":
            continue


        if _node.get_leader_uid() == "mod_slave_duel_host":
            continue


        if _node._is_village_garrison():
            if not self.is_player:
                continue

        if _is_power_than and TeamUtils.is_power_than(self, _node):

            if _is_villain_boss and _node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.LORD:
                if not TeamUtils.is_power_than(self, _node, 2.0):
                    continue

            if not will_attack_player and _node.is_player:
                continue


            var _behavior_data: Dictionary = json.get("behavior_data",{})
            if _behavior_data.get("no_attack_lords", false) \
            and _node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.LORD:
                continue


            var _will_spare_enemy_caravan: = _check_will_spare_enemy_caravan(_node)
            if _will_spare_enemy_caravan:
                continue

            _result.append(_node)
            if require_only_one:
                return _result
        elif not _is_power_than and not TeamUtils.is_power_than(self, _node):



            if _node.is_danger:
                _result.append(_node)
                if require_only_one:
                    return _result

    return _result

func unchoose():
    select_effect_node.hide()


func forbid_choose():
    check_choose_area_node.mouse_filter = Control.MouseFilter.MOUSE_FILTER_IGNORE

func allow_choose():
    check_choose_area_node.mouse_filter = Control.MouseFilter.MOUSE_FILTER_STOP

func target_effect():
    var click_effect_instance = click_effect_node.instantiate()
    shape_node.add_child(click_effect_instance)
    click_effect_instance.play_left_click03()



func join_battle(_battle_id: String, _battle_team_type_enum: String = ""):
    if StringUtils.is_empty(_battle_team_type_enum):

        _battle_team_type_enum = TeamUtils.get_ally_battle_team_type_enum(_battle_id, get_uid())

    json.current_battle_id = _battle_id
    json.battle_team_type_enum = _battle_team_type_enum
    WSData.join_battle(_battle_id, _battle_team_type_enum, get_uid())
    change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK)

func get_uid():
    return json.uid

func hurt(_atk: int)-> void:



    var _atk_actual = _atk
    if _is_village_garrison():
        _atk_actual = ceili(_atk * MWConfig.NPC_BATTLE_GARRISON_DAMAGE_MULT)

    var _hurt_nop: = CommonUtils.random_num2(
        1,
        min(npc_battle_temp_team.size(), 20)
    )

    var _damage: = CommonUtils.random_num2(int(_atk_actual * 0.5), _atk_actual)

    var _damage_pre_nop: = int(_damage / _hurt_nop)


    if _is_village_garrison():
        _damage_pre_nop = min(_damage_pre_nop, MWConfig.NPC_BATTLE_GARRISON_DAMAGE_PER_SOLDIER_MAX)





    var _death_to_injured_ratio: float = MWConfig.NPC_BATTLE_DEATH_TO_INJURED_RATIO
    if team_info != null:
        _death_to_injured_ratio = max(
            _death_to_injured_ratio,
            SkillUtils.get_skill_operation_save_prob(team_info.skill_operation)
        )

    var _random_index_list = CommonUtils.get_random_index_list(npc_battle_temp_team.size(), _hurt_nop)
    for _index in _random_index_list:
        SoldierUtils.json_hurt(
            npc_battle_temp_team[_index],
            _damage_pre_nop,
            _death_to_injured_ratio
        )


    npc_battle_temp_team = TeamUtils.list_living_soldier_json(npc_battle_temp_team)



    remove_death_simple_json_and_refresh_nop_info()

    _update_info_count()

func remove_death_simple_json_and_refresh_nop_info()-> void:
    remove_death_soldier_json(true)

    refresh_nop_info()

func refresh_nop_info()-> void:
    team_info.refresh_nop_info2()


func handle_battle_end(
    _battle_result_enum: String,

    _ally_relation_gain_after_battle_factor: float = 0.0,
)-> void:
    clear_battle_data()

    if _battle_result_enum == BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:

        if json.has("appointed_leader_uid") and json.appointed_leader_uid != "":
            _handle_appointed_team_defeated()
            return
        change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)
        return


    refresh_nop_info()

    if get_active_nop() == 0:


        if json.has("appointed_leader_uid") and json.appointed_leader_uid != "":
            _handle_appointed_team_defeated()
            return
        change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)
        return


    _heal_all_hero()


    if json.has("appointed_leader_uid") and json.appointed_leader_uid != "":
        _mod_capture_defeated_to_prison()
        _accumulate_appointed_team_loot()
        _mod_handle_looting_level_up()

    _custom_handle_ally_relation_gain_after_battle(_ally_relation_gain_after_battle_factor)


    json.erase("_pending_loot_enemy_team")

    change_status_to_thinking()

func get_active_nop()-> int:
    return team_info.count

func get_team_atk()-> int:
    return team_info.team_atk




func _mod_capture_defeated_to_prison()-> void:
    var _enemy_team: Array = json.get("_pending_loot_enemy_team",[])
    if _enemy_team.is_empty():
        return

    var _prison_list: Array = WSLocationData.mod_get_player_prison_location_list()
    if _prison_list.is_empty():
        return

    var _candidate_list: Array = []
    for _sj in _enemy_team:
        if not(_sj is Dictionary):
            continue
        if SoldierUtils.is_hero_by_simple_json(_sj):
            continue

        if SoldierUtils.is_conquest_knight_soldier(_sj):
            continue
        _candidate_list.append(_sj)
    if _candidate_list.is_empty():
        return

    var _capture_count: int = int(float(_candidate_list.size()) * 0.08)
    if _capture_count <= 0:
        return
    _capture_count = min(_capture_count, _candidate_list.size())
    var _to_capture: Array = _candidate_list.slice(0, _capture_count)

    var _remaining: int = _to_capture.size()
    var _captured_total: int = 0
    for _prison_info: Dictionary in _prison_list:
        if _remaining <= 0:
            break
        var _loc_code: String = _prison_info.location_code
        var _available: int = _prison_info.available
        var _take: int = min(_remaining, _available)
        if _take <= 0:
            continue
        var _slice: Array = _to_capture.slice(_captured_total, _captured_total + _take)
        var _prison_capture: Array = WSLocationData.get_prison_capture_info(_loc_code)
        _prison_capture.append_array(_slice)
        WSLocationData.save_prison_capture_info(_loc_code, _prison_capture)
        _captured_total += _take
        _remaining -= _take
    if _captured_total > 0:
        var _hero_uid: String = json.appointed_leader_uid
        var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
        var _name: String = SoldierUtils.get_nickname(_hero_json) if not _hero_json.is_empty() else "分队"
        GlobalMessageInterface.add_message(
            MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
            [_name + " 的分队击败敌军，共" + str(_captured_total) + "名俘虏已关入监狱"]
        )




func _accumulate_appointed_team_loot()-> void:
    var _enemy_team: Array = json.get("_pending_loot_enemy_team",[])
    json.erase("_pending_loot_enemy_team")
    if _enemy_team.is_empty():
        return


    var _is_conquest_knight: bool = false
    for _soldier in _enemy_team:
        if _soldier is Dictionary and SoldierUtils.is_conquest_knight_soldier(_soldier):
            _is_conquest_knight = true
            break
    if _is_conquest_knight:
        var _ruby_count: int = CommonUtils.random_num2(30, 50)
        var _goods: Array = WSData.get_player_goods()
        GoodsUtils.add_goods(_goods, "commodity_0027", _ruby_count)
        WSData.save_my_goods(_goods)
        var _hero_uid: String = json.appointed_leader_uid
        var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
        var _name: String = SoldierUtils.get_nickname(_hero_json) if not _hero_json.is_empty() else "分队"
        GlobalMessageInterface.add_message(
            MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
            [_name + " 的分队击败了征伐骑士，获得" + str(_ruby_count) + "个沙漠红宝石"]
        )
        return


    var _star_values: Dictionary = {1: 7, 2: 15, 3: 24, 4: 29, 5: 37}
    var _total_money: int = 0
    for _soldier in _enemy_team:
        if not _soldier is Dictionary:
            continue

        if SoldierUtils.is_conquest_knight_soldier(_soldier):
            continue
        var _star: int = _soldier.get("star", 1)
        if _star < 1:
            _star = 1
        if _star > 5:
            _star = 5
        _total_money += _star_values.get(_star, 7)

    if _total_money < 1:
        return


    var _looting_level: int = json.get("looting_level", 1)
    var _bonus_mult: float = 1.0 + _looting_level * MWConfig.MOD_LOOTING_LEVEL_MONEY_BONUS
    _total_money = int(_total_money * _bonus_mult)


    var _hero_uid: String = json.appointed_leader_uid
    var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    if not _hero_json.is_empty():
        var _current: int = _hero_json.get("appointed_team_loot_money", 0)
        _hero_json["appointed_team_loot_money"] = _current + _total_money



func _mod_handle_looting_level_up()-> void:
    var _win_count: int = json.get("battle_win_count", 0) + 1
    json["battle_win_count"] = _win_count
    if _win_count >= MWConfig.MOD_LOOTING_LEVEL_UP_BATTLES:
        json["battle_win_count"] = 0
        var _current_level: int = json.get("looting_level", 1)
        json["looting_level"] = _current_level + 1
        var _hero_uid: String = json.appointed_leader_uid
        var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
        if not _hero_json.is_empty():
            var _name: String = SoldierUtils.get_nickname(_hero_json)
            GlobalMessageInterface.add_message(
                MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
                [_name + " 的分队掠夺等级提升至 " + str(_current_level + 1) + " 级！战利品获取+3%"]
            )


func _handle_appointed_team_defeated()-> void:
    var _hero_uid: String = json.appointed_leader_uid
    clear_battle_data()

    var _player_node = WSData.get_player_team_node()


    if _player_node == null or not is_instance_valid(_player_node):
        call_deferred("_handle_appointed_team_defeated_retry", _hero_uid)
        return

    _do_appointed_team_return_to_player(_hero_uid, false)

func _handle_appointed_team_defeated_retry(_hero_uid: String)-> void:
    var _player_node = WSData.get_player_team_node()
    if _player_node == null or not is_instance_valid(_player_node):


        if not json.has("_defeated_retry_count"):
            json["_defeated_retry_count"] = 0
        json["_defeated_retry_count"] += 1
        if json["_defeated_retry_count"] < 60:
            call_deferred("_handle_appointed_team_defeated_retry", _hero_uid)
            return

        var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)
        if not _hero_json.is_empty():
            _hero_json.erase("is_appointed_leader")
            _hero_json.erase("appointed_team_code")
        var _assigned_list: Array = json.get("assigned_heroes",[])
        for _assigned_uid in _assigned_list:
            var _assigned_hj = SoldierUtils.get_json_by_hero_uid(_assigned_uid)
            if not _assigned_hj.is_empty():
                _assigned_hj.erase("assigned_to_team")
        push_warning("[AppointedTeam] 分队" + _hero_uid + "战败归队重试超时, 已清除任命标记")
        change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)
        return

    _do_appointed_team_return_to_player(_hero_uid, false)


func _do_appointed_team_return_to_player(_hero_uid: String, _is_recall: bool)-> void:
    var _player_node = WSData.get_player_team_node()

    var _hero_json = SoldierUtils.get_json_by_hero_uid(_hero_uid)


    DialogueCustomUtils._settle_appointed_team_loot(_hero_json, _player_node)


    json.erase("_pending_loot_enemy_team")


    var _has_hero_in_team: bool = false
    for _member in json.team:
        if _member is Dictionary and _member.get("uid", "") == _hero_uid:
            _has_hero_in_team = true
            break
    if not _has_hero_in_team:
        json.team.append({"uid": _hero_uid, "htype": BSSoldierConstants.H_TYPE_ENUM.HERO})


    var _team_array: Array = json.team
    for _member in _team_array:
        if not(_member is Dictionary):
            continue
        _member.erase("is_leader")

        if SoldierUtils.is_hero_by_simple_json(_member):
            _member["hp"] = 1
            _member["is_wounded"] = true
        _player_node.json.team.append(_member)

    _player_node.refresh_team_info(true)


    if not _hero_json.is_empty():
        _hero_json.erase("is_appointed_leader")
        _hero_json.erase("appointed_team_code")

    var _assigned_list: Array = json.get("assigned_heroes",[])
    for _assigned_uid in _assigned_list:
        var _assigned_hj = SoldierUtils.get_json_by_hero_uid(_assigned_uid)
        if not _assigned_hj.is_empty():
            _assigned_hj.erase("assigned_to_team")
    json.erase("assigned_heroes")


    var _team_uid: String = json.uid
    json.erase("appointed_leader_uid")
    WSData.other_team_data.erase(_team_uid)
    WSData.team_node_info.erase(_team_uid)
    if is_instance_valid(self):
        queue_free()


    var _msg: String = ""
    if _is_recall:
        _msg = SoldierUtils.get_nickname(_hero_json) + " 已归队"
    else:
        _msg = SoldierUtils.get_nickname(_hero_json) + " 战败，重伤归队！"
    GlobalMessageInterface.add_message(
        MessageConstants.MESSAGE_ENUM.VILLAIN_BOSS_APPEAR,
        [_msg]
    )


func clear_battle_data():
    json.current_battle_id = ""
    json.battle_team_type_enum = ""

func update_status_icon(_status_icon_type_enum: int)-> void:




    status_icon_node.update_icon(_status_icon_type_enum)

func update_status_debug_info(_text):
    if GameConfig.DEBUG_CONFIG_IS_AI_DEBUG and pre_debug_info_status != _text:
        pre_debug_info_status = _text
        if _text != null:
            CommonUtils.set_text(debug_info_status_node, "[" + _text + "]")



func remove_death_soldier_json(_keep_hero: = false):
    json.team = TeamUtils.list_living_and_injured_soldier_json(json.team, _keep_hero)


func get_combat_power()-> int:
    return team_info.combat_power

func get_combat_power_hp_ratio()-> int:
    return team_info.combat_power_hp_ratio

func to_day():


    if not ignore_food_consume \
    and status_machine_node.get_action_status() != MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:

        _npc_food_consume(0.5)


    team_info.update_speed_day_night_mult(1.0)

    _custom_to_day()

func to_night():
    if not ignore_food_consume \
    and status_machine_node.get_action_status() != MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:

        _npc_food_consume(0.5)


    team_info.update_speed_day_night_mult(MWConfig.SPEED_NIGHT_RATIO)

    _custom_to_night()





func handle_team_skill_operation()-> Dictionary:
    var save_prob = SkillUtils.get_skill_operation_save_prob(team_info.skill_operation)

    var _total = 0
    var _operation_nop = 0
    for _simple_json: Dictionary in json.team:
        if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.DEATH \

        and not CommonUtils.get_value(_simple_json, "is_operation_failed", false):
            _total += 1
            if save_prob > 0.001 and CommonUtils.prob_true(save_prob):
                _operation_nop += 1
                _simple_json.living_status = BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY
            else:

                _simple_json.is_operation_failed = true

    return {
        "total": _total,
        "operation_nop": _operation_nop
    }

func get_morale()-> int:


    return team_info.current_morale

func refresh_team_info(_need_new = true):
    if _need_new:
        team_info = TeamInfo.new(json, is_player)
        _update_team_name(team_info.team_name)
    else:
        team_info.refresh()


    _update_info_count()

    _update_debug_info()















func update_view_level_and_count_info(_level: int)-> void:
    _handle_danger_tag_style(_level)
    view_level = _level

    var _active_nop: = team_info.count
    var _total: = team_info.total

    if view_level <= 1:
        _update_count_origin(CommonUtils.get_vague_num_str(_active_nop))
    else:
        _update_count(_active_nop, _total)


func get_count():
    return team_info.count


func get_dialogue_template_old(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return TempDialogue.COMMON_BATTLE_0001


    if SoldierUtils.is_hero2(get_leader_json()):
        var _hero_uid = get_leader_uid()
        var _dialogue_template_json: Dictionary = DialogueUtils.get_hero_dialogue_template_json(_hero_uid)
        if not _dialogue_template_json.is_empty():
            return _dialogue_template_json

    match get_team_role():
        MWTeamConstants.TEAM_ROLE_ENUM.ROBBER:

            var dialogue_file_name: = "CommonRobberDialogue"
            if[
                MWTeamConstants.TEAM_SMALL_TYPE_ENUM.EVIL_EAGLE_MERCENARY,
                MWTeamConstants.TEAM_SMALL_TYPE_ENUM.SCORCHING_SOUL_SECT,
                MWTeamConstants.TEAM_SMALL_TYPE_ENUM.CALANT_EXILES,
            ].has(get_team_small_type()):
                dialogue_file_name = "Robber_" + get_team_small_type() + "_Dialogue"

            var _dialogue_node: BaseDialogue = CommonUtils.load_gd(
                DialogueUtils.get_dialogue_path(dialogue_file_name)
            )
            _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
            _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
            return _dialogue_node.get_current_dialogue_template()
        MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY:
            return MerchantConvoyDialogue.MERCHANT_CONVOY_DIALOGUE_0001
        MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER:
            return TempDialogue.VILLAGER_DIALOGUE_0001

    return {}

func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    return {}



func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    return {}


func get_dialogue_info()-> Dictionary:
    var _origin_location_code: String = CommonUtils.get_value(json, "origin_location_code", "")
    var _target_location_code: String = CommonUtils.get_value(json, "target_location_code", "")

    var _origin_location_name: String = WSLocationData.get_location_name(_origin_location_code)
    var _target_location_name: String = WSLocationData.get_location_name(_target_location_code)



    return {
        "leader_uid": get_leader_uid(),

        "leader_name": _custom_get_dialogue_leader_name(),
        "leader_gender": CommonUtils.get_value(get_leader_json(), "gender", BSSoldierConstants.GENDER_ENUM.MALE),
        "origin_location_name": _origin_location_name,
        "target_location_name": _target_location_name,
        "exchange_treasure": CommonUtils.get_value(json, "exchange_treasure",[]),
        "uid": json.uid,
        "money": json.money,
        "nop": team_info.count,
        "combat_power": team_info.combat_power,

        "origin_location_code": _origin_location_code,

        "battle_id": get_current_battle_id(),

        "is_chase_player": CommonUtils.is_not_null(move_target_node) and move_target_node == TeamUtils.get_player_team_node()
    }

func update_exchange_treasure(_exchange_treasure: Array):
    json.exchange_treasure = _exchange_treasure

func plus_money(_plus_value: int)-> void:
    json.money += _plus_value
    if json.money < 0:
        json.money = 0

func plus_food_stock_value(_plus_value: int)-> void:
    json.food_stock_value += _plus_value

func plus_additional_location_resource(_plus_json: Dictionary)-> void:
    if not json.has("additional_location_resource"):
        json["additional_location_resource"] = {}

    TeamUtils.plus_trophy_resource(
        json.additional_location_resource,
        _plus_json
    )


func update_morale(_plus_morale: float)-> void:
    if _plus_morale != 0.0:
        json.morale += _plus_morale


















func check_is_need_replenish_food():
    var surplus_days = team_info.get_food_surplus_days()
    if surplus_days <= NpcAIConfig.NPC_FOOD_SUPPLY_THRESHOLD_DAYS:
        return true
    else:
        return false


func check_is_need_replenish_soldier():
    var _expect_num: int = TeamUtils.get_expect_soldier_num(json)
    var replenish_soldier_prob: float = TeamUtils.get_npc_replenish_soldier_prob(team_info.total, _expect_num)
    return CommonUtils.prob_true(replenish_soldier_prob)




func get_next_patrol_position(_should_reset_to_center_out_of_range: bool = false)-> Vector2:
    var _behavior_data: Dictionary = json.behavior_data

    var _patrol_origin: Vector2 = _behavior_data.get("patrol_origin_position", Vector2.ZERO)


    var _city_positions: Array = _behavior_data.get("patrol_city_positions",[])
    if not _city_positions.is_empty():
        _patrol_origin = _city_positions.pick_random()


    if _patrol_origin.length() < 100:
        _patrol_origin = global_position
        _behavior_data.patrol_origin_position = _patrol_origin

    return TeamUtils.generate_patrol_positon(
        global_position,
        _patrol_origin,
        _behavior_data.get("patrol_radius", 0),
        _behavior_data.get("move_distance_interval",[30, 80]),
        _should_reset_to_center_out_of_range
    )


func is_out_of_patrol_range()-> bool:
    var _behavior_data: Dictionary = json.behavior_data

    var _patrol_origin: Vector2 = _behavior_data.get("patrol_origin_position", Vector2.ZERO)


    var _city_positions: Array = _behavior_data.get("patrol_city_positions",[])
    if not _city_positions.is_empty():
        var _radius_sq: float = pow(_behavior_data.get("patrol_radius", 0), 2)
        for _city_pos in _city_positions:
            if global_position.distance_squared_to(_city_pos) <= _radius_sq:
                return false
        return true


    if _patrol_origin.length() < 100:
        return false
    return global_position.distance_squared_to(_patrol_origin) > pow(_behavior_data.get("patrol_radius", 0), 2)

func view_mode_unchoose():
    view_focus_effect_node.hide()
    view_select_effect_node.hide()

func get_flee_target_position()-> Vector2:
    var _danger_node_list: = get_danger_node_list(false)
    if ArrayUtils.is_empty(_danger_node_list):
        return Vector2.ZERO

    return TeamUtils.get_flee_target_position(self, _danger_node_list)

func custom_on_check_area_body_entered(_body):
    pass

func custom_on_check_area_body_exited(_body):
    pass


func terrain_enter(_terrain_type: int)-> void:
    _terrain_load(_terrain_type)


func terrain_exit(_terrain_type: int)-> void:
    _terrain_load(MWorldConstants.DEFAULT_TERRAIN_TYPE)

func update_save_json():
    json.position = global_position
    json.current_target_location_code = current_target_location_code
    if CommonUtils.is_not_null(ai_node):
        json.ai_data = ai_node.get_save_data()
    json.status_machine_data = status_machine_node.get_save_data()
    json.is_in_location = is_in_location
    json.in_location_code = in_location_code
    json.belong_robber_faction = belong_robber_faction

func get_enter_exit_location_wait_frame_count()-> int:
    return 0

func get_current_battle_id():
    if json.current_battle_id == null:
        return ""

    return json.current_battle_id

func get_battle_team_type_enum():
    if json.battle_team_type_enum == null:
        return ""

    return json.battle_team_type_enum


func not_attack_player():
    will_attack_player_counter = 60 * 8
    will_attack_player = false












func heal_active_soldier_and_all_hero()-> void:
    for _simple_json: Dictionary in json.team:
        if SoldierUtils.is_living_by_json(_simple_json) \
        or SoldierUtils.is_hero_by_simple_json(_simple_json):
            SoldierUtils.heal_soldier(_simple_json)

func change_status_with_step_task(_status: int)-> void:
    change_status(_status, Callable(self, "ai_task_finish_step"))

func ai_task_finish_step()-> void:
    json.ai_task.pop_front()

func change_status_to_flee()-> void:
    move_type = MWTeamConstants.MOVE_TYPE_ENUM.FLEE

    change_status_to_move()

func change_status_to_pursue()-> void:
    move_type = MWTeamConstants.MOVE_TYPE_ENUM.PURSUE

    change_status_to_move()

func change_status_to_delete()-> void:
    change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)



func maybe_handle_mw_team_node_collision()-> void:

    if not is_player:
        _check_appointed_team_nearby()

    if CommonUtils.is_null(move_target_node) or not move_target_node.is_open_detact:
        change_status_to_thinking()
        return

    var _meet_mw_team_node: MWTeam = move_target_node

    if is_player:
        handle_mw_team_node_collision(_meet_mw_team_node)
        return

    if _meet_mw_team_node.is_player:

        if not will_attack_player:

            var _my_behavior: Dictionary = json.get("behavior_data",{})
            if _my_behavior.get("appointed_state", "") == "FOLLOWING":
                return

            if _my_behavior.get("following_to_garrison", false):
                return
            change_status_to_thinking()
            return

        _meet_mw_team_node.handle_mw_team_node_collision(self)
        return

    if _meet_mw_team_node.move_target_node == self \
    and self.get_instance_id() > _meet_mw_team_node.get_instance_id():

        return

    handle_mw_team_node_collision(_meet_mw_team_node)


func handle_mw_team_node_collision(_meet_mw_team_node: MWTeam)-> void:


    if not self.is_player and not _meet_mw_team_node.is_player:


        if get_leader_uid() == "mod_hero_0002" or _meet_mw_team_node.get_leader_uid() == "mod_hero_0002":
            return


        if get_leader_uid() == "minor_hero_0012" or _meet_mw_team_node.get_leader_uid() == "minor_hero_0012":
            return


        if get_leader_uid() == "mod_slave_duel_host" or _meet_mw_team_node.get_leader_uid() == "mod_slave_duel_host":
            return


        if _is_village_garrison() or _meet_mw_team_node._is_village_garrison():
            if not self.is_player:
                return


        var _rel_value: int = TeamUtils.get_team_rel_value(self, _meet_mw_team_node)
        if _rel_value >= 0:
            return

        TeamUtils.join_battle(self, _meet_mw_team_node)
        return









func refresh_injured_simple_json()-> void:
    npc_injured_simple_json_list = []
    for _simple_json: Dictionary in json.team:
        if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
            npc_injured_simple_json_list.append(_simple_json)


    if npc_injured_simple_json_list.size() != team_info.hurt_nop:
        print_debug("error: npc_injured_simple_json_list.size() != team_info.hurt_nop")



func custom_get_replenish_prop()-> float:
    return 0.0

func save_decision_ai_data(_ai_type_enum: String)-> void:
    json.decision_ai = _ai_type_enum

func get_decision_ai_data()-> String:
    if json.has("decision_ai"):
        return json.decision_ai
    else:
        return ""

func get_replenish_soldier_speed()-> int:
    return 3

func get_plan_replenish_soldier_nop()-> int:
    return max(_get_nop_max() - team_info.total, 0)

func custom_npc_replenish_soldier(_replenish_nop: int)-> void:
    pass

func add_soldier(_simple_json_list: Array)-> void:
    TeamUtils.repair_simple_json(_simple_json_list, false)
    json.team.append_array(_simple_json_list)


func get_owned_location_code_list()-> Array:
    return SoldierUtils.get_owned_location_code_list(get_leader_uid())

func get_leader_uid()-> String:

    return team_info.leader_json.uid

func get_leader_json()-> Dictionary:
    return team_info.leader_json


func get_nop()-> int:


    return json.team.size()

func get_nop_limit()-> int:
    return team_info.nop_limit

func get_team_name()-> String:
    return team_info.team_name


func refresh_banner()-> void:

    if json.has("npc_team_code") and json.npc_team_code == NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT:
        lord_banner_node.hide()
        return
    var leader_json: Dictionary = get_leader_json()
    if leader_json.has("banner_config"):
        lord_banner_node.show()
        lord_banner_node.init_by_banner_config(leader_json.banner_config)

func get_team_small_type()-> String:
    return TeamUtils.get_team_small_type(json)

func get_team_role()-> MWTeamConstants.TEAM_ROLE_ENUM:
    return json.team_role

func update_belong_country(_country_code: String)-> void:
    belong_country = _country_code
    json.belong_country = _country_code

func get_belong_country()-> String:
    return belong_country


func get_belong_robber_faction()-> bool:
    return belong_robber_faction

func update_belong_robber_faction(_belong: bool)-> void:
    belong_robber_faction = _belong
    json.belong_robber_faction = _belong
    if _belong:
        _update_info_color(MWTeamConstants.ROBBER_FACTION_COLOR)
    else:
        _custom_handle_team_info_color()

func get_npc_team_code()-> String:
    return json.get("npc_team_code", "")


func custom_train_start()-> void:
    pass


func custom_train_end()-> void:
    pass

func _heal_all_hero()-> void:
    for _simple_json: Dictionary in json.team:
        if SoldierUtils.is_hero_by_simple_json(_simple_json):
            SoldierUtils.heal_soldier(_simple_json)

func _get_day_night_terrain_rel_speed_mult()-> float:
    return team_info.get_day_night_terrain_rel_speed_mult()

func _custom_handle_delete()-> void:
    pass

func _get_caution_level()-> int:
    return get_leader_json().caution_level

func _get_integrity_level()-> int:
    return get_leader_json().integrity_level

func _get_warlike_level()-> int:
    return get_leader_json().warlike_level

func _get_nop_max()-> int:
    return SoldierUtils.get_nop_by_army_size_level(get_leader_json().army_size_level)

func _init_status()-> void:
    is_init_status = true

    _custom_init_status()

    is_init_status = false


func _handle_npc_recover_injured(_recover_weight: float = 1.0)-> void:
    if[
        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK,
        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE
    ].has(status_machine_node.get_action_status()):
        return

    if npc_injured_simple_json_list.size() == 0:
        return

    if status_machine_node.get_action_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY:
        _recover_weight *= MWConfig.TEAM_RECOVER_SPEED_RATIO_LOCATION_STAY


    var _operation_ratio: float = _recover_weight * 2 /(npc_injured_simple_json_list.size() + 10)

    var _healed_count: = 0
    for _index: int in range(npc_injured_simple_json_list.size() - 1, -1, -1):
        var _simple_json = npc_injured_simple_json_list[_index]
        if CommonUtils.prob_true(_operation_ratio):
            SoldierUtils.heal_soldier(_simple_json)
            npc_injured_simple_json_list.remove_at(_index)
            _healed_count += 1

    if _healed_count > 0:
        team_info.count += _healed_count
        team_info.hurt_nop -= _healed_count
        _update_info_count()


func _check_will_spare_enemy_caravan(_mw_team_node: MWTeam)-> bool:

    if get_team_role() != MWTeamConstants.TEAM_ROLE_ENUM.LORD:
        return false

    if not[MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER, MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY, MWTeamConstants.TEAM_ROLE_ENUM.ROBBER] \

    .has(_mw_team_node.get_team_role()):
        return false


    match _get_integrity_level():
        HeroConstants.INTEGRITY_LEVEL_ENUM.BRUTAL:

            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER \
            and CommonUtils.prob_true(TeamConfig.MW_TEAM_SEARCH_ENEMY_INTERVAL_COUNTER * 0.002):
                return false
            elif _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY:
                return false
            else:
                return true

        HeroConstants.INTEGRITY_LEVEL_ENUM.PETTY:

            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.ROBBER:
                return true
            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER:
                return true

        HeroConstants.INTEGRITY_LEVEL_ENUM.NEUTRAL:

            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.ROBBER:
                if CommonUtils.prob_true(TeamConfig.MW_TEAM_SEARCH_ENEMY_INTERVAL_COUNTER * 0.0025):
                    return false
                else:
                    return true
            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.MERCHANT_CONVOY \
            and CommonUtils.prob_true(TeamConfig.MW_TEAM_SEARCH_ENEMY_INTERVAL_COUNTER * 0.002):
                return false
            else:
                return true

        HeroConstants.INTEGRITY_LEVEL_ENUM.RIGHTEOUS:

            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.ROBBER:
                return false
            return true

        HeroConstants.INTEGRITY_LEVEL_ENUM.NOBLE:

            if _mw_team_node.get_team_role() == MWTeamConstants.TEAM_ROLE_ENUM.ROBBER:
                return false
            return true

    return false

func _open_or_close_detect(_is_open_detect: bool, is_force: = false)-> void:
    if is_open_detact == _is_open_detect and not is_force:
        return

    is_open_detact = _is_open_detect

    if _is_open_detect:
        check_area_node.get_node("CollisionShape2D").disabled = false
        self.get_node("CollisionShape2D").disabled = false
    else:
        check_area_node.get_node("CollisionShape2D").disabled = true
        self.get_node("CollisionShape2D").disabled = true

func _custom_init_status()-> void:
    if json.has("status_machine_data"):
        if[
            MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.MOVE,
            MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE
        ].has(json.status_machine_data.status):

            load_init_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.THINKING)
        else:

            load_init_status(json.status_machine_data.status)
    else:

        load_init_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.THINKING)

func _custom_handle_team_info_color()-> void:
    pass


func _custom_get_dialogue_leader_name()-> String:
    return team_info.leader_name

func _custom_handle_ally_relation_gain_after_battle(_value_factor: float)-> void:
    pass

func _show_or_hide_body(
    _is_show: bool, is_force: = false,
    _player_animation: = true
)-> void:
    if is_show == _is_show and not is_force:
        return

    is_show = _is_show

    if _is_show:
        check_choose_area_node.show()
        if _player_animation:
            show_animation()
        else:
            self.show()
    else:
        check_choose_area_node.hide()
        if _player_animation:
            disappear_animation()
        else:
            self.hide()

func _custom_move()-> void:
    pass

func _handle_danger_tag_style(_level: int)-> void:

    if view_level == _level:
        pass
    else:
        var _tween = get_tree().create_tween()
        _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        if _level >= 2:
            _tween.tween_property(danger_tag_node, "modulate:a", 1.0, 0.3)
        else:
            _tween.tween_property(danger_tag_node, "modulate:a", 0.0, 0.3)


    if _level >= 2:
        var _danger_config = TeamUtils.get_danger_config_by_node(self, WSData.get_player_team_node())
        var _tween = get_tree().create_tween()
        _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _tween.tween_property(danger_tag_node, "self_modulate", _danger_config.color, 0.3)

func _terrain_load(_terrain_type: int)-> void:
    _save_terrain_type(_terrain_type)
    if not MWConfig.TERRAIN_TYPE_CONFIG.has(_terrain_type):
        return

    var _config = MWConfig.TERRAIN_TYPE_CONFIG.get(_terrain_type)
    if _config.has("speed_mult"):
        team_info.update_speed_terrain_mult(_config.speed_mult)
    if _config.has("investigation_range_mult"):
        _update_investigation_area_length_mult(_config.investigation_range_mult)

func _save_terrain_type(_terrain_type: int):

    json.pre_terrain_type = CommonUtils.get_value(json, "terrain_type", _terrain_type)
    json.terrain_type = _terrain_type
    _handle_terrain_type_change_custom(_terrain_type)


func _handle_terrain_type_change_custom(_terrain_type: int)-> void:
    pass


func _update_investigation_area_length_mult(_mult: float)-> void:
    pass


func _custom_physics_process(delta):
    pass








































func _npc_food_consume(_mult: float):
    if is_player:
        return

    var _food_stock_value = team_info.npc_food_consume(_mult)
    if _food_stock_value <= 0 and not is_player:

        delete(false)

func _update_debug_info():
    if not GameConfig.SHOW_TEAM_DEBUF_INFO:
        return

    var _text = "食物存量: {0}\n士气: {1}\n人数: {2}\n战斗力: {3}\n移速: {4}\n德里: {5}"
    _text = StringUtils.replace(
        _text,
        [
            team_info.food_stock_value, int(team_info.current_morale),
            team_info.count, team_info.combat_power, team_info.get_speed(), team_info.money
        ]
    )
    CommonUtils.set_text(debug_info_node, _text)


func _handle_morale_recover(_time: float):

    if status_machine_node.get_action_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return

    var _plus_morale: float = TeamUtils.get_plus_morale_recover(team_info.current_morale, team_info.base_morale, _time)
    if _plus_morale != 0.0:
        json.morale += _plus_morale


    if is_player and json.morale <= 0:

        var flee_soldier_record: = {}
        for _soldier_simple_json: Dictionary in json.team:
            if SoldierUtils.is_hero2(_soldier_simple_json):
                continue

            var soldier_json: Dictionary = SoldierUtils.get_json_by_uid(_soldier_simple_json.uid)

            if soldier_json.star >= BattleSceneConfig.FLEE_MAX_SOLDIER_STAR:
                continue

            var _prob: float = _time * 0.008 / soldier_json.star
            if CommonUtils.prob_true(_prob):
                if not flee_soldier_record.has(soldier_json.name):
                    flee_soldier_record[soldier_json.name] = 0

                flee_soldier_record[soldier_json.name] += 1

                json.team.erase(_soldier_simple_json)


        if flee_soldier_record.size() > 0:
            for _key in flee_soldier_record.keys():
                GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SOLDIER_FLEE_MESSAGE,[flee_soldier_record.get(_key), _key])

func _custom_to_day():
    pass

func _custom_to_night():
    pass

func _update_info_color(_color: Color):
    CommonUtils.update_color(name_node, _color)
    CommonUtils.update_color(count_node, _color)


func _custom_init():
    pass




























func _update_info_count():
    if is_player:
        _update_count(team_info.count, team_info.total)
    else:
        update_view_level_and_count_info(view_level)


func _handle_medical_and_operation(_time_weight: int):
    if team_info.hp_percent >= 100:
        return

    var _skill = team_info.skill_medical



    var _hp_percent_pre: float = _time_weight *(0.3 + _skill * SkillConfig.SKILL_MEDICAL_EFFECT_WEIGHT_CONFIG)

    if status_machine_node.get_action_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.MOVE:
        pass
    elif status_machine_node.get_action_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE:
        _hp_percent_pre *= MWConfig.TEAM_RECOVER_SPEED_RATIO_IDLE
    elif status_machine_node.get_action_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY:
        _hp_percent_pre *= MWConfig.TEAM_RECOVER_SPEED_RATIO_LOCATION_STAY


    var _extra_nop = _skill
    var _extra_hp_percent = _skill * 0.1

    var _injured_simple_json_list: = []

    for _simple_json in json.team:

        if _simple_json.living_status == BSSoldierConstants.LIVING_STATUS_ENUM.SERIOUS_INJURY:
            _injured_simple_json_list.append(_simple_json)
            continue

        var _is_complete_recover = SoldierUtils.plus_hp_percent(_simple_json, _hp_percent_pre)
        if not _is_complete_recover and _extra_nop > 0:

            _extra_nop -= 1
            SoldierUtils.plus_hp_percent(_simple_json, _hp_percent_pre)

    var _skill_operation_ratio: float = SkillUtils.get_skill_operation_ratio(
        self.team_info.skill_operation, _time_weight, _injured_simple_json_list.size()
    )

    self._handle_operation(_injured_simple_json_list, _skill_operation_ratio)


func _handle_operation(_injured_simple_json_list: Array, _skill_operation_ratio: float)-> void:
    if _skill_operation_ratio < 0.001:
        return

    if ArrayUtils.is_empty(_injured_simple_json_list):
        return

    for _injured_simple_json in _injured_simple_json_list:
        if CommonUtils.prob_true(_skill_operation_ratio):
            _injured_simple_json.living_status = BSSoldierConstants.LIVING_STATUS_ENUM.ACTIVE

func _update_team_name(_name):
    CommonUtils.update_texture3(
        role_type_icon_node,

        TeamUtils.get_team_role_type_icon(get_team_role())
    )
    CommonUtils.set_text(name_node, _name)

func _update_count(_active_nop: int, _total: int)-> void:
    if _active_nop == _total:
        _update_count_origin(str(_active_nop))
    else:
        _update_count_origin(str(_active_nop) + "/" + str(_total))

func _update_count_origin(_str: String)-> void:
    CommonUtils.set_text(count_node, _str)

func _custom_timer_timeout()-> void:
    pass

func _player_color_mark()-> void:
    _update_info_color(CommonConstants.COLOR_ENUM.BLUE_LIGHT)

func _country_color_mark()-> void:
    var _color: Color = CountryUtils.get_country_color(belong_country)
    _update_info_color(_color)





























func _on_check_area_body_entered(body):
    if body == self:
        return

    warning_team_list.append(body)
    custom_on_check_area_body_entered(body)


func _on_check_area_body_exited(body):
    if body == self:
        return

    warning_team_list.erase(body)
    custom_on_check_area_body_exited(body)


func _on_check_choose_area_cancel_focus():
    focus_effect_node.hide()
    view_focus_effect_node.hide()


func _on_check_choose_area_click():
    if not GlobalNode.is_world_input_active():
        return







    emit_signal("choose_team_sign", self, true)

    if GlobalNode.is_show_mode():
        view_select_effect_node.show()
    else:
        select_effect_node.show()

func _on_check_choose_area_right_click_sign():
    if not GlobalNode.is_world_input_active():
        return

    emit_signal("choose_team_sign", self, false)

func _on_check_choose_area_focus():





    if GlobalNode.is_show_mode():
        view_focus_effect_node.show()
    else:
        focus_effect_node.show()













func _on_timer_timeout():
    _custom_timer_timeout()


func _on_navigation_agent_2d_link_reached(details: Dictionary)-> void:






    if WSLinkData.check_is_location_gate(details.rid):
        gate_exit_point = details.link_exit_position
        gate_location_code = WSLinkData.get_location_code(details.rid)
        change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ACROSS_GATE)


func _on_check_area_area_entered(area: Area2D)-> void:
    pass

func _on_check_area_area_exited(area: Area2D)-> void:
    pass




func _check_appointed_team_nearby()-> void:
    for _node in warning_team_list:
        if _node is MWTeam and _node.json.get("appointed_leader_uid", "") != "":
            if global_position.distance_squared_to(_node.global_position) < 30 * 30:
                var _rel_value: int = TeamUtils.get_team_rel_value(self, _node)
                if _rel_value < 0:
                    handle_mw_team_node_collision(_node)
                    return