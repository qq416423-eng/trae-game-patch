class_name MWTeamLord extends MWTeam

@onready var lord_decision_ai_node: Node =$LordDecisionAI




var _mod_defender_battle_id: String = ""
var _mod_defender_battle_team_type: String = ""

var _mod_defender_was_defeated: bool = false




func get_leader_uid()-> String:
    if json.get("leader_uid", "") == "village_guard":
        return "village_guard"
    if json.get("leader_uid", "") == "village_defender":
        return "village_defender"
    return super.get_leader_uid()



func _is_village_garrison()-> bool:
    var _uid: String = json.get("leader_uid", "")
    return _uid == "village_guard" or _uid == "village_defender"





const GARRISON_SUPPORT_LORD_SEARCH_RADIUS: = 1200.0

const GARRISON_SUPPORT_SCAN_INTERVAL: = 90

const GARRISON_SUPPORT_JOIN_DIRECT_RADIUS: = 40.0



func join_battle(_battle_id: String, _battle_team_type_enum: String = ""):
    super.join_battle(_battle_id, _battle_team_type_enum)


    if json.has("behavior_data"):
        json.behavior_data.erase("is_moving_to_support_garrison")

    if _is_village_garrison():
        _call_nearby_lords_to_support(_battle_id)


func _call_nearby_lords_to_support(_battle_id: String)-> void:
    var _country: String = get_belong_country()
    if _country == WSCountryData.COUNTRY_NAME_ENUM.NONE:
        return
    var _search_radius_sq: float = GARRISON_SUPPORT_LORD_SEARCH_RADIUS * GARRISON_SUPPORT_LORD_SEARCH_RADIUS
    var _join_direct_sq: float = GARRISON_SUPPORT_JOIN_DIRECT_RADIUS * GARRISON_SUPPORT_JOIN_DIRECT_RADIUS

    for _node in WSData.team_node_info.values():
        if not is_instance_valid(_node):
            continue
        if _node == self:
            continue
        if not _node is MWTeamLord:
            continue
        if _node._is_village_garrison():
            continue
        if _node.get_belong_country() != _country:
            continue
        if _node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
            continue

        if _node.json.get("behavior_data",{}).get("is_moving_to_support_garrison", false):
            continue
        var _dist_sq: float = CommonUtils.get_distance_square(self, _node)
        if _dist_sq > _search_radius_sq:
            continue

        if _dist_sq <= _join_direct_sq:

            _node.join_battle(_battle_id)
        else:

            if not _node.json.has("behavior_data"):
                _node.json.behavior_data = {}
            _node.json.behavior_data.is_moving_to_support_garrison = true
            _node.move_to_team(self, false, true)




func _custom_init()-> void:
    if _is_village_garrison():
        var _country_code: String = json.get("belong_country", "")
        var _banner_config: Dictionary = _get_kingdom_banner_config(_country_code)
        if not _banner_config.is_empty():
            if not team_info.leader_json.has("banner_config"):
                team_info.leader_json.banner_config = _banner_config
    super._custom_init()


func _get_kingdom_banner_config(_country_code: String)-> Dictionary:
    match _country_code:
        WSCountryData.COUNTRY_NAME_ENUM.LUCIANA:
            return {"shape_code": "shape_0021", "shape_color": Color("1d3248"), "emblem_code": "emblem_0054", "emblem_color": Color("cf9f3e")}
        WSCountryData.COUNTRY_NAME_ENUM.EDRAS:
            return {"shape_code": "shape_0022", "shape_color": Color("4c2e5d"), "emblem_code": "emblem_0056", "emblem_color": Color("bdbdbd")}
        WSCountryData.COUNTRY_NAME_ENUM.DORDAR:
            return {"shape_code": "shape_0017", "shape_color": Color("5189ab"), "emblem_code": "emblem_0058", "emblem_color": Color("e1a815")}
        WSCountryData.COUNTRY_NAME_ENUM.HASKAL:
            return {"shape_code": "shape_0013", "shape_color": Color("b69037"), "emblem_code": "emblem_0060", "emblem_color": Color("8d3332")}
    return {}


func status_thinking_action()-> void:

    if _is_village_garrison():
        return
    lord_decision_ai_node.action()





const SUPPORT_DURATION_MSEC: = 32000
const SUPPORT_HALF_RELATION_EXTRA_MSEC: = 15000
const SUPPORT_FOLLOW_MAX_DISTANCE: = 140
const SUPPORT_BATTLE_JOIN_DISTANCE: = 88
const SUPPORT_LOST_TRACK_WAIT_MSEC: = 8000


func is_supporting_player()-> bool:
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    return _behavior_data.get("is_supporting_player", false)


func _is_in_half_relation_period()-> bool:
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    if not _behavior_data.get("is_supporting_player", false):
        var _half_end_time: int = _behavior_data.get("support_half_relation_end_time_msec", 0)
        if _half_end_time > 0:
            return Time.get_ticks_msec() < _half_end_time
    return false


func start_support_player()-> void:
    if not json.has("behavior_data"):
        json.behavior_data = {}

    var _player_node: MWTeam = TeamUtils.get_player_team_node()
    if _player_node == null:
        return

    var _current_time_msec: int = Time.get_ticks_msec()


    var _original_patrol_origin: Vector2 = json.behavior_data.get("patrol_origin_position", self.global_position)


    json.behavior_data.is_supporting_player = true
    json.behavior_data.support_start_time_msec = _current_time_msec
    json.behavior_data.support_original_patrol_origin = _original_patrol_origin
    json.behavior_data.support_half_relation_end_time_msec \
    = _current_time_msec + SUPPORT_DURATION_MSEC + SUPPORT_HALF_RELATION_EXTRA_MSEC


    json.behavior_data.ai_data = HeroConstants.LORD_DECISION_AI_TYPE_ENUM.FOLLOW_PLAYER


    move_to_team(_player_node, false, false)


func _end_support_player()-> void:
    if not json.has("behavior_data"):
        return

    var _current_time_msec: int = Time.get_ticks_msec()


    json.behavior_data.is_supporting_player = false
    json.behavior_data.support_half_relation_end_time_msec \
    = _current_time_msec + SUPPORT_HALF_RELATION_EXTRA_MSEC


    json.behavior_data.ai_data = HeroConstants.LORD_DECISION_AI_TYPE_ENUM.NONE


    if json.behavior_data.has("support_original_patrol_origin"):
        json.behavior_data.patrol_origin_position = json.behavior_data.support_original_patrol_origin


    reset_move_target_node()


    _find_enemy_or_return_to_patrol()


func _find_enemy_or_return_to_patrol()-> void:
    var _enemy_node: MWTeam = _find_nearest_hostile_team()

    if _enemy_node != null:

        move_to_team(_enemy_node, true, true)
    else:

        var _behavior_data: Dictionary = json.behavior_data
        var _patrol_origin: Vector2 = _behavior_data.get("patrol_origin_position", self.global_position)

        var _random_offset: Vector2 = Vector2(
            CommonUtils.random_num2(-100, 100),
            CommonUtils.random_num2(-100, 100)
        )

        move_to_target(_patrol_origin + _random_offset, true, true)


func _find_nearest_hostile_team()-> MWTeam:
    var _nearest_node: MWTeam = null
    var _nearest_distance_sq: float = INF
    var _search_radius: float = 500.0

    var _all_team_nodes: Array = WSData.team_node_info.values()
    for _node in _all_team_nodes:
        if _node == self:
            continue
        if _node == TeamUtils.get_player_team_node():
            continue

        var _dist_sq: float = CommonUtils.get_distance_square(self, _node)
        if _dist_sq > _search_radius * _search_radius:
            continue

        if _dist_sq < _nearest_distance_sq:
            var _rel_enum = TeamUtils.get_team_rel_type_enum(self, _node)
            if _rel_enum == MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE:
                _nearest_distance_sq = _dist_sq
                _nearest_node = _node

    return _nearest_node



const SUPPORT_FOLLOW_OFFSET_SQUARE: = 20 * 20



func maybe_handle_mw_team_node_collision()-> void:
    if is_supporting_player():
        return
    super.maybe_handle_mw_team_node_collision()



func _custom_physics_process(delta)-> void:

    if _is_village_garrison():
        if counter % GARRISON_SUPPORT_SCAN_INTERVAL == 0:
            var _battle_id: String = get_current_battle_id()
            if not _battle_id.is_empty() and get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
                _call_nearby_lords_to_support(_battle_id)
        return


    if json.get("behavior_data",{}).get("is_moving_to_support_garrison", false):
        var _garrison_still_fighting: bool = false
        for _node in WSData.team_node_info.values():
            if is_instance_valid(_node) and _node is MWTeamLord and _node._is_village_garrison() \
            and _node.get_belong_country() == get_belong_country() \
            and _node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
                _garrison_still_fighting = true
                break
        if not _garrison_still_fighting:
            json.behavior_data.erase("is_moving_to_support_garrison")
            reset_move_target_node()
            change_status_to_idle()

    if not is_supporting_player():
        return

    var _current_time_msec: int = Time.get_ticks_msec()
    var _start_time_msec: int = json.behavior_data.get("support_start_time_msec", 0)


    if _current_time_msec - _start_time_msec >= SUPPORT_DURATION_MSEC:
        _end_support_player()
        return




    var _player_node: MWTeam = TeamUtils.get_player_team_node()
    if _player_node != null:
        var _distance_sq: float = CommonUtils.get_distance_square(self, _player_node)
        var _lost_track_start: int = json.behavior_data.get("support_lost_track_start_msec", 0)

        if _distance_sq <= SUPPORT_FOLLOW_MAX_DISTANCE * SUPPORT_FOLLOW_MAX_DISTANCE:

            if _lost_track_start != 0:

                json.behavior_data.support_lost_track_start_msec = 0
                move_to_team(_player_node, false, false)
            if move_type == MWTeamConstants.MOVE_TYPE_ENUM.DYNAMIC:
                set_move_target(_player_node.global_position)
            return


        if _lost_track_start == 0:

            json.behavior_data.support_lost_track_start_msec = _current_time_msec
            move_to_target(self.global_position, false, false)
            return


        if _current_time_msec - _lost_track_start >= SUPPORT_LOST_TRACK_WAIT_MSEC:
            _end_support_player()
            return




func _custom_handle_ally_relation_gain_after_battle(_value_factor: float)-> void:
    var _current_time_msec: int = Time.get_ticks_msec()
    var _behavior_data: Dictionary = json.get("behavior_data",{})


    if _behavior_data.get("is_supporting_player", false):
        var _damage_percent: int = 100 - team_info.hp_percent
        if _damage_percent >= 95:
            SoldierUtils.plus_player_relation_value(get_leader_uid(), -4.0, true)
            return
        elif _damage_percent >= 80:
            SoldierUtils.plus_player_relation_value(get_leader_uid(), -2.0, true)
            return
        elif _damage_percent >= 66:
            SoldierUtils.plus_player_relation_value(get_leader_uid(), -1.0, true)
            return
        elif _damage_percent >= 55:

            return


    var _is_half_relation: bool = false

    if _behavior_data.get("is_supporting_player", false):

        _is_half_relation = true
    else:
        var _half_end_time: int = _behavior_data.get("support_half_relation_end_time_msec", 0)
        if _half_end_time > 0 and _current_time_msec < _half_end_time:

            _is_half_relation = true

    var _adjusted_value: float = _value_factor
    if _is_half_relation:
        _adjusted_value = _value_factor / 2.0

    else:

        var _multiplier: float = 2.0
        if _adjusted_value > 0.0:
            _multiplier = clampf(2.0 -(_adjusted_value / 10.0), 1.0, 2.0)
            _adjusted_value = _multiplier * _adjusted_value

    SoldierUtils.plus_player_relation_value(
        get_leader_uid(), _adjusted_value,
        true
    )

func handle_patrol_origin_position()-> void:


    if _is_village_garrison():
        return


    var _lord_config: Dictionary = LordConfig.LORD_CONFIG.get(json.get("leader_uid", ""))
    if _lord_config.has("custom_spawn_position"):
        json.behavior_data.patrol_origin_position = _lord_config.custom_spawn_position
        return

    var _lord_patrol_strategy_enum: MWTeamConstants.LORD_PATROL_STRATEGY_ENUM = \
    _get_lord_patrol_strategy()


    json.behavior_data.patrol_origin_position = \
    _generate_patrol_origin_position(_lord_patrol_strategy_enum)


    if json.behavior_data.patrol_origin_position.length() < 100:
        json.behavior_data.patrol_origin_position = self.global_position


func custom_get_replenish_prop()-> float:

    if _is_village_garrison():
        return 0.0

    var _npc_code: String = json.get("npc_team_code", "")
    if NpcTeamConfig.VILLAIN_BOSS_CONFIG.has(_npc_code):
        return 0.0

    var _lord_config: Dictionary = LordConfig.LORD_CONFIG.get(json.get("leader_uid", ""))
    if _lord_config.has("fixed_max_troop"):
        if team_info.count >= _lord_config.fixed_max_troop:
            return 0.0

    var _army_ratio: float = team_info.count * 1.0 / _get_nop_max()
    var _army_ratio_min_max: = []

    match _get_caution_level():
        HeroConstants.CAUTION_LEVEL_ENUM.CAUTIOUS:
            _army_ratio_min_max = [0.5, 0.6]
        HeroConstants.CAUTION_LEVEL_ENUM.NEUTRAL:
            _army_ratio_min_max = [0.4, 0.55]
        HeroConstants.CAUTION_LEVEL_ENUM.RECKLESS:
            _army_ratio_min_max = [0.3, 0.5]

    if _army_ratio < _army_ratio_min_max[0]:
        return 1.0

    return CommonUtils.get_section_value([0.3, 0.05], _army_ratio_min_max, _army_ratio)


func get_location_sub_status_by_thinking()-> Dictionary:
    match get_decision_ai_data():
        HeroConstants.LORD_DECISION_AI_TYPE_ENUM.REPLENISH_TROOPS:
            return {
                "status": MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_NPC_REPLENISH,
                "callable": Callable()
            }

    return {
        "status": MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_EXIT,
        "callable": Callable()
    }


func custom_npc_replenish_soldier(_replenish_nop: int)-> void:
    var _lord_config: Dictionary = LordConfig.LORD_CONFIG.get(json.leader_uid)

    if _lord_config.has("fixed_max_troop"):
        var _max_add: int = _lord_config.fixed_max_troop - team_info.count
        _replenish_nop = clampi(_replenish_nop, 0, _max_add)
        if _replenish_nop <= 0:
            return
    var _simple_json_list: Array = TeamUtils.generate_team_json_list_by_team_config(
        _lord_config.team_config, _replenish_nop, true, false
    )

    add_soldier(_simple_json_list)


    WSLocationData.plus_population_working_age_by_nop(
        in_location_code,
        - _simple_json_list.size(),

        LocationConfig.POPULATION_WORKING_AGE_LORD_CONSCRIPTION_DISCOUNT
    )

    refresh_nop_info()


func get_replenish_soldier_speed()-> int:
    return int(3 * 2.5)

func reach_location()-> void:

    if get_decision_ai_data() == HeroConstants.LORD_DECISION_AI_TYPE_ENUM.REPLENISH_TROOPS \
    and WSLocationData.get_location_type(current_target_location_code) == LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
        change_status_to_location_outside_replenish()
        return

    change_status_to_location_stay()

func exit_location_end()-> void:
    GlobalLocationData.handle_hero_team_exit_location(in_location_code, get_uid())

func enter_location()-> void:
    GlobalLocationData.handle_hero_team_enter_location(in_location_code, get_uid())



func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    var _dialogue_gd_path: String = _dialogue_gd_path()

    if _dialogue_gd_path.is_empty():
        return {}
    var _dialogue_node: BaseDialogue = CommonUtils.load_gd(_dialogue_gd_path)

    if _dialogue_node == null or not is_instance_valid(_dialogue_node):
        return {}
    return _dialogue_node.get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor)

func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return TempDialogue.COMMON_BATTLE_0001



    if _is_village_garrison():
        var _dialogue_node: BaseDialogue = CommonUtils.load_gd(DialogueUtils.get_dialogue_path("VillageGuardDialogue"))
        _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
        _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
        return _dialogue_node.get_current_dialogue_template()

    var _dialogue_gd: LordDialogueBase = DialogueUtils.get_dialogue_gd_by_hero_uid(get_leader_uid())


    if _dialogue_gd == null or not is_instance_valid(_dialogue_gd):
        print("[MOD] 警告: 领主 ", get_leader_uid(), " 无对话GD文件, 使用通用对话模板")
        return TempDialogue.COMMON_BATTLE_0001

    _dialogue_gd.set_a_team_dialogue_info(_a_team_dialogue_info)
    _dialogue_gd.set_b_team_dialogue_info(_b_team_dialogue_info)

    return _dialogue_gd.get_current_dialogue_template()


func handle_battle_end(_battle_result_enum: String, _ally_relation_gain_after_battle_factor: float = 0.0)-> void:
    var _is_guard: bool = json.get("leader_uid", "") == "village_guard"
    var _is_defender: bool = json.get("leader_uid", "") == "village_defender"
    var _location_code: String = ""
    var _country_code: String = ""
    if _is_guard and _battle_result_enum == BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
        _location_code = json.get("garrison_location_code", "")
        _country_code = json.get("belong_country", "")


    var _defender_location: String = ""
    if _is_defender and _battle_result_enum == BattleConstants.BATTLE_RESULT_ENUM.DEFEAT:
        _defender_location = json.get("garrison_location_code", "")

        _mod_defender_battle_id = json.get("current_battle_id", "")
        _mod_defender_battle_team_type = json.get("battle_team_type_enum", "")
        _mod_defender_was_defeated = true

    super.handle_battle_end(_battle_result_enum, _ally_relation_gain_after_battle_factor)

    if _is_guard and _location_code != "":


        var _other_alive: int = 0
        for _node in WSData.team_node_info.values():
            if not is_instance_valid(_node) or _node == self:
                continue
            if _node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE:
                continue
            if _node.json.get("leader_uid", "") == "village_guard" \
            and _node.json.get("garrison_location_code", "") == _location_code:
                _other_alive += 1
        if _other_alive == 0:
            DialogueCustomUtils.check_and_spawn_defender_for_village(_location_code, _country_code, get_uid())


    if _is_defender and _defender_location != "":
        DialogueCustomUtils.capture_village(
            _defender_location, _mod_defender_battle_id, _mod_defender_battle_team_type
        )
        _mod_defender_battle_id = ""
        _mod_defender_battle_team_type = ""




func delete(_need_plus_power_value: = true):
    var _is_guard: bool = json.get("leader_uid", "") == "village_guard"
    var _is_defender: bool = json.get("leader_uid", "") == "village_defender"
    var _location_code: String = ""
    var _country_code: String = ""
    var _defender_location: String = ""
    if _is_guard:
        _location_code = json.get("garrison_location_code", "")
        _country_code = json.get("belong_country", "")
    if _is_defender:
        _defender_location = json.get("garrison_location_code", "")

    super.delete(_need_plus_power_value)

    if _is_guard and _location_code != "":
        DialogueCustomUtils.check_and_spawn_defender_for_village(_location_code, _country_code)



    if _is_defender and _defender_location != "" and _mod_defender_was_defeated:
        DialogueCustomUtils.capture_village(
            _defender_location, _mod_defender_battle_id, _mod_defender_battle_team_type
        )
        _mod_defender_battle_id = ""
        _mod_defender_battle_team_type = ""
        _mod_defender_was_defeated = false


func _custom_handle_delete()-> void:


    if json.get("leader_uid", "") == "village_guard" \
    or json.get("leader_uid", "") == "village_defender":
        return

    var _npc_code: String = json.get("npc_team_code", "")
    if NpcTeamConfig.VILLAIN_BOSS_CONFIG.has(_npc_code):
        GlobalNpcTeamData.npc_team_die(_npc_code)
        return

    WSData.handle_lord_defeated(get_leader_uid(), self.global_position)


func _custom_timer_timeout()-> void:

    _handle_npc_recover_injured(timer_node.wait_time / 4.0)


func _get_lord_patrol_strategy()-> MWTeamConstants.LORD_PATROL_STRATEGY_ENUM:

    match _get_warlike_level():
        HeroConstants.WARLIKE_LEVEL_ENUM.AVOIDANT:
            return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.HOMELAND

        HeroConstants.WARLIKE_LEVEL_ENUM.CAUTIOUS:
            if CommonUtils.prob_true(0.5):
                return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_OWN
            if CommonUtils.prob_true(1.0):
                return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.HOMELAND

        HeroConstants.WARLIKE_LEVEL_ENUM.BALANCED:
            if CommonUtils.prob_true(0.5):
                return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_ENEMY
            if CommonUtils.prob_true(1.0):
                return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_OWN

        HeroConstants.WARLIKE_LEVEL_ENUM.AGGRESSIVE:
            if CommonUtils.prob_true(0.3):
                return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_OWN
            if CommonUtils.prob_true(1.0):
                return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_ENEMY

        HeroConstants.WARLIKE_LEVEL_ENUM.AGGRESSIVE:
            return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_ENEMY

    return MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.HOMELAND


func _generate_patrol_origin_position(_lord_patrol_strategy_enum: MWTeamConstants.LORD_PATROL_STRATEGY_ENUM)-> Vector2:
    var _belong_country: String = json.belong_country

    var _country_data: Dictionary = GlobalCountryData.country_data.get(_belong_country)
    var _patrol_location_code: String = ""

    while(StringUtils.is_empty(_patrol_location_code)):
        match _lord_patrol_strategy_enum:
            MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.HOMELAND:
                if ArrayUtils.is_not_empty(_country_data.city_castle_code_list):
                    _patrol_location_code = _country_data.city_castle_code_list.pick_random()

                break

            MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_OWN:
                if ArrayUtils.is_not_empty(_country_data.frontline_own_city_castle_code_list):
                    _patrol_location_code = _country_data.frontline_own_city_castle_code_list.pick_random()
                else:
                    _lord_patrol_strategy_enum = MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.HOMELAND

            MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_ENEMY:
                if ArrayUtils.is_not_empty(_country_data.frontline_enemy_city_castle_code_list):
                    _patrol_location_code = _country_data.frontline_enemy_city_castle_code_list.pick_random()
                else:
                    _lord_patrol_strategy_enum = MWTeamConstants.LORD_PATROL_STRATEGY_ENUM.FRONTLINE_OWN

    if StringUtils.is_not_empty(_patrol_location_code):
        return GlobalLocationData.get_location_point(_patrol_location_code)

    return Vector2.ZERO

func _custom_handle_team_info_color()-> void:

    if get_team_small_type() == MWTeamConstants.TEAM_SMALL_TYPE_ENUM.BLACK_MOON_PAPACY:
        var _config: Dictionary = MWTeamConstants.TEAM_SMALL_TYPE_CONFIG.get(get_team_small_type(),{})
        if _config.has("info_color"):
            _update_info_color(_config.info_color)
            return
    _country_color_mark()


func _dialogue_gd_path()-> String:


    if _is_village_garrison():
        return ""
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(get_leader_uid())
    return DialogueUtils.get_lord_generic_dialogue_gd_path(_hero_json)

func _get_nop_max()-> int:

    if json.get("leader_uid", "") == "village_guard":
        return 80

    if json.get("leader_uid", "") == "village_defender":
        return 300

    var _lord_config: Dictionary = LordConfig.LORD_CONFIG.get(json.get("leader_uid", ""))
    if _lord_config.has("fixed_max_troop"):
        return _lord_config.fixed_max_troop
    return SoldierUtils.get_nop_by_army_size_level(get_leader_json().army_size_level) * 2