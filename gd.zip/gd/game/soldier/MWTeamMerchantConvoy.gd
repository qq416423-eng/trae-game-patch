class_name MWTeamMerchantConvoy extends MWTeamTrade

func _custom_handle_team_info_color()-> void:
    _country_color_mark()

func _custom_timer_timeout()-> void:

    _handle_npc_recover_injured(timer_node.wait_time / 4.0)


func _custom_get_dialogue_leader_name()-> String:
    return team_info.team_name



func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    var _dialogue_node: BaseDialogue = CommonUtils.load_gd(
        DialogueUtils.get_dialogue_path("MerchantConvoyDialogue")
    )
    return _dialogue_node.get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor)

func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return TempDialogue.COMMON_BATTLE_0001

    return MerchantConvoyDialogue.MERCHANT_CONVOY_DIALOGUE_0001