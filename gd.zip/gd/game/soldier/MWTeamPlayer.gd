class_name MWTeamPlayer extends MWTeam



@onready var rain_light_2d_node =$RainLight2D
@onready var draw_circle_node: DrawCircle =$DrawCircle
@onready var draw_circle_battle_join_node: DrawCircle =$DrawCircleBattleJoin


var investigation_area_length: = 0

var investigation_area_length_mult: = 1.0
var light_pic_size: = 512.0

var battle_join_circle_radius: float = 0

var current_battle_join_circle_radius_mult: = 1.0

signal in_location_sign()
signal enter_location_sign(_location_code: String)
signal exit_location_begin_sign(_location_code: String)
signal exit_location_end_sign(_location_code: String)
signal path_points_update_sign(_points: PackedVector2Array)

func open_weather_light2d()-> void:
    rain_light_2d_node.show()

func close_weather_light2d()-> void:
    rain_light_2d_node.hide()

func get_draw_circle_radius()-> float:
    return check_area_collision_shape_2d_node.shape.radius + 20


func handle_and_get_battle_join_check_circle_radius()-> float:
    if current_battle_join_circle_radius_mult != _get_day_night_terrain_rel_speed_mult():
        current_battle_join_circle_radius_mult = _get_day_night_terrain_rel_speed_mult()
        var _tween = get_tree().create_tween()
        _tween.tween_property(
            self, "battle_join_circle_radius",
            TeamConfig.JOIN_PLAYER_BATTLE_RADIUS * current_battle_join_circle_radius_mult, 0.5
        )

    return battle_join_circle_radius

func custom_on_check_area_body_entered(_body: MWTeam):
    if not GlobalNode.game_root.is_in_battle and _body != self:


        _body._show_or_hide_body(true)

func custom_on_check_area_body_exited(_body: MWTeam):

    if is_player and not get_leader_uid().begins_with("mod_") and not GlobalNode.game_root.is_in_battle and _body != self:
        _body._show_or_hide_body(false)


func maybe_handle_mw_team_node_collision()-> void:
    if get_leader_uid().begins_with("mod_"):
        return
    super.maybe_handle_mw_team_node_collision()


func handle_mw_team_node_collision(_meet_mw_team_node: MWTeam)-> void:

    if get_leader_uid().begins_with("mod_"):
        return

    if _meet_mw_team_node.get_leader_uid().begins_with("mod_"):
        var _hero_json = SoldierUtils.get_json_by_hero_uid(_meet_mw_team_node.get_leader_uid())
        if _hero_json.get("current_dialogue_flag", "") == "FOLLOWING":
            return

    if _meet_mw_team_node._is_village_garrison():
        var _player_country: String = SoldierUtils.get_player_belong_country()
        if _player_country != WSCountryData.COUNTRY_NAME_ENUM.NONE \
        and _player_country == _meet_mw_team_node.get_belong_country():
            return

    # 村庄布防不再由"碰到/卷入守军"推断; 现在只有玩家在守军对话里显式选择"进攻村庄"后,
    # 由 BattleScene 依据 GlobalNode._mod_village_assault_target_uid 决定是否布防

    var _meet_behavior: Dictionary = _meet_mw_team_node.json.get("behavior_data",{})
    if _meet_behavior.get("appointed_state", "") == "FOLLOWING":

        if move_target_node != _meet_mw_team_node:
            return
    player_meet_sign.emit(_meet_mw_team_node)



func join_battle(_battle_id: String, _battle_team_type_enum: String = ""):
    if get_leader_uid().begins_with("mod_"):
        return
    super.join_battle(_battle_id, _battle_team_type_enum)



func _update_team_name(_name):
    if get_leader_uid().begins_with("mod_"):
        CommonUtils.update_texture3(
            role_type_icon_node,
            TeamUtils.get_team_role_type_icon(MWTeamConstants.TEAM_ROLE_ENUM.VILLAGER)
        )
        CommonUtils.set_text(name_node, _name)
    else:
        super._update_team_name(_name)

func status_thinking_action()-> void:
    change_status_to_idle()
    GlobalNode.mworld_scene.tip_cshow_camping()


func reach_point()-> void:
    reach_point_sign.emit()


func in_location()-> void:
    var _enter_node = GlobalLocationData.get_location_node(in_location_code)
    if _enter_node:

        var _target_on_island = _enter_node.global_position.y > 4000.0
        var _player_on_island = self.global_position.y > 4000.0
        if _target_on_island == _player_on_island:
            self.global_position = _enter_node.global_position
    in_location_sign.emit()

func enter_location()-> void:
    GlobalLocationData.handle_hero_team_enter_location(in_location_code, get_uid())
    enter_location_sign.emit(in_location_code)

func exit_location_begin()-> void:
    exit_location_begin_sign.emit(in_location_code)

func exit_location_end()-> void:
    GlobalLocationData.handle_hero_team_exit_location(in_location_code, get_uid())
    exit_location_end_sign.emit(in_location_code)

func get_enter_exit_location_wait_frame_count()-> int:
    var _location_type: String = WSLocationData.get_location_type(in_location_code)
    match _location_type:
        LocationConstants.LOCATION_TYPE_ENUM.CITY:
            return 90
        LocationConstants.LOCATION_TYPE_ENUM.CASTLE:
            return 60
        LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:

            return 0
        LocationConstants.LOCATION_TYPE_ENUM.SPECIAL_LOCATION:

            return 0

    return 0

func show_animation()-> void:
    animation_player_node.play("appear_for_player")

func disappear_animation()-> void:
    animation_player_node.play("diappear_for_player")







































func get_join_battle_team_info(_meet_team_node: MWTeam)-> Dictionary:
    var _result: = {
        "left_team_node_list": [],
        "right_team_node_list": []
    }

    if _meet_team_node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:

        var _battle_id: String = _meet_team_node.get_current_battle_id()
        _result.left_team_node_list.append_array(
            WSData.get_team_node_by_battle_id(_battle_id, MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM1)
        )
        _result.right_team_node_list.append_array(
            WSData.get_team_node_by_battle_id(_battle_id, MWTeamConstants.BATTLE_TEAM_TYPE_ENUM.TEAM2)
        )
    else:




        _result.left_team_node_list.append(self)
        _result.right_team_node_list.append(_meet_team_node)

    var _left_origin_node: MWTeam = _result.left_team_node_list[0]
    var _right_origin_node: MWTeam = _result.right_team_node_list[0]

    var check_distance_square = battle_join_circle_radius * battle_join_circle_radius

    for _mw_team_node: MWTeam in warning_team_list:
        if CommonUtils.get_distance_square(self, _mw_team_node) > check_distance_square:
            continue

        if _meet_team_node == _mw_team_node:
            continue


        if _mw_team_node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
            continue


        # 守军/驻军(村庄守备队)只在"被攻击目标本身就是守备队"的村庄攻防战中参战;
        # 其余情况(普通野战)一律不卷入
        if _meet_team_node._is_village_garrison():
            if not _mw_team_node._is_village_garrison() and _mw_team_node.json.get("appointed_leader_uid", "") == "":
                continue
        elif _mw_team_node._is_village_garrison():
            continue

        var _rel_left_enum: = TeamUtils.get_team_rel_type_enum(_left_origin_node, _mw_team_node)
        var _rel_right_enum: = TeamUtils.get_team_rel_type_enum(_right_origin_node, _mw_team_node)
        match _rel_left_enum:
            MWTeamConstants.TEAM_REL_TYPE_ENUM.ALLIED:
                if _rel_right_enum == MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE:
                    _result.left_team_node_list.append(_mw_team_node)
            MWTeamConstants.TEAM_REL_TYPE_ENUM.HOSTILE:
                if _rel_right_enum == MWTeamConstants.TEAM_REL_TYPE_ENUM.ALLIED:
                    _result.right_team_node_list.append(_mw_team_node)




    if not _meet_team_node._is_village_garrison():
        _add_supporting_lords_to_battle(_result, _meet_team_node)


    _add_nearby_appointed_teams_to_battle(_result, _meet_team_node)

    return _result



func _add_supporting_lords_to_battle(_result: Dictionary, _meet_team_node: MWTeam)-> void:
    var _support_join_distance_sq: float = 88.0 * 88.0

    var _all_team_nodes: Array = WSData.team_node_info.values()
    for _node in _all_team_nodes:
        if _node == self:
            continue
        if _node == _meet_team_node:
            continue


        if not _node is MWTeamLord:
            continue

        # 守军/驻军不参与非村庄攻防战
        if _node._is_village_garrison():
            continue

        var _lord_node: MWTeamLord = _node as MWTeamLord
        if not _lord_node.is_supporting_player():
            continue


        if _result.left_team_node_list.has(_node) or _result.right_team_node_list.has(_node):
            continue


        if _node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
            continue


        var _dist_sq: float = CommonUtils.get_distance_square(self, _node)
        if _dist_sq <= _support_join_distance_sq:

            _result.left_team_node_list.append(_node)



func _add_nearby_appointed_teams_to_battle(_result: Dictionary, _meet_team_node: MWTeam)-> void:
    var _appointed_join_distance_sq: float = 80.0 * 80.0

    var _all_team_nodes: Array = WSData.team_node_info.values()
    for _node in _all_team_nodes:
        if _node == self:
            continue
        if _node == _meet_team_node:
            continue


        if _node.json.get("appointed_leader_uid", "") == "":
            continue


        if _result.left_team_node_list.has(_node) or _result.right_team_node_list.has(_node):
            continue


        if _node.get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
            continue


        var _dist_sq: float = CommonUtils.get_distance_square(self, _node)
        if _dist_sq <= _appointed_join_distance_sq:

            _result.left_team_node_list.append(_node)


func camping()-> void:
    change_status_to_idle()


func train()-> void:
    status_machine_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.TRAIN)


func custom_train_start()-> void:
    json.is_training = true
    json.train_start_time_counter = WSData.get_system_counter()


func custom_train_end()-> void:
    json.is_training = false


    var _train_duration_counter: float = WSData.get_system_counter() - json.train_start_time_counter

    if _train_duration_counter < 0.1:
        return

    var _exp: = SkillUtils.get_exp_by_skill_train(team_info.skill_train, team_info.total)
    _exp = int(_exp * SkillConfig.CUSTOM_TRAIN_EXP_RATIO * _train_duration_counter / 1.0)
    TeamUtils.team_add_exp(WSData.get_player_team_simple_json_list(), _exp, false)
    GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.ACQUIRE_EXP_EXTRA_TRAIN,[_exp])
    GlobalNode.refresh_upgrade_soldier_icon()

func _custom_init_status()-> void:
    if not json.has("status_machine_data"):
        load_init_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE)
        return

    if[

        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY,
        MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.TRAIN
    ].has(json.status_machine_data.status):

        load_init_status(json.status_machine_data.status)
    else:

        load_init_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE)

func _custom_physics_process(delta):
    if CommonUtils.counter_is_true(counter, 10):
        _update_surrounding_team_info()


    _check_garrison_arrival()


    if CommonUtils.counter_is_true(counter, 300):
        DialogueCustomUtils.check_and_spawn_village_garrison_teams()

func _custom_init():

    var _player_node = WSData.get_player_team_node()
    var _is_real_player: bool =(_player_node == null or self == _player_node)

    if _is_real_player:
        view_level = 3
        is_player = true
        refresh_team_info(true)
        self.forbid_choose()
        var _investigation_area_length = SkillUtils.get_investigation_area_length(team_info.skill_investigation)
        investigation_area_length = _investigation_area_length
        check_area_collision_shape_2d_node.shape.radius = _investigation_area_length
        current_battle_join_circle_radius_mult = _get_day_night_terrain_rel_speed_mult()
        battle_join_circle_radius = TeamConfig.JOIN_PLAYER_BATTLE_RADIUS * current_battle_join_circle_radius_mult
        var _light_size_mult = _get_light_size_mult()
        rain_light_2d_node.texture_scale = _light_size_mult

    _show_or_hide_body(true)

    if _is_real_player:
        update_belong_country(SoldierUtils.get_player_belong_country())

func _custom_to_day():
    var _investigation_area_length = SkillUtils.get_investigation_area_length(team_info.skill_investigation)
    investigation_area_length = _investigation_area_length
    _change_investigation_area_length_effect()

func _change_investigation_area_length_effect():
    var _tween = get_tree().create_tween()
    _tween.tween_property(
        check_area_collision_shape_2d_node.shape, "radius",
        investigation_area_length * investigation_area_length_mult, 0.5
    )
    var _light_size_mult = _get_light_size_mult()
    _tween.tween_property(
        rain_light_2d_node, "texture_scale",
        _light_size_mult, 0.5
    )

func _get_light_size_mult()-> float:
    return investigation_area_length * investigation_area_length_mult * 1.2 / light_pic_size

func _custom_move()-> void:

    var _points: PackedVector2Array = [self.global_position]

    _points.append_array(navigation_agent_node.get_current_navigation_path().slice(navigation_agent_node.get_current_navigation_path_index()))
    path_points_update_sign.emit(_points)

func _custom_to_night():
    var _investigation_area_length = int(SkillUtils.get_investigation_area_length(team_info.skill_investigation) * MWConfig.INVESTIGATION_NIGHT_RATIO)
    investigation_area_length = _investigation_area_length
    _change_investigation_area_length_effect()

func _update_surrounding_team_info():
    for _node in warning_team_list:
        var _level = SkillUtils.get_view_level(_node.global_position)
        _node.update_view_level_and_count_info(_level)


func _update_investigation_area_length_mult(_mult: float)-> void:
    investigation_area_length_mult = _mult
    _change_investigation_area_length_effect()

func _handle_terrain_type_change_custom(_terrain_type: int)-> void:
    GlobalNode.mworld_scene.update_terrain_type_info(_terrain_type)


    if _terrain_type == MWorldConstants.TERRAIN_TYPE_ENUM.DESERT \
    or WSData.get_player_pre_terrain_type() == MWorldConstants.TERRAIN_TYPE_ENUM.DESERT:
        GlobalNode.mworld_scene.change_weather(WSData.get_player_weather())

func _show_or_hide_body(
    _is_show: bool, is_force: = false,
    _player_animation: = true
)-> void:
    if is_show == _is_show and not is_force:
        return

    is_show = _is_show

    if _is_show:


        show_animation()
    else:



        disappear_animation()

func _open_or_close_detect(_is_open_detect: bool, is_force: = false)-> void:
    if is_open_detact == _is_open_detect and not is_force:
        return

    is_open_detact = _is_open_detect

    if _is_open_detect:
        self.get_node("CollisionShape2D").disabled = false
    else:
        self.get_node("CollisionShape2D").disabled = true

func _custom_handle_team_info_color()-> void:
    _player_color_mark()

func _custom_timer_timeout()-> void:
    var _medical_weight: = int(timer_node.wait_time)


    _handle_medical_and_operation(_medical_weight)
    _handle_morale_recover(timer_node.wait_time)

    self.refresh_team_info(false)

func _on_check_area_area_entered(area: Area2D)-> void:
    var _location_node: MWLocationBase = area.owner

    _location_node.refresh_nop_info()

func _on_check_area_area_exited(area: Area2D)-> void:
    var _location_node: MWLocationBase = area.owner
    _location_node.disable_player_detection()



func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    var _leader_uid: String = get_leader_uid()
    if _leader_uid.begins_with("mod_"):

        var _hero_json = SoldierUtils.get_json_by_hero_uid(_leader_uid)
        if _hero_json.get("current_dialogue_flag", "") == "FOLLOWING":
            return {}
        var _behavior_data: Dictionary = json.get("behavior_data",{})
        if _behavior_data.get("following_to_garrison", false):
            return {}

        var _now: int = WSData.get_system_counter()
        var _last_dialogue: int = json.get("_last_dialogue_counter", 0)
        if _now - _last_dialogue < 2:
            return {}
        json["_last_dialogue_counter"] = _now
        var _dialogue_node: BaseDialogue = DialogueUtils.get_dialogue_gd_by_hero_uid(_leader_uid)
        _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
        _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
        return _dialogue_node.get_current_dialogue_template()
    return {}



func get_team_role()-> int:
    if get_leader_uid().begins_with("mod_"):
        return 99
    return super.get_team_role()



func _check_garrison_arrival()-> void:
    if is_player:
        return

    var _behavior_data: Dictionary = json.get("behavior_data",{})
    if not _behavior_data.get("following_to_garrison", false):
        return

    var _garrison_code: String = _behavior_data.get("garrison_location", "")
    if _garrison_code == "":
        return

    var _garrison_pos: Vector2 = GlobalLocationData.get_location_point(_garrison_code)
    var _dist: float = global_position.distance_to(_garrison_pos)


    var _player_node = WSData.get_player_team_node()
    var _player_near: bool = false
    if _player_node != null:
        _player_near = _player_node.global_position.distance_to(_garrison_pos) <= 29

    if _dist <= 29 or _player_near:

        reset_move_target_node()
        change_status_to_idle()
        json["behavior_data"] = {}
        DialogueUtils.change_current_dialogue_flag("mod_hero_0002", "ARRIVED")