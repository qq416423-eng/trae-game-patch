class_name MWTeamRobber extends MWTeam


func status_thinking_action()-> void:

    var _patrol_target_position: Vector2 = get_next_patrol_position()
    move_to_target(
        _patrol_target_position,
        true, true
    )

func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return TempDialogue.COMMON_BATTLE_0001


    var _dialogue_file_name: = "CommonRobberDialogue"
    if[
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.EVIL_EAGLE_MERCENARY,
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.SCORCHING_SOUL_SECT,
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.CALANT_EXILES,
    ].has(get_team_small_type()):
        _dialogue_file_name = "Robber_" + get_team_small_type() + "_Dialogue"

    var _dialogue_node: BaseDialogue = CommonUtils.load_gd(
        DialogueUtils.get_dialogue_path(_dialogue_file_name)
    )

    _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
    _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)

    return _dialogue_node.get_current_dialogue_template()

func _custom_init():
    pass

func _custom_handle_team_info_color()-> void:
    var _team_small_type_config: Dictionary = MWTeamConstants.TEAM_SMALL_TYPE_CONFIG.get(json.team_small_type)
    _update_info_color(_team_small_type_config.info_color)

func _custom_timer_timeout()-> void:

    _handle_npc_recover_injured(timer_node.wait_time / 4.0)

func _custom_handle_delete()-> void:

    WSData.get_wild_generate_area_node(json.generate_origin).plus_used_enery(- json.generate_enery)


    GlobalNpcTeamData.plus_power_value(
        CommonUtils.get_value(json, "team_small_type", ""),
        team_info.count
    )