class_name MWTeamRobberBoss extends MWTeamRobber

func _custom_handle_delete()-> void:

    GlobalNpcTeamData.npc_team_die(json.npc_team_code)


func status_thinking_action()-> void:

    if get_team_small_type() == MWTeamConstants.TEAM_SMALL_TYPE_ENUM.IMPERIAL_UNION_ARMY \
    and not _is_player_in_kingdom():
        _imperial_union_chase_player()
        return

    if CommonUtils.prob_true(custom_get_replenish_prop()):
        change_status_to_delete()
        return

    var _patrol_target_position: Vector2 = get_next_patrol_position(true)
    move_to_target(
        _patrol_target_position,
        true, true
    )


func _is_player_in_kingdom()-> bool:
    var _player_country: String = SoldierUtils.get_player_belong_country()
    return[
        WSCountryData.COUNTRY_NAME_ENUM.LUCIANA,
        WSCountryData.COUNTRY_NAME_ENUM.EDRAS,
        WSCountryData.COUNTRY_NAME_ENUM.DORDAR,
        WSCountryData.COUNTRY_NAME_ENUM.HASKAL,
    ].has(_player_country)



func _imperial_union_chase_player()-> void:

    if team_info.count * 1.0 / 430 < 0.3:
        change_status_to_delete()
        return

    var _player_node: MWTeam = WSData.get_player_team_node()
    if _player_node == null:
        var _patrol_target_position: Vector2 = get_next_patrol_position(true)
        move_to_target(_patrol_target_position, true, true)
        return

    var _distance: float = global_position.distance_to(_player_node.global_position)
    if _distance < 3500:

        move_to_target(_player_node.global_position, false, false)
    else:

        var _patrol_target_position: Vector2 = get_next_patrol_position(true)
        move_to_target(_patrol_target_position, true, true)



func custom_get_replenish_prop()-> float:


    return 0.0

func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:
    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return TempDialogue.COMMON_BATTLE_0001


    if get_team_small_type() == MWTeamConstants.TEAM_SMALL_TYPE_ENUM.IMPERIAL_UNION_ARMY:
        var _dialogue_file_name: = "ImperialUnionDialogue"
        var _dialogue_node: BaseDialogue = CommonUtils.load_gd(
            DialogueUtils.get_dialogue_path(_dialogue_file_name)
        )
        _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
        _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
        return _dialogue_node.get_current_dialogue_template()

    var _dialogue_gd: BaseDialogue = DialogueUtils.get_dialogue_gd_by_hero_uid(get_leader_uid())

    _dialogue_gd.set_a_team_dialogue_info(_a_team_dialogue_info)
    _dialogue_gd.set_b_team_dialogue_info(_b_team_dialogue_info)

    return _dialogue_gd.get_current_dialogue_template()


func _custom_get_dialogue_leader_name()-> String:
    if get_team_small_type() == MWTeamConstants.TEAM_SMALL_TYPE_ENUM.IMPERIAL_UNION_ARMY:
        return CommonUtils.get_value(json, "team_name", "帝国联盟军")
    return team_info.leader_name