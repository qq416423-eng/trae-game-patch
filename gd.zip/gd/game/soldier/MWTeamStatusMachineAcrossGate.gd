extends StatusMachineBase

var team_node: MWTeam = owner

var allow_exit_status: = true

var counter: = 0

func _ready():
    team_node = owner

func enter_status():
    team_node.is_in_location = true
    team_node.in_location_code = team_node.gate_location_code
    allow_exit_status = false
    counter = 0

    team_node.show_or_hide_body_and_detect(false, false)

    if team_node.is_player:
        GlobalLocationData.show_player_avatar(team_node.in_location_code)

func action():
    if counter > 120:
        allow_exit_status = true
        if team_node.move_type == MWTeamConstants.MOVE_TYPE_ENUM.NONE:
            team_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.THINKING)
        else:
            team_node.change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.MOVE)

    counter += 1

func exit_status(_next_status)-> bool:
    if allow_exit_status:
        allow_exit_status = false
        if team_node.gate_exit_point == Vector2.ZERO:
            var _gate_code = team_node.in_location_code if StringUtils.is_not_empty(team_node.in_location_code) else "MWCastle0001"
            team_node.gate_exit_point = GlobalLocationData.get_gate_exit_point(
                _gate_code,
                team_node.global_position
            )

        team_node.global_position = team_node.gate_exit_point

        team_node.gate_exit_point = Vector2.ZERO
        team_node._open_or_close_detect(true)

        if team_node.is_player:
            team_node._show_or_hide_body(true)
            GlobalLocationData.delete_player_avatar(team_node.in_location_code)

        team_node.is_in_location = false
        team_node.in_location_code = ""

        return true
    else:
        return false

func get_action_status():
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ACROSS_GATE

func get_action_status_str()-> String:
    return "ACROSS_GATE"