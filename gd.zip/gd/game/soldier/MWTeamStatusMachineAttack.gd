extends StatusMachineBase

var team_node: MWTeam = owner
var counter = 0

var refresh_info_interval = 60 * 3

func _ready()-> void:
    team_node = owner

func enter_status()-> void:
    team_node.move_stop()
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.BATTLE)

    team_node.npc_battle_temp_team = TeamUtils.list_living_soldier_json(team_node.json.team)

func action()-> void:
    pass

func exit_status(_next_status)-> bool:
    if _next_status == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE:
        return true

    team_node.npc_battle_temp_team = []





    if not team_node.is_player:


        team_node.heal_active_soldier_and_all_hero()

    team_node.refresh_nop_info()

    if not team_node.is_player:
        team_node.refresh_injured_simple_json()

    return true

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK

func get_action_status_str()-> String:
    return "ATTACK"