extends StatusMachineBase

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status():
    team_node.delete()

func action():
    pass

func exit_status(_next_status)-> bool:
    return true

func get_action_status():
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE

func get_action_status_str()-> String:
    return "DELETE"