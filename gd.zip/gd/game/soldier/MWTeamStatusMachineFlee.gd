extends StatusMachineSubBase

var team_node: MWTeam = owner
var counter: = 0

var flee_target_position: Vector2 = Vector2.ZERO

func _ready():
    team_node = owner

func enter_status()-> void:
    counter = 0

func action()-> void:
    if CommonUtils.counter_is_true(counter, 20):
        flee_target_position = team_node.get_flee_target_position()
        if flee_target_position == Vector2.ZERO:
            team_node.change_status_to_thinking()
            return

        team_node.set_move_target(flee_target_position)

    var _is_reach: = team_node.move()
    if _is_reach:
        team_node.change_status_to_thinking()

    counter += 1

func exit_status(_next_status: int)-> bool:
    return true

func get_action_status_str()-> String:
    return "FLEE"