extends StatusMachineBase

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status():
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.REST)
    team_node.move_stop()

func action():
    pass

func exit_status(_next_status)-> bool:
    return true

func get_action_status():
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE

func get_action_status_str()-> String:
    return "IDLE"