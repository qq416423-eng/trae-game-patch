extends StatusMachineSubBase

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status()-> void:
    team_node.delete()

func action()-> void:
    pass

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_DELETE

func get_action_status_str()-> String:
    return "LocationDelete"