extends StatusMachineSubBase

var team_node: MWTeam = owner
var counter: = 0.0

var wait_frame_count: = 0

func _ready():
    team_node = owner

func enter_status()-> void:
    team_node.is_in_location = true

    if StringUtils.is_empty(team_node.in_location_code):


        team_node.in_location_code = team_node.current_target_location_code


    team_node.move_stop()

    team_node.show_or_hide_body_and_detect(false, false)
    counter = 0
    if team_node.is_init_status:
        wait_frame_count = 0
    else:
        wait_frame_count = team_node.get_enter_exit_location_wait_frame_count()

    team_node.enter_location()
    team_node.clear_move_info()


    if team_node.is_player:
        GlobalLocationData.show_player_avatar(team_node.in_location_code)



func action()-> void:
    if counter >= wait_frame_count:
        get_parent().change_sub_status(
            MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_THINKING
        )
        return

    counter +=(1 * GlobalTimeControl.current_time_scale)

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_ENTER

func get_action_status_str()-> String:
    return "LocationEnter"