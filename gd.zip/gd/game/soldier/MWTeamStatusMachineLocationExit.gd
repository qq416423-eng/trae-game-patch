extends StatusMachineSubBase

var team_node: MWTeam = owner

var wait_frame_count: = 0
var counter: = 0.0

func _ready():
    team_node = owner

func enter_status()-> void:
    counter = 0
    wait_frame_count = team_node.get_enter_exit_location_wait_frame_count()
    team_node.exit_location_begin()

func action()-> void:
    if counter >= wait_frame_count:

        var _exit_node = GlobalLocationData.get_location_node(
            team_node.in_location_code
        )
        if _exit_node:
            team_node.global_position = _exit_node.get_near_entrance_position(
                team_node.get_move_target_position()
            )
        team_node.change_status_to_move(call_back_func)
        return

    counter +=(1 * GlobalTimeControl.current_time_scale)

func exit_status(_next_status: int)-> bool:
    if counter < wait_frame_count:
        return false

    if team_node.is_player:
        team_node._show_or_hide_body(true)
        GlobalLocationData.delete_player_avatar(team_node.in_location_code)


    team_node.exit_location_end()


    team_node.is_in_location = false
    team_node.in_location_code = ""



    team_node._open_or_close_detect(true)


    return true

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_EXIT

func get_action_status_str()-> String:
    return "LocationExit"