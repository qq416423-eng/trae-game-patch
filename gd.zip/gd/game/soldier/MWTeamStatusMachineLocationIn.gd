extends StatusMachineSubBase

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status()-> void:
    if team_node.is_init_status:
        pass
    else:
        team_node.in_location()

func action()-> void:
    if team_node.move_type == MWTeamConstants.MOVE_TYPE_ENUM.LOCATION \
    and team_node.current_target_location_code == team_node.in_location_code:


        team_node.move_type = MWTeamConstants.MOVE_TYPE_ENUM.NONE
        team_node.in_location()
        return

    if team_node.move_type != MWTeamConstants.MOVE_TYPE_ENUM.NONE:
        get_parent().change_sub_status(
            MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_EXIT
        )
        return

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_IN

func get_action_status_str()-> String:
    return "LocationIn"