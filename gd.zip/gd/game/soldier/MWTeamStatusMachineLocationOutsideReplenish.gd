extends StatusMachineBase

var team_node: MWTeam = owner
const INTERVAL_FRAMES = 60 * 10

var replenish_speed: = 10

var plan_replenish_nop: = 0

var current_replenish_nop: = 0
var counter: = 0
var flee_check_counter: = 0

func _ready():
    team_node = owner

func enter_status():
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.REST)
    team_node.move_stop()
    team_node.move_need_flee = true
    team_node.move_need_pursue = false
    team_node.in_location_code = team_node.current_target_location_code



    replenish_speed = team_node.get_replenish_soldier_speed()
    plan_replenish_nop = team_node.get_plan_replenish_soldier_nop()
    current_replenish_nop = 0
    counter = 0

    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.REST)

func action():
    counter += int(1 * GlobalTimeControl.current_time_scale)
    flee_check_counter += 1

    if CommonUtils.counter_is_true(counter, 40):

        var _has_event: bool = team_node.handle_maybe_flee_pursue()
        if _has_event:
            return

    if counter > INTERVAL_FRAMES:
        var _replenish_nop: int = min(
            plan_replenish_nop - current_replenish_nop,
            replenish_speed
        )
        team_node.custom_npc_replenish_soldier(_replenish_nop)
        current_replenish_nop += _replenish_nop
        counter = 0

        if current_replenish_nop >= plan_replenish_nop:

            team_node.save_decision_ai_data(HeroConstants.LORD_DECISION_AI_TYPE_ENUM.NONE)
            team_node.change_status_to_thinking()

func exit_status(_next_status)-> bool:
    team_node.in_location_code = ""
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.NONE)
    return true

func get_action_status():
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_OUTSIDE_REPLENISH

func get_action_status_str()-> String:
    return "LOCATION_OUTSIDE_REPLENISH"