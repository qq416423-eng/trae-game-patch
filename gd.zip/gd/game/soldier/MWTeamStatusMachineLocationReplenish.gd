extends StatusMachineSubBase

var team_node: MWTeam = owner

const INTERVAL_FRAMES = 60 * 10

var replenish_speed: = 10

var plan_replenish_nop: = 0

var current_replenish_nop: = 0
var counter: = 0

func _ready():
    team_node = owner

func enter_status()-> void:


    replenish_speed = team_node.get_replenish_soldier_speed()
    plan_replenish_nop = team_node.get_plan_replenish_soldier_nop()
    current_replenish_nop = 0
    counter = 0

func action()-> void:
    counter += int(1 * GlobalTimeControl.current_time_scale)
    if counter > INTERVAL_FRAMES:
        var _replenish_nop: int = min(plan_replenish_nop - current_replenish_nop, replenish_speed)
        team_node.custom_npc_replenish_soldier(_replenish_nop)
        current_replenish_nop += _replenish_nop
        counter = 0

        GlobalLocationData.maybe_refresh_nop_info(team_node.in_location_code)

        if current_replenish_nop >= plan_replenish_nop:

            team_node.save_decision_ai_data(HeroConstants.LORD_DECISION_AI_TYPE_ENUM.NONE)
            team_node.status_thinking_action()
            change_sub_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_THINKING)

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_NPC_REPLENISH

func get_action_status_str()-> String:
    return "LocationReplenish"