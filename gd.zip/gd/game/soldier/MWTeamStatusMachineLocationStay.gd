extends StatusMachineTopBase

@onready var location_enter_node: StatusMachineBase =$LocationEnter







var team_node: MWTeam = owner
var current_sub_status_machine_node: StatusMachineBase

var sub_status_machine_node_dic: Dictionary = {}

func _ready():
    team_node = owner
    for _sub_status_machine_node: StatusMachineSubBase in get_children():
        sub_status_machine_node_dic[_sub_status_machine_node.get_action_status()] = _sub_status_machine_node

func enter_status():
    current_sub_status_machine_node = location_enter_node
    current_sub_status_machine_node.enter_status()

func load_init_status():
    current_sub_status_machine_node = location_enter_node
    var _pre_status: = current_sub_status_machine_node.get_action_status()
    current_sub_status_machine_node.enter_status()
    current_sub_status_machine_node.action()

    while(_pre_status != current_sub_status_machine_node.get_action_status()):
        _pre_status = current_sub_status_machine_node.get_action_status()

        current_sub_status_machine_node.action()

func change_sub_status(_mw_team_status: int, _callable: Callable = Callable())-> void:















    current_sub_status_machine_node = sub_status_machine_node_dic.get(_mw_team_status)

    current_sub_status_machine_node.set_callable(_callable)
    current_sub_status_machine_node.enter_status()

func action():
    current_sub_status_machine_node.action()

func exit_status(_next_status)-> bool:


    return current_sub_status_machine_node.exit_status(_next_status)

func set_callable(_callable: Callable)-> void:
    current_sub_status_machine_node.call_back_func = _callable

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY

func get_action_status_str()-> String:
    return current_sub_status_machine_node.get_action_status_str()