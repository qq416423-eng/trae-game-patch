extends StatusMachineSubBase


const TRADE_STAY_DURATION_FRAMES: int = LocationConfig.TRADE_ENTER_TIME_ELAPSED_SECONDS * 60

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status():
    pass

func action():
    var _location_sub_status_info: Dictionary = team_node.get_location_sub_status_by_thinking()
    change_sub_status(_location_sub_status_info.status, _location_sub_status_info.callable)

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_THINKING

func get_action_status_str()-> String:
    return "LocationThinking"