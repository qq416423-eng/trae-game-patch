extends StatusMachineSubBase


const TRADE_STAY_DURATION_FRAMES: int = LocationConfig.TRADE_ENTER_TIME_ELAPSED_SECONDS * 60

var team_node: MWTeam = owner
var counter: = 0

func _ready():
    team_node = owner

func enter_status():
    counter = 0
    team_node.trade()

func action():
    if counter >= TRADE_STAY_DURATION_FRAMES:
        if not call_back_func.is_null():
            call_back_func.call()

        change_sub_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_THINKING)
        return

    counter += 1

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_TRADE

func get_action_status_str()-> String:
    return "LocationTrade"