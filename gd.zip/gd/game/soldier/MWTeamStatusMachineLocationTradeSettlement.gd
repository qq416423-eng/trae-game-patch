extends StatusMachineSubBase

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status():
    team_node.trade_recycle()

func action():
    if not call_back_func.is_null():
        call_back_func.call()

    change_sub_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_THINKING)

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_TRADE_SETTLEMENT

func get_action_status_str()-> String:
    return "LocationTradeSettlement"