extends StatusMachineTopBase

@onready var move_to_point_node: StatusMachineBase =$MoveToPoint
@onready var move_to_location: StatusMachineBase =$MoveToLocation
@onready var move_to_mw_team: StatusMachineBase =$MoveToMWTeam
@onready var flee_node: Node =$Flee
@onready var pursue_node: Node =$Pursue

var team_node: MWTeam = owner
var current_sub_status_machine_node: StatusMachineBase

func _ready():
    team_node = owner

func enter_status()-> void:
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.NONE)

    match team_node.move_type:
        MWTeamConstants.MOVE_TYPE_ENUM.FIXED:
            current_sub_status_machine_node = move_to_point_node
        MWTeamConstants.MOVE_TYPE_ENUM.DYNAMIC:
            current_sub_status_machine_node = move_to_mw_team
        MWTeamConstants.MOVE_TYPE_ENUM.LOCATION:
            current_sub_status_machine_node = move_to_location
        MWTeamConstants.MOVE_TYPE_ENUM.FLEE:
            current_sub_status_machine_node = flee_node
        MWTeamConstants.MOVE_TYPE_ENUM.PURSUE:
            current_sub_status_machine_node = pursue_node

    current_sub_status_machine_node.enter_status()

func action()-> void:
    current_sub_status_machine_node.action()

func exit_status(_next_status: int)-> bool:
    return current_sub_status_machine_node.exit_status(_next_status)

func set_callable(_callable: Callable)-> void:
    current_sub_status_machine_node.call_back_func = _callable

func get_action_status()-> int:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.MOVE

func get_action_status_str()-> String:
    return current_sub_status_machine_node.get_action_status_str()