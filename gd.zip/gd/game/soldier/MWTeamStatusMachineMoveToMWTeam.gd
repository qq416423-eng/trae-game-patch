extends StatusMachineSubBase

const MOVE_TO_TARGET_NODE_ALLOW_OFFSET_SQUARE: = 32 * 32

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func enter_status()-> void:
    pass

func action()-> void:
    if CommonUtils.is_not_null(team_node.move_target_node):
        team_node.set_move_target(team_node.move_target_node.global_position)

    var _is_reach: = team_node.move(MOVE_TO_TARGET_NODE_ALLOW_OFFSET_SQUARE)
    if _is_reach:
        team_node.maybe_handle_mw_team_node_collision()

func exit_status(_next_status: int)-> bool:
    team_node.reset_flee_pursue_setting()
    return true

func get_action_status_str()-> String:
    return "MOVE"