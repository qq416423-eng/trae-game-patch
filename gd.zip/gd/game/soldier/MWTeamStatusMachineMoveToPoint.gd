extends StatusMachineSubBase

var team_node: MWTeam = owner

var counter: = 0

func _ready():
    team_node = owner

func enter_status()-> void:
    counter = 0

func action()-> void:



    if CommonUtils.counter_is_true(counter, 40):





        var _has_event: bool = team_node.handle_maybe_flee_pursue()
        if _has_event:
            return

    var _is_reach: = team_node.move()
    if _is_reach:
        if not call_back_func.is_null():
            call_back_func.call()

        team_node.change_status_to_thinking()
        team_node.reach_point()
        return

    counter += 1

func exit_status(_next_status: int)-> bool:
    team_node.reset_flee_pursue_setting()
    return true

func get_action_status_str()-> String:
    return "MOVE"