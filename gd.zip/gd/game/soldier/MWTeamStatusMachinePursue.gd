extends StatusMachineSubBase

var team_node: MWTeam = owner
var counter: = 0
var target_update_counter: = 0



const MOVE_TO_TARGET_NODE_ALLOW_OFFSET_SQUARE: = 32 * 32
const TARGET_UPDATE_INTERVAL: = 10

func _ready():
    team_node = owner

func enter_status()-> void:
    counter = 0
    target_update_counter = 0
    if CommonUtils.is_not_null(team_node.move_target_node):
        team_node.set_move_target(team_node.move_target_node.global_position)

func action()-> void:
    if CommonUtils.counter_is_true(counter, 20):

        if team_node.check_danger():
            team_node.change_status_to_flee()
            return

        team_node.set_move_target_node(team_node.get_pursue_target_node())

    if CommonUtils.is_null(team_node.move_target_node):
        team_node.change_status_to_thinking()
        return

    if CommonUtils.counter_is_true(target_update_counter, TARGET_UPDATE_INTERVAL):
        team_node.set_move_target(team_node.move_target_node.global_position)

    var _is_reach: = team_node.move(MOVE_TO_TARGET_NODE_ALLOW_OFFSET_SQUARE)
    if _is_reach:
        team_node.maybe_handle_mw_team_node_collision()

    counter += 1
    target_update_counter += 1

func exit_status(_next_status: int)-> bool:
    team_node.set_move_target_node(null)
    return true

func get_action_status_str()-> String:
    return "PURSUE"