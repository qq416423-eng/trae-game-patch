extends StatusMachineBase

var team_node: MWTeam = owner

func _ready()-> void:
    team_node = owner

func enter_status()-> void:
    pass

func action()-> void:
    team_node.status_thinking_action()

func exit_status(_next_status)-> bool:
    return true

func get_action_status():
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.THINKING

func get_action_status_str()-> String:
    return "THINKING"