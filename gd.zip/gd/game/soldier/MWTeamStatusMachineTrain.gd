extends StatusMachineBase

var team_node: MWTeam = owner

func _ready():
    team_node = owner

func load_init_status()-> void:
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.TRAIN)

func enter_status()-> void:
    team_node.update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.TRAIN)
    team_node.move_stop()
    team_node.custom_train_start()

func action()-> void:
    pass

func exit_status(_next_status)-> bool:
    team_node.custom_train_end()
    return true

func get_action_status()-> MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM:
    return MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.TRAIN

func get_action_status_str()-> String:
    return "TRAIN"