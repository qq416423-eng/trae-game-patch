class_name MWTeamTrade extends MWTeam





func handle_mw_team_node_collision(_meet_mw_team_node: MWTeam)-> void:
    if not self.is_player and not _meet_mw_team_node.is_player:

        if _meet_mw_team_node.json.has("appointed_leader_uid") and _meet_mw_team_node.json.appointed_leader_uid != "":
            var _rel_value: int = TeamUtils.get_team_rel_value(self, _meet_mw_team_node)
            if _rel_value < 0:
                var _my_power: float = float(get_combat_power())
                var _enemy_power: float = float(_meet_mw_team_node.get_combat_power())
                if _my_power < _enemy_power:

                    change_status_to_flee()

                return
    super.handle_mw_team_node_collision(_meet_mw_team_node)


func status_thinking_action()-> void:
    if json.ai_task.size() >= 1:
        var _task_json: Dictionary = json.ai_task[0]
        AiTaskMWTConstants.handle_task(self, _task_json)
    else:
        change_status(MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.DELETE)


func get_location_sub_status_by_thinking()-> Dictionary:
    if json.ai_task.size() >= 1:
        var _task_json: Dictionary = json.ai_task[0]
        return AiTaskMWTConstants.get_location_sub_status(self, _task_json)
    else:
        return {
            "status": MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.LOCATION_STAY_SUB_DELETE,
            "callable": Callable()
        }

func _custom_init():

    if not json.has("ai_task"):
        if json.has("ai_data") and json.ai_data.has("blackboard") and json.ai_data.blackboard.has("location_list"):

            var _location_list: Array = json.ai_data.blackboard.location_list
            json.ai_task = _tranfer_ai_task(_location_list)
        else:
            json.ai_task = _generate_ai_task()

func _generate_ai_task()-> Array:
    return[
        AiTaskMWTConstants.generate_move_to_location_with_flee_task(
            json.target_location_code
        ),

        AiTaskMWTConstants.generate_trade_task(),
        AiTaskMWTConstants.generate_move_to_location_with_flee_task(
            json.origin_location_code
        ),

        AiTaskMWTConstants.generate_trade_settlement_task(),
        AiTaskMWTConstants.generate_delete_task()
    ]

func _tranfer_ai_task(_location_code_list: Array)-> Array:
    var _temp_location_code_list = _location_code_list.duplicate(true)
    var _task: = []

    _task.push_front(
        AiTaskMWTConstants.generate_delete_task()
    )

    _task.push_front(
        AiTaskMWTConstants.generate_trade_settlement_task()
    )


    if _temp_location_code_list.size() >= 1:
        _task.push_front(
            AiTaskMWTConstants.generate_move_to_location_with_flee_task(
                _temp_location_code_list.pop_back()
            )
        )
    else:
        return _task


    if not CommonUtils.get_value(json, "is_trade_finish", false):
        _task.push_front(
            AiTaskMWTConstants.generate_trade_task()
        )
    else:
        return _task

    if _temp_location_code_list.size() >= 1:
        _task.push_front(
            AiTaskMWTConstants.generate_move_to_location_with_flee_task(
                _temp_location_code_list.pop_back()
            )
        )
    else:
        return _task

    return _task

func _custom_handle_ally_relation_gain_after_battle(_value_factor: float)-> void:
    LocationUtils.plus_player_relation_value(
        _get_origin_location_code(),
        _value_factor *(1.0 +(get_active_nop() * 1.0 / 100))
    )

func _get_origin_location_code()-> String:
    return CommonUtils.get_value(json, "origin_location_code", "")