class_name MWTeamVillager extends MWTeamTrade






var mod_replenish_target: String = ""
var mod_replenish_last_time: float = 0.0
var mod_replenish_state: String = "none"
var mod_replenish_cooldown: Dictionary = {}

var mod_replenish_paused: bool = false



const MOD_REPLENISH_CAPTURED_INTERVAL: float = 2.0 / 30.0
const MOD_REPLENISH_GRANTED_INTERVAL: float = 3.8 / 30.0

const MOD_REPLENISH_COOLDOWN_DAYS: float = 30.0



func _custom_init():
    super._custom_init()
    var _saved_cooldown = json.get("mod_replenish_cooldown",{})
    if _saved_cooldown is Dictionary:
        mod_replenish_cooldown = _saved_cooldown


func _custom_physics_process(delta):

    _check_garrison_arrival()

    var _behavior_data: Dictionary = json.get("behavior_data",{})
    if _behavior_data.get("patrol_mode", "") == "replenish":
        var _max_nop: int = _mod_get_team_max_nop()
        var _cur_nop: int = team_info.count
        if _max_nop > 0 and float(_cur_nop) < float(_max_nop) * 0.15:

            pass
        else:

            _combat_follow_scan_enemies()
            _replenish_patrol_scan_enemies()
    else:
        _combat_follow_scan_enemies()

    _mod_handle_replenish()



func status_thinking_action()-> void:
    var _behavior_data: Dictionary = json.get("behavior_data",{})

    if _behavior_data.get("appointed_state", "") == "COMBAT_FOLLOW":
        var _player_node = WSData.get_player_team_node()
        if _player_node != null:
            will_attack_player = false
            will_attack_player_counter = -1
            move_to_team(_player_node)
        return

    if _behavior_data.get("patrol_mode", "") == "replenish":

        var _max_nop: int = _mod_get_team_max_nop()
        var _is_critical_low: bool = _max_nop > 0 and float(team_info.count) < float(_max_nop) * 0.15

        if _is_critical_low:
            mod_replenish_paused = false
        if _is_critical_low and mod_replenish_state == "none" and not mod_replenish_paused:

            if _mod_try_start_replenish():
                return
        if mod_replenish_state == "replenishing" and mod_replenish_target != "":

            mod_replenish_state = "moving"
            move_to_location(mod_replenish_target, true, false)
            return

        if not mod_replenish_paused:
            if _mod_try_start_replenish():
                return
    if _behavior_data.get("patrol_radius", 0) > 0:
        var _patrol_target_position: Vector2 = get_next_patrol_position()
        move_to_target(_patrol_target_position, true, true)
    elif get_leader_uid() == "minor_hero_0012":

        _nun_thinking_action()
    elif get_leader_uid().begins_with("mod_"):

        pass
    else:
        super.status_thinking_action()




func reach_location()-> void:

    if get_leader_uid() == "minor_hero_0012":
        _nun_switch_target()
        change_status_to_thinking()
        return
    if json.has("appointed_leader_uid") and json.appointed_leader_uid != "":
        if mod_replenish_state == "moving" and current_target_location_code == mod_replenish_target:

            mod_replenish_state = "replenishing"
            mod_replenish_last_time = WSData.get_system_counter()
            change_status_to_idle()
            update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.REST)
            return
        change_status_to_thinking()
        return
    super.reach_location()



func _mod_handle_replenish()-> void:
    if mod_replenish_state != "replenishing":
        return

    if get_status() != MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.IDLE:
        return

    var _max_nop: int = _mod_get_team_max_nop()
    if team_info.count >= _max_nop:
        _mod_finish_replenish()
        return

    var _is_captured: bool = _mod_is_captured_village(mod_replenish_target)
    var _interval: float = MOD_REPLENISH_CAPTURED_INTERVAL if _is_captured else MOD_REPLENISH_GRANTED_INTERVAL
    var _cur_time: float = WSData.get_system_counter()
    if _cur_time - mod_replenish_last_time < _interval:
        return
    mod_replenish_last_time = _cur_time

    var _soldier_uid: String = _mod_generate_local_soldier(mod_replenish_target, _is_captured)
    if _soldier_uid != "":
        var _simple_json: Dictionary = SoldierUtils.generate_repair_simple_json(_soldier_uid)
        add_soldier([_simple_json])
        refresh_nop_info()



func _mod_try_start_replenish()-> bool:
    if not json.has("appointed_leader_uid") or json.appointed_leader_uid == "":
        return false
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    if _behavior_data.get("appointed_state", "") == "COMBAT_FOLLOW":
        return false
    if mod_replenish_state != "none":
        return false

    var _max_nop: int = _mod_get_team_max_nop()
    if team_info.count >= _max_nop:
        return false

    var _target_code: String = _mod_find_nearest_replenish_location()
    if _target_code == "":
        return false
    mod_replenish_target = _target_code
    mod_replenish_state = "moving"
    move_to_location(_target_code, true, false)
    return true



func _mod_finish_replenish()-> void:
    if mod_replenish_target != "":
        mod_replenish_cooldown[mod_replenish_target] = WSData.get_system_counter()

        json["mod_replenish_cooldown"] = mod_replenish_cooldown
        mod_replenish_target = ""
    mod_replenish_state = "none"
    update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.NONE)
    change_status_to_thinking()



func _mod_get_team_max_nop()-> int:
    var _hero_uid: String = json.get("appointed_leader_uid", "")
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    var _skill_manage: int = CommonUtils.get_value(_hero_json, "skill_manage", 0)
    return _skill_manage * SkillConfig.HERO_MANAGE_SKILL_NOP_LIMIT_PER_LEVEL + SkillConfig.HERO_MANAGE_SKILL_NOP_LIMIT_BASE






func _mod_find_nearest_replenish_location()-> String:
    var _player_uid: String = SoldierUtils.get_player_hero_uid()
    var _player_fief_list: Array = SoldierUtils.get_player_fief_code_list()
    var _cur_time: float = WSData.get_system_counter()
    var _captured_candidates: Array = []
    var _granted_candidates: Array = []
    for _loc_code in _player_fief_list:

        if WSLocationData.get_location_type(_loc_code) != LocationConstants.LOCATION_TYPE_ENUM.VILLAGE:
            continue

        if mod_replenish_cooldown.has(_loc_code):
            if _cur_time - mod_replenish_cooldown[_loc_code] < MOD_REPLENISH_COOLDOWN_DAYS:
                continue
        var _belong_country: String = WSLocationData.get_belong_country(_loc_code)
        if _belong_country == WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION:

            _captured_candidates.append(_loc_code)
        else:

            _granted_candidates.append(_loc_code)

    var _best: String = _mod_nearest_in_list(_captured_candidates)
    if _best != "":
        return _best
    return _mod_nearest_in_list(_granted_candidates)



func _mod_is_captured_village(_location_code: String)-> bool:
    return WSLocationData.get_belong_country(_location_code) == WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION



func _mod_nearest_in_list(_loc_list: Array)-> String:
    if _loc_list.is_empty():
        return ""
    var _best_code: String = ""
    var _best_dist: float = 1000000000000000000
    for _code in _loc_list:
        var _pos: Vector2 = GlobalLocationData.get_location_point(_code)
        var _dist: float = global_position.distance_squared_to(_pos)
        if _dist < _best_dist:
            _best_dist = _dist
            _best_code = _code
    return _best_code




func _mod_generate_local_soldier(_location_code: String, _is_captured: bool)-> String:
    var _loc_data: Dictionary = WSLocationData.get_city_data(_location_code)
    var _recruit_config: Dictionary = LocationUtils._get_recruit_config(_loc_data)
    if _recruit_config.is_empty():
        return ""
    var _all_uids: Array = []
    if _recruit_config.has("common"):
        _all_uids.append_array(_recruit_config.common.keys())
    if _recruit_config.has("addition"):
        _all_uids.append_array(_recruit_config.addition.keys())
    if _all_uids.is_empty():
        return ""
    var _target_stars: Array = [2, 3] if _is_captured else[1, 2]
    var _filtered: Array = []
    for _uid in _all_uids:
        var _star: int = GlobalSoldierInfo.get_star(_uid)
        if _star in _target_stars:
            _filtered.append(_uid)
    if _filtered.is_empty():
        _filtered = _all_uids
    return _filtered[randi() % _filtered.size()]


func _custom_handle_team_info_color()-> void:

    var _leader_uid: String = get_leader_uid()
    if _leader_uid.begins_with("mod_"):
        _player_color_mark()
    else:
        _country_color_mark()

func _custom_timer_timeout()-> void:
    _handle_npc_recover_injured(timer_node.wait_time / 4.0)


func _custom_get_dialogue_leader_name()-> String:
    return team_info.team_name


func get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor: float)-> Dictionary:
    var _dialogue_node: BaseDialogue = CommonUtils.load_gd(
        DialogueUtils.get_dialogue_path("VillagerDialogue")
    )
    return _dialogue_node.get_after_battle_thank_dialogue_template(_relation_gain_after_battle_factor)


func get_dialogue_template(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary
)-> Dictionary:

    var _leader_uid: String = get_leader_uid()
    if _leader_uid.begins_with("mod_"):
        var _dialogue_node: BaseDialogue = DialogueUtils.get_dialogue_gd_by_hero_uid(_leader_uid)
        _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
        _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
        return _dialogue_node.get_current_dialogue_template()


    if _leader_uid == "minor_hero_0012":
        var _dialogue_node: BaseDialogue = DialogueUtils.get_dialogue_gd_by_hero_uid(_leader_uid)
        _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
        _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
        return _dialogue_node.get_current_dialogue_template()


    if json.has("appointed_leader_uid") and json.appointed_leader_uid != "":
        var _dialogue_node: BaseDialogue = CommonUtils.load_gd("res://gd/game/dialogue/AppointedHeroDialogue.gd")
        _dialogue_node.set_a_team_dialogue_info(_a_team_dialogue_info)
        _dialogue_node.set_b_team_dialogue_info(_b_team_dialogue_info)
        _dialogue_node.appointed_hero_uid = json.appointed_leader_uid
        _dialogue_node.is_in_battle =(get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK)
        return _dialogue_node.get_current_dialogue_template()

    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return TempDialogue.COMMON_BATTLE_0001

    return TempDialogue.VILLAGER_DIALOGUE_0001



func _check_garrison_arrival()-> void:
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    if not _behavior_data.get("following_to_garrison", false):
        return

    var _garrison_code: String = _behavior_data.get("garrison_location", "")
    if _garrison_code == "":
        return

    var _garrison_pos: Vector2 = GlobalLocationData.get_location_point(_garrison_code)
    var _dist: float = global_position.distance_to(_garrison_pos)

    if _dist <= 50:
        reset_move_target_node()
        change_status_to_idle()
        json["behavior_data"] = {}
        DialogueUtils.change_current_dialogue_flag("mod_hero_0002", "ARRIVED")



func handle_battle_end(
    _battle_result_enum: String,
    _ally_relation_gain_after_battle_factor: float = 0.0,
)-> void:

    if mod_replenish_state == "replenishing" or mod_replenish_state == "moving":
        mod_replenish_state = "none"
        mod_replenish_target = ""
        update_status_icon(MWTeamConstants.STATUS_ICON_TYPE_ENUM.NONE)

    mod_replenish_paused = true
    super.handle_battle_end(_battle_result_enum, _ally_relation_gain_after_battle_factor)



var _replenish_scan_counter: int = 0
func _replenish_patrol_scan_enemies()-> void:
    var _behavior_data: Dictionary = json.get("behavior_data",{})

    if _behavior_data.get("patrol_mode", "") != "replenish":
        return

    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return

    if move_type == MWTeamConstants.MOVE_TYPE_ENUM.PURSUE:
        return

    _replenish_scan_counter += 1
    if _replenish_scan_counter % 15 != 0:
        return

    for _uid in WSData.team_node_info:
        var _node = WSData.team_node_info[_uid]
        if not is_instance_valid(_node) or _node == self:
            continue
        if _node.is_queued_for_deletion():
            continue
        if _node.is_player:
            continue
        var _rel: int = TeamUtils.get_team_rel_value(self, _node)
        if _rel >= 0:
            continue
        var _dist: float = global_position.distance_to(_node.global_position)
        if _dist <= 80:

            set_move_target_node(_node)
            change_status_to_pursue()
            return




var _combat_follow_scan_counter: int = 0

func _combat_follow_scan_enemies()-> void:
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    if _behavior_data.get("appointed_state", "") != "COMBAT_FOLLOW":
        return
    if get_status() == MWTeamConstants.MW_TEAM_ACTION_STATUS_ENUM.ATTACK:
        return

    if move_type == MWTeamConstants.MOVE_TYPE_ENUM.PURSUE:
        return

    _combat_follow_scan_counter += 1
    if _combat_follow_scan_counter % 15 != 0:
        return

    for _uid in WSData.team_node_info:
        var _node = WSData.team_node_info[_uid]
        if not is_instance_valid(_node) or _node == self:
            continue
        if _node.is_queued_for_deletion():
            continue
        if _node.is_player:
            continue
        var _rel: int = TeamUtils.get_team_rel_value(self, _node)
        if _rel >= 0:

            if not(_behavior_data.get("can_attack_garrison", false) and _node._is_village_garrison()):
                continue
        var _dist: float = global_position.distance_to(_node.global_position)
        if _dist <= 80:

            set_move_target_node(_node)
            change_status_to_pursue()
            return


func handle_mw_team_node_collision(_meet_mw_team_node: MWTeam)-> void:

    if get_leader_uid() == "minor_hero_0012":
        return

    if get_leader_uid() == "mod_slave_duel_host":
        return
    var _behavior_data: Dictionary = json.get("behavior_data",{})

    var _is_combat_mode: bool = _behavior_data.get("patrol_radius", 0) > 0 or _behavior_data.get("appointed_state", "") == "COMBAT_FOLLOW"
    if _is_combat_mode and not self.is_player and not _meet_mw_team_node.is_player:
        var _rel_value: int = TeamUtils.get_team_rel_value(self, _meet_mw_team_node)
        if _rel_value >= 0:

            if not(_behavior_data.get("can_attack_garrison", false) and _meet_mw_team_node._is_village_garrison()):
                return

        var _my_power: float = float(get_combat_power())
        var _enemy_power: float = float(_meet_mw_team_node.get_combat_power())
        if _my_power > _enemy_power * 1.2:

            json["_pending_loot_enemy_team"] = _meet_mw_team_node.json.team.duplicate(true)
            TeamUtils.join_battle(self, _meet_mw_team_node)
        else:

            change_status_to_flee()
        return
    super.handle_mw_team_node_collision(_meet_mw_team_node)


const NUN_CITY_A: = "MWCity0001"
const NUN_CITY_B: = "MWCity0003"

func _nun_thinking_action()-> void:
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    var _current_target: String = _behavior_data.get("nun_current_target", "")
    if _current_target == "":
        _current_target = NUN_CITY_A
        _behavior_data["nun_current_target"] = _current_target
    move_to_location(_current_target, true, false)

func _nun_switch_target()-> void:
    var _behavior_data: Dictionary = json.get("behavior_data",{})
    var _current_target: String = _behavior_data.get("nun_current_target", NUN_CITY_A)
    if _current_target == NUN_CITY_A:
        _behavior_data["nun_current_target"] = NUN_CITY_B
    else:
        _behavior_data["nun_current_target"] = NUN_CITY_A