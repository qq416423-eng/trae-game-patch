class_name MoraleBox extends Control

@onready var value_node =$Shape / Value
@onready var color_node =$Shape / Color
@onready var up_arrow_node =$Shape / ArrowRoot / UpArrow
@onready var down_arrow_node =$Shape / ArrowRoot / DownArrow
@onready var arrow_animation_player_node =$Shape / ArrowRoot / ArrowAnimationPlayer
@onready var arrow_root_node =$Shape / ArrowRoot
@onready var hero_up_down_animation_node = preload("res://tscn/game/soldier/HeroUpDownAnimation.tscn")
@onready var hero_up_down_animation_root_node =$Shape / HeroUpDownAnimationRoot
@onready var animated_sprite_2d_node =$Shape / AnimatedSprite2D

@export var start_color: Color = CommonConstants.COLOR_ENUM.DARK
@export var end_color: Color = CommonConstants.COLOR_ENUM.RED
@export var end_value: int = 100
@export var fire_start_value: int = 80
@export var is_right: bool = false

var value: = 0.0
var current_value: = 0.0
var counter: = 0
var up_or_down: = 0
var up_or_down_animation_is_stop: = true

const counter_interval: = 4

func _ready():
    CommonUtils.update_self_color(up_arrow_node, end_color)
    CommonUtils.update_self_color(down_arrow_node, start_color)
    if is_right:
        arrow_root_node.position += Vector2(62, 0)

func _physics_process(delta):
    counter += 1
    if counter % counter_interval == 0:
        if int(current_value) == int(value):
            up_or_down = 0
        elif current_value > value:
            current_value -= 1
            up_or_down = -1
            _update_value_node()
        else:
            current_value += 1
            up_or_down = 1
            _update_value_node()

        if up_or_down != 0 and up_or_down_animation_is_stop:
            arrow_animation_player_node.play("show")

func clear():
    counter = 0
    value = 0
    current_value = 0

func set_value(_value: float)-> void:
    value = _value
    current_value = _value
    _update_value_node()

func plus_value(_plus_value: float, _is_show_hero_up_down_animation: = false)-> void:

    value = min(value + _plus_value, TeamConfig.MORALE_MAX)
    if _is_show_hero_up_down_animation:
        _add_hero_up_or_dowm_animation(_plus_value > 0)

func stop():
    set_physics_process(false)

func _add_hero_up_or_dowm_animation(_is_up: bool):
    var _node = hero_up_down_animation_node.instantiate() as HeroUpDownAnimation
    hero_up_down_animation_root_node.add_child(_node)
    if _is_up:
        _node.play_up()
    else:
        _node.play_down()

func _start_show_arrow():
    up_arrow_node.hide()
    down_arrow_node.hide()

    if up_or_down > 0:
        up_arrow_node.show()
    elif up_or_down < 0:
        down_arrow_node.show()

    up_or_down_animation_is_stop = false

func _end_show_arrow():
    up_or_down_animation_is_stop = true

func _update_value_node():
    CommonUtils.set_text(value_node, int(current_value))

    var _update_color: = start_color
    if int(current_value) >= end_value:
        _update_color = end_color
    else:
        var _ratio = current_value / end_value
        _update_color = Color(
            start_color.r +(end_color.r - start_color.r) * _ratio,
            start_color.g +(end_color.g - start_color.g) * _ratio,
            start_color.b +(end_color.b - start_color.b) * _ratio,
            1
        )

    CommonUtils.update_color(color_node, _update_color)

    var fire_a = 0.0
    if current_value > fire_start_value:
        fire_a =(current_value - fire_start_value) * 0.03

    CommonUtils.update_color_a(animated_sprite_2d_node, fire_a)