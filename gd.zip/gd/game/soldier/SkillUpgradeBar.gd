class_name SkillUpgradeBar extends TextureProgressBar

@onready var current_level_value_node =$CurrentLevelValue
@onready var next_level_value_node =$NextLevelValue
@onready var progress_value_node =$ProgressValue
@onready var max_level_effect_node: TextureRect =$MaxLevelEffect

func init(_level: int, _exp: int, _exp_max: int):
    CommonUtils.set_text(current_level_value_node, "LV " + str(_level))
    CommonUtils.set_text(next_level_value_node, "LV " + str(_level + 1))
    var _progress_percent = _exp * 100 / _exp_max
    self.value = _progress_percent
    CommonUtils.set_text(progress_value_node, str(_progress_percent) + "%")

func show_or_hide_max_effect(_is_show: bool)-> void:
    if _is_show:
        max_level_effect_node.show()
    else:
        max_level_effect_node.hide()