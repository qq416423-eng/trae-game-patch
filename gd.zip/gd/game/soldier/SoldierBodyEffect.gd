class_name SoldierBodyEffect extends AnimatedSprite2D

var effect_name_enum = null

func animation_play(_effect_name_enum: String):
    effect_name_enum = _effect_name_enum

    match _effect_name_enum:
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.HURT:
            _effect_name_enum += str(CommonUtils.random_num(1))
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.BOW_HURT:
            _effect_name_enum += str(CommonUtils.random_num(1))
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DIE_BLOOD:
            _effect_name_enum += str(CommonUtils.random_num(2))
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.WALK_RAISE_DUST:
            _effect_name_enum += str(CommonUtils.random_num(1))
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.INFANTRY_SPLASH_EFFECT:
            _effect_name_enum += str(CommonUtils.random_num(1))
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.CAVALRY_SPLASH_EFFECT:
            _effect_name_enum += str(CommonUtils.random_num(1))
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.ARROW_SPLASH_EFFECT:
            _effect_name_enum += str(CommonUtils.random_num(1))

    self.play(_effect_name_enum)

func _on_animation_finished():
    match effect_name_enum:
        BSSoldierConstants.SOLDIER_BODY_EFFECT_NAME_ENUM.DIE_BLOOD:
            return


    self.queue_free()
