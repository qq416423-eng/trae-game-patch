class_name StatusMachineRoot extends Node

var current_status_machine_node: StatusMachineBase
var status_machine_node_dic = {}

func _ready():
    stop()
    await owner.ready

    for _status_machine_node: StatusMachineBase in get_children():
        status_machine_node_dic[_status_machine_node.get_action_status()] = _status_machine_node

func _physics_process(_delta):
    current_status_machine_node.action()

func stop()-> void:
    set_physics_process(false)

func start()-> void:
    set_physics_process(true)

func get_action_status():
    return current_status_machine_node.get_action_status()

func get_save_data()-> Dictionary:
    return {
        "status": get_action_status()
    }

func change_status(_action_status: int, callable: Callable = Callable())-> void:
    if current_status_machine_node != null:




        var _success = current_status_machine_node.exit_status(_action_status)
        if not _success:
            return

    current_status_machine_node = status_machine_node_dic.get(_action_status)
    current_status_machine_node.enter_status()
    current_status_machine_node.set_callable(callable)

func load_init_status(_action_status: int)-> void:
    current_status_machine_node = status_machine_node_dic.get(_action_status)
    current_status_machine_node.load_init_status()

func get_action_status_str()-> String:
    return current_status_machine_node.get_action_status_str()