extends Line2D
class_name TargetLine

@onready var animation_player_node =$AnimationPlayer

var target_global_point: Vector2

func _ready():
    stop()

func _physics_process(_delta):





    self.points[1] = target_global_point - self.global_position

func start(_target_global_point: Vector2, _line_color: Color = CommonConstants.COLOR_ENUM.WHITE):
    target_global_point = _target_global_point
    self.set_physics_process(true)
    animation_player_node.seek(0)
    animation_player_node.play("start")
    self.points[1] = target_global_point - self.global_position

    self.self_modulate = _line_color

    self.show()

func stop():
    self.set_physics_process(false)
    self.hide()