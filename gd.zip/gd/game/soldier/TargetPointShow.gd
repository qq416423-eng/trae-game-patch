extends Node2D
class_name TargetPointShow

@onready var target_point_node = preload("res://tscn/game/soldier/TargetPoint.tscn")
@onready var point_root_node =$PointRoot
@onready var animation_player_node =$AnimationPlayer
@onready var formation_direction_node =$FormationDirection



var start_position: Vector2
var node_list: = []
var direction_vector: = Vector2.RIGHT

func _ready():
    self.set_physics_process(false)

func _physics_process(_delta):
    self.rotation =(owner.get_mouse_position() - start_position).angle()

func init(_position_list, _target_point, _color: Color = CommonConstants.COLOR_ENUM.WHITE):
    self.rotation = 0
    self.set_physics_process(false)
    animation_player_node.seek(0)
    formation_direction_node.hide()
    _init_point(_position_list, _target_point, _color)

    animation_player_node.play("show")
    self.show()


func set_formation_direction(_node_list, _start_position):
    node_list = _node_list
    self.show()
    formation_direction_node.show()
    point_root_node.show()

    animation_player_node.seek(0)
    animation_player_node.stop()

    start_position = _start_position

    var _position_list = SoldierUtils.soldier_formation2(_node_list, _start_position, Vector2.RIGHT)
    _init_point(_position_list, _start_position, CommonConstants.COLOR_ENUM.WHITE)

    self.set_physics_process(true)


func get_formation_position_list():
    direction_vector = owner.get_mouse_position() - start_position

    var _position_list = SoldierUtils.soldier_formation2(
        node_list, start_position,
        direction_vector)

    node_list = []

    disappear()
    return _position_list

func point_root_show():
    point_root_node.show()




func disappear()-> void:
    animation_player_node.play("arrow_disappear")
    self.set_physics_process(false)
    point_root_node.hide()

func chide():
    CommonUtils.update_color(formation_direction_node, Color(1, 1, 1, 1))
    self.hide()


func get_direction_enum():
    var _vector = owner.get_mouse_position() - start_position
    if _vector.x >= 0:
        return CommonConstants.DIRECTION_ENUM.RIGHT
    else:
        return CommonConstants.DIRECTION_ENUM.LEFT

func get_refer_point()-> Vector2:
    return start_position

func get_direction_vector()-> Vector2:
    return direction_vector

func _init_point(_position_list, _target_point, _color: Color = CommonConstants.COLOR_ENUM.WHITE):
    CommonUtils.clear_node(point_root_node)

    self.global_position = _target_point

    for _point in _position_list:
        var target_point_instance = target_point_node.instantiate()
        point_root_node.add_child(target_point_instance)
        target_point_instance.position = _point - _target_point
        CommonUtils.update_color(target_point_instance, _color)