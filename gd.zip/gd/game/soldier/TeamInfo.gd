class_name TeamInfo

var json
var is_player: bool = false


var team_name = ""

var leader_name = "leader_name"
var leader_json: = {}


var count: = 0

var hurt_nop: = 0

var total: = 0

var cavalry_count: = 0

var infantry_count: = 0


var cavalry_count_include_injury: = 0

var infantry_count_include_injury: = 0


var combat_power: = 0

var combat_power_hp_ratio: = 0

var team_atk: = 0

var hp_percent: = 0

var money: = 0

var cavalry_remote_count: = 0

var cavalry_melee_count: = 0

var infantry_remote_count: = 0

var infantry_melee_count: = 0

var surrender_count: = 0

var capture_count: = 0


var speed_day_night_mult: = 1.0

var speed_terrain_mult: = 1.0

var origin_speed: = 0.0

var speed: = 0.0

var speed_base: = 0.0

var speed_morale_effect: = 0.0

var speed_terrain_effect: = 0.0

var speed_inventory_horse_effect: = 0.0

var speed_inventory_cart_effect: = 0.0

var speed_night_effect = 0.0

var speed_skill_motility_effect: = 0.0

var speed_nop_effect: = 0.0

var inventory_horse_power: = 0

var inventory_carriage_count: = 0

var inventory_weight: = 0.0

var carrying_capacity_list = []

var carrying_capacity: = 0

var speed_inventory_weight_effect_ratio: = 0.0

var real_speed_inventory_weight_effect_ratio: = 0.0

var walk_acceleration = TeamConfig.WALK_ACCELERATION



var skill_medical: = 0

var skill_operation: = 0

var skill_investigation: = 0

var skill_motility: = 0

var skill_manage: = 0

var skill_trade: = 0

var skill_plunder: = 0

var skill_engineer: = 0

var skill_train: = 0

var skill_charisma: = 0

var skill_special_methodical: = 0




var food_morale_staple_1: = 0.0

var food_morale_staple_2: = 0.0

var food_morale_staple_3: = 0.0

var food_morale_accompaniment_1: = 0.0

var food_morale_accompaniment_2: = 0.0

var food_morale_accompaniment_3: = 0.0

var food_variety_morale: = 0.0

var team_morale: = 0.0

var current_morale: = 0.0

var base_morale: = 0.0

var tired_morale: = 0.0

var food_consume_type = FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS

var food_stock_value: int = 0

var soldier_simple_info_list: Array = []



var nop_limit: = 0

func refresh():
    _init(json, is_player)

func refresh_nop_info2()-> void:
    refresh_nop_info(json.team)

func refresh_nop_info(_simple_json_list: Array)-> void:
    var _info_json: = TeamUtils.get_team_info(_simple_json_list)

    leader_name = _info_json.leader_name
    count = _info_json.nop
    cavalry_count = _info_json.cavalry_nop
    infantry_count = _info_json.infantry_nop


    cavalry_count_include_injury = _info_json.cavalry_count_include_injury
    infantry_count_include_injury = _info_json.infantry_count_include_injury

    hp_percent = _info_json.hp_percent
    hurt_nop = _info_json.hurt_nop
    total = _info_json.nop + _info_json.hurt_nop
    cavalry_remote_count = _info_json.cavalry_remote_count
    cavalry_melee_count = _info_json.cavalry_melee_count
    infantry_remote_count = _info_json.infantry_remote_count
    infantry_melee_count = _info_json.infantry_melee_count
    soldier_simple_info_list = _info_json.soldier_simple_info_list
    combat_power = _info_json.combat_power
    combat_power_hp_ratio = _info_json.combat_power_hp_ratio
    team_atk = _info_json.team_atk
    leader_json = _info_json.leader_json


func _init(_json, _is_player: = false):
    json = _json
    is_player = _is_player



    refresh_nop_info2()


    team_name = SoldierUtils.get_nickname(leader_json)
    if _json.has("team_name"):
        team_name = _json.team_name

    money = CommonUtils.get_value(_json, "money", 0)



    var _active_hero_prop_list: Array = TeamUtils.list_active_hero_prop(_json.team)
    var _active_include_injury_hero_prop_list2: Array = TeamUtils.list_active_hero_prop(_json.team, false)

    var _mod_weights: Array = []
    if _json.has("assigned_heroes") and _json.assigned_heroes.size() > 0:
        _mod_weights = MWConfig.MOD_APPOINTED_TEAM_SKILL_WEIGHTS
    skill_medical = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_medical", _mod_weights)

    skill_investigation = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_investigation", _mod_weights)
    skill_motility = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_motility", _mod_weights)


    skill_manage = TeamUtils.get_team_skill_level_by_prop_list(_active_include_injury_hero_prop_list2, "skill_manage", _mod_weights)

    skill_operation = TeamUtils.get_team_skill_level_by_prop_list(_active_include_injury_hero_prop_list2, "skill_operation", _mod_weights)

    skill_trade = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_trade", _mod_weights)
    skill_plunder = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_plunder", _mod_weights)
    skill_engineer = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_engineer", _mod_weights)
    skill_train = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_train", _mod_weights)
    skill_charisma = TeamUtils.get_team_skill_level_by_prop_list(_active_hero_prop_list, "skill_charisma", _mod_weights)
    skill_special_methodical = TeamUtils.get_team_skill_level_sum_by_prop_list(_active_hero_prop_list, "skill_special_methodical")

    if _is_player:
        surrender_count = WSData.get_surrender_count()
        capture_count = WSData.get_capture_count()


    _handle_morale(_json)


    if not GlobalNode.mworld_scene.is_day:
        update_speed_day_night_mult(MWConfig.SPEED_NIGHT_RATIO)

    _handle_speed()

    if is_player:
        _refresh_nop_limit()

func get_food_staple_morale():
    match food_consume_type:
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS:
            return food_morale_staple_1
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.COMMON:
            return food_morale_staple_2
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.LUXURIOUS:
            return food_morale_staple_3

func get_food_accompaniment_morale():
    match food_consume_type:
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS:
            return food_morale_accompaniment_1
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.COMMON:
            return food_morale_accompaniment_2
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.LUXURIOUS:
            return food_morale_accompaniment_3

func get_food_morale(_food_consume_type: String):
    match _food_consume_type:
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.FRUGALNESS:
            return food_morale_staple_1 + food_morale_accompaniment_1
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.COMMON:
            return food_morale_staple_2 + food_morale_accompaniment_2
        FoodConstants.FOOD_CONSUME_TYPE_ENUM.LUXURIOUS:
            return food_morale_staple_3 + food_morale_accompaniment_3

func refresh_morale():
    _handle_morale(json)


func get_npc_food_consume_day()-> float:
    return total * FoodConfig.NPC_FOOD_CONSUME_FACTOR



func npc_food_consume(_mult: float):
    json.food_stock_value -= _mult * get_npc_food_consume_day()
    if json.food_stock_value < 0:
        json.food_stock_value = 0

    _handle_morale(json)

    return json.food_stock_value

func npc_food_plus(_value):
    json.food_stock_value += _value
    _handle_morale(json)


func get_food_surplus_days():
    return int(json.food_stock_value / get_npc_food_consume_day())

func update_speed_day_night_mult(_mult: float)-> void:


    speed_day_night_mult = _mult
    speed_night_effect =(speed_day_night_mult - 1) * origin_speed

    _refresh_speed_field()

func _refresh_speed_field():
    speed = max(10, origin_speed + speed_terrain_effect + speed_night_effect - origin_speed * real_speed_inventory_weight_effect_ratio)

func update_speed_terrain_mult(_mult: float)-> void:


    speed_terrain_mult = _mult
    speed_terrain_effect =(speed_terrain_mult - 1) * origin_speed

    _refresh_speed_field()

func get_speed()-> int:

    return speed

func _refresh_nop_limit()-> void:
    nop_limit = TeamConfig.PLAYER_BASE_NOP_LIMIT + skill_manage * SkillConfig.MANAGE_SKILL_EFFECT_NOP_LIMIT \
    + min(WSData.get_player_reputation_value_int() / 20, 60)



func _handle_morale(_json):
    if is_player:
        var _food_morale_info: Dictionary = FoodUtils.get_food_morale_info(_json.goods)
        food_morale_staple_1 = _food_morale_info.get("food_morale_staple_1")
        food_morale_staple_2 = _food_morale_info.get("food_morale_staple_2")
        food_morale_staple_3 = _food_morale_info.get("food_morale_staple_3")
        food_morale_accompaniment_1 = _food_morale_info.get("food_morale_accompaniment_1")
        food_morale_accompaniment_2 = _food_morale_info.get("food_morale_accompaniment_2")
        food_morale_accompaniment_3 = _food_morale_info.get("food_morale_accompaniment_3")
        food_stock_value = _food_morale_info.get("food_stock_value")
        food_variety_morale = _food_morale_info.get("food_variety_morale")
    else:

        if _json.has("food_stock_value"):
            food_stock_value = _json.food_stock_value

    if json.has("food_consume_type"):
        food_consume_type = json.food_consume_type

    team_morale = TeamUtils.get_team_morale(skill_manage, total)


    tired_morale = 0

    var _current_food_morale = 0
    if json.has("current_food_morale"):

        _current_food_morale = json.current_food_morale

        if team_morale < TeamConfig.NPC_BASE_MORALE:
            team_morale = TeamConfig.NPC_BASE_MORALE
    else:
        _current_food_morale = get_food_morale(food_consume_type)


    if food_stock_value > 0:
        base_morale = \
        team_morale + tired_morale \
        + _current_food_morale + food_variety_morale \
        + SkillUtils.get_skill_special_methodical_effect_morale(skill_special_methodical)
    else:
        base_morale = 0

    if base_morale < 0:
        base_morale = 0

    if json.has("morale"):
        current_morale = json.morale
    else:
        json.morale = base_morale
        current_morale = base_morale


func _handle_speed():
    var _defalut_cavalry_speed = TeamConfig.DEFALUT_CAVALRY_SPEED
    var _defalut_infantry_speed = TeamConfig.DEFALUT_INFANTRY_SPEED


    if is_player:
        _handle_inventory_data()
    else:
        _defalut_cavalry_speed = TeamConfig.DEFALUT_NPC_CAVALRY_SPEED
        _defalut_infantry_speed = TeamConfig.DEFALUT_NPC_INFANTRY_SPEED


    var _team_skill_motility = skill_motility

    var _total_unit_count = total + capture_count
    if _total_unit_count <= 0:
        return





    var _cavalry_speed_count = cavalry_count_include_injury

    var _infantry_speed_count = infantry_count_include_injury + capture_count


    var _real_use_inventory_horse_power = inventory_horse_power
    if _real_use_inventory_horse_power > _infantry_speed_count:
        _real_use_inventory_horse_power = _infantry_speed_count

    _cavalry_speed_count += _real_use_inventory_horse_power
    _infantry_speed_count -= _real_use_inventory_horse_power


    var _temp_speed_base: float = \
    (cavalry_count_include_injury * _defalut_cavalry_speed * 1.0 + infantry_count_include_injury * _defalut_infantry_speed) / _total_unit_count

    speed_base = \
    (_cavalry_speed_count * _defalut_cavalry_speed * 1.0 + _infantry_speed_count * _defalut_infantry_speed) / _total_unit_count

    speed_inventory_horse_effect = speed_base - _temp_speed_base


    speed_nop_effect = - min(_total_unit_count * SkillConfig.UNIT_COUNT_SPEED_RATIO, 0.5) * speed_base
    speed_base += speed_nop_effect


    if is_player:
        speed_skill_motility_effect = speed_base * _team_skill_motility * SkillConfig.SKILL_MOTILITY_SPEED_RATIO
    else:
        speed_skill_motility_effect = speed_base * _team_skill_motility * SkillConfig.SKILL_MOTILITY_NPC_SPEED_RATIO


    var _morale_plus_speed_ratio: float = TeamUtils.get_morale_plus_speed_ratio(current_morale)
    speed_morale_effect = speed_base * _morale_plus_speed_ratio

    if is_player and GameConfig.DEBUG_CONFIG_PLAYER_SPEED_MAX:
        walk_acceleration = 150
        speed_base = 150

    origin_speed = speed_base + speed_skill_motility_effect + speed_morale_effect

    speed_terrain_effect =(speed_terrain_mult - 1) * origin_speed
    speed_night_effect =(speed_day_night_mult - 1) * origin_speed

    _refresh_speed_field()

func get_day_night_terrain_rel_speed_mult()-> float:
    return speed_day_night_mult + speed_terrain_mult - 1


func _handle_inventory_data():
    var _inventory_horse_power: = 0
    var _weight: = 0.0

    var carrying_capacity_list = []
    for _simple_json: Dictionary in json.goods:
        var _json = GoodsUtils.get_json_by_uid(_simple_json.item.uid)
        if[WeaponTypeConstants.STYPE_ENUM.HORSE, WeaponTypeConstants.STYPE_ENUM.CARRIAGE].has(WeaponTypeConstants.get_stype(_simple_json.item.uid)):

            if CommonUtils.get_value(_simple_json.item, "quality", WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON) \
            < WeaponTypeConstants.EQUIPMENT_QUALITY_ENUM.COMMON:
                continue

            _inventory_horse_power += _json.horse_power * _simple_json.count
            if _json.has("carrying_capacity"):
                carrying_capacity_list.append({
                    "carrying_capacity": _json.carrying_capacity * _simple_json.count,
                    "speed_reduction": _json.speed_reduction,
                })
        else:
            _weight += _json.weight * _simple_json.count



    carrying_capacity = 0
    for _carrying_capacity_json: Dictionary in carrying_capacity_list:
        carrying_capacity += _carrying_capacity_json.carrying_capacity

    carrying_capacity_list.sort_custom(SortUtils.speed_reduction_sort)
    var _temp_weight = _weight
    var _real_speed_inventory_weight_effect: = 0.0
    for _carrying_capacity_json: Dictionary in carrying_capacity_list:
        var _use_weight = min(_carrying_capacity_json.carrying_capacity, _temp_weight)
        _real_speed_inventory_weight_effect += 0.01 * _use_weight * TeamConfig.CARRYING_CAPACITY_SPEED_FACTOR * _carrying_capacity_json.speed_reduction
        _temp_weight -= _carrying_capacity_json.carrying_capacity
        if _temp_weight <= 0:
            break

    if _temp_weight > 0:
        _real_speed_inventory_weight_effect += 0.01 * _temp_weight * TeamConfig.CARRYING_CAPACITY_SPEED_FACTOR

    speed_inventory_weight_effect_ratio = _weight * TeamConfig.CARRYING_CAPACITY_SPEED_FACTOR * 0.01
    real_speed_inventory_weight_effect_ratio = _real_speed_inventory_weight_effect


    inventory_horse_power = _inventory_horse_power
    inventory_weight = _weight