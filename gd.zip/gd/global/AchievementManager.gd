extends CanvasLayer


const ACHIEVEMENTS = [
    {"code": "first_victory", "name": "初战告捷", "desc": "赢得第一场战斗", "category": 0, "hidden": false},
    {"code": "hundred_battles", "name": "百战之将", "desc": "累计赢得50场战斗", "category": 0, "hidden": false},
    {"code": "lord_slayer", "name": "擒贼擒王", "desc": "击败5名领主", "category": 0, "hidden": false},
    {"code": "first_fief", "name": "初露锋芒", "desc": "拥有首个领地", "category": 1, "hidden": false},
    {"code": "warlord", "name": "割据一方", "desc": "同时拥有5处领地", "category": 1, "hidden": false},
    {"code": "rich_man", "name": "富甲一方", "desc": "累计获得10000德里", "category": 1, "hidden": false},
    {"code": "join_kingdom", "name": "投明之主", "desc": "加入一个王国", "category": 2, "hidden": false},
    {"code": "five_heroes", "name": "桃李满门", "desc": "招募5名英雄", "category": 2, "hidden": false},
    {"code": "max_relation", "name": "一见如故", "desc": "与某位英雄好感达到100", "category": 2, "hidden": false},
    {"code": "popular", "name": "人见人爱", "desc": "与3名英雄好感达到85以上", "category": 2, "hidden": false},
    {"code": "first_city", "name": "初出茅庐", "desc": "首次访问城市", "category": 3, "hidden": false},
    {"code": "all_cities", "name": "走遍天下", "desc": "访问全部城市", "category": 3, "hidden": false},
    {"code": "veteran", "name": "久经沙场", "desc": "游戏存活100天", "category": 4, "hidden": false},
    {"code": "lu_bu", "name": "吾乃吕布", "desc": "加入势力后退出, 再击败原势力的领主", "category": 2, "hidden": false},
    {"code": "dice_god", "name": "赌神附体", "desc": "骰子赌局连胜3局", "category": 4, "hidden": true},
]

const CATEGORY_NAMES = {
    0: "战斗",
    1: "经济",
    2: "社交",
    3: "探索",
    4: "旅途",
}

const CATEGORY_LABELS = {
    0: "[战]",
    1: "[经]",
    2: "[社]",
    3: "[探]",
    4: "[旅]",
}

const CATEGORY_COLORS = {
    0: Color(0.9, 0.35, 0.35, 1.0),
    1: Color(0.3, 0.78, 0.42, 1.0),
    2: Color(0.35, 0.62, 0.92, 1.0),
    3: Color(0.75, 0.45, 0.9, 1.0),
    4: Color(0.92, 0.68, 0.28, 1.0),
}


var _ui_root: Control
var _achievement_button: Button
var _achievement_interface: Control = null
var _notice_script = null


var _notice_queue: Array = []
var _current_notice: Control = null
var _is_showing: bool = false


const BUTTON_X = 8.0
const BUTTON_Y = 48.0
const BUTTON_W = 80.0
const BUTTON_H = 24.0


func _ready()-> void:
    layer = 100

    _ui_root = Control.new()
    _ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
    _ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_ui_root)

    _create_button()


    var _iface_script = load("res://gd/game/interface/AchievementInterface.gd")
    if _iface_script != null:
        _achievement_interface = _iface_script.new()
        _ui_root.add_child(_achievement_interface)
        _achievement_interface.setup(self)
    else:
        push_warning("[Achievement] AchievementInterface 加载失败")


    _notice_script = load("res://gd/util/AchievementNotice.gd")
    if _notice_script != null:
        _current_notice = _notice_script.new()
        _ui_root.add_child(_current_notice)
    else:
        push_warning("[Achievement] AchievementNotice 加载失败")


func _process(_delta: float)-> void:
    if _is_showing:
        if _current_notice != null and _current_notice.has_method("is_idle"):
            if _current_notice.is_idle():
                _is_showing = false
    elif not _notice_queue.is_empty():
        if _current_notice != null and _current_notice.has_method("show_notice"):
            var _ach = _notice_queue.pop_front()
            _current_notice.show_notice(_ach)
            _is_showing = true




func _create_button()-> void:
    _achievement_button = Button.new()
    _achievement_button.text = "成就"
    _achievement_button.position = Vector2(BUTTON_X, BUTTON_Y)
    _achievement_button.size = Vector2(BUTTON_W, BUTTON_H)
    _achievement_button.add_theme_font_size_override("font_size", 14)
    _achievement_button.tooltip_text = "点击查看成就"

    var sb: = StyleBoxFlat.new()
    sb.bg_color = Color(0.1, 0.1, 0.15, 0.88)
    sb.border_color = Color(0.5, 0.42, 0.2, 0.7)
    sb.border_width_left = 1
    sb.border_width_right = 1
    sb.border_width_top = 1
    sb.border_width_bottom = 1
    sb.corner_radius_top_left = 4
    sb.corner_radius_top_right = 4
    sb.corner_radius_bottom_left = 4
    sb.corner_radius_bottom_right = 4
    sb.content_margin_left = 8
    sb.content_margin_right = 8
    sb.content_margin_top = 2
    sb.content_margin_bottom = 2
    _achievement_button.add_theme_stylebox_override("normal", sb)

    var sb2: = StyleBoxFlat.new()
    sb2.bg_color = Color(0.15, 0.13, 0.08, 0.95)
    sb2.border_color = Color(0.85, 0.7, 0.3, 1.0)
    sb2.border_width_left = 1
    sb2.border_width_right = 1
    sb2.border_width_top = 1
    sb2.border_width_bottom = 1
    sb2.corner_radius_top_left = 4
    sb2.corner_radius_top_right = 4
    sb2.corner_radius_bottom_left = 4
    sb2.corner_radius_bottom_right = 4
    sb2.content_margin_left = 8
    sb2.content_margin_right = 8
    sb2.content_margin_top = 2
    sb2.content_margin_bottom = 2
    _achievement_button.add_theme_stylebox_override("hover", sb2)

    _achievement_button.pressed.connect(_on_button_pressed)
    _ui_root.add_child(_achievement_button)


func _on_button_pressed()-> void:
    if _achievement_interface == null:
        return
    if _achievement_interface.visible:
        _achievement_interface.hide()
    else:
        _achievement_interface.show()
        if _achievement_interface.has_method("refresh_display"):
            _achievement_interface.refresh_display()




func get_all_achievements()-> Array:
    return ACHIEVEMENTS


func get_category_name(_cat: int)-> String:
    return CATEGORY_NAMES.get(_cat, "未知")


func get_category_label(_cat: int)-> String:
    return CATEGORY_LABELS.get(_cat, "[-]")


func get_category_color(_cat: int)-> Color:
    return CATEGORY_COLORS.get(_cat, Color(0.85, 0.7, 0.3, 1.0))


func is_unlocked(_code: String)-> bool:
    var _data = WSData.achievement_meta_data
    if not _data.has("ach_unlocked"):
        return false
    return _data["ach_unlocked"].has(_code)


func get_unlocked_count()-> int:
    var _data = WSData.achievement_meta_data
    if not _data.has("ach_unlocked"):
        return 0
    return _data["ach_unlocked"].size()


func unlock(_code: String)-> void:
    var _data = WSData.achievement_meta_data
    if not _data.has("ach_unlocked"):
        _data["ach_unlocked"] = {}
    if not _data["ach_unlocked"].has(_code):
        _data["ach_unlocked"][_code] = true

        for _ach in ACHIEVEMENTS:
            if _ach["code"] == _code:
                _notice_queue.append(_ach)
                break




func check_achievements()-> void:
    if WSData.player_data.is_empty():
        return

    var _data = WSData.achievement_meta_data



    var _money = int(WSData.get_player_money())
    if _money >= 10000:
        unlock("rich_man")


    var _player_hero = SoldierUtils.get_player_hero_json()
    var _fief_list = SoldierUtils.get_owned_location_code_list(SoldierUtils.get_player_hero_uid())
    var _fief_count = _fief_list.size()
    if _fief_count >= 1:
        unlock("first_fief")
    if _fief_count >= 5:
        unlock("warlord")



    if WSData.player_data.has("team"):
        var _hero_count = 0
        for _member in WSData.player_data["team"]:
            if _member is Dictionary and _member.has("uid"):
                var _uid = _member["uid"]
                if _uid.begins_with("hero_") or _uid.begins_with("lord_") or _uid.begins_with("minor_hero_"):
                    _hero_count += 1
        if _hero_count >= 5:
            unlock("five_heroes")


    var _country = _player_hero.get("belong_country", "")
    if _country != "PLAYER_FACTION" and _country != "":
        unlock("join_kingdom")


    _check_relation_achievements()



    var _battle_wins = _data.get("battle_win_count", 0)
    if int(_battle_wins) >= 1:
        unlock("first_victory")
    if int(_battle_wins) >= 50:
        unlock("hundred_battles")


    var _lord_kills = int(_data.get("lord_kill_count", 0))
    if _lord_kills < 5:

        _lord_kills = max(_lord_kills, WSData.defeated_lord_data.size())
    if _lord_kills >= 5:
        unlock("lord_slayer")



    var _visited = _data.get("visited_cities",{})
    if _visited is Dictionary:
        if _visited.size() >= 1:
            unlock("first_city")

        var _all_cities = WSLocationData.get_city_code_list()
        if _all_cities.size() > 0 and _visited.size() >= _all_cities.size():
            unlock("all_cities")
    elif _visited is Array:
        if _visited.size() >= 1:
            unlock("first_city")
        var _all_cities = WSLocationData.get_city_code_list()
        if _all_cities.size() > 0 and _visited.size() >= _all_cities.size():
            unlock("all_cities")



    var _days = int(WSData.system_counter / 100.0)
    if _days >= 100:
        unlock("veteran")



    if _data.has("ach_unlocked") and _data["ach_unlocked"].has("lu_bu"):
        pass



func _check_relation_achievements()-> void:
    var _player_uid = SoldierUtils.get_player_hero_uid()
    var _rel_data = WSData.hero_relation_value_data

    if not _rel_data.has(_player_uid):
        return

    var _max_rel = 0
    var _count_85 = 0

    for _hero_uid in _rel_data[_player_uid]:
        var _rel_entry = _rel_data[_player_uid][_hero_uid]
        if _rel_entry is Dictionary and _rel_entry.has("relation_value"):
            var _rel_val = int(_rel_entry["relation_value"])
            if _rel_val > _max_rel:
                _max_rel = _rel_val
            if _rel_val >= 85:
                _count_85 += 1


    if _max_rel >= 100:
        unlock("max_relation")


    if _count_85 >= 3:
        unlock("popular")