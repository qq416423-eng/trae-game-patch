extends Node

signal change_zoom_sign(_zoom: Vector2)

func _ready():


    if OS.has_feature("android"):

        GameConfig.PLATFORM = CommonConstants.PLATFORM_ENUM.MOBILE


    var _version: String = ProjectSettings.get("application/config/version")
    if _version.ends_with("_s"):
        GameConfig.is_sponsor_edition = true
    if _version.ends_with("_mes"):
        GameConfig.need_manage_external_storage_edition = true




    UnitTreeConstants.repair_unit_tree_data()
    WSData.clear_data()
    GlobalSoldierInfo.reset_hero_dic()
    NpcTeamConfig.init()


func mw_update_zoom(_zoom: Vector2):

    change_zoom_sign.emit(_zoom)