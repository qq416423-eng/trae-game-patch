extends Node


var bs_part_dic = {

}

func _ready():
























    for _part_gd_stript in SoldierPartUtils.get_all_part_gd():
        _handle_json(_part_gd_stript.get_data())


    BSHairData.init_hair_data()
    BSBodyData.init_body_data()

func _handle_json(_json_dic: Dictionary):
    for _key in _json_dic.keys():
        var _json: Dictionary = _json_dic.get(_key).duplicate(true)
        _json.uid = _key
        bs_part_dic[_key] = _json


        if _json.has("unit_price") and not _json.has("price"):
            _json.price = int(_json.unit_price * _json.consumption_total)