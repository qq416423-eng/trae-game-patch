extends Node



var country_data: = {}



var country_rel_data: = {}



var country_diplomacy_records: = []



var country_record: = {



}


const INIT_COUNTRY_REL_DATA: = {
    WSCountryData.COUNTRY_NAME_ENUM.LUCIANA: {
        WSCountryData.COUNTRY_NAME_ENUM.EDRAS: {
            "rel_value": -10,
            "start_time": 0,
        },
    },
    WSCountryData.COUNTRY_NAME_ENUM.EDRAS: {
        WSCountryData.COUNTRY_NAME_ENUM.LUCIANA: {
            "rel_value": -10,
            "start_time": 0,
        },
    },
    WSCountryData.COUNTRY_NAME_ENUM.DORDAR: {
        WSCountryData.COUNTRY_NAME_ENUM.HASKAL: {
            "rel_value": -10,
            "start_time": 0,
        },
    },
    WSCountryData.COUNTRY_NAME_ENUM.HASKAL: {
        WSCountryData.COUNTRY_NAME_ENUM.DORDAR: {
            "rel_value": -10,
            "start_time": 0,
        },
    },

    WSCountryData.COUNTRY_NAME_ENUM.BLACK_FANG: {
        WSCountryData.COUNTRY_NAME_ENUM.LUCIANA: {
            "rel_value": -50,
            "start_time": 0,
        },
        WSCountryData.COUNTRY_NAME_ENUM.EDRAS: {
            "rel_value": -50,
            "start_time": 0,
        },
        WSCountryData.COUNTRY_NAME_ENUM.DORDAR: {
            "rel_value": -50,
            "start_time": 0,
        },
        WSCountryData.COUNTRY_NAME_ENUM.HASKAL: {
            "rel_value": -50,
            "start_time": 0,
        },
    },
}

func _ready()-> void:
    reset()

func handle_country_data()-> void:
    country_data = {}

    for _country_name_enum: String in WSCountryData.COUNTRY_NAME_ENUM.values():
        country_data[_country_name_enum] = {

            "city_castle_code_list": [],

            "location_code_list": [],
            "frontline_own_city_castle_code_list": [],
            "frontline_enemy_city_castle_code_list": [],
            "king_hero_uid": "",

            "neighbor_country_code_list": [],
        }

    for _location_code: String in WSLocationData.city_data.keys():
        var _location_data: Dictionary = WSLocationData.city_data.get(_location_code)

        if not _location_data.has("belong_country"):
            continue

        country_data.get(_location_data.belong_country).location_code_list.append(_location_code)

        if not[LocationConstants.LOCATION_TYPE_ENUM.CITY, LocationConstants.LOCATION_TYPE_ENUM.CASTLE] \
        .has(_location_data.type):
            continue

        country_data.get(_location_data.belong_country).city_castle_code_list.append(_location_code)


    _refresh_country_frontline_data()


    for _hero_json: Dictionary in GlobalSoldierInfo.hero_dic.values():

        if SoldierUtils.is_king(_hero_json):
            country_data.get(_hero_json.belong_country).king_hero_uid = _hero_json.uid


func get_country_rel_value_by_location_code(_location_code: String, _belong_country: String)-> int:
    var _belong_country1: String = LocationUtils.get_belong_country(_location_code)
    return get_country_rel_value_by_country_code(_belong_country1, _belong_country)

func get_country_rel_value_by_country_code(_belong_country1: String, _belong_country2: String)-> int:
    if _belong_country1 == _belong_country2:
        return 100

    if country_rel_data.has(_belong_country1) and country_rel_data.get(_belong_country1).has(_belong_country2):
        return country_rel_data.get(_belong_country1).get(_belong_country2).rel_value

    return 0


func get_country_location_code_list(_belong_country: String)-> Array:
    return country_data.get(_belong_country).location_code_list

func get_king_uid_by_country_code(_country_code: String)-> String:
    if not country_data.has(_country_code):
        return ""
    return country_data.get(_country_code).king_hero_uid

func get_save_data()-> Dictionary:
    return {
        "country_rel_data": country_rel_data,
        "country_record": country_record,
        "country_diplomacy_records": country_diplomacy_records,
    }

func load_save_data(_country_data: Dictionary)-> void:
    country_rel_data = CommonUtils.get_value(
        _country_data, "country_rel_data", INIT_COUNTRY_REL_DATA.duplicate(true)
    )

    country_diplomacy_records = CommonUtils.get_value(
        _country_data, "country_diplomacy_records",[]
    )


    if country_rel_data.is_empty():
        country_rel_data = INIT_COUNTRY_REL_DATA.duplicate(true)


    _maybe_repair_old_country_rel_data(country_rel_data)

    country_record = CommonUtils.get_value(
        _country_data, "country_record",{}
    )

func reset()-> void:
    country_rel_data = INIT_COUNTRY_REL_DATA.duplicate(true)
    country_data = {}
    country_record = {}
    country_diplomacy_records = []


func record_player_leave_country_counter(_country_code: String)-> void:
    if not country_record.has(_country_code):
        country_record[_country_code] = {}

    country_record[_country_code].player_last_leave_country_counter = WSData.get_system_counter()


func get_player_leave_country_counter(_country_code: String)-> float:
    if not country_record.has(_country_code):
        return -1.0

    return CommonUtils.get_value(country_record.get(_country_code), "player_last_leave_country_counter", -1.0)


func handle_toggle_war_status()-> void:
    for _country_code: String in WSCountryData.COUNTRY_NAME_ENUM.values():

        if[
            WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION,
            WSCountryData.COUNTRY_NAME_ENUM.NONE,
            WSCountryData.COUNTRY_NAME_ENUM.BLACK_FANG,
        ].has(_country_code):
            continue



        var _temp_country_war_data: Dictionary = {}


        var _country_lord_warlike_score: int = CountryUtils.get_country_lord_warlike_score(_country_code)

        if country_rel_data.has(_country_code):
            var _item_country_data: Dictionary = country_rel_data.get(_country_code)
            for _target_country_code: String in _item_country_data.keys():


                if[
                    WSCountryData.COUNTRY_NAME_ENUM.NONE,
                    WSCountryData.COUNTRY_NAME_ENUM.BLACK_FANG,
                ].has(_target_country_code):
                    continue

                var _target_country_data: Dictionary = _item_country_data.get(_target_country_code)
                if _target_country_data.rel_value < 0:
                    _temp_country_war_data[_target_country_code] = _target_country_data


        var _has_action: = false



        for _index: int in range(_temp_country_war_data.keys().size() - 1, -1, -1):
            var _target_country_code: String = _temp_country_war_data.keys()[_index]

            var _target_country_data: Dictionary = _temp_country_war_data.get(_target_country_code)


            var _change_to_peace_prob: float = _get_change_to_peace_prob(
                _target_country_data,
                _temp_country_war_data.size(),
                _country_lord_warlike_score
            )

            if CommonUtils.prob_true(_change_to_peace_prob):
                handle_country_change_to_peace(_country_code, _target_country_code)
                _temp_country_war_data.erase(_target_country_code)

                _has_action = true
                break

        if _has_action:

            continue


        if not _temp_country_war_data.is_empty():

            continue

        for _target_country_code: String in WSCountryData.COUNTRY_NAME_ENUM.values():
            if[
                    WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION,
                    WSCountryData.COUNTRY_NAME_ENUM.NONE,
                    WSCountryData.COUNTRY_NAME_ENUM.BLACK_FANG,
                ].has(_target_country_code):
                    continue

            var _change_to_war_prob: float = _get_change_to_war_prob(
                _country_code,
                _target_country_code,

                _country_lord_warlike_score
            )
            if CommonUtils.prob_true(_change_to_war_prob):
                handle_country_change_to_war(_country_code, _target_country_code)

                break

    if GlobalMessageInterface.maybe_show_important_message_box():
        GlobalNode.mworld_scene.stop_and_hide_module()

func country_diplomacy_records_append(
    _origin_country_code: String, _target_country_code: String, _update_rel_value: int
)-> void:
    country_diplomacy_records.append({
        "origin_country_code": _origin_country_code,
        "target_country_code": _target_country_code,
        "system_counter": WSData.get_system_counter(),
        "rel_value": _update_rel_value,
    })

    while country_diplomacy_records.size() > CountryConfig.COUNTRY_DIPLOMACY_RECORDS_LIMIT:
        country_diplomacy_records.pop_front()

func get_target_country_rel_data(_origin_country_code: String, _target_country_code: String)-> Dictionary:
    if country_rel_data.has(_origin_country_code) and country_rel_data.get(_origin_country_code).has(_target_country_code):
        return country_rel_data.get(_origin_country_code).get(_target_country_code)

    return {
        "rel_value": 0,
        "start_time": 0
    }


func handle_country_change_to_peace(
    _origin_country_code: String, _target_country_code: String
)-> void:

    if StringUtils.equals(_origin_country_code, _target_country_code):
        return

    if get_country_rel_value_by_country_code(_origin_country_code, _target_country_code) >= 0:
        return
    _update_country_relation_to_peace(_origin_country_code, _target_country_code)

    _refresh_country_frontline_data()


    var _player_country_code: String = SoldierUtils.get_player_belong_country()
    if StringUtils.equals(_origin_country_code, _player_country_code) or \
    StringUtils.equals(_target_country_code, _player_country_code):
        GlobalMessageInterface.add_important_message(
            ImportantMessageData.MESSAGE_TYPE_ENUM.COUNTRY_CHANGE_TO_PEACE,
            [
                CountryUtils.get_country_name_by_country_code(_origin_country_code),
                CountryUtils.get_country_name_by_country_code(_target_country_code)
            ]
        )



    GlobalMessageInterface.add_country_peace_message(_origin_country_code, _target_country_code)


    BattleUtils.handle_country_change_to_peace_abort_active_lord_combat(_origin_country_code, _target_country_code)

func handle_country_change_to_war(_origin_country_code: String, _target_country_code: String)-> void:


    if StringUtils.equals(_origin_country_code, _target_country_code):
        return

    if StringUtils.is_empty(_origin_country_code) or StringUtils.is_empty(_target_country_code):
        return

    if get_country_rel_value_by_country_code(_origin_country_code, _target_country_code) < 0:
        return
    _update_country_relation_to_hostile(_origin_country_code, _target_country_code)

    _refresh_country_frontline_data()


    var _player_country_code: String = SoldierUtils.get_player_belong_country()
    if StringUtils.equals(_origin_country_code, _player_country_code) or \
    StringUtils.equals(_target_country_code, _player_country_code):
        GlobalMessageInterface.add_important_message(
            ImportantMessageData.MESSAGE_TYPE_ENUM.COUNTRY_CHANGE_TO_WAR,
            [
                CountryUtils.get_country_name_by_country_code(_origin_country_code),
                CountryUtils.get_country_name_by_country_code(_target_country_code)
            ]
        )



    GlobalMessageInterface.add_country_war_message(_origin_country_code, _target_country_code)

func _refresh_country_frontline_data()-> void:


    for _country_code in WSCountryData.COUNTRY_NAME_ENUM.values():
        if country_data.has(_country_code):
            country_data.get(_country_code).frontline_own_city_castle_code_list = []
            country_data.get(_country_code).frontline_enemy_city_castle_code_list = []
            country_data.get(_country_code).neighbor_country_code_list = []

    for _location_code: String in WSLocationData.city_data.keys():
        var _location_data: Dictionary = WSLocationData.city_data.get(_location_code)

        if not _location_data.has("belong_country"):
            continue

        if not[LocationConstants.LOCATION_TYPE_ENUM.CITY, LocationConstants.LOCATION_TYPE_ENUM.CASTLE] \
        .has(_location_data.type):
            continue


        var _adjacent_city_castle_code_list: Array = GlobalLocationData.get_adjacent_city_castle_code_list(_location_code)
        for _adjacent_city_castle_code: String in _adjacent_city_castle_code_list:
            var _adjacent_location_belong_country_code: String = LocationUtils.get_belong_country(_adjacent_city_castle_code)
            if StringUtils.equals(_adjacent_location_belong_country_code, _location_data.belong_country):
                continue

            country_data.get(_location_data.belong_country).neighbor_country_code_list.append(
                _adjacent_location_belong_country_code
            )

            var _rel_value: int = get_country_rel_value_by_location_code(_adjacent_city_castle_code, _location_data.belong_country)

            if _rel_value < 0:
                country_data.get(_location_data.belong_country).frontline_own_city_castle_code_list.append(_location_code)
                country_data.get(_location_data.belong_country).frontline_enemy_city_castle_code_list.append(_adjacent_city_castle_code)


        country_data.get(_location_data.belong_country).frontline_own_city_castle_code_list = \
        ArrayUtils.distinct(country_data.get(_location_data.belong_country).frontline_own_city_castle_code_list)
        country_data.get(_location_data.belong_country).frontline_enemy_city_castle_code_list = \
        ArrayUtils.distinct(country_data.get(_location_data.belong_country).frontline_enemy_city_castle_code_list)
        country_data.get(_location_data.belong_country).neighbor_country_code_list = \
        ArrayUtils.distinct(country_data.get(_location_data.belong_country).neighbor_country_code_list)




func _get_change_to_peace_prob(
        _target_country_data: Dictionary,
        _hostile_country_count: int,

        country_lord_warlike_score: int,
    )-> float:
    if _target_country_data.rel_value >= 0:

        return 0.0



    if WSData.system_counter - _target_country_data.start_time < CountryConfig.WAR_DURATION_RANGE[0]:
        return 0.0

    if WSData.system_counter - _target_country_data.start_time > CountryConfig.WAR_DURATION_RANGE[1]:
        return 1.0

    return(1.0 * _hostile_country_count *(1 - country_lord_warlike_score * 1.0 / CountryConfig.COUNTRY_LORD_WARLIKE_SCORE_BASELINE)) \
    /(CountryConfig.WAR_DURATION_RANGE[1] - CountryConfig.WAR_DURATION_RANGE[0])


func _get_change_to_war_prob(
    _origin_country_code: String,
    _target_country_code: String,

    country_lord_warlike_score: int,
)-> float:
    if StringUtils.equals(_origin_country_code, _target_country_code):
        return 0.0

    var _target_country_data: = get_target_country_rel_data(_origin_country_code, _target_country_code)

    if _target_country_data.rel_value < 0:

        return 0.0



    if WSData.system_counter - _target_country_data.start_time < CountryConfig.PEACE_DURATION_RANGE[0]:
        return 0.0


    if not country_data.get(_origin_country_code).neighbor_country_code_list.has(_target_country_code):
        return 0.0

    return 1.0 *(1 + country_lord_warlike_score * 1.0 / CountryConfig.COUNTRY_LORD_WARLIKE_SCORE_BASELINE) \
    /(CountryConfig.PEACE_DURATION_RANGE[1] - CountryConfig.PEACE_DURATION_RANGE[0])

func _maybe_repair_old_country_rel_data(_country_rel_data: Dictionary)-> void:
    for _value: Dictionary in _country_rel_data.values():
        for _maybe_rel_value in _value.values():
            if not _maybe_rel_value is Dictionary:

                break
            else:

                return


    var _new_country_rel_data: Dictionary = {}
    for _country_code1: String in _country_rel_data.keys():
        _new_country_rel_data[_country_code1] = {}
        for _country_code2: String in _country_rel_data.get(_country_code1).keys():
            _new_country_rel_data[_country_code1][_country_code2] = {
                "rel_value": _country_rel_data[_country_code1][_country_code2],
                "start_time": WSData.system_counter
            }

    country_rel_data = _new_country_rel_data

func _update_country_relation_to_hostile(_country_code1: String, _country_code2: String)-> void:
        var _update_rel_value: = -10
        _update_country_relation_value(_country_code1, _country_code2, _update_rel_value, true)
        country_diplomacy_records_append(
                _country_code1, _country_code2, _update_rel_value
        )

func _update_country_relation_to_peace(_country_code1: String, _country_code2: String)-> void:
        var _update_rel_value: = 0
        _update_country_relation_value(_country_code1, _country_code2, _update_rel_value, true)
        country_diplomacy_records_append(
                _country_code1, _country_code2, _update_rel_value
        )

func _update_country_relation_value(
    _country_code1: String, _country_code2: String,
    _value: int,

    _is_sync_update: bool
)-> void:
    if not country_rel_data.has(_country_code1):
        country_rel_data[_country_code1] = {}

    if not country_rel_data[_country_code1].has(_country_code2):
        country_rel_data[_country_code1][_country_code2] = {
            "rel_value": 0,
            "start_time": 0,
        }

    country_rel_data[_country_code1][_country_code2].rel_value = _value
    country_rel_data[_country_code1][_country_code2].start_time = WSData.get_system_counter()

    if _is_sync_update:
        _update_country_relation_value(_country_code2, _country_code1, _value, false)


func update_country_relation_value(
    _country_code1: String, _country_code2: String,
    _value: int,

    _is_sync_update: bool
)-> void:
    _update_country_relation_value(_country_code1, _country_code2, _value, _is_sync_update)