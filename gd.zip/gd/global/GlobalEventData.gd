extends Node




var enter_location_event = {}







var init_event_load_record = {}


const INIT_EVENT = [
    "MW_SPECIAL_LOCATION_0001_ENTER"
]

func init()-> void:
    for _event_code: String in INIT_EVENT:
        if init_event_load_record.has(_event_code):

            continue

        var _event_data: Dictionary = EventData.get_event(_event_code)

        match _event_data.trigger_type:
            EventBase.TRIGGER_TYPE_ENUM.ENTER_LOCATION:
                _add_active_event(enter_location_event, _event_data.location_code, _event_code)


func reset()-> void:
    _clear()
    init()

func load_save_data(_data: Dictionary)-> void:
    _clear()

    if _data.is_empty():
        pass
    else:
        enter_location_event = _data.enter_location_event
        init_event_load_record = _data.init_event_load_record

    init()

func get_save_data()-> Dictionary:
    return {
        "enter_location_event": enter_location_event,
        "init_event_load_record": init_event_load_record,
    }

func remove_active_event(_event_code: String)-> void:
    var _event_data: Dictionary = EventData.get_event(_event_code)
    match _event_data.trigger_type:
        EventBase.TRIGGER_TYPE_ENUM.ENTER_LOCATION:
            _remove_active_event(enter_location_event, _event_data.location_code, _event_code)

func _remove_active_event(
    _active_event_data: Dictionary, _key: String,
    _event_code: String
)-> void:
    if _active_event_data.has(_key):
        _active_event_data.get(_key).erase(_event_code)
        if ArrayUtils.is_empty(_active_event_data.get(_key)):
            _active_event_data.erase(_key)

func _clear()-> void:
    enter_location_event = {}
    init_event_load_record = {}



func _add_active_event(
    _active_event_data: Dictionary, _key: String,
    _event_code: String
)-> void:
    if _active_event_data.has(_key):
        pass
    else:
        _active_event_data[_key] = {}




    _active_event_data[_key][_event_code] = {}

    init_event_load_record[_event_code] = {
        "is_load": true
    }