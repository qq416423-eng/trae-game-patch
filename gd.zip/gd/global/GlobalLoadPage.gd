extends CanvasLayer

@onready var hourglass_animation_player_node: AnimationPlayer =$Mask / HourglassRoot / HourglassAnimationPlayer
@onready var mask_node: Control =$Mask
@onready var animation_player_node: AnimationPlayer =$AnimationPlayer

func _ready()-> void:
    self.hide()

func load_open_ani()-> void:
    if self.visible:
        return

    mask_node.modulate.a = 0.0
    hourglass_animation_player_node.play("hourglass_roll")
    animation_player_node.play("show_ani")
    self.show()

func load_close_ani()-> void:
    animation_player_node.play("hide_ani")

func load_open()-> void:
    if self.visible:
        return

    mask_node.modulate.a = 1.0
    self.show()
    hourglass_animation_player_node.play("hourglass_roll")

func load_close()-> void:
    hourglass_animation_player_node.stop()
    self.hide()