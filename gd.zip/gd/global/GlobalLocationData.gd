extends Node

var city_node_dic = {

}













func get_location_node(_location_code: String)-> MWLocationBase:
    var _node = city_node_dic.get(_location_code)
    if _node and is_instance_valid(_node):
        return _node
    return null

func set_location_node(_location_code: String, _node: MWLocationBase):
    city_node_dic[_location_code] = _node


func get_location_point(_location_code: String)-> Vector2:
    var _node = city_node_dic.get(_location_code)
    if _node and is_instance_valid(_node):
        return _node.global_position
    return Vector2.ZERO


func get_nearest_location_code_by_location_code_list(
    _rel_position: Vector2, _location_code_list: Array
)-> String:
    var _result_code: String = ""
    var _temp_distance_square: = CommonConstants.INT_MAX
    for _location_code: String in _location_code_list:
        var _distance_square: = get_location_point(_location_code).distance_squared_to(_rel_position)
        if _distance_square < _temp_distance_square:
            _temp_distance_square = _distance_square
            _result_code = _location_code

    return _result_code

func get_nearest_location_code(
    _rel_position: Vector2,
    _belong_country: String,

    _location_type_list: Array
)-> String:

    var _location_code_list: Array = GlobalCountryData.get_country_location_code_list(_belong_country)

    var _candidate_locaton_code: = []
    for _location_code: String in _location_code_list:
        if not _location_type_list.has(WSLocationData.get_location_type(_location_code)):

            continue

        _candidate_locaton_code.append(_location_code)

    return get_nearest_location_code_by_location_code_list(
        _rel_position, _candidate_locaton_code
    )





func refresh_location_tag(_location_code: String)-> void:
    var _node = get_location_node(_location_code)
    if _node:
        _node.refresh_location_tag()


func show_player_avatar(_location_code: String)-> void:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if _location_node:
        _location_node.show_player_avatar()

func delete_player_avatar(_location_code: String)-> void:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if _location_node:
        _location_node.delete_player_avatar()

func get_gate_exit_point(_location_code: String, enter_point: Vector2)-> Vector2:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if not _location_node or ArrayUtils.is_empty(_location_node.nav_link_points):
        return Vector2.ZERO

    var _exit_point: = enter_point
    var _temp_distance_square: = 0.0
    for _point: Vector2 in _location_node.nav_link_points:
        var _distance: = _point.distance_squared_to(enter_point)
        if _distance > _temp_distance_square:
            _temp_distance_square = _distance
            _exit_point = _point

    return _exit_point

func get_random_entrance_position(_location_code: String)-> Vector2:
    var _node = get_location_node(_location_code)
    if _node:
        return _node.get_random_entrance_position()
    return Vector2.ZERO


func get_adjacent_city_castle_code_list(_location_code: String)-> Array[String]:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if _location_node:
        return _location_node.adjacent_nodes
    return[]

func handle_hero_team_enter_location(_location_code: String, _team_uid: String)-> void:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if _location_node:
        _location_node.handle_hero_team_enter_location(_team_uid)

func handle_hero_team_exit_location(_location_code: String, _team_uid: String)-> void:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if _location_node:
        _location_node.handle_hero_team_exit_location(_team_uid)

func maybe_refresh_nop_info(_location_code: String)-> void:
    var _location_node: MWLocationBase = get_location_node(_location_code)
    if _location_node:
        _location_node.maybe_refresh_nop_info()