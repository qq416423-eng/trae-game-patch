extends CanvasLayer

@onready var center_message_interface_node: CenterMessageInterface =$Control / CenterMessageInterface
@onready var message_box_node = preload("res://tscn/game/interface/other/MessageBox.tscn")
@onready var message_root_node =$Control / MessageRoot
@onready var fps_value_node: Label =$Control / FPSRoot / FPSValue
@onready var fps_root_node: Label =$Control / FPSRoot
@onready var confirm_box_node: ConfirmBox =$Control / ConfirmBox
@onready var remove_all_button_node: Button =$Control / MessageRoot / RemoveAllButton
@onready var remove_all_button_animation_player_node: AnimationPlayer =$Control / MessageRoot / RemoveAllButton / RemoveAllButtonAnimationPlayer
@onready var mask_node: Control =$Control / Mask
@onready var important_message_box_node: ImportantMessageBox =$Control / ImportantMessageBox

signal center_message_show_timeout()


var message_list = []
var current_message_info = {}
var counter: float = 0

var important_message_type_enum_dic_list: = []

signal important_message_box_close_sign()

func _ready()-> void:
    remove_all_button_node.modulate.a = 0.0
    remove_all_button_node.show()
    remove_all_button_node.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _physics_process(delta):
    if counter == 0 and message_list.size() > 0:

        var _message_info: Dictionary = message_list.pop_front()
        _show_message(_message_info)
        counter = 1

    if counter >= 1:

        counter += 1
        if counter > SystemConfig.MESSAGE_SHOW_INTERVAL:
            counter = 0



func show_center_message(_content, _seconds)-> void:
    mask_node.show()
    center_message_interface_node.show_center_message(_content, _seconds)

func hide_center_message()-> void:
    mask_node.hide()
    center_message_interface_node.chide()

func show_confirm_box(_content: String):
    confirm_box_node.update_content(_content)
    confirm_box_node.show()


func add_upgrade_soldier_message(_upgrade_num, _cost):
    add_message(
        MessageConstants.MESSAGE_ENUM.SOLDIER_UPGRADE_SUCCESS,
        [_upgrade_num, _cost])


func add_hero_upgrade_message(_hero_name, _level):
    add_message(
        MessageConstants.MESSAGE_ENUM.HERO_UPGRADE_SUCCESS,
        [_hero_name, _level])


func add_team_skill_operation_work_message(_skill_level, _total, _operation_nop):
    add_message(
        MessageConstants.MESSAGE_ENUM.TEAM_SKILL_OPERATION_WORK,
        [_skill_level, _total, _operation_nop])

func add_practise_upgrade_message(
    _hero_name: String, _practise_field: String,
    _old_practise_value: int, _new_practise_value: int):
    var _practise_field_name = SoldierUtils.get_practise_name(_practise_field)
    add_message(
        MessageConstants.MESSAGE_ENUM.PRACTISE_UPGRADE_MESSAGE,
        [_hero_name, _practise_field_name, _old_practise_value, _new_practise_value]
    )

func add_skill_upgrade_message(_hero_name: String, _skill_name: String, _old_level: int):
    var _skill_config = SkillUtils.get_skill_config(_skill_name)
    add_message(
        MessageConstants.MESSAGE_ENUM.SKILL_UPGRADE_MESSAGE,
        [_hero_name, _skill_config.name, _old_level, _old_level + 1]
    )

func add_message(_message_enum: Dictionary, _keyword_list: Array = []):
    var _content: String = _message_enum.content
    if ArrayUtils.is_not_empty(_keyword_list):
        _content = StringUtils.replace(_content, _keyword_list)

    var _message_info = {
        "content": _content,
        "message_type": _message_enum.type,
        "color": _message_enum.color
    }

    if counter > 0 and current_message_info == _message_info \
    or(message_list.size() > 1 and message_list[message_list.size() - 1] == _message_info):
        return

    message_list.append(_message_info)

func show_or_hide_fps(_is_show: bool)-> void:
    fps_root_node.show_or_hide(_is_show)

func add_lost_goods_message(_uid: String)-> void:
    var _goods_name: String = GoodsUtils.get_goods_name(_uid)
    add_message(
        MessageConstants.MESSAGE_ENUM.LOST_ONE_GOODS,
        [_goods_name]
    )

func add_add_goods_message(_uid: String)-> void:
    var _goods_name: String = GoodsUtils.get_goods_name(_uid)
    add_message(
        MessageConstants.MESSAGE_ENUM.ADD_ONE_GOODS,
        [_goods_name]
    )

func add_add_goods_message_by_name(_name: String)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.ADD_ONE_GOODS,
        [_name]
    )

func add_important_message(_message_type_enum: String, _replace_str_list: Array = [])-> void:
    important_message_type_enum_dic_list.append(
        {
            "type": _message_type_enum,
            "replace_str_list": _replace_str_list
        }
    )



func maybe_show_important_message_box()-> bool:
    if ArrayUtils.is_empty(important_message_type_enum_dic_list):
        return false

    var _message_type_enum_dic: Dictionary = important_message_type_enum_dic_list.pop_front()
    important_message_box_node.cshow()
    mask_node.show()
    important_message_box_node.init_by_message_type_enum_dic(_message_type_enum_dic)
    return true

func _show_message(_message_info: Dictionary):
    var message_box_instance = message_box_node.instantiate() as MessageBox
    message_root_node.add_child(message_box_instance)

    message_box_instance.connect("message_disappear_begin_sign", _handle_message_disappear)

    message_root_node.move_child(message_box_instance, 1)
    message_box_instance.init(_message_info)
    current_message_info = _message_info

    if not remove_all_button_node.modulate.a == 1.0:
        _remove_all_button_node_show()


func _handle_message_disappear()-> void:

    for _node in message_root_node.get_children():
        if not _node is MessageBox:
            continue

        if not _node.is_disappear:
            return


    _remove_all_button_node_disappear()

func _remove_all_button_node_show()-> void:
    remove_all_button_animation_player_node.stop()
    remove_all_button_node.modulate.a = 1.0
    remove_all_button_node.disabled = false
    remove_all_button_node.show()
    remove_all_button_node.mouse_filter = Control.MOUSE_FILTER_STOP

func _remove_all_button_node_disappear()-> void:
    remove_all_button_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
    remove_all_button_node.disabled = true
    remove_all_button_animation_player_node.play("disappear")

func _on_center_message_show_timeout():
    mask_node.hide()
    emit_signal("center_message_show_timeout")


func _on_remove_all_button_pressed()-> void:
    for _child_node in message_root_node.get_children():
        if _child_node is MessageBox:
            _child_node.disappear_and_no_sign()

    _remove_all_button_node_disappear()

func add_plus_reputation_value_message(
    _plus_reputation_value: float
)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.PLUS_REPUTATION_VALUE,
        [int(_plus_reputation_value), WSData.get_player_reputation_value_int()]
    )

func add_message_exceeded_troop_limit()-> void:
    add_message(MessageConstants.MESSAGE_ENUM.EXCEEDED_TROOP_LIMIT)

func add_message_join_kingdom(_country_code: String)-> void:
    var _country_name = CountryUtils.get_country_name_by_country_code(_country_code)
    add_message(MessageConstants.MESSAGE_ENUM.JOIN_KINGDOM,[_country_name])

func add_leave_country_message(_country_code: String)-> void:
    var _country_name = CountryUtils.get_country_name_by_country_code(_country_code)
    add_message(MessageConstants.MESSAGE_ENUM.LEAVE_COUNTRY,[_country_name])

func add_message_get_fief(_location_code: String)-> void:
    var _location_name = LocationUtils.get_location_name_by_location_code(_location_code)
    add_message(MessageConstants.MESSAGE_ENUM.GET_FIEF,[_location_name])


func add_message_capture_village(_location_code: String)-> void:
    var _location_name = LocationUtils.get_location_name_by_location_code(_location_code)
    add_message(MessageConstants.MESSAGE_ENUM.CAPTURE_VILLAGE,[_location_name])

func add_message_player_return_fief()-> void:
    add_message(MessageConstants.MESSAGE_ENUM.RETURN_FIEF)

func add_message_unlock_tree_unit(_unit_tree_code: String)-> void:
    var _unit_tree_name = SoldierUtils.get_unit_tree_name_by_code(_unit_tree_code)
    add_message(MessageConstants.MESSAGE_ENUM.UNLOCK_UNIT_TREE,[_unit_tree_name])

func add_message_lock_tree_unit(_unit_tree_code: String)-> void:
    var _unit_tree_name = SoldierUtils.get_unit_tree_name_by_code(_unit_tree_code)
    add_message(MessageConstants.MESSAGE_ENUM.LOCK_UNIT_TREE,[_unit_tree_name])

func add_message_pay_wage(_pay_value: int, _unpaid_wages: int)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.PAY_WAGES,
        [
            _pay_value, WSData.get_player_money(),
            "" if _unpaid_wages <= 0 else ", 欠款 " + str(_unpaid_wages) + " 德里"
        ]
    )


func add_settlement_income_message(_income: int)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.SETTLEMENT_INCOME,
        [_income]
    )


func add_location_relation_value_change_message(_location_name: String, _pre_value: int, _current_value: int)-> void:
    var _message_enum = MessageConstants.MESSAGE_ENUM.PLAYER_LOCATION_RELATION_VALUE_INCREASE
    if _current_value < _pre_value:
        _message_enum = MessageConstants.MESSAGE_ENUM.PLAYER_LOCATION_RELATION_VALUE_DECREASE

    add_message(
        _message_enum,[
            _location_name, _current_value - _pre_value,
            _pre_value, _current_value
        ]
    )


func add_hero_relation_value_change_message(_hero_uid: String, _pre_value: int, _current_value: int)-> void:
    var _message_enum = MessageConstants.MESSAGE_ENUM.PLAYER_NPC_RELATION_VALUE_INCREASE
    if _current_value < _pre_value:
        _message_enum = MessageConstants.MESSAGE_ENUM.PLAYER_NPC_RELATION_VALUE_DECREASE

    var _nickname: String = SoldierUtils.get_nickname_by_hero_uid(_hero_uid)

    add_message(
        _message_enum,[
            _nickname, _current_value - _pre_value,
            _pre_value, _current_value
        ]
    )


func add_player_morality_value_change_message(_pre_value: int, _current_value: int)-> void:
    var _message_enum = MessageConstants.MESSAGE_ENUM.PLAYER_NPC_MORALITY_VALUE_INCREASE
    if _current_value < _pre_value:
        _message_enum = MessageConstants.MESSAGE_ENUM.PLAYER_NPC_MORALITY_VALUE_DECREASE

    add_message(
        _message_enum,[
            _current_value - _pre_value,
            _pre_value,
            _current_value
        ]
    )

func add_message_player_become_hostile_to_country(_country_code: String)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.PLAYER_BECOME_HOSTILE_TO_COUNTRY,
        [CountryUtils.get_country_name_by_country_code(_country_code)]
    )

func add_capture_hero_message(_hero_uid: String)-> void:
    var _hero_name: = SoldierUtils.get_nickname_by_hero_uid(_hero_uid)
    add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURE_HERO,[_hero_name]
    )

func add_hero_flee_message(_hero_uid: String)-> void:
    var _hero_name: = SoldierUtils.get_nickname_by_hero_uid(_hero_uid)
    add_message(
        MessageConstants.MESSAGE_ENUM.HERO_FLEE,[_hero_name]
    )

func add_hero_released_message(_hero_uid: String)-> void:
    var _hero_name: = SoldierUtils.get_nickname_by_hero_uid(_hero_uid)
    add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURED_HERO_RELEASED,[_hero_name]
    )

func add_captured_hero_flee_message(_hero_uid: String)-> void:
    var _hero_name: = SoldierUtils.get_nickname_by_hero_uid(_hero_uid)
    add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURED_HERO_FLEE,[_hero_name]
    )

func add_captured_soldier_flee_message(_flee_count: int)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.CAPTURED_SOLDIER_FLEE,[_flee_count]
    )


func add_save_data_import_success(_save_name: String)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.SAVE_DATA_IMPORT_SUCCESS,
        [_save_name]
    )

func add_export_save_data_success_message(_save_data_dir_name: String)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.SAVE_DATA_EXPORT_SUCCESS,
        [_save_data_dir_name]
    )

func add_rename_save_name_success_message(_new_name: String)-> void:
    add_message(
        MessageConstants.MESSAGE_ENUM.RENAME_SAVE_NAME_SUCCESS,
        [_new_name]
    )

func _on_important_message_box_close_page_sign()-> void:

    var _flag: = maybe_show_important_message_box()
    if not _flag:
        mask_node.hide()
        important_message_box_close_sign.emit()

func add_country_peace_message(_origin_country_code: String, _target_country_code: String)-> void:
    var _origin_country_name: String = CountryUtils.get_country_name_by_country_code(_origin_country_code)
    var _target_country_name: String = CountryUtils.get_country_name_by_country_code(_target_country_code)
    add_message(
        MessageConstants.MESSAGE_ENUM.COUNTRY_PEACE,
        [_origin_country_name, _target_country_name]
    )

func add_country_war_message(_origin_country_code: String, _target_country_code: String)-> void:
    var _origin_country_name: String = CountryUtils.get_country_name_by_country_code(_origin_country_code)
    var _target_country_name: String = CountryUtils.get_country_name_by_country_code(_target_country_code)
    add_message(
        MessageConstants.MESSAGE_ENUM.COUNTRY_WAR,
        [_origin_country_name, _target_country_name]
    )






func add_robber_relation_value_change_message(
    _robber_code: String,
    _old_value: int,
    _new_value: int
)-> void:
    var _robber_name: String = NpcTeamConfig.get_npc_team_name_by_code(_robber_code)
    var _diff: int = _new_value - _old_value
    var _diff_text: String = "+%d" % _diff if _diff > 0 else "%d" % _diff

    var _relation_info: Dictionary = SoldierUtils.get_robber_relation_value_info(_new_value)

    add_message({
        "content": "%s对你的好感度%s，当前%s" % [_robber_name, _diff_text, _relation_info.label],
        "color": MessageConstants.MESSAGE_COLOR_ENUM.COMMON,
        "type": MessageConstants.MESSAGE_TYPE_ENUM.COMMON,
    })

func add_message_join_robber_faction(_robber_code: String)-> void:
    var _robber_name: String = NpcTeamConfig.get_npc_team_name_by_code(_robber_code)
    add_message({
        "content": "你加入了%s的盗贼团！现在你是匪团领主了！" % _robber_name,
        "color": MessageConstants.MESSAGE_COLOR_ENUM.IMPORTANT,
        "type": MessageConstants.MESSAGE_TYPE_ENUM.COMMON,
    })

func add_message_leave_robber_faction()-> void:
    add_message({
        "content": "你离开了盗贼团，你的身份恢复了。",
        "color": MessageConstants.MESSAGE_COLOR_ENUM.COMMON,
        "type": MessageConstants.MESSAGE_TYPE_ENUM.COMMON,
    })