extends Node





var spawn_trigger_power_value_data = {}



var npc_team_temp_data: Dictionary = {}



var lord_team_temp_data: Dictionary = {}



var _hero_uid_rel_team_code_data: Dictionary = {}

func _ready()-> void:
    _init_npc_team_temp_data_and_hero_uid_rel_team_code_data()
    _init_lord_team_temp_data_and_hero_uid_rel_team_code_data()

func _init_npc_team_temp_data_and_hero_uid_rel_team_code_data()-> void:
    npc_team_temp_data = {}
    for _npc_team_code: String in NpcTeamConfig.VILLAIN_BOSS_CONFIG.keys():
        var _hero_uid_list: Array = []
        for _soldier_or_hero_uid: String in NpcTeamConfig.VILLAIN_BOSS_CONFIG.get(_npc_team_code).team_config.keys():
            if SoldierUtils.is_hero_by_uid(_soldier_or_hero_uid):
                _hero_uid_list.append(_soldier_or_hero_uid)

                _hero_uid_rel_team_code_data[_soldier_or_hero_uid] = {
                    "is_lord": false,
                    "team_code": _npc_team_code,
                }

        npc_team_temp_data[_npc_team_code] = {
            "hero_uid_list": _hero_uid_list
        }

func _init_lord_team_temp_data_and_hero_uid_rel_team_code_data()-> void:
    lord_team_temp_data = {}
    for _lord_hero_uid: String in LordConfig.LORD_CONFIG.keys():
        var _hero_uid_list: Array = []

        for _soldier_or_hero_uid: String in LordConfig.LORD_CONFIG.get(_lord_hero_uid).team_config.keys():
            if SoldierUtils.is_hero_by_uid(_soldier_or_hero_uid):
                _hero_uid_list.append(_soldier_or_hero_uid)

                _hero_uid_rel_team_code_data[_soldier_or_hero_uid] = {
                    "is_lord": true,
                    "team_code": _lord_hero_uid,
                }

        lord_team_temp_data[_lord_hero_uid] = {
            "hero_uid_list": _hero_uid_list
        }

func reset()-> void:
    spawn_trigger_power_value_data = {}

func plus_power_value_by_time(_days: float)-> void:
    plus_power_value(NpcTeamConstants.TEAM_SMALL_TYPE_TIME, _days)

    check_villain_boss_force_spawn_daily()

func plus_power_value(_team_small_type: String, _die_nop_or_days: float)-> void:
    if StringUtils.is_empty(_team_small_type):
        return


    var _plus_power_value_plus_config_list: Array = NpcTeamConfig.get_plus_power_value_plus_config_list(_team_small_type)
    for _plus_power_value_plus_config: Dictionary in _plus_power_value_plus_config_list:
        var _npc_team_code: String = _plus_power_value_plus_config.npc_team_code
        if not spawn_trigger_power_value_data.has(_npc_team_code):
            spawn_trigger_power_value_data[_npc_team_code] = {
                "current_value": 0,
                "is_team_exist": false,
            }

        var _spawn_trigger_power_value_npc_team_code_data: Dictionary = spawn_trigger_power_value_data.get(_npc_team_code)
        if _spawn_trigger_power_value_npc_team_code_data.is_team_exist:

            continue


        if not CommonUtils.get_value(_spawn_trigger_power_value_npc_team_code_data, "is_revival_allowed", true):
            continue

        _spawn_trigger_power_value_npc_team_code_data.current_value += int(_die_nop_or_days * _plus_power_value_plus_config.power_value_pnop)
        if _spawn_trigger_power_value_npc_team_code_data.current_value >= NpcTeamConfig.get_spawn_trigger_power_value(_npc_team_code):

            var _success = GlobalNode.mworld_scene.generate_villain_boss_team(_npc_team_code)

            if _success:
                _spawn_trigger_power_value_npc_team_code_data.current_value = 0
                _spawn_trigger_power_value_npc_team_code_data.is_team_exist = true



func load_save_data(_data: Dictionary)-> void:
    reset()
    if _data.is_empty():
        return

    spawn_trigger_power_value_data = _data.spawn_trigger_power_value_data

func get_save_data()-> Dictionary:
    return {
        "spawn_trigger_power_value_data": spawn_trigger_power_value_data,
    }



func npc_team_die(_npc_team_code: String)-> void:
    spawn_trigger_power_value_data.get(_npc_team_code).is_team_exist = false

    spawn_trigger_power_value_data.get(_npc_team_code).is_revival_allowed = true

    spawn_trigger_power_value_data.get(_npc_team_code).hero_captured_data = {}


    spawn_trigger_power_value_data.get(_npc_team_code).death_days = int(WSData.get_system_counter())

    var _hero_uid_list: Array = _get_hero_uid_list_by_npc_team_code(_npc_team_code)
    for _hero_uid: String in _hero_uid_list:
        var _is_captured: bool = SoldierUtils.check_is_captured(_hero_uid)
        if _is_captured:

            if spawn_trigger_power_value_data.get(_npc_team_code).is_revival_allowed:
                spawn_trigger_power_value_data.get(_npc_team_code).is_revival_allowed = false

            spawn_trigger_power_value_data.get(_npc_team_code).hero_captured_data[_hero_uid] = _is_captured



func clear_npc_team_exist_flag(_npc_team_code: String)-> void:
    if spawn_trigger_power_value_data.has(_npc_team_code):
        spawn_trigger_power_value_data[_npc_team_code]["is_team_exist"] = false

func _get_hero_uid_list_by_npc_team_code(_npc_team_code: String)-> Array:
    return npc_team_temp_data.get(_npc_team_code).hero_uid_list

func get_hero_uid_list_by_lord_hero_uid(_lord_hero_uid: String)-> Array:
    return lord_team_temp_data.get(_lord_hero_uid).hero_uid_list

func get_hero_uid_rel_team_code_data(_hero_uid: String)-> Dictionary:
    return _hero_uid_rel_team_code_data.get(_hero_uid)



func check_imperial_union_army_spawn_condition()-> bool:

    if WSData.get_player_combat_power() < 1200:
        return false


    var _kingdom_list: Array = [
        WSCountryData.COUNTRY_NAME_ENUM.LUCIANA,
        WSCountryData.COUNTRY_NAME_ENUM.EDRAS,
        WSCountryData.COUNTRY_NAME_ENUM.DORDAR,
        WSCountryData.COUNTRY_NAME_ENUM.HASKAL,
    ]

    var _player_country: String = SoldierUtils.get_player_belong_country()

    if _kingdom_list.has(_player_country):
        return false




    var _faction_code_list: Array = [
        WSCountryData.COUNTRY_NAME_ENUM.NONE,
        WSCountryData.COUNTRY_NAME_ENUM.PLAYER_FACTION,
    ]
    if not _faction_code_list.has(_player_country):
        _faction_code_list.append(_player_country)

    for _kingdom_code: String in _kingdom_list:
        var _is_hostile: bool = false
        for _faction_code: String in _faction_code_list:
            var _rel_value: int = CountryUtils.get_country_rel_value_by_country_code(
                _faction_code, _kingdom_code
            )
            if _rel_value < 0:
                _is_hostile = true
                break
        if not _is_hostile:
            print_debug("[四国联军] 与 %s 未处于战争状态, 不刷新" % _kingdom_code)
            return false

    print_debug("[四国联军] 刷新条件满足: 战力%d, 与四国全部敌对" % WSData.get_player_combat_power())
    return true



func check_imperial_union_army_daily()-> void:
    var _imperial_union_codes: Array = [
        NpcTeamConstants.NPC_TEAM_CODE.IMPERIAL_UNION_ARMY_1,
        NpcTeamConstants.NPC_TEAM_CODE.IMPERIAL_UNION_ARMY_2,
    ]
    for _npc_team_code: String in _imperial_union_codes:
        if not spawn_trigger_power_value_data.has(_npc_team_code):
            spawn_trigger_power_value_data[_npc_team_code] = {
                "current_value": 0,
                "is_team_exist": false,
            }

        var _data: Dictionary = spawn_trigger_power_value_data.get(_npc_team_code)
        if _data.is_team_exist:

            if GlobalNode.mworld_scene == null or not is_instance_valid(GlobalNode.mworld_scene):
                continue
            if not GlobalNode.mworld_scene.is_npc_team_alive(_npc_team_code):
                print_debug("[四国联军] %s 标记存在但场上无队伍, 重置刷新状态" % _npc_team_code)
                _data.is_team_exist = false
                _data.current_value = 0
            else:
                continue

        if not CommonUtils.get_value(_data, "is_revival_allowed", true):
            continue


        if _data.has("death_days"):
            var _days_since_death: int = int(WSData.get_system_counter()) - _data.death_days
            if _days_since_death < 15:
                continue

        _data.current_value += 10
        if _data.current_value >= NpcTeamConfig.get_spawn_trigger_power_value(_npc_team_code):
            if check_imperial_union_army_spawn_condition():
                var _success = GlobalNode.mworld_scene.generate_imperial_union_army_team(_npc_team_code)
                if _success:
                    _data.current_value = 0
                    _data.is_team_exist = true



func check_villain_boss_force_spawn_daily()-> void:
    var _villain_boss_codes: Array = [
        NpcTeamConstants.NPC_TEAM_CODE.ROBBER_LEADER,
        NpcTeamConstants.NPC_TEAM_CODE.FOREST_BANDIT_LEADER,
        NpcTeamConstants.NPC_TEAM_CODE.PIRATE_LEADER,
        NpcTeamConstants.NPC_TEAM_CODE.STEPPE_BANDIT_BOSS,
        NpcTeamConstants.NPC_TEAM_CODE.DESERT_BANDIT_BOSS,

        NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT,
    ]
    var _current_day: int = int(WSData.get_system_counter())

    for _npc_team_code: String in _villain_boss_codes:
        if not spawn_trigger_power_value_data.has(_npc_team_code):
            continue

        var _data: Dictionary = spawn_trigger_power_value_data.get(_npc_team_code)

        if _data.is_team_exist:
            continue

        if not CommonUtils.get_value(_data, "is_revival_allowed", true):
            continue

        if not _data.has("death_days"):
            continue

        var _days_since_death: int = _current_day - _data.death_days




        var _force_spawn_days: int = 26
        if _npc_team_code == NpcTeamConstants.NPC_TEAM_CODE.CONQUEST_KNIGHT:
            _force_spawn_days = 10
        if _days_since_death >= _force_spawn_days:
            var _success = GlobalNode.mworld_scene.generate_villain_boss_team(_npc_team_code)
            if _success:
                _data.current_value = 0
                _data.is_team_exist = true