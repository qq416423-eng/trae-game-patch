extends Node



var is_auto_save: = true

var is_show_fps: = false

var is_show_button_tip: = true

var is_view_move_reversal: = false

var is_default_forced_move: = true

var is_show_time_control_button: = true
var is_show_move_mode_button: = true
var is_show_box_select_button: = true

var is_show_hero_helmet_in_battle_scene: = true

var is_auto_discard_expired_food: = false

var sfx_value: = 100

var bg_music_value: = 100

var is_show_damage_text: = true

var enable_pre_battle_deployment: = true

var enable_screen_rotation: = true

var battle_unit_limit_percent: float = 50

var battle_enable_chat_bubble: = true

func get_save_data()-> Dictionary:
    return {
        "is_auto_save": is_auto_save,
        "is_show_fps": is_show_fps,
        "is_show_button_tip": is_show_button_tip,
        "is_view_move_reversal": is_view_move_reversal,
        "is_default_forced_move": is_default_forced_move,
        "is_show_time_control_button": is_show_time_control_button,
        "is_show_move_mode_button": is_show_move_mode_button,
        "is_show_box_select_button": is_show_box_select_button,
        "is_show_hero_helmet_in_battle_scene": is_show_hero_helmet_in_battle_scene,
        "is_auto_discard_expired_food": is_auto_discard_expired_food,
        "sfx_value": sfx_value,
        "bg_music_value": bg_music_value,
        "is_show_damage_text": is_show_damage_text,
        "enable_pre_battle_deployment": enable_pre_battle_deployment,
        "enable_screen_rotation": enable_screen_rotation,
        "battle_unit_limit_percent": battle_unit_limit_percent,
        "battle_enable_chat_bubble": battle_enable_chat_bubble,
    }

func reload(_dic: Dictionary)-> void:
    for _field in _dic.keys():
        set(_field, _dic.get(_field))

    SystemUtils.set_sfx_volume(sfx_value, false)
    SystemUtils.set_bg_music_volume(bg_music_value)

    SystemUtils.enable_screen_rotation(enable_screen_rotation)

func update_config(_field: String, _value)-> void:
    set(_field, _value)

func get_battle_unit_limit()-> int:






    return BattleSceneUtils.get_battle_unit_limit(battle_unit_limit_percent)