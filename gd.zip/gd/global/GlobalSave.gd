extends Node


const SAVE_SUMMARY_DIC_FILE_PATH = "user://save/save_summary.dat"

const SAVE_PLAYER_CONFIG_FILE_PATH = "user://save/save_player_config.dat"

const CUSTOM_BATTLE_DATA_FILE_PATH = "user://save/custom_data.dat"


static var EXPORT_PATH_PREFIX: = OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)

const EXPORT_SAVE_DATA_DIR_NAME: = "Rodri"


var current_save_code: = ""


var save_summary_dic = {}

func _ready()-> void:

    init_save_summary_dic()

    reload_player_config()

func save_new()-> void:
    current_save_code = SystemUtils.generate_save_code()


    save()


func save(_send_message: = false, is_auto_save_message: = false)-> void:


    var _save_data: Dictionary = _get_save_data()
    var _file_path: String = _get_save_file_path(current_save_code)
    _save_to_file_by_path_atomic(_file_path, _save_data)

    var _save_summary: Dictionary = _get_save_summary()
    if save_summary_dic.has(current_save_code):
        var _origin_save_summary: Dictionary = save_summary_dic.get(current_save_code)
        _save_summary = CommonUtils.cover_json(_save_summary, _origin_save_summary)

    save_summary_dic[current_save_code] = _save_summary


    save_save_summary_dic()

    if _send_message:
        if is_auto_save_message:
            GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.AUTO_SAVE_GAME_SUCCESS)
        else:
            GlobalMessageInterface.add_message(MessageConstants.MESSAGE_ENUM.SAVE_GAME_SUCCESS)

func reload()-> void:
    cload(current_save_code)

func cload(_save_code: String)-> void:
    current_save_code = _save_code
    var _save_file_path: String = _get_save_path(_save_code)

    if _save_file_path.is_empty():
        printerr("GlobalSave.cload: save_path is empty for save_code = ", _save_code)
        return
    _load_by_save_path(_save_file_path)


func reload_player_config()-> void:
    var _config_data: Dictionary = {}
    var _file = FileAccess.open(SAVE_PLAYER_CONFIG_FILE_PATH, FileAccess.READ)
    if _file == null:

        _config_data = _try_recover_data(SAVE_PLAYER_CONFIG_FILE_PATH)
    else:
        var _raw_data = _file.get_var()
        if _raw_data is Dictionary:
            _config_data = _raw_data
        else:

            _config_data = _try_recover_data(SAVE_PLAYER_CONFIG_FILE_PATH)

    if not _config_data.is_empty():
        GlobalPlayerConfig.reload(_config_data)

    GlobalMessageInterface.show_or_hide_fps(GlobalPlayerConfig.is_show_fps)

func save_player_config()-> void:

    _save_to_file_by_path_atomic(SAVE_PLAYER_CONFIG_FILE_PATH, GlobalPlayerConfig.get_save_data())

func save_custom_battle_data(
    _left_simple_json_list: Array,
    _right_simple_json_list: Array,
    _map_key: String,
    _weather_key: String
)-> void:

    _save_to_file_by_path_atomic(
        CUSTOM_BATTLE_DATA_FILE_PATH,
        {
            "left_simple_json_list": _left_simple_json_list,
            "right_simple_json_list": _right_simple_json_list,

            "formation_config": WSData.formation_config,
            "group_icon_config": WSData.group_icon_config,
            "map_key": _map_key,
            "weather_key": _weather_key,
        }
    )

func load_custom_battle_data()-> void:
    var _data: Dictionary = {}

    var _file = FileAccess.open(CUSTOM_BATTLE_DATA_FILE_PATH, FileAccess.READ)
    if _file == null:

        _data = _try_recover_data(CUSTOM_BATTLE_DATA_FILE_PATH)
    else:

        var _raw_data = _file.get_var()
        if _raw_data is Dictionary:
            _data = _raw_data
        else:

            _data = _try_recover_data(CUSTOM_BATTLE_DATA_FILE_PATH)

    WSData.custom_battle_left_simple_json_list = CommonUtils.get_value(_data, "left_simple_json_list",[])
    WSData.custom_battle_right_simple_json_list = CommonUtils.get_value(_data, "right_simple_json_list",[])
    WSData.formation_config = CommonUtils.get_value(_data, "formation_config",{})
    WSData.group_icon_config = CommonUtils.get_value(_data, "group_icon_config", WSData.INIT_GROUP_ICON_CONFIG.duplicate(true))
    WSData.custom_battle_map_key = CommonUtils.get_value(_data, "map_key", "random")
    WSData.custom_battle_weather_key = CommonUtils.get_value(_data, "weather_key", "random")

func _get_save_path(_save_code: String)-> String:

    var _summary = save_summary_dic.get(_save_code)
    if _summary == null:
        return ""
    return _summary.get("save_path", "")

func _load_by_save_path(_save_file_path: String)-> void:
    _mod_save_log("load_save: START path=" + _save_file_path)
    var _save_data: = get_data_from_file(_save_file_path)
    _mod_save_log("load_save: file read done, empty=" + str(_save_data.is_empty()))


    if _save_data.is_empty():

        if FileAccess.file_exists(_save_file_path + ".tmp"):
            _save_data = get_data_from_file(_save_file_path + ".tmp")

        if _save_data.is_empty() and FileAccess.file_exists(_save_file_path + ".bak"):
            _save_data = get_data_from_file(_save_file_path + ".bak")

        if _save_data.is_empty():
            printerr("GlobalSave: 存档文件全部损坏且无备份可恢复: ", _save_file_path)
            OS.alert("存档文件损坏且无法恢复，请导出其他备份后联系开发者", "加载失败")
            return

    _mod_save_log("load_save: ws_data load START")
    WSData.load_save_data(CommonUtils.get_value(_save_data, "ws_data",{}))
    _mod_save_log("load_save: ws_data done, teams=" + str(WSData.other_team_data.size()))

    _mod_save_log("load_save: location_data load START")
    WSLocationData.load_save_data(CommonUtils.get_value(_save_data, "location_data",{}))
    _mod_save_log("load_save: location_data done, cities=" + str(WSLocationData.city_data.size()))

    _mod_save_log("load_save: hero_data load START")
    GlobalSoldierInfo.load_hero_data(CommonUtils.get_value(_save_data, "hero_data",{}))
    _mod_save_log("load_save: hero_data done, heroes=" + str(GlobalSoldierInfo.hero_dic.size()))

    _mod_save_log("load_save: init_owner_uid START")
    WSLocationData.init_owner_uid()
    _mod_save_log("load_save: init_owner_uid done")

    _mod_save_log("load_save: event_data load START")
    GlobalEventData.load_save_data(CommonUtils.get_value(_save_data, "event_data",{}))
    _mod_save_log("load_save: event_data done")

    _mod_save_log("load_save: npc_team_data load START")
    GlobalNpcTeamData.load_save_data(CommonUtils.get_value(_save_data, "special_npc_team_data",{}))
    _mod_save_log("load_save: npc_team_data done")

    _mod_save_log("load_save: country_data load START")
    GlobalCountryData.load_save_data(CommonUtils.get_value(_save_data, "country_data",{}))
    _mod_save_log("load_save: country_data done, ALL COMPLETE")

static var _mod_save_log_file: FileAccess = null
static func _mod_save_log(_msg: String)-> void:
    if _mod_save_log_file == null:
        _mod_save_log_file = FileAccess.open("user://mod_crash_log.txt", FileAccess.WRITE)
        if _mod_save_log_file == null:
            return
    _mod_save_log_file.store_line(str(Time.get_ticks_msec()) + " " + _msg)
    _mod_save_log_file.flush()
    print("[SaveMod] " + _msg)


func init_save_summary_dic():
    var _save_summary_dic = {}

    var _file = FileAccess.open(SAVE_SUMMARY_DIC_FILE_PATH, FileAccess.READ)
    if _file == null:

        _save_summary_dic = _try_recover_save_summary()
    else:
        var _data = _file.get_var()

        if _data is Dictionary:
            _save_summary_dic = _data
        else:

            _save_summary_dic = _try_recover_save_summary()

    save_summary_dic = _save_summary_dic


func _try_recover_save_summary()-> Dictionary:
    return _try_recover_data(SAVE_SUMMARY_DIC_FILE_PATH)


func _try_recover_data(_file_path: String)-> Dictionary:
    var _tmp_path = _file_path + ".tmp"
    var _bak_path = _file_path + ".bak"

    if FileAccess.file_exists(_tmp_path):
        var _tmp_file = FileAccess.open(_tmp_path, FileAccess.READ)
        if _tmp_file != null:
            var _tmp_data = _tmp_file.get_var()
            if _tmp_data is Dictionary:
                return _tmp_data

    if FileAccess.file_exists(_bak_path):
        var _bak_file = FileAccess.open(_bak_path, FileAccess.READ)
        if _bak_file != null:
            var _bak_data = _bak_file.get_var()
            if _bak_data is Dictionary:
                return _bak_data
    return {}

func save_save_summary_dic():

    _save_to_file_by_path_atomic(SAVE_SUMMARY_DIC_FILE_PATH, save_summary_dic)

func get_data_from_file(_save_file_path: String)-> Dictionary:
    var _file = FileAccess.open(_save_file_path, FileAccess.READ)

    if _file == null:
        return {}
    var _data = _file.get_var()
    if _data is Dictionary:
        return _data
    return {}

func delete(_save_code: String)-> void:
    if not save_summary_dic.has(_save_code):
        printerr("_save_code not exist, _save_code = ", _save_code)
        return


    var _sumary_json: Dictionary = save_summary_dic.get(_save_code)
    var _save_path: String = _sumary_json.get("save_path", "")
    if not _save_path.is_empty():
        if FileAccess.file_exists(_save_path):
            DirAccess.remove_absolute(_save_path)

        if FileAccess.file_exists(_save_path + ".tmp"):
            DirAccess.remove_absolute(_save_path + ".tmp")
        if FileAccess.file_exists(_save_path + ".bak"):
            DirAccess.remove_absolute(_save_path + ".bak")


    save_summary_dic.erase(_save_code)
    save_save_summary_dic()

func list_export_save_data_dir()-> Array:
    var _result: Array[Dictionary] = []


    var _downloads_path = EXPORT_PATH_PREFIX

    if _downloads_path.is_empty():

        return _result


    var _rodri_path = _downloads_path.path_join("Rodri")


    var _rodri_dir = DirAccess.open(_rodri_path)
    if _rodri_dir == null:

        return _result


    var _folders: Array = _rodri_dir.get_directories()


    _folders.sort_custom(func(a: String, b: String)-> bool:
        return a > b
    )



    for _folder: String in _folders:
        _result.append(
            {
                "name": _folder,
                "path": _rodri_path.path_join(_folder),
            }
        )


    return _result



func export_save_data()-> String:
    var save_dir = "user://save/"
    var dir = DirAccess.open(save_dir)

    if dir == null:
        OS.alert("存档文件夹不存在, 无法导出!", "错误")
        return ""


    var downloads_path: = EXPORT_PATH_PREFIX
    if downloads_path.is_empty():
        OS.alert("无法获取 Download 目录", "错误")
        return ""


    var rodri_path = downloads_path.path_join("Rodri")
    var rodri_dir = DirAccess.open(downloads_path)

    if rodri_dir == null:
        OS.alert("无法访问下载目录", "错误")
        return ""
    if not rodri_dir.dir_exists(EXPORT_SAVE_DATA_DIR_NAME):
        if rodri_dir.make_dir(EXPORT_SAVE_DATA_DIR_NAME) != OK:
            OS.alert("无法创建 " + EXPORT_SAVE_DATA_DIR_NAME + " 文件夹", "错误")
            return ""


    var timestamp = Time.get_datetime_string_from_system(false, true).replace(":", "").replace(" ", "_")
    var random_num = str(randi() % 900000 + 100000)
    var folder_name = timestamp + "_" + random_num
    var target_folder = rodri_path.path_join(folder_name)

    var target_dir = DirAccess.open(rodri_path)

    if target_dir == null:
        OS.alert("无法访问导出目录", "错误")
        return ""
    if target_dir.make_dir(folder_name) != OK:
        OS.alert("无法创建导出文件夹", "错误")
        return ""


    var file_list = dir.get_files()
    var success_count = 0

    for file_name in file_list:

        if file_name.ends_with(".tmp") or file_name.ends_with(".bak"):
            continue
        var source_file = save_dir + file_name
        var target_file = target_folder.path_join(file_name)

        if _copy_file_by_read_write(source_file, target_file):
            success_count += 1
        else:
            OS.alert("复制失败: " + file_name, "错误")


    if success_count > 0:
        var full_path = "Downloads/Rodri/" + folder_name


        return folder_name
    else:
        OS.alert("没有找到存档文件", "导出失败")
        return ""


func import_save_data(
    _save_summary_json: Dictionary,
    _origin_save_data_file_dir_path: String
)-> void:

    var _old_save_path: String = _save_summary_json.get("save_path", "")
    if _old_save_path.is_empty():
        printerr("GlobalSave.import_save_data: save_path is empty in _save_summary_json")
        return
    var _old_save_file_name: = StringUtils.substringEnd(
        _old_save_path,
        _old_save_path.rfind("/")
    )

    var _new_save_code: = SystemUtils.generate_import_save_code()
    _save_summary_json.save_code = _new_save_code
    _save_summary_json.save_path = _get_save_file_path(_new_save_code)
    _save_summary_json.save_name = SystemUtils.get_save_name(_save_summary_json) + " (导入)"


    var _origin_save_file_path: = _origin_save_data_file_dir_path.path_join(_old_save_file_name)
    var _new_save_file_path = _save_summary_json.save_path
    if _copy_file_by_read_write(_origin_save_file_path, _new_save_file_path):

        GlobalMessageInterface.add_save_data_import_success(
            SystemUtils.get_save_name(_save_summary_json)
        )
    else:
        OS.alert("复制失败: ", _origin_save_file_path)
        return

    save_summary_dic[_new_save_code] = _save_summary_json
    save_save_summary_dic()


func _get_save_summary()-> Dictionary:
    return {
        "save_code": current_save_code,
        "save_path": _get_save_file_path(current_save_code),
        "update_time": CommonUtils.get_system_timestamp(),
        "team_json": WSData.get_player_data(),
        "player_hero_json": SoldierUtils.get_json_by_uid(CreateCharacterConstants.PLAYER_HERO_CODE),
        "system_counter": WSData.system_counter,
    }

func _save_data_to_file(_save_code: String)-> void:
    var _save_data: Dictionary = _get_save_data()

    var _file_path: String = _get_save_file_path(_save_code)
    _save_to_file_by_path_atomic(_file_path, _save_data)



func _save_to_file_by_path(_file_path: String, _save_data: Dictionary)-> void:
    var _file = _get_file_access_write(_file_path)

    if _file == null:
        return
    _file.store_var(_save_data)
    _file.close()



func _save_to_file_by_path_atomic(_file_path: String, _save_data: Dictionary)-> void:
    var _tmp_path: String = _file_path + ".tmp"
    var _bak_path: String = _file_path + ".bak"


    var _file = _get_file_access_write(_tmp_path)
    if _file == null:

        _save_to_file_by_path(_file_path, _save_data)
        return
    _file.store_var(_save_data)
    _file.close()



    if FileAccess.file_exists(_file_path):
        if FileAccess.file_exists(_bak_path):
            DirAccess.remove_absolute(_bak_path)

        if DirAccess.rename_absolute(_file_path, _bak_path) != OK:

            _copy_file(_file_path, _bak_path)


    if DirAccess.rename_absolute(_tmp_path, _file_path) != OK:

        if DirAccess.copy_absolute(_tmp_path, _file_path) == OK:
            DirAccess.remove_absolute(_tmp_path)



func _copy_file(_source_path: String, _target_path: String)-> void:
    var _source = FileAccess.open(_source_path, FileAccess.READ)
    if _source == null:
        return
    var _buffer = _source.get_buffer(_source.get_length())
    _source.close()
    var _target = FileAccess.open(_target_path, FileAccess.WRITE)
    if _target == null:
        return
    _target.store_buffer(_buffer)
    _target.close()

func _get_save_file_path(_code)-> String:
    return "user://save/" + _code + ".dat"

func _get_file_access_write(_path: String)-> FileAccess:


    var _dir = StringUtils.substringStart(_path, _path.rfind("/"))
    if not _dir.is_empty():
        if not DirAccess.dir_exists_absolute(_dir):
            DirAccess.make_dir_absolute(_dir)
    return FileAccess.open(_path, FileAccess.WRITE)


func _copy_file_by_read_write(_source_path: String, _target_path: String)-> bool:
    var _source_file = FileAccess.open(_source_path, FileAccess.READ)
    if _source_file == null:
        OS.alert("无法读取源文件: " + _source_path + "\n错误码: " + str(FileAccess.get_open_error()), "错误")
        return false
    var _buffer = _source_file.get_buffer(_source_file.get_length())
    _source_file.close()

    var _save_dir = DirAccess.open("user://")
    if _save_dir != null and not _save_dir.dir_exists("save"):
        _save_dir.make_dir("save")

    var _target_file = FileAccess.open(_target_path, FileAccess.WRITE)
    if _target_file == null:
        OS.alert("无法写入目标文件: " + _target_path + "\n错误码: " + str(FileAccess.get_open_error()), "错误")
        return false
    _target_file.store_buffer(_buffer)
    _target_file.close()
    return true


func _get_save_data()-> Dictionary:
    return {


        "hero_data": GlobalSoldierInfo.hero_dic,
        "world_data": _get_world_data(),
        "ws_data": WSData.get_save_data(),
        "location_data": WSLocationData.get_save_data(),
        "event_data": GlobalEventData.get_save_data(),
        "special_npc_team_data": GlobalNpcTeamData.get_save_data(),
        "country_data": GlobalCountryData.get_save_data()
    }


func _get_world_data()-> Dictionary:

    if GlobalNode.mworld_scene == null:
        return {}
    return GlobalNode.mworld_scene.get_save_data()