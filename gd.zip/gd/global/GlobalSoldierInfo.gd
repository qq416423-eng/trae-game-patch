extends Node


var soldier_dic: = {}


var hero_dic: = {}




var soldier_cache_info: = {}



var refresh_location_hero_uid_dic: = {}


var init_hero_dic: = {}


var action_soldier_uid_list: = []


var action_boss_lord_hero_uid_list: = []

func _ready():
    _handle_soldier_dic(TestSoldierData.test_soldier_list)
    _handle_soldier_dic(WildSoldierData.wild_soldier_list)
    _handle_soldier_dic(RegularSoldierData.regular_soldier_list)
    reset_hero_dic()

    for soldier_uid: String in soldier_dic.keys():
        if soldier_uid.begins_with("test_"):
            continue

        action_soldier_uid_list.append(soldier_uid)


    var wild_hero_uid_list = [
        "wild_hero_0008", "wild_hero_0009", "wild_hero_0010",
        "wild_hero_0011", "wild_hero_0012", "wild_hero_0013"
    ]

    for _hero_uid: String in wild_hero_uid_list:
        action_boss_lord_hero_uid_list.append(_hero_uid)

    for _hero_uid: String in LordHeroData.HERO_LIST:
        if _hero_uid == "mod_boss_conquest_knight":
            continue
        action_boss_lord_hero_uid_list.append(_hero_uid)

func reset_hero_dic():
    hero_dic = {}
    _handle_hero_dic(TestHeroData.TEST_HERO_LIST)
    _handle_hero_dic(MinorHeroData.HERO_LIST)
    _handle_hero_dic(WildHeroData.HERO_LIST)
    _handle_hero_dic(LordHeroData.HERO_LIST)

    _handle_override_hero_data()

    _handle_default_prop()


    _mod_register_village_npc()




func _mod_register_village_npc()-> void:
    var _mod_npc_list: Array = [
        {"uid": "mod_blacksmith_armour", "name": "盔甲铁匠", "gender": BSSoldierConstants.GENDER_ENUM.MALE},
        {"uid": "mod_blacksmith_weapon", "name": "武器铁匠", "gender": BSSoldierConstants.GENDER_ENUM.MALE},
        {"uid": "mod_blacksmith_harmour", "name": "马铠铁匠", "gender": BSSoldierConstants.GENDER_ENUM.MALE},
        {"uid": "mod_quartermaster", "name": "军需人员", "gender": BSSoldierConstants.GENDER_ENUM.MALE},
        {"uid": "mod_appraiser", "name": "赌物人", "gender": BSSoldierConstants.GENDER_ENUM.MALE},
    ]
    for _npc_json: Dictionary in _mod_npc_list:
        if not hero_dic.has(_npc_json.uid):
            _npc_json["level"] = 1
            _npc_json["exp"] = 0
            _npc_json["attr_point"] = 0
            hero_dic[_npc_json.uid] = _npc_json

func add_hero(_hero_code: String, _hero_json: Dictionary)-> void:
    var _hero_json_d: = _hero_json.duplicate(true)
    _hero_json_d.uid = _hero_code
    hero_dic[_hero_code] = _hero_json_d


const INCOMPLETE_FIELD_SAVE_HERO_UID_PREFIX_LIST = ["minor_"]
const INCOMPLETE_FIELD_SAVE_LIST = [

    "current_dialogue_flag",

    "dialogue_save_info",

    "wandering_info",
]

func load_hero_data(_save_hero_dic: Dictionary)-> void:
    _merge_hero_dic(_save_hero_dic)

    _handle_override_hero_data()



    handle_hero_location_data()


func handle_hero_location_data()-> void:
    refresh_location_hero_uid_dic = {}

    for _hero_data: Dictionary in hero_dic.values():
        if _hero_data.uid == "wild_hero_0001" or _hero_data.uid == "wild_hero_0002":
            if not _hero_data.has("current_location"):
                _hero_data.current_location = {
                    "need_load": true,
                    "location": "MWCity0002:Tavern",
                }
            elif not _hero_data.has("wandering_info"):
                _hero_data.current_location.need_load = true

        if not _hero_data.has("current_location") and not _hero_data.has("wandering_info"):
            continue

        if _hero_data.has("current_location") and _hero_data.current_location.has("need_load") and _hero_data.current_location.need_load:
            _hero_data.current_location.need_load = false

            WSLocationData.add_location_static_npc_info(_hero_data.current_location.location, _hero_data.uid)


        if _hero_data.has("wandering_info"):
            if not _hero_data.has("wandering_config"):



                WSLocationData.remove_npc_from_all_locations(_hero_data.uid)
                _hero_data.erase("wandering_info")
                continue
            refresh_location_hero_uid_dic[_hero_data.uid] = 1
            if not _hero_data.wandering_info.has_been_loaded:
                _hero_data.wandering_info.has_been_loaded = true
                WSLocationData.place_hero_randomly(_hero_data)


func get_refresh_location_hero_uid_list()-> Array:
    return refresh_location_hero_uid_dic.keys()


func get_init_hero_data(_hero_uid: String)-> Dictionary:
    if init_hero_dic.has(_hero_uid):
        return init_hero_dic.get(_hero_uid)

    return {}

func get_star(_soldier_uid: String)-> int:
    return soldier_cache_info.get(_soldier_uid).star


func _handle_default_prop()-> void:






    pass


func _merge_hero_dic(_hero_dic: Dictionary)-> void:
    for _hero_json in _hero_dic.values():

        var _prefix: String = StringUtils.substringStart(_hero_json.uid, _hero_json.uid.find("_") + 1)


        if INCOMPLETE_FIELD_SAVE_HERO_UID_PREFIX_LIST.has(_prefix):

            for _field: String in INCOMPLETE_FIELD_SAVE_LIST:
                if _hero_json.has(_field):
                    hero_dic[_hero_json.uid][_field] = _hero_json[_field]
        else:




            if hero_dic.has(_hero_json.uid):
                CommonUtils.cover_json(_hero_json, hero_dic.get(_hero_json.uid))
            else:
                hero_dic[_hero_json.uid] = _hero_json


func _handle_override_hero_data()-> void:
    for _hero_uid: String in HeroDataOverride.HERO_OVERRIDE_DATA.keys():
        CommonUtils.cover_json(
            HeroDataOverride.HERO_OVERRIDE_DATA.get(_hero_uid).duplicate(true),
            hero_dic.get(_hero_uid)
        )

func _handle_soldier_dic(_json_dic: Dictionary):
    for _key in _json_dic.keys():
        var _json = _json_dic.get(_key).duplicate(true)
        _json.uid = _key
        soldier_dic[_key] = _json


        var _info: = SoldierUtils.get_combat_power_and_price(_key)
        if not soldier_dic.has("combat_power"):
            _json["combat_power"] = _info.combat_power

        if not soldier_dic.has("price"):
            _json["price"] = _info.price





        soldier_cache_info[_key] = {
            "hp_max": SoldierUtils.get_hp_max_by_complete_json(_json),
            "star": _json.star
        }

func _handle_hero_dic(_json_dic: Dictionary):
    for _hero_uid: String in _json_dic.keys():
        var _hero_data: Dictionary = _json_dic.get(_hero_uid)
        add_hero(_hero_uid, _hero_data)

        if CommonUtils.get_value(_hero_data, "need_save_init", false):
            init_hero_dic[_hero_uid] = _hero_data.duplicate(true)