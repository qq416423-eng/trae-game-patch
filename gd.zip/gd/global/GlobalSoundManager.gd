extends Node

@onready var button_click_0001_node: AudioStreamPlayer =$SFX / ButtonClick0001
@onready var button_click_0002_node: AudioStreamPlayer =$SFX / ButtonClick0002
@onready var button_click_0003_node: AudioStreamPlayer =$SFX / ButtonClick0003
@onready var button_click_0004_node: AudioStreamPlayer =$SFX / ButtonClick0004
@onready var button_click_0005_node: AudioStreamPlayer =$SFX / ButtonClick0005
@onready var click_left_node: AudioStreamPlayer =$SFX / ClickLeft
@onready var click_right_node: AudioStreamPlayer =$SFX / ClickRight
@onready var draw_sword_node: AudioStreamPlayer =$SFX / DrawSword
@onready var rain_sfx_node: AudioStreamPlayer =$Environment / RainSFX
@onready var bg_music_node: AudioStreamPlayer =$MusicRoot / BGMusic

const HEAVY_RAIN_1 = preload("res://resource/sound/environment/heavy_rain_1.mp3")
const LIGHT_RAIN_1 = preload("res://resource/sound/environment/light_rain_1.mp3")

enum RAIN_SFX_ENUM {
    LIGHT_RAIN,
    HEAVY_RAIN,
    NO_RAIN
}
const LIGHT_RAIN_VOLUME_DB = -20
const HEAVY_RAIN_VOLUME_DB = -10

var sfx_config: = {}
var current_rain_sfx: = RAIN_SFX_ENUM.NO_RAIN
var target_rain_sfx: = RAIN_SFX_ENUM.NO_RAIN
var is_changing_rain_sfx: = false

enum BG_MUSIC_TYPE_ENUM {
    DEFAULT,
    BATTLE
}

const BS_MUSIC_CONFIG: = {
    BG_MUSIC_TYPE_ENUM.DEFAULT: {
        "path_list": [
            "res://resource/sound/music/dawn_of_the_kingdom.mp3",
            "res://resource/sound/music/town.mp3",
            "res://resource/sound/music/623427__zhr__medieval-various-music.mp3",
            "res://resource/sound/music/dawn_of_the_kingdom.mp3",
            "res://resource/sound/music/588644__gertraut_hecher__mysterious-world-glittering-crystals.wav",
            "res://resource/sound/music/769807__soundsandrebounds__shakespeare-lover-and-his-lass-lute-and-wood-flute.wav",
        ]
    },
    BG_MUSIC_TYPE_ENUM.BATTLE: {
        "path_list": [
            "res://resource/sound/music/defencing_battle.mp3",
            "res://resource/sound/music/sea_battle.mp3",
            "res://resource/sound/music/sea_battle_2.mp3",
            "res://resource/sound/music/trailer.mp3",
        ]
    }
}

func _ready()-> void:
    sfx_config = {
        SoundConstants.SFX_NAME.BUTTON_CLICK_0001: button_click_0001_node,
        SoundConstants.SFX_NAME.BUTTON_CLICK_0002_SWITCH: button_click_0002_node,
        SoundConstants.SFX_NAME.BUTTON_CLICK_0003_LIST: button_click_0003_node,
        SoundConstants.SFX_NAME.BUTTON_CLICK_0004_BATTLE: button_click_0004_node,
        SoundConstants.SFX_NAME.BUTTON_CLICK_0005_CHARGE: button_click_0005_node,
        SoundConstants.SFX_NAME.CLICK_LEFT: click_left_node,
        SoundConstants.SFX_NAME.CLICK_RIGHT: click_right_node,
        SoundConstants.SFX_NAME.DRAW_SWORD: draw_sword_node,
    }

func play_sfx(_sfx_name: SoundConstants.SFX_NAME)-> void:
    sfx_config.get(_sfx_name).play()

func handle_weather_sfx(_weather: MWorldConstants.WEATHER_TYPE_ENUM)-> void:
    match _weather:
        MWorldConstants.WEATHER_TYPE_ENUM.SMALL_RAIN:
            GlobalSoundManager.play_light_rain_sfx()
        MWorldConstants.WEATHER_TYPE_ENUM.BIG_RAIN:
            GlobalSoundManager.play_heavy_rain_sfx()
        MWorldConstants.WEATHER_TYPE_ENUM.CLEAR:
            GlobalSoundManager.stop_rain_sfx()

func play_light_rain_sfx()-> void:
    target_rain_sfx = RAIN_SFX_ENUM.LIGHT_RAIN
    _change_rain_sfx()

func play_heavy_rain_sfx()-> void:
    target_rain_sfx = RAIN_SFX_ENUM.HEAVY_RAIN
    _change_rain_sfx()

func stop_rain_sfx()-> void:
    target_rain_sfx = RAIN_SFX_ENUM.NO_RAIN
    _change_rain_sfx()






func _change_rain_sfx()-> void:
    if is_changing_rain_sfx:
        return

    if current_rain_sfx == target_rain_sfx:
        return

    is_changing_rain_sfx = true
    current_rain_sfx = target_rain_sfx

    var _tween: = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    if target_rain_sfx == RAIN_SFX_ENUM.NO_RAIN:
        _tween.tween_property(rain_sfx_node, "volume_db", -80, 1.0)
        await _tween.finished
        is_changing_rain_sfx = false
        _change_rain_sfx()
        return

    _tween.tween_property(rain_sfx_node, "volume_db", -80, 1.0)
    await _tween.finished

    if target_rain_sfx == RAIN_SFX_ENUM.NO_RAIN:
        return

    var _target_volume_db: = 0
    match target_rain_sfx:
        RAIN_SFX_ENUM.LIGHT_RAIN:
            rain_sfx_node.stream = LIGHT_RAIN_1
            _target_volume_db = LIGHT_RAIN_VOLUME_DB
        RAIN_SFX_ENUM.HEAVY_RAIN:
            rain_sfx_node.stream = HEAVY_RAIN_1
            _target_volume_db = HEAVY_RAIN_VOLUME_DB

    rain_sfx_node.stream.loop = true
    rain_sfx_node.play()

    _tween = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(rain_sfx_node, "volume_db", _target_volume_db, 1.0)
    await _tween.finished
    is_changing_rain_sfx = false
    _change_rain_sfx()

var current_bg_music_path: = ""
var current_bg_music_type: = BG_MUSIC_TYPE_ENUM.DEFAULT

func change_music(_type: BG_MUSIC_TYPE_ENUM)-> void:
    if bg_music_node.playing and current_bg_music_type == _type:

        return

    current_bg_music_type = _type
    var _path_list = BS_MUSIC_CONFIG.get(_type).path_list
    var _path = ""
    if _path_list.size() == 1:
        _path = _path_list[0]
    elif ArrayUtils.is_empty(_path_list):
        return
    else:
        _path = current_bg_music_path
        while(_path == current_bg_music_path):
            _path = _path_list.pick_random()

    if bg_music_node.playing:
        var _tween: = get_tree().create_tween()
        _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _tween.tween_property(bg_music_node, "volume_db", -80, 2.0)
        await _tween.finished

    bg_music_node.stream = load(_path)
    bg_music_node.volume_db = -80
    bg_music_node.play()
    var _tween: = get_tree().create_tween()
    _tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween.tween_property(bg_music_node, "volume_db", -5, 2.0)

func _on_bg_music_finished()-> void:
    change_music(current_bg_music_type)


var _nun_music_playing: bool = false
var _saved_bg_music_type: int = BG_MUSIC_TYPE_ENUM.DEFAULT

func play_nun_music()-> void:
    if _nun_music_playing:
        return
    _nun_music_playing = true
    _saved_bg_music_type = current_bg_music_type

    if bg_music_node.playing:
        var _tween_out: = get_tree().create_tween()
        _tween_out.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _tween_out.tween_property(bg_music_node, "volume_db", -80, 0.3)
        await _tween_out.finished

    var _path: String = "res://resource/sound/music/nun_church_miracle.mp3"
    var _stream: AudioStreamMP3 = load(_path)
    if _stream == null:
        _nun_music_playing = false
        return
    _stream.loop = true
    bg_music_node.stream = _stream
    bg_music_node.volume_db = -80
    bg_music_node.play()
    var _tween_in: = get_tree().create_tween()
    _tween_in.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    _tween_in.tween_property(bg_music_node, "volume_db", -5, 0.5)

func stop_nun_music()-> void:
    if not _nun_music_playing:
        return
    _nun_music_playing = false
    if bg_music_node.playing:
        var _tween_out: = get_tree().create_tween()
        _tween_out.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        _tween_out.tween_property(bg_music_node, "volume_db", -80, 0.3)
        await _tween_out.finished

    bg_music_node.stop()
    change_music(_saved_bg_music_type)