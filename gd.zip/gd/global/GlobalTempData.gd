extends Node


var current_location_code: = ""


var mod_is_armory_recruit: bool = false

var mod_armory_saved_recruit: Array = []

var mod_prison_build_mode: bool = false

var current_battle_uid: String

var current_battle_win_team_type: String

var player_battle_result: = BattleConstants.BATTLE_RESULT_ENUM.DEFEAT

var grocery_price_info = null


var my_team_morale_value: = 0.0

var enemy_morale_value: = 0.0

var teammate_morale_value: = 0.0
var a_team_dialogue_info: Dictionary = {}
var b_team_dialogue_info: Dictionary = {}


var player_prep_fief_code: = ""



var mult_battle_player_simple_json_list: = []
var mult_battle_enemy_simple_json_list: = []
var mult_battle_ally_simple_json_list: = []
var mult_battle_is_first_init: bool = true
var mult_battle_need_filter_living_not_busy: bool = true

var mult_battle_current_round_num: = 1



var mult_battle_player_kill_soldier_simple_json = []

var mult_battle_player_kill_soldier_combat_power_total: = 0



var mult_battle_player_kill_nop = 0
var mult_battle_ally_kill_nop = 0


var mult_battle_enemy_combat_power_total: = 0


var mult_battle_ally_combat_power_total: = 0


var mult_battle_enemy_team_node_list: Array = []
var mult_battle_ally_team_node_list: Array = []


var mult_battle_victory_reputation_value = 0



var mw_team_node_to_thank: MWTeam = null
var ally_relation_gain_after_battle_factor: float = 0.0

func set_current_location_code(_location_code: String)-> void:
    current_location_code = _location_code

func get_current_location_code()-> String:
    return current_location_code

func save_current_battle_info(
    _current_battle_uid, _current_battle_win_team_type,
    _player_battle_result
):
    if _current_battle_win_team_type == null:

        _current_battle_win_team_type = ""

    current_battle_uid = _current_battle_uid
    current_battle_win_team_type = _current_battle_win_team_type
    player_battle_result = _player_battle_result

func clear_current_battle_info():
    current_battle_uid = ""
    current_battle_win_team_type = ""

func set_grocery_price_info(_temp_json):
    grocery_price_info = _temp_json


func update_grocery_price_info(_uid: String, _plus_count: int)-> bool:
    if not GoodsUtils.is_commodity(_uid):
        return false

    if grocery_price_info == null:
        return false

    if grocery_price_info.has(_uid):
        grocery_price_info[_uid].count += _plus_count
    else:
        grocery_price_info[_uid] = {
            "real_production_capacity": 0,
            "count": _plus_count,
        }

    return true


func get_commodity_price_ratio(_uid: String, _plus_count: int = 0)-> float:
    if grocery_price_info == null or not grocery_price_info.has(_uid):
        return 1.0

    var _info = grocery_price_info.get(_uid)
    var _plus_ratio = - _info.real_production_capacity * 0.0005 -(_info.count + _plus_count) * 0.017
    var _result_ratio = 1.0 + _plus_ratio

    if _result_ratio < GoodsConfig.COMMODITY_MIN_DISCOUNT:
        _result_ratio = GoodsConfig.COMMODITY_MIN_DISCOUNT

    return _result_ratio


func get_min_discount_count(_uid: String)-> int:
    var _info = grocery_price_info.get(_uid)
    return int((1 - _info.real_production_capacity * 0.0005 - GoodsConfig.COMMODITY_MIN_DISCOUNT) / 0.017) \
    - _info.count + 1

func get_commodity_base_discount(_uid: String):
    if grocery_price_info == null or not grocery_price_info.has(_uid):
        return 0

    var _info = grocery_price_info.get(_uid)
    return _info.real_production_capacity * 0.0005

func get_morale(_group: String)-> float:
    match _group:
        BSSoldierConstants.BS_GROUP_ENUM.PLAYER_GROUP:
            return my_team_morale_value
        BSSoldierConstants.BS_GROUP_ENUM.TEAMMATE_GROUP:
            return teammate_morale_value
        BSSoldierConstants.BS_GROUP_ENUM.ENEMY_GROUP:
            return enemy_morale_value

    return TeamConfig.DEFAULT_MORALE

func update_dialogue_info(
    _a_team_dialogue_info: Dictionary,
    _b_team_dialogue_info: Dictionary,
)-> void:
    a_team_dialogue_info = _a_team_dialogue_info
    b_team_dialogue_info = _b_team_dialogue_info

func set_player_prep_fief_code(_location_code: String)-> void:
    player_prep_fief_code = _location_code

func reset_mult_battle_data()-> void:
    mult_battle_player_simple_json_list = []
    mult_battle_enemy_simple_json_list = []
    mult_battle_ally_simple_json_list = []
    mult_battle_is_first_init = true
    mult_battle_need_filter_living_not_busy = true
    mult_battle_current_round_num = 1


    mult_battle_player_kill_soldier_simple_json = []


    mult_battle_enemy_combat_power_total = 0
    mult_battle_ally_combat_power_total = 0
    mult_battle_enemy_team_node_list = []
    mult_battle_ally_team_node_list = []

    mult_battle_victory_reputation_value = 0.0
    mult_battle_player_kill_soldier_combat_power_total = 0

func compute_mult_battle_player_kill_soldier_combat_power_total()-> void:

    var _temp_simple_json: Array = mult_battle_player_kill_soldier_simple_json.duplicate(true)

    TeamUtils.simple_json_recovery(_temp_simple_json)

    mult_battle_player_kill_soldier_combat_power_total = \
    SoldierUtils.get_combat_power_total_by_simple_json_list(
            _temp_simple_json, false
        )