extends Node

var current_time_scale: = 1.0

const SLOW_TIME_SCALE: = 0.35
const NORMAL_TIME_SCALE: = 1.0

static var QUICK_TIME_SCALE: = 3.0

signal time_scale_update_sign(_time_scale: float)

func _ready()-> void:
    if GameConfig.WORLD_TIME_SPEED_MAX:
        QUICK_TIME_SCALE = 10

func time_slow():
    if current_time_scale != SLOW_TIME_SCALE:
        Engine.time_scale = SLOW_TIME_SCALE
        current_time_scale = SLOW_TIME_SCALE
        time_scale_update_sign.emit(current_time_scale)

func time_normal():
    if current_time_scale != NORMAL_TIME_SCALE:
        Engine.time_scale = NORMAL_TIME_SCALE
        current_time_scale = NORMAL_TIME_SCALE
        time_scale_update_sign.emit(current_time_scale)

func time_quick():
    if current_time_scale != QUICK_TIME_SCALE:
        Engine.time_scale = QUICK_TIME_SCALE
        current_time_scale = QUICK_TIME_SCALE
        time_scale_update_sign.emit(current_time_scale)

func get_current_time_scale()-> float:
    return current_time_scale