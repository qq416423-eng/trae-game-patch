extends Node2D

@onready var line_edit_node: LineEdit =$LineEdit
@onready var button_node: Button =$Button

func _ready():

    pass


func _get_specialty_data(_code: String)-> void:
    var _result = ""
    for _location_code: String in WSLocationData.CITY_SYSTEM_DATA.keys():
        if not _location_code.contains("City"):
            continue

        var _location_data: Dictionary = WSLocationData.CITY_SYSTEM_DATA.get(_location_code)
        if _location_data.specialty_grocery.has(_code):
            _result +=(_location_code + ": " + _code + ": " + str(_location_data.specialty_grocery.get(_code)) + "\n")



func _on_button_pressed()-> void:
    _get_specialty_data(line_edit_node.text)