class_name ImperialUnionTestConfig



const is_enabled: = "否"

func _ready()-> void:
    pass

static func is_test_enabled()-> bool:
    return is_enabled == "是"


static func apply_test_settings()-> void:
    if not is_test_enabled():
        return


    var player_country = SoldierUtils.get_player_belong_country()
    for country_code: String in WSCountryData.COUNTRY_DATA.keys():
        if country_code == WSCountryData.COUNTRY_NAME_ENUM.NONE:
            continue
        if country_code == player_country:
            continue
        GlobalCountryData.update_country_relation_value(
            player_country,
            country_code,
            0,
            true
        )


    SoldierUtils.get_player_hero_json().reputation_value = 100


    var _player_hero_json = SoldierUtils.get_json_by_uid(CreateCharacterConstants.PLAYER_HERO_CODE)
    _player_hero_json["combat_power"] = 100