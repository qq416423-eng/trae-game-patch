extends Node2D



func _ready():
    pass



func _process(delta):
    pass

func _on_hurt_area_2d_area_entered(area):

    pass