extends Node2D

@onready var battle_scene_node =$BattleScene as BattleScene

const B_MAP_SHOAL_0001 = preload("res://tscn/game/map/bMap/BMapForestShoal0001.tscn")
const B_MAP_PLAIN_0001 = preload("res://tscn/game/map/bMap/BMapPlain0001.tscn")
const B_MAP_DESERT_0001 = preload("res://tscn/game/map/bMap/BMapDesert0001.tscn")
const B_MAP_FOREST_0001 = preload("res://tscn/game/map/bMap/BMapForest0001.tscn")

func _ready()-> void:
    WSData.save_player_weather(MWorldConstants.WEATHER_TYPE_ENUM.CLEAR)
    GlobalNode.battle_scene = battle_scene_node

    battle_scene_node.init_map(B_MAP_PLAIN_0001)
    battle_scene_node.init(TestTeamData.get_player_team_json(), TestTeamData.get_enemy_team_json())