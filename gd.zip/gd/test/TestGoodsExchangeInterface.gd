extends Control

@onready var goods_exchange_interface_node =$GoodsExchangeInterface

var team_data = {
    "money": 10000,
    "goods": [],
    "team": [
        {
            "uid": "lord_hero_0016",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "wild_hero_0008",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
            "is_leader": true,
            "is_player": true,

        },
        {
            "uid": "wild_hero_0007",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
    ]
}

func _ready():





























    goods_exchange_interface_node.init_base(team_data.goods,[], team_data)
    goods_exchange_interface_node.cshow()

func _add_good(_list_dic: Dictionary):
    var _goods_list: = []
    for _key: String in _list_dic.keys():
        _goods_list.append(
            {
                "item": {
                    "uid": _key,

                },
                "count": 1
            }
        )

    team_data.goods.append_array(_goods_list)