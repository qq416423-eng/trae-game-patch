extends Control

@onready var color_rect_node: ColorRect =$ColorRect

func _ready()-> void:
    play_shader_animation()

func play_shader_animation()-> void:
    var tween = create_tween()
    tween.tween_property(color_rect_node, "material:shader_parameter/progress", 3.0, 1.0)