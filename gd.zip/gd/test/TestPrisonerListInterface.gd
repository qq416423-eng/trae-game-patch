extends Control

@onready var prisoner_list_interface_node: PrisonerListInterface =$PrisonerListInterface

func _ready()-> void:
    var _test_data: = [

        {
            "uid": "regular_soldier_0007",
        },
        {
            "uid": "regular_soldier_0007",
        },
        {
            "uid": "regular_soldier_0007",
        },
        {
            "uid": "regular_soldier_0007",
        },
        {
            "uid": "regular_soldier_0007",
        },
        {
            "uid": "regular_soldier_0007",
        },
        {
            "uid": "regular_soldier_0014",
        },
        {
            "uid": "lord_hero_0001",

            "is_captured": true,
        },
        {
            "uid": "regular_soldier_0014",
        },
        {
            "uid": "regular_soldier_0014",
        },
        {
            "uid": "regular_soldier_0014",
        },
    ]

    for _simple_json: Dictionary in _test_data:
        SoldierUtils.repair_simple_json(_simple_json)

    prisoner_list_interface_node.init(_test_data)