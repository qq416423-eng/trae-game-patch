extends Control

@onready var team_manage_interface: TeamManageInterface =$TeamManageInterface

func _ready()-> void:
    WSData.player_data.goods = []
    var _json: = [
        {
            "uid": "regular_soldier_0041",
            "htype": BSSoldierConstants.H_TYPE_ENUM.SOLDIER,
        },




































        {
            "uid": "lord_hero_0008",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0007",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0006",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0005",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0004",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0003",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0002",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0001",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0009",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0010",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0011",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0012",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0013",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "lord_hero_0015",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "regular_soldier_0039",
            "htype": BSSoldierConstants.H_TYPE_ENUM.SOLDIER,
        },
        {
            "uid": "regular_soldier_0042",
            "htype": BSSoldierConstants.H_TYPE_ENUM.SOLDIER,
        },
        {
            "uid": "lord_hero_0016",
            "htype": BSSoldierConstants.H_TYPE_ENUM.HERO,
        },
        {
            "uid": "regular_soldier_0043",
            "htype": BSSoldierConstants.H_TYPE_ENUM.SOLDIER,
        },
    ]

    TeamUtils.repair_simple_json(_json, false)
    team_manage_interface.init(_json)

func _add_all_soldier()-> Array:
    var _result: Array = []
    for _key: String in RegularSoldierData.regular_soldier_list.keys():
        _result.append({
            "uid": _key,
            "htype": BSSoldierConstants.H_TYPE_ENUM.SOLDIER,
        })
    for _key: String in WildSoldierData.wild_soldier_list.keys():
        _result.append({
            "uid": _key,
            "htype": BSSoldierConstants.H_TYPE_ENUM.SOLDIER,
        })
    return _result