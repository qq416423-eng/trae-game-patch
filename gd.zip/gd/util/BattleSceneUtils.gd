class_name BattleSceneUtils

static func get_army_distance(_nop: int)-> int:

    var _nop_mia: = [20, 120]

    var _distance_mia = [1500, 1800]

    var _distance = CommonUtils.get_section_value(_distance_mia, _nop_mia, _nop)
    _distance = min(_distance, _distance_mia[1])
    _distance = max(_distance, _distance_mia[0])

    return _distance


static func get_reputation_value(

    _player_combat_power: int,

    _enemy_combat_power: int,

    _allies_combat_power: int,



)-> float:
    return minf(
        (
            (



                _enemy_combat_power * 3.0 /(_player_combat_power + _allies_combat_power)



                +(_enemy_combat_power * 1.0 / 2000)
            )

            *(_player_combat_power * 1.0 /(_allies_combat_power + _player_combat_power))
        ) \

        * BattleSceneConfig.ACQUIRE_REPUTATION_MULT_RATIO,
        20.0
    )

static func get_battle_unit_limit(_percent: float)-> int:
    return(int(
        BattleSceneConfig.BATTLE_UNIT_LIMIT_MIN \
        + _percent *(
            BattleSceneConfig.BATTLE_UNIT_LIMIT_MAX - BattleSceneConfig.BATTLE_UNIT_LIMIT_MIN
        ) / 100
    ) / 5) * 5