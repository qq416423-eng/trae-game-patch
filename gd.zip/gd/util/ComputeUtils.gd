class_name ComputeUtils


static func split_int(_total: int, _float_list: Array, _allow_zero: = false)-> Array:
    var _result = []

    if _total <= 0:
        return[0]

    if _total <= _float_list.size() and not _allow_zero:
        for _index in range(_total):
            _result.append(1)

        return _result

    var _sum_float = ArrayUtils.get_total(_float_list)

    var _temp_fraction_info_list = []
    var _remain_num = _total



    for _index in range(_float_list.size()):
        var _float: float = _float_list[_index]
        var _ratio: float = _total * _float / _sum_float
        var _ratio_int: = int(_ratio)
        if _ratio_int == 0 and not _allow_zero:
            _ratio_int = 1
        else:
            _temp_fraction_info_list.append({
                "value": _ratio - _ratio_int,
                "index": _index,
            })

        _result.append(_ratio_int)
        _remain_num -= _ratio_int

    if _remain_num == 0:
        return _result


    if _remain_num > 0:
        _temp_fraction_info_list.sort_custom(func(_a: Dictionary, _b: Dictionary): return _a.value > _b.value)
        var _current_index = 0
        while(_remain_num != 0):
            _result[_temp_fraction_info_list[_current_index].index] += 1
            _remain_num -= 1
            _current_index += 1
            if _current_index >= _temp_fraction_info_list.size():
                _current_index = 0
    else:
        _temp_fraction_info_list.sort_custom(func(_a: Dictionary, _b: Dictionary): return _a.value < _b.value)
        var _current_index = 0
        while(_remain_num != 0):
            if _result[_temp_fraction_info_list[_current_index].index] <= 1:
                pass
            else:
                if _remain_num > 0:
                    _result[_temp_fraction_info_list[_current_index].index] += 1
                    _remain_num -= 1
                else:
                    _result[_temp_fraction_info_list[_current_index].index] -= 1
                    _remain_num += 1

            _current_index += 1
            if _current_index >= _temp_fraction_info_list.size():
                _current_index = 0

    return _result


static func compute_real_location_relation_value_plus(_pre_value: float, _plus_value: float)-> float:
    if _plus_value == 0:
        return 0

    var _config_value: = [10.0, 20.0, 40.0, 70.0]
    var _config_ratio: = [0.85, 0.7, 0.5, 0.3]
    var _real_plus_value: = 0.0
    var _result_need_negative: = false

    var _multiplier: = 1.0
    if _plus_value < 0:
        _pre_value *= -1
        _plus_value *= -1
        _multiplier = -1.0

    while(_plus_value > 0.0001):
        var _ratio: float = 1.0
        var _next_level: float = _config_value[0]

        if _pre_value >= _config_value[3]:
            _ratio = _config_ratio[3]
            _next_level = 10000.0
        elif _pre_value >= _config_value[2]:
            _ratio = _config_ratio[2]
            _next_level = _config_value[3]
        elif _pre_value >= _config_value[1]:
            _ratio = _config_ratio[1]
            _next_level = _config_value[2]
        elif _pre_value >= _config_value[0]:
            _ratio = _config_ratio[0]
            _next_level = _config_value[1]

        if _pre_value +(_plus_value * _ratio) <= _next_level:
            _real_plus_value += _plus_value * _ratio
            break
        else:
            _plus_value -=(_next_level - _pre_value) / _ratio
            _real_plus_value += _next_level - _pre_value
            _pre_value = _next_level

    return _real_plus_value * _multiplier