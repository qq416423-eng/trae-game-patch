class_name DialogueUtils


static func condition_match(
    _content_json_item: Dictionary, _turn,
    a_team_dialogue_info: Dictionary, b_team_dialogue_info: Dictionary
    )-> bool:
    if _content_json_item.has("condition"):
        var _refer_condition_turn = _turn
        if _content_json_item.has("condition_side"):
            _refer_condition_turn = _content_json_item.condition_side

        var _refer_condition = a_team_dialogue_info
        if _refer_condition_turn == DialogueConstants.SPEAKER_ENUM.B:
            _refer_condition = b_team_dialogue_info

        match _content_json_item.condition:
            DialogueConstants.CONTENT_CONDITION_ENUM.HAS_EXCHANGE_TREASURE:
                if _refer_condition.has("exchange_treasure") and ArrayUtils.is_not_empty(_refer_condition.exchange_treasure):
                    return true
            DialogueConstants.CONTENT_CONDITION_ENUM.ALL:
                return true
            DialogueConstants.CONTENT_CONDITION_ENUM.LEADER_IS_MALE:
                return _refer_condition.leader_gender == BSSoldierConstants.GENDER_ENUM.MALE
            DialogueConstants.CONTENT_CONDITION_ENUM.LEADER_IS_FEMALE:
                return _refer_condition.leader_gender == BSSoldierConstants.GENDER_ENUM.FEMALE
            DialogueConstants.CONTENT_CONDITION_ENUM.MONEY_ENOUGH:
                if CommonUtils.get_value(_content_json_item, "use_hire_money", false):
                    return _refer_condition.money >= b_team_dialogue_info.hire_money
                else:
                    return _refer_condition.money >= _content_json_item.condition_value
            DialogueConstants.CONTENT_CONDITION_ENUM.MONEY_NOT_ENOUGH:
                if CommonUtils.get_value(_content_json_item, "use_hire_money", false):
                    return _refer_condition.money < b_team_dialogue_info.hire_money
                else:
                    return _refer_condition.money < _content_json_item.condition_value
            DialogueConstants.CONTENT_CONDITION_ENUM.NOP_NOT_ENOUGH:
                return _refer_condition.nop < _content_json_item.condition_value
            DialogueConstants.CONTENT_CONDITION_ENUM.NOP_ENOUGH:
                return _refer_condition.nop >= _content_json_item.condition_value

        return false

    elif _content_json_item.has("custom_choose_func"):
        var _callable = Callable(DialogueCustomUtils, _content_json_item.custom_choose_func.func_name)
        if _content_json_item.custom_choose_func.has("params"):

            var _result: bool = _callable.callv(_content_json_item.custom_choose_func.params.duplicate(true))

            return _result
        else:
            return _callable.call()

    return true

static func get_hero_dialogue_template_json(_hero_uid: String)-> Dictionary:
    var _dialogue_gd_path: = get_dialogue_path_by_hero_uid(_hero_uid)



    return get_dialogue_template_by_path(_dialogue_gd_path)

static func get_dialogue_gd_by_hero_uid(_hero_uid: String)-> BaseDialogue:
    var _dialogue_gd_path: = get_dialogue_path_by_hero_uid(_hero_uid)
    return CommonUtils.load_gd(_dialogue_gd_path)

static func get_dialogue_path_by_hero_uid(_hero_uid: String)-> String:
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    var _dialogue_gd_path: = ""
    if SoldierUtils.is_lord(_hero_json):

        _dialogue_gd_path = get_lord_generic_dialogue_gd_path(_hero_json)
    else:
        _dialogue_gd_path = HeroDefaultData.get_dialogue_gd_path(_hero_uid)

    return _dialogue_gd_path

static func get_dialogue_path_by_team_small_type(
    _team_small_type: String
)-> String:
    var _dialogue_file_name = "BaseDialogue"

    match _team_small_type:
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.ROBBER, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.FOREST_BANDIT, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.PIRATE, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.MARKA_CRIMSON_WARBAND, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.DESERT_BANDITS, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.EVIL_EAGLE_MERCENARY, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.SCORCHING_SOUL_SECT, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.CALANT_EXILES:
            _dialogue_file_name = "Robber_" + _team_small_type + "_Dialogue"
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.ROAO_VILLAGER, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.SAINA_VILLAGER, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.MARKA_VILLAGER, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.SHALUK_VILLAGER:
            _dialogue_file_name = "VillagerDialogue"
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.MERCHANT_CONVOY, \
        MWTeamConstants.TEAM_SMALL_TYPE_ENUM.DESERT_CARAVAN:
            _dialogue_file_name = "MerchantConvoyDialogue"

    return get_dialogue_path(_dialogue_file_name)

static func get_dialogue_path(_node_name: String)-> String:

    return "res://gd/game/dialogue/" + _node_name + ".gd"

static func get_dialogue_template_by_path(_dialogue_gd_path: String)-> Dictionary:
    var _gd_node: BaseDialogue = CommonUtils.load_gd(_dialogue_gd_path)

    _gd_node.set_b_team_dialogue_info(GlobalTempData.b_team_dialogue_info)
    return _gd_node.get_current_dialogue_template()


static func get_dialogue_info(_hero_uid: String)-> Dictionary:
    if StringUtils.is_empty(_hero_uid):
        return {
            "leader_uid": "",
            "leader_name": "",
            "leader_gender": BSSoldierConstants.GENDER_ENUM.MALE,
        }

    var _hero_json = SoldierUtils.get_json_by_uid(_hero_uid)
    return {
        "leader_uid": _hero_uid,
        "leader_name": _hero_json.name,
        "leader_gender": CommonUtils.get_value(_hero_json, "gender", BSSoldierConstants.GENDER_ENUM.MALE)
    }

static func get_inverse_speaker_enum(_turn: BaseDialogue.SPEAKER_ENUM)-> BaseDialogue.SPEAKER_ENUM:
    if _turn == BaseDialogue.SPEAKER_ENUM.B:
        return BaseDialogue.SPEAKER_ENUM.A
    else:
        return BaseDialogue.SPEAKER_ENUM.B

static func change_current_dialogue_flag(_hero_uid: String, _dialogue_flag: String)-> void:
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    if _hero_json.has("current_dialogue_flag") and _hero_json.current_dialogue_flag == _dialogue_flag:
        return

    _hero_json.current_dialogue_flag = _dialogue_flag

static func save_dialogue_save_info(_hero_uid: String, _dialogue_save_info: Dictionary)-> void:
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    if not _hero_json.has("dialogue_save_info"):
        _hero_json.dialogue_save_info = {}

    for _key: String in _dialogue_save_info.keys():
        _hero_json.dialogue_save_info[_key] = _dialogue_save_info.get(_key)

static func plus_dialogue_save_info_num(_hero_uid: String, _dic: Dictionary)-> void:
    var _hero_json: Dictionary = SoldierUtils.get_json_by_hero_uid(_hero_uid)
    if not _hero_json.has("dialogue_save_info"):
        _hero_json.dialogue_save_info = {}

    for _key: String in _dic.keys():
        if not _hero_json.dialogue_save_info.has(_key):
            _hero_json.dialogue_save_info[_key] = 0

        _hero_json.dialogue_save_info[_key] += _dic.get(_key)


static func get_lord_generic_dialogue_gd_path(_hero_json: Dictionary)-> String:
    var _dialogue_gd_path: = HeroDefaultData.get_dialogue_gd_path(_hero_json.uid)

    if StringUtils.is_empty(_dialogue_gd_path):
        match _hero_json.integrity_level:
            HeroConstants.INTEGRITY_LEVEL_ENUM.BRUTAL:
                return "res://gd/game/dialogue/LordBrutalDialogue.gd"
            HeroConstants.INTEGRITY_LEVEL_ENUM.PETTY:
                return "res://gd/game/dialogue/LordPettyDialogue.gd"
            HeroConstants.INTEGRITY_LEVEL_ENUM.NEUTRAL:
                return "res://gd/game/dialogue/LordNeutralDialogue.gd"
            HeroConstants.INTEGRITY_LEVEL_ENUM.RIGHTEOUS:
                return "res://gd/game/dialogue/LordRighteousDialogue.gd"
            HeroConstants.INTEGRITY_LEVEL_ENUM.NOBLE:
                return "res://gd/game/dialogue/LordNobleDialogue.gd"


        return "res://gd/game/dialogue/LordDialogueBase.gd"

    return _dialogue_gd_path





















static func handle_str_from_func(_origin_content: String, _str_from_func: Array)-> String:
    var _result_content: = _origin_content

    if ArrayUtils.is_empty(_str_from_func):
        return _result_content

    for _index: int in range(_str_from_func.size()):
        var _replace_str = "#{" + str(_index) + "}"
        if _result_content.find(_replace_str) >= 0:
            var _func_info: Dictionary = _str_from_func[_index]
            var _callable = Callable(DialogueCustomUtils, _func_info.func_name)
            var _func_str: String = ""

            if _func_info.has("params"):
                _func_str = str(_callable.callv(_func_info.params.duplicate(true)))
            else:
                _func_str = str(_callable.call())

            _result_content = _result_content.replace(_replace_str, _func_str)

    return _result_content






































static func choose_content_by_rel_value(_content_list: Array, _target_hero_uid: String)-> String:
    var _hero_rel_value: int = SoldierUtils.get_player_relation_value_int(_target_hero_uid)






    var _chosen_content = choose_content_list_by_rel_value(_content_list, _hero_rel_value)




    if _chosen_content is String:
        return _chosen_content
    if _chosen_content is Array and not(_chosen_content as Array).is_empty():
        return(_chosen_content as Array).pick_random()


    for _item in _content_list:
        if _item is String:
            return _item
        if _item is Array and not(_item as Array).is_empty():
            return(_item as Array)[0]
    return ""


static func choose_content_list_by_rel_value(_content_list: Array, rel_value: int)-> Array:
    var _content_size: = _content_list.size()
    if _content_size == 1:
        return _normalize_rel_value_content(_content_list[0])

    var _max_rel_value: = 40

    if _content_size == 2:
        _max_rel_value = 0
    elif _content_size < 5:
        _max_rel_value = 40 + 10 *(_content_size - 5)
    else:
        _max_rel_value = min(40 + 5 *(_content_size - 5), 80)

    if rel_value >= _max_rel_value:
        return _normalize_rel_value_content(_content_list[_content_size - 1])

    if rel_value < - _max_rel_value:
        return _normalize_rel_value_content(_content_list[0])

    var _rel_value_interval: float = _max_rel_value * 2.0 /(_content_size - 2)
    var _current_check_index: int = _content_size - 2
    var _current_check_rel_value: float = _max_rel_value - _rel_value_interval

    var _choose_index: = _content_size - 2
    for _index in range(_content_size - 3):
        if rel_value >= _current_check_rel_value:
            break

        _choose_index -= 1
        _current_check_rel_value -= _rel_value_interval

    return _normalize_rel_value_content(_content_list[_choose_index])






static func _normalize_rel_value_content(_item)-> Array:
    if _item is String:
        return[_item]
    if _item is Array:
        return _item
    return[str(_item)]