extends Node
class_name ModObjectPool



@export var default_pool_size: int = 30


@export var battle_pool_size: int = 80



var _pools: Dictionary = {}


static var _instance: ModObjectPool = null

static func get_instance()-> ModObjectPool:
    return _instance

func _ready()-> void:
    _instance = self







func register_pool(_pool_name: String, _scene: PackedScene, _parent: Node, _preload_count: int = -1)-> void:
    if _pools.has(_pool_name):
        return

    if _preload_count < 0:
        _preload_count = default_pool_size

    var _pool_data: Dictionary = {
        "scene": _scene,
        "free": [],
        "in_use": [],
        "parent": _parent,
        "max_size": _preload_count
    }


    for i in range(_preload_count):
        var _node: Node = _scene.instantiate()
        _parent.add_child(_node)
        _node.set_process(false)
        _node.set_physics_process(false)
        _node.visible = false
        _pool_data["free"].append(_node)

    _pools[_pool_name] = _pool_data



func acquire(_pool_name: String)-> Node:
    if not _pools.has(_pool_name):
        push_error("[ObjectPool] 未注册的池子: " + _pool_name)
        return null

    var _pool: Dictionary = _pools[_pool_name]
    var _node: Node

    if _pool["free"].size() > 0:

        _node = _pool["free"].pop_back()
    else:

        _node = _pool["scene"].instantiate()
        _pool["parent"].add_child(_node)

    _node.set_process(true)
    _node.set_physics_process(true)
    _node.visible = true
    _pool["in_use"].append(_node)

    return _node



func release(_pool_name: String, _node: Node)-> void:
    if not _pools.has(_pool_name):

        if is_instance_valid(_node):
            _node.queue_free()
        return

    var _pool: Dictionary = _pools[_pool_name]


    var _idx: int = _pool["in_use"].find(_node)
    if _idx >= 0:
        _pool["in_use"].pop_at(_idx)

    if not is_instance_valid(_node):
        return


    _node.set_process(false)
    _node.set_physics_process(false)
    _node.visible = false


    if _pool["free"].size() < _pool["max_size"]:
        _pool["free"].append(_node)
    else:
        _node.queue_free()


func clear_pool(_pool_name: String)-> void:
    if not _pools.has(_pool_name):
        return

    var _pool: Dictionary = _pools[_pool_name]
    for _node in _pool["free"]:
        if is_instance_valid(_node):
            _node.queue_free()
    for _node in _pool["in_use"]:
        if is_instance_valid(_node):
            _node.queue_free()

    _pool["free"].clear()
    _pool["in_use"].clear()


func clear_all()-> void:
    for _pool_name in _pools.keys():
        clear_pool(_pool_name)
    _pools.clear()


func get_pool_stats(_pool_name: String)-> Dictionary:
    if not _pools.has(_pool_name):
        return {}
    var _pool: Dictionary = _pools[_pool_name]
    return {
        "free": _pool["free"].size(),
        "in_use": _pool["in_use"].size(),
        "max_size": _pool["max_size"]
    }


func print_all_stats()-> void:
    for _pool_name in _pools.keys():
        var _stats: Dictionary = get_pool_stats(_pool_name)
        print("[ObjectPool] %s: 空闲=%d 使用中=%d 上限=%d" % [
            _pool_name, _stats["free"], _stats["in_use"], _stats["max_size"]
        ])