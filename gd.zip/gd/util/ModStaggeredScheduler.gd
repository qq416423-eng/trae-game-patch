extends Node
class_name ModStaggeredScheduler




@export var batch_size: int = 20


@export var enable_debug_stats: bool = false



var _scan_groups: Dictionary = {}


var _frame_counter: int = 0


static var _instance: ModStaggeredScheduler = null

static func get_instance()-> ModStaggeredScheduler:
    return _instance

func _ready()-> void:
    _instance = self
    set_process(true)





func register_group(_group_name: String, _objects: Array)-> void:
    _scan_groups[_group_name] = {
        "objects": _objects,
        "index": 0,
        "last_full_scan": _frame_counter
    }


func update_group(_group_name: String, _objects: Array)-> void:
    if _scan_groups.has(_group_name):
        var _group: Dictionary = _scan_groups[_group_name]

        if _group["index"] >= _objects.size():
            _group["index"] = 0
        _group["objects"] = _objects


func unregister_group(_group_name: String)-> void:
    _scan_groups.erase(_group_name)




func get_batch_this_frame(_group_name: String)-> Array:
    if not _scan_groups.has(_group_name):
        return[]

    var _group: Dictionary = _scan_groups[_group_name]
    var _objects: Array = _group["objects"]
    var _obj_count: int = _objects.size()

    if _obj_count == 0:
        return[]

    var _index: int = _group["index"]


    var _end: int = _index + batch_size
    var _batch: Array

    if _end >= _obj_count:

        _batch = _objects.slice(_index, _obj_count)
        var _overflow: int = _end - _obj_count
        if _overflow > 0:
            _batch.append_array(_objects.slice(0, _overflow))
        _group["index"] = _overflow
        _group["last_full_scan"] = _frame_counter
    else:
        _batch = _objects.slice(_index, _end)
        _group["index"] = _end

    return _batch






func should_process_this_frame(_group_name: String, _obj)-> bool:
    if not _scan_groups.has(_group_name):
        return true

    var _group: Dictionary = _scan_groups[_group_name]
    var _objects: Array = _group["objects"]
    var _obj_count: int = _objects.size()

    if _obj_count == 0:
        return false

    var _index: int = _group["index"]
    var _obj_idx: int = _objects.find(_obj)
    if _obj_idx < 0:
        return true


    var _end: int =(_index + batch_size) % _obj_count
    if _index < _end:
        return _obj_idx >= _index and _obj_idx < _end
    else:

        return _obj_idx >= _index or _obj_idx < _end


func get_frame_counter()-> int:
    return _frame_counter

func _process(_delta: float)-> void:
    _frame_counter += 1


    if enable_debug_stats and _frame_counter % 300 == 0:
        for _group_name in _scan_groups.keys():
            var _group: Dictionary = _scan_groups[_group_name]
            print("[Staggered] %s: 对象数=%d 当前索引=%d 批大小=%d 上轮完成帧=%d" % [
                _group_name, _group["objects"].size(), _group["index"],
                batch_size, _group["last_full_scan"]
            ])