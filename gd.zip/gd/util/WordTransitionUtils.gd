extends Node2D

static func get_shelf_life_value_name(_value: int)-> String:
    if _value >= 0:
        return str(_value) + "天"
    else:
        return "∞"